package mil;

//r48454

import java.math.BigDecimal;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.logging.log4j.Logger;
import org.jibx.runtime.IUnmarshallingContext;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.P10CostElementCategoryType;
import mil.dtic.cbes.p40.vo.Base;
import mil.dtic.cbes.p40.vo.CodeBPe;
import mil.dtic.cbes.p40.vo.CompoSplit;
import mil.dtic.cbes.p40.vo.CostElement;
import mil.dtic.cbes.p40.vo.Costs;
import mil.dtic.cbes.p40.vo.DeliverySchedule;
import mil.dtic.cbes.p40.vo.DevelopmentMilestone;
import mil.dtic.cbes.p40.vo.ExtendedHistoryPlanning;
import mil.dtic.cbes.p40.vo.ExtendedPYSCosts;
import mil.dtic.cbes.p40.vo.Facility;
import mil.dtic.cbes.p40.vo.HistoryPlanning;
import mil.dtic.cbes.p40.vo.InactiveIndustrialFacility;
import mil.dtic.cbes.p40.vo.InactiveIndustrialFacilityProject;
import mil.dtic.cbes.p40.vo.InstallationCost;
import mil.dtic.cbes.p40.vo.InstallationSchedule;
import mil.dtic.cbes.p40.vo.Item;
import mil.dtic.cbes.p40.vo.ItemGroup;
import mil.dtic.cbes.p40.vo.LayawayDistributionProject;
import mil.dtic.cbes.p40.vo.LayawayFacility;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.Manufacturer;
import mil.dtic.cbes.p40.vo.ManufacturerQuantity;
import mil.dtic.cbes.p40.vo.ModelAffected;
import mil.dtic.cbes.p40.vo.ModsImplementationMethod;
import mil.dtic.cbes.p40.vo.ModsItem;
import mil.dtic.cbes.p40.vo.ModsItemGroup;
import mil.dtic.cbes.p40.vo.ModsManufacturer;
import mil.dtic.cbes.p40.vo.MonthlyDelivery;
import mil.dtic.cbes.p40.vo.OtherBasicItems;
import mil.dtic.cbes.p40.vo.OtherPe;
import mil.dtic.cbes.p40.vo.P10AdvanceProcurement;
import mil.dtic.cbes.p40.vo.P10AdvanceProcurementCustomCategorySubtotal;
import mil.dtic.cbes.p40.vo.P10AdvanceProcurementCustomCostElementCategory;
import mil.dtic.cbes.p40.vo.P10CostElement;
import mil.dtic.cbes.p40.vo.P20BY1InventoryObjective;
import mil.dtic.cbes.p40.vo.P20RequirementsStudy;
import mil.dtic.cbes.p40.vo.P20SupplementalInfo;
import mil.dtic.cbes.p40.vo.P40ContractMethod;
import mil.dtic.cbes.p40.vo.P40ContractType;
import mil.dtic.cbes.p40.vo.P40FundingVehicle;
import mil.dtic.cbes.p40.vo.P40aCategory;
import mil.dtic.cbes.p40.vo.ProductionSupportFacility;
import mil.dtic.cbes.p40.vo.ProductionSupportFacilityProject;
import mil.dtic.cbes.p40.vo.ProductionSupportFacilityProjectCostElement;
import mil.dtic.cbes.p40.vo.ProductionSupportFacilityProjectCostElementItem;
import mil.dtic.cbes.p40.vo.ProductionSupportFacilityProjectRelatedProject;
import mil.dtic.cbes.p40.vo.QuantityForBudgetYear;
import mil.dtic.cbes.p40.vo.QuarterlySchedule;
import mil.dtic.cbes.p40.vo.RelatedPe;
import mil.dtic.cbes.p40.vo.ResourceSummary;
import mil.dtic.cbes.p40.vo.ResourceSummaryRow;
import mil.dtic.cbes.p40.vo.ShipBudgetYearsForPDF;
import mil.dtic.cbes.p40.vo.ShipCategoryItem;
import mil.dtic.cbes.p40.vo.ShipCharacteristics;
import mil.dtic.cbes.p40.vo.ShipClass;
import mil.dtic.cbes.p40.vo.ShipContract;
import mil.dtic.cbes.p40.vo.ShipCostCategory;
import mil.dtic.cbes.p40.vo.ShipFiscalYearFunding;
import mil.dtic.cbes.p40.vo.ShipHull;
import mil.dtic.cbes.p40.vo.ShipInitialReissueStartCompleteDates;
import mil.dtic.cbes.p40.vo.ShipNomenclature;
import mil.dtic.cbes.p40.vo.ShipP35Category;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryCostCategory;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryCostElem;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryExhibit;
import mil.dtic.cbes.p40.vo.SparesBudgetActivity;
import mil.dtic.cbes.p40.vo.SparesItem;
import mil.dtic.cbes.p40.vo.SparesList;
import mil.dtic.cbes.p40.vo.SparesRequirement;
import mil.dtic.cbes.p40.vo.wrappers.ShipFiscalYearFundingMatrixWrapper;
import mil.dtic.utility.CbesLogFactory;

public class P40CayenneJibxFactory
{
  private static final Logger log = CbesLogFactory.getLog(P40CayenneJibxFactory.class);
  private static final ThreadLocal<ObjectContext> _context = new ThreadLocal<ObjectContext>();

  public static ObjectContext getObjectContext() {
    if (_context==null) {
      log.error("_context is null");
      throw new IllegalStateException("No Cayenne ObjectContext available.");
    }
    return _context.get();
  }

  public static void setObjectContext(ObjectContext context) {
    _context.set(context);
  }

  private static <T extends Base> T cachedQuery(boolean preloadWholeTable, Class<T> t, String property, Object value)
  {
    SelectQuery one = new SelectQuery(t, ExpressionFactory.matchExp(property, value));
    SelectQuery all = new SelectQuery(t);
    one.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
    all.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
    if (preloadWholeTable)
      getObjectContext().performQuery(all);
    @SuppressWarnings("unchecked")
    List<T> l = getObjectContext().performQuery(one);
    if (l.isEmpty())
      return null;
    if (l.size()>1)
      log.warn("select returned more than one");
    return l.get(0);
  }

  public static LineItem lineItem() {
    if (getObjectContext()==null){log.error("context is null");}
    return getObjectContext().newObject(LineItem.class);
  }

  public static ResourceSummary resourceSummary() {
    return null;
  }

  public static ResourceSummaryRow resourceSummaryRow() {
    return getObjectContext().newObject(ResourceSummaryRow.class);
  }

  public static RelatedPe codeBPe() {
    return getObjectContext().newObject(CodeBPe.class);
  }

  public static RelatedPe otherPe() {
    return getObjectContext().newObject(OtherPe.class);
  }

  public static ModelAffected modelAffected() {
    return getObjectContext().newObject(ModelAffected.class);
  }

  public static ItemGroup itemGroup(IUnmarshallingContext iuctx) {
    ItemGroup ig = getObjectContext().newObject(ItemGroup.class);
    return ig;
  }

  public static P40aCategory category() {
    return getObjectContext().newObject(P40aCategory.class);
  }

  public static Item item() {
    return getObjectContext().newObject(Item.class);
  }

  public static <T> T dontCallThis() {
    throw new RuntimeException("this factory method should not be called, the mapping should provide an object before calling map-as");
  }

  public static CostElement costElement() {
    return getObjectContext().newObject(CostElement.class);
  }

  public static Manufacturer manufacturer() {
    return getObjectContext().newObject(Manufacturer.class);
  }

  public static HistoryPlanning historyPlanning() {
    return getObjectContext().newObject(HistoryPlanning.class);
  }

  public static ExtendedHistoryPlanning extendedHistoryPlanning() {
    return getObjectContext().newObject(ExtendedHistoryPlanning.class);
  }

  public static P40ContractType deserializeContractType(String ct)
  {
    return cachedQuery(true, P40ContractType.class, P40ContractType.NAME_PROPERTY, ct);
  }

  public static P40ContractMethod deserializeContractMethod(String cm)
  {
    return cachedQuery(true, P40ContractMethod.class, P40ContractMethod.NAME_PROPERTY, cm);
  }

  public static P40FundingVehicle deserializeFundingVehicle(String fv)
  {
    return cachedQuery(true, P40FundingVehicle.class, P40FundingVehicle.NAME_PROPERTY, fv);
  }

  public static DeliverySchedule deliverySchedule() {
    return getObjectContext().newObject(DeliverySchedule.class);
  }

  public static MonthlyDelivery monthlyDelivery() {
    return getObjectContext().newObject(MonthlyDelivery.class);
  }

  public static ManufacturerQuantity manufacturerQuantity() {
    return new ManufacturerQuantity();
  }

  public static Facility facility() {
    return getObjectContext().newObject(Facility.class);
  }

  public static InactiveIndustrialFacility inactiveIndustrialFacility() {
    return getObjectContext().newObject(InactiveIndustrialFacility.class);
  }

  public static LayawayFacility layawayFacility() {
    return getObjectContext().newObject(LayawayFacility.class);
  }

  public static ProductionSupportFacility productionSupportFacility() {
    return getObjectContext().newObject(ProductionSupportFacility.class);
  }

  public static ProductionSupportFacilityProject productionSupportFacilityProject() {
    return getObjectContext().newObject(
      ProductionSupportFacilityProject.class);
  }

  public static InactiveIndustrialFacilityProject inactiveFacilityProject() {
    return getObjectContext().newObject(
      InactiveIndustrialFacilityProject.class);
  }

  public static LayawayDistributionProject layawayFacilityProject() {
    return getObjectContext().newObject(
      LayawayDistributionProject.class);
  }

  public static CompoSplit compoSplit() {
    return getObjectContext().newObject(CompoSplit.class);
  }

  public static ProductionSupportFacilityProjectCostElement productionSupportFacilityProjectCostElement()
  {
    return getObjectContext().newObject(ProductionSupportFacilityProjectCostElement.class);
  }

  public static ProductionSupportFacilityProjectCostElementItem productionSupportFacilityProjectCostElementItem()
  {
    return getObjectContext().newObject(ProductionSupportFacilityProjectCostElementItem.class);
  }

  public static ProductionSupportFacilityProjectRelatedProject productionSupportFacilityProjectRelatedProject()
  {
    return getObjectContext().newObject(ProductionSupportFacilityProjectRelatedProject.class);
  }

  public static Costs costs()
  {
    Costs c = getObjectContext().newObject(Costs.class);
    c.setType(CostRowType.TOTALCOST);
    return c;
  }

  public static Costs qtyCosts()
  {
    Costs c = getObjectContext().newObject(Costs.class);
    c.setType(CostRowType.QUANTITY);
    return c;
  }

  public static ModsItemGroup modsGroup()
  {
    return getObjectContext().newObject(ModsItemGroup.class);
  }

  public static DevelopmentMilestone developmentMilestone()
  {
    return getObjectContext().newObject(DevelopmentMilestone.class);
  }

  public static ModsItem modsItem()
  {
    return getObjectContext().newObject(ModsItem.class);
  }

  public static ModsManufacturer modsManufacturer()
  {
    return getObjectContext().newObject(ModsManufacturer.class);
  }

  public static ModsImplementationMethod modsImplementationMethod()
  {
    return getObjectContext().newObject(ModsImplementationMethod.class);
  }

  public static InstallationCost installationCost()
  {
    return getObjectContext().newObject(InstallationCost.class);
  }

  public static InstallationSchedule installationSchedule()
  {
    return getObjectContext().newObject(InstallationSchedule.class);
  }

  public static SparesRequirement sparesRequirement()
  {
    return getObjectContext().newObject(SparesRequirement.class);
  }

  public static SparesList sparesList()
  {
    return getObjectContext().newObject(SparesList.class);
  }

  public static SparesBudgetActivity sparesBudgetActivity()
  {
    return getObjectContext().newObject(SparesBudgetActivity.class);
  }

  public static SparesItem sparesItem()
  {
    return getObjectContext().newObject(SparesItem.class);
  }

  public static P20RequirementsStudy requirementsStudy()
  {
    return getObjectContext().newObject(P20RequirementsStudy.class);
  }

  public static P20BY1InventoryObjective by1InventoryObjective()
  {
    return getObjectContext().newObject(P20BY1InventoryObjective.class);
  }

  public static P20SupplementalInfo supplementalInfo()
  {
    return getObjectContext().newObject(P20SupplementalInfo.class);
  }

  public static P10AdvanceProcurement p10AdvanceProcurement()
  {
    return getObjectContext().newObject(P10AdvanceProcurement.class);
  }

  public static P10CostElement p10CostElement()
  {
    return getObjectContext().newObject(P10CostElement.class);
  }

  public static P10CostElement p10CFECostElement()
  {
    return P10CostElement.createWithCategory(getObjectContext(),  P10CostElementCategoryType.CFE);
  }

  public static P10CostElement p10GFECostElement()
  {
    return P10CostElement.createWithCategory(getObjectContext(),  P10CostElementCategoryType.GFE);
  }

  public static P10CostElement p10EOQCostElement()
  {
    return P10CostElement.createWithCategory(getObjectContext(),  P10CostElementCategoryType.EOQ);
  }

  public static P10CostElement p10OtherCostElement()
  {
    return P10CostElement.createWithCategory(getObjectContext(),  P10CostElementCategoryType.Other);
  }

  public static P10CostElement p10CustomCostElement()
  {
    return P10CostElement.createWithCategory(getObjectContext(),  P10CostElementCategoryType.Custom);
  }

  public static QuarterlySchedule quarterlySchedule()
  {
    return getObjectContext().newObject(QuarterlySchedule.class);
  }

  public static QuantityForBudgetYear quantityForBudgetYear()
  {
    return getObjectContext().newObject(QuantityForBudgetYear.class);
  }

  public static ShipClass shipClass()
  {
    return getObjectContext().newObject(ShipClass.class);
  }

  public static ShipNomenclature shipNomenclature()
  {
    return getObjectContext().newObject(ShipNomenclature.class);
  }

  public static ShipCharacteristics shipCharacteristics()
  {
    return getObjectContext().newObject(ShipCharacteristics.class);
  }

  public static ShipContract shipContract()
  {
    return getObjectContext().newObject(ShipContract.class);
  }

  public static ShipBudgetYearsForPDF shipBudgetYearsForPDF()
  {
    return getObjectContext().newObject(ShipBudgetYearsForPDF.class);
  }

  public static ShipHull shipHull()
  {
    return getObjectContext().newObject(ShipHull.class);
  }

  public static ShipInitialReissueStartCompleteDates shipInitialReissueStartCompleteDates()
  {
    return getObjectContext().newObject(ShipInitialReissueStartCompleteDates.class);
  }

  public static OtherBasicItems otherBasicItems()
  {
    return getObjectContext().newObject(OtherBasicItems.class);
  }

  public static ExtendedPYSCosts extendedPYSCosts()
  {
    return getObjectContext().newObject(ExtendedPYSCosts.class);
  }

  public static ShipCostCategory shipCostCategory()
  {
    return getObjectContext().newObject(ShipCostCategory.class);
  }

  public static ShipFiscalYearFunding shipFiscalYearFunding()
  {
    return getObjectContext().newObject(ShipFiscalYearFunding.class);
  }

  public static ShipCategoryItem shipCategoryItem()
  {
    return getObjectContext().newObject(ShipCategoryItem.class);
  }

  public static ShipP35Category shipP35Category()
  {
    return getObjectContext().newObject(ShipP35Category.class);
  }

  public static ShipsOutfittingDeliveryCostCategory shipsOutfittingDeliveryCostCategory()
  {
    return getObjectContext().newObject(ShipsOutfittingDeliveryCostCategory.class);
  }

  public static ShipsOutfittingDeliveryCostElem shipsOutfittingDeliveryCostElem()
  {
    return getObjectContext().newObject(ShipsOutfittingDeliveryCostElem.class);
  }

  public static ShipsOutfittingDeliveryExhibit shipsOutfittingDeliveryExhibit()
  {
    return getObjectContext().newObject(ShipsOutfittingDeliveryExhibit.class);
  }

  public static P10AdvanceProcurementCustomCategorySubtotal p10AdvanceProcurementCustomCategorySubtotal()
  {
    return getObjectContext().newObject(P10AdvanceProcurementCustomCategorySubtotal.class);
  }

  public static P10AdvanceProcurementCustomCostElementCategory p10AdvanceProcurementCustomCostElementCategory()
  {
    return new P10AdvanceProcurementCustomCostElementCategory();
  }


  public static ShipFiscalYearFundingMatrixWrapper shipFiscalYearFundingMatrixWrapper()
  {
    return null;
  }

  public static ShipFiscalYearFundingMatrixWrapper customShipFiscalYearFundingMatrixWrapper()
  {
    ShipClass tmp = shipClass();
    return new ShipFiscalYearFundingMatrixWrapper(tmp, tmp.getShipFiscalYearFundings(), "HOLDER_TEXT_TO_BE_SET_FROM_XML_AFTER_MAPPING", ShipClass.SHIP_FISCAL_YEAR_FUNDINGS_RELATIONSHIP_PROPERTY, true);
  }

  //quantites are stored as bigdecimal, convert them to Long
  public static String serializeQty(BigDecimal qty)
  {
    if (qty == null)
      return null;

    //This zero test is used to truncate after the decimal if all values are zero
    //Otherwise, jibx will convert 123 to 123.0, which fails the roundtrip tests.
    long zeroTest = qty.multiply(BigDecimal.valueOf(1000)).longValue();
    long modValue = zeroTest % 1000;
    if(modValue == 0)
      return (zeroTest / 1000) + "";

    return qty.toPlainString();
  }

  public static BigDecimal bigDecimalWithError(String bd)
  {
    return new BigDecimal(bd);
  }

  public static String bigDecimalWithError(BigDecimal bd)
  {
    return bd.toPlainString();
  }
}
