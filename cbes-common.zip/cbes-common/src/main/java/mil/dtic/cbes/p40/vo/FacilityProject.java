package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;



public interface FacilityProject extends HasDisplayOrder
{
}