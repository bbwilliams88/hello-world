/*
 * $Id: R1D.java 44901 2010-08-15 23:22:47Z aibrahim $
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;


public class SDReport extends JBDefaultSystemGeneratedPart
{
  private static final long serialVersionUID = 1L;

  public SDReport()
  {
    this(null);
  }

  public SDReport(String titlePrefix)
  {
    setFileSetting(FileSetting.SD_REPORT);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.SD_REPORT.getTitle()));
  }
}
