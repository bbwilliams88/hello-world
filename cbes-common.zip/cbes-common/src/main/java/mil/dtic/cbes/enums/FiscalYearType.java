package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum FiscalYearType implements ExtendedEnumeration
{
    PRIOR_YEAR_TWENTY     ("PriorYearTwenty",     "PY20", "Prior Year Twenty"), 
    PRIOR_YEAR_NINETEEN   ("PriorYearNineteen",   "PY19", "Prior Year Nineteen"),
    PRIOR_YEAR_EIGHTEEN   ("PriorYearEighteen",   "PY18", "Prior Year Eighteen"),
    PRIOR_YEAR_SEVENTEEN  ("PriorYearSeventeen",  "PY17", "Prior Year Seventeen"),
    PRIOR_YEAR_SIXTEEN    ("PriorYearSixteen",    "PY16", "Prior Year Sixteen"),
    PRIOR_YEAR_FIFTEEN    ("PriorYearFifteen",    "PY15", "Prior Year Fifteen"),
    PRIOR_YEAR_FOURTEEN   ("PriorYearFourteen",   "PY14", "Prior Year Fourteen"),
    PRIOR_YEAR_THIRTEEN   ("PriorYearThirteen",   "PY13", "Prior Year Thirteen"),
    PRIOR_YEAR_TWELVE     ("PriorYearTwelve",     "PY12", "Prior Year Twelve"),
    PRIOR_YEAR_ELEVEN     ("PriorYearEleven",     "PY11", "Prior Year Eleven"),
    PRIOR_YEAR_TEN        ("PriorYearTen",        "PY10", "Prior Year Ten"),
    PRIOR_YEAR_NINE       ("PriorYearNine",       "PY9",  "Prior Year Nine"),
    PRIOR_YEAR_EIGHT      ("PriorYearEight",      "PY8",  "Prior Year Eight"),
    PRIOR_YEAR_SEVEN      ("PriorYearSeven",      "PY7",  "Prior Year Seven"),
    PRIOR_YEAR_SIX        ("PriorYearSix",        "PY6",  "Prior Year Six"),
    PRIOR_YEAR_FIVE       ("PriorYearFive",       "PY5",  "Prior Year Five"),
    PRIOR_YEAR_FOUR       ("PriorYearFour",       "PY4",  "Prior Year Four"),
    PRIOR_YEAR_THREE      ("PriorYearThree",      "PY3",  "Prior Year Three"),
    PRIOR_YEAR_TWO        ("PriorYearTwo",        "PY2",  "Prior Year Two"),
    PRIOR_YEAR            ("PriorYear",           "PY",   "Prior Year"),
    CURRENT_YEAR          ("CurrentYear",         "CY",   "Current Year"),
    BUDGET_YEAR_ONE       ("BudgetYearOne",       "BY1",  "Budget Year One"),
    BUDGET_YEAR_TWO       ("BudgetYearTwo",       "BY2",  "Budget Year Two"),
    BUDGET_YEAR_THREE     ("BudgetYearThree",     "BY3",  "Budget Year Three"),
    BUDGET_YEAR_FOUR      ("BudgetYearFour",      "BY4",  "Budget Year Four"),
    BUDGET_YEAR_FIVE      ("BudgetYearFive",      "BY5",  "Budget Year Five"),
    BUDGET_YEAR_SIX      ("BudgetYearSix",      "BY6",  "Budget Year Six"),
    BUDGET_YEAR_SEVEN      ("BudgetYearSeven",      "BY7",  "Budget Year Seven");

    private final String xmlName;
    private final String dbName;
    private final String description;

    private FiscalYearType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static FiscalYearType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(FiscalYearType.class, databaseValue);
    }

    public static FiscalYearType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(FiscalYearType.class, enumValue);
    }
}
