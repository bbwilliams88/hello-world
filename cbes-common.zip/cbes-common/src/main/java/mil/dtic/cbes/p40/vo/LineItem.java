package mil.dtic.cbes.p40.vo;

import static java.math.BigDecimal.ZERO;
import static mil.dtic.cbes.enums.ItemExhibitType.P17;
import static mil.dtic.cbes.enums.ItemExhibitType.P18;
import static mil.dtic.cbes.enums.ItemExhibitType.P25;
import static mil.dtic.cbes.enums.ItemExhibitType.P26;
import static mil.dtic.cbes.enums.ItemExhibitType.P29P30;
import static mil.dtic.cbes.enums.ItemExhibitType.P3A;
import static mil.dtic.cbes.enums.ItemExhibitType.P40A;
import static mil.dtic.cbes.enums.ItemExhibitType.P5;
import static mil.dtic.cbes.enums.ItemExhibitType.P5S;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.InitialSourceType;
import mil.dtic.cbes.data.config.ValidityType;
import mil.dtic.cbes.data.config.XmlValidityType;
import mil.dtic.cbes.dto.P1DataValidationBean;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ManufacturerRateUnitType;
import mil.dtic.cbes.enums.MonetaryUnitType;
import mil.dtic.cbes.enums.QuantityUnitNameType;
import mil.dtic.cbes.enums.QuantityUnitType;
import mil.dtic.cbes.enums.ResourceSummaryEntryType;
import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.service.exception.NotFoundException;
import mil.dtic.cbes.p40.service.exception.ProcurementServiceException;
import mil.dtic.cbes.p40.vo.auto._LineItem;
import mil.dtic.cbes.p40.vo.jibx.LineItemPostprocessData;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.p40.vo.wrappers.ResourceSummaryWrapper;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.validation.backend.CacheFactory;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class LineItem
    extends _LineItem
    implements CompoSplitParent,
               Equivalence<LineItem>,
               HasUnitsAndBudgetYear,
               HasValidity,
               PriorYearsDeltaParent,
               RollupParent,
               ResourceSummaryParent
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(LineItem.class);

  private transient LineItemPostprocessData jibxData;
  private transient int advanceProcurementTotalPages;
  private transient Map<String, P1DataValidationBean> p1DataCache;
  private transient Boolean isPrcpLoadedForBudgetYear;

  private String multiYearProcurementSystem;
  
  private transient Boolean suppressOutfittingDeliveryBY2ToBY5;

  /***********************************************************************/
  /*** Cayenne Callbacks                                               ***/
  /***********************************************************************/

  /**
   * Upon creation of a new Line Item through the web UI, sets all the default values
   * for the object and in the DB.
   */
  @Override
  protected void onPostAdd()
  {
    setValidity(ValidityType.NONE);
    setStatus(StatusType.ACTIVE);
    setErrorCount((short) 0);
    setWarningCount((short) 0);
    setP10Count((short) 0);
    setP17Count((short) 0);
    setP18Count((short) 0);
    setP20Count((short) 0);
    setP21Count((short) 0);
    setP23Count((short) 0);
    setP25Count((short) 0);
    setP26Count((short) 0);
    setP3aCount((short) 0);
    setP40aCount((short) 0);
    setP5Count((short) 0);
    setP5aCount((short) 0);
    setXmlValidity(XmlValidityType.VALID);
    setInitialSource(InitialSourceType.WEB);
    setTest(false);
    setUnitCostUnits(MonetaryUnitType.Millions);
    setQuantityUnits(QuantityUnitType.Each);
    setQuantityUnitName(QuantityUnitNameType.Each);
    setTotalCostUnits(MonetaryUnitType.Millions);
    // setManufacturerRateUnit(ManufacturerRateUnitType.MONTHLY);
    // default PDF option is to suppress P40A and include P40A data in Item
    // Schedule to avoid redundancy
    setGenerateItemSchedule(true);
    setP40aItemScheduleFlag("expandItemSuppressExhibit");
    setSuppressP40As(true);
    setExpandP40AInItemSchedule(true);
    setupModsOutYearsDeltas();
    setupSecondaryDistributionSubtotal();
  }


  @Override
  protected void onPostLoad()
  {
    // Will leave unset to force users to deliberately specify a rate now so
    // they don't mistakenly use the wrong one.
    // if (getManufacturerRateUnit() == null)
    // setManufacturerRateUnit(ManufacturerRateUnitType.MONTHLY);

    setupModsOutYearsDeltas();
    setupSecondaryDistributionSubtotal();
  }


  private void setupModsOutYearsDeltas()
  {
    if (getModsOutYearsDelta() == null)
      setModsOutYearsDelta(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

    if (getModsOutYearsQuantityDelta() == null)
      setModsOutYearsQuantityDelta(Costs.create(getObjectContext(), CostRowType.QUANTITY));
  }


  public void setupSecondaryDistributionSubtotal()
  {
    if (getSecondaryDistributionQuantity() == null)
      setSecondaryDistributionQuantity(Costs.create(getObjectContext(), CostRowType.QUANTITY));

    if (getSecondaryDistributionTotalCosts() == null)
      setSecondaryDistributionTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
  }


  @Override
  protected void onPrePersist()
  {
    Util.cleanupContinuingTriplet(getResourceSummary());
  }


  @Override
  protected void onPreUpdate()
  {
    log.debug("onPreUpdate");
  }


  /***********************************************************************/
  /*** Custom Accessors                                                ***/
  /***********************************************************************/
  public String getCodeBText()
  {
    return getPeText(CODE_BPE_LIST_RELATIONSHIP_PROPERTY);
  }


  public void setCodeBText(String newVal)
  {
    setPeText(CodeBPe.class, CODE_BPE_LIST_RELATIONSHIP_PROPERTY, getCodeBText(), newVal);
  }


  /**
   * @return quantities value for this component as a parent of the compo split
   */
  @Override
  public Quantities getCompoSplitParentQuantities()
  {
    ResourceSummaryRow summary = getResourceSummary().getQuantity();

    if (summary != null)
    {
      Quantities quantities = new Quantities(summary.getCosts());
      return quantities;
    }
    else
    {
      return null;
    }
  }


  @Override
  public List<Exhibit> getExhibits()
  {
    List<Exhibit> exhibits = getSortedByDisplayOrder(super.getExhibits());

    return exhibits;
  }


  @SuppressWarnings("unchecked")
  public List<LineItemHistory> getHistoryWithUsers()
  {
    SelectQuery query = new SelectQuery(LineItemHistory.class, ExpressionFactory.matchExp(LineItemHistory.LINE_ITEM_RELATIONSHIP_PROPERTY, this));

    query.addPrefetch(LineItemHistory.MODIFIED_BY_RELATIONSHIP_PROPERTY);

    return getObjectContext().performQuery(query);
  }


  public String getOtherPeText()
  {
    return getPeText(OTHER_PE_LIST_RELATIONSHIP_PROPERTY);
  }


  public void setOtherPeText(String newVal)
  {
    setPeText(OtherPe.class, OTHER_PE_LIST_RELATIONSHIP_PROPERTY, getOtherPeText(), newVal);
  }


  @Override
  public ResourceSummary getResourceSummary()
  {
    return new ResourceSummaryWrapper(this, super.getResourceSummaryRows(), RESOURCE_SUMMARY_ROWS_RELATIONSHIP_PROPERTY, true);
  }


  public void setResourceSummary(ResourceSummaryWrapper l)
  {
    log.trace("Collection setters not implemented " + (l == null ? null : l.size()));
  }


  @Override
  public void setSecondaryDistributionQuantity(Costs newCosts)
  {
    Costs originalCosts = getSecondaryDistributionQuantity();

    if (originalCosts != null && originalCosts != newCosts)
    {
      super.setSecondaryDistributionQuantity(null);
      originalCosts.delete();
    }

    super.setSecondaryDistributionQuantity(newCosts);
  }


  @Override
  public void setSecondaryDistributionTotalCosts(Costs newCosts)
  {
    Costs originalCosts = getSecondaryDistributionTotalCosts();

    if (originalCosts != null && originalCosts != newCosts)
    {
      super.setSecondaryDistributionTotalCosts(null);
      originalCosts.delete();
    }

    super.setSecondaryDistributionTotalCosts(newCosts);
  }

  public String getClassificationLabel()
  {
      return Util.getClassificationLabel();
  }

  public boolean isUnique()
  {
    Expression exp1 = ExpressionFactory.matchExp(LINE_ITEM_NUMBER_PROPERTY, getLineItemNumber());
    Expression exp2 = ExpressionFactory.matchExp(SERVICE_AGENCY_RELATIONSHIP_PROPERTY, getServiceAgency());
    Expression exp3 = ExpressionFactory.matchExp(BUDGET_SUB_ACTIVITY_RELATIONSHIP_PROPERTY, getBudgetSubActivity());
    Expression exp4 = ExpressionFactory.matchExp(BUDGET_CYCLE_PROPERTY, getBudgetCycle());
    Expression exp5 = ExpressionFactory.matchExp(BUDGET_YEAR_PROPERTY, getBudgetYear());
    Expression exp6 = ExpressionFactory.matchExp(STATUS_PROPERTY, StatusType.ACTIVE);
    Expression exp7 = ExpressionFactory.matchExp(TEST_PROPERTY, getTest());
    Expression expression = exp1.andExp(exp2).andExp(exp3).andExp(exp4).andExp(exp5).andExp(exp6).andExp(exp7);
    SelectQuery query = new SelectQuery(LineItem.class, expression);

    @SuppressWarnings("unchecked")
    List<LineItem> results = CayenneUtils.createDataContext().performQuery(query);

    // log.debug("isUnique lineItems = " + results);

    if (results.size() == 0)
      return true;
    else if (results.size() > 1)
      return false;

    LineItem lineItem = results.get(0);

    // log.debug("isUnique lineItem = " + lineItem);
    // log.debug("isUnique fetched lineItem.pk = " + lineItem.getId());
    // log.debug("isUnique existing lineItem.pk = " + getId());

    // boolean returnValue;

    // if (lineItem.getId() == getId())
    // returnValue = true;
    // else
    // returnValue = false;

    return ObjectUtils.equals(lineItem.getId(), getId());
    // log.debug("isUnique returning = " + returnValue);

    // return returnValue;
  }

  /***********************************************************************/
  /*** Business Logic                                                  ***/
  /***********************************************************************/

  private void addResourceSummariesToLineItem(List<ResourceSummaryRow> resourceSummaryList)
  {
    for (ResourceSummaryEntryType entryType : ResourceSummaryEntryType.lineItemRows)
      resourceSummaryList.add(ResourceSummaryRow.create(getObjectContext(), entryType));
  }


  private void addResourceSummariesForP5(List<ResourceSummaryRow> resourceSummaryList)
  {
    for (ResourceSummaryEntryType entryType : ResourceSummaryEntryType.itemRows)
      resourceSummaryList.add(ResourceSummaryRow.create(getObjectContext(), entryType));
  }


  private void addResourceSummariesForP3A(List<ResourceSummaryRow> resourceSummaryList)
  {
    for (ResourceSummaryEntryType entryType : ResourceSummaryEntryType.p3aRows)
      resourceSummaryList.add(ResourceSummaryRow.create(getObjectContext(), entryType));
  }

  @Override
  public void clearOutYears()
  {
      // Do nothing -- don't clear Line Item's out-year data.
  };

  // @Override
  // public void setPysDelta(BigDecimal pysDelta)
  // {
  // if(pysDelta.scale() > 3)
  // pysDelta.setScale(3);
  // super.setPysDelta(pysDelta);
  // }

  // shift 'forward in time' by shifting costs 'back in time'
  @Override
  public void shiftForwardInTime(int years)
  {
    for (CodeBPe codeBProgramElement : this.getCodeBPeList())
      codeBProgramElement.shiftForwardInTime(years);

    for (CompoSplit split : this.getComponentSplitList())
      split.shiftForwardInTime(years);

    if (this.getSecondaryDistributionTotalCosts() != null)
    {
      this.getSecondaryDistributionTotalCosts().shiftForwardInTime(years);
      this.getSecondaryDistributionTotalCosts().setPriorYears(null);
    }

    if (this.getSecondaryDistributionQuantity() != null)
    {
      this.getSecondaryDistributionQuantity().shiftForwardInTime(years);
      this.getSecondaryDistributionQuantity().setPriorYears(null);
    }




    for (Exhibit exhibit : this.getExhibits())
      exhibit.shiftForwardInTime(years);

    for (OtherPe otherProgramElement : this.getOtherPeList())
      otherProgramElement.shiftForwardInTime(years);

    for (ResourceSummaryRow resourceSummaryRow : this.getResourceSummaryRows())
      resourceSummaryRow.shiftForwardInTime(years);
  }


  /***********************************************************************/
  /*** Utilities                                                       ***/
  /***********************************************************************/

  /**
   * Checks to see if a LineItem with the key set exists in the database already
   * to prevent creating a second one
   *
   * @param budgetCycle
   * @param budgetYear
   * @param p1LineItemNumber
   * @param serviceAgency
   * @param budgetSubActivity
   * @return
   */
  public static boolean alreadyExists(String budgetCycle, Integer budgetYear, String lineItemNumber, ServiceAgency serviceAgency, BudgetSubActivity budgetSubActivity, boolean isTest)
  {
    Expression exp4 = ExpressionFactory.matchExp(BUDGET_CYCLE_PROPERTY, budgetCycle);
    Expression exp5 = ExpressionFactory.matchExp(BUDGET_YEAR_PROPERTY, budgetYear);
    Expression exp2 = ExpressionFactory.matchExp(LINE_ITEM_NUMBER_PROPERTY, lineItemNumber);
    Expression exp1 = ExpressionFactory.matchExp(SERVICE_AGENCY_RELATIONSHIP_PROPERTY, serviceAgency);
    Expression exp3 = ExpressionFactory.matchExp(BUDGET_SUB_ACTIVITY_RELATIONSHIP_PROPERTY, budgetSubActivity);
    Expression exp6 = ExpressionFactory.matchExp(STATUS_PROPERTY, StatusType.ACTIVE);
    Expression exp7 = ExpressionFactory.matchExp(TEST_PROPERTY, isTest);
    Expression expression = exp1.andExp(exp2).andExp(exp3).andExp(exp4).andExp(exp5).andExp(exp6).andExp(exp7);
    SelectQuery query = new SelectQuery(LineItem.class, expression);

    @SuppressWarnings("unchecked")
    List<LineItem> results = CayenneUtils.createDataContext().performQuery(query);

    if (results.isEmpty())
    {
      return false;
    }
    else
    {
      return true;
    }
  }


  /**
   *
   * @param context
   * @param budgetCycle
   * @param lineItemNumber
   * @param agency
   * @param budgetSubActivity
   * @return null if this set of unique parameters already exists in the
   *         database, otherwise a new LineItem with the values passed in
   * @throws ProcurementServiceException
   */
  public static LineItem createNewLineItem(ObjectContext context, BudgetCycle budgetCycle, String lineItemNumber, String p1LineItemNumber, ServiceAgency agency, BudgetSubActivity budgetSubActivity)
  {
    if (budgetCycle == null || lineItemNumber == null || agency == null || budgetSubActivity == null)
      throw new NullPointerException();

    if (alreadyExists(budgetCycle.getCycle(), budgetCycle.getBudgetYear(), lineItemNumber, agency, budgetSubActivity, false))
      return null;

    LineItem lineItem = context.newObject(LineItem.class);
    lineItem.setP1LineItemNumber(p1LineItemNumber);
    lineItem.setBudgetCycle(budgetCycle.getCycle());
    lineItem.setBudgetYear(budgetCycle.getBudgetYear());
    lineItem.setSubmissionDate(budgetCycle.getSubmissionDates().get(0).getDate());
    lineItem.setLineItemNumber(lineItemNumber);
    lineItem.setServiceAgency(CayenneUtils.copyToContext(agency, context));
    lineItem.setBudgetSubActivity(CayenneUtils.copyToContext(budgetSubActivity, context));
    lineItem.addResourceSummariesToLineItem(lineItem.getResourceSummary());
    lineItem.setupSecondaryDistributionSubtotal();

    return lineItem;
  }


  public static List<LineItem> fetchAllActive(ObjectContext context)
  {
    return fetch(context, LineItem.class, Expression.EQUAL_TO, null, LineItem.STATUS_PROPERTY, StatusType.ACTIVE);
  }


  public static List<LineItem> fetchWithIds(ObjectContext context, Collection<Integer> ids)
  {
    return fetchWithIds(context, LineItem.class, LI_ID_PK_COLUMN, ids.toArray(new Object[0]));
  }

  public static List<LineItem> fetchActiveByBudgetCycle(ObjectContext context, BudgetCycle budgetCycle)
  {
    return fetch(context, LineItem.class, Expression.EQUAL_TO, null, LineItem.STATUS_PROPERTY, LineItem.BUDGET_CYCLE_PROPERTY, LineItem.BUDGET_YEAR_PROPERTY, StatusType.ACTIVE, budgetCycle.getCycle(), budgetCycle.getBudgetYear());
  }

  public static List<LineItem> fetchActiveByServiceAgencyAndBudgetCycle(ObjectContext context, List<ServiceAgency> serviceAgencies, BudgetCycle budgetCycle)
  {
    List<LineItem> results = fetchActiveByBudgetCycle(context,budgetCycle);
    Expression exp = ExpressionFactory.inExp(SERVICE_AGENCY_RELATIONSHIP_PROPERTY, serviceAgencies);
    List<LineItem> filtered = exp.filterObjects(results);
    return filtered;
  }

  @SuppressWarnings("unchecked")
  public static List<LineItem> fetchByIdsWithResourceSummaries(ObjectContext context, Collection<Integer> ids)
  {
    SelectQuery query = new SelectQuery(LineItem.class, ExpressionFactory.inDbExp(LI_ID_PK_COLUMN, ids));
    // q.addPrefetch(LineItem.RESOURCE_SUMMARY_ROWS_PROPERTY); // TODO this
    // is breaking things, I suppose I'll have to live with the extra
    // selects
    query.addPrefetch(makePath(LineItem.RESOURCE_SUMMARY_ROWS_RELATIONSHIP_PROPERTY, ResourceSummaryRow.COSTS_RELATIONSHIP_PROPERTY));

    return context.performQuery(query);
  }


  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  public void jibx_setCombinedP5Flag(String flag)
  {
    if (StringUtils.equals("true", flag))
      setCombinedP5Flag(Boolean.TRUE);
    else if (StringUtils.equals("false", flag))
      setCombinedP5Flag(Boolean.FALSE);
  }

  public String jibx_getCombinedP5Flag()
  {
    if (getCombinedP5Flag())
      return "true";

    return "false";
  }

  public boolean jibx_hasCombinedP5Flag()
  {
    return getCombinedP5Flag() != null;
  }

  public void jibx_setManufacturerRateUnit(String value)
  {
    setManufacturerRateUnit(ManufacturerRateUnitType.fromEnumValue(value));
  }


  public String jibx_getManufacturerRateUnit()
  {
    if (getManufacturerRateUnit() != null)
      return getManufacturerRateUnit().getLabel();
    else
      return null;
  }


  public boolean jibx_hasAdvanceProcurement()
  {
    if (getAdvanceProcurementP1LineItemNumber() == null && getAdvanceProcurementDescription() == null)
      return false;

    return true;
  }


  // jibx uses this to generate xml
  public void initJibxData()
  {
    jibxData = new LineItemPostprocessData();
    if (getServiceAgency() != null)
    {
      jibxData.setServiceAgencyName(getServiceAgency().getName());
    }
    if (getBudgetSubActivity() != null)
    {
      jibxData.setBudgetSubActivityNumber(getBudgetSubActivity().getNumber());
      jibxData.setBudgetSubActivityTitle(getBudgetSubActivity().getTitle());
      if (getBudgetSubActivity().getBudgetActivity() != null)
      {
        jibxData.setBudgetActivityNumber(getBudgetSubActivity().getBudgetActivity().getNumber());
        jibxData.setBudgetActivityTitle(getBudgetSubActivity().getBudgetActivity().getTitle());
        if (getBudgetSubActivity().getBudgetActivity().getAppropriation() != null)
        {
          jibxData.setAppropriationNumber(getBudgetSubActivity().getBudgetActivity().getAppropriation().getCode());
          jibxData.setAppropriationTitle(getBudgetSubActivity().getBudgetActivity().getAppropriation().getName());
        }
      }
    }
  }


  public LineItemPostprocessData getJibxData()
  {
    return jibxData;
  }


  public void setJibxData(LineItemPostprocessData jibxData)
  {
    this.jibxData = jibxData;
  }


  public boolean jibx_hasStandardExhibitList()
  {
    // A Facility P40 will have one Exhibit. Ships exhibits aren't in the standard set. If either Facility or Ships Exhibits are present, this should return false.
    return CollectionUtils.isNotEmpty(getExhibits()) && getExhibits().get(0).getFacility() == null && !jibx_hasShipsExhibitList();
  }

  public boolean jibx_hasShipsExhibitList()
  {
    if (CollectionUtils.isNotEmpty(getExhibits()))
    {
      for (Exhibit exhibit : getExhibits())
      {
        if (exhibit.getP5ShipClass() == null && exhibit.getP29P30Combined() == null)
        {
          return false;
        }
      }
      return true;
    }
    return false;
  }


  public boolean jibx_hasModsOutYearsDelta()
  {
    // Check if there is a Mods Delta for this Line Item.
    if (jibx_hasModsOutYearsCostDelta() || jibx_hasModsOutYearsQuantityDelta())
      return true;

    return false;
  }


  public boolean jibx_hasModsOutYearsCostDelta()
  {
    if (getModsOutYearsDelta() != null && !getModsOutYearsDelta().isEmpty())
      return true;
    return false;
  }


  public boolean jibx_hasModsOutYearsQuantityDelta()
  {
    if (getModsOutYearsQuantityDelta() != null && !getModsOutYearsQuantityDelta().isEmpty())
      return true;
    return false;
  }


  @Override
  public boolean jibx_hasPysDelta()
  {
    // Check if there is a Prior Years Delta for this Line Item.
    if (getPysDelta() != null || getPysQuantityDelta() != null)
      return true;

    return false;
  }


  @Override
  public boolean jibx_hasPysQuantityDelta()
  {
    if (getPysQuantityDelta() != null)
      return true;
    else
      return false;
  }


  @Override
  public boolean jibx_hasPysCostDelta()
  {
    if (getPysDelta() != null)
      return true;
    else
      return false;
  }


  public LineItem jibx_getLineItem()
  {
    // Jibx insists on an object for ItemExhibitList, I don't feel like
    // making
    // one
    return this;
  }


  public void jibx_setLineItem(LineItem li)
  {
  }


  public void jibx_addFacility(Facility facility)
  {
    Exhibit exhibit = getObjectContext().newObject(Exhibit.class);

    if (facility instanceof InactiveIndustrialFacility)
    {
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P26));
      exhibit.setInactiveFacility((InactiveIndustrialFacility) facility);
    }
    else if (facility instanceof LayawayFacility)
    {
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P17));
      exhibit.setLayawayFacility((LayawayFacility) facility);
    }
    else if (facility instanceof ProductionSupportFacility)
    {
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P25));
      exhibit.setProductionFacility((ProductionSupportFacility) facility);
    }

    exhibit.setDisplayOrder(Util.getNextDisplayOrderValue(getExhibits()));
    addToExhibits(exhibit);
  }


  public Iterator<Facility> jibx_facilityIterator()
  {
    // create facility list from line item
    List<Facility> facilities = new ArrayList<Facility>();

    for (Exhibit exhibit : getExhibits())
      if (exhibit.getFacility() != null)
        facilities.add(exhibit.getFacility());

    return facilities.iterator();
  }


  public boolean jibx_hasFacilities()
  {
    return CollectionUtils.isNotEmpty(getExhibits()) && getExhibits().get(0).getFacility() != null;
  }


  public boolean jibx_hasCodeBPes()
  {
    return CollectionUtils.isNotEmpty(getCodeBPeList());
  }


  @SuppressWarnings("unchecked")
  public Iterator<CodeBPe> jibx_codeBPeIterator()
  {
    return IteratorUtils.unmodifiableIterator(getCodeBPeList().iterator());
  }


  public boolean jibx_hasOtherPes()
  {
    return CollectionUtils.isNotEmpty(getOtherPeList());
  }


  @SuppressWarnings("unchecked")
  public Iterator<OtherPe> jibx_otherPeIterator()
  {
    return IteratorUtils.unmodifiableIterator(getOtherPeList().iterator());
  }


  public boolean jibx_hasMDAPCode()
  {
    return getMdapCode() != null;
  }


  public boolean jibx_hasDocumentAssemblyOptions()
  {
    return jibx_hasP40aItemScheduleFlag() || jibx_hasTrackingNote();
  }

  public boolean jibx_hasP40aItemScheduleFlag()
  {
    return this.getP40aItemScheduleFlag() != null || this.getGenerateItemSchedule();
  }

  public boolean jibx_hasTrackingNote()
  {
    return StringUtils.isNotEmpty(getTrackingNote());
  }

  @Override
  public boolean jibx_hasComponentSplit()
  {
    return CollectionUtils.isNotEmpty(getComponentSplitList());
  }


  @Override
  public Iterator<CompoSplit> jibx_componentSplitIterator()
  {
    return getIterator(getComponentSplitList());
  }


  public void jibx_postSet()
  {
    Util.generateDisplayOrder(getComponentSplitList());
    Util.generateDisplayOrder(getExhibits());
  }


  public boolean jibx_hasSecondaryDistributionSubtotal()
  {
    return getSecondaryDistributionTotalCosts() != null && !getSecondaryDistributionTotalCosts().isEmpty();
  }


  public boolean jibx_hasSecondaryDistributionQuantity()
  {
    return getSecondaryDistributionQuantity() != null && !getSecondaryDistributionQuantity().isEmpty();
  }


  public void jibx_setSecondaryDistributionQuantity(Costs quantities)
  {
    if (quantities != null)
      setSecondaryDistributionQuantity(quantities);
  }


  public void jibx_setSecondaryDistributionTotalCosts(Costs totalCosts)
  {
    if (totalCosts != null)
      setSecondaryDistributionTotalCosts(totalCosts);
  }


  public Costs jibx_getSecondaryDistributionQuantity()
  {
    return getSecondaryDistributionQuantity();
  }


  public Costs jibx_getSecondaryDistributionTotalCosts()
  {
    return getSecondaryDistributionTotalCosts();
  }


  public void jibx_setModsOutYearsDelta(Costs modsOutYearsDelta)
  {
    if (modsOutYearsDelta != null)
      setModsOutYearsDelta(modsOutYearsDelta);
  }


  public void jibx_setModsOutYearsQuantityDelta(Costs modsOutYearsQuantityDelta)
  {
    if (modsOutYearsQuantityDelta != null)
      setModsOutYearsQuantityDelta(modsOutYearsQuantityDelta);
  }

  public String getMultiYearProcurementSystem()
  {
    return multiYearProcurementSystem;
  }

  public boolean jibx_hasMultiYearProcurementSystem()
  {
    return multiYearProcurementSystem != null;
  }

 /**
   * This setter should only be used by java during pdf creation to indicate what MYP this Line Item is associated with.
   * @param multiYearProcurementSystem
   */
  public void setMultiYearProcurementSystem(String multiYearProcurementSystem)
  {
    this.multiYearProcurementSystem = multiYearProcurementSystem;
  }

  private enum OutYearsMethods
  {
    BY2
    {
      @Override
      public String toString()
      {
        return "getBy2";
      }
    },
    BY3
    {
      @Override
      public String toString()
      {
        return "getBy3";
      }
    },
    BY4
    {
      @Override
      public String toString()
      {
        return "getBy4";
      }
    },
    BY5
    {
      @Override
      public String toString()
      {
        return "getBy5";
      }
    },
    TOCOMPLETE
    {
      @Override
      public String toString()
      {
        return "getToComplete";
      }
    },
    TOTAL
    {
      @Override
      public String toString()
      {
        return "getTotal";
      }
    }
  }

  @Override
  public boolean suppressOutyears() throws MethodDispatchException
  {
    for (Exhibit exhibit : getExhibits())
    {
      for (OutYearsMethods methodName : OutYearsMethods.values())
      {
//        try
//        {
//          Method method = Costs.class.getMethod(methodName.toString(), (Class<?>[]) null);
          if (exhibit.getP5Item() != null)
          {
            Item item = exhibit.getP5Item();
            if (item.getCosts() != null)
            {
                BigDecimal cost = (BigDecimal) Util.dispatch(item.getCosts(), methodName.toString());
//                BigDecimal cost = (BigDecimal) method.invoke(item.getCosts());
              if (cost != null && cost.compareTo(ZERO) != 0)
                return false;
            }
          }
          else if (exhibit.getP40aItemGroup() != null)
          {
            ItemGroup itemGroup = exhibit.getP40aItemGroup();
            for (P40aCategory category : itemGroup.getCategories())
            {
              for (Item item : category.getItems())
              {
                if (item.getCosts() != null)
                {
                    BigDecimal cost = (BigDecimal) Util.dispatch(item.getCosts(), methodName.toString());
//                    BigDecimal cost = (BigDecimal) method.invoke(item.getCosts());
                  if (cost != null && cost.compareTo(ZERO) != 0)
                    return false;
                }
              }
            }
          }
          else if (exhibit.getModsItemGroup() != null)
          {
            return false;
          }
//        }
//        catch (NoSuchMethodException e)
//        {
//          log.fatal("Method " + methodName + " not found in Costs object. This should never happen.", e);
//          throw e;
//        }
//        catch (InvocationTargetException e)
//        {
//          log.error("An exception was thrown while executing method " + methodName, e.getCause());
//          throw e;
//        }
//        catch (IllegalAccessException e)
//        {
//          log.fatal("An illegal access execption was thrown when executing method " + methodName + " on the Costs object. This should never happen", e);
//          throw e;
//        }
      }
    }
    return true;
  }


  // Used to check the Quantities in sub-exhibits for any value
  public boolean suppressQuantityOutyears() throws MethodDispatchException
  {
    if (!Constants.BUDGET_CYCLE_PB.equals(getBudgetCycle()) &&
        !Constants.BUDGET_CYCLE_PB_AMENDED.equals(getBudgetCycle()) &&
        !Constants.BUDGET_CYCLE_PB_SUPPLEMENTAL.equals(getBudgetCycle()))
      return false;
    else
    {
      for (Exhibit exhibit : getExhibits())
      {
        for (OutYearsMethods methodName : OutYearsMethods.values())
        {
//          try
//          {
//            Method method = Costs.class.getMethod(methodName.toString(), (Class<?>[]) null);
            if (exhibit.getP5Item() != null)
            {
              Item item = exhibit.getP5Item();
              if (item.getQuantities() != null)
              {
                  BigDecimal cost = (BigDecimal) Util.dispatch(item.getQuantities(), methodName.toString());
//                  BigDecimal cost = (BigDecimal) method.invoke(item.getQuantities());
                if (cost != null && cost.compareTo(ZERO) != 0)
                  return false;
              }
            }
            else if (exhibit.getP40aItemGroup() != null)
            {
              ItemGroup itemGroup = exhibit.getP40aItemGroup();
              for (P40aCategory category : itemGroup.getCategories())
              {
                for (Item item : category.getItems())
                {
                  if (item.getQuantities() != null)
                  {
                      BigDecimal cost = (BigDecimal) Util.dispatch(item.getQuantities(), methodName.toString());
//                      BigDecimal cost = (BigDecimal) method.invoke(item.getQuantities());
                    if (cost != null && cost.compareTo(ZERO) != 0)
                      return false;
                  }
                }
              }
            }
            else if (exhibit.getModsItemGroup() != null)
            {
              return false;
            }
//          }
//          catch (NoSuchMethodException e)
//          {
//            Util.fatal(log, "Method " + methodName + " not found in Costs object. This should never happen.", e);
//          }
//          catch (InvocationTargetException e)
//          {
//              Util.error(log, "An exception was thrown while executing method " + methodName, e);
//          }
//          catch (IllegalAccessException e)
//          {
//              Util.fatal(log, "An illegal access execption was thrown when executing method " + methodName + " on the Costs object. This should never happen", e);
//          }
        }
      }
      return true;
    }
  }


  // wrap a P5/P40a/P3a/whatever object in an Exhibit and add it
  public Exhibit addExhibit(ItemExhibitType itemExhibitType)
  {
    int displayOrder = Util.getNextDisplayOrderValue(getExhibits());
    Exhibit exhibit = getObjectContext().newObject(Exhibit.class);

    exhibit.setDisplayOrder(displayOrder);
    itemExhibitType.setExhibit(exhibit);
    exhibit.setLockedBy(getLockedBy());
    exhibit.setLockedByDate(new Timestamp(new Date().getTime()));

    if (itemExhibitType instanceof Item)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P5));
    else if (itemExhibitType instanceof ItemGroup)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P40A));
    else if (itemExhibitType instanceof ModsItemGroup)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P3A));
    else if (itemExhibitType instanceof SparesRequirement)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P18));
    else if (itemExhibitType instanceof ShipClass)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P5S));
    else if (itemExhibitType instanceof ShipsOutfittingDeliveryExhibit)
      exhibit.setItemExhibit(ItemExhibit.byCode(getObjectContext(), P29P30));
    else
      log.error("Unimplemented ItemExhibit", new NotFoundException());

    addToExhibits(exhibit);

    return exhibit;
  }


  @Override
  public CompoSplit addCompoSplit(String serviceComponent)
  {
    if (serviceComponent == null)
      throw new NullPointerException();
    ServiceComponent sc = fetchOne(getObjectContext(),
      ServiceComponent.class, ServiceComponent.TITLE_PROPERTY,
      serviceComponent);
    if (sc == null)
      throw new RuntimeException(
        "ServiceComponent query returned no result");
    CompoSplit cs = getObjectContext().newObject(CompoSplit.class);
    cs.setServiceComponent(sc);
    cs.setServiceAgency(getParentLineItem().getServiceAgency());
    cs.setDisplayOrder(Util
      .getNextDisplayOrderValue(getComponentSplitList()));
    addToComponentSplitList(cs);
    return cs;
  }


  @Override
  public CompoSplit getCompoSplit(String serviceComponent)
  {
    for (CompoSplit cs : getComponentSplitList())
    {
      if (cs.getServiceComponent().getTitle().equals(serviceComponent))
        return cs;
    }
    return null;
  }


  @Override
  public void removeCompoSplit(CompoSplit cs)
  {
    removeFromComponentSplitList(cs);
    getObjectContext().deleteObjects(cs);
  }


  /** Create and add a P40a item group with one item in it */
  public Exhibit addP40aItemGroup()
  {
    ItemGroup ig = getObjectContext().newObject(ItemGroup.class);

    return addExhibit(ig);
  }


  /** Create and add a P40a item group with one item in it */
  public Exhibit addP18Item()
  {
    SparesRequirement sr = getObjectContext().newObject(
      SparesRequirement.class);

    return addExhibit(sr);
  }


  /** Create and add a P5 item with one item in it */
  public Exhibit addP5Item()
  {
    Item item = getObjectContext().newObject(Item.class);
    addResourceSummariesForP5(item.getResourceSummary());
    return addExhibit(item);
  }


  /** Create and add a P3a item group */
  public Exhibit addP3aItemGroup()
  {
    ModsItemGroup item = getObjectContext().newObject(ModsItemGroup.class);
    // item.setDescription(""); // Shut up stupid DB mandatory field error.
    addResourceSummariesForP3A(item.getResourceSummary());
    return addExhibit(item);
  }


  public void removeExhibit(Exhibit e)
  {
    removeFromExhibits(e);
    getObjectContext().deleteObjects(e);
  }


  @Override
  public ResourceSummaryRow addResourceSummaryRow(
    ResourceSummaryEntryType entryType)
  {
    ResourceSummaryRow rsr = ResourceSummaryRow.create(getObjectContext(),
      entryType);
    addToResourceSummaryRows(rsr);
    return rsr;
  }


  @Override
  public void removeResourceSummaryRow(ResourceSummaryRow rsr)
  {
    removeFromResourceSummaryRows(rsr);
    getObjectContext().deleteObjects(rsr);
  }


  /**
   * Add a snapshot of the xml with the validity status and date/user modified
   */
  public void addHistory(String xml)
  {
    LineItemHistory lih = getObjectContext().newObject(
      LineItemHistory.class);
    lih.setXml(xml);
    lih.setValidity(getErrorCount() != 0 ? ValidityType.E
      : getWarningCount() != 0 ? ValidityType.W : ValidityType.V);
    lih.setXmlValidity(getXmlValidity());
    lih.setDateModified(getDateModified());
    lih.setModifiedBy(getModifiedBy());
    addToHistory(lih);
  }


  @Override
  public Costs getCosts()
  {
    if (getResourceSummary() != null
      && getResourceSummary().getGrossWeaponSystemCost() != null)
      return getResourceSummary().getGrossWeaponSystemCost().getCosts();
    return null;
  }


  @Override
  public Costs getUnitCosts()
  {
    if (getResourceSummary() != null
      && getResourceSummary().getGrossWeaponSystemUnitCost() != null)
      return getResourceSummary().getGrossWeaponSystemUnitCost()
        .getCosts();
    return null;
  }


  public boolean isManufacturerPresent()
  {
    for (Exhibit e : getExhibits())
    {
      if (e.getItemExhibit() != null)
      {
        switch (e.getItemExhibit().getCode())
        {
          case P5:
            for (CostElement ce : e.getP5Item().getFlattenedCostElements())
              if (ce.getManufacturerList().isEmpty() == false)
                return true;
            break;
          case P40A:
            for (P40aCategory cat : e.getP40aItemGroup().getCategories())
              for (Item it : cat.getItems())
                if (it.getManufacturerList().isEmpty() == false)
                  return true;
            break;
        }
      }
    }

    return false;
  }


  public boolean isAdvanceProcurement()
  {
    // Look through all the exhibits for Advance Procurement.
    for (Exhibit exhibit : getExhibits())
    {
      // Check for a P-5 Advance Procurement
      if (exhibit.getP5Item() != null && exhibit.getP5Item().getAdvanceProcurement() != null)
        return true;

      // Check for a P-3A (buried under a ModsItemGroup/ModsItem) Advance
      // Procurement
      if (exhibit.getModsItemGroup() != null && exhibit.getModsItemGroup().getAdvanceProcurement() != null)
        return true;

      // Check for a P-5c Advance Procurement (for Ships)
      if (exhibit.getP5ShipClass() != null && exhibit.getP5ShipClass().getAdvanceProcurement() != null)
        return true;
    }

    // Didn't find any.
    return false;
  }


  public void clearAdvanceProcurementData()
  {
    if (isAdvanceProcurement() != true)
    {
      setAdvanceProcurementDescription(null);
      setAdvanceProcurementJustification(null);
      setAdvanceProcurementP1LineItemNumber(null);
    }
  }

  public boolean hasAPOnlyFlag()
  {
    Boolean isAPOnlyFlag = getAPOnlyFlag();
    return (isAPOnlyFlag !=null);
  }

  public boolean isAPP40Standalone()
  {
    Boolean isAPOnlyFlag = getAPOnlyFlag();
    return (isAPOnlyFlag !=null && isAPOnlyFlag.booleanValue());
  }

  public boolean isSuppressAdvanceProcurementP40()
  {
    return getSuppressAdvanceProcurementP40() != null && getSuppressAdvanceProcurementP40().booleanValue();
  }

  // FIXME: Delete this method.
  public boolean hasAdvanceProcurement()
  {
    return isAdvanceProcurement();
  }


  @Override
  public List<? extends CostContainer> getChildren()
  {
    List<CostContainer> children = new ArrayList<CostContainer>();
    for (Exhibit exhibit : getExhibits())
    {
      children.add(exhibit.getItemExhibitType());
    }
    return children;
  }


  public String getBudgetCycleAndYear()
  {
    return String.format("%s %s", getBudgetCycle(), getBudgetYear());
  }


  public String getIdentifyingString()
  {
    return "Line Item " + getId() + " - " + getLineItemNumber() + " "
      + getBudgetCycle() + getBudgetYear();
  }


  @Override
  public String getLockIdentifyingString()
  {
    return "P-40";
  }


  @Override
  public Costs getQuantities()
  {
    if (getResourceSummary() != null
      && getResourceSummary().getQuantity() != null)
      return getResourceSummary().getQuantity().getCosts();
    return null;
  }


  @Override
  public Costs getCompoSplitCosts()
  {
    if (getResourceSummary().getTotalProcCost() != null)
      return getResourceSummary().getTotalProcCost().getCosts();
    return null;
  }


  @Override
  public boolean isValid()
  {
    return getErrorCount() != null && getErrorCount() == 0
      && getWarningCount() != null && getWarningCount() == 0;
  }


  @Override
  public boolean isErrors()
  {
    return getErrorCount() != null && getErrorCount() > 0;
  }


  @Override
  public boolean isWarnings()
  {
    return getWarningCount() != null && getWarningCount() > 0;
  }


  private void incrementCayenneProp(String relName)
  {
    Short s = (Short) readProperty(relName);
    if (s == null)
      s = (short) 0;
    writeProperty(relName, ++s);
  }


  // Update P5a/P21 exhibit count
  // TODO the P10 might mess this up!!!
  private void updateExhibitCount(HasManufacturers hm)
  {
    if (!hm.getManufacturerList().isEmpty())
    {
      incrementCayenneProp(P5A_COUNT_PROPERTY);
      for (Manufacturer m : hm.getManufacturerList())
      {
        for (HistoryPlanning hp : m.getHistoryPlanningList())
        {
          if (!hp.getDeliveryScheduleList().isEmpty())
          {
            incrementCayenneProp(P21COUNT_PROPERTY);
          }
        }
      }
    }
  }


  // Recursively search P5 cost elements for P5as/P21s
  private void updateExhibitCount(List<CostElement> ces)
  {
    for (CostElement ce : ces)
    {
      updateExhibitCount(ce);
      updateExhibitCount(ce.getCostElementList());
    }
  }


  public void updateExhibitCount()
  {
    setP10Count((short) 0);
    setP17Count((short) 0);
    setP18Count((short) 0);
    setP20Count((short) 0);
    setP21Count((short) 0);
    setP23Count((short) 0);
    setP25Count((short) 0);
    setP26Count((short) 0);
    setP3aCount((short) 0);
    setP40aCount((short) 0);
    setP5Count((short) 0);
    setP5aCount((short) 0);
    for (Exhibit e : getExhibits())
    {
      if (e.getItemExhibit() != null)
      {
        switch (e.getItemExhibit().getCode())
        {
          case P3A:
            incrementCayenneProp(P3A_COUNT_PROPERTY);
            if (e.getModsItemGroup().getAdvanceProcurement() != null)
              incrementCayenneProp(P10COUNT_PROPERTY);
            break;
          case P5:
            incrementCayenneProp(P5COUNT_PROPERTY);
            updateExhibitCount(e.getP5Item().getCostElements());
            if (e.getP5Item().getP20RequirementsStudy() != null)
            {
              incrementCayenneProp(P20COUNT_PROPERTY);
            }
            if (e.getP5Item().getAdvanceProcurement() != null)
            {
              incrementCayenneProp(P10COUNT_PROPERTY);
            }
            break;
          case P17:
            incrementCayenneProp(P17COUNT_PROPERTY);
            break;
          case P18:
            incrementCayenneProp(P18COUNT_PROPERTY);
            break;
          case P25:
            incrementCayenneProp(P25COUNT_PROPERTY);
            break;
          case P26:
            incrementCayenneProp(P26COUNT_PROPERTY);
            break;
          case P40A:
            incrementCayenneProp(P40A_COUNT_PROPERTY);
            for (P40aCategory cat : e.getP40aItemGroup()
              .getCategories())
            {
              for (Item it : cat.getItems())
              {
                updateExhibitCount(it);
                if (it.getP20RequirementsStudy() != null)
                {
                  incrementCayenneProp(P20COUNT_PROPERTY);
                }
              }
            }
            break;
          default:
            log.debug("Seems like you found an exhibit that is not mapped in the Line Item. Exhibit ID:" + e.getId());
            break;
        }
      }
    }
  }


  @Override
  public boolean hasEditLock()
  {
    if (getLockedBy() != null)
      return true;
    for (Exhibit e : getExhibits())
    {
      if (e.getLockedBy() != null)
        return true;
    }
    return false;
  }


  @Override
  public boolean isFrozen()
  {
    return getAllLockedBy() != null;
  }


  public boolean lockAll(P40User user)
  {
    if (lock(user) == false)
      return false;

    for (Exhibit exhibit : getExhibits())
      if (exhibit.lock(user) == false)
        return false;

    return true;
  }


  public static Comparator<LineItem> getComparatorForOrderingByBa()
  {
    return new Comparator<LineItem>()
    {
      @Override
      public int compare(LineItem li1, LineItem li2)
      {
        int appropOrder = Util.compare(li1.getBudgetSubActivity()
          .getBudgetActivity().getAppropriation().getCode(), li2
          .getBudgetSubActivity().getBudgetActivity()
          .getAppropriation().getCode());
        if (appropOrder != 0)
        {
          return appropOrder;
        }
        int baOrder = Util
          .compare(li1.getBudgetSubActivity().getBudgetActivity()
            .getNumber(), li2.getBudgetSubActivity()
            .getBudgetActivity().getNumber());
        if (baOrder != 0)
        {
          return baOrder;
        }
        // ba's are same, order by p1 line item #
        int p1LineItemOrder = Util.compare(li1.getSortableP1LineItemNumber(),
          li2.getSortableP1LineItemNumber());
        if (p1LineItemOrder != 0)
        {
          return p1LineItemOrder;
        }
        // p1 line item #'s are same, order by pe # (should never get
        // same
        // p1 line item #'s except in test cases or unfinalized budgets)
        return Util.compare(li1.getLineItemNumber(),
          li2.getLineItemNumber());
      }
    };
  }

  public String getSortableP1LineItemNumber()
  {
    if (isAPP40Standalone()) {
      return getAdvanceProcurementP1LineItemNumber();
    }
    else {
      return getP1LineItemNumber();
    }
  }

  @Override
  public Long getLongId()
  {
    // TODO Auto-generated method stub
    return null;
  }


  /*
   * PDF Selection:
   *
   * 1. Include P40A Exhibit and generate full Item Schedule 2. Include P40A and
   * only Categories in Item Schedule" 3. Include P40A and only Summary/Total in
   * Item Schedule" 4. Include P40A information in Item Schedule without
   * generating P40A Exhibit"
   *
   * Note: Item Schedule is always generated in PDF.
   *
   * Translation: 1. Total redundancy: display P40A data in its entirety in Item
   * Schedule and P40A Exhibit (suppressP40As=false;
   * expandP40AInItemSchedule='true', p40AItemScheduleSetting='item') 2.
   * suppressP40As=false; expandP40AInItemSchedule ='true',
   * p40AItemScheduleSetting='category' 3. suppressP40As=false;
   * expandP40AInItemSchedule = 'true', p40AItemScheduleSetting='total' 4.
   * suppressP40As='true', expandP40AInItemSchedule = 'true';
   * p40AItemScheduleSetting= 'expandItemSuppressExhibit'
   *
   * It should match with what we define in migrate-xml-PB2013-to-BES2014.xml
   */
  public int pdfOptionForP40A()
  {
    int pdfOption = 0;
    String p40aItemScheduleFlag = (String) readProperty("p40aItemScheduleFlag");

    if ("item".equals(p40aItemScheduleFlag))
      pdfOption = 1;
    else if ("category".equals(p40aItemScheduleFlag))
      pdfOption = 2;
    else if ("total".equals(p40aItemScheduleFlag))
      pdfOption = 3;
    else if ("expandItemSuppressExhibit".equals(p40aItemScheduleFlag))
      pdfOption = 4;
    return pdfOption;
  }


  public void setAdvanceProcurementTotalPages(int advanceProcurementTotalPages)
  {
    this.advanceProcurementTotalPages = advanceProcurementTotalPages;
  }


  public int getAdvanceProcurementTotalPages()
  {
    return this.advanceProcurementTotalPages;
  }

  public List<P40User> getViewableByUsers()
  {
    List<P40User> users = new ArrayList<P40User>();
    List<UserLineItem> userLineItems = super.getUserLineItems();
    for (UserLineItem vuli : userLineItems)
    {
      if (vuli.isViewPrivilege())
      {
        users.add(vuli.getUser());
      }
    }
    return users;
  }

  public List<P40User> getEditableByUsers()
  {
    List<P40User> users = new ArrayList<P40User>();
    List<UserLineItem> userLineItems = super.getUserLineItems();
    for (UserLineItem vuli : userLineItems)
    {
      if (vuli.isEditPrivilege())
      {
        users.add(vuli.getUser());
      }
    }
    return users;
  }

  public List<P40User> getNotAccessibleByUsers()
  {
    List<P40User> users = new ArrayList<P40User>();
    List<UserLineItem> userLineItems = super.getUserLineItems();
    for (UserLineItem vuli : userLineItems)
    {
      if (!vuli.isEditPrivilege() && !vuli.isEditPrivilege())
      {
        users.add(vuli.getUser());
      }
    }
    return users;
  }
  
  public Map<String, P1DataValidationBean> getP1DataCache() {
    if(p1DataCache == null){
      if(isPrcpLoadedForYear()) {
        p1DataCache = CacheFactory.getP1DataCache(this);
      }
      else {
        p1DataCache = new HashMap<String, P1DataValidationBean>();
      }
    }
    
    return p1DataCache;
  }
  
  public boolean isPrcpLoadedForYear(){
    if(isPrcpLoadedForBudgetYear == null){
      isPrcpLoadedForBudgetYear = BudgesContext.getP1DataDAO().p1DataExistsForYear(getBudgetYear());
    }
    
    return isPrcpLoadedForBudgetYear;
  }
  
  public boolean isOutfittingDeliveryLineItem(){
    boolean isOutfittingDelivery = false;
    
    for(Exhibit exhibit : getExhibits()){
      ItemExhibitType itemExhibitType = exhibit.getItemExhibitType();
      
      if(itemExhibitType instanceof ShipsOutfittingDeliveryExhibit){
        isOutfittingDelivery = true;
        break;
      }
    }
    
    return isOutfittingDelivery;
  }
  
  /***********************************************************************/
  /*** Validation Support                                              ***/
  /***********************************************************************/

  /**
   * HashCode based on Business Rule [E-XML-PROC#U100]
   */
  @Override
  public int equivalenceHashCode()
  {
    HashCodeBuilder builder = new HashCodeBuilder();

    builder.append(toLowerAndTrim(getLineItemNumber()));
    builder.append(getBudgetSubActivity());
    builder.append(getBudgetYear());
    builder.append(toLowerAndTrim(getBudgetCycle()));

    return builder.toHashCode();
  }


  /**
   * Equality based on Business Rule [E-XML-PROC#U100]
   */
  @Override
  public boolean equivalentTo(LineItem other)
  {
    EqualsBuilder builder = new EqualsBuilder();

    builder.append(toLowerAndTrim(getLineItemNumber()), toLowerAndTrim(other.getLineItemNumber()));
    builder.append(toLowerAndTrim(this.getLineItemTitle()), toLowerAndTrim(other.getLineItemTitle()));
    builder.append(toLowerAndTrim(getBudgetSubActivity().getNumberPlusTitle()), toLowerAndTrim(other.getBudgetSubActivity().getNumberPlusTitle()));
    builder.append(getBudgetYear(), other.getBudgetYear());
    builder.append(toLowerAndTrim(getBudgetCycle()), toLowerAndTrim(other.getBudgetCycle()));
    builder.append(toLowerAndTrim(getServiceAgency().getCode()), toLowerAndTrim(other.getServiceAgency().getCode()));

    return builder.isEquals();
  }

  public Boolean isSuppressOutfittingDeliveryBY2ToBY5() {
    return suppressOutfittingDeliveryBY2ToBY5;
  }


  public void setSuppressOutfittingDeliveryBY2ToBY5(Boolean suppressOutfittingDeliveryBY2ToBY5) {
    this.suppressOutfittingDeliveryBY2ToBY5 = suppressOutfittingDeliveryBY2ToBY5;
  }
}
