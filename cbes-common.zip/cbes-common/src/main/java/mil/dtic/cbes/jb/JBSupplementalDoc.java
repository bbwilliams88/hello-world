/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBSupplementalDoc extends JBDefaultUserSuppliedPart
{
  public JBSupplementalDoc()
  {
    setFileSetting(FileSetting.SUPPLEMENTAL_DOC);    
    setTitle(fileSetting.getTitle());    
  }

}
