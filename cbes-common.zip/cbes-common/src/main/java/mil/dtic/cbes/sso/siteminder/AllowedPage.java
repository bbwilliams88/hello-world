package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;

/**
 * Represents an allowed page
 * Used when a user is not fully logged in.
 * T4 and T5 pages would check whether they are in
 * the list of allowed pages, and redirect to the first
 * one in the list if they're not.
 */
public class AllowedPage implements Serializable
{
  private static final long serialVersionUID = 5667181391022436868L;

  private final String url;
  private final String classname;

  public AllowedPage(String url, String classname)
  {
    this.url = url;
    this.classname = classname;
  }

  public String getUrl()
  {
    return url;
  }

  public String getClassname()
  {
    return classname;
  }
}
