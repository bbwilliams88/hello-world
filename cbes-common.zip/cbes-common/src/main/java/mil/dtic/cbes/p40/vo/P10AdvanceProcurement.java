package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.P10CostElementCategoryType;
import mil.dtic.cbes.p40.vo.auto._P10AdvanceProcurement;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.utility.Util;

public class P10AdvanceProcurement extends _P10AdvanceProcurement implements Equivalence<P10AdvanceProcurement>, RollupParent
{
    private static final long serialVersionUID = 1L;
    private static final String DEFAULT_CUSTOM_COST_ELEMENT_CATEGORY_NAME = "NULL";

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setupP10();
    }

    @Override
    protected void onPrePersist()
    {
        setupP10();
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    @Override
    public List<? extends CostContainer> getChildren()
    {
        List<P10CostElement> costElements = new ArrayList<P10CostElement>();

        costElements.addAll(getCFECostElements());
        costElements.addAll(getGFECostElements());
        costElements.addAll(getEOQCostElements());
        costElements.addAll(getOtherCostElements());

        return costElements;
    }

    //TODO I really hate that this is called getCosts
    @Override
    public Costs getCosts()
    {
        if (getItem() != null && getItem().getResourceSummary() != null && getItem().getResourceSummary().getPlusCYAdvProc() != null)
            return getItem().getResourceSummary().getPlusCYAdvProc().getCosts();
        //Because of the ModsGroup/ModsItem, this Rollup will not work for P3a
        return null;
    }

    @Override
    public Costs getUnitCosts()
    {
        return null;
    }

    @Override
    public Costs getQuantities()
    {
        return null;
    }

    //This may be able to replace the use of getCosts and will work for both the P-5 and P-3a P-10s.
    public Costs getParentPlusCYCosts()
    {
    	if (getItem() != null && getItem().getResourceSummary() != null && getItem().getResourceSummary().getPlusCYAdvProc() != null)
            return getItem().getResourceSummary().getPlusCYAdvProc().getCosts();
    	else if(getModsItemGroup() != null && getModsItemGroup().getResourceSummary() != null && getModsItemGroup().getResourceSummary().getPlusCYAdvProc() != null)
    		return getModsItemGroup().getResourceSummary().getPlusCYAdvProc().getCosts();
    	return null;
    }

    public List<P10CostElement> getCFECostElements()
    {
        return getOrderedCostElementsByCategory(P10CostElementCategoryType.CFE);
    }

    public List<P10CostElement> getGFECostElements()
    {
        return getOrderedCostElementsByCategory(P10CostElementCategoryType.GFE);
    }

    public List<P10CostElement> getEOQCostElements()
    {
        return getOrderedCostElementsByCategory(P10CostElementCategoryType.EOQ);
    }

    public List<P10CostElement> getOtherCostElements()
    {
        return getOrderedCostElementsByCategory(P10CostElementCategoryType.Other);
    }

    public Collection<P10AdvanceProcurementCustomCostElementCategory> getCustomCostElementCategories()
    {
        HashMap<String, P10AdvanceProcurementCustomCostElementCategory> mapOfCategories = new HashMap<String, P10AdvanceProcurementCustomCostElementCategory>();
        String key;
        Integer nextDisplayOrder = 0;
        for (P10CostElement costElement : getOrderedCostElementsByCategory(P10CostElementCategoryType.Custom))
        {
          key = costElement.getCustomCategoryTitle();
          if (StringUtils.isEmpty(key))
            key = DEFAULT_CUSTOM_COST_ELEMENT_CATEGORY_NAME;
          if (mapOfCategories.get(key) == null)
            mapOfCategories.put(key, new P10AdvanceProcurementCustomCostElementCategory(costElement.getCustomCategoryTitle(), nextDisplayOrder++, this));
          mapOfCategories.get(key).add(costElement);
        }

        return mapOfCategories.values();
    }

    private List<P10CostElement> getOrderedCostElementsByCategory(P10CostElementCategoryType type)
    {
        List<P10CostElement> costElementList = new ArrayList<P10CostElement>();

        for (P10CostElement costElement : getCostElements())
            if (costElement.getCategory() == type)
                costElementList.add(costElement);

        return getSortedByDisplayOrder(costElementList);
    }

    public Item getItem()
    {
        if (getItems() != null && !getItems().isEmpty())
            return getItems().get(0);

        return null;
    }

    public ModsItemGroup getModsItemGroup()
    {
        if (getModsItemGroups() != null && !getModsItemGroups().isEmpty())
            return getModsItemGroups().get(0);

        return null;
    }

    public P10AdvanceProcurementCustomCategorySubtotal getCategorySubtotalByTitle(String title)
    {
        for (P10AdvanceProcurementCustomCategorySubtotal subtotal : getCustomCategorySubtotals())
        {
          if (StringUtils.equals(subtotal.getTitle(), title))
            return subtotal;
        }
        return null;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public void clearOutYears()
    {
        for (P10CostElement costElement : getCostElements())
        {
            Costs.clearOutYears(costElement.getTerminationLiabilityCosts());
            Costs.clearOutYears(costElement.getTotalCosts());
        }

        Costs.clearOutYears(getAdvanceProcurementTotal());
        Costs.clearOutYears(getCFECategorySubtotalCosts());
        Costs.clearOutYears(getEOQCategorySubtotalCosts());
        Costs.clearOutYears(getGFECategorySubtotalCosts());
        Costs.clearOutYears(getOtherCategorySubtotalCosts());
        Costs.clearOutYears(getParentPlusCYCosts());
    }

    public P10CostElement addBlankCostElement(P10CostElementCategoryType category)
    {
        P10CostElement costElement = getObjectContext().newObject(P10CostElement.class);

        costElement.setCategory(category);
        addToCostElements(costElement);

        return costElement;
    }

    public P10CostElement addCostElementForCategoryType(P10CostElementCategoryType type)
    {
        P10CostElement ce = P10CostElement.createWithCategory(getObjectContext(), type);
        // Add a termination liability to the child.
        P10CostElement terminationLiabilityCostElement = getObjectContext().newObject(P10CostElement.class);
        terminationLiabilityCostElement.setDisplayOrder(1);

        addToCostElements(ce);
        return ce;
    }

    public void setupP10()
    {
        if (getCFECategorySubtotalCosts() == null)
            setCFECategorySubtotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

        if (getGFECategorySubtotalCosts() == null)
            setGFECategorySubtotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

        if (getEOQCategorySubtotalCosts() == null)
            setEOQCategorySubtotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

        if (getOtherCategorySubtotalCosts() == null)
            setOtherCategorySubtotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
    }

    public void cleanUpCFECategorySubtotalCosts()
    {
        if (getCFECategorySubtotalCosts() != null && getCFECostElements().isEmpty())
        {
            getCFECategorySubtotalCosts().clearValues();
        }
    }

    public void cleanUpGFECategorySubtotalCosts()
    {
        if (getGFECategorySubtotalCosts() != null && getGFECostElements().isEmpty())
        {
            getGFECategorySubtotalCosts().clearValues();
        }
    }

    public void cleanUpEOQCategorySubtotalCosts()
    {
        if (getEOQCategorySubtotalCosts() != null && getEOQCostElements().isEmpty())
        {
            getEOQCategorySubtotalCosts().clearValues();
        }
    }

    public void cleanUpOtherCategorySubtotalCosts()
    {
        if (getOtherCategorySubtotalCosts() != null && getOtherCostElements().isEmpty())
        {
            getOtherCategorySubtotalCosts().clearValues();
        }
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        //Handling the Cost Elements
        for (P10CostElement ce : this.getCostElements())
            ce.shiftForwardInTime(years);

        //Handling the totals for each Category
        if(getCFECategorySubtotalCosts() != null)
          getCFECategorySubtotalCosts().shiftForwardInTime(years, false);
        if(getGFECategorySubtotalCosts() != null)
          getGFECategorySubtotalCosts().shiftForwardInTime(years, false);
        if(getEOQCategorySubtotalCosts() != null)
          getEOQCategorySubtotalCosts().shiftForwardInTime(years, false);
        if(getOtherCategorySubtotalCosts() != null)
          getOtherCategorySubtotalCosts().shiftForwardInTime(years, false);
        if (getAdvanceProcurementTotal() != null)
          getAdvanceProcurementTotal().shiftForwardInTime(years, false);
        for (P10AdvanceProcurementCustomCategorySubtotal categorySubtotal : getCustomCategorySubtotals())
          if (categorySubtotal.getSubtotal() != null)
            categorySubtotal.getSubtotal().shiftForwardInTime(years, false);

    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(getCFECostElements());
        Util.generateDisplayOrder(getGFECostElements());
        Util.generateDisplayOrder(getEOQCostElements());
        Util.generateDisplayOrder(getOtherCostElements());
    }

    public boolean jibx_hasCFE()
    {
        return CollectionUtils.isNotEmpty(getCFECostElements());
    }

    public Iterator<P10CostElement> jibx_CFEIterator()
    {
        return getIterator(getCFECostElements());
    }

    public boolean jibx_hasGFE()
    {
        return CollectionUtils.isNotEmpty(getGFECostElements());
    }

    public Iterator<P10CostElement> jibx_GFEIterator()
    {
        return getIterator(getGFECostElements());
    }

    public boolean jibx_hasEOQ()
    {
        return CollectionUtils.isNotEmpty(getEOQCostElements());
    }

    public Iterator<P10CostElement> jibx_EOQIterator()
    {
        return getIterator(getEOQCostElements());
    }

    public boolean jibx_hasOther()
    {
        return CollectionUtils.isNotEmpty(getOtherCostElements());
    }

    public Iterator<P10CostElement> jibx_OtherIterator()
    {
        return getIterator(getOtherCostElements());
    }

    public boolean jibx_hasCFECategorySubtotalCosts()
    {
        if (getCFECategorySubtotalCosts() != null)
            return !getCFECategorySubtotalCosts().isEmpty();
        return false;
    }

    public boolean jibx_hasGFECategorySubtotalCosts()
    {
        if (getGFECategorySubtotalCosts() != null)
            return !getGFECategorySubtotalCosts().isEmpty();
        return false;
    }

    public boolean jibx_hasEOQCategorySubtotalCosts()
    {
        if (getEOQCategorySubtotalCosts() != null)
            return !getEOQCategorySubtotalCosts().isEmpty();
        return false;
    }

    public boolean jibx_hasOtherCategorySubtotalCosts()
    {
        if (getOtherCategorySubtotalCosts() != null)
            return !getOtherCategorySubtotalCosts().isEmpty();
        return false;
    }

    public boolean jibx_hasFirstSystemAwardDate()
    {
        return (getFirstSystemAwardDate() != null);
    }

    public boolean jibx_hasFirstSystemCompletionDate()
    {
        return (getFirstSystemCompletionDate() != null);
    }

    public boolean jibx_hasIntervalBetweenSystems()
    {
        return (getIntervalBetweenSystems() != null);
    }

    public boolean jibx_hasProductionLeadtime()
    {
        return (getProductionLeadtime() != null);
    }

    public boolean jibx_hasCustomCategories()
    {
        return CollectionUtils.isNotEmpty(getOrderedCostElementsByCategory(P10CostElementCategoryType.Custom));
    }

    public void jibx_addToCustomCategories(P10AdvanceProcurementCustomCostElementCategory customCategory)
    {
        if (CollectionUtils.isNotEmpty(customCategory))
          for (P10CostElement costElement : customCategory)
            addToCostElements(costElement);
        if (customCategory.jibx_hasCategorySubtotalCosts())
          addToCustomCategorySubtotals(customCategory.getCustomCategorySubtotal());
    }

    public Iterator<P10AdvanceProcurementCustomCostElementCategory> jibx_customCategoriesIterator()
    {
        return Util.getSortedByDisplayOrder(getCustomCostElementCategories()).iterator();
    }

    /**
     * The AdvanceProcurementTotal here is only used for SCN P-10 Exhibits. Regular P-10s (not part of Navy's SCN appropriation) will be pulling
     * their P-10 totals from the Plus CY row of the parent P-5 or P-3a Resource Summary. This is just to accommodate a request from Dave Burriss (Navy)
     */
    public boolean jibx_hasAdvanceProcurementTotal()
    {
        if (getAdvanceProcurementTotal() != null)
          return !getAdvanceProcurementTotal().isEmpty();
        return false;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * HashCode based on Business Rule [E-XML-PROC#U100]
     */
    @Override
    public int equivalenceHashCode()
    {
        if (this.getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(getItem());
        builder.append(getModsItemGroup());
        builder.append(getParentLineItem());

        return builder.toHashCode();
    }

    /**
     * Equality based on Business Rule [E-XML-PROC#U100]
     */
    @Override
    public boolean equivalentTo(P10AdvanceProcurement obj)
    {
        if (this == obj)
            return true;

        if (obj == null)
            return false;


        if (getClass() != obj.getClass())
            return false;


        P10AdvanceProcurement other = obj;

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(getItem(), other.getItem());
        builder.append(getModsItemGroup(), other.getModsItemGroup());
        builder.append(getParentLineItem(), other.getParentLineItem());

        return builder.isEquals();
    }
}