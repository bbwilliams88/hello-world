package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

public interface HasManufacturersWithDeliveries extends HasManufacturers
{
  public BigDecimal getPriorYearsDeliveries();
  public void setPriorYearsDeliveries(BigDecimal priorYearsDeliveries);
}
