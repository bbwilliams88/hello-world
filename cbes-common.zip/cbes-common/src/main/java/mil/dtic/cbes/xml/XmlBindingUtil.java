/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.utility.CbesLogFactory;

public class XmlBindingUtil
{
  private static final Logger log = CbesLogFactory.getLog(XmlBindingUtil.class);


  public static SimpleDateFormat getMonthYearFormatter()
  {
    return new SimpleDateFormat(Constants.XML_MONTH_DATE_FORMAT);
  }
  
  public static Date convertMonthYearToDate(String dateStr)
  {
    Date date = null;
    if (dateStr != null)
    {
      try
      {
        date = getMonthYearFormatter().parse(dateStr);
      }
      catch (ParseException e)
      {
        log.error("Could not convert date string into Java date " + dateStr, e);
      }
    }
    return date;
  }


  public static String convertDateToMonthYearString(Date date)
  {
//    String dateStr = "9999-12"; // TODO should really be null, but jibx does not like a null to be returned here
    String dateStr = null;
    if (date != null)
      dateStr = getMonthYearFormatter().format(date);
    return dateStr;
  }
}
