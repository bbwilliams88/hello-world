/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.util.Date;
import java.util.List;

import mil.dtic.utility.KeyValuePair;

public class PdfAssemblyOptions
{

  protected Integer budgetYear;
  protected String budgetCycle;
  private Date submissionDate;
  private String serviceAgencyName;
  private boolean forceEvenPages;
  private String docTitle;
  private boolean includeR2a = true;
  private List<KeyValuePair> r2PageNumberKvpList;
  private List<KeyValuePair> tocKvpList;
  private List<KeyValuePair> r4KvpList;
  private String docToGenerate;
  private String watermark;
  private String logoSource;
  private boolean generateR1;
  private boolean generateR1Summary;
  private boolean generateR1c;
  private boolean generateR1d;
  private boolean pdfPerPe;


  public Integer getBudgetYear()
  {
    return budgetYear;
  }


  public void setBudgetYear(Integer budgetYear)
  {
    this.budgetYear = budgetYear;
  }


  public String getBudgetCycle()
  {
    return budgetCycle;
  }


  public void setBudgetCycle(String budgetCycle)
  {
    this.budgetCycle = budgetCycle;
  }


  public Date getSubmissionDate()
  {
    return submissionDate;
  }


  public void setSubmissionDate(Date submissionDate)
  {
    this.submissionDate = submissionDate;
  }


  public String getServiceAgencyName()
  {
    return serviceAgencyName;
  }


  public void setServiceAgencyName(String serviceAgencyName)
  {
    this.serviceAgencyName = serviceAgencyName;
  }


  public boolean isForceEvenPages()
  {
    return forceEvenPages;
  }


  public void setForceEvenPages(boolean forceEvenPages)
  {
    this.forceEvenPages = forceEvenPages;
  }


  public String getDocTitle()
  {
    return docTitle;
  }


  public void setDocTitle(String docTitle)
  {
    this.docTitle = docTitle;
  }


  public boolean isIncludeR2a()
  {
    return includeR2a;
  }


  public void setIncludeR2a(boolean includeR2a)
  {
    this.includeR2a = includeR2a;
  }


  public List<KeyValuePair> getR2PageNumberKvpList()
  {
    return r2PageNumberKvpList;
  }


  public void setR2PageNumberKvpList(List<KeyValuePair> pageNumberKvpList)
  {
    r2PageNumberKvpList = pageNumberKvpList;
  }


  public List<KeyValuePair> getTocKvpList()
  {
    return tocKvpList;
  }


  public void setTocKvpList(List<KeyValuePair> tocKvpList)
  {
    this.tocKvpList = tocKvpList;
  }


  public List<KeyValuePair> getR4KvpList()
  {
    return r4KvpList;
  }


  public void setR4KvpList(List<KeyValuePair> kvpList)
  {
    r4KvpList = kvpList;
  }


  public String getDocToGenerate()
  {
    return docToGenerate;
  }


  public void setDocToGenerate(String docToGenerate)
  {
    this.docToGenerate = docToGenerate;
  }


  public String getWatermark()
  {
    return watermark;
  }


  public void setWatermark(String watermark)
  {
    this.watermark = watermark;
  }


  public String getLogoSource()
  {
    return logoSource;
  }


  public void setLogoSource(String logoSource)
  {
    this.logoSource = logoSource;
  }


  public boolean isGenerateR1()
  {
    return generateR1;
  }


  public void setGenerateR1(boolean generateR1)
  {
    this.generateR1 = generateR1;
  }


  public boolean isGenerateR1Summary()
  {
    return generateR1Summary;
  }


  public void setGenerateR1Summary(boolean generateR1Summary)
  {
    this.generateR1Summary = generateR1Summary;
  }


  public boolean isGenerateR1c()
  {
    return generateR1c;
  }


  public void setGenerateR1c(boolean generateR1c)
  {
    this.generateR1c = generateR1c;
  }


  public boolean isGenerateR1d()
  {
    return generateR1d;
  }


  public void setGenerateR1d(boolean generateR1d)
  {
    this.generateR1d = generateR1d;
  }


  public boolean isPdfPerPe()
  {
    return pdfPerPe;
  }


  public void setPdfPerPe(boolean pdfPerPe)
  {
    this.pdfPerPe = pdfPerPe;
  }


}
