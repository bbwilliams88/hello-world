package mil.dtic.cbes.p40.vo;

import java.util.Collections;
import java.util.List;

/**
 *
 */
public abstract class DisplayOrderBase extends Base implements Comparable<DisplayOrderBase>
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public abstract Integer getDisplayOrder();
    public abstract void setDisplayOrder(Integer displayOrder);

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(DisplayOrderBase other)
    {
        Integer d1 = getDisplayOrder();
        Integer d2 = other.getDisplayOrder();

        if (d1 == null)
            return -1;
        else if (d2 == null)
            return 1;
        else
            return d1.compareTo(d2);
    }
    

    /**
     * @param list
     * @param after
     */
    public void moveInList(List<DisplayOrderBase> list, DisplayOrderBase after)
    {
        if (!list.contains(this))
            throw new IllegalArgumentException("The list must contain this DisplayOrderBase object");

        if (after != null && !list.contains(after))
            throw new IllegalArgumentException("The list must contain the 'after' DisplayOrderBase object");

        Collections.sort(list);
        list.remove(this);

        int newIndex = 0;

        if (after != null)
            newIndex = list.indexOf(after);

        list.add(newIndex, this);

        int i = 1;

        for (DisplayOrderBase currentDOB : list)
            currentDOB.setDisplayOrder(i++);
    }
}
