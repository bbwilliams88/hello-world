package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._InactiveIndustrialFacilityProjectFunding;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class InactiveIndustrialFacilityProjectFunding extends _InactiveIndustrialFacilityProjectFunding implements HasDisplayOrder
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
    setDisplayOrder(0);
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
 }

  
  @Override
  protected void onPrePersist()
  {
  }
}
