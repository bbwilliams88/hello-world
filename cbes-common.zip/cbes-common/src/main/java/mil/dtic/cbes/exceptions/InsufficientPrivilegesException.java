package mil.dtic.cbes.exceptions;

public class InsufficientPrivilegesException extends Exception
{
    private static final long serialVersionUID = 1L;

    public InsufficientPrivilegesException() { super(); }
    public InsufficientPrivilegesException(String message) { super(message); }
    public InsufficientPrivilegesException(String message, Throwable cause) { super(message, cause); }
    public InsufficientPrivilegesException(Throwable cause) { super(cause); }
}
