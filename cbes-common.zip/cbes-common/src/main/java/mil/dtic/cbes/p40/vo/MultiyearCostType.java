
package mil.dtic.cbes.p40.vo;

/** 
 * MYP Object generated with JiBX
 * This class is not to be committed to the DB
 */
public class MultiyearCostType
{
    private DollarAmountType allPriorYears;
    private DollarAmountType priorYear;
    private DollarAmountType currentYear;
    private DollarAmountType budgetYearOne;
    private DollarAmountType budgetYearTwo;
    private DollarAmountType budgetYearThree;
    private DollarAmountType budgetYearFour;
    private DollarAmountType budgetYearFive;
    private DollarAmountType total;

    /**
     * @return the allPriorYears
     */
    public DollarAmountType getAllPriorYears()
    {
      return allPriorYears;
    }

    /**
     * @param allPriorYears the allPriorYears to set
     */
    public void setAllPriorYears(DollarAmountType allPriorYears)
    {
      this.allPriorYears = allPriorYears;
    }

    /**
     * @return the priorYear
     */
    public DollarAmountType getPriorYear()
    {
      return priorYear;
    }

    /**
     * @param priorYear the priorYear to set
     */
    public void setPriorYear(DollarAmountType priorYear)
    {
      this.priorYear = priorYear;
    }

    /**
     * @return the currentYear
     */
    public DollarAmountType getCurrentYear()
    {
      return currentYear;
    }

    /**
     * @param currentYear the currentYear to set
     */
    public void setCurrentYear(DollarAmountType currentYear)
    {
      this.currentYear = currentYear;
    }

    /**
     * @return the budgetYearOne
     */
    public DollarAmountType getBudgetYearOne()
    {
      return budgetYearOne;
    }

    /**
     * @param budgetYearOne the budgetYearOne to set
     */
    public void setBudgetYearOne(DollarAmountType budgetYearOne)
    {
      this.budgetYearOne = budgetYearOne;
    }

    /**
     * @return the budgetYearTwo
     */
    public DollarAmountType getBudgetYearTwo()
    {
      return budgetYearTwo;
    }

    /**
     * @param budgetYearTwo the budgetYearTwo to set
     */
    public void setBudgetYearTwo(DollarAmountType budgetYearTwo)
    {
      this.budgetYearTwo = budgetYearTwo;
    }

    /**
     * @return the budgetYearThree
     */
    public DollarAmountType getBudgetYearThree()
    {
      return budgetYearThree;
    }

    /**
     * @param budgetYearThree the budgetYearThree to set
     */
    public void setBudgetYearThree(DollarAmountType budgetYearThree)
    {
      this.budgetYearThree = budgetYearThree;
    }

    /**
     * @return the budgetYearFour
     */
    public DollarAmountType getBudgetYearFour()
    {
      return budgetYearFour;
    }

    /**
     * @param budgetYearFour the budgetYearFour to set
     */
    public void setBudgetYearFour(DollarAmountType budgetYearFour)
    {
      this.budgetYearFour = budgetYearFour;
    }

    /**
     * @return the budgetYearFive
     */
    public DollarAmountType getBudgetYearFive()
    {
      return budgetYearFive;
    }

    /**
     * @param budgetYearFive the budgetYearFive to set
     */
    public void setBudgetYearFive(DollarAmountType budgetYearFive)
    {
      this.budgetYearFive = budgetYearFive;
    }

    /**
     * @return the total
     */
    public DollarAmountType getTotal()
    {
      return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(DollarAmountType total)
    {
      this.total = total;
    }
}
