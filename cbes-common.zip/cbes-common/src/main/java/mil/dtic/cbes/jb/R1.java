/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;


public class R1 extends JBDefaultSystemGeneratedPart
{
  public R1()
  {
    this(null);
  }
  
  public R1(String titlePrefix)
  {
    setFileSetting(FileSetting.R1);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.R1.getTitle()));    
  }
}
