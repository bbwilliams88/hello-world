package mil.dtic.cbes.xml;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class XMLToolsUtil {

  private static Logger log = LogManager.getLogger(XMLToolsUtil.class);
  
  private static XPath xPath = XPathFactory.newInstance().newXPath();
  
  public static boolean isMJB(Document doc) {
    return hasElement(Constants.MJB_ROOT_LOCAL_NAME, doc);
  }
  
  public static boolean isJB(Document doc) {
    if (hasElement(Constants.JB_ROOT_LOCAL_NAME, doc) && !hasElement(Constants.MJB_ROOT_LOCAL_NAME, doc)){
      return true;
    }
    return false;
  }
  
  public static boolean isR2ExhibitDoc(Document doc) {
    if ( (hasElement(Constants.R2_ROOT_LOCAL_NAME, doc) || hasElement(Constants.R2_ROOT_LOCAL_NAME_LEGACY, doc)) &&
        !(hasElement(Constants.MJB_ROOT_LOCAL_NAME, doc) || hasElement(Constants.JB_ROOT_LOCAL_NAME,doc))){
      return true;
    }
    else {
      return false;
    }
  }
  
  public static boolean isR2(Document doc) {
    return hasElement("ProgramElement", doc);
  }
  
  public static boolean isP40ExhibitDoc(Document doc) {
    if (hasElement(Constants.P40_ROOT_LOCAL_NAME, doc) && !(hasElement(Constants.MJB_ROOT_LOCAL_NAME, doc) || hasElement(Constants.JB_ROOT_LOCAL_NAME, doc))){
      return true;
    }
    return false;
  }
  
  public static String getBudgetCycle(Document doc) {
    String cycle = getNodeText("//*/BudgetCycle",doc);
    if (StringUtils.isNotEmpty(cycle))
    {
      return cycle;
    }
    return null;
  }
  
  public static String getBudgetYear(Document doc) {
    String year = getNodeText("//*/BudgetYear",doc);
    if (StringUtils.isNotEmpty(year))
    {
      return year;
    }
    return null;
  }
  
  public static String getServiceAgencyName(Document doc) {
    String serviceAgencyName = getNodeText("//*/ServiceAgencyName",doc);
    if (StringUtils.isNotEmpty(serviceAgencyName))
    {
      return serviceAgencyName;
    }
    return null;
  }
 
  
  private static String getNodeText(String xPathStr, Document doc) {
    NodeList nodes;
    try {
      XPathExpression expr = xPath.compile(xPathStr);
      nodes = (NodeList)expr.evaluate(doc,XPathConstants.NODESET);
      String textVal = null;
      if (nodes!=null && nodes.getLength() > 0) {
        try {
          textVal = nodes.item(0).getTextContent();
          return textVal;
        } catch (DOMException e) {
          log.error("Couldn't read node value for: "+xPathStr+" "+e.getMessage());
          return null;
        }
      }
    } catch (XPathExpressionException e) {
      log.warn("Problem generating xpath expression",e);
      return null;
    }
    return null;
  }
  
  private static boolean hasElement(String elementName, Document doc) {
    try {
      NodeList node = (NodeList)xPath.evaluate("//*[local-name()='"+elementName+"']", doc, XPathConstants.NODESET);
      if (node==null || node.getLength()<=0){
        NodeList node2 = (NodeList)xPath.evaluate("//*/*[local-name()='"+elementName+"']", doc, XPathConstants.NODESET);
        if (node2==null || node2.getLength()<=0){
          return false;
        }
        else {
          return true;
        }
      }
      return true;
    } catch (XPathExpressionException ex){
      log.error("problem getting doc type "+ex.getMessage());
      return false;
    }
    
  }
  
  public static String getSchemaPath( String budgetCycle, String budgetYear) {
    if (StringUtils.isNotBlank(budgetYear) && StringUtils.isNotBlank(budgetCycle))
    {
      StringBuilder jbSchemaPath = new StringBuilder();
      jbSchemaPath.append("xml/");
      jbSchemaPath.append(budgetCycle.toLowerCase());
      jbSchemaPath.append("_");
      jbSchemaPath.append(budgetYear);
      log.debug("Schema: "+jbSchemaPath.toString());
      return jbSchemaPath.toString();
    }
    else
    {
      log.error("No budget cycle or year found in xml.");
      return null;
    }
    
  }
  
  public static String getSchemaName(Document doc) {
    if (isMJB(doc)){
      return "dticmjb.xsd";
    }
    else if (isJB(doc)){
      return "dticjb.xsd";
    }
    else if (isR2ExhibitDoc(doc)){
      return "dticr2.xsd"; 
    }
    else if (isP40ExhibitDoc(doc)) {
      return "procurement.xsd";
    }
    else {
      return "";
    }
    
  }
  
  public static List<Map<String, String>> getLineItemInfoList(LineItemList p40List) {
    
    List<Map<String, String>> items = new LinkedList<Map<String, String>>();
    if (p40List!=null) {
      List<LineItem>lis =  p40List.getLineItemsUnWrapped();
      log.debug("################ Number of LI: "+lis.size());
      for (LineItem li :lis){
        Map<String, String> map = new HashMap<String, String>();
        map.put("number", li.getLineItemNumber());
        map.put("title", li.getLineItemTitle());
        map.put("budgetCycleAndYear", li.getBudgetCycleAndYear());
        map.put("serviceAgency", li.getServiceAgency().getName());
        items.add(map);
      }
    }
    log.debug("There are "+items.size()+" line items.");
    return items;
  }

  

  
  public static List<Map<String, String>> getProgramElementInfoList(R2ExhibitList r2List) {
    List<Map<String, String>> items = new LinkedList<Map<String, String>>();
    if (r2List!=null) {
      List<ProgramElement>pes =  r2List.getProgramElements();
      log.debug("################ Number of PEs: "+r2List.getProgramElements().size());
      for (ProgramElement pe :pes){
        Map<String, String> map = new HashMap<String, String>();
        map.put("number", pe.getNumber());
        map.put("title", pe.getTitle());
        map.put("budgetCycleAndYear", pe.getBudgetCycleAndYear());
        map.put("serviceAgency", pe.getServiceAgency().getName());
        items.add(map);
      }
    }
    log.debug("There are "+items.size()+" program elements");
    return items;
  }
  
  public static String getMigrationStyleSheet(String cycle, String year, String newCycle, String newYear) {
    StringBuilder xsltName = new StringBuilder();
    xsltName.append("migrate-xml-");
    xsltName.append(cycle);
    xsltName.append(year);
    xsltName.append("-to-");
    xsltName.append(newCycle);
    xsltName.append(newYear);
    xsltName.append(".xslt");
    log.debug("Migration Stylesheet:"+xsltName.toString());
    return xsltName.toString();
  }
  
  public static List<String> getSchemaPathList(String schemaPath) {
    List<String>xsdPathList = new LinkedList<String>();
    xsdPathList.add(schemaPath+"/xsd/");
    xsdPathList.add(schemaPath+"/xsd/r2/");
    xsdPathList.add(schemaPath+"/xsd/p40/");
    return xsdPathList;
  }
  
  public static List<String> getXslPathList(String schemaPath, boolean isR2Doc) {
    List<String> xslPathList = new LinkedList<String>();
    if (isR2Doc){
      log.debug("Getting stylesheet for R1: /xsl/r2/");
      xslPathList.add(schemaPath+"/xsl/r2/");
    }
    else {
      log.debug("Getting stylesheet for P1: /xsl/p40/");
      xslPathList.add(schemaPath+"/xsl/p40/");
    }
  return xslPathList;
  }
}
