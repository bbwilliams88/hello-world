/*
 * $Id$
 */
package mil.dtic.cbes.constants;


public enum FileSetting
{
  MASTER_JB("Master Justification Book", null, null, "masterjb", PdfDocProperties.MASTER_JB),   
  JB("Justification Book", null, null, "jb", PdfDocProperties.JB), 
  BLANK("Blank Page", "jbBlank.xsl", null, "blank", PdfDocProperties.JB), 
  COVER("Cover", "jbCover.xsl", null, "cover", null), 
  INTRODUCTON_DOC("Introduction and Explanation of Contents", null, null, "introduction", null),
  TOC("Table of Contents", "jbToc.xsl", null, "toc", null), 
  MASTER_TOC("Table of Contents", "mjbToc.xsl", null, "mtoc", null),   
  GENERIC_TOC("Generic Table of Contents", "mjbToc.xsl", null, "generic_toc", null),   
  SUMMARY_DOC("Summary Document", null, null, "summary", null), 
  USER_R1("Comptroller Exhibit R-1", null, null, "userR1", null), 
  PE_TOC_BY_BA("Program Element Table of Contents (by Budget Activity then Line Item Number)", "jbPeToc.xsl", null, "peTocByBa", null), 
  PE_TOC_BY_TITLE("Program Element Table of Contents (Alphabetically by Program Element Title)", "jbPeToc.xsl", null, "peTocByTitle", null), 
  R1SUMMARY("Exhibit R-1 Summary", "r1.xsl", "r1summary-excel.xsl", "r1Summary", PdfDocProperties.R1SUMMARY), 
  R1("Exhibit R-1", "r1.xsl", "r1-excel.xsl", "r1", PdfDocProperties.R1), 
  R1C("Exhibit R-1C", "r1.xsl", "r1c-excel.xsl", "r1c", PdfDocProperties.R1C), 
  R1D("Exhibit R-1D", "r1.xsl", "r1d-excel.xsl", "r1d", PdfDocProperties.R1D), 
  SUPPLEMENTAL_DOC_COLLECTION("Supplemental Documents", null, null, null, null), 
  SUPPLEMENTAL_DOC("Supplemental Document", null, null, "supplemental", null), 
  ACRONYM_DOC("Acronyms", null, null, "acronym", null), 
  R2COLLECTION("Exhibit R-2s", "r2.xsl", null, "r2ExhibitList", null), // TODO rename to R2ExhibitList 
  R2("Exhibit R-2", "r2.xsl", null, "r2", PdfDocProperties.R2), 
  R2A("Exhibit R-2A", "r2a.xsl", null, "r2a", PdfDocProperties.R2A),
  R3("Exhibit R-3", "r3.xsl", null, "r3", PdfDocProperties.R3),
  R4("Exhibit R-4", "r4.xsl", null, "r4", PdfDocProperties.R4),
  R4A("Exhibit R-4a", "r4a.xsl", null, "r4a", PdfDocProperties.R4A),
  R5("Exhibit R-5", "r5.xsl", null, "r5", PdfDocProperties.R5),
  P40("Exhibit P-40", "p40.xsl", null, "p40", null),
  P40COLLECTION("Exhibit P-40s", "p40.xsl", null, "lineItemList", null),
  LI_TOC_BY_BA("Line Item Table of Contents (by Appropriation then Line Number)", "jbLiToc.xsl", null, "liTocByBa", null), 
  LI_TOC_BY_TITLE("Line Item Table of Contents (Alphabetically by Line Item Title)", "jbLiToc.xsl", null, "liTocByTitle", null), 
  USER_P1("Comptroller Exhibit P-1", null, null, "userP1", null),
  P1("Exhibit P-1, Procurement Program", "p1.xsl", "p1-excel.xsl", "p1", PdfDocProperties.P1),
  P1M("Exhibit P-1M, Procurement Programs - Modification Summary", "p1m.xsl", "p1m-excel.xsl", "p1m", PdfDocProperties.P1M),  
  P1D("Exhibit P-1D", "p1.xsl", "p1-excel.xsl", "p1d", PdfDocProperties.P1D),
  SD_REPORT("Secondary Distribution Report", "p1.xsl", "p1-secondary-distribution-excel.xsl", "p1", PdfDocProperties.SD_REPORT),
  P21_WALLCHART("Delivery Schedule Wall Chart","p1.xsl","p21-wallchart-excel.xsl","p21",PdfDocProperties.P21_WALLCHART),
  R3_OVERVIEW("R3 overview",null,"r3-overview-excel.xsl","r3overview",null),
  MYP("MultiYear Procurement", "myp1.xsl", null, "myp", null),
  COST_OF_REPORT_DOC("Cost of Report", null, null, "cost", null);
  
  private final String title;
  private final String pdfXslFileName;
  private final String excelXslFileName;
  private final String htmlXslFileName;
  private final String fileNamePrefix;
  private final PdfDocProperties pdfDocProperties;


  private FileSetting(String title, String pdfXslFileName, String excelXslFileName, String fileNamePrefix, PdfDocProperties pdfDocProperties)
  {
    this.title = title;
    this.pdfXslFileName = pdfXslFileName;
    this.fileNamePrefix = fileNamePrefix;
    this.excelXslFileName = excelXslFileName;
    this.pdfDocProperties = pdfDocProperties;
    this.htmlXslFileName = "fo2html.xsl";
  }

  public String getTitle()
  {
    return title;
  }


  public String getPdfXslFileName()
  {
    return pdfXslFileName;
  }


  public String getFileNamePrefix()
  {
    return fileNamePrefix;
  }

  public PdfDocProperties getPdfDocProperties()
  {
    return pdfDocProperties;
  }


  public String getExcelXslFileName()
  {
    return excelXslFileName;
  }

  public String getHtmlXslFileName()
  {
    return htmlXslFileName;
  }
}