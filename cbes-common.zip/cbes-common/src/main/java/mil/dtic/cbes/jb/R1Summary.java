/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;

public class R1Summary extends JBDefaultSystemGeneratedPart
{
  public R1Summary()
  {
    this(null);
  }
  
  public R1Summary(String titlePrefix)
  {
    setFileSetting(FileSetting.R1SUMMARY);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.R1SUMMARY.getTitle()));    
  }
  
}
