package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;

public interface HasManufacturers extends IBase
{
  public String getName();
  public String getLongName();
  public List<Manufacturer> getManufacturerList();
  public Manufacturer addManufacturer();
  public void removeManufacturer(Manufacturer m);
  public List<HistoryPlanning> getAllHistoryPlanningsSorted();
  public ObjectContext getObjectContext();
  public boolean isTransient();
}
