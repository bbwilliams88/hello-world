package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class MultiYearProcurementFundingPlanType
{
  private MultiyearProcurementResourceSummary annualCosts;
  private MultiyearProcurementResourceSummary multiyearCosts;
  private List<MultiyearAdvanceProcurementType> multiyearAdvanceProcurementTypeList = new ArrayList<MultiyearAdvanceProcurementType>();
  private MultiyearCostType multiyearSavings;
  private BigDecimal multiyearSavingsPercent;
  private String multiyearSavingsPercentFootnote;
  private MultiyearCostType cancellationCeilingFunded;
  private MultiyearCostType cancellationCeilingUnfunded;
  private HugeMultiyearCostType annualOutlay;
  private HugeMultiyearCostType multiyearOutlay;
  private HugeMultiyearCostType savingsOutlay;


  /**
   * Get the 'AnnualOutlay' element value.
   * 
   * @return value
   */
  public HugeMultiyearCostType getAnnualOutlay()
  {
    return annualOutlay;
  }


  /**
   * Set the 'AnnualOutlay' element value.
   * 
   * @param annualOutlay
   */
  public void setAnnualOutlay(HugeMultiyearCostType annualOutlay)
  {
    this.annualOutlay = annualOutlay;
  }


  /**
   * Get the 'MultiyearOutlay' element value.
   * 
   * @return value
   */
  public HugeMultiyearCostType getMultiyearOutlay()
  {
    return multiyearOutlay;
  }


  /**
   * Set the 'MultiyearOutlay' element value.
   * 
   * @param multiyearOutlay
   */
  public void setMultiyearOutlay(HugeMultiyearCostType multiyearOutlay)
  {
    this.multiyearOutlay = multiyearOutlay;
  }


  /**
   * Get the 'SavingsOutlay' element value.
   * 
   * @return value
   */
  public HugeMultiyearCostType getSavingsOutlay()
  {
    return savingsOutlay;
  }


  /**
   * Set the 'SavingsOutlay' element value.
   * 
   * @param savingsOutlay
   */
  public void setSavingsOutlay(HugeMultiyearCostType savingsOutlay)
  {
    this.savingsOutlay = savingsOutlay;
  }


  /**
   * Get the 'MultiyearSavings' element value.
   * 
   * @return value
   */
  public MultiyearCostType getMultiyearSavings()
  {
    return multiyearSavings;
  }


  /**
   * Set the 'MultiyearSavings' element value.
   * 
   * @param multiyearSavings
   */
  public void setMultiyearSavings(MultiyearCostType multiyearSavings)
  {
    this.multiyearSavings = multiyearSavings;
  }


  /**
   * Get the 'CancellationCeilingFunded' element value.
   * 
   * @return value
   */
  public MultiyearCostType getCancellationCeilingFunded()
  {
    return cancellationCeilingFunded;
  }


  /**
   * Set the 'CancellationCeilingFunded' element value.
   * 
   * @param cancellationCeilingFunded
   */
  public void setCancellationCeilingFunded(MultiyearCostType cancellationCeilingFunded)
  {
    this.cancellationCeilingFunded = cancellationCeilingFunded;
  }


  /**
   * Get the 'CancellationCeilingUnfunded' element value.
   * 
   * @return value
   */
  public MultiyearCostType getCancellationCeilingUnfunded()
  {
    return cancellationCeilingUnfunded;
  }


  /**
   * Set the 'CancellationCeilingUnfunded' element value.
   * 
   * @param cancellationCeilingUnfunded
   */
  public void setCancellationCeilingUnfunded(MultiyearCostType cancellationCeilingUnfunded)
  {
    this.cancellationCeilingUnfunded = cancellationCeilingUnfunded;
  }


  /**
   * Get the 'ResourceSummary' element value.
   * 
   * @return value
   */
  public MultiyearProcurementResourceSummary getMultiyearCosts()
  {
    return multiyearCosts;
  }


  /**
   * Set the 'ResourceSummary' element value.
   * 
   * @param multiyearCosts
   */
  public void setMultiyearCosts(MultiyearProcurementResourceSummary multiyearCosts)
  {
    this.multiyearCosts = multiyearCosts;
  }


  /**
   * Get the 'AdvanceProcurementList' element value.
   * 
   * @return value
   */
  public Iterator<MultiyearAdvanceProcurementType> jibx_AdvanceProcurementListIterator()
  {
    return multiyearAdvanceProcurementTypeList.iterator();
  }


  /**
   * Set the 'AdvanceProcurementList' element value.
   * 
   * @param advanceProcurementList
   */
  public void addToAdvanceProcurementList(MultiyearAdvanceProcurementType multiyearAdvanceProcurementType)
  {
    this.multiyearAdvanceProcurementTypeList.add(multiyearAdvanceProcurementType);
  }
  
  
  public boolean jibx_hasAdvancedProcurement()
  {
    return CollectionUtils.isNotEmpty(multiyearAdvanceProcurementTypeList);
  }


  /**
   * Get the 'AnnualCosts' element value.
   * 
   * @return value
   */
  public MultiyearProcurementResourceSummary getAnnualCosts()
  {
    return annualCosts;
  }


  /**
   * Set the 'AnnualCosts' element value.
   * 
   * @param annualCosts
   */
  public void setAnnualCosts(MultiyearProcurementResourceSummary annualCosts)
  {
    this.annualCosts = annualCosts;
  }


  public boolean jibx_hasMultiyearSavingsPercent()
  {
    return multiyearSavingsPercent != null;
  }
  
  
  /**
   * @return the multiyearSavingsPercent
   */
  public BigDecimal getMultiyearSavingsPercent()
  {
    return multiyearSavingsPercent;
  }


  /**
   * @param multiyearSavingsPercent the multiyearSavingsPercent to set
   */
  public void setMultiyearSavingsPercent(BigDecimal multiyearSavingsPercent)
  {
    this.multiyearSavingsPercent = multiyearSavingsPercent;
  }


  /**
   * @return the multiyearSavingsPercentFootnote
   */
  public String getMultiyearSavingsPercentFootnote()
  {
    return multiyearSavingsPercentFootnote;
  }


  /**
   * @param multiyearSavingsPercentFootnote the multiyearSavingsPercentFootnote to set
   */
  public void setMultiyearSavingsPercentFootnote(String multiyearSavingsPercentFootnote)
  {
    this.multiyearSavingsPercentFootnote = multiyearSavingsPercentFootnote;
  }
}
