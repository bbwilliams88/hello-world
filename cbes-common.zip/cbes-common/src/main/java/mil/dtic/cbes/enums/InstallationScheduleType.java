package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum InstallationScheduleType implements ExtendedEnumeration
{
  IN("I"), OUT("O");


  private final String dbName;

  private InstallationScheduleType(String dbName)
  {
    this.dbName = dbName;
  }

  public String getDatabaseValue()
  {
    return dbName;
  }
}
