package mil.dtic.cbes.enums;

import static java.math.BigDecimal.ROUND_HALF_UP;
import static java.math.BigDecimal.ROUND_UP;
import static java.math.BigDecimal.ZERO;

import java.math.BigDecimal;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

public enum MonetaryUnitType implements ExtendedEnumeration
{
  Dollars("1"), Thousands("1000"), Millions("1000000");

  private static final Logger log = CbesLogFactory.getLog(MonetaryUnitType.class);
  private final String dbName;


  private MonetaryUnitType(String dbName)
  {
    this.dbName = dbName;
  }


  public String getXmlName()
  {
    return toString();
  }


  public String getDatabaseValue()
  {
    return dbName;
  }


  public BigDecimal getDollars(BigDecimal bd)
  {
    if (bd == null)
      return null;
    switch (this)
    {
      case Dollars:
        return bd;
      case Thousands:
        return bd.movePointRight(3);
      case Millions:
        return bd.movePointRight(6);
      default:
        log.error("This is not supposed to happen", new RuntimeException());
        return ZERO;
    }
  }


  public BigDecimal getDollarsInUnitsRounded(BigDecimal bd)
  {
    if (bd != null)
    {
      switch (this)
      {
        case Dollars:
          return bd.setScale(0, ROUND_UP);
        case Thousands:
          return bd.movePointLeft(3);
        case Millions:
          return bd.movePointLeft(6).setScale(3, ROUND_HALF_UP);
        default:
          log.error("This is not supposed to happen", new RuntimeException());
          return ZERO;
      }
    }
    return null;
  }


  public BigDecimal getMillionsWithError(BigDecimal bd)
  {
    if (bd != null)
    {
      switch (this)
      {
        case Dollars:
          return bd.movePointLeft(6);
        case Thousands:
          return bd.movePointLeft(3);
        case Millions:
          return bd;
        default:
          RuntimeException e = new RuntimeException("This should never happen, if it does then a new enum value has been added to MonetaryUnitType without updating this method");
          log.error("This is not supposed to happen", e);
          throw e;
      }
    }
    return null;
  }

}
