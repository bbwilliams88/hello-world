package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

public interface ModsOutYearDifference
{
  

  /***********************************************************************/
  /*** Custom Accessors                                                ***/
  /***********************************************************************/
  
  public void setBy2(BigDecimal by2);  
  public BigDecimal getBy2();

  public void setBy3(BigDecimal by3);
  public BigDecimal getBy3();

  public void setBy4(BigDecimal by4);
  public BigDecimal getBy4();

  public void setBy5(BigDecimal by5);
  public BigDecimal getBy5();

  public void setContinuing(boolean continuing);
  public boolean isContinuing();
  
  public void setToComplete(BigDecimal toComplete);
  public BigDecimal getToComplete();
  
  public void setTotal(BigDecimal total);
  public BigDecimal getTotal();


  /***********************************************************************/
  /*** Business Logic                                                  ***/
  /***********************************************************************/

  // Put non-accessor methods here.

  /***********************************************************************/
  /*** Utilities                                                       ***/
  /***********************************************************************/

  // Put utility-type methods here, which are typically static, such as
  // fetch* type methods, which fetch Cayenne objects from the database.

  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  // Put JiBX support methods here.

  /***********************************************************************/
  /*** Validation Support                                              ***/
  /***********************************************************************/

  // Put equivalenceHashCode and equivalentTo methods here, if the class
  // implements Equivalence.

}
