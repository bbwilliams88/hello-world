package mil.dtic.cbes.p40.vo;

import java.util.List;
import java.util.NoSuchElementException;

import org.apache.cayenne.ObjectContext;

import com.google.common.collect.Iterables;

import mil.dtic.cbes.p40.vo.auto._Permission;
import mil.dtic.cbes.p40.vo.util.EqualsPredicate;



public class Permission extends _Permission {
  private static final long serialVersionUID = 1L;

  public static List<Permission> fetchAll(ObjectContext context)
  {
    return fetchAllForClass(context, Permission.class);
  }
  
  public static Permission fetchByName(ObjectContext context, String name)
  {
    return fetchOne(context, Permission.class, NAME_PROPERTY, name);
  }
  
  public boolean hasRole(Role r)
  {
    return hasRole(r.getName());
  }
  
  public boolean hasRole(String roleName)
  {
    try 
    {
      if (Iterables.find(getRoles(), new EqualsPredicate<Role>(roleName, Role.NAME_PROPERTY))!=null)
      {
        return true;
      }
      return false;
    } 
    catch (NoSuchElementException e)
    {
      return false;
    }
  }
}
