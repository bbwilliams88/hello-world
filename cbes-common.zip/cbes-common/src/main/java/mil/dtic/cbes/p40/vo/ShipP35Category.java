package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ShipP35Category;

/**
 *
 */
public class ShipP35Category extends _ShipP35Category implements ShipP8aItemCostParent
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasCosts()
    {
      return jibx_hasTotalCost() || jibx_hasQuantity();
    }
    
    public boolean jibx_hasTotalCost()
    {
      return getTotalCost() != null;
    }
    
    public boolean jibx_hasQuantity()
    {
      return getQuantity() != null;
    }
    
    public void jibx_setQuantity(ExtendedPYSCosts quantity)
    {
      if (quantity != null)
      {
        quantity.setType(CostRowType.QUANTITY);
        super.setQuantity(quantity);
      }
    }
    
    public void jibx_setTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setTotalCost(totalCost);
      }
    }

    @Override
    public boolean jibx_hasTitle()
    {
      return StringUtils.isNotEmpty(getTitle());
    }

    
    //May re-write this later since these fields below are only to support the Major Item and Other Cost Elements hanging off the P-8a. 
    //They just need to be included here because the interface they use (to simplify the JiBX binding) is the same.
    @Override
    public Boolean getIsSignificant()
    {
      return new Boolean(false);
    }

    @Override
    public void setIsSignificant(Boolean isSignificant)
    {
      
    }

    @Override
    public boolean jibx_hasIsSignificant()
    {
      return false;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
