package mil.dtic.cbes.service;

import java.io.File;

import java.util.Date;
import org.apache.commons.io.FilenameUtils;

import mil.dtic.cbes.submissions.ValueObjects.SYSFile;

public class SYSUploadServiceImpl extends BudgetFileUploadServiceImpl<SYSFile>
{
	
	private SYSFile sysFile;
	
	@Override
    protected String generateFileName(String fileName, String userName)
    {
        String extension = FilenameUtils.getExtension(fileName).toLowerCase();
        StringBuffer newFileName = new StringBuffer();
        newFileName.append("SYS-");
        newFileName.append(userName);
        newFileName.append("-");
        Date date = new Date();
        long time = date.getTime();
        newFileName.append(time);
        newFileName.append(extension);
        return newFileName.toString();
    }

    @Override
	protected void storeFile(File file, String fileName, String userName, String description, Date date) {
		sysFile = new SYSFile();
		sysFile.setFileURI(file.toURI());
		sysFile.setName(fileName);
		sysFile.setCreatedBy(userName);
		sysFile.setDescription(description);
		if(null != date) {
			sysFile.setDateCreated(date);
		} else {
			sysFile.setDateCreated(new Date());
		}
		uploadedFileDAO.save(sysFile);
	}
}
