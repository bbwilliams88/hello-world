package mil.dtic.cbes.p40.vo;

public class MYPLineItemDetails
{

  private Short budgetActivityNumber;
  private Short budgetSubActivityNumber;
  private String lineItemNumber;


  /**
   * @return the budgetActivityNumber
   */
  public Short getBudgetActivityNumber()
  {
    return budgetActivityNumber;
  }


  /**
   * @param budgetActivityNumber
   *          the budgetActivityNumber to set
   */
  public void setBudgetActivityNumber(Short budgetActivityNumber)
  {
    this.budgetActivityNumber = budgetActivityNumber;
  }


  /**
   * @return the budgetSubActivityNumber
   */
  public Short getBudgetSubActivityNumber()
  {
    return budgetSubActivityNumber;
  }


  /**
   * @param budgetSubActivityNumber
   *          the budgetSubActivityNumber to set
   */
  public void setBudgetSubActivityNumber(Short budgetSubActivityNumber)
  {
    this.budgetSubActivityNumber = budgetSubActivityNumber;
  }


  /**
   * @return the lineItemNumber
   */
  public String getLineItemNumber()
  {
    return lineItemNumber;
  }


  /**
   * @param lineItemNumber
   *          the lineItemNumber to set
   */
  public void setLineItemNumber(String lineItemNumber)
  {
    this.lineItemNumber = lineItemNumber;
  }
}
