package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ShipP35CategoryType;
import mil.dtic.cbes.p40.vo.auto._ShipCategoryItem;
import mil.dtic.utility.CbesLogFactory;

/**
 *
 */
public class ShipCategoryItem extends _ShipCategoryItem implements ShipP8aItemCostParent, HasManufacturers
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(ShipCategoryItem.class);

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.
    private ShipP35Category getShipP35CategoryByType(ShipP35CategoryType type)
    {
      for (ShipP35Category category : getShipP35Categories())
        if (category.getCategory().equals(type))
          return category;
      return null;
    }
    
    private void setShipP35CategoryByType(ShipP35Category category, ShipP35CategoryType type)
    {
      if (getShipP35CategoryByType(type) != null)
        log.debug("You already have one Ship Cost Category for " + type.getDescription() + ". You cannot have more than one of each category.");
        //throw new IllegalArgumentException("You already have one Ship Cost Category for " + type.getDescription() + ". You cannot have more than one of each category.");
      
      if (category != null)
      {
        category.setCategory(type);
        addToShipP35Categories(category);
      }
    }
    
    public List<ShipP35Category> getUserDefinedShipCostCategories()
    {
      List<ShipP35Category> userDefinedCategories = new ArrayList<ShipP35Category>();
      for (ShipP35Category category : getShipP35Categories())
        if (category.getCategory().equals(ShipP35CategoryType.USER_DEFINED))
          userDefinedCategories.add(category);
      return userDefinedCategories;
    }
    
    public void addToUserDefinedShipP35Categories(ShipP35Category category)
    {
      if (category != null)
      {
        category.setCategory(ShipP35CategoryType.USER_DEFINED);
        addToShipP35Categories(category);
      }
    }
    
    public ShipP35Category getMajorHardwareCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.MAJOR_HARDWARE);
    }
    
    public ShipP35Category getAncillaryEquipmentCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.ANCILLARY_EQUIPMENT);
    }
    
    public ShipP35Category getTechnicalDataAndDocumentationCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.TECHNICAL_DATA_AND_DOCUMENTATION);
    }
    
    public ShipP35Category getSparesCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.SPARES);
    }
    
    public ShipP35Category getSystemEngineeringCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.SYSTEM_ENGINEERING);
    }
    
    public ShipP35Category getTechnicalEngineeringServicesCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.TECHNICAL_ENGINEERING_SERVICES);
    }
    
    public ShipP35Category getAssemblyAndIntegrationCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.ASSEMBLY_AND_INTEGRATION);
    }
    
    public ShipP35Category getOtherCostsCategory()
    {
      return getShipP35CategoryByType(ShipP35CategoryType.OTHER_COSTS);
    }
    
    public void setMajorHardwareCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.MAJOR_HARDWARE);
    }
    
    public void setAncillaryEquipmentCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.ANCILLARY_EQUIPMENT);
    }
    
    public void setTechnicalDataAndDocumentationCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.TECHNICAL_DATA_AND_DOCUMENTATION);
    }
    
    public void setSparesCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.SPARES);
    }
    
    public void setSystemEngineeringCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.SYSTEM_ENGINEERING);
    }
    
    public void setTechnicalEngineeringServicesCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.TECHNICAL_ENGINEERING_SERVICES);
    }
    
    public void setAssemblyAndIntegrationCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.ASSEMBLY_AND_INTEGRATION);
    }
    
    public void setOtherCostsCategory(ShipP35Category category)
    {
      setShipP35CategoryByType(category, ShipP35CategoryType.OTHER_COSTS);
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    
    public boolean jibx_hasTitle()
    {
      return StringUtils.isNotEmpty(getTitle());
    }
    
    public boolean jibx_hasPARMCode()
    {
      return StringUtils.isNotEmpty(getPARMCode());
    }
    
    public boolean jibx_hasCosts()
    {
      return jibx_hasTotalCost() || jibx_hasQuantity();
    }
    
    public boolean jibx_hasTotalCost()
    {
      return getTotalCost() != null;
    }
    
    public boolean jibx_hasQuantity()
    {
      return getQuantity() != null;
    }
    
    public boolean jibx_hasP35Total()
    {
      return jibx_hasP35TotalCost() || jibx_hasP35TotalQuantity();
    }
    
    public boolean jibx_hasP35TotalCost()
    {
      return getP35TotalCost() != null;
    }
    
    public boolean jibx_hasP35TotalQuantity()
    {
      return getP35TotalQuantity() != null;
    }
    
    public void jibx_setQuantity(ExtendedPYSCosts quantity)
    {
      if (quantity != null)
      {
        quantity.setType(CostRowType.QUANTITY);
        super.setQuantity(quantity);
      }
    }
    
    public void jibx_setTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setTotalCost(totalCost);
      }
    }
    
    public void jibx_setP35TotalQuantity(ExtendedPYSCosts quantity)
    {
      if (quantity != null)
      {
        quantity.setType(CostRowType.QUANTITY);
        super.setP35TotalQuantity(quantity);
      }
    }
    
    public void jibx_setP35TotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setP35TotalCost(totalCost);
      }
    }
    
    public boolean jibx_hasIsSignificant()
    {
      return getIsSignificant() != null;
    }
    
    public boolean jibx_hasShipP35Categories()
    {
      return CollectionUtils.isNotEmpty(getShipP35Categories());
    }
    
    public boolean jibx_hasMajorHardwareCategory()
    {
      return getMajorHardwareCategory() != null;
    }
    
    public boolean jibx_hasAncillaryEquipmentCategory()
    {
      return getAncillaryEquipmentCategory() != null;
    }
    
    public boolean jibx_hasTechnicalDataAndDocumentationCategory()
    {
      return getTechnicalDataAndDocumentationCategory() != null; 
    }
    
    public boolean jibx_hasSparesCategory()
    {
      return getSparesCategory() != null;
    }
    
    public boolean jibx_hasSystemEngineeringCategory()
    {
      return getSystemEngineeringCategory() != null;
    }
    
    public boolean jibx_hasTechnicalEngineeringServicesCategory()
    {
      return getTechnicalEngineeringServicesCategory() != null; 
    }
    
    public boolean jibx_hasAssemblyAndIntegrationCategory()
    {
      return getAssemblyAndIntegrationCategory() != null;
    }
    
    public boolean jibx_hasOtherCostsCategory()
    {
      return getOtherCostsCategory() != null;
    }
    
    public boolean jibx_hasUserDefinedShipP35Categories()
    {
      return CollectionUtils.isNotEmpty(getUserDefinedShipCostCategories());
    }
    
    public Iterator<ShipP35Category> jibx_userDefinedShipP35Categories()
    {
      return getUserDefinedShipCostCategories().iterator();
    }
    
    public boolean jibx_hasManufacturers()
    {
      return CollectionUtils.isNotEmpty(getManufacturerList());
    }
    
    public Iterator<Manufacturer> jibx_manufacturerIterator()
    {
      return getManufacturerList().iterator();
    }
    
    @Override
    public List<Manufacturer> getManufacturerList()
    {
        return getSortedByDisplayOrder(super.getManufacturerList());
    }

    @Override
    public String getName()
    {
      return getTitle();
    }

    @Override
    public String getLongName()
    {
      return getShipCostCategory() != null ? (getShipCostCategory().getCategory().getDescription() + ": " + getTitle()) : getTitle();
    }

    @Override
    public Manufacturer addManufacturer()
    {
      Manufacturer m = getObjectContext().newObject(Manufacturer.class);
      addToManufacturerList(m);
      return m;
    }

    @Override
    public void removeManufacturer(Manufacturer m)
    {
      removeFromManufacturerList(m);
      getObjectContext().deleteObjects(m);
    }

    @Override
    public List<HistoryPlanning> getAllHistoryPlanningsSorted()
    {
      // Method needed to satisfy the Interface requirements, but this is only needed for H&P entries that are tied to traditional Items and Cost Elements
      return null;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
