package mil.dtic.cbes.p40.vo;


/**
 *
 */
public abstract class LookupBase extends Base
{

}
