/*
 * $Id$
 */
package mil.dtic.cbes.fop;

import java.io.IOException;
import java.io.InputStream;

import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.configuration.DefaultConfigurationBuilder;
import org.apache.logging.log4j.Logger;
import org.xml.sax.SAXException;

import mil.dtic.utility.CbesLogFactory;

public class FopConfiguration
{
  private static final Logger log = CbesLogFactory.getLog(FopConfiguration.class);

  private String fopConfigFilePath;
  private Configuration config;

  public FopConfiguration(String fopConfigFilePath)
  {
    this.fopConfigFilePath = fopConfigFilePath;
    ClassLoader cl = FopFactoryWrapper.class.getClassLoader();
      if(cl!= null){
    	try (InputStream is = cl.getResourceAsStream(fopConfigFilePath)) {
		  DefaultConfigurationBuilder cfgBuilder = new DefaultConfigurationBuilder();
		  if (is != null)
			config = cfgBuilder.build(is);
		} catch (ConfigurationException | SAXException | IOException e) {
			log.error("Could not create FOP Configuration for budges", e);
		}
      }
  }

  public Configuration getConfig()
  {
    return config;
  }

  public String getFopConfigFilePath()
  {
    return fopConfigFilePath;
  }
}
