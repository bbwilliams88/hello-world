package mil.dtic.cbes.sso.siteminder;


public class P40Privileges
{
  //ldap, probably not going to be used
  public static final String BASIC_LDAP = "ROLE_R2User";
  public static final String ADMIN_LDAP = "ROLE_R2AppMgr";

  /**
   * this reflects the user's status flag, ACTIVE/DELETED/NEW,
   * only ACTIVE gets this role
   */
  public static final String BASIC = "ROLE_P40_BASIC";

  //The rest of these are entries in the permission db table
  //use a ROLE_P40 prefix for all of them in case some other DTIC app uses spring security
  public static final String FOO = "ROLE_bar";

  /** pretend user is a member of all agencies */
  public static final String ALL_AGENCIES = "ROLE_P40_ALL_AGENCIES";
  /** low level admin stuff */
  public static final String ADMIN_TOOLS = "ROLE_P40_ADMIN_TOOLS";
  /** log in as any user */
  public static final String ADMIN_SWITCH_USER = "ROLE_P40_SWITCH_USER";
  
  // No longer used.  It is now combination of edit access on line item and
  // if user has CREATE_LINE_ITEM permission
//  public static final String ENABLE_COPY = "ROLE_P40_MANAGE_COPY";
  
  public static final String ENABLE_DELETE = "ROLE_P40_MANAGE_DELETE";
  
  // No longer used.  Check the user's line item access to
  // check if user has view only access
//  public static final String DISABLE_WRITE = "ROLE_P40_BLOCK_WRITE";
  public static final String ACCESS_IN_MAINTENANCE_MODE = "ROLE_P40_MAINT_MODE";
  public static final String SHOW_TEST_P40S = "ROLE_P40_TEST";
  public static final String SHOW_DEFAULT_LOGO_CHECKBOX = "ROLE_P40_JBLOGOCHNG";
  /** always show unlock, and allow overriding of others locks */
  public static final String UNLOCK_ANY = "ROLE_P40_UNLOCK_ANY";
  /** Prevent others from editing an entire P-40 on a long term basis */
  public static final String FREEZE = "ROLE_P40_FREEZE";
  /** Normally only the freezer can unfreeze - this permission lets you override other users freezes */
  public static final String UNFREEZE_ANY = "ROLE_P40_UNFREEZE_ANY";
  
  /** Defaults user access to edit on line items if access has not been specifically defined for line item **/
  public static final String EDIT_LINE_ITEM = "ROLE_P40_EDIT_LINE_ITEM";
  
  /** Defaults user access to edit on line items if access has not been specifically defined for line item **/
  public static final String VIEW_LINE_ITEM = "ROLE_P40_VIEW_LINE_ITEM";
  
  /** This is on a per user-basis **/
  public static final String CREATE_LINE_ITEM = "ROLE_P40_CREATE_LINE_ITEM";
}
