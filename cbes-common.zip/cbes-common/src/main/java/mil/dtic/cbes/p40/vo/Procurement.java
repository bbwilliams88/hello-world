package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._Procurement;

public class Procurement extends _Procurement {

    private static Procurement instance;

    private Procurement() {}

    public static Procurement getInstance() {
        if(instance == null) {
            instance = new Procurement();
        }

        return instance;
    }
}
