/*
 * $Id$
 */
package mil.dtic.cbes.output;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.activation.DataSource;

import org.apache.commons.lang3.ArrayUtils;

import mil.dtic.cbes.constants.BudgesContentType;

public class DefaultBudgesDownloadableObject implements BudgesDownloadableObject, DataSource
{
  private static final long serialVersionUID = 6575222759489948022L;

  File dataFilePath;
  byte[] dataByteArray;
  String userVisibleLabel;
  BudgesContentType budgesContentType;


  public DefaultBudgesDownloadableObject(File dataFilePath, String userVisibleLabel, BudgesContentType budgesContentType)
  {
    this.dataFilePath = dataFilePath;
    this.userVisibleLabel = userVisibleLabel;
    this.budgesContentType = budgesContentType;
  }

  public DefaultBudgesDownloadableObject(File dataFilePath, String userVisibleLabel)
  {
    this.dataFilePath = dataFilePath;
    this.userVisibleLabel = userVisibleLabel;
    this.budgesContentType = BudgesContentType.getContentType(dataFilePath.getAbsolutePath());
  }

  public DefaultBudgesDownloadableObject(byte[] dataByteArray, String userVisibleLabel, BudgesContentType budgesContentType)
  {
    this.dataByteArray = ArrayUtils.clone(dataByteArray);
    this.userVisibleLabel = userVisibleLabel;
    this.budgesContentType = budgesContentType;
  }

  public long getTotalSizeInBytes() throws IOException
  {
    if (dataFilePath != null)
      return dataFilePath.length();
    return dataByteArray.length;
  }


  public File getDataFilePath()
  {
    return dataFilePath;
  }


  public byte[] getDataByteArray()
  {
    return dataByteArray;
  }


  public BudgesContentType getBudgesContentType()
  {
    return budgesContentType;
  }


  // DataSource methods

  public InputStream getInputStream() throws IOException
  {
    if (dataFilePath != null)
      return new BufferedInputStream(new FileInputStream(dataFilePath));

    return new ByteArrayInputStream(dataByteArray);
  }


  public String getUserVisibleLabel()
  {
    return userVisibleLabel;
  }


  public String getContentType()
  {
    return getBudgesContentType().getMimeType();
  }


  public String getName()
  {
    return getUserVisibleLabel();
  }


  public OutputStream getOutputStream() throws IOException
  {
    throw new IOException("getOutputStream() is not supported by " + this.getClass().getName());
  }
}
