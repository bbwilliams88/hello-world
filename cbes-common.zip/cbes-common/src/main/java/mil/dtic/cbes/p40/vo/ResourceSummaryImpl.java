package mil.dtic.cbes.p40.vo;




public class ResourceSummaryImpl
{
  private ResourceSummaryRow grossCost;
  private ResourceSummaryRow lessPyAdvProc;
  private ResourceSummaryRow plusPyAdvProc;
  private ResourceSummaryRow netProcP1;
  private ResourceSummaryRow initialSpares;
  private ResourceSummaryRow totalProcCost;
  
  public ResourceSummaryRow getGrossCost()
  {
    return grossCost;
  }
  public void setGrossCost(ResourceSummaryRow grossCost)
  {
    this.grossCost = grossCost;
  }
  public ResourceSummaryRow getLessPyAdvProc()
  {
    return lessPyAdvProc;
  }
  public void setLessPyAdvProc(ResourceSummaryRow lessPyAdvProc)
  {
    this.lessPyAdvProc = lessPyAdvProc;
  }
  public ResourceSummaryRow getPlusPyAdvProc()
  {
    return plusPyAdvProc;
  }
  public void setPlusPyAdvProc(ResourceSummaryRow plusPyAdvProc)
  {
    this.plusPyAdvProc = plusPyAdvProc;
  }
  public ResourceSummaryRow getNetProcP1()
  {
    return netProcP1;
  }
  public void setNetProcP1(ResourceSummaryRow netProcP1)
  {
    this.netProcP1 = netProcP1;
  }
  public ResourceSummaryRow getInitialSpares()
  {
    return initialSpares;
  }
  public void setInitialSpares(ResourceSummaryRow initialSpares)
  {
    this.initialSpares = initialSpares;
  }
  public ResourceSummaryRow getTotalProcCost()
  {
    return totalProcCost;
  }
  public void setTotalProcCost(ResourceSummaryRow totalProcCost)
  {
    this.totalProcCost = totalProcCost;
  }
}