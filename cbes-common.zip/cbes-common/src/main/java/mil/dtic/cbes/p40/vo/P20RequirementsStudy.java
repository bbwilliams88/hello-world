package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._P20RequirementsStudy;
import mil.dtic.cbes.p40.vo.util.EqualsPredicate;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class P20RequirementsStudy extends _P20RequirementsStudy
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(P20RequirementsStudy.class);


  @Override
  protected void onPostAdd()
  {
    setInventoryObjectives(getObjectContext().newObject(Costs.class));
    getInventoryObjectives().setType(CostRowType.QUANTITY);
    setTotalAssetsOnHand(getObjectContext().newObject(Costs.class));
    getTotalAssetsOnHand().setType(CostRowType.QUANTITY);
  }


  public void shiftForwardInTime(int years)
  {
    // Vertical shift
    for (int i=0 ; i<years ; i++) {
      if (getPriorYearsDeliveries() != null) {
        Costs apy = getPriorYearsDeliveries();
        setPriorYearsDeliveries(null); // sigh cayenne
        apy.delete();
      }
      setPriorYearsDeliveries(getPriorYearDeliveries());
      setPriorYearDeliveries(getCurrentYearDeliveries());
      setCurrentYearDeliveries(getBy1BaseDeliveries());
      setBy1BaseDeliveries(getBy2Deliveries());
      if (getBy1OocDeliveries() != null) {
        Costs zero = new Costs();
        zero.copyTo(getBy1OocDeliveries());
      }
      setBy2Deliveries(getBy3Deliveries());
      setBy3Deliveries(getBy4Deliveries());
      setBy4Deliveries(getBy5Deliveries());
      createDeliveryIfItDoesntExist(BY5DELIVERIES_RELATIONSHIP_PROPERTY);
    }
    if (getPriorYearsDeliveries() != null) {
      getPriorYearsDeliveries().shiftForwardInTimeNoApysOrBase(years);
    }
    if (getPriorYearDeliveries() != null)
      getPriorYearDeliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getCurrentYearDeliveries() != null)
      getCurrentYearDeliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getBy1BaseDeliveries() != null) {
      getBy1BaseDeliveries().shiftForwardInTimeNoApysOrBase(years);
    }
    // ooc gets erased
    if (getBy2Deliveries() != null)
      getBy2Deliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getBy3Deliveries() != null)
      getBy3Deliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getBy4Deliveries() != null)
      getBy4Deliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getToCompleteDeliveries() != null)
      getToCompleteDeliveries().shiftForwardInTimeNoApysOrBase(years);
    if (getTotalAssetsOnHand() != null)
      getTotalAssetsOnHand().shiftForwardInTimeNoApysOrBase(years);

    cleanupDeliveries();

    for (CostElement ce : this.getCostElements())
    {
      ce.shiftForwardInTimeP20(years);
    }
    if (this.getInventoryObjectives() != null)
      this.getInventoryObjectives().shiftForwardInTimeNoApysOrBase(years);
  }



  public Iterator<P20BY1InventoryObjective> jibx_By1InventoryObjectiveIterator()
  {
    return getIterator(super.getBy1InventoryObjectives());
  }

  @Override
  public List<P20BY1InventoryObjective> getBy1InventoryObjectives()
  {
    return getSortedByDisplayOrder(super.getBy1InventoryObjectives());
  }

  public boolean jibx_hasExpenditures()
  {
    return getTrainingExpenditures() != null || getNonTrainingExpenditures() != null;
  }

  public boolean jibx_hasBy1InventoryObjectives()
  {
    return getBy1InventoryObjectives() != null && !getBy1InventoryObjectives().isEmpty();
  }

  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getBy1InventoryObjectives());
    Util.generateDisplayOrder(super.getSupplementalInfos());
    Util.generateDisplayOrder(getFixedCes(CostElementCategoryType.OtherGains));
    Util.generateDisplayOrder(getFixedCes(CostElementCategoryType.UsageLosses));
  }

  @SuppressWarnings("unchecked")
  private List<CostElement> getFixedCes(CostElementCategoryType cat)
  {
    return new ArrayList<CostElement>(CollectionUtils.select(super.getCostElements(),
      new EqualsPredicate(cat,
        makePath(CostElement.CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY))));
  }

  private void addToFixed(CostElement ce, CostElementCategoryType cat)
  {
    ce.setCategory(CostElementCategory.fetchByTitle(getObjectContext(), cat));
    if (ce.getCategory() == null)
      log.error("category not found: " + cat.getDatabaseValue(), new NullPointerException("q"));
    addToCostElements(ce);
  }

  public boolean jibx_hasOtherGains()
  {
    return CollectionUtils.isNotEmpty(getFixedCes(CostElementCategoryType.OtherGains));
  }

  public Iterator<CostElement> jibx_OtherGainsIterator()
  {
    return getIterator(getFixedCes(CostElementCategoryType.OtherGains));
  }

  public void addToOtherGains(CostElement ce)
  {
    addToFixed(ce, CostElementCategoryType.OtherGains);
  }

  public boolean jibx_hasUsageLosses()
  {
    return CollectionUtils.isNotEmpty(getFixedCes(CostElementCategoryType.UsageLosses));
  }

  public Iterator<CostElement> jibx_UsageLossesIterator()
  {
    return getIterator(getFixedCes(CostElementCategoryType.UsageLosses));
  }

  public void addToUsageLosses(CostElement ce)
  {
    addToFixed(ce, CostElementCategoryType.UsageLosses);
  }

  private P20SupplementalInfo getOneFixed(CostElementCategoryType cat)
  {
    return (P20SupplementalInfo)CollectionUtils.find(getSupplementalInfos(),
      new EqualsPredicate(cat,
        makePath(P20SupplementalInfo.CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY)));
  }

  private void setOneFixed(P20SupplementalInfo si, CostElementCategoryType cat)
  {
    P20SupplementalInfo existing = getOneFixed(cat);
    if (existing == null && si != null)
    {
      si.setCategory(CostElementCategory.fetchByTitleCached(getObjectContext(), cat));
      if (si.getCategory() == null)
        log.error("category not found: " + cat, new NullPointerException("q"));
      addToSupplementalInfos(si);
    } else {
      log.debug("Don't use this to replace existing fixed cost elements");
    }
  }

  public P20SupplementalInfo getTrainingExpenditures()
  {
    return getOneFixed(CostElementCategoryType.Training);
  }

  public void setTrainingExpenditures(P20SupplementalInfo si)
  {
    setOneFixed(si, CostElementCategoryType.Training);
  }

  public P20SupplementalInfo getNonTrainingExpenditures()
  {
    return getOneFixed(CostElementCategoryType.NonTraining);
  }

  public void setNonTrainingExpenditures(P20SupplementalInfo si)
  {
    setOneFixed(si, CostElementCategoryType.NonTraining);
  }

  public P20SupplementalInfo getEligibleForReplacement()
  {
    return getOneFixed(CostElementCategoryType.EligibleForReplacement);
  }

  public void setEligibleForReplacement(P20SupplementalInfo si)
  {
    setOneFixed(si, CostElementCategoryType.EligibleForReplacement);
  }



  // actually does Aircraft as well
  public void generateSuplimentalInfos()
  {
    if (getEligibleForReplacement() == null)
      setEligibleForReplacement(getObjectContext().newObject(P20SupplementalInfo.class));
    if (getTrainingExpenditures() == null)
      setTrainingExpenditures(getObjectContext().newObject(P20SupplementalInfo.class));
    if (getNonTrainingExpenditures() == null)
      setNonTrainingExpenditures(getObjectContext().newObject(P20SupplementalInfo.class));
    if (getAircraftInventory() == null)
      setAircraftInventory(getObjectContext().newObject(P20AircraftInventory.class));
  }


  public void deleteSuplimentalInfosAmmo()
  {
    P20SupplementalInfo info;

    info = getTrainingExpenditures();
    if (info != null)
    {
      setTrainingExpenditures(null);
      getObjectContext().deleteObjects(info);
    }

    info = getNonTrainingExpenditures();
    if (info != null)
    {
      setNonTrainingExpenditures(null);
      getObjectContext().deleteObjects(info);
    }
  }

  public void deleteSuplimentalInfosVehicles()
  {
    P20SupplementalInfo info;

    info = getEligibleForReplacement();
    if (info != null)
    {
      getObjectContext().deleteObjects(info);
      setEligibleForReplacement(null);
    }
  }

  public void deleteAircraftInventories()
  {
    P20AircraftInventory info;

    info = getAircraftInventory();
    if (info != null)
    {
      setAircraftInventory(null);
      getObjectContext().deleteObjects(info);
    }
  }



  private void createDeliveryIfItDoesntExist(String relName)
  {
    Costs c =  (Costs)readProperty(relName);
    if (c == null) {
      c = getObjectContext().newObject(Costs.class);
      c.setType(CostRowType.QUANTITY);
      setToOneTarget(relName, c, true);
    }
  }

  public void generateDeliveries()
  {
    createDeliveryIfItDoesntExist(PRIOR_YEARS_DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(PRIOR_YEAR_DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(CURRENT_YEAR_DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY1BASE_DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY1OOC_DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY2DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY3DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY4DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(BY5DELIVERIES_RELATIONSHIP_PROPERTY);
    createDeliveryIfItDoesntExist(TO_COMPLETE_DELIVERIES_RELATIONSHIP_PROPERTY);
  }

  private void deleteDeliveryIfItsEmpty(String relName)
  {
    Costs c =  (Costs)readProperty(relName);
    if (c != null && c.isEmpty()) {
      setToOneTarget(relName, null, true);
      getObjectContext().deleteObjects(c);
    }
  }

  public void cleanupDeliveries()
  {
    deleteDeliveryIfItsEmpty(PRIOR_YEARS_DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(PRIOR_YEAR_DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(CURRENT_YEAR_DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY1BASE_DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY1OOC_DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY2DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY3DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY4DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(BY5DELIVERIES_RELATIONSHIP_PROPERTY);
    deleteDeliveryIfItsEmpty(TO_COMPLETE_DELIVERIES_RELATIONSHIP_PROPERTY);
  }

  public CostElement addOtherGain()
  {
    CostElement ce = getObjectContext().newObject(CostElement.class);
    addToOtherGains(ce);
    return ce;
  }

  public List<CostElement> getOtherGains()
  {
    return getSortedByDisplayOrder(getFixedCes(CostElementCategoryType.OtherGains));
  }

  public CostElement addUsageLoss()
  {
    CostElement ce = getObjectContext().newObject(CostElement.class);
    addToUsageLosses(ce);
    return ce;
  }

  public List<CostElement> getUsageLosses()
  {
    return getSortedByDisplayOrder(getFixedCes(CostElementCategoryType.UsageLosses));
  }

  public void removeCostElement(CostElement ce)
  {
    removeFromCostElements(ce);
    getObjectContext().deleteObjects(ce);
  }

  public P20BY1InventoryObjective addBy1InventoryObjective()
  {
    P20BY1InventoryObjective io = getObjectContext().newObject(P20BY1InventoryObjective.class);
    addToBy1InventoryObjectives(io);
    return io;
  }

  public void removeBy1InventoryObjective(P20BY1InventoryObjective io)
  {
    removeFromBy1InventoryObjectives(io);
    getObjectContext().deleteObjects(io);
  }

  public List<Costs> getDeliveries()
  {
    List<Costs> list = new ArrayList<Costs>();
    if(getPriorYearsDeliveries() != null)
      list.add(getPriorYearsDeliveries());
    if(getPriorYearDeliveries() != null)
      list.add(getPriorYearDeliveries());
    if(getCurrentYearDeliveries() != null)
      list.add(getCurrentYearDeliveries());
    if(getBy1Deliveries() != null)
      list.add(getBy1Deliveries());
    return list;
  }
}
