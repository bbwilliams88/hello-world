/*
 * $Id: JBToc.java 32873 2009-10-23 17:51:02Z aibrahim $
 */
package mil.dtic.cbes.jb;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.KeyValuePair;


public class MasterJBToc extends BaseToc
{
  private static final Logger log = CbesLogFactory.getLog(MasterJBToc.class);

  GenericToc volumeToc;
  MasterJustificationBook mjb;


  public MasterJBToc()
  {
    this(null, null);
  }


  public MasterJBToc(MasterJustificationBook mjb, GenericToc volumeToc)
  {
    super(mjb, FileSetting.MASTER_TOC);
    this.volumeToc = volumeToc;
    this.mjb = mjb;
  }


  public FormattingResults createPdf() throws IOException, DocumentException, SQLException
  {
    if (volumeToc != null)
      docCreationParams.setTovKvpList(volumeToc.getTocItemList());
    FormattingResults fr = super.createPdf();
    return fr;
  }


  public void prepareTocContents()
  {
    log.debug("Preparing JB TOC items...");
    super.prepareTocContents();
    String firstVolumeLocation = "";
    if (mjb != null && mjb.getJbgList() != null)
      firstVolumeLocation = mjb.getJbgList().get(0).getJbiList().get(0).getJb().getPageNumberPrefix();
    // Note: if we are building a MJBs with multiple JB Groups, there is a flaw
    // in that the below TOC entry always shows the first JB's location in all
    // MJB's. But, since that is not how the Comptroller will use the MJB build,
    // we should be fine. We need to clean this up at some point though.
    if (firstVolumeLocation != null)
    {
      if (mjb.r2sExist())
        addTocItem(tocItemList, new KeyValuePair("RDT&E Justification Books", firstVolumeLocation));
      else if (mjb.lineItemsExist())
        addTocItem(tocItemList, new KeyValuePair("Procurement Justification Books", firstVolumeLocation));
    }
  }

}
