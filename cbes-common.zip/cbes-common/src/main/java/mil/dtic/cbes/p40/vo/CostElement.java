package mil.dtic.cbes.p40.vo;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.PersistenceState;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ItemExhibitType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._CostElement;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.Util;

/**
 *
 */
public class CostElement extends _CostElement implements HasManufacturersWithDeliveries, HasTripletCosts, HasDisplayOrder, RollupParent, Equivalence<CostElement>, IsSubtotalParent, CostContainer
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setupCostElement();
    }

    @Override
    protected void onPrePersist()
    {
      if (CollectionUtils.isEmpty(getAllHistoryPlanningsSorted()))
        setPriorYearsDeliveries(null);
    }

    @Override
    protected void onPostLoad()
    {
        setupCostElement();
    }

    @Override
    protected void onPreUpdate()
    {
      if (CollectionUtils.isEmpty(getManufacturerList()))
        setPriorYearsDeliveries(null);
    }

    private void setupCostElement()
    {
        if (getContracted() == null)
            setContracted(false);
        if (getDisplayOrder() == null)
            setDisplayOrder(0);
        if (getQuantities() == null)
            setQuantities(Costs.create(getObjectContext(), CostRowType.QUANTITY));
        if (getTotalCosts() == null)
            setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
        if (getUnitCosts() == null)
            setUnitCosts(Costs.create(getObjectContext(), CostRowType.UNITCOST));
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * Walks UP the recursive Cost Elements looking for the actual item that
     * holds them all.
     *
     * @return The top Item that contains all the Cost Elements.
     */
    public Item getActualItem()
    {
        if (getItem() == null)
            return getParentCostElement().getActualItem();

        return getItem();
    }

    @Override
    public List<HistoryPlanning> getAllHistoryPlanningsSorted()
    {
        List<HistoryPlanning> allHistoryPlannings = new ArrayList<HistoryPlanning>();

        for (Manufacturer manufacturer : getManufacturerList())
            for (HistoryPlanning historyPlanning : manufacturer.getHistoryPlanningList())
                allHistoryPlannings.add(historyPlanning);

        List<Ordering> orderings = new ArrayList<Ordering>();
        String parentProperty = Manufacturer.COST_ELEMENT_RELATIONSHIP_PROPERTY;
        orderings.add(new Ordering(makePath(HistoryPlanning.MANUFACTURER_RELATIONSHIP_PROPERTY, parentProperty, DISPLAY_ORDER_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));
        orderings.add(new Ordering(HistoryPlanning.ITEM_NAME_SUFFIX_PROPERTY, SortOrder.ASCENDING_INSENSITIVE));
        orderings.add(new Ordering(HistoryPlanning.FISCAL_YEAR_PROPERTY, SortOrder.ASCENDING)); // !!!
        // TODO this was pasted from P5aEdit
        orderings.add(new Ordering(HistoryPlanning.OOC_PROPERTY, SortOrder.ASCENDING));
        orderings.add(new Ordering(makePath(HistoryPlanning.MANUFACTURER_RELATIONSHIP_PROPERTY, Manufacturer.NAME_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));
        orderings.add(new Ordering(makePath(HistoryPlanning.MANUFACTURER_RELATIONSHIP_PROPERTY, Manufacturer.LOCATION_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));

        Ordering.orderList(allHistoryPlannings, orderings);

        return allHistoryPlannings;
    }

    @Override
    public Costs getCosts()
    {
        if (getTotalCosts() != null && !getTotalCosts().isEmpty())
            return getTotalCosts();
        return null;
    }

    public String getFullTitle()
    {
        if (getCategory().isP5TypeWithoutRecurringNonRecurring())
            return getCategory().getTitle().getDatabaseValue() + " " + (getName() == null ? "" : getName());
        else if (getParentCostElement().getName() == null || getParentCostElement().getName().isEmpty())
            return getParentCostElement().getCategory().getTitle().getDatabaseValue() + " " + getCategory().getTitle().getDatabaseValue();
        else
            return getParentCostElement().getCategory().getTitle().getDatabaseValue() + " " + getParentCostElement().getName() + " " + getCategory().getTitle().getDatabaseValue();
    }

    // show "Flyaway/Recurring/name"
    @Override
    public String getLongName()
    {
        CostElement ce = this;
        String catname = "";
        String subcatname = "";
        String name = ce.getName();

        if (ce.getParentCostElement() != null)
        {
            subcatname = ce.getParentCostElement().getCategory().getTitle().getDatabaseValue();
            if (ce.getParentCostElement().getParentCostElement() != null)
            {
                catname = ce.getParentCostElement().getParentCostElement().getCategory().getTitle().getDatabaseValue();
            }
        }

        return catname + " / " + subcatname + " / " + name;
    }

    // FIXME: Is this really this complicated?
    @SuppressWarnings("unchecked")
    public List<CostElementCategory> getSecondaryCategories(ItemExhibitType itemExhibit)
    {
        Expression expression1 = // Category must be active.
        ExpressionFactory.matchExp(Base.makePath(CostElementCategoryExhibit.COST_ELEMENT_CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.STATUS_PROPERTY), StatusFlag.ACTIVE);
        Expression expression2 = // Category must be appropriate to the P5.
        ExpressionFactory.matchExp(Base.makePath(CostElementCategoryExhibit.ITEM_EXHIBIT_RELATIONSHIP_PROPERTY, ItemExhibit.CODE_PROPERTY), itemExhibit);
        Expression expression3 = // Category must be appropriate for the current
                                 // primary category.
        ExpressionFactory.matchExp(CostElementCategoryExhibit.COST_ELEMENT_CATEGORY_RELATIONSHIP_PROPERTY, getParentCostElement().getCategory());

        Ordering ordering1 = new Ordering(Base.makePath(CostElementCategoryExhibit.COST_ELEMENT_CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY), SortOrder.ASCENDING_INSENSITIVE);
        Ordering ordering2 = new Ordering(Base.makePath(CostElementCategoryExhibit.COST_ELEMENT_SUBCATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY), SortOrder.ASCENDING_INSENSITIVE);

        SelectQuery query = new SelectQuery(CostElementCategoryExhibit.class, expression1.andExp(expression2).andExp(expression3));
        query.addOrdering(ordering1);
        query.addOrdering(ordering2);

        // ListOrderedSet los = null;
        // List<CostElementCategoryExhibit> avaliableCategories =
        // CostElementCategoryExhibit.getOrderedCostElementCategories(item.getObjectContext(),
        // ItemExhibitType.P5);
        List<CostElementCategoryExhibit> avaliableCategories = getObjectContext().performQuery(query);
        List<CostElementCategory> secondaryCategories = new ArrayList<CostElementCategory>(avaliableCategories.size());

        // log.debug("*** avaliableCategories = " + avaliableCategories);

        for (CostElementCategoryExhibit costElementCategoryExhibit : avaliableCategories)
            if (costElementCategoryExhibit.getCostElementSubcategory() != null)
                secondaryCategories.add(costElementCategoryExhibit.getCostElementSubcategory());

        // return secondaryCategories.asList();
        // return Collections.list(secondaryCategories.iterator());
        return secondaryCategories;
    }

    /**
     * Returns the lowest level Costs Elements for Rollup
     *
     */
    @Override
    public List<? extends CostContainer> getChildren()
    {
      List<CostElement> costElementsForRollup = new ArrayList<CostElement>();
      if(!CollectionUtils.isEmpty(getCostElementList()))
      {
        //For Flyaway, Hardware, etc get to the iterate over the Subcategories
        if(getCategory() != null && getCategory().isP5TopLevelCategory() && getCategory().isP5TypeWithRecurringNonRecurring())
          for(CostElement costElement : getCostElementList())
          {
            costElementsForRollup.addAll(costElement.getCostElementList());
          }
        else //When this is a Recurring/Nonrecurring category just add the CEs
          costElementsForRollup.addAll(getCostElementList());
      }

      return costElementsForRollup;
    }

    // FIXME: This should be an is* method.
    public boolean hasDeliverySchedule()
    {
        for (HistoryPlanning historyPlanning : getAllHistoryPlanningsSorted())
            if (historyPlanning.getDeliveryScheduleList() != null && !historyPlanning.getDeliveryScheduleList().isEmpty())
                return true;

        return false;
    }

    @Override
    public boolean isContinuing()
    {
        return getTotalCosts() != null && getTotalCosts().isContinuing();
    }


    @Override
    public List<CostElement> getCostElementList()
    {
      //FIXME this hsould be removed and all references updated to getOrderedCostElements()
        return getSortedByDisplayOrder(super.getCostElementList());
    }

    public List<CostElement> getOrderedCostElements()
    {
        return getSortedByDisplayOrder(super.getCostElementList());
    }

    @Override
    public List<Manufacturer> getManufacturerList()
    {
        return getSortedByDisplayOrder(super.getManufacturerList());
    }

    @Override
    public Manufacturer addManufacturer()
    {
        Manufacturer m = getObjectContext().newObject(Manufacturer.class);
        addToManufacturerList(m);
        return m;
    }

    @Override
    public void removeManufacturer(Manufacturer m)
    {
        removeFromManufacturerList(m);
        getObjectContext().deleteObjects(m);
    }

    public boolean isFixed()
    {
        return (getCategory() != null);
    }

    private CostElement getFixed(CostElementCategoryType cat)
    {
        return getFixedCe(COST_ELEMENT_LIST_RELATIONSHIP_PROPERTY, cat);
    }

    private void setFixed(CostElement ce, CostElement existing, CostElementCategoryType cat)
    {
        setFixedCe(COST_ELEMENT_LIST_RELATIONSHIP_PROPERTY, ce, existing, cat);
    }

    public CostElement getRecurring()
    {
        return getFixed(CostElementCategoryType.RECURRING);
    }

    public void setRecurring(CostElement ce)
    {
        setFixed(ce, getRecurring(), CostElementCategoryType.RECURRING);
    }

    public CostElement getNonRecurring()
    {
        return getFixed(CostElementCategoryType.NONRECURRING);
    }

    public void setNonRecurring(CostElement ce)
    {
        setFixed(ce, getNonRecurring(), CostElementCategoryType.NONRECURRING);
    }

    /**
     * Method to
     * @return list of CostElements that makes up the lowest level CostElements
     */
    public List<CostElement> getLowestLevelCostElements()
    {
        if (getCategory() != null)
        {
            // TODO make sure this works with the P3a
            List<CostElement> childCostElements = new ArrayList<CostElement>();
            if (getCategory().isP5TypeWithoutRecurringNonRecurring())
            {
                childCostElements.addAll(getCostElementList());
            }
            else
            {
                for (CostElement childCostElement : getCostElementList())
                {
                    childCostElements.addAll(childCostElement.getCostElementList());
                }
            }
            // TODO Should this return null if the list is empty?
            return childCostElements;
        }

        return null;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Recursively clear out Cost Element Costs.
    public static void clearOutYears(List<CostElement> costElements)
    {
        if (CollectionUtils.isNotEmpty(costElements))
        {
            for (CostElement costElement : costElements)
            {
                Costs.clearOutYears(costElement.getQuantities());
                Costs.clearOutYears(costElement.getUnitCosts());
                Costs.clearOutYears(costElement.getTotalCosts());

                clearOutYears(costElement.getCostElementList());
            }
        }
    }

    public CostElement addCostElement(String name)
    {
        CostElement costElement = getObjectContext().newObject(CostElement.class);

        costElement.setName(name);
        addToCostElementList(costElement);
        //Util.generateDisplayOrder(getCostElementList());

        return costElement;
    }

    @Override
    public void addToCostElementList(CostElement costElement)
    {
    	super.addToCostElementList(costElement);
    	Util.generateDisplayOrder(super.getCostElementList());
    }

    public void deleteCostElement(CostElement costElement)
    {
        if (super.getCostElementList().contains(costElement))
        {
            removeFromCostElementList(costElement);
            getObjectContext().deleteObjects(costElement);
        }
        else
        {
            throw new IllegalArgumentException("it wasn't here to begin with");
        }
    }

    /**
     * Sets the Cost Elements TotalCosts to the sum of the child cost elements
     * costs Uses the Subtotal of Recurring and Nonrecurring when at the top
     * level Handles Recurring and Nonrecurring for the P3a as well
     * @throws ReflectiveOperationException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    @Override
    public void calculateSubtotals() throws MethodDispatchException
    {
        if (getCategory() != null && getCategory().isP5TopLevelCategory())
        {
            // Need to reset the Total Cost before any calculations
            Costs subtotals = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
            if (getRecurring() != null)
            {
                getRecurring().calculateSubtotals();
                addToSubtotalInDollars(subtotals, getRecurring().getCostElementList());
            }

            if (getNonRecurring() != null)
            {
                getNonRecurring().calculateSubtotals();
                addToSubtotalInDollars(subtotals, getNonRecurring().getCostElementList());
            }

            if (getCategory().isP5TypeWithoutRecurringNonRecurring())
            {
                addToSubtotalInDollars(subtotals, getCostElementList());
            }

            // Check if any CE's are Cont and if so then set the Cost Element Total Continuing
            if ((getRecurring() != null && isChildContinuing(getRecurring().getCostElementList())) || (getNonRecurring() != null && isChildContinuing(getNonRecurring().getCostElementList())))
                subtotals.setContinuing(true);

            replaceCosts(setSubtotalValuesInMillion(subtotals), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
        }
        else if (getCategory() != null && (getCategory().getTitle().equals(CostElementCategoryType.RECURRING) || getCategory().getTitle().equals(CostElementCategoryType.NONRECURRING)))
        {
            // Need to reset the Total Cost before any calculations
            Costs subtotals = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
            addToSubtotalInDollars(subtotals, getCostElementList());
            replaceCosts(setSubtotalValuesInMillion(subtotals), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
        }
        else if (getCategory() != null)
        {
            //QUESTION: A/B kit does not have category?
            // Handle the P3a Kits so they calculate their recurring and non-recurring subtotals
            for (CostElement costElement : getCostElementList())
                costElement.calculateSubtotals();
        }
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        for (CostElement costElement : this.getCostElementList())
            costElement.shiftForwardInTime(years);

        if (this.getInstallationSchedule() != null)
            this.getInstallationSchedule().shiftForwardInTime(years);

        if (this.getTotalCosts() != null)
            this.getTotalCosts().shiftForwardInTime(years);

        if (this.getQuantities() != null)
            this.getQuantities().shiftForwardInTime(years);

        if (this.getUnitCosts() != null)
            this.getUnitCosts().shiftForwardInTime(years);
    }

    public void shiftForwardInTimeP20(int years)
    {
        for (CostElement costElement : this.getCostElementList())
            costElement.shiftForwardInTimeP20(years);

        if (this.getTotalCosts() != null)
            this.getTotalCosts().shiftForwardInTimeNoApysOrBase(years);

        if (this.getQuantities() != null)
            this.getQuantities().shiftForwardInTimeNoApysOrBase(years);

        if (this.getUnitCosts() != null)
            this.getUnitCosts().shiftForwardInTimeNoApysOrBase(years);
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasRecurring()
    {
        return (getRecurring() != null && getRecurring().getTotalCosts() != null && !getRecurring().getTotalCosts().isEmpty()) ||
        		(getRecurring() != null && getRecurring().getCostElementList() != null && !getRecurring().getCostElementList().isEmpty());
    }

    public boolean jibx_hasNonRecurring()
    {
        return (getNonRecurring() != null && getNonRecurring().getTotalCosts() != null && !getNonRecurring().getTotalCosts().isEmpty()) ||
        		(getNonRecurring() != null && getNonRecurring().getCostElementList() != null && !getNonRecurring().getCostElementList().isEmpty());
    }

    public boolean jibx_HasCategoryName()
    {
        return super.getCategory().getTitle() != null && getName() != null;
    }

    public boolean jibx_HasName()
    {
        if (StringUtils.isEmpty(getName()))
            return false;
        else
            return true;
    }

    public boolean jibx_hasPriorYearsDeliveries()
    {
        if (getPriorYearsDeliveries() != null)
            return true;

        return false;
    }

    public boolean jibx_hasCostElements()
    {
        return super.getCostElementList().size() > 0;
    }

    public Iterator<CostElement> jibx_costElementIterator()
    {
        return getIterator(getCostElementList());
    }

    public boolean jibx_hasManufacturerList()
    {
        return CollectionUtils.isNotEmpty(super.getManufacturerList());
    }

    public Iterator<Manufacturer> jibx_manufacturerIterator()
    {
        return getIterator(super.getManufacturerList());
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(super.getCostElementList());
        Util.generateDisplayOrder(super.getManufacturerList());
    }

    @Override
    public String jibx_getContinuingFootnote()
    {
        return getTotalCosts().getContinuingFootnote();
    }

    @Override
    public void jibx_setContinuingFootnote(String s)
    {
        getTotalCosts().setContinuingFootnote(s);
    }

    @Override
    public boolean jibx_hasQuantity()
    {
        return getQuantities() != null && !getQuantities().isEmpty();
    }

    @Override
    public boolean jibx_hasTotalCost()
    {
        return getTotalCosts() != null && !getTotalCosts().isEmpty();
    }

    @Override
    public boolean jibx_hasUnitCost()
    {
        return getUnitCosts() != null && !getUnitCosts().isEmpty();
    }

    public boolean jibx_hasTotalCostsOrQuantities()
    {
        return (getTotalCosts() != null && !getTotalCosts().isEmpty()) || (getQuantities() != null && !getQuantities().isEmpty());
    }

    public boolean jibx_hasTotalCostsOrQuantitiesOrUnitCosts()
    {
        return (getTotalCosts() != null && !getTotalCosts().isEmpty()) || (getQuantities() != null && !getQuantities().isEmpty()) || (getUnitCosts() != null && !getUnitCosts().isEmpty());
    }

    @Override
    public void jibx_setQuantities(Costs quantities)
    {
        if (quantities != null)
            setQuantities(quantities);
    }

    @Override
    public void jibx_setTotalCosts(Costs totalCosts)
    {
        if (totalCosts != null)
            setTotalCosts(totalCosts);
    }

    @Override
    public void jibx_setUnitCosts(Costs unitCosts)
    {
        if (unitCosts != null)
            setUnitCosts(unitCosts);
    }


    public boolean jibx_hasOrganic()
    {
        return getOrganic() != null;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * HashCode based on Business Rule [E-XML-PROC#U150]
     */
    @Override
    public int equivalenceHashCode()
    {
        if (this.getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getName()));
        builder.append(getCategory());
        builder.append(getItem());
        builder.append(getParentCostElement());
        builder.append(getModsItem());
        builder.append(getModsItemGroup());
        builder.append(getRequirementsStudy());

        return builder.toHashCode();
    }

    /**
     * Equality based on Business Rule [E-XML-PROC#U150]
     */
    @Override
    public boolean equivalentTo(CostElement obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        CostElement other = obj;

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName()));
        builder.append(getCategory(), other.getCategory());
        builder.append(getItem(), other.getItem());
        builder.append(getParentCostElement(), other.getParentCostElement());
        builder.append(getModsItem(), other.getModsItem());
        builder.append(getModsItemGroup(), other.getModsItemGroup());
        builder.append(getRequirementsStudy(), other.getRequirementsStudy());

        return builder.isEquals();
    }
}
