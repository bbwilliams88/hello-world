package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum NewOptionType implements ExtendedEnumeration
{
    NEW     ("new",     "NEW",     "New contracts"), 
    OPTION  ("option",  "OPTION",  "Option year renewal"),
    VARIOUS ("various", "VARIOUS", "Various since several contracts represented");
    
    private final String xmlName;
    private final String dbName;
    private final String description;

    private NewOptionType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static NewOptionType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(NewOptionType.class, databaseValue);
    }

    public static NewOptionType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(NewOptionType.class, enumValue);
    }
}
