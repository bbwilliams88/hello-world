package mil.dtic.cbes.p40.vo;

import java.util.List;

import mil.dtic.cbes.p40.vo.auto._InactiveIndustrialFacilityProjectFundingCategory;
import mil.dtic.cbes.p40.vo.wrappers.CayenneListWrapper;

/**
 *
 */
public class InactiveIndustrialFacilityProjectFundingCategory extends _InactiveIndustrialFacilityProjectFundingCategory
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    @Override
    public List<InactiveIndustrialFacilityProjectFunding> getFundingList()
    {
        return new CayenneListWrapper<InactiveIndustrialFacilityProjectFunding>(this, super.getFundingList(), FUNDING_LIST_RELATIONSHIP_PROPERTY, true);
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public void shiftForwardInTime(int years)
    {
        for (InactiveIndustrialFacilityProjectFunding funding : this.getFundingList())
            funding.shiftForwardInTime(years);
    }
}
