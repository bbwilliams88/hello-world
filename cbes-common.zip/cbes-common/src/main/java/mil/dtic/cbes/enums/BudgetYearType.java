package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.service.exception.NotFoundException;
import mil.dtic.utility.CbesLogFactory;

/**
 * Used by Mods installation cost
 */
public enum BudgetYearType implements ExtendedEnumeration
{
  PriorYears("PYRS"),
  PriorYear("PY"),
  CurrentYear("CY"),
  //  BY1BASE("BY1"),
  //  BY1OOC("BY1"),
  BY1,
  BY2,
  BY3,
  BY4,
  BY5,
  ToComplete("TC"),
  Total("TOTAL");

  private static final Logger log = CbesLogFactory.getLog(BudgetYearType.class);
  private final String databaseValue;

  private BudgetYearType()
  {
    this.databaseValue = toString();
  }

  private BudgetYearType(String dbName)
  {
    this.databaseValue = dbName;
  }

  @Override
  public String getDatabaseValue()
  {
    return databaseValue;
  }

  /**
   * @return the BudgetYearType shifted by <tt>direction</tt> years, or null
   * if out of bounds
   */
  public BudgetYearType getShifted(int direction) {
    // This depends on the ordinal ordering of the enum to shift
    int newordinal = ordinal() + direction;
    if (newordinal >= 0 && newordinal < values().length) {
      return values()[newordinal];
    }
    return null;
  }

  public String getUiYear(int baseYear)
  {
    switch (this)
    {
      case PriorYears:
        return "Prior Years";
      case PriorYear:
        return "FY " + (baseYear - 2);
      case CurrentYear:
        return "FY " + (baseYear - 1);
      case BY1:
        return "FY " + (baseYear - 0);
      case BY2:
        return "FY " + (baseYear + 1);
      case BY3:
        return "FY " + (baseYear + 2);
      case BY4:
        return "FY " + (baseYear + 3);
      case BY5:
        return "FY " + (baseYear + 4);
      case ToComplete:
        return "To Complete";
      case Total:
        return "Total";
      default:
        log.error("case failed, showing dummy message", new NotFoundException());
        return "{error}";
    }
  }

  public boolean isPriorYears()
  {
    return this == PriorYears;
  }

  public boolean isPriorYearsEditable()
  {
    return this == Total || this == PriorYears;
  }

  public boolean isPriorYearEditable()
  {
    return this == Total || this == PriorYears || this == PriorYear;
  }

  public boolean isCurrentYearEditable()
  {
    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear;
  }

  public boolean isBy1Editable()
  {
    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1;
  }

  public boolean isBy2Editable()
  {
    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1 || this == BY2;
  }

  public boolean isBy3Editable()
  {
    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1 || this == BY2 || this == BY3;
  }

  public boolean isBy4Editable()
  {

    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1 || this == BY2 || this == BY3 || this == BY4;

  }

  public boolean isBy5Editable()
  {
    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1 || this == BY2 || this == BY3 || this == BY4 || this == BY5;

  }

  public boolean isToCompleteEditable()
  {

    return this == Total || this == PriorYears || this == PriorYear || this == CurrentYear || this == BY1 || this == BY2 || this == BY3 || this == BY4 || this == BY5 || this == ToComplete;

  }

  public boolean isTotal()
  {
    return this == Total;
  }
}
