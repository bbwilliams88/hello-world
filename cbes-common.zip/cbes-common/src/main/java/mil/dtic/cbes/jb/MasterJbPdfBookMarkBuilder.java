package mil.dtic.cbes.jb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import mil.dtic.utility.CbesLogFactory;

public class MasterJbPdfBookMarkBuilder {
    private static final Logger log = CbesLogFactory.getLog(MasterJbPdfBookMarkBuilder.class);
    
    private static final String TITLE = "Title";
    private static final String STYLE = "Style";
    private static final String BOLD = "bold";
    private static final String ACTION = "Action";
    private static final String GOTO = "GoTo";
    private static final String PAGE = "Page";
    private static final String OPEN = "Open";
    private static final String TRUE = "True";
    private static final String FALSE = "False";
    private static final String FIT_W_LEAD_SPACE = " Fit";
    private static final String KIDS = "Kids";
    
    int pageNumberOffset;

    public MasterJbPdfBookMarkBuilder() {}

    public List<HashMap<String, Object>> getBookmarkList(MasterJustificationBook mjb, JustificationBookGroup jbig){
      log.trace("getBookmarkList(mjb): - start");        
      List<HashMap<String, Object>> mjbOutlineList = new ArrayList<HashMap<String, Object>>();
      List<HashMap<String, Object>> kidsList = new ArrayList<HashMap<String, Object>>();
      mjbOutlineList.add(createBookmarkEntry(mjb, kidsList, true, true));
      addComponentsToBookmarkList(kidsList, mjb);
      
      if (jbig != null) {
          int runningPageNumberOffset = mjb.getPdfTotalPageCount();
          log.trace("getBookmarkList(mjb): runningPageNumberOffSet: " + runningPageNumberOffset);
          JbPdfBookMarkBuilder jbbb = new JbPdfBookMarkBuilder();
          for (JustificationBookInfo jbi : jbig.getJbiList()) {
              JustificationBook jb = jbi.getJb();
              jbbb.setPageNumberOffset(runningPageNumberOffset);
              kidsList.addAll(jbbb.getBookmarkList(jb));
              log.trace("getBookmarkList(mjb): kidsLists size: " + kidsList.size());
              runningPageNumberOffset += jb.getPdfTotalPageCount();
          }
      }
      log.trace("getBookmarkList(mjb): - finished");
      return mjbOutlineList;
    }

    public void addComponentsToBookmarkList(List<HashMap<String, Object>> outlineList, MasterJustificationBook mjb) {
        log.trace("addComponentsToBookmarkList(mjb): - start  initial outlineList size: " + outlineList.size());
        outlineList.add(createBookmarkEntry(mjb.getCoverDoc()));
        outlineList.add(createBookmarkEntry(mjb.getVolumeToc()));
        outlineList.add(createBookmarkEntry(mjb.getToc()));
        
        if (mjb.getCostDoc() != null){
            outlineList.add(createBookmarkEntry(mjb.getCostDoc()));
        }

        if (mjb.getIntroductionDoc() != null){
            outlineList.add(createBookmarkEntry(mjb.getIntroductionDoc()));
        }

        if (mjb.getUserR1Doc() != null){
            outlineList.add(createBookmarkEntry(mjb.getUserR1Doc()));
        }

        if (mjb.getUserP1Doc() != null){
            outlineList.add(createBookmarkEntry(mjb.getUserP1Doc()));
        }

        if (mjb.getPeTocByBa() != null){
            outlineList.add(createBookmarkEntry(mjb.getPeTocByBa()));
        }

        if (mjb.getPeTocByTitle() != null){
            outlineList.add(createBookmarkEntry(mjb.getPeTocByTitle()));
        }

        if (mjb.getLiTocByBa() != null){
            outlineList.add(createBookmarkEntry(mjb.getLiTocByBa()));
        }

        if (mjb.getLiTocByTitle() != null){
            outlineList.add(createBookmarkEntry(mjb.getLiTocByTitle()));
        }

        if (mjb.getSummaryDoc() != null){
            outlineList.add(createBookmarkEntry(mjb.getSummaryDoc()));
        }

        if (mjb.getR1Summary() != null){
            outlineList.add(createBookmarkEntry(mjb.getR1Summary()));
        }

        if (mjb.getR1() != null){
            outlineList.add(createBookmarkEntry(mjb.getR1()));
        }

        if (mjb.getR1c() != null){
            outlineList.add(createBookmarkEntry(mjb.getR1c()));
        }

        if (mjb.getR1d() != null){
            outlineList.add(createBookmarkEntry(mjb.getR1d()));
        }

        if (mjb.getP1() != null){
            outlineList.add(createBookmarkEntry(mjb.getP1()));
        }

        if (mjb.getP1m() != null){
            outlineList.add(createBookmarkEntry(mjb.getP1m()));
        }

        if (mjb.getSupplementalDocCollection() != null) {
            List<HashMap<String, Object>> suppOutlineList = new ArrayList<HashMap<String, Object>>();
            for (JBSupplementalDoc suppDoc : mjb.getSupplementalDocCollection().getSupplementalDocList()) {
                suppOutlineList.add(createBookmarkEntry(suppDoc));
            }
            mjb.getSupplementalDocCollection().setPdfAbsoluteStartPage(mjb.getSupplementalDocCollection().getSupplementalDocList().get(0).getPdfAbsoluteStartPage());
            outlineList.add(createBookmarkEntry(mjb.getSupplementalDocCollection(), suppOutlineList));
        }

        if (mjb.getAcronymDoc() != null){
            outlineList.add(createBookmarkEntry(mjb.getAcronymDoc()));
        }
        
        log.trace("addComponentsToBookmarkList: - finished  outlineList size: " + outlineList.size());
  }

  protected HashMap<String, Object> createBookmarkEntry(JBPart jbPart)  {
      log.trace("createBookmarkEntry: 1 param");
      return createBookmarkEntry(jbPart, null);
  }

  protected HashMap<String, Object> createBookmarkEntry(JBPart jbPart, List<HashMap<String, Object>> kidsList) {
      log.trace("createBookmarkEntry: 2 param");
      return createBookmarkEntry(jbPart, kidsList, false, false);
  }
  
  protected HashMap<String, Object> createBookmarkEntry(JBPart jbPart, List<HashMap<String, Object>> kidsList, 
          boolean makeBold, boolean expandOnLoad) {
      log.trace("createBookmarkEntry: 4 param processing jbPart: " + jbPart.getClass().getName());
      HashMap<String, Object> bookmarkEntryMap = new HashMap<String, Object>();
      bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.TITLE, jbPart.getPdfBookmarkLabel());
      
      if (makeBold){
          bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.STYLE, MasterJbPdfBookMarkBuilder.BOLD);
      }
    
      bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.ACTION, MasterJbPdfBookMarkBuilder.GOTO);
      bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.PAGE, getPageNumber(jbPart) + MasterJbPdfBookMarkBuilder.FIT_W_LEAD_SPACE);
      
      if (kidsList != null) {
          bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.KIDS, kidsList);
      }
      
      if (expandOnLoad){
          bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.OPEN, MasterJbPdfBookMarkBuilder.TRUE);
      }
      else {
          bookmarkEntryMap.put(MasterJbPdfBookMarkBuilder.OPEN, MasterJbPdfBookMarkBuilder.FALSE);
      }
          
      Iterator<Map.Entry<String, Object>> iterator = bookmarkEntryMap.entrySet().iterator();
      while(iterator.hasNext()){
          Map.Entry<String, Object> entry = iterator.next();
          log.trace("bookmarkEntryMap key: " + entry.getKey() + " value: " + entry.getValue().toString());
      }
      
      return bookmarkEntryMap;
  }

  protected int getPageNumber(JBPart jbPart) {
      log.trace("getPageNumber: for jbPart: " + jbPart.getClass().getName());
      log.trace("getPageNumber: pageNumberOffset = " + pageNumberOffset);
      int pageNumber = jbPart.getPdfAbsoluteStartPage() + pageNumberOffset;
      log.trace("getPageNumber: returning " + pageNumber);
      return pageNumber;
  }


  public int getPageNumberOffset() {
      log.trace("getPageNumberOffset: returning: " + pageNumberOffset);
      return pageNumberOffset;
  }

  public void setPageNumberOffset(int pageNumberOffset) {
      log.trace("setPageNumberOffset: pageNumberOffset value " + pageNumberOffset);
      this.pageNumberOffset = pageNumberOffset;
  }

}
