package mil.dtic.cbes.p40.vo;



import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.DateAlternateOptionsType;
import mil.dtic.cbes.p40.vo.auto._ExtendedHistoryPlanning;
import mil.dtic.cbes.xml.XmlBindingUtil;

public class ExtendedHistoryPlanning extends _ExtendedHistoryPlanning
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasContractMethodAndTypeList() {
      return CollectionUtils.isNotEmpty(getContractMethodAndTypeList());
    }

    public Iterator<ContractMethodTypeFundingVehicle> jibx_contractMethodAndTypeListIterator() {
      return getContractMethodAndTypeList().iterator();
    }
    
    public void jibx_setAwardDate(String date)
    {
      for (DateAlternateOptionsType type : DateAlternateOptionsType.values())
      {
        if (StringUtils.equals(date, type.getXmlName()))
        {
          setAwardDateAlternateOption(type);
          return;
        }
      }
      setAwardDate(XmlBindingUtil.convertMonthYearToDate(date));
    }
    
    public String jibx_getAwardDate()
    {
      return getAwardDateAlternateOption() == null ? XmlBindingUtil.convertDateToMonthYearString(getAwardDate()) : getAwardDateAlternateOption().getXmlName();
    }
    
    @Override
    public boolean jibx_hasAwardDate()
    {
      return StringUtils.isNotEmpty(jibx_getAwardDate());
    }
    
    public void jibx_setFirstDeliveryDate(String date)
    {
      for (DateAlternateOptionsType type : DateAlternateOptionsType.values())
      {
        if (StringUtils.equals(date, type.getXmlName()))
        {
          setFirstDeliveryDateAlternateOption(type);
          return;
        }
      }
      setFirstDeliveryDate(XmlBindingUtil.convertMonthYearToDate(date));
    }
    
    public String jibx_getFirstDeliveryDate()
    {
      return getFirstDeliveryDateAlternateOption() == null ? XmlBindingUtil.convertDateToMonthYearString(getFirstDeliveryDate()) : getFirstDeliveryDateAlternateOption().getXmlName();
    }
    
    @Override
    public boolean jibx_hasFirstDeliveryDate()
    {
      return StringUtils.isNotEmpty(jibx_getFirstDeliveryDate());
    }
    
    public void jibx_setRequiredAwardDate(String date)
    {
      for (DateAlternateOptionsType type : DateAlternateOptionsType.values())
      {
        if (StringUtils.equals(date, type.getXmlName()))
        {
          setRequiredAwardDateAlternateOption(type);
          return;
        }
      }
      setRequiredAwardDate(XmlBindingUtil.convertMonthYearToDate(date));
    }
    
    public String jibx_getRequiredAwardDate()
    {
      return getRequiredAwardDateAlternateOption() == null ? XmlBindingUtil.convertDateToMonthYearString(getRequiredAwardDate()) : getRequiredAwardDateAlternateOption().getXmlName();
    }
    
    @Override
    public boolean jibx_hasRequiredAwardDate()
    {
      return StringUtils.isNotEmpty(jibx_getRequiredAwardDate());
    }
        
    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
