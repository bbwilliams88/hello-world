package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectCostElementItem;

public class ProductionSupportFacilityProjectCostElementItem extends _ProductionSupportFacilityProjectCostElementItem implements CostContainer
{
  private static final long serialVersionUID = 1L;


  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
  }


  @Override
  protected void onPrePersist()
  {
  }


  public void shiftForwardInTime(int years)
  {
    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
  }


  @Override
  public Costs getUnitCosts()
  {
    return null;
  }


  @Override
  public Costs getQuantities()
  {
    return null;
  }
}
