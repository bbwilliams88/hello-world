package mil.dtic.cbes.jb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.MultiYearProcurement;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.utility.CbesLogFactory;


public class JbPdfBookMarkBuilder extends MasterJbPdfBookMarkBuilder {
    private static final Logger log = CbesLogFactory.getLog(JbPdfBookMarkBuilder.class);
    private boolean postSupplementalDocuments = false;
    
  public JbPdfBookMarkBuilder() {}

  public List<HashMap<String, Object>> getBookmarkList(JustificationBook jb) {
      log.trace("getBookmarkList(jb): - start");
      List<HashMap<String, Object>> jbOutlineList = new ArrayList<HashMap<String, Object>>();
      List<HashMap<String, Object>> kidsList = new ArrayList<HashMap<String, Object>>();
      jbOutlineList.add(createBookmarkEntry(jb, kidsList, true, jb.isStandalone()));
      addComponentsToBookmarkList(kidsList, jb);
    
      if (jb.r2sExist()) {
          List<HashMap<String, Object>> r2OutlineList = new ArrayList<HashMap<String, Object>>();
          
          for (R2Exhibit r2Exhibit : jb.getR2ExhibitList().getR2Exhibits()){
              List<HashMap<String, Object>> projectOutlineList = new ArrayList<HashMap<String, Object>>();
              r2OutlineList.add(createBookmarkEntry(r2Exhibit, projectOutlineList));
          }
          
          kidsList.add(createBookmarkEntry(jb.getR2ExhibitList(), r2OutlineList));
      }

      int totalAdvanceProcurementPages = 0;
      
      if (jb.lineItemsExist()) {
          int advanceProcurementPages = 0;
          List<HashMap<String, Object>> p40OutlineList = new ArrayList<HashMap<String, Object>>();
          List<LineItemWrapper> lineItems = new ArrayList<LineItemWrapper>(jb.getLineItemList().getLineItems());
          // Create a Bookmark entry for Advance Procurement
          for (LineItemWrapper li : lineItems) {
              // Account for the Advance Procurement pages in the absolute start page
              if (advanceProcurementPages > 0){
                  li.setPdfAbsoluteStartPage(li.getPdfAbsoluteStartPage() + advanceProcurementPages);
              }

              List<HashMap<String, Object>> itemOutlineList = new ArrayList<HashMap<String, Object>>();
        
              if(!li.getLineItem().hasAPOnlyFlag() || li.getLineItem().getAPOnlyFlag() == false){
                  p40OutlineList.add(createBookmarkEntry(li, itemOutlineList));
              }
        
              //Add the Advance Procurement bookmark here
              //Take note of special exception for standalone AP P-40s
              if (li.getLineItem().isAdvanceProcurement()) {
                  LineItem liap = new LineItem();
                  liap.setLineItemNumber(li.getLineItem().getLineItemNumber());
                  liap.setP1LineItemNumber(li.getLineItem().getAdvanceProcurementP1LineItemNumber());
                  liap.setLineItemTitle(li.getLineItem().getLineItemTitle() + ", Advance Procurement");

                  LineItemWrapper liwap = new LineItemWrapper();
                  liwap.setLineItem(liap);

                  //Only increment for the Line Item if this is not a standalone AP P-40.
                  //Otherwise the LI will not show up in the PDF and we should ignore it in
                  //the bookmarks.
                  
                  if(!li.getLineItem().hasAPOnlyFlag() || li.getLineItem().getAPOnlyFlag() == false){
                      liwap.setPdfAbsoluteStartPage(li.getPdfAbsoluteStartPage() + li.getPdfTotalPageCount());
                  }
                  else{
                      liwap.setPdfAbsoluteStartPage(li.getPdfAbsoluteStartPage());
                  }
          
                  p40OutlineList.add(createBookmarkEntry(liwap, itemOutlineList));
          
                  //Do not add standalone AP P-40 pages to the overall advanceProcurementPages.
                  if(!li.getLineItem().hasAPOnlyFlag() || li.getLineItem().getAPOnlyFlag() == false){
                      advanceProcurementPages += li.getLineItem().getAdvanceProcurementTotalPages();
                  }
              }
          }  // end of forEach
          
          kidsList.add(createBookmarkEntry(jb.getLineItemList(), p40OutlineList));
          totalAdvanceProcurementPages = advanceProcurementPages;
      }

      if (jb.multiYearProcurementsExist()) {
          List<HashMap<String, Object>> mypOutlineList = new ArrayList<HashMap<String, Object>>();
          for (MultiYearProcurement myp : jb.getMultiYearProcurementList().getMultiYearProcurements()) {
              if (totalAdvanceProcurementPages > 0){
                  myp.setPdfAbsoluteStartPage(myp.getPdfAbsoluteStartPage() + totalAdvanceProcurementPages);
              }
              List<HashMap<String, Object>> mypList = new ArrayList<HashMap<String, Object>>();
              //r2OutlineList.add(createBookmarkEntry(r2Exhibit, projectOutlineList));
              mypOutlineList.add(createBookmarkEntry(myp, mypList));
          }
          
          jb.getMultiYearProcurementList().setPdfAbsoluteStartPage(jb.getMultiYearProcurementList().
                  getPdfAbsoluteStartPage() + totalAdvanceProcurementPages);
          kidsList.add(createBookmarkEntry(jb.getMultiYearProcurementList(), mypOutlineList));
      }
      
      if(postSupplementalDocuments){
          log.trace("getBookmarkList(): processing supplementalDocs at the end of JBook");
          processSupplementalDocuments(jb.getSupplementalDocCollection(), kidsList, jb);
      }
      
      log.trace("getBookmarkList(jb): - finished");
      return jbOutlineList;
  }


  public void addComponentsToBookmarkList(List<HashMap<String, Object>> outlineList, JustificationBook jb){
      log.trace("addComponentsToBookmarkList(jb): - start  initial outlineList size: " + outlineList.size());
      outlineList.add(createBookmarkEntry(jb.getCoverDoc()));

      if (jb.getMasterVolumeToc() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterVolumeToc()));
      }

      if (jb.getToc() != null){
          outlineList.add(createBookmarkEntry(jb.getToc()));
      }

      //CXE-6606
      if (jb.getCostDoc() != null){
          outlineList.add(createBookmarkEntry(jb.getCostDoc()));
      }

      if (jb.getIntroductionDoc() != null){
          outlineList.add(createBookmarkEntry(jb.getIntroductionDoc()));
      }

      if (jb.getUserR1Doc() != null){
          outlineList.add(createBookmarkEntry(jb.getUserR1Doc()));
      }

      if (jb.getUserP1Doc() != null){
          outlineList.add(createBookmarkEntry(jb.getUserP1Doc()));
      }

      if (jb.getMasterPeTocByBa() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterPeTocByBa()));
      }

      if (jb.getMasterPeTocByTitle() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterPeTocByTitle()));
      }

      if (jb.getPeTocByBa() != null){
          outlineList.add(createBookmarkEntry(jb.getPeTocByBa()));
      }

      if (jb.getPeTocByTitle() != null){
          outlineList.add(createBookmarkEntry(jb.getPeTocByTitle()));
      }

      if (jb.getMasterLiTocByBa() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterLiTocByBa()));
      }

      if (jb.getMasterLiTocByTitle() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterLiTocByTitle()));
      }

      if (jb.getLiTocByBa() != null){
          outlineList.add(createBookmarkEntry(jb.getLiTocByBa()));
      }

      if (jb.getLiTocByTitle() != null){
          outlineList.add(createBookmarkEntry(jb.getLiTocByTitle()));
      }

      if (jb.getSummaryDoc() != null){
          outlineList.add(createBookmarkEntry(jb.getSummaryDoc()));
      }

      if (jb.getMasterR1Summary() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterR1Summary()));
      }

      if (jb.getMasterR1() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterR1()));
      }

      if (jb.getMasterR1c() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterR1c()));
      }

      if (jb.getMasterR1d() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterR1d()));
      }

      if (jb.getR1Summary() != null){
          outlineList.add(createBookmarkEntry(jb.getR1Summary()));
      }

      if (jb.getR1() != null){
          outlineList.add(createBookmarkEntry(jb.getR1()));
      }

      if (jb.getR1c() != null){
          outlineList.add(createBookmarkEntry(jb.getR1c()));
      }

      if (jb.getR1d() != null){
          outlineList.add(createBookmarkEntry(jb.getR1d()));
      }

      if (jb.getMasterP1() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterP1()));
      }

      if (jb.getMasterP1m() != null){
          outlineList.add(createBookmarkEntry(jb.getMasterP1m()));
      }

      if (jb.getP1() != null){
          outlineList.add(createBookmarkEntry(jb.getP1()));
      }

      if (jb.getP1m() != null){
          outlineList.add(createBookmarkEntry(jb.getP1m()));
      }

      //doProcess returns false indicates that supplemental docs will positioned after exhibits
      if (jb.getSupplementalDocCollection() != null && doProcess(jb)){
          processSupplementalDocuments(jb.getSupplementalDocCollection(),outlineList, jb);
      }

      if (jb.getAcronymDoc() != null){
          outlineList.add(createBookmarkEntry(jb.getAcronymDoc()));
      }
  }

  private void processSupplementalDocuments(JBSupplementalDocCollection supplementDocCollection, 
          List<HashMap<String, Object>> outlineList, JustificationBook jb) {
      log.trace("processSupplementalDocuments: - start - determining positioning of supplemental docs");
      
      List<HashMap<String, Object>> suppOutlineList = new ArrayList<HashMap<String, Object>>();
      
      for (JBSupplementalDoc suppDoc : jb.getSupplementalDocCollection().getSupplementalDocList()) {
          log.trace("processSupplementalDocuments: suppDoc: " + suppDoc.getTitle());
          suppOutlineList.add(createBookmarkEntry(suppDoc));
      }
      
      jb.getSupplementalDocCollection().setPdfAbsoluteStartPage(jb.getSupplementalDocCollection().getSupplementalDocList().get(0).getPdfAbsoluteStartPage());
      outlineList.add(createBookmarkEntry(jb.getSupplementalDocCollection(), suppOutlineList));
  }
  
  private boolean doProcess(JustificationBook jb){
      log.trace("doProcess(): - start - determining positioning of supplemental docs"); 
      boolean rValue = true;
      
      if (jb.getDocAssemblyOptions().isPositionAttachmentsAfterExhibits()){
          rValue = false;
          postSupplementalDocuments = true;
      }
      
      log.trace(String.format("doProcess(): rValue: %s postSupplementalDocuments: %s", rValue, postSupplementalDocuments)); 
      return rValue;
  }

}
