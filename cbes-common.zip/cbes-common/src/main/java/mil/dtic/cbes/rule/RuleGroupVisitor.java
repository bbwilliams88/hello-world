package mil.dtic.cbes.rule;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.rule.ExhibitPath.ExhibitSet;
import mil.dtic.utility.CbesLogFactory;

/**
 * Visits one or more rule groups in a tree, executing rules from
 * a rule repository. Manages an exhibit path as rule groups are
 * visited.
 *
 * Visitors are meant to be used once. Rule violations are collected
 * as rule groups are visited.
 *
 * Tracks which rules executed during a visit.
 *
 *
 * @author AZumkhaw
 *
 */
public class RuleGroupVisitor {
  private static final Logger log = CbesLogFactory.getLog(RuleGroupVisitor.class);

  private RuleRepository repository = new RuleRepository();
  private RuleViolationList violations = new RuleViolationList();
  private ExhibitPath path = new ExhibitPath();
  private Set<String> executedRules = new TreeSet<String>();

  public RuleGroupVisitor(RuleRepository repository) {
    this.repository = repository;
  }

  /**
   * Runs methods in a rule group that are present in the visitor's
   * rule repository.
   *
   * @param group
   * @param organizationCode The abbreviated Service/Agency name, such as SOCOM or DARPA.
   */
  public void visit(RuleGroup group, String organizationCode) {
    if (group.getClass().isAnnotationPresent(RuleGroupName.class)) {
      RuleGroupName annotation = group.getClass().getAnnotation(RuleGroupName.class);
      String ruleGroupName = annotation.value();
      log.debug("Running Rule Group: "+ruleGroupName);

      boolean pathExtend = group.getClass().isAnnotationPresent(Location.class);
      if (pathExtend) {
        extendPath(group);
      }

      Set<Rule> rules = repository.rules(ruleGroupName);
      Map<String, Method> ruleAnnotatedMethods = getAnnotatedMethods(group);

      // run rules on this bucket
      runRules(rules, group, organizationCode, ruleAnnotatedMethods);

      // visit the buckets children
      group.accept(this, organizationCode);

      // only pop if the path was extended
      if (pathExtend) {
        path.pop();
      }
    } else {
      // visit the bucket
      group.accept(this, organizationCode);
    }
  }


  public RuleViolationList getRuleViolations() {
    return violations;
  }

  public boolean hasExecutedRule(String ruleNumber) {
    return executedRules.contains(ruleNumber);
  }

  public boolean hasViolations() {
    return !violations.isEmpty();
  }


    /**
     * Invoke rule bucket methods annotated with enabled validation rules.
     *
     * @param rules
     * @param bucket
     * @param organizationCode
     */
    private void runRules(Set<Rule> rules, RuleGroup bucket, String organizationCode, Map<String, Method> ruleAnnotatedMethods)
    {
        for (Rule rule : rules)
        {
            if (rule.isActive() && rule.isNotExempt(organizationCode))
            {
                String ruleNumber = rule.getRuleNumber();

                if (ruleAnnotatedMethods.containsKey(ruleNumber))
                {
                    path.subIndex();
                    violations.setViolationPath(path);
                    Method m = ruleAnnotatedMethods.get(ruleNumber);
                    try
                    {
                        m.invoke(bucket, rule, violations);
                        executedRules.add(ruleNumber);
                    }
                    catch (IllegalAccessException |IllegalArgumentException |  InvocationTargetException e)
                    {
                        violations.addSystemError(path, ruleNumber);
                        log.error("Exception thrown while executing rule '" + ruleNumber + "' at " + path.toString(), e);
                    }
                    path.clearSubIndex();
                }
            }
        }
    }

  /**
   * Find all methods on a bucket annotated with
   * @Rule
   *
   * @param bucket
   * @return
   */
  private Map<String, Method> getAnnotatedMethods(RuleGroup bucket) {
    HashMap<String, Method> annotated = new HashMap<String, Method>();
    for (Method m : bucket.getClass().getMethods()) {
      if (m.isAnnotationPresent(RuleNumber.class)) {
        RuleNumber annotation = m.getAnnotation(RuleNumber.class);
        String annotatedRuleNumber = annotation.value();
        annotated.put(annotatedRuleNumber, m);
      }
    }
    return annotated;
  }

  /**
   * Extend the exhibit path, if the rule bucket is annotated
   * with @Location
   *
   * @param bucket
   * @return
   */
  private void extendPath(RuleGroup bucket) {
    Location location = bucket.getClass().getAnnotation(Location.class);
    if (location.identify()) {
      String identifier = componentIdentifier(bucket);
      path.appendIdentified(location.component(), identifier, location.index() ? ExhibitSet.Index : ExhibitSet.NoIndex);
    } else {
      path.append(location.component(), location.index() ? ExhibitSet.Index : ExhibitSet.NoIndex);
    }

    if (location.key()) {
      path.generateExhibitKey();
    }
  }

  /**
   * Ask the validator for the exhibit path identifier,
   * for example, a program element's title.
   *
   * @param bucket
   * @return
   */
  private String componentIdentifier(RuleGroup bucket) {
    String identifier = "";
    Method m;
    try {
      m = bucket.getClass().getDeclaredMethod("identify");
      String pathIdentifier = (String) m.invoke(bucket);
      if (pathIdentifier != null) {
        identifier = pathIdentifier;
      }
    } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
      log.error("Rule group validator caught exception, ", e);
    }
    return identifier;
  }
}
