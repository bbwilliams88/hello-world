/*
 * $Id$
 */
package mil.dtic.cbes.service;

import mil.dtic.cbes.constants.Constants;

public class XmlFullValidationServiceFactory
{    
  public static XmlFullValidationService getFullValidator()
  {
   return new XmlFullValidationService(Constants.MJB_SCHEMA);
  }
  
  public static XmlFullValidationService get2010R2FullValidator()
  {
    XmlFullValidationService xfv = new XmlFullValidationService(Constants.R2_LEGACY_SCHEMA);
    return xfv;
  }
   
}
