package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ShipCategoryItemType implements ExtendedEnumeration
{
    P35("P35Item", "P35", "P-35 Major Equipment"), 
    MAJOR_ITEM("MajorItem", "MAJOR_ITEM", "Major Items"),
    COST_ELEMENT("CostElement", "COST_ELEMENT", "Other Cost Elements");

    private final String xmlName;
    private final String dbName;
    private final String description;

    private ShipCategoryItemType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static ShipCategoryItemType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ShipCategoryItemType.class, databaseValue);
    }

    public static ShipCategoryItemType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ShipCategoryItemType.class, enumValue);
    }
}
