package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

// FIXME: Rename to ItemExhibitCodeType at some point.
public enum ItemExhibitType implements ExtendedEnumeration
{
    MYP_14("MYP 1-4"), // Multiyear Procurement Analysis
    P1("P-1"),         // Procurement Program
    P1C("P-1C"),       // Procurement Program - Comparison Report
    P1M("P-1M"),       // Modification Summary
    P3A("P-3a"),       // Individual Modification Program
    P5("P-5"),         // Cost Analysis
    P5S("P-5s"),       // Ship Cost Analysis
    P5A("P-5a"),       // Procurement History and Planning
    P5B("P-5B"),       // Analysis of Cost Estimate-Basic/Escalation
    P8A("P-8A"),       // Analysis of Ship Cost Estimates - Major Equipment
    P10("P-10"),       // Advance Procurement Analysis
    P17("P-17"),       // Layaway and/or Distribution
    P18("P-18"),       // Initial, Outfitting, and Replenishment Spares Requirements
    P20("P-20"),       // Requirements Study
    P21("P-21"),       // Production Schedule
    P23A("P-23A"),     // Installations Data
    P25("P-25"),       // Production Support and Industrial Facilities Cost Analysis
    P26("P-26"),       // Maintenance of Inactive Facilities
    P27("P-27"),       // Ship Production Schedule
    P29("P-29"),       // Outfitting Costs
    P30("P-30"),       // Post Delivery Estimates
    P29P30("P-29/P-30"),// Combined P-29/P-30 Ships Outfitting and Delivery Exhibit
    P35("P-35"),       // Major Ship Component Fact Sheet
    P36("P-36"),       // Depot Level Ship Maintenance Schedule (OPN only)
    P40("P-40"),       // Budget Item Justification
    P40A("P-40a");     // Budget Item Just for Aggregated Items

    private final String databaseValue;

    private ItemExhibitType(String dbName)
    {
      this.databaseValue = dbName;
    }

    @Override
    public String getDatabaseValue()
    {
      return databaseValue;
    }
}
