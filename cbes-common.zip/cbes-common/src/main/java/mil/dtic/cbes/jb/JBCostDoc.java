package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBCostDoc extends JBDefaultUserSuppliedPart{
    
    public JBCostDoc() {
        setFileSetting(FileSetting.COST_OF_REPORT_DOC); 
        setTitle(fileSetting.getTitle());    
        setFixedTitle(true); 
    }
}
