package mil.dtic.cbes.p40.vo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.PersistenceState;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._ServiceAgency;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.utility.CbesLogFactory;

/**
 * Reference data for DoD Services and Agencies.
 */
public class ServiceAgency extends _ServiceAgency implements Equivalence<ServiceAgency>
{
    private static final Logger log = CbesLogFactory.getLog(ServiceAgency.class);
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public List<Appropriation> getActiveProcurementAppropriationList()
    {
        Expression exp1       = ExpressionFactory.matchExp(Appropriation.STATUS_PROPERTY, StatusType.ACTIVE);
        Expression exp2       = ExpressionFactory.matchExp(makePath(Appropriation.BUDGET_ACTIVITY_LIST_RELATIONSHIP_PROPERTY, BudgetActivity.PROCUREMENT_PROPERTY), true);
        Expression expression = exp1.andExp(exp2);

        return expression.filterObjects(super.getAppropriationList());
    }
    
    
    public List<Appropriation> getAllAppropriationsList(){
        return super.getAppropriationList();
    }

    /**
     * @return true if a DoD Service, false if a DoD Agency.
     */
    public boolean isService()
    {
      if (getServiceComponents().isEmpty())
        return false;
      else
        return true;
      // These were WRONG:
      // if (StringUtils.equals("A", getCode()))
      // return true;
      // if (StringUtils.equals("AF", getCode()))
      // return true;
      // if (StringUtils.equals("N", getCode()))
      // return true;
      // if (StringUtils.equals("PROCDEMO", getCode()))
      // return true;
      //
      // return false;
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    public static ServiceAgency fetchWithName(ObjectContext context, String name)
    {
        ServiceAgency organization = fetchOneCached(context, ServiceAgency.class, ServiceAgency.NAME_PROPERTY, name);

        if (organization == null)
            log.error("No ServiceAgency found in db for " + name);

        return organization;
    }

    public static List<ServiceAgency> fetchAll(ObjectContext context)
    {
        return Base.fetchAllForClass(context, ServiceAgency.class);
    }

    public static List<ServiceAgency> fetchAllOrderedByProperty(ObjectContext context, String property)
    {
        return Base.fetchAllWithClassForPropertyAndOrdering(context, ServiceAgency.class, property, SortOrder.ASCENDING);
    }

    public static List<ServiceAgency> fetchAllWithPreloadedApprBaBsa(ObjectContext context)
    {
        return fetchWithPreloadedApprBaBsa(context, null, false);
    }

    public static List<ServiceAgency> fetchAllProcurementAndSMCAWithPreloadedApprBaBsa(ObjectContext context)
    {
        return fetchWithPreloadedApprBaBsa(context, null, true);
    }

    public static ServiceAgency fetchWithCode(ObjectContext context, String value)
    {
      return Base.fetchOne(context, ServiceAgency.class, ServiceAgency.CODE_PROPERTY, value);
    }

    public static List<ServiceAgency> fetchWithCodes(DataContext context, List<String> codes){
      Expression exp = ExpressionFactory.inExp(CODE_PROPERTY, codes);
      return exp.filterObjects(fetchAllOrderedByProperty(context, ServiceAgency.NAME_PROPERTY));
    }

    public static List<ServiceAgency> fetchWithPreloadedApprBaBsa(ObjectContext context, List<ServiceAgency> onlyThese)
    {
        return fetchWithPreloadedApprBaBsa(context, onlyThese, false);
    }

    @SuppressWarnings("unchecked")
    public static List<ServiceAgency> fetchWithPreloadedApprBaBsa(ObjectContext context, List<ServiceAgency> onlyThese, boolean includeSMCA)
    {
        Set<String> agencyCodes = new HashSet<String>();

        if (onlyThese != null)
            for (ServiceAgency serviceAgency : onlyThese)
                agencyCodes.add(serviceAgency.getCode());

        // normally addPrefetch alone would be fine but
        // these objects dereference relationships in their
        // hashCode, which cayenne doesn't like
        preloadApprBaBsa(context);

        SelectQuery all = new SelectQuery(ServiceAgency.class);

        Expression appropriationExpression;

        if (includeSMCA)
            appropriationExpression =
                ExpressionFactory.noMatchExp(makePath(APPROPRIATION_LIST_RELATIONSHIP_PROPERTY + "+",
                                                      Appropriation.BUDGET_ACTIVITY_LIST_RELATIONSHIP_PROPERTY + "+"),
                                             null).orExp(ExpressionFactory.matchExp(SMCA_PROPERTY, true));
        else
            appropriationExpression =
                ExpressionFactory.matchExp(makePath(APPROPRIATION_LIST_RELATIONSHIP_PROPERTY,
                                                    Appropriation.BUDGET_ACTIVITY_LIST_RELATIONSHIP_PROPERTY,
                                                    BudgetActivity.PROCUREMENT_PROPERTY), true);

        all.andQualifier(appropriationExpression);

        if (agencyCodes.isEmpty() == false)
            all.andQualifier(ExpressionFactory.inExp(CODE_PROPERTY, agencyCodes));

        all.addPrefetch(ServiceAgency.APPROPRIATION_LIST_RELATIONSHIP_PROPERTY);
        all.addPrefetch("appropriationList.budgetActivityList"); // FIXME: Use makePath()?
        all.addPrefetch("appropriationList.budgetActivityList.budgetSubActivityList"); // FIXME: Use makePath()?
        all.addOrdering(new Ordering(ServiceAgency.CODE_PROPERTY, SortOrder.ASCENDING));

        Expression exp = ExpressionFactory.matchExp(ServiceAgency.STATUS_PROPERTY, StatusType.ACTIVE);

        return exp.filterObjects(context.performQuery(all));
    }

    public static List<ServiceAgency> fetchAllActiveAgencies(ObjectContext oc) {
      Expression exp = ExpressionFactory.matchExp(ServiceAgency.STATUS_PROPERTY, StatusType.ACTIVE);
      return exp.filterObjects(fetchAllOrderedByProperty(oc, ServiceAgency.NAME_PROPERTY));
    }

    private static void preloadApprBaBsa(ObjectContext context)
    {
        SelectQuery s1 = new SelectQuery(Appropriation.class);
        SelectQuery s2 = new SelectQuery(BudgetActivity.class);
        SelectQuery s3 = new SelectQuery(BudgetSubActivity.class);
        s1.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        s2.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        s3.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        context.performQuery(s1);
        context.performQuery(s2);
        context.performQuery(s3);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    @Override
    public int equivalenceHashCode()
    {
        if (getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(this.getName());
        builder.append(this.getCode());

        return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(ServiceAgency obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        ServiceAgency other = obj;

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(this.getName(), other.getName());
        builder.append(this.getCode(), other.getCode());

        return builder.isEquals();
    }

    @Override
    public boolean equals(Object object)
    {
        return equivalentTo((ServiceAgency)object);
    }
}
