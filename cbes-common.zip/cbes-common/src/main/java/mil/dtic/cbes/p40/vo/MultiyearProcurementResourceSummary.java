package mil.dtic.cbes.p40.vo;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class MultiyearProcurementResourceSummary
{
  private MultiyearCostType grossCost;
  private MultiyearCostType priorYearAdvanceProcurement;
  private MultiyearCostType netProcurement;
  private MultiyearCostType currentYearAdvanceProcurement;
  private MultiyearCostType weaponSystemCost;
  private MultiyearCostType quantity;


  /**
   * Get the 'GrossCost' element value.
   * 
   * @return value
   */
  public MultiyearCostType getGrossCost()
  {
    return grossCost;
  }


  /**
   * Set the 'GrossCost' element value.
   * 
   * @param grossCost
   */
  public void setGrossCost(MultiyearCostType grossCost)
  {
    this.grossCost = grossCost;
  }


  /**
   * Get the 'PriorYearAdvanceProcurement' element value.
   * 
   * @return value
   */
  public MultiyearCostType getPriorYearAdvanceProcurement()
  {
    return priorYearAdvanceProcurement;
  }


  /**
   * Set the 'PriorYearAdvanceProcurement' element value.
   * 
   * @param priorYearAdvanceProcurement
   */
  public void setPriorYearAdvanceProcurement(MultiyearCostType priorYearAdvanceProcurement)
  {
    this.priorYearAdvanceProcurement = priorYearAdvanceProcurement;
  }


  /**
   * Get the 'NetProcurement' element value.
   * 
   * @return value
   */
  public MultiyearCostType getNetProcurement()
  {
    return netProcurement;
  }


  /**
   * Set the 'NetProcurement' element value.
   * 
   * @param netProcurement
   */
  public void setNetProcurement(MultiyearCostType netProcurement)
  {
    this.netProcurement = netProcurement;
  }


  /**
   * Get the 'CurrentYearAdvanceProcurement' element value.
   * 
   * @return value
   */
  public MultiyearCostType getCurrentYearAdvanceProcurement()
  {
    return currentYearAdvanceProcurement;
  }


  /**
   * Set the 'CurrentYearAdvanceProcurement' element value.
   * 
   * @param currentYearAdvanceProcurement
   */
  public void setCurrentYearAdvanceProcurement(MultiyearCostType currentYearAdvanceProcurement)
  {
    this.currentYearAdvanceProcurement = currentYearAdvanceProcurement;
  }


  /**
   * Get the 'WeaponSystemCost' element value.
   * 
   * @return value
   */
  public MultiyearCostType getWeaponSystemCost()
  {
    return weaponSystemCost;
  }


  /**
   * Set the 'WeaponSystemCost' element value.
   * 
   * @param weaponSystemCost
   */
  public void setWeaponSystemCost(MultiyearCostType weaponSystemCost)
  {
    this.weaponSystemCost = weaponSystemCost;
  }


  /**
   * Get the 'Quantity' element value.
   * 
   * @return value
   */
  public MultiyearCostType getQuantity()
  {
    return quantity;
  }


  /**
   * Set the 'Quantity' element value.
   * 
   * @param quantity
   */
  public void setQuantity(MultiyearCostType quantity)
  {
    this.quantity = quantity;
  }
}
