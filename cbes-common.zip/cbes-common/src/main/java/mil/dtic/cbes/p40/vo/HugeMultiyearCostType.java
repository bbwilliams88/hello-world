package mil.dtic.cbes.p40.vo;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class HugeMultiyearCostType
{
  private DollarAmountType allPriorYears;
  private DollarAmountType priorYear;
  private DollarAmountType currentYear;
  private DollarAmountType budgetYearOne;
  private DollarAmountType budgetYearTwo;
  private DollarAmountType budgetYearThree;
  private DollarAmountType budgetYearFour;
  private DollarAmountType budgetYearFive;
  private DollarAmountType budgetYearSix;
  private DollarAmountType budgetYearSeven;
  private DollarAmountType budgetYearEight;
  private DollarAmountType budgetYearNine;
  private DollarAmountType budgetYearTen;
  private DollarAmountType budgetYearEleven;
  private DollarAmountType budgetYearTwelve;
  private DollarAmountType budgetYearThirteen;
  private DollarAmountType budgetYearFourteen;
  private DollarAmountType budgetYearFifteen;
  private DollarAmountType budgetYearSixteen;
  private DollarAmountType budgetYearSeventeen;
  private DollarAmountType budgetYearEighteen;
  private DollarAmountType budgetYearNineteen;
  private DollarAmountType budgetYearTwenty;
  private DollarAmountType budgetYearTwentyOne;
  private DollarAmountType budgetYearTwentyTwo;
  private DollarAmountType budgetYearTwentyThree;
  private DollarAmountType budgetYearTwentyFour;
  private DollarAmountType budgetYearTwentyFive;
  private DollarAmountType budgetYearTwentySix;
  private DollarAmountType budgetYearTwentySeven;
  private DollarAmountType budgetYearTwentyEight;
  private DollarAmountType budgetYearTwentyNine;
  private DollarAmountType budgetYearThirty;
  private DollarAmountType total;
  /**
   * @return the allPriorYears
   */
  public DollarAmountType getAllPriorYears()
  {
    return allPriorYears;
  }
  /**
   * @param allPriorYears the allPriorYears to set
   */
  public void setAllPriorYears(DollarAmountType allPriorYears)
  {
    this.allPriorYears = allPriorYears;
  }
  /**
   * @return the priorYear
   */
  public DollarAmountType getPriorYear()
  {
    return priorYear;
  }
  /**
   * @param priorYear the priorYear to set
   */
  public void setPriorYear(DollarAmountType priorYear)
  {
    this.priorYear = priorYear;
  }
  /**
   * @return the currentYear
   */
  public DollarAmountType getCurrentYear()
  {
    return currentYear;
  }
  /**
   * @param currentYear the currentYear to set
   */
  public void setCurrentYear(DollarAmountType currentYear)
  {
    this.currentYear = currentYear;
  }
  /**
   * @return the budgetYearOne
   */
  public DollarAmountType getBudgetYearOne()
  {
    return budgetYearOne;
  }
  /**
   * @param budgetYearOne the budgetYearOne to set
   */
  public void setBudgetYearOne(DollarAmountType budgetYearOne)
  {
    this.budgetYearOne = budgetYearOne;
  }
  /**
   * @return the budgetYearTwo
   */
  public DollarAmountType getBudgetYearTwo()
  {
    return budgetYearTwo;
  }
  /**
   * @param budgetYearTwo the budgetYearTwo to set
   */
  public void setBudgetYearTwo(DollarAmountType budgetYearTwo)
  {
    this.budgetYearTwo = budgetYearTwo;
  }
  /**
   * @return the budgetYearThree
   */
  public DollarAmountType getBudgetYearThree()
  {
    return budgetYearThree;
  }
  /**
   * @param budgetYearThree the budgetYearThree to set
   */
  public void setBudgetYearThree(DollarAmountType budgetYearThree)
  {
    this.budgetYearThree = budgetYearThree;
  }
  /**
   * @return the budgetYearFour
   */
  public DollarAmountType getBudgetYearFour()
  {
    return budgetYearFour;
  }
  /**
   * @param budgetYearFour the budgetYearFour to set
   */
  public void setBudgetYearFour(DollarAmountType budgetYearFour)
  {
    this.budgetYearFour = budgetYearFour;
  }
  /**
   * @return the budgetYearFive
   */
  public DollarAmountType getBudgetYearFive()
  {
    return budgetYearFive;
  }
  /**
   * @param budgetYearFive the budgetYearFive to set
   */
  public void setBudgetYearFive(DollarAmountType budgetYearFive)
  {
    this.budgetYearFive = budgetYearFive;
  }
  /**
   * @return the budgetYearSix
   */
  public DollarAmountType getBudgetYearSix()
  {
    return budgetYearSix;
  }
  /**
   * @param budgetYearSix the budgetYearSix to set
   */
  public void setBudgetYearSix(DollarAmountType budgetYearSix)
  {
    this.budgetYearSix = budgetYearSix;
  }
  /**
   * @return the budgetYearSeven
   */
  public DollarAmountType getBudgetYearSeven()
  {
    return budgetYearSeven;
  }
  /**
   * @param budgetYearSeven the budgetYearSeven to set
   */
  public void setBudgetYearSeven(DollarAmountType budgetYearSeven)
  {
    this.budgetYearSeven = budgetYearSeven;
  }
  /**
   * @return the budgetYearEight
   */
  public DollarAmountType getBudgetYearEight()
  {
    return budgetYearEight;
  }
  /**
   * @param budgetYearEight the budgetYearEight to set
   */
  public void setBudgetYearEight(DollarAmountType budgetYearEight)
  {
    this.budgetYearEight = budgetYearEight;
  }
  /**
   * @return the budgetYearNine
   */
  public DollarAmountType getBudgetYearNine()
  {
    return budgetYearNine;
  }
  /**
   * @param budgetYearNine the budgetYearNine to set
   */
  public void setBudgetYearNine(DollarAmountType budgetYearNine)
  {
    this.budgetYearNine = budgetYearNine;
  }
  /**
   * @return the budgetYearTen
   */
  public DollarAmountType getBudgetYearTen()
  {
    return budgetYearTen;
  }
  /**
   * @param budgetYearTen the budgetYearTen to set
   */
  public void setBudgetYearTen(DollarAmountType budgetYearTen)
  {
    this.budgetYearTen = budgetYearTen;
  }
  /**
   * @return the budgetYearEleven
   */
  public DollarAmountType getBudgetYearEleven()
  {
    return budgetYearEleven;
  }
  /**
   * @param budgetYearEleven the budgetYearEleven to set
   */
  public void setBudgetYearEleven(DollarAmountType budgetYearEleven)
  {
    this.budgetYearEleven = budgetYearEleven;
  }
  /**
   * @return the budgetYearTwelve
   */
  public DollarAmountType getBudgetYearTwelve()
  {
    return budgetYearTwelve;
  }
  /**
   * @param budgetYearTwelve the budgetYearTwelve to set
   */
  public void setBudgetYearTwelve(DollarAmountType budgetYearTwelve)
  {
    this.budgetYearTwelve = budgetYearTwelve;
  }
  /**
   * @return the budgetYearThirteen
   */
  public DollarAmountType getBudgetYearThirteen()
  {
    return budgetYearThirteen;
  }
  /**
   * @param budgetYearThirteen the budgetYearThirteen to set
   */
  public void setBudgetYearThirteen(DollarAmountType budgetYearThirteen)
  {
    this.budgetYearThirteen = budgetYearThirteen;
  }
  /**
   * @return the budgetYearFourteen
   */
  public DollarAmountType getBudgetYearFourteen()
  {
    return budgetYearFourteen;
  }
  /**
   * @param budgetYearFourteen the budgetYearFourteen to set
   */
  public void setBudgetYearFourteen(DollarAmountType budgetYearFourteen)
  {
    this.budgetYearFourteen = budgetYearFourteen;
  }
  /**
   * @return the budgetYearFifteen
   */
  public DollarAmountType getBudgetYearFifteen()
  {
    return budgetYearFifteen;
  }
  /**
   * @param budgetYearFifteen the budgetYearFifteen to set
   */
  public void setBudgetYearFifteen(DollarAmountType budgetYearFifteen)
  {
    this.budgetYearFifteen = budgetYearFifteen;
  }
  /**
   * @return the budgetYearSixteen
   */
  public DollarAmountType getBudgetYearSixteen()
  {
    return budgetYearSixteen;
  }
  /**
   * @param budgetYearSixteen the budgetYearSixteen to set
   */
  public void setBudgetYearSixteen(DollarAmountType budgetYearSixteen)
  {
    this.budgetYearSixteen = budgetYearSixteen;
  }
  /**
   * @return the budgetYearSeventeen
   */
  public DollarAmountType getBudgetYearSeventeen()
  {
    return budgetYearSeventeen;
  }
  /**
   * @param budgetYearSeventeen the budgetYearSeventeen to set
   */
  public void setBudgetYearSeventeen(DollarAmountType budgetYearSeventeen)
  {
    this.budgetYearSeventeen = budgetYearSeventeen;
  }
  /**
   * @return the budgetYearEighteen
   */
  public DollarAmountType getBudgetYearEighteen()
  {
    return budgetYearEighteen;
  }
  /**
   * @param budgetYearEighteen the budgetYearEighteen to set
   */
  public void setBudgetYearEighteen(DollarAmountType budgetYearEighteen)
  {
    this.budgetYearEighteen = budgetYearEighteen;
  }
  /**
   * @return the budgetYearNineteen
   */
  public DollarAmountType getBudgetYearNineteen()
  {
    return budgetYearNineteen;
  }
  /**
   * @param budgetYearNineteen the budgetYearNineteen to set
   */
  public void setBudgetYearNineteen(DollarAmountType budgetYearNineteen)
  {
    this.budgetYearNineteen = budgetYearNineteen;
  }
  /**
   * @return the budgetYearTwenty
   */
  public DollarAmountType getBudgetYearTwenty()
  {
    return budgetYearTwenty;
  }
  /**
   * @param budgetYearTwenty the budgetYearTwenty to set
   */
  public void setBudgetYearTwenty(DollarAmountType budgetYearTwenty)
  {
    this.budgetYearTwenty = budgetYearTwenty;
  }
  /**
   * @return the budgetYearTwentyOne
   */
  public DollarAmountType getBudgetYearTwentyOne()
  {
    return budgetYearTwentyOne;
  }
  /**
   * @param budgetYearTwentyOne the budgetYearTwentyOne to set
   */
  public void setBudgetYearTwentyOne(DollarAmountType budgetYearTwentyOne)
  {
    this.budgetYearTwentyOne = budgetYearTwentyOne;
  }
  /**
   * @return the budgetYearTwentyTwo
   */
  public DollarAmountType getBudgetYearTwentyTwo()
  {
    return budgetYearTwentyTwo;
  }
  /**
   * @param budgetYearTwentyTwo the budgetYearTwentyTwo to set
   */
  public void setBudgetYearTwentyTwo(DollarAmountType budgetYearTwentyTwo)
  {
    this.budgetYearTwentyTwo = budgetYearTwentyTwo;
  }
  /**
   * @return the budgetYearTwentyThree
   */
  public DollarAmountType getBudgetYearTwentyThree()
  {
    return budgetYearTwentyThree;
  }
  /**
   * @param budgetYearTwentyThree the budgetYearTwentyThree to set
   */
  public void setBudgetYearTwentyThree(DollarAmountType budgetYearTwentyThree)
  {
    this.budgetYearTwentyThree = budgetYearTwentyThree;
  }
  /**
   * @return the budgetYearTwentyFour
   */
  public DollarAmountType getBudgetYearTwentyFour()
  {
    return budgetYearTwentyFour;
  }
  /**
   * @param budgetYearTwentyFour the budgetYearTwentyFour to set
   */
  public void setBudgetYearTwentyFour(DollarAmountType budgetYearTwentyFour)
  {
    this.budgetYearTwentyFour = budgetYearTwentyFour;
  }
  /**
   * @return the budgetYearTwentyFive
   */
  public DollarAmountType getBudgetYearTwentyFive()
  {
    return budgetYearTwentyFive;
  }
  /**
   * @param budgetYearTwentyFive the budgetYearTwentyFive to set
   */
  public void setBudgetYearTwentyFive(DollarAmountType budgetYearTwentyFive)
  {
    this.budgetYearTwentyFive = budgetYearTwentyFive;
  }
  /**
   * @return the budgetYearTwentySix
   */
  public DollarAmountType getBudgetYearTwentySix()
  {
    return budgetYearTwentySix;
  }
  /**
   * @param budgetYearTwentySix the budgetYearTwentySix to set
   */
  public void setBudgetYearTwentySix(DollarAmountType budgetYearTwentySix)
  {
    this.budgetYearTwentySix = budgetYearTwentySix;
  }
  /**
   * @return the budgetYearTwentySeven
   */
  public DollarAmountType getBudgetYearTwentySeven()
  {
    return budgetYearTwentySeven;
  }
  /**
   * @param budgetYearTwentySeven the budgetYearTwentySeven to set
   */
  public void setBudgetYearTwentySeven(DollarAmountType budgetYearTwentySeven)
  {
    this.budgetYearTwentySeven = budgetYearTwentySeven;
  }
  /**
   * @return the budgetYearTwentyEight
   */
  public DollarAmountType getBudgetYearTwentyEight()
  {
    return budgetYearTwentyEight;
  }
  /**
   * @param budgetYearTwentyEight the budgetYearTwentyEight to set
   */
  public void setBudgetYearTwentyEight(DollarAmountType budgetYearTwentyEight)
  {
    this.budgetYearTwentyEight = budgetYearTwentyEight;
  }
  /**
   * @return the budgetYearTwentyNine
   */
  public DollarAmountType getBudgetYearTwentyNine()
  {
    return budgetYearTwentyNine;
  }
  /**
   * @param budgetYearTwentyNine the budgetYearTwentyNine to set
   */
  public void setBudgetYearTwentyNine(DollarAmountType budgetYearTwentyNine)
  {
    this.budgetYearTwentyNine = budgetYearTwentyNine;
  }
  /**
   * @return the budgetYearThirty
   */
  public DollarAmountType getBudgetYearThirty()
  {
    return budgetYearThirty;
  }
  /**
   * @param budgetYearThirty the budgetYearThirty to set
   */
  public void setBudgetYearThirty(DollarAmountType budgetYearThirty)
  {
    this.budgetYearThirty = budgetYearThirty;
  }
  /**
   * @return the total
   */
  public DollarAmountType getTotal()
  {
    return total;
  }
  /**
   * @param total the total to set
   */
  public void setTotal(DollarAmountType total)
  {
    this.total = total;
  }

}
