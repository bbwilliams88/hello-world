package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum FacilityCategoryType implements ExtendedEnumeration
{
  //Production Cost Elements
  Construction("Construction Cost"),
  Equipment("Equipment Cost"),
  EquipmentInstallCost("Equipment Installation Cost"),
  ContractorSupport("Contractor Support Cost"),
  CorpEngineersSupport("Corps of Engineers Support Cost"),
  OtherSupport("Other In-House Support Cost"),
  Total("Total Facility Project Cost"),
  Other("Other Costs"),
  //Production Milestones
  ConceptDesign("Concept Design Complete"),
  FinalDesign("Final Design Complete"),
  InitialAward("Initial Project Award"),
  FinalAward("Final Project Award"),
  ConstructionComplete("Construction Complete"),
  EquipmentInstallation("Equipment Installation"),
  ProveOutBegins("Prove Out Begins"),
  ProveOutComplete("Prove Out Complete"),
  //Inactive Funding
  MAINTENANCE,
  RECURRING,
  ENVIRONMENTAL,
  OTHER,
  ;

  private final String databaseValue;

  private FacilityCategoryType()
  {
    this.databaseValue = toString();
  }

  private FacilityCategoryType(String dbName)
  {
    this.databaseValue = dbName;
  }

  public String getDatabaseValue()
  {
    return databaseValue;
  }

  public static FacilityCategoryType fromDatabaseValue(String dbName)
  {
    for (FacilityCategoryType cat : FacilityCategoryType.values()) {
      if (cat.getDatabaseValue().equals(dbName)) {
        return cat;
      }
    }
    return null;
  }
}
