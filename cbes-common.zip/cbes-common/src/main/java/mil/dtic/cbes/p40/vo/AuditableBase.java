package mil.dtic.cbes.p40.vo;

import java.util.Date;

/**
 * Abstract class defining methods required for any Cayenne object which needs
 * to save auditing information into the database.
 */
public abstract class AuditableBase extends Base
{
    private static final long serialVersionUID = 1L;

    public abstract P40User getCreatedBy();
    public abstract void setCreatedBy(P40User user);

    public abstract Date getDateCreated();
    public abstract void setDateCreated(Date date);

    public abstract P40User getModifiedBy();
    public abstract void setModifiedBy(P40User user);

    public abstract Date getDateModified();
    public abstract void setDateModified(Date date);
}
