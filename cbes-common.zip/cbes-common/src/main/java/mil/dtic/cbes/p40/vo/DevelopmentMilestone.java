package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.p40.vo.auto._DevelopmentMilestone;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

/**
 *
 */
public class DevelopmentMilestone extends _DevelopmentMilestone implements HasDisplayOrder, Equivalence<DevelopmentMilestone>
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        if (this.getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();
        if(getDate() !=null)
          builder.append(getDate().toString());
        builder.append(toLowerAndTrim(getTitle()));
        builder.append(getParentLineItem());

        return builder.toHashCode();
    }

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(DevelopmentMilestone obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        DevelopmentMilestone other   = obj;
        EqualsBuilder        builder = new EqualsBuilder();

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        builder.append(getDate(), other.getDate());
        builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
        builder.append(getParentLineItem(), other.getParentLineItem());

        return builder.isEquals();
    }
    
    /***********************************************************************/
    /*** JiBX Support ***/
    /***********************************************************************/

    public boolean jibx_hasDate() {
        if(getDate() != null)
         return true;
        return false;
      }
}
