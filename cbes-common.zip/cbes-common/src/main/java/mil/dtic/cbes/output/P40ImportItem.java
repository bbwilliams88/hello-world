/*
 * $Id: P40ImportItem.java 31657 2009-05-18 18:56:43Z bhicks $
 */
package mil.dtic.cbes.output;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import mil.dtic.cbes.p40.vo.LineItem;

public class P40ImportItem
{
  protected LineItem lineItem;
  protected int xmlIndex;
  protected List<String> errorList;
  protected List<String> warningList;
  protected boolean importable;

  public P40ImportItem(LineItem lineItem, int xmlIndex, List<String> errorList, List<String> warningList)
  {
    this.lineItem = lineItem;
    this.xmlIndex = xmlIndex;
    this.errorList = errorList == null ? new ArrayList<String>() : errorList;
    this.warningList = warningList == null ? new ArrayList<String>() : warningList;
  }


  public boolean isDoImport()
  {
    return CollectionUtils.isEmpty(errorList);
  }


  public boolean isImportSuccessful()
  {
    return lineItem.getId() != null && CollectionUtils.isEmpty(errorList);
  }


  public LineItem getLineItem()
  {
    return lineItem;
  }


  public void setLineItem(LineItem lineItem)
  {
    this.lineItem = lineItem;
  }


  public int getXmlIndex()
  {
    return xmlIndex;
  }


  public void setXmlIndex(int xmlIndex)
  {
    this.xmlIndex = xmlIndex;
  }


  public List<String> getErrorList()
  {
    return errorList;
  }


  public void setErrorList(List<String> errorList)
  {
    this.errorList = errorList;
  }


  public List<String> getWarningList()
  {
    return warningList;
  }


  public void setWarningList(List<String> warningList)
  {
    this.warningList = warningList;
  }


  public boolean isImportable()
  {
    return importable;
  }


  public void setImportable(boolean importable)
  {
    this.importable = importable;
  }
  
  public boolean hasWarnings()
  {
    return !this.warningList.isEmpty() ;
  }

}