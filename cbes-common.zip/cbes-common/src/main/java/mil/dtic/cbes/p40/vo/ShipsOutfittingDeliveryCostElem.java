package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ShipsOutfittingDeliveryCostType;
import mil.dtic.cbes.p40.vo.auto._ShipsOutfittingDeliveryCostElem;

/**
 *
 */
public class ShipsOutfittingDeliveryCostElem extends _ShipsOutfittingDeliveryCostElem
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public void jibx_setDeliveryCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setDeliveryCosts(costs);
      }
    }
    
    public void jibx_setOutfittingCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setOutfittingCosts(costs);
      }
    }
    
    public boolean jibx_hasDeliveryCosts()
    {
      return getDeliveryCosts() != null;
    }
    
    public boolean jibx_hasOutfittingCosts()
    {
      return getOutfittingCosts() != null;
    }
    
    public boolean jibx_hasContract()
    {
      return getContract() != null;
    }
    
    public boolean jibx_hasHullNumber()
    {
      return getHullNumber() != null;
    }
    
    public boolean jibx_hasProgramYear()
    {
      return getProgramYear() != null;
    }
    
    public void jibx_setShip()
    {
      setElementType(ShipsOutfittingDeliveryCostType.SHIP_CLASS);
    }
    
    public void jibx_setDestination()
    {
      setElementType(ShipsOutfittingDeliveryCostType.FIRST_DESTINATION);
    }
    
    public void jibx_setPubs()
    {
      setElementType(ShipsOutfittingDeliveryCostType.PUBS);
    }
    
    public boolean jibx_hasShipType()
    {
      return getElementType() == ShipsOutfittingDeliveryCostType.SHIP_CLASS;
    }
    
    public boolean jibx_hasDestinationType()
    {
      return getElementType() == ShipsOutfittingDeliveryCostType.FIRST_DESTINATION;
    }
    
    public boolean jibx_hasPubsType()
    {
      return getElementType() == ShipsOutfittingDeliveryCostType.PUBS;
    }
    
    
    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
