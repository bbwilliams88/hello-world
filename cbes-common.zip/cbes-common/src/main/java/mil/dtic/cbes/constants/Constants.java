package mil.dtic.cbes.constants;

import java.math.BigDecimal;
import java.util.Calendar;

import com.itextpdf.text.pdf.PdfWriter;

import mil.dtic.cbes.data.config.BudgetTypeFlag;

/*******************************************************************************
 * Constant values used throughout the application.
 ******************************************************************************/

public final class Constants
{
  public static final String[] BUDGET_CYCLE_BES_PBR_POM = {"BES", "PBR", "POM"};
  public static final String BUDGET_CYCLE_BES ="BES";
  public static final String BUDGET_CYCLE_PB ="PB";
  public static final String BUDGET_CYCLE_POM ="POM";
  public static final String BUDGET_CYCLE_PBR = "PBR";
  public static final String BUDGET_CYCLE_PB_AMENDED = "PBAmended";
  public static final String BUDGET_CYCLE_PB_SUPPLEMENTAL = "PBSupplemental";

  public static final String INITIAL_SUBMISSION_CYCLE = BUDGET_CYCLE_BES;
  public static final int INITIAL_SUBMISSION_MONTH = Calendar.SEPTEMBER;
  public static final int INITIAL_SUBMISSION_YEAR_OFFSET = 2;

  public static final String FINAL_SUBMISSION_CYCLE = BUDGET_CYCLE_PB;
  public static final int FINAL_SUBMISSION_MONTH = Calendar.FEBRUARY;
  public static final int FINAL_SUBMISSION_YEAR_OFFSET = 1;

  public static final Short[] VALID_R3_to_R5_BA_NUMS = {3, 4, 5, 7, 8};
  public static final Short[] VALID_ARTICLES_BA_NUMS = {3, 4, 5, 7, 8};

  public static final BudgetTypeFlag DEFAULT_BUDGET_CYCLE_TYPE = BudgetTypeFlag.BASE;

  public static final String R2_DOCTYPE = "R2";
  public static final String R2A_DOCTYPE = "R2a";

  public final static int TOTAL_COLS_EVEN_BUDGET_YEAR = 16;
  public final static int FUNDING_COLS_EVEN_BUDGET_YEAR = 13;

  public final static String R2_LEGACY_SCHEMA = "dticr2.xsd";
  public final static String MJB_ROOT_LOCAL_NAME = "MasterJustificationBook";
  public final static String JB_ROOT_LOCAL_NAME = "JustificationBook";
  public final static String R2_ROOT_LOCAL_NAME = "ProgramElementList";
  public final static String R2_ROOT_LOCAL_NAME_LEGACY = "R2ExhibitList";
  public final static String P40_ROOT_LOCAL_NAME = "LineItemList";
  public final static String MJB_SCHEMA = "dticmjb.xsd";
  //public final static String JB_SCHEMA = "dticjb.xsd";

  public final static String R2_RULES_VALIDATION_XSLT_NAME = "dticr2_schematron_rules_validator.xsl";
  public final static String JB_RULES_VALIDATION_XSLT_NAME = "dticr2_schematron_rules_validator.xsl";
  public final static String XML_2010_TO_XML_2011_CONVERTER_XSLT_NAME = "migrate2010xmlto2011xml.xslt";
  public final static String P40_XML_2013_TO_XML_2014_CONVERTER_XSLT_NAME = "migrate-xml-PB2013-to-PB2014.xslt";
  public final static String P40_XML_2015_TO_XML_2016_CONVERTER_XSLT_NAME = "migrate-xml-PB2015-to-BES2016.xsl";

  public static final String RESPONSE_CHARSET = ";charset=UTF-8";
  public static final String CBES_PDF_AUTHOR = "Comptroller XML Exhibits System";

  // FIXME: Perhaps this should be an enum?
  public static final String SUBMITTED = "S";
  public static final String PE_STATUS_SAVED = "A";

  public static final String DATE_FORMAT = "MMM dd, yyyy";
  public static final String HEADER_DATETIME_FORMAT = "EEEEE, MMMMM dd, yyyy hh:mm:ss a z";
  public static final String DATETIME_FORMAT = "MMM dd, yyyy HH:mm z";
  public static final String SUBMISSION_DATE_FORMAT = "MMMM yyyy";
  public static final String MP_DATE_FORMAT = "MM/yyyy";
  public static final String AWARD_DATE_FORMAT = "MM/yyyy";
  public static final String MONTHYEAR_FORMAT = "MMM yyyy";
  public static final String XML_MONTH_DATE_FORMAT = "yyyy-MM";

  public static final String FUNDING_VALUE_FORMATTER = "#,##0.000";

  public static final String ALL_PRIOR_YEARS = "All Prior Years";
  public static final String PRIOR_YEAR = "PY";
  public static final String CURRENT_YEAR = "CY";
  public static final String BUDGET_YEAR = "BY";
  public static final String BUDGET_YEAR1 = "BY1";
  public static final String BUDGET_YEAR1_BASE = "BY1BASE";
  public static final String BUDGET_YEAR1_OOC = "BY1OOC";
  public static final String BUDGET_YEAR2 = "BY2";
  public static final String BUDGET_YEAR3 = "BY3";
  public static final String BUDGET_YEAR4 = "BY4";
  public static final String BUDGET_YEAR5 = "BY5";
  public static final String COST_TO_COMPLETE = "COST_COMP";
  public static final String TOTAL_COST = "TOTAL_COST";


  public static final String CCG_LOC = "#CCG";
  public static final String FUNDING_LOC = "#FUND";
  public static final String APP_LOC = "#APP";
  public static final String MP_LOC = "#MP";
  public static final String PROJ_LOC = "#PROJ";
  public static final String OTHADJ_LOC = "#OTHADJ";
  public static final String CONGINCR_LOC = "#CONGINCR";
  public static final String CONGADD_LOC = "#CONGADD";
  public static final String REPROG_LOC = "#REPROG";
  public static final String JOINTFUNDING_LOC = "#JOINTFUND";

  public static final String CONTINUING = "Continuing";
  public static final String COMP_COST_DEFAULT = CONTINUING;
  public static final String TOTAL_COST_DEFAULT = CONTINUING;

  public static final boolean SORT_CONTENTS_FOR_PDF_CREATE = false;
  public static final boolean SORT_CONTENTS_FOR_PDF_PREVIEW = false;
  public static final boolean SORT_CONTENTS_FOR_PDF_DOWNLOAD = true;

  public static final String SESSKEY_DOWNLOADABLE_OBJECT = "mil.dtic.cbes.downloadableObject";
  public static final String APPKEY_ALL_SESSIONS = "mil.dtic.cbes.allHttpSessions";
  public static final String APPKEY_LOCKOUT_NON_ADMIN_USERS = "mil.dtic.cbes.lockOutNonAdminUsers";

  public static final String COLOR_WHITE = "#FFFFFF";
  public static final String COLOR_LIGHT_GRAY = "#E9E9E9";
  public static final String COLOR_ROW_HIGHLIGHT = "#FFFFCC";

  public static final String COLOR_WHITE_STYLE = "whiteBackground";
  public static final String COLOR_LIGHT_GRAY_STYLE = "lightgrayBackground";
  public static final String COLOR_ROW_HIGHLIGHT_STYLE = "highlightBackground";

  public static final String R2_SCHEMA_PACKAGE_ZIP_FILE_NAME = "ComptrollerXMLExhibits-xmlpackage.zip";
  public static final String DOC_PACKAGE_LINK_TEXT = "Download Comptroller XML Exhibits Documentation";
  public static final String R2_TRAINING_PACKAGE_ZIP_FILE_NAME = "r2trainingpackage.zip";
  public static final String R2_IMAGE_INSTRUCTIONS_ZIP_FILE_NAME = "r2exportimageinstructions.zip";

  public static final int TMP_BUFFER_SIZE = 32 * 1024;

  public static final String REQ_ATTRIB_IGNORE_RENDER = "ignoreRender";

  public static final String DB_COL_DATE_MODIFIED = "dateModified";
  public static final String DB_SORT_ASC = "asc";
  public static final String DB_SORT_DESC = "desc";

  public static final String HTTP_HEADER_REMOTE_USER = "remote_user";

  public static final String SHOW_APPLICATION_STATE_URL_TRAILER = "showme.html";

  public static final String PAGE_DEFAULT_EXCEPTION = "Exception";

  public static final String RELEASE_DESCRIPTION_PREFIX = "Version";
  public static final int INVALID_PEID = -1;
  public static final int MIN_LENGTH_PENUM = 8;

  // The 0.000 may be important for precision elsewhere.  FIXME: Verify and if not, use BigDecimal.ZERO.
  public static final BigDecimal DEFAULT_FUNDING_VALUE = new BigDecimal("0.000");
  public static final BigDecimal ROUNDING_ACCOMMODATION = new BigDecimal("0.001");
  public static final BigDecimal FUNDING_THRESHOLD_FOR_CONTRACT_DATA = new BigDecimal("5000000.000"); //5 Million FIXME: change this to 10 Million and remove business rule once the Christmas Release is complete
  public static final BigDecimal INCREASED_FUNDING_THRESHOLD_FOR_CONTRACT_DATA = new BigDecimal("5000000.000"); // 10 Million (P-3a and P-21) changed in CXE-5967 
  public static final BigDecimal FUNDING_THRESHOLD_FOR_SUBEXHIBITS = new BigDecimal("5000000.000"); // 5 million (P-40a/P-5 cutoff) changed in CXE-5967 


  public static final int DEFAULT_ARTICLES_VALUE = 0;

  public static final Character PE_INITIAL_SOURCE_XML = Character.valueOf('X');
  public static final Character PE_INITIAL_SOURCE_WEB = Character.valueOf('W');

  public static final Character PE_STATE_ACTIVE = Character.valueOf('A');
  public static final Character PE_STATE_INACTIVE = Character.valueOf('I');

  public static final Character PE_EDITABLE_TRUE = Character.valueOf('T');
  public static final Character PE_EDITABLE_FALSE = Character.valueOf('F');

//  public static final Character LI_INITIAL_SOURCE_XML = new Character('X');
//  public static final Character LI_INITIAL_SOURCE_WEB = new Character('W');

  public static final Character LI_STATE_ACTIVE = Character.valueOf('A');
  public static final Character LI_STATE_INACTIVE = Character.valueOf('I');

  public static final Character LI_EDITABLE_TRUE = Character.valueOf('T');
  public static final Character LI_EDITABLE_FALSE = Character.valueOf('F');

  public static final String SORT_ORDER_DESC = "desc";
  public static final String SORT_ORDER_ASC = "asc";
  public static final String DEFAULT_SORT_ORDER = Constants.SORT_ORDER_DESC;

  public static final String YES = "Yes";
  public static final String NO = "No";

  public static final String JB_XML_VERSION = "1.0";
  public static final String R2_XML_VERSION = "1.0";
  public static final String XML_MONETARY_UNIT = "Millions";

  public static final String EMAIL_SIGNATURE = "\n\n------------\nR2 Team\nThis is an automatically generated email.\n------------";
  public static final String EMAIL_CURRENT_USER_EMAIL_KEY = "%CURRENT_USER_EMAIL%";

  public static final Integer UI_DISPLAY_ORDER_INIT_VALUE = Integer.valueOf(10);

  public static final int DEFAULT_STRING_TRUNCATION_LENGTH = 50;

  public static final String SYSPROP_ENV = "mil.dtic.env";
  public static final String SYSPROP_ENVLIST = "mil.dtic.envList";

  // FIXME: Rename and perhaps split into top-level enum.
  public static enum R2AInclusionCheck {RESPECT_R2A_INCLUSION_FLAG, IGNORE_R2A_INCLUSION_FLAG};

  public static final int MAX_ROMAN_NUMERAL_VALUE = 4000;

  public static final String APPLICATION_LOG_DIR = "/logs/r2";
  public static final String JBOSS_LOG_DIR = "/logs/jboss";
  public static final String JBOSS_WEBFILES = "/d2/webfiles/r2";
  public static final String RELEASE_DIR = "/release/R2/dev";
  public static final String APPSERVER_DIR = "/src";

  // FIXME: Rename and perhaps split into top-level enums.
  public static enum JBLogoImageFileType {JPG, BMP, GIF, PNG, TIF};
  public static enum JBPredefinedLogoSource {AUTO, DOD_GENERIC};
  public static enum JBPageNumbering {NONE, RESTART, CONTINUE};
  public static enum JBPageNumberingStyle {ARABIC_NUMERALS, ROMAN_NUMERALS};
  public static enum JBPageNumberingModel {SECTIONED, CONTINUOUS};

  public static final int KILOBYTE = 1024;
  public static final int MEGABYTE = KILOBYTE * 1024;
  public static final int GIGABYTE = MEGABYTE * 1024;


  // FIXME: Perhaps split into top-level enum.
  public static enum BudgesXmlType {R2, JB};

  public static final int MAX_UPLOADABLE_JB_ZIP_FILES_FOR_MJB_BUILD = 32;

  public static final String PDF_INACCURATE_DATA_WARNING_MESSAGE = "<THERE SHOULD BE A WARNING MESSAGE HERE!>";

  public static final String PDF_PRIVATE_NOTICE_MESSAGE_PB = "[DISTRIBUTION A: FOR PUBLIC RELEASE]";

  public static final String PDF_PRIVATE_NOTICE_MESSAGE_BES = "[NOT FOR PUBLIC RELEASE]";

  public static final float PDF_STAMPING_NORMAL_FONT_SIZE = 9f;

  public static final int PDF_READ_ONLY_PERMISSIONS = PdfWriter.ALLOW_COPY | PdfWriter.ALLOW_PRINTING | PdfWriter.ALLOW_SCREENREADERS;

  public static final int PDF_ALL_PERMISSIONS = 0;

  public static final String PDF_PROPS_TITLE_KEY = "Title";
  public static final String PDF_PROPS_AUTHOR_KEY = "Author";
  public static final String PDF_PROPS_SUBJECT_KEY = "Subject";
  public static final String PDF_PROPS_KEYWORDS_KEY = "Keywords";

  public static final String DEFAULT_SCHEDULE_PROFILE_TITLE = "N/A";

  public static final String PDF_OWNER_PWD = "@D7E9870b$784eBA5Ff#E87!B18";

  // FIXME: Rename to CamelCase and perhaps split into top-level enum.
  public static enum BUDGET_AREA {RDTE, PROCUREMENT, NOEXHIBITS};

  public static final String UC_KEY = "user.credentials";
  public static final String P40_UC_KEY = "p40user.credentials";
  public static final String ALLOWEDPAGES_KEY = "mil.dtic.cbes.allowedpages";
  public static final String JBBUTTON_KEY = "mil.dtic.cbes.showJbWizardButton";
  public static final int SECONDS_IN_MINUTE = 60;
  public static final int SECONDS_IN_HOUR = 3600;
  public static final int SECONDS_IN_DAY = 24 * SECONDS_IN_HOUR;

  // XML Resource can be loaded from one of these locations
  // FIXME: Rename to CamelCase and perhaps split into top-level enum.
  public static enum XML_RESOURCES_SOURCE {CLASSPATH, FILESYSTEM, DATABASE};

  // Identifies the name of the app (r2, p40, restapp, jobmanager, etc)
  public static final String SYSKEY_APP_NAME = "mil.dtic.cbes.appName";

  // List of all app names for the project
  public static final String SYSKEY_APP_NAME_LIST = "mil.dtic.cbes.appNameList";
  public static final String DEFAULT_APP_NAME_LIST = "r2,p40,restapp,jobmanager";

  // Multiple instances of the same app can be deployed on the same or multiple servers, this identifies the name of each instance
  public static final String SYSKEY_APP_INSTANCE_NAME = "mil.dtic.cbes.appInstanceId";

  // Container name
  public static final String SYSKEY_CONTAINER_NAME = "mil.dtic.cbes.containerName";

  // FIXME: Rename to CamelCase and perhaps split into top-level enum.
  public static enum ENVIRONMENT_TYPE {LOCAL, DEV, STAGING, PROD};

  public static final int DIFFERENCE_FOR_PRIOR_YEAR_EIGHT = 9;

  public static final String TITLES_UNDEFINED = "Title(s) undefined";
  public static final String WEB_SERVICE_NULL_VALUE = "null,";
  public static final String BLANK_TITLE = " ";

  // construction not allowed
  private Constants()
  {
  }
}

