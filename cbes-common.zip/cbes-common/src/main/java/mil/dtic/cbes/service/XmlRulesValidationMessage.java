/*
 * $Id$
 */
package mil.dtic.cbes.service;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.comptroller.xml.schema.dticFunctions.R2ErrorDocument.R2Error;
import mil.dtic.utility.Util;

public class XmlRulesValidationMessage extends ValidationMessageImpl
{
  protected R2Error error;
  protected String programElementNumber;
  protected int programElementIndex;
  protected String projectNumber;
  protected int projectIndex;
  protected String r2aExhibitProjectNumber;
  protected int r2aExhibitIndex;
  protected String r2aProjectNumber;
  protected int r2aProjectIndex;


  public XmlRulesValidationMessage(String message, int lineNum, int colNum)
  {
    super(message, null, lineNum, colNum);
    init();
  }

  public XmlRulesValidationMessage(String programElementNumber, int programElementIndex, String message)
  {
    this(message, NO_VALUE, NO_VALUE);
    this.programElementNumber = programElementNumber;
    this.programElementIndex = programElementIndex;
  }

  public XmlRulesValidationMessage(String programElementNumber, int programElementIndex, int lineNum, int colNum, String message)
  {
    this(message, lineNum, colNum);
    this.programElementNumber = programElementNumber;
    this.programElementIndex = programElementIndex;
  }


  public XmlRulesValidationMessage(R2Error error)
  {
    init();
    this.error = error;
/*
    Context context = error.getContext();

    setMessage(error.getMessage());

    if (error.getSeverity() != null)
      setSeverity(error.getSeverity().getCode());

    if (context != null)
    {
      if (context.getLineNumber() != null)
        super.setLineNum(context.getLineNumber().intValue());

      if (!Util.isEmpty(context.getProgramElementNumber()))
      {
        programElementNumber = context.getProgramElementNumber();
        programElementIndex = context.getProgramElementIndex().intValue();
      }

      if (!Util.isEmpty(context.getProjectNumber()))
      {
        projectNumber = context.getProjectNumber();
        projectIndex = context.getProjectIndex().intValue();
      }

      if (!Util.isEmpty(context.getR2AExhibitProjectNumber()))
      {
        r2aExhibitProjectNumber = context.getR2AExhibitProjectNumber();
        r2aExhibitIndex = context.getR2AExhibitIndex().intValue();
      }

      if (!Util.isEmpty(context.getR2AProjectNumber()))
      {
        r2aProjectNumber = context.getR2AProjectNumber();
        r2aProjectIndex = context.getR2AProjectIndex().intValue();

      }

    }
*/
  }


  private void init()
  {
    programElementIndex = NO_VALUE;
    projectIndex = NO_VALUE;
    r2aExhibitIndex = NO_VALUE;
    r2aProjectIndex = NO_VALUE;
  }


  public String toWord(int num)
  {
    return(Util.formatIndex(num));
  }


  public String getProgramElementNumber()
  {
    return this.programElementNumber;
  }


  public void setProgramElementNumber(String programElementNumber)
  {
    this.programElementNumber = programElementNumber;
  }


  public int getProgramElementIndex()
  {
    return this.programElementIndex;
  }


  public void setProgramElementIndex(int programElementIndex)
  {
    this.programElementIndex = programElementIndex;
  }


  public String getProjectNumber()
  {
    return this.projectNumber;
  }


  public void setProjectNumber(String projectNumber)
  {
    this.projectNumber = projectNumber;
  }


  public int getProjectIndex()
  {
    return this.projectIndex;
  }


  public void setProjectIndex(int projectIndex)
  {
    this.projectIndex = projectIndex;
  }


  public String getR2aExhibitProjectNumber()
  {
    return this.r2aExhibitProjectNumber;
  }


  public void setR2aExhibitProjectNumber(String exhibitProjectNumber)
  {
    this.r2aExhibitProjectNumber = exhibitProjectNumber;
  }


  public int getR2aExhibitIndex()
  {
    return this.r2aExhibitIndex;
  }


  public void setR2aExhibitIndex(int exhibitIndex)
  {
    this.r2aExhibitIndex = exhibitIndex;
  }


  public String getR2aProjectNumber()
  {
    return this.r2aProjectNumber;
  }


  public void setR2aProjectNumber(String projectNumber)
  {
    this.r2aProjectNumber = projectNumber;
  }


  public int getR2aProjectIndex()
  {
    return this.r2aProjectIndex;
  }


  public void setR2aProjectIndex(int projectIndex)
  {
    this.r2aProjectIndex = projectIndex;
  }


  public R2Error getError()
  {
    return this.error;
  }


  @Override
  public String toString()
  {
    StringBuffer sb = new StringBuffer("[");
    if (StringUtils.isNotEmpty(getProgramElementNumber()))
    {
      sb.append(toWord(getProgramElementIndex()) + " Program Element ");
      sb.append("# \"" + getProgramElementNumber() + "\"");
    }

    if (StringUtils.isNotEmpty(getProjectNumber()))
    {
      if (sb.length() > 1)
        sb.append(" - ");
      sb.append(toWord(getProjectIndex()) + " Project ");
      sb.append("(Proj# " + getProjectNumber() + ")");
    }

    if (getR2aExhibitProjectNumber() != null)
    {
      if (sb.length() > 1)
        sb.append(" - ");
      sb.append(toWord(getR2aExhibitIndex()) + " R2aExhibit ");
      sb.append("(Proj# " + getR2aExhibitProjectNumber() + ")");
    }

    sb.append("] : ");

    sb.append(getMessage());

    return sb.toString();
  }

}
