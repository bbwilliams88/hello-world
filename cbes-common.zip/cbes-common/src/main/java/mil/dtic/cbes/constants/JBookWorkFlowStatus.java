package mil.dtic.cbes.constants;

import java.util.HashMap;
import java.util.Map;

public enum JBookWorkFlowStatus {
	DRAFT("DRAFT","Draft",0, 0, "", "jb.workFlowStatusDraftDisabled"),
	REVIEW("REVIEW", "Ready for Review", 1, 1, "Failed to process Ready for Review workflow. Warnings exist in the document.", "jb.workFlowStatusRFRDisabled"),
	PREPRCP("PREPRCP", "Pre-PRCP", 1,2, "Failed to process Pre-PRCP workflow. There must be PRCP warnings and only PRCP warning in the document to process as Pre-PRCP workflow.", "jb.workFlowStatusPrePRCPDisabled" ),
	FINAL("FINAL", "Final", 1,3, "Failed to process Final workflow. Warnings exist in document.", "jb.workFlowStatusFinalDisabled" ),
	ALL("ALL","All", 0, -2,"", null),  //used on UI page object.
	NONE("NONE", "None", 0, -1, "", null);
    //
    
    private static Map<Integer, JBookWorkFlowStatus> workFlowMap = new HashMap<Integer, JBookWorkFlowStatus>();
    
    static {
       for (JBookWorkFlowStatus jBookWorkflowStatus : JBookWorkFlowStatus.values()){
           workFlowMap.put(jBookWorkflowStatus.getType(), jBookWorkflowStatus);
       }
    }

    
	private JBookWorkFlowStatus(String code, String displayName, int process, int type, String failMsg, String configTableEntry){
		this.code = code;
		this.displayName = displayName;
		this.process = process;  
		this.type = type;
		this.failMsg = failMsg;
		this.configTableEntry = configTableEntry;
	}
	
	private final String code;
	private final String displayName;
	private final int process;
	private final int type;
	private final String failMsg;
	private final String configTableEntry;
	
	public String getCode(){
		return code;
	}
	
	public String getDisplayName(){
		return displayName;
	}

	public boolean getProcess(){
		if (process > 0){
			return true;
		}
		return false;
	}
	
	public int getType(){
	    return type;
	}
	
	public String getFailMsg(){
	    return failMsg;
	}
	
	public String getConfigTableEntry(){
	  return configTableEntry;
	}
	
	public static JBookWorkFlowStatus getByType(Integer type){
	    JBookWorkFlowStatus JBookWorkFlowStatus = workFlowMap.get(type);
	    return JBookWorkFlowStatus;
	}
	
	public static JBookWorkFlowStatus getByConfigTableEntry(String configTableEntry){
	  JBookWorkFlowStatus jBookWorkFlowStatus = null;
	  
	  for(JBookWorkFlowStatus j: values()){
	    if(j.getConfigTableEntry().equals(configTableEntry)){
	      jBookWorkFlowStatus = j;
	      break;
	    }
	  }
	  
	  return jBookWorkFlowStatus;
	}
	
	public static JBookWorkFlowStatus getByDisplayName(String displayName){
	  JBookWorkFlowStatus jBookWorkFlowStatus =  null;
	  
	  for(JBookWorkFlowStatus j: values()){
      if(j.displayName.equals(displayName)){
        jBookWorkFlowStatus = j;
        break;
      }
    }
    
	  return jBookWorkFlowStatus;
	}
	
	public static JBookWorkFlowStatus getByCode(String code) {
		 JBookWorkFlowStatus jBookWorkFlowStatus =  null;
		
		for(JBookWorkFlowStatus j : values()) {
			if(j.code.equals(code)) {
				jBookWorkFlowStatus = j;
	        	break;
			}
		}
		
		return jBookWorkFlowStatus;
	}

	@Override
	public String toString() {
		return displayName;
	}

	
}
