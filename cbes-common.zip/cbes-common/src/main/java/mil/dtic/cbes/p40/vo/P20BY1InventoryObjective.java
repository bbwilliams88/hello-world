package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.p40.vo.auto._P20BY1InventoryObjective;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class P20BY1InventoryObjective extends _P20BY1InventoryObjective implements HasDisplayOrder, Equivalence<P20BY1InventoryObjective>
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);
  }

  /**
   * HashCode based on Business Rule [E-XML-PROC#U150]
   */
  @Override
  public int equivalenceHashCode()
  {
    if (this.getPersistenceState() == PersistenceState.DELETED)
      return super.hashCode();
    HashCodeBuilder builder = new HashCodeBuilder();
    builder.append(toLowerAndTrim(getName()));
    builder.append(getRequirementsStudy());
    return builder.toHashCode();
  }


  /**
   * Equality based on Business Rule [E-XML-PROC#U150]
   */
  @Override
  public boolean equivalentTo(P20BY1InventoryObjective obj)
  {
    if (this == obj){
      return true;
    }
    if (obj == null){
      return false;
    }
    if (getClass() != obj.getClass()){
      return false;
    }
    P20BY1InventoryObjective other = obj;
    if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
      return super.equals(obj);
    EqualsBuilder builder = new EqualsBuilder();
    builder.append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName()));
    builder.append(getRequirementsStudy(), other.getRequirementsStudy());
    return builder.isEquals();
  }
}
