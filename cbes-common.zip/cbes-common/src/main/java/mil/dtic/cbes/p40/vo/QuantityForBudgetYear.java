package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._QuantityForBudgetYear;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

/**
 *
 */
public class QuantityForBudgetYear extends _QuantityForBudgetYear implements CostContainer, HasDisplayOrder
{
  private static final long serialVersionUID = 1L;


  /***********************************************************************/
  /*** Cayenne Callbacks ***/
  /***********************************************************************/

  protected void onPostAdd()
  {
    setDisplayOrder(0);

    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
  }


  /***********************************************************************/
  /*** Custom Accessors ***/
  /***********************************************************************/

  @Override
  public Costs getUnitCosts()
  {
    return null;
  }


  @Override
  public Costs getQuantities()
  {
    if(getQuantity() != null)
    {
      Costs quantities = getObjectContext().newObject(Costs.class);
      quantities.setType(CostRowType.QUANTITY);
      quantities.setBy1(getQuantity());
      return quantities;
    }
    else
      return null;
  }


  /***********************************************************************/
  /*** Business Logic ***/
  /***********************************************************************/

  @Override
  public void shiftForwardInTime(int years)
  {
    if (getCosts() != null)
      getCosts().shiftForwardInTime(years, false);
  }

  /***********************************************************************/
  /*** Utilities ***/
  /***********************************************************************/

  // Put utility-type methods here, which are typically static, such as
  // fetch* type methods, which fetch Cayenne objects from the database.

  /***********************************************************************/
  /*** JiBX Support ***/
  /***********************************************************************/

  // Put JiBX support methods here.

  public boolean jibx_hasCosts()
  {
    return getCosts() != null && !getCosts().isEmpty();
  }


  public boolean jibx_hasBudgetYearQuantity()
  {
    return getQuantity() != null;
  }


  public boolean jibx_hasBudgetYear()
  {
    return getBudgetYear() != null;
  }

  /***********************************************************************/
  /*** Validation Support ***/
  /***********************************************************************/

  // Put equivalenceHashCode and equivalentTo methods here, if the class
  // implements Equivalence.
}
