package mil.dtic.cbes.p40.vo;


/**
 *
 */
public interface HasTotalCostsAndQuantities extends HasTotalCosts, HasQuantities
{
}
