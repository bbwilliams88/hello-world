package mil.dtic.cbes.rule;

/**
 * Factories a rule group visitor.
 * 
 * @author AZumkhaw
 *
 */
public class RuleGroupVisitorFactory {
  
  /**
   * Create a visitor with all rules, excluding those disabled
   * via rule administration.
   * 
   * @return
   */
  static public RuleGroupVisitor makeVisitor() {
    RuleRepository repository = RuleRepositoryFactory.makeRepository();
    RuleGroupVisitor v = new RuleGroupVisitor(repository);
    return v;
  }
  
  /**
   * Create a visitor narrowed down to a specified set of rules.
   * All rule numbers provided must be defined in the rule repository.
   * For unit testing.
   * 
   * @param ruleNumbers
   * @return
   */
  static public RuleGroupVisitor makeVisitor(String... ruleNumbers) {
    RuleRepository repository = RuleRepositoryFactory.makeBaseRepository();
    RuleRepository narrowedRepository = repository.narrowTo(ruleNumbers);
    RuleGroupVisitor v = new RuleGroupVisitor(narrowedRepository);
    return v;
  }

}
