package mil.dtic.cbes.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.exceptions.InvalidFileTypeException;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.CBESFilenameUtils;

/**
 *
 */
public class UnzipService
{
  private static final Logger log = CbesLogFactory.getLog(UnzipService.class);

  protected List<BudgesFile> unzippedXmlFileList;
  protected List<BudgesFile> unzippedPdfFileList;
  protected Map<String, BudgesFile> unzipMap;
  protected List<ValidationMessage> errorList;
  protected File workingFolder;


  public UnzipService(File workingFolder) {
    this.workingFolder = workingFolder;
    unzippedXmlFileList = new ArrayList<BudgesFile>();
    unzippedPdfFileList = new ArrayList<BudgesFile>();
    unzipMap = new HashMap<String, BudgesFile>();
    errorList = new ArrayList<ValidationMessage>();
  }


  public boolean unzip(List<BudgesFile> filesToUnzip) {
    boolean success = true;
    if (filesToUnzip != null)
    {
      for (BudgesFile fileToUnzip : filesToUnzip)
        success &= unzip(fileToUnzip);
    } else {
      success = false;
    }
    return success;
  }

  public boolean unzip(BudgesFile fileToUnzip) {
    return unzip(fileToUnzip, 1);
  }

  public boolean unzipOriginalNames(BudgesFile budgesFile) {
    return unzip(budgesFile,1,true);
  }

  public boolean unzip(BudgesFile fileToUnzip, int zipFileIndex){
    return unzip(fileToUnzip,zipFileIndex, false);
  }


  /**
 * @param fileToUnzip
 * @param zipFileIndex
 * @param useOriginalName Even if true, files may not keep their original name after sanitization.
 * @throws InvalidFileTypeException if the filename does not match the whitelist.
 * @return
 */
  public boolean unzip(BudgesFile fileToUnzip, int zipFileIndex, final boolean useOriginalName)
  {
    boolean success = false;

    // Closing a ZipFile closes all InputStreams opened from the ZipFile.
    try (ZipFile zipFile = new ZipFile(fileToUnzip.getFile()))
    {
      log.debug("Unzipping file: " + fileToUnzip);

      // Collect ZipEntries into an Iterable list.
      List<ZipEntry> zipEntries = new ArrayList<>();
      CollectionUtils.addAll(zipEntries, zipFile.entries());

      int index = 1;
      for (ZipEntry zipEntry : zipEntries)
      {
        // Ignore metadata from Mac-created Zips or its contents will be treated as additional XML/image files.
        if (zipEntry.isDirectory()                     ||
            zipEntry.getName().startsWith("__MACOSX/") ||
            StringUtils.equals(CBESFilenameUtils.getName(zipEntry.getName()), ".DS_Store"))
        {
          log.debug("Ignoring zip entry " + zipEntry.getName());
        }
        else
        {
            // First check all ZipEntry names (file types) for suitability, ignoring directories.
            if (CBESFilenameUtils.isNotWhitelisted(zipEntry.getName(), BudgesContext.getConfigService().getWhitelist()))
                throw new InvalidFileTypeException("File '" + zipEntry.getName() + "' is not an allowed file type.");

          log.debug("Unzipping zip entry " + zipEntry.getName());

        String unzippedFileName;

          if (useOriginalName)
          {
              // Sanitize the filename, removing any directory information
              // and other potentially problematic characters that might
              // be in it.
              unzippedFileName = CBESFilenameUtils.sanitizeFileName(zipEntry.getName()).toLowerCase();

              if (StringUtils.equals(zipEntry.getName(), unzippedFileName) == false)
                  log.warn("  useOriginalName = true, but will use sanitized name instead: " + unzippedFileName);
          }
          else
          {
              unzippedFileName = FileUtil.createFileName(CBESFilenameUtils.getExtension(zipEntry.getName()).toLowerCase(), "unzippedFile", zipFileIndex, index++);
          }

          File unzippedFile = new File(workingFolder, unzippedFileName);

          FileUtil.writeFileContents(zipFile.getInputStream(zipEntry), unzippedFile);
          BudgesFile tmpBudgesFile = new BudgesFile(zipEntry.getName(), unzippedFile, fileToUnzip);

          // This key includes the zip archive's name
          String key = getUnzipMapKey(fileToUnzip.getFile().getName(), zipEntry.getName());
          unzipMap.put(key, tmpBudgesFile);

          // This key includes the file name alone to support discovery of R4 schedule images
          String secondKey = getUnzipMapKey(fileToUnzip.getFile().getName(), zipEntry.getName().substring(zipEntry.getName().indexOf('/')+1));
          unzipMap.put(secondKey, tmpBudgesFile);

          if (FileUtil.isXmlFile(zipEntry.getName()))
          {
            unzippedXmlFileList.add(tmpBudgesFile);
          }
          else if (FileUtil.isPdfFile(zipEntry.getName())){
            unzippedPdfFileList.add(tmpBudgesFile);
          }
          log.debug("Successfully unzipped " + tmpBudgesFile);
        }
      }
      if (unzipMap.size() == 0)
      {
        addError("Zip file contains no files.");
      }

      dumpUnzipMap();
      success = true;
    }
    catch (ZipException e)
    {
      log.error("Invalid zip file: " + fileToUnzip, e);
      addError("Invalid zip file: " + fileToUnzip);
    }
    catch (IOException e)
    {
      log.error("Could not unzip file: " + fileToUnzip, e);
      addError("Could not unzip file: " + fileToUnzip);
    }

    return success;
  }


  public boolean hasErrors() {
    return errorList.size() > 0;
  }


  private void dumpUnzipMap() {
    log.debug("Dumping unzip map...");
    if (unzipMap != null)
    {
      for (Map.Entry<String, BudgesFile> entry : unzipMap.entrySet())
        log.debug(entry.getKey() + "==>" + entry.getValue());
    }
  }


  public Collection<String> getAllUnzippedFiles() {
    return unzipMap.keySet();
  }


  public List<BudgesFile> getUnzippedXmlFileList() {
    return unzippedXmlFileList;
  }

  public List<BudgesFile> getUnzippedPdfFileList(){
    return unzippedPdfFileList;
  }


  public Map<String, BudgesFile> getUnzipMap2() {
    return unzipMap;
  }


  public List<ValidationMessage> getErrorList() {
    return errorList;
  }


  public File getWorkingFolder() {
    return workingFolder;
  }


  private void addError(String msg) {
    errorList.add(new ValidationMessageImpl(msg));
  }


  private String getUnzipMapKey(String zipFileName, String zipEntryFileName) {
    return (zipFileName + zipEntryFileName).toLowerCase();
  }


  public UnzipMap getUnzipMap(BudgesFile zipFile) {
    return new UnzipMap(zipFile, unzipMap);
  }

  public class UnzipMap
  {
    Map<String, BudgesFile> unzipMap;
    BudgesFile zipFile;


    public UnzipMap(BudgesFile zipFile, Map<String, BudgesFile> unzipMap) {
      this.unzipMap = unzipMap;
      this.zipFile = zipFile;
    }

    public BudgesFile get(String zipEntryFileName){
      String key = getUnzipMapKey(zipFile.getFile().getName(), zipEntryFileName);
      return unzipMap.get(key);
    }

    public Set<String> keySet() {
      return unzipMap.keySet();
    }
  }
}
