package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum DateAlternateOptionsType implements ExtendedEnumeration
{
    TBD     ("TBD",     "TBD",     "To be determined"),
    VARIOUS ("Various", "VARIOUS", "Various since several contracts represented");
    
    private final String xmlName;
    private final String dbName;
    private final String description;

    private DateAlternateOptionsType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static DateAlternateOptionsType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(DateAlternateOptionsType.class, databaseValue);
    }

    public static DateAlternateOptionsType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(DateAlternateOptionsType.class, enumValue);
    }
}
