package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;

public class R3Overview extends JBDefaultSystemGeneratedPart
{
  public R3Overview()
  {
    this(null);
  }
  
  public R3Overview(String titlePrefix)
  {
    setFileSetting(FileSetting.R3_OVERVIEW);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.R3_OVERVIEW.getTitle()));    
  }
  
}
