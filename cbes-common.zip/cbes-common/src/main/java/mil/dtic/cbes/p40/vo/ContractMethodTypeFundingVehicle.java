package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.logging.log4j.Logger;
import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.p40.vo.auto._ContractMethodTypeFundingVehicle;
import mil.dtic.utility.CbesLogFactory;

/**
 *
 */
public class ContractMethodTypeFundingVehicle extends _ContractMethodTypeFundingVehicle
{
    private static final Logger log = CbesLogFactory.getLog(ContractMethodTypeFundingVehicle.class);
    private static final long serialVersionUID = 1L;

    private P40ContractType jibxContractType;
    private P40ContractMethod jibxContractMethod;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return
     */
    public String getAllConcat()
    {
        // combine cm/ct/fv into one string
        P40ContractMethod cm = getContractMethod();
        P40ContractType ct = getContractType();
        P40FundingVehicle fv = getFundingVehicle();

        // this assumes that you either have both cm & ct, or fv by itself
        if (cm != null && ct != null)
        {
            String names = cm.getName() + "/" + ct.getName();
            // String descs = cm.getDesc() + "/" + ct.getDesc();
            return names;// + " - " + descs;
        }

        if (fv != null)
        {
            return fv.getName();// + " - " + fv.getDesc();
        }

        log.error("odd combo of cm/ct/fv, expecting either both cm & ct, or fv by itself");

        return "???";
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * Fetch all ContractMethodTypeFundingVehicle objects with all relationships
     * prefetched since they tend to be used right away.
     *
     * @param objectContext
     *            The ObjectContext to fetch all of the
     *            ContractMethodTypeFundingVehicle objects into.
     * @return All of the ContractMethodTypeFundingVehicle objects ordered by
     *         Contract Method, Contract Type, and Funding Vehicle.
     */
    @SuppressWarnings("unchecked")
    public static List<ContractMethodTypeFundingVehicle> fetchAll(ObjectContext objectContext)
    {
        SelectQuery query = new SelectQuery(ContractMethodTypeFundingVehicle.class);

        query.addPrefetch(CONTRACT_METHOD_RELATIONSHIP_PROPERTY);
        query.addPrefetch(CONTRACT_TYPE_RELATIONSHIP_PROPERTY);
        query.addPrefetch(FUNDING_VEHICLE_RELATIONSHIP_PROPERTY);

        List<ContractMethodTypeFundingVehicle> results = objectContext.performQuery(query);

        List<Ordering> orderings = new ArrayList<Ordering>();

        orderings.add(new Ordering(makePath(CONTRACT_METHOD_RELATIONSHIP_PROPERTY, P40ContractMethod.NAME_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));
        orderings.add(new Ordering(makePath(CONTRACT_TYPE_RELATIONSHIP_PROPERTY, P40ContractType.NAME_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));
        orderings.add(new Ordering(makePath(FUNDING_VEHICLE_RELATIONSHIP_PROPERTY, P40FundingVehicle.NAME_PROPERTY), SortOrder.ASCENDING_INSENSITIVE));

        Ordering.orderList(results, orderings);

        return results;
    }
    
    public P40ContractType getJibxContractType()
    {
        return getContractType();
    }

    public P40ContractType _getJibxContractType()
    {
      return jibxContractType;
    }

    public void setJibxContractType(P40ContractType jibxContractType)
    {
      this.jibxContractType = jibxContractType;
    }

    public P40ContractMethod getJibxContractMethod()
    {
        return getContractMethod();
    }

    public P40ContractMethod _getJibxContractMethod()
    {
      return jibxContractMethod;
    }

    public void setJibxContractMethod(P40ContractMethod jibxContractMethod)
    {
      this.jibxContractMethod = jibxContractMethod;
    }
}
