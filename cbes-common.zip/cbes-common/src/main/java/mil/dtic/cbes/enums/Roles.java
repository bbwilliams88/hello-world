package mil.dtic.cbes.enums;

public enum Roles {
        R2AppMgr("App Manager"),
        R2SiteAdmin("Site Admin"),
        R2LocalSiteAdmin("Local Site Admin"),
        R2User("User"),
        R2Analyst("Osd Analyst"),
        R2OmbAnalyst("Omb Examiner");

        private final String name;

        private Roles(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
 }

