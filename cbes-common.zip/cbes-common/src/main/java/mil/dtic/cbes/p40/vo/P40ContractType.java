package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P40ContractType;

public class P40ContractType extends _P40ContractType
{
    private static final long serialVersionUID = 1L;

    @Override
    public String toString()
    {
        return getName();
    }
}
