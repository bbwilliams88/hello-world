package mil.dtic.cbes.constants;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

/*
 * $Id$
 */
public enum BudgesContentType
{
  PDF("application/pdf", "pdf"),
  WORD("application/msword", "pdf"),
  EXCEL("application/vnd.ms-excel", "xls.xml"),
  ZIP("application/zip", "zip"),
  ZZZ("application/zip", "zzz"),
  XML("text/xml", "xml"),
  TEXT("text/plain", "txt"),
  GENERIC("application/octet-stream", ""),
  XLSX("application/vnd.ms-excel", "xls.xml");

  private String mimeType;
  private String fileExtension;
  private static final Logger log = CbesLogFactory.getLog(BudgesContentType.class);

  private BudgesContentType(String mimeType, String fileExtension)
  {
    this.mimeType = mimeType;
    this.fileExtension = fileExtension;
  }


  public String getMimeType()
  {
    return mimeType;
  }


  public void setMimeType(String mimeType)
  {
    this.mimeType = mimeType;
  }


  public String getFileExtension()
  {
    return fileExtension;
  }


  public void setFileExtension(String fileExtension)
  {
    this.fileExtension = fileExtension;
  }

  public static BudgesContentType getContentType(String fileName)
  {
    String ext = FilenameUtils.getExtension(fileName);
    try
    {
      return BudgesContentType.valueOf(ext.toUpperCase());
    } catch (IllegalArgumentException | NullPointerException e) {
      log.warn("Failed to get content type for filename ["+fileName+"]: " + e.getMessage(),e );
      return GENERIC;
    }
  }
}
