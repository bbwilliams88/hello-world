package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._ShipAnalysisOfCostEstimate;

/**
 *
 */
public class ShipAnalysisOfCostEstimate extends _ShipAnalysisOfCostEstimate
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasDesignSchedule()
    {
      return jibx_hasIssueDateForTLR()      ||
             jibx_hasIssueDateForTLS()      ||
             jibx_hasPreliminaryDesign()    ||
             jibx_hasContractDesign()       ||
             jibx_hasDetailDesign()         ||
             jibx_hasRequestForProposals()  ||
             jibx_hasDesignAgent();
    }
    
    public boolean jibx_hasIssueDateForTLR()
    {
      return getIssueDateForTLR() != null;
    }
    
    public boolean jibx_hasIssueDateForTLS()
    {
      return getIssueDateForTLS() != null;
    }
    
    public boolean jibx_hasPreliminaryDesign()
    {
      return getPreliminaryDesign() != null;
    }
    
    public boolean jibx_hasContractDesign()
    {
      return getContractDesign() != null;
    }
    
    public boolean jibx_hasDetailDesign()
    {
      return getDetailDesign() != null;
    }
    
    public boolean jibx_hasRequestForProposals()
    {
      return getRequestForProposals() != null;
    }
    
    public boolean jibx_hasDesignAgent()
    {
      return StringUtils.isNotEmpty(getDesignAgent());
    }
    
    public boolean jibx_hasClassification()
    {
      return StringUtils.isNotEmpty(getClassification());
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
