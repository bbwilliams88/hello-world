/*
 * $Id$
 */
package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;
import java.util.Set;

public class LdapUser implements Serializable {
	private static final long serialVersionUID = -5385260570009295800L;

	public static final String LDAP_USER_ID = "ldapUserId";
	public static final String EMAIL_ADDRESS = "emailAddress";

	protected String ldapUserId;
	protected Set<String> groupSet;
	protected String r2Role;
	protected String r2RoleDescription; // transient - doesn't come from LDAP
	protected String fullName;
	protected String firstName;
	protected String middleInitial;
	protected String lastName;
	protected String emailAddress;
	protected String phoneNumber;

	public String getLdapUserId() {
		return this.ldapUserId;
	}

	public void setLdapUserId(String ldapUserId) {
		this.ldapUserId = ldapUserId;
	}

	public Set<String> getGroupSet() {
		return this.groupSet;
	}

	public void setGroupSet(Set<String> groupSet) {
		this.groupSet = groupSet;
	}

	/** Role string for UI */
	public String getR2Role() {
		return r2Role;
	}

	public void setR2Role(String role) {
		r2Role = role;
	}

	public String getR2RoleDescription() {
		return r2RoleDescription;
	}

	public void setR2RoleDescription(String r2RoleDescription) {
		this.r2RoleDescription = r2RoleDescription;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleInitial() {
		return this.middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFullName() {
		return this.fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "LdapUser [ldapUserId=" + ldapUserId + ", groupSet=" + groupSet
				+ ", r2Role=" + r2Role + ", r2RoleDescription="
				+ r2RoleDescription + ", fullName=" + fullName + ", firstName="
				+ firstName + ", middleInitial=" + middleInitial
				+ ", lastName=" + lastName + ", emailAddress=" + emailAddress
				+ ", phoneNumber=" + phoneNumber + "]";
	}


}
