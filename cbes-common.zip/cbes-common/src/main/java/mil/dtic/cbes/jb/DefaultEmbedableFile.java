package mil.dtic.cbes.jb;

import java.io.File;

import org.apache.commons.lang3.ArrayUtils;

import mil.dtic.utility.FileUtil;

public class DefaultEmbedableFile implements EmbedableFile
{

  private String displayFileName;
  private String displayDescription;
  private String fileToEmbedAbsolutePath;
  private File fileToEmbed;
  private byte[] objectToEmbed;


  public DefaultEmbedableFile()
  {
  }


  public DefaultEmbedableFile(JBPart jbPart, String fileToEmbedAbsoluteFile)
  {
    this(jbPart, new File(fileToEmbedAbsoluteFile));
  }


  public DefaultEmbedableFile(JBPart jbPart, File fileToEmbed)
  {
    String displayFileName = FileUtil.createFileNameOfSameType(fileToEmbed.getName(), jbPart.getTitle());
    String displayDescription = jbPart.getFileSetting().getTitle();
    if (FileUtil.isZzzFile(fileToEmbed.getName()))
      displayDescription += " (save & rename to .zip to open)";
    setDisplayFileName(displayFileName);
    setDisplayDescription(displayDescription);
    setFileToEmbed(fileToEmbed);
  }


  public DefaultEmbedableFile(String displayFileName, String displayDescription, byte[] objectToEmbed)
  {
    super();
    this.displayFileName = displayFileName;
    this.displayDescription = displayDescription;
    this.objectToEmbed = ArrayUtils.clone(objectToEmbed);
  }


  public DefaultEmbedableFile(String displayFileName, String displayDescription, File fileToEmbed)
  {
    super();
    this.displayFileName = displayFileName;
    this.displayDescription = displayDescription;
    this.fileToEmbed = fileToEmbed;
  }


  public DefaultEmbedableFile(String displayFileName, String displayDescription, String fileToEmbedAbsolutePath)
  {
    super();
    this.displayFileName = displayFileName;
    this.displayDescription = displayDescription;
    this.fileToEmbedAbsolutePath = fileToEmbedAbsolutePath;
  }


  public String getFileLocation()
  {
    if (fileToEmbed != null)
      return fileToEmbed.getAbsolutePath();
    return fileToEmbedAbsolutePath;
  }


  public String getDisplayFileName()
  {
    return displayFileName;
  }


  public void setDisplayFileName(String displayFileName)
  {
    this.displayFileName = displayFileName;
  }


  public String getDisplayDescription()
  {
    return displayDescription;
  }


  public void setDisplayDescription(String displayDescription)
  {
    this.displayDescription = displayDescription;
  }


  public String getFileToEmbedAbsolutePath()
  {
    return fileToEmbedAbsolutePath;
  }


  public void setFileToEmbedAbsolutePath(String fileToEmbedAbsolutePath)
  {
    this.fileToEmbedAbsolutePath = fileToEmbedAbsolutePath;
  }


  public File getFileToEmbed()
  {
    return fileToEmbed;
  }


  public void setFileToEmbed(File fileToEmbed)
  {
    this.fileToEmbed = fileToEmbed;
  }


  public byte[] getObjectToEmbed()
  {
    return objectToEmbed;
  }


  public void setObjectToEmbed(byte[] objectToEmbed)
  {
    this.objectToEmbed = ArrayUtils.clone(objectToEmbed);
  }

}
