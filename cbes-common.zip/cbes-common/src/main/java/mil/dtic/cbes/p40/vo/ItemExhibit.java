package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.vo.auto._ItemExhibit;

/**
 *
 */
public class ItemExhibit extends _ItemExhibit
{
  private static final long serialVersionUID = 1L;


  public static ItemExhibit byCode(ObjectContext context, String code)
  {
    return fetchOneCached(context, ItemExhibit.class, ItemExhibit.CODE_PROPERTY, code);
  }

  public static ItemExhibit byCode(ObjectContext context, mil.dtic.cbes.enums.ItemExhibitType code)
  {
    return fetchOneCached(context, ItemExhibit.class, ItemExhibit.CODE_PROPERTY, code.getDatabaseValue());
  }
  public static List<String> getAllCodes(ObjectContext oc)
  {
    return Lists.newArrayList(Iterables.transform(fetchAllForClass(oc, ItemExhibit.class), new Function<ItemExhibit, String>(){

      @Override
      public String apply(ItemExhibit input)
      {
        return (input != null && input.getCode() != null)?input.getCode().toString(): null;
      }
    }));
  }
}
