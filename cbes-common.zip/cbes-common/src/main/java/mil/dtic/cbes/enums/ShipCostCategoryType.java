package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ShipCostCategoryType implements ExtendedEnumeration
{
    PLAN_COSTS("PlanCosts", "PLAN_COSTS", "Plan Costs"), 
    BASIC_CONSTRUCTION_CONVERSION("BasicConstructionConversion", "BASIC_CONSTRUCTION_CONVERSION", "Basic Construction and Conversion Costs"),
    CHANGE_ORDERS("ChangeOrders", "CHANGE_ORDERS", "Change Orders"),
    ELECTRONICS("Electronics", "ELECTRONICS", "Electronics Costs"),
    TECHNOLOGY_INSERTION("TechnologyInsertion", "TECHNOLOGY_INSERTION", "Technology Insertion Costs"),
    PROPULSION_EQUIPMENT("PropulsionEquipment", "PROPULSION_EQUIPMENT", "Propulsion Equipment Costs"),
    HME("HME", "HME", "Hull, Mechanical & Electrical Costs"),
    ORDNANCE("Ordnance", "ORDNANCE", "Ordnance Costs"),
    ESCALATION("Escalation", "ESCALATION", "Escalation Costs"),
    OTHER_COST("OtherCost", "OTHER_COST", "Other Costs"),
    USER_DEFINED(null, "USER_DEFINED", "User Defined Costs");


    private final String xmlName;
    private final String dbName;
    private final String description;

    private ShipCostCategoryType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static ShipCostCategoryType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ShipCostCategoryType.class, databaseValue);
    }

    public static ShipCostCategoryType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ShipCostCategoryType.class, enumValue);
    }
}
