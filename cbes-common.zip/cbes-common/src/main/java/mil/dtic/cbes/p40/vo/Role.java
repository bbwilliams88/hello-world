package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.query.SortOrder;

import mil.dtic.cbes.p40.vo.auto._Role;

public class Role extends _Role
{
    private static final long serialVersionUID = 1L;

    // FIXME: I really don't like that we have hard-coded strings here that have
    // to match entries in the DB.
    public static final String APPMGR         = "ROLE_App_Manager";
    public static final String SITEADMIN      = "ROLE_Site_Admin";
    public static final String LOCALSITEADMIN = "ROLE_Local_Site_Admin";
    public static final String USER           = "ROLE_User";
    public static final String ANALYST        = "ROLE_Analyst";
    public static final String OMBANALYST     = "ROLE_Omb_Analyst";

    public boolean isApplicationManager()
    {
        return getName().equals(APPMGR);
    }

    public boolean isSiteAdministrator()
    {
        return getName().equals(SITEADMIN);
    }

    public boolean isLocalAdministrator()
    {
        return getName().equals(LOCALSITEADMIN);
    }

    public boolean isUser()
    {
        return getName().equals(USER);
    }
    
    public boolean isAnalyst(){
        return getName().equals(ANALYST);
    }
    
    public boolean isOmbAnalyst() {
    	return getName().equals(OMBANALYST);
    }

    public int getRank()
    {
        if (isAnalyst() || isOmbAnalyst()){
            return 0;
        }
        
        if (isApplicationManager())
            return 100;
        else if (isSiteAdministrator())
            return 75;
        else if (isLocalAdministrator())
            return 50;
        else if (isUser())
            return 25;
        else
            return 0;
    }

    public static List<Role> fetchAll(ObjectContext context)
    {
        return fetchAllForClass(context, Role.class);
    }

    public static Role fetchByName(ObjectContext context, String name)
    {
        return fetchOne(context, Role.class, NAME_PROPERTY, name);
    }

    public static List<Role> fetchAllOrderedByName(ObjectContext oc)
    {
        return Base.fetchAllWithClassForPropertyAndOrdering(oc, Role.class, Role.NAME_PROPERTY, SortOrder.ASCENDING);
    }

    @Override
    public String toString()
    {
        if (getName().equals(APPMGR))
            return "Application Manager";
        else if (getName().equals(SITEADMIN))
            return "Site Administrator";
        else if (getName().equals(LOCALSITEADMIN))
            return "Local Site Administrator";
        else if (getName().equals(USER))
            return "User";
        else if (getName().equals(ANALYST)){
            return "Analyst";
        }
        else
            return "Unknown";
    }
}
