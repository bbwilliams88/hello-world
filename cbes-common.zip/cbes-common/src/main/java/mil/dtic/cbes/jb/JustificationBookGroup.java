package mil.dtic.cbes.jb;

import java.io.File;
import java.util.List;

public class JustificationBookGroup
{
  private List<JustificationBookInfo> jbiList;
  private File masterJbFile;

  public List<JustificationBookInfo> getJbiList()
  {
    return jbiList;
  }


  public void setJbiList(List<JustificationBookInfo> jbiList)
  {
    this.jbiList = jbiList;
  }


  public File getMasterJbFile()
  {
    return masterJbFile;
  }


  public void setMasterJbFile(File masterJbFile)
  {
    this.masterJbFile = masterJbFile;
  }
}
