package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._ShipInitialReissueStartCompleteDates;

/**
 *
 */
public class ShipInitialReissueStartCompleteDates extends _ShipInitialReissueStartCompleteDates
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasInitialStart()
    {
      return getInitialStart() != null;
    }
    
    public boolean jibx_hasInitialComplete()
    {
      return getInitialComplete() != null;
    }
    
    public boolean jibx_hasReissueStart()
    {
      return getReissueStart() != null;
    }
    
    public boolean jibx_hasReissueComplete()
    {
      return getReissueComplete() != null; 
    }
    
    public boolean jibx_hasInitial()
    {
      return jibx_hasInitialStart() || jibx_hasInitialComplete();
    }
    
    public boolean jibx_hasReissue()
    {
      return jibx_hasReissueStart() || jibx_hasReissueComplete();
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
