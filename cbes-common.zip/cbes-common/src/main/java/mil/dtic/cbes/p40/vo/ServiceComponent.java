package mil.dtic.cbes.p40.vo;

import static org.apache.cayenne.query.SortOrder.ASCENDING;

import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.logging.log4j.Logger;
import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.p40.vo.auto._ServiceComponent;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.utility.CbesLogFactory;

public class ServiceComponent extends _ServiceComponent implements Equivalence<ServiceComponent>
{
    private static final Logger log = CbesLogFactory.getLog(ServiceAgency.class);
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    public static ServiceComponent fetchWithTitle(ObjectContext context, String value)
    {
        return fetchOne(context, ServiceComponent.class, ServiceComponent.TITLE_PROPERTY, value);
    }

    public static List<ServiceComponent> fetchAll(ObjectContext context)
    {
        return fetchAllForClass(context, ServiceComponent.class);
    }

    public static List<ServiceComponent> fetchAllOrderedByTitle(ObjectContext oc)
    {
        return fetchAllWithClassForPropertyAndOrdering(oc, ServiceComponent.class, ServiceComponent.TITLE_PROPERTY, ASCENDING);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getTitle()));
        builder.append(toLowerAndTrim(getCode()));

        return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(ServiceComponent obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        EqualsBuilder    builder = new EqualsBuilder();
        ServiceComponent other   = obj;

        builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
        builder.append(toLowerAndTrim(getCode()), toLowerAndTrim(other.getCode()));

        return builder.isEquals();
    }
}
