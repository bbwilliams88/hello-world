package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.data.config.InitialSourceType;
import mil.dtic.cbes.data.config.ValidityType;
import mil.dtic.cbes.data.config.XmlValidityType;
import mil.dtic.cbes.enums.StatusType;

public interface HasValidity
{
  Boolean getTest();
  ValidityType getValidity();
  XmlValidityType getXmlValidity();
  InitialSourceType getInitialSource();
  StatusType getStatus();
  boolean isValid();
  boolean isErrors();
  boolean isWarnings();
  boolean hasEditLock();
  boolean isFrozen();
  Short getErrorCount();
  Short getWarningCount();
  Short getP10Count();
  Short getP17Count();
  Short getP18Count();
  Short getP20Count();
  Short getP21Count();
  Short getP23Count();
  Short getP25Count();
  Short getP26Count();
  Short getP3aCount();
  Short getP40aCount();
  Short getP5Count();
  Short getP5aCount();
  String getSchemaError();
}