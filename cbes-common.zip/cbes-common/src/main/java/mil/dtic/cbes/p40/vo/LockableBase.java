package mil.dtic.cbes.p40.vo;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.cayenne.CayenneRuntimeException;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.EJBQLQuery;
import org.apache.cayenne.query.RelationshipQuery;
import org.apache.cayenne.query.SelectQuery;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.exceptions.LockingException;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * This abstract Cayenne superclass provides locking facilities for exhibits
 * that support locking (by subclassing this class as specified in Cayenne
 * Modeler).
 */
public abstract class LockableBase extends AuditableBase
{
    private static final Logger log = CbesLogFactory.getLog(LockableBase.class);
    private static final long serialVersionUID = 1L;
    private static final int  sessionTimeout   = 1000 * 60 * 40; // 1000ms * 60s * 40m = 40 minutes.

    public static final String LOCKED_BY_RELATIONSHIP_PROPERTY = "lockedBy";
    public static final String LOCKED_BY_DATE_PROPERTY         = "lockedByDate";

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public abstract P40User getLockedBy();
    public abstract void setLockedBy(P40User user);

    public abstract Timestamp getLockedByDate();
    public abstract void setLockedByDate(Timestamp timestamp);

    public abstract String getLockIdentifyingString();

    // FIXME: This is technically wrong ...
    private String getClassName()
    {
        return getClass().getSimpleName();
    }

    public String getLockState()
    {
        String user = getLockedBy() == null ? "null" : getLockedBy().getUserLdapId();

        return Util.concat(" ", getClassName(), getId(), user, getLockedByDate());
    }

    public P40User getRefreshedLockedBy()
    {
        if (isTransient() || isNew())
            return null;

        RelationshipQuery query = new RelationshipQuery(getObjectId(), LOCKED_BY_RELATIONSHIP_PROPERTY, true);

        @SuppressWarnings("unchecked")
        List<P40User> users = getObjectContext().performQuery(query);

        return users.size() == 0 ? null : users.get(0);
    }

    //These two assume that you ran some sort of refresh query beforehand

    // FIXME: Rename to isNotLockedByUser().
    public boolean isLockedByOther(P40User otherUser)
    {
        return getLockedBy() != null && !getLockedBy().getUserLdapId().equals(otherUser.getUserLdapId());
    }

    // FIXME: Rename to isLockedByUser().
    public boolean isLockedByMe(P40User me)
    {
        return getLockedBy() != null && getLockedBy().getUserLdapId().equals(me.getUserLdapId());
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    /**
     * Lock this row for the given user.
     *
     * @param user
     * @return whether it was successful - false if another user got the lock
     */
    public boolean lock(P40User user)
    {
        user = CayenneUtils.copyToContext(user, getObjectContext());
//        user = user.getInOtherContext(getContext());

        if (isLockedByMe(user))
            return true;

        if (isLockedByOther(user))
            return false;

        try
        {
            Timestamp  now   = new Timestamp(System.currentTimeMillis());
            EJBQLQuery query =
                new EJBQLQuery("update " + getClassName() +
                               " as lock set lock.lockedBy=:lockedBy, lock.lockedByDate=:lockedByDate " +
                               "where lock.lockedBy is null and lock.longId=:longId");

            query.setParameter("lockedBy", user);
            query.setParameter("lockedByDate", now);
            query.setParameter("longId", Long.valueOf(getId()));

            int updatecount = getContext().performNonSelectingQuery(query)[0];

            if (updatecount == 1)
            {
                setLockedBy(user);
                setLockedByDate(now);

                return true;
            }

            log.info("lock failed because someone else locking - " + updatecount, new LockingException("derp"));
        }
        catch (RuntimeException e)
        {
            log.error("Unexpected error on locking", e);
        }

        return false;
    }

    /**
     * Unlock a row, even if it isn't yours.
     */
    public void unlock()
    {
        setLockedBy(null);
        setLockedByDate(null);

        try
        {
            EJBQLQuery q = new EJBQLQuery("update " + getClassName() + " as lock set lock.lockedBy=null, lock.lockedByDate=null where lock.longId=:longId");
            q.setParameter("longId", Long.valueOf(getId()));

            getContext().performNonSelectingQuery(q);
        }
        catch (RuntimeException e)
        {
            log.error("Unexpected error on unlocking", e);
        }
    }

    /**
     * Unlock an exhibit if it belongs to the given user.
     *
     * @param user
     */
    public boolean unlock(P40User user)
    {
        if (isLockedByMe(user))
        {
            try
            {
                EJBQLQuery q = new EJBQLQuery("update " + getClassName() + " as lock set lock.lockedBy=null, lock.lockedByDate=null "
                        + "where lock.lockedBy=:lockedBy and lock.longId=:longId");

                q.setParameter("lockedBy", getLockedBy());
                q.setParameter("longId", Long.valueOf(getId()));

                int updatecount = getContext().performNonSelectingQuery(q)[0];

                if (updatecount == 1)
                {
                    setLockedBy(null);
                    setLockedByDate(null);

                    return true;
                }

                log.error(updatecount);
            }
            catch (RuntimeException e)
            {
                log.error("Unexpected error on unlocking", e);
                return false;
            }
        }

        log.error("unlock failed because of not being locked by current user", new LockingException("herp"));

        setLockedBy(null);
        setLockedByDate(null);

        return false;
    }

    /**
     * Unlock stale locks found in the database. The session timeout is assumed
     * to be 30 minutes (maximum allowable per DoD guidelines) and an additional
     * buffer added for grace. Any locked exhibits found outside this window
     * with no edits will be unlocked.
     */
    @SuppressWarnings("unchecked")
    public static void unlockStaleLocks()
    {
        log.info("Scanning for stale locks...");

        List<Class<? extends LockableBase>> exhibits = Arrays.asList(Exhibit.class, LineItem.class);

        // Loop over all lockable exhibits.
        for (Class<? extends LockableBase> lockableClass : exhibits)
        {
            DataContext dataContext = CayenneUtils.createDataContext();
            Date        threshold   = new Date(System.currentTimeMillis() - sessionTimeout);

            // Fetch all records that are currently locked by someone.
            Expression         lockedExp      = ExpressionFactory.noMatchExp(LockableBase.LOCKED_BY_RELATIONSHIP_PROPERTY, null);
            SelectQuery        query          = new SelectQuery(lockableClass, lockedExp);
            List<LockableBase> lockedExhibits = dataContext.performQuery(query);

            // Loop over all locked exhibits to find stale locks.
            for (LockableBase lockableExhibit : lockedExhibits)
            {
                // By default, do not reap the lock.
                boolean reapIt = false;

                log.info("Found locked record: " + lockableExhibit.getObjectId() + ", Locked by: " + lockableExhibit.getLockedBy().getUserLdapId());

                if (lockableExhibit.getLockedByDate() == null && lockableExhibit.getDateModified() == null)
                {
                    // If the locked by date and date modified are both null
                    // (which shouldn't happen), check the date created, which
                    // really should be there.
                    if (lockableExhibit.getDateCreated().before(threshold))
                        reapIt = true;
                }
                else if (lockableExhibit.getLockedByDate() == null && lockableExhibit.getDateModified() != null)
                {
                    // If we only have the date modified, use it to check for
                    // old sessions.
                    if (lockableExhibit.getDateModified().before(threshold))
                        reapIt = true;
                }
                else if (lockableExhibit.getLockedByDate() != null && lockableExhibit.getDateModified() == null)
                {
                    // If we only have the locked by date, use it to check for
                    // old sessions.
                    if (lockableExhibit.getLockedByDate().before(threshold))
                        reapIt = true;
                }
                else if (lockableExhibit.getLockedByDate() != null && lockableExhibit.getDateModified() != null)
                {
                    // Check to see if the lockable exhibit was locked a while
                    // ago, but never saved. Otherwise check to see if it was
                    // locked and modified, but a while ago.
                    if (lockableExhibit.getLockedByDate().after(lockableExhibit.getDateModified()) && lockableExhibit.getLockedByDate().before(threshold))
                        reapIt = true;
                    else if (lockableExhibit.getLockedByDate().before(lockableExhibit.getDateModified()) && lockableExhibit.getDateModified().before(threshold))
                        reapIt = true;
                }

                if (reapIt)
                {
                    log.info("Reaping locked record: " + lockableExhibit.getObjectId() + ", Locked by: " + lockableExhibit.getLockedBy().getUserLdapId());

                    lockableExhibit.setLockedBy(null);
                    lockableExhibit.setLockedByDate(null);
                }
            }

            try
            {
                // Flush any reapings to the database.
                dataContext.commitChanges();
            }
            catch (CayenneRuntimeException e)
            {
                log.error("An error occurred trying to reap stale locks.", e);
            }
        }

        log.info("Finished scanning for stale locks.");
    }

    /**
     * Unlock all with no optimistic locking
     */
//    public static int unlockAll(Class<? extends LockableBase> clazz) throws CayenneRuntimeException
//    {
//        String q = "update " + clazz.getSimpleName() + " as lb set lb.lockedBy = null, lb.lockedByDate = null "
//                + "where lb.lockedBy is not null or lb.lockedByDate is not null";
//        return Util.createDataContext().performNonSelectingQuery(new EJBQLQuery(q))[0];
//    }
}
