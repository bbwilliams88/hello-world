package mil.dtic.cbes.rule;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONObject;

import mil.dtic.utility.CbesLogFactory;

/**
 * Reads a JSON file of business rules, creating a rule
 * group repository.
 * 
 * @author AZumkhaw
 *
 */
public class RuleFileReader {  
  private static final Logger log = CbesLogFactory.getLog(RuleFileReader.class);  
  
  public static RuleRepository makeRuleRepository(String r2jsonFile) {
    try (Scanner sc = new Scanner(new File(r2jsonFile))) {
      sc.useDelimiter("\\A");
      String s = sc.next();
      return buildRuleRepository(s);
    } catch (FileNotFoundException e) {
      log.error("Failed to find JSON rules file: " + r2jsonFile, e);
    }
    return null;
  }
  
  public static RuleRepository makeRuleRepository(InputStream rulesStream) {
    String jsonConfiguration = null;
    try {
      jsonConfiguration = IOUtils.toString(rulesStream);
    } catch (IOException e1) {
      log.error("Unable to read rules", e1);
    }

    if (jsonConfiguration != null) {
      try (Scanner sc = new Scanner(jsonConfiguration)) {
        sc.useDelimiter("\\A");
        String s = sc.next();
        return buildRuleRepository(s);
      }
    }
    return null;
  }
  
  public static RuleRepository buildRuleRepository(String jsonConfiguration) {
    RuleRepository r = new RuleRepository();
    JSONObject jsonObject = new JSONObject(jsonConfiguration);
    
    for (String ruleBucket : jsonObject.keys()) {
      JSONObject ruleBuckets = jsonObject.getJSONObject(ruleBucket);
      for (String ruleNumber : ruleBuckets.keys()) {
        String ruleMessage = ruleBuckets.getString(ruleNumber);
        Rule rule = new Rule(ruleNumber, ruleMessage, ruleBucket);
        r.addRule(rule);
      }
    }
    return r;
  }
}