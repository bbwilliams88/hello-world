package mil.dtic.cbes.jobs;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import mil.dtic.cbes.data.config.JobSourceFlag;
import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;

public class AynchJobCreator
{
	public final static String WEBSERV_CREATED_USER = "WebService";
	private BudgesJobDAO theDao;
	
	public AynchJobCreator(BudgesJobDAO theDAO)
	{
		this.theDao = theDAO;
	}
	
	public BudgesJob CreateJobForUI(String jobIdUuid, JobTypeFlag jobType, 
						String queueName,String inputFileName, 
						String workingDirectory, String originalFileName, 
						ServiceAgency agency, BudgesUser theUser)
	{

		BudgesJob theJob = null;
		theJob = createJob(jobIdUuid, jobType,queueName, inputFileName,
							workingDirectory, originalFileName, agency, theUser,
				JobSourceFlag.UI);
		return (theJob);
	}
	
	
	public BudgesJob CreateJobForWebService(String jobIdUuid, 
			JobTypeFlag jobType, String queueName, String inputFileName, 
			String workingDirectory, String originalFileName, 
			ServiceAgency agency, BudgesUser theUser)
	{
		BudgesJob theJob = null;
		theJob = createJob(jobIdUuid, jobType, queueName,inputFileName, workingDirectory,
				originalFileName, agency, theUser, JobSourceFlag.WebService);
		return (theJob);
	}
	
	public boolean updateJobWithUserAndFileName(BudgesJob theJob, BudgesUser theUser, String resultFileName)
	{
		boolean retValue = false;
		if ((theJob!= null) && (StringUtils.isNotBlank(resultFileName)))
		{
			theJob.setResultFilename(resultFileName);
			if (theUser != null)
			{
				theJob.setModifiedByBudgesUser(theUser);
			}
			theJob.setDateModified(new Date());
			if (theDao != null)
			{
				theDao.saveOrUpdate(theJob);
				retValue = true;      
			}
		}
		return (retValue);
	}
	
	private BudgesJob createJob(String jobIdUuid, JobTypeFlag jobType,
						String queueName, String inputFileName,
						String workingDirectory, String originalFileName, 
						ServiceAgency agency, BudgesUser theUser,
						JobSourceFlag jobSource)
	{
		BudgesJob theJob = null;
		if (theDao != null)
		{
			theJob = new BudgesJob();
			// Parameters that were passed in
			theJob.setAgency(agency);
			theJob.setUuidStr(jobIdUuid);
			theJob.setJobType(jobType);
			theJob.setInputFilename(inputFileName);
			theJob.setWorkingDirectory(workingDirectory);
			theJob.setOriginalInputFilename(originalFileName);
			theJob.setQueueName(queueName);

			// now set our preset values
			Date now = new Date();
			theJob.setDateCreated(now);
			theJob.setDateModified(now);
			if (jobSource == JobSourceFlag.UI)
			{
				theJob.setCreatedByBudgesUser(theUser);
				theJob.setModifiedByBudgesUser(theUser);

			}
			theJob.setJobStatus(JobStatusFlag.NEW);
			theDao.save(theJob);
		}
		return (theJob);
	}
}
