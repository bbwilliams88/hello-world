/*
 * $Id: JBToc.java,v 1.7 2009/06/08 01:41:06 aibrahim Exp $
 */
package mil.dtic.cbes.jb;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.KeyValuePair;


public class GenericToc extends JBDefaultSystemGeneratedPart
{
  private static final Logger log = CbesLogFactory.getLog(GenericToc.class);

  List<KeyValuePair> tocItemList = null;
  
  public GenericToc()
  {    
  }

  public GenericToc(FileSetting fs)
  {
    setFileSetting(fs);
    if (fs != null)
      setTitle(fs.getTitle());
  }

  public FormattingResults createPdf() throws IOException, DocumentException, SQLException   
  {
    docCreationParams.setTocKvpList(tocItemList);
    FormattingResults fr = super.createPdf();
    return fr;
  }

  public List<KeyValuePair> getTocItemList()
  {
    return tocItemList;
  }


  public void setTocItemList(List<KeyValuePair> tocItemList)
  {
    this.tocItemList = tocItemList;
  }

}
