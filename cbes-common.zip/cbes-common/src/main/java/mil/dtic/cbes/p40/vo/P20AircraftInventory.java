package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P20AircraftInventory;

public class P20AircraftInventory extends _P20AircraftInventory
{
  private static final long serialVersionUID = 1L;
  private boolean removed = false;

  public boolean jibx_hasActive()
  {
    return jibx_hasActivePrimary()
    || getActiveBackup() != null
    || getActiveAttritionReserve() != null
    || getActiveReconstitutionReserve() != null;
  }

  public boolean jibx_hasActivePrimary()
  {
    return  getActivePrimaryMission() != null
    || getActivePrimaryTraining() != null
    || getActivePrimaryDevelopmentTest() != null
    || getActivePrimaryOther() != null;
  }

  public boolean jibx_hasInactive()
  {
    return  getInactiveBailment() != null
    || getInactiveContract() != null
    || getInactiveForeign() != null
    || getInactiveLease() != null
    || getInactiveLoan() != null
    || getInactiveMaintenanceTraining() != null
    || getInactiveReclamation() != null
    || getInactiveStorage() != null;
  }
  
  public boolean hasAnythingAtAll()
  {
    return  getInactiveBailment() != null
      || getInactiveContract() != null
      || getInactiveForeign() != null
      || getInactiveLease() != null
      || getInactiveLoan() != null
      || getInactiveMaintenanceTraining() != null
      || getInactiveReclamation() != null
      || getInactiveStorage() != null
      || getActivePrimaryMission() != null
      || getActivePrimaryTraining() != null
      || getActivePrimaryDevelopmentTest() != null
      || getActivePrimaryOther() != null
      || getActiveBackup() != null
      || getActiveAttritionReserve() != null
      || getActiveReconstitutionReserve() != null
      || getTotalActive() != null
      || getTotalInactive() != null
      || getTotalOverall()!=null;
  }
  public boolean isRemoved()
  {
    return removed;
  }
  
  public void setRemoved(boolean removed)
  {
    this.removed = removed; 
  }
}
