package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ShipsOutfittingDeliveryCostType implements ExtendedEnumeration
{
    PUBS("PUBS", "PUBS", "Publications Costs"), 
    FIRST_DESTINATION("FirstDestination", "FIRST_DESTINATION", "First Destination Costs"),
    SHIP_CLASS("ShipClass", "SHIP_CLASS", "Ship Class Costs");


    private final String xmlName;
    private final String dbName;
    private final String description;

    private ShipsOutfittingDeliveryCostType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static ShipsOutfittingDeliveryCostType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ShipsOutfittingDeliveryCostType.class, databaseValue);
    }

    public static ShipsOutfittingDeliveryCostType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ShipsOutfittingDeliveryCostType.class, enumValue);
    }
}
