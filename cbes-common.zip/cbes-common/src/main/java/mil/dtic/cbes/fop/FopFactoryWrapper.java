/*
 * $Id$
 */
package mil.dtic.cbes.fop;

import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FopFactory;
import org.xml.sax.SAXException;

import mil.dtic.utility.CbesLogFactory;

public class FopFactoryWrapper
{
  private static final Logger log = CbesLogFactory.getLog(FopFactoryWrapper.class);

  private FopConfiguration fopConfig;


  public FopFactoryWrapper(FopConfiguration fopConfig)
  {
    this.fopConfig = fopConfig;
  }


  public FopFactory getFopFactory()
  {
    // When FOPFactory is certified to be thread-safe by Apache, change this
    // code so that we don't return a new instance of it on every call.
    FopFactory fopFactory = FopFactory.newInstance();
    try
    {
      fopFactory.setUserConfig(fopConfig.getConfig());
    }
    catch (SAXException e)
    {
      log.error("Could not configure FOP Factory for budges", e);
    }
    return fopFactory;
  }


  public FopConfiguration getConfig()
  {
    return fopConfig;
  }
}
