package mil.dtic.cbes.rule;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *  Annotates a rule group method with a rule number,
 *  for invocation by a rule group visitor.
 *
 *  @RuleNumber("RDTE#PE-100")
 *  checkPENumber()
 *
 *  Analogous to @ValidationMethod
 *  
 *  @author AZumkhaw
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RuleNumber {
  String value();
}