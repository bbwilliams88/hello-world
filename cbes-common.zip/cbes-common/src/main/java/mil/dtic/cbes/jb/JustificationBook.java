package mil.dtic.cbes.jb;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;
import org.apache.fop.apps.PageSequenceResults;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.p40.vo.MultiYearProcurement;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.xml.JavaToXml;
import mil.dtic.cbes.xml.JavaToXmlResult;
import mil.dtic.cbes.xml.XMLConvertable;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.InvalidXMLListener;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.XmlUtil;

public class JustificationBook extends JBBase implements XMLConvertable {
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(JustificationBook.class);
    
    private JustificationBookInfo jbi;
    private MasterJustificationBook mjb;
    private GenericToc masterVolumeToc;

    // rdt&e fields
    private JBPeToc masterPeTocByBa;
    private JBPeToc masterPeTocByTitle;
    private R1Summary masterR1Summary;
    private R1 masterR1;
    private R1C masterR1c;
    private R1D masterR1d;

    // procurement fields
    private JBLiToc masterLiTocByBa;
    private JBLiToc masterLiTocByTitle;
    private P1 masterP1;
    private P1M masterP1m;

    private boolean standalone = true;

    public JustificationBook(){
        targetSchemaVersion = Constants.JB_XML_VERSION;
        setFileSetting(FileSetting.JB);
        setTitle(FileSetting.JB.getTitle());
    }

    @Override
    public JavaToXmlResult toZip(InvalidXMLListener invalidXMLListener, boolean excludeExternalObjectsFromZip) throws IOException, SQLException {
        JavaToXml jtx = new JavaToXml(workingFolder, excludeExternalObjectsFromZip);
        JavaToXmlResult jtxResult = jtx.toZip(this);
      
        if (invalidXMLListener != null){
            XmlUtil.sanityValidateXml(jtxResult.getXmlFile(), invalidXMLListener);
        }
      
        return jtxResult;
    }

    @Override
    public String getPdfBookmarkLabel() {
        String label = "";
      
        if (jbi != null){
            label = "(" + jbi.getLabel() + " " + jbi.getNumber() + " - " + jbi.getDescription() + ")";
        }
      
        return label + " " + FileSetting.JB.getTitle() + " - " + super.getPdfBookmarkLabel();
  }

  @Override
  public boolean r3sExist(){
      if (false == (r2ExhibitList != null && CollectionUtils.isNotEmpty(r2ExhibitList.getR2Exhibits()))){
          return false;
      }
      
      for(R2Exhibit r2: r2ExhibitList.getR2Exhibits()){
          if( r2.getProgramElement() != null && r2.getProgramElement().getProjects() != null){
              for (Project p : r2.getProgramElement().getProjects()){
                  if (p.getR3Exhibit() != null){
                      return true;
                  }
              }
          }
      }
      
      return false;
  }

  @Override
  public boolean r2sExist() {
      return r2ExhibitList != null && CollectionUtils.isNotEmpty(r2ExhibitList.getR2Exhibits());
  }

  @Override
  public boolean lineItemsExist(){
      return lineItemList != null && CollectionUtils.isNotEmpty(lineItemList.getLineItems());
  }

  @Override
  public boolean multiYearProcurementsExist() {
      return multiYearProcurementList != null && CollectionUtils.isNotEmpty(multiYearProcurementList.getMultiYearProcurements());
  }

  @Override
  public boolean p21sExist() {
      if(lineItemList != null) {
          for(LineItemWrapper lineItem : lineItemList.getLineItems()) {
              if(lineItem.isContainingDeliverySchedules()){
                  return true;
              }
          }
      }
      
      return false;
  }

  @Override
  public boolean secondaryDistributionsExist() {
      if(lineItemList != null){
          for(LineItemWrapper lineItem : lineItemList.getLineItems()) {
              if(lineItem.isContainingSecondaryDistributions()){
                  return true;
              }
          }
      }
      return false;
  }


  @Override
  protected String getPageNumberPrefix(){
      if (jbi == null){
          return "";
      }
      
      return jbi.getLabel() + " " + jbi.getNumber();
  }

  public String getBookGroupLabelAndNumber() {
      return(fileSetting.getTitle() + " " + getPageNumberPrefix());
  }

  protected String getPageNumber() {
      if (jbi == null){
          return "";
      }
      return jbi.getNumber();
  }

  public String getBookGroupNumber() {
      return(getPageNumber());
  }

  @Override
  public String getBusinessId() {
      if(super.getBusinessId() == null){
          return null;
      }
      
      String fileTag = getFileMetaTag(this);
      log.trace("fileTag: " + fileTag);
      String fileName = Util.underscoreConcat(Util.getClassificationSymbol(), getBudgetArea(), JBBase.META_JB, fileTag, super.getBusinessId());
      log.trace("fileName: " + fileName);
      return fileName;
  }
  
  @Override
  public FormattingResults createPdf() throws DocumentException, IOException, SQLException {
      log.trace("createPdf(): 1.  Creating JB PDF with page offset " + pdfPageOffset);
      
      pdfStartPage = pdfPageOffset;
      String oldWatermark = null;
      String oldTrackingHeader = null;
      String oldWorkFlowStatus = null;
      
      try {
          // TODO remove, no longer needed
          if (docAssemblyOptions == null){
              docAssemblyOptions = new DocumentAssemblyOptions();
              docAssemblyOptions.setGenerateR1(true);
              docAssemblyOptions.setGenerateProgramElementTocByBA(true);
              docAssemblyOptions.setGenerateProgramElementTocByTitle(true);
              docAssemblyOptions.setSuppressSubExhibits(false);
          }
          else {
              oldWatermark = docAssemblyOptions.getWatermark();
              oldTrackingHeader = docAssemblyOptions.getTrackingHeader();
              oldWorkFlowStatus = docAssemblyOptions.getWorkFlowStatus();
              docAssemblyOptions.setWatermark(null);
              docAssemblyOptions.setTrackingHeader(null);
              docAssemblyOptions.setWorkFlowStatus(null);
          }
          
          docCreationParams.setBudgetArea(getBudgetArea());

          if (docCreationParams.getBudgetCycle() == null){
              docCreationParams.setBudgetCycle(budgetCycle);
          }

          if (docCreationParams.getBudgetYear() == null){
              docCreationParams.setBudgetYear(budgetYear);
          }

          // Since the approp info is optional, set it manually if it is not
          // available
          if (getAppropriation() == null) {
              if (r2sExist()){
                  IAppropriation approp = r2ExhibitList.getR2Exhibits().get(0).getProgramElement().getBudgetActivity().getAppropriation();
                  setAppropriation(approp);
                  docCreationParams.setAppropriationName(approp.getName());
                  docCreationParams.setAppropriationCode(approp.getCode());
              }
              else if (lineItemsExist()){
                  IAppropriation approp = lineItemList.getLineItems().get(0).getLineItem().getBudgetSubActivity().getBudgetActivity().getAppropriation();
                  setAppropriation(approp);
                  docCreationParams.setAppropriationName(approp.getName());
                  docCreationParams.setAppropriationCode(approp.getCode());
              }
          }

          if (Constants.JBPageNumberingModel.SECTIONED.equals(jbPageNumberingModel))  {
              log.trace("createPdf() createPaginationGroups");
              createPaginationGroups();
          }
          else{
              log.trace("Preparing JB documents continuous page numbering model...");
              createPaginationGroupsCont();
          }

          log.trace("Concatenating JB documents...");
          concatPdfs();
          log.trace("Setting absolute page numbers for all JB pages...");
          setPdfAbsoluteStartPages();
      }
      finally{
          docAssemblyOptions.setWatermark(oldWatermark);
          docAssemblyOptions.setTrackingHeader(oldTrackingHeader);
          docAssemblyOptions.setWorkFlowStatus(oldWorkFlowStatus);
      }

      log.trace("Page numbering and watermarking JB document...");
      createJb();
      log.trace("Finished building JB document...");
      rfr = isRfr();
      return null;
  }


  public void preCreateR2Pdfs() throws IOException, DocumentException, SQLException {
      log.trace("Pre-Creating R2's...");
      createR2Pdfs(null);
  }

  public void preCreateP40Pdfs() throws IOException, DocumentException, SQLException {
      log.trace("Pre-Creating P40's...");
      createP40Pdfs(null);
  }

  public void createPaginationGroups() throws IOException, DocumentException, SQLException {
      log.trace("**createPaginationGroups(): Creating pagination groups...");

    // Prepare the pagination sections
      PaginationGroup pg1 = new PaginationGroup(Constants.JBPageNumbering.NONE, true);
      PaginationGroup pg2 = new PaginationGroup(Constants.JBPageNumbering.RESTART, Constants.JBPageNumberingStyle.ROMAN_NUMERALS, true);
      PaginationGroup pg3 = new PaginationGroup(Constants.JBPageNumbering.RESTART, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);

      pgList = new ArrayList<PaginationGroup>();
      
      if (standalone){
          pgList.add(pg1);
      }
      pgList.add(pg2);
      pgList.add(pg3);
    //MYP will go in Pagination Group 4, if it exists.
      PaginationGroup pg4;
      if (multiYearProcurementsExist()){
          log.trace("Adding MYP pagination group and processing...");
          pg4 = new PaginationGroup(Constants.JBPageNumbering.CONTINUE, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);
          pgList.add(pg4);
          populatePaginationGroups(pg1, pg2, pg3, pg4);
      }
      else{
          populatePaginationGroups(pg1, pg2, pg3);
      }
  }

  public void populatePaginationGroups(PaginationGroup pg1, PaginationGroup pg2, PaginationGroup pg3) throws IOException, DocumentException, SQLException {
    log.trace("JustificationBook:populatePaginationGroups - three pagination groups...");
    log.trace("Creating cover...");
    createCoverPdf(standalone ? pg1 : pg2);

    if (r2sExist()){
      log.trace("Creating R2's...");
      createR2Pdfs(pg3);
    }
    else if (lineItemsExist()){
      log.trace("Creating P40's...");
      createP40Pdfs(pg3);
    }

    if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat() && docAssemblyOptions.isIncludeTov())  {
        masterVolumeToc = mjb.getVolumeToc();
        log.trace("Adding table of volumes..." + masterVolumeToc.getAbsoluteFileName());
        pg2.addJbPart(masterVolumeToc);
    }

    log.trace("Creating dummy (place holder) TOC...");
    // Put a place holder for the 1-page (if blank pages are suppressed) or
    // 2-page (if blank pages are not suppressed) TOC
    toc = new JBToc(this);
    toc.setPdfTotalPageCount(docAssemblyOptions.isForceEvenPages() ? 2 : 1);
    pg2.addJbPart(toc);
    log.trace("Created " + toc.getPdfTotalPageCount() + "-page place holder for TOC...");
    
    log.trace("Preparing user supplied cost doc...");
    prepareUserSuppliedDoc(costDoc, pg2);

    log.trace("Preparing user supplied introduction doc...");
    prepareUserSuppliedDoc(introductionDoc, pg2);

    log.trace("Preparing user supplied comptroller r1 doc...");
    prepareUserSuppliedDoc(userR1Doc, pg2);

    log.trace("Preparing user supplied comptroller p1 doc...");
    prepareUserSuppliedDoc(userP1Doc, pg2);

    if (r2sExist()) {
        if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat()) {
            if (docAssemblyOptions.isIncludeMasterProgramElementTocByBA()){
                log.trace("Adding master PE TOC by BA #...");
                masterPeTocByBa = mjb.getPeTocByBa();
                pg2.addJbPart(masterPeTocByBa);
            }

            if (docAssemblyOptions.isIncludeMasterProgramElementTocByTitle()) {
                log.trace("Adding master PE TOC by PE Title...");
                masterPeTocByTitle = mjb.getPeTocByTitle();
                pg2.addJbPart(masterPeTocByTitle);
            }
        }

        if (docAssemblyOptions.isGenerateProgramElementTocByBA()) {
            log.trace("Creating PE TOC by BA #...");
            createPeTocByBa(pg2);
        }
        if (docAssemblyOptions.isGenerateProgramElementTocByTitle()){
            log.trace("Creating PE TOC by PE Title...");
            createPeTocByTitle(pg2);
        }
    }

    if (lineItemsExist()) {
        if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat()) {
            if (docAssemblyOptions.isIncludeMasterLineItemTocByBA()) {
                log.trace("Adding master LI TOC by BA #...");
                masterLiTocByBa = mjb.getLiTocByBa();
                pg2.addJbPart(masterLiTocByBa);
            }

            if (docAssemblyOptions.isIncludeMasterLineItemTocByTitle()){
                log.trace("Adding master LI TOC by LI Title...");
                masterLiTocByTitle = mjb.getLiTocByTitle();
                pg2.addJbPart(masterLiTocByTitle);
            }
        }

        if (docAssemblyOptions.isGenerateLineItemTocByBA()){
            log.trace("Creating LI TOC by BA #...");
            createLiTocByBa(pg2);
        }
      
        if (docAssemblyOptions.isGenerateLineItemTocByTitle()){
            log.trace("Creating LI TOC by LI Title...");
            createLiTocByTitle(pg2);
        }
    }

    log.trace("Preparing user supplied summary doc...");
    prepareUserSuppliedDoc(summaryDoc, pg2);

    if (r2sExist()){
        if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat()) {
            if (docAssemblyOptions.isIncludeMasterR1Summary()){
                log.trace("Including master R1 Summary...");
                masterR1Summary = mjb.getR1Summary();
                pg2.addJbPart(masterR1Summary);
            }
            
            if (docAssemblyOptions.isIncludeMasterR1()){
                log.trace("Including master R1...");
                masterR1 = mjb.getR1();
                pg2.addJbPart(masterR1);
            }

            if (docAssemblyOptions.isIncludeMasterR1c()){
                log.trace("Including master R1C...");
                masterR1c = mjb.getR1c();
                pg2.addJbPart(masterR1c);
            }

            if (docAssemblyOptions.isIncludeMasterR1d()) {
                log.trace("Including master R1D...");
                masterR1d = mjb.getR1d();
                pg2.addJbPart(masterR1d);
            }
        }

        if (docAssemblyOptions.isGenerateR1Summary()) {
            log.trace("Creating R1 Summary...");
            createR1SummaryPdf(pg2);
        }
      
        if (docAssemblyOptions.isGenerateR1()){
            log.trace("Creating R1...");
            createR1Pdf(pg2);
        }
      
        if (docAssemblyOptions.isGenerateR1c()) {
            log.trace("Creating R1C...");
            createR1cPdf(pg2);
        }
      
        if (docAssemblyOptions.isGenerateR1d()){
            log.trace("Creating R1D...");
            createR1dPdf(pg2);
        }
    }

    if (lineItemsExist()) {
        if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat()) {
            if (docAssemblyOptions.isIncludeMasterP1()){
                log.trace("Including master P1...");
                masterP1 = mjb.getP1();
                pg2.addJbPart(masterP1);
            }
            
            if (docAssemblyOptions.isIncludeMasterP1m()) {
                log.trace("Including master P1m...");
                masterP1m = mjb.getP1m();
                pg2.addJbPart(masterP1m);
                log.trace("... included master P1m");
            }
        }

        if (docAssemblyOptions.isGenerateP1()){
            log.trace("Creating P1...");
            createP1Pdf(pg2);
        }
        
        if (docAssemblyOptions.isGenerateP1m()){
            log.trace("Creating P1m...");
            createP1mPdf(pg2);
        }
    }

    if (supplementalDocCollection != null) {
        log.trace("Preparing user supplied supplemental docs...");
        
        if (determineAlternateDocumentPagination(supplementalDocCollection)){
            prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg3);
            
        }
        else {
            prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg2);
        }
        supplementalDocCollection.setPdfStartPage(supplementalDocCollection.getSupplementalDocList().get(0).getPdfStartPage());
        supplementalDocCollection.setPdfPaginationGroup(pg2);
    }
    
    log.trace("Preparing user supplied acronyms doc...");
    prepareUserSuppliedDoc(acronymDoc, pg2);

    adjustTocAndGroupPdfCount(pg2); //total toc pdf page may varied and now we need to adjust to the real #
    log.trace("Creating actual TOC...");
    createPartPdf(toc);
    updatePdfTotalPageCount();
    dumpPaginationGroups();
  }
  
  //CXE-4197
  private boolean determineAlternateDocumentPagination(JBSupplementalDocCollection supplementDocCollection){
      log.trace("** determineAlternateDocumentPagination: - start" );
      boolean alternatePagination = false;
      
      if (supplementDocCollection.getSupplementalDocList().size() < 1){
          return alternatePagination;
      }
      
      if (null != this.getDocAssemblyOptions() && this.getDocAssemblyOptions().isPositionAttachmentsAfterExhibits()){
          alternatePagination = true;
      } 
      
      log.trace("determineAlternateDocumentPagination(): alternatePagination " + alternatePagination);
      return alternatePagination;
  }


  public void populatePaginationGroups(PaginationGroup pg1, PaginationGroup pg2, PaginationGroup pg3, PaginationGroup pg4) throws IOException, DocumentException, SQLException {
    log.trace("populatePaginationGroups: populating four pagination groups...");

    log.trace("Creating cover...");
    createCoverPdf(standalone ? pg1 : pg2);

    if (r2sExist())
    {
      log.trace("Creating R2's...");
      createR2Pdfs(pg3);
    }
    else if (lineItemsExist())
    {
      log.trace("Creating P40's...");
      createP40Pdfs(pg3);
    }

    if (multiYearProcurementsExist())
    {
      log.trace("Creating MYP's...");
      createMYPPdfs(pg4);
      pg4.adjustStartPages(pg3.getTotalPageCount());
    }
    else
    {
      log.trace("Shouldn't have gotten here.  Only call the 4 Pagination group method if MYP exists");
    }

    if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat() && docAssemblyOptions.isIncludeTov())
    {
      masterVolumeToc = mjb.getVolumeToc();
      log.trace("Adding table of volumes..." + masterVolumeToc.getAbsoluteFileName());
      pg2.addJbPart(masterVolumeToc);
    }

    log.trace("Creating dummy (place holder) TOC...");
    // Put a place holder for the 1-page (if blank pages are suppressed) or
    // 2-page (if blank pages are not suppressed) TOC
    toc = new JBToc(this);
    toc.setPdfTotalPageCount(docAssemblyOptions.isForceEvenPages() ? 2 : 1);
    pg2.addJbPart(toc);
    log.trace("Created " + toc.getPdfTotalPageCount() + "-page place holder for TOC...");
    
    log.trace("Preparing user supplied cost doc...");
    prepareUserSuppliedDoc(costDoc, pg2);

    log.trace("Preparing user supplied introduction doc...");
    prepareUserSuppliedDoc(introductionDoc, pg2);

    log.trace("Preparing user supplied comptroller r1 doc...");
    prepareUserSuppliedDoc(userR1Doc, pg2);

    log.trace("Preparing user supplied comptroller p1 doc...");
    prepareUserSuppliedDoc(userP1Doc, pg2);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterProgramElementTocByBA())
        {
          log.trace("Adding master PE TOC by BA #...");
          masterPeTocByBa = mjb.getPeTocByBa();
          pg2.addJbPart(masterPeTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterProgramElementTocByTitle())
        {
          log.trace("Adding master PE TOC by PE Title...");
          masterPeTocByTitle = mjb.getPeTocByTitle();
          pg2.addJbPart(masterPeTocByTitle);
        }
      }

      if (docAssemblyOptions.isGenerateProgramElementTocByBA())
      {
        log.trace("Creating PE TOC by BA #...");
        createPeTocByBa(pg2);
      }
      if (docAssemblyOptions.isGenerateProgramElementTocByTitle())
      {
        log.trace("Creating PE TOC by PE Title...");
        createPeTocByTitle(pg2);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterLineItemTocByBA())
        {
          log.trace("Adding master LI TOC by BA #...");
          masterLiTocByBa = mjb.getLiTocByBa();
          pg2.addJbPart(masterLiTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterLineItemTocByTitle())
        {
          log.trace("Adding master LI TOC by LI Title...");
          masterLiTocByTitle = mjb.getLiTocByTitle();
          pg2.addJbPart(masterLiTocByTitle);
        }
      }

      if (docAssemblyOptions.isGenerateLineItemTocByBA())
      {
        log.trace("Creating LI TOC by BA #...");
        createLiTocByBa(pg2);
      }
      if (docAssemblyOptions.isGenerateLineItemTocByTitle())
      {
        log.trace("Creating LI TOC by LI Title...");
        createLiTocByTitle(pg2);
      }
    }

    log.trace("Preparing user supplied summary doc...");
    prepareUserSuppliedDoc(summaryDoc, pg2);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterR1Summary())
        {
          log.trace("Including master R1 Summary...");
          masterR1Summary = mjb.getR1Summary();
          pg2.addJbPart(masterR1Summary);
        }

        if (docAssemblyOptions.isIncludeMasterR1())
        {
          log.trace("Including master R1...");
          masterR1 = mjb.getR1();
          pg2.addJbPart(masterR1);
        }

        if (docAssemblyOptions.isIncludeMasterR1c())
        {
          log.trace("Including master R1C...");
          masterR1c = mjb.getR1c();
          pg2.addJbPart(masterR1c);
        }

        if (docAssemblyOptions.isIncludeMasterR1d())
        {
          log.trace("Including master R1D...");
          masterR1d = mjb.getR1d();
          pg2.addJbPart(masterR1d);
        }
      }

      if (docAssemblyOptions.isGenerateR1Summary())
      {
        log.trace("Creating R1 Summary...");
        createR1SummaryPdf(pg2);
      }
      if (docAssemblyOptions.isGenerateR1())
      {
        log.trace("Creating R1...");
        createR1Pdf(pg2);
      }
      if (docAssemblyOptions.isGenerateR1c())
      {
        log.trace("Creating R1C...");
        createR1cPdf(pg2);
      }
      if (docAssemblyOptions.isGenerateR1d())
      {
        log.trace("Creating R1D...");
        createR1dPdf(pg2);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterP1())
        {
          log.trace("Including master P1...");
          masterP1 = mjb.getP1();
          pg2.addJbPart(masterP1);
        }
        if (docAssemblyOptions.isIncludeMasterP1m())
        {
          log.trace("Including master P1m...");
          masterP1m = mjb.getP1m();
          pg2.addJbPart(masterP1m);
          log.trace("... included master P1m");
        }
      }

      if (docAssemblyOptions.isGenerateP1())
      {
        log.trace("Creating P1...");
        createP1Pdf(pg2);
      }
      if (docAssemblyOptions.isGenerateP1m())
      {
        log.trace("Creating P1m...");
        createP1mPdf(pg2);
      }
    }

    if (supplementalDocCollection != null) {
      log.trace("** populatePaginationGroups: Preparing user supplied supplemental docs...");
      
      if (determineAlternateDocumentPagination(supplementalDocCollection)){
          log.trace("populatePaginationGroups: adjusting paginationGroup to pg4");
          prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg4);
      }
      else {
          log.trace("populatePaginationGroups(): retaining paginationGroup to pg2");
          prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg2);
      }
      supplementalDocCollection.setPdfStartPage(supplementalDocCollection.getSupplementalDocList().get(0).getPdfStartPage());
      supplementalDocCollection.setPdfPaginationGroup(pg2);
    }

    log.trace("Preparing user supplied acronyms doc...");
    prepareUserSuppliedDoc(acronymDoc, pg2);

    adjustTocAndGroupPdfCount(pg2); //total toc pdf page may varied and now we need to adjust to the real #
    log.trace("populatePaginationGroups(): Creating actual TOC...");
    createPartPdf(toc);
    updatePdfTotalPageCount();

    dumpPaginationGroups();
  }


  private void adjustTocAndGroupPdfCount(PaginationGroup pg2) throws IOException, DocumentException, SQLException
  {
    FormattingResults fr = createPartPdf(toc);
    int tocTotalPages = (fr != null?fr.getPageCount():0);
    toc.setPdfTotalPageCount(tocTotalPages);
    pg2.adjustStartPages(1);
  }


  protected void createToc(PaginationGroup pg) throws IOException, DocumentException, SQLException {
    log.trace("createToc() - start");
    if (toc == null){
      toc = new JBToc(this);
    }
    createPartPdf(toc, pg);
    log.trace("createToc() - finished");
  }


  public void createR2Pdfs(PaginationGroup pg) throws IOException, DocumentException, SQLException
  {
    if (r2sExist())
    {
      if (r2ExhibitList.hasContent())
      {
        log.trace("R2 Exhibit List PDF already exists, not re-building..." + r2ExhibitList.getAbsoluteFileName());
        pg.addJbPart(r2ExhibitList);
      }
      else
      {
        log.trace("R2 Exhibit List does not have content, building PDF...");
        int count = r2ExhibitList.getR2Exhibits().size();
        log.trace("createR2Pdfs(): Building PDF for " + count + " r2's " + "...");
        FormattingResults fr = createPartPdf(r2ExhibitList, pg);
        if (fr != null)
        {
          log.trace("FOP PDF results: generated " + fr.getPageCount() + " total pages " + " and " + fr.getPageSequences().size() + " page sequences ...");

          int startPage = 1;
          r2PageNumberKvpList = new ArrayList<KeyValuePair>();
          int index = 0;
          List<PageSequenceResults> psrList = fr.getPageSequences();
          for (PageSequenceResults psr : psrList)
          {
            R2Exhibit r2Exhibit = r2ExhibitList.getR2Exhibits().get(index);
            r2Exhibit.setPdfStartPage(startPage);
            r2Exhibit.setPdfTotalPageCount(psr.getPageCount());

            String r2Id = r2Exhibit.getBusinessId();
            log.trace("R2 " + r2Id + " built with " + psr.getPageCount() + " pages and id " + psr.getID() + " starts on page " + startPage);

            String pageNumberText = Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(r2Exhibit.getPdfStartPage()));
            // Save the page # info for use in the toc later
            KeyValuePair kvp = new KeyValuePair(r2Id, pageNumberText);
            r2PageNumberKvpList.add(kvp);

            startPage += psr.getPageCount();
            ++index;
          }

          r2ExhibitList.setPdfStartPage(r2ExhibitList.getR2Exhibits().get(0).getPdfStartPage());
        }
        r2ExhibitList.setPdfPaginationGroup(pg);
      }
    }
  }

  public void createP40Pdfs(PaginationGroup pg) throws IOException, DocumentException, SQLException
  {
    if (lineItemsExist())
    {
      if (lineItemList.hasContent())
      {
        log.trace("Line Item List PDF already exists, not re-building..." + lineItemList.getAbsoluteFileName());
        pg.addJbPart(lineItemList);
      }
      else
      {
        log.trace("Line Item List does not have content, building PDF...");
        int count = lineItemList.getLineItems().size();
        log.trace("Building PDF for " + count + " p40's " + "...");

        if (multiYearProcurementsExist())
        {
          log.trace("Adding MYP names to associated Line Items");
          lineItemList.addAssociatedMultiYearProcurement(getMultiYearProcurementList());
        }

        FormattingResults fr = createPartPdf(lineItemList, pg);
        if (fr != null)
        {
          log.trace("FOP PDF results: generated " + fr.getPageCount() + " total pages " + " and " + fr.getPageSequences().size() + " page sequences ...");
          int startPage = 1;
          p40PageNumberKvpList = new ArrayList<KeyValuePair>();
          int index = 0;
          List<PageSequenceResults> psrList = fr.getPageSequences();
          int pageSequenceResultsIndex = 0;

          while (pageSequenceResultsIndex < psrList.size())
          {
            if (index < lineItemList.getLineItems().size())
            {
              log.trace("This is better, we should do this all the time");
              // Get the set of pages from the PDF's P40 (P10s have their own
              // page sequence)
              PageSequenceResults pageSequenceResults = psrList.get(pageSequenceResultsIndex);

              // Get the LineItem (includes the P10s)
              LineItemWrapper lineItem = lineItemList.getLineItems().get(index);
              String lineItemBusinessId = lineItem.getBusinessId();

              lineItem.setPdfStartPage(startPage);
              lineItem.setPdfTotalPageCount(pageSequenceResults.getPageCount());

              log.trace("P40 " + lineItemBusinessId + " built with " + pageSequenceResults.getPageCount() + " pages and id " + pageSequenceResults.getID() + " starts on page " + startPage);

              String pageNumberText = Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(lineItem.getPdfStartPage()));
              // Save the page # info for use in the toc later
              lineItemBusinessId = lineItemBusinessId + "_TITLE-" + lineItem.getLineItem().getLineItemTitle();

              // If the LineItem is AP only, then ignore the entry for the non-existent parent Line Item in the page numbering.
              if (false == lineItem.getLineItem().isAPP40Standalone())
              {
                startPage += pageSequenceResults.getPageCount();
                log.trace("Processing line Item which isn't only advanded procurement: " + lineItemBusinessId);
                ++pageSequenceResultsIndex;
                KeyValuePair keyValuePair = new KeyValuePair(lineItemBusinessId, pageNumberText);
                p40PageNumberKvpList.add(keyValuePair);
              }
              else
              {
                log.trace("Processing an Advance Procurement Only Line Item: " + lineItemBusinessId);
              }

              if (lineItem.getLineItem().hasAdvanceProcurement())
              {
                log.trace("Entering the AP for " + lineItemBusinessId);
                log.trace("AP40 " + lineItemBusinessId + " built with " + pageSequenceResults.getPageCount() + " pages and id " + pageSequenceResults.getID() + " starts on page " + startPage);
                PageSequenceResults advancePorcurementPageSequenceResults = psrList.get(pageSequenceResultsIndex);
                String advanceProcurementPageNumberText = Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(startPage));
                p40PageNumberKvpList.add(new KeyValuePair("AP" + lineItemBusinessId, advanceProcurementPageNumberText));
                startPage += advancePorcurementPageSequenceResults.getPageCount();
                lineItem.getLineItem().setAdvanceProcurementTotalPages(advancePorcurementPageSequenceResults.getPageCount());
                lineItem.setPdfTotalPageCount(lineItem.getPdfTotalPageCount());
                ++pageSequenceResultsIndex;
              }
              ++index;
            }
            else
            {
              ++pageSequenceResultsIndex;
              log.error("Well this is odd... how did we get here? The line item index is " + index + ".");
            }
          }

          lineItemList.setPdfStartPage(lineItemList.getLineItems().get(0).getPdfStartPage());
        }
        lineItemList.setPdfPaginationGroup(pg);
      }
    }
  }


  public void createMYPPdfs(PaginationGroup pg) throws IOException, DocumentException, SQLException
  {
    if (multiYearProcurementsExist())
    {
      if (multiYearProcurementList.hasContent())
      {
        log.trace("MultiYear Procurement List PDF already exists, not re-building..." + multiYearProcurementList.getAbsoluteFileName());
        pg.addJbPart(multiYearProcurementList);
      }
      else
      {
        log.trace("MultiYear Procurement List does not have content, building PDF...");
        int count = multiYearProcurementList.getMultiYearProcurements().size();
        log.trace("Building PDF for " + count + " MYP's " + "...");
        FormattingResults fr = createPartPdf(multiYearProcurementList, pg);
        if (fr != null)
        {
          log.trace("FOP PDF results: generated " + fr.getPageCount() + " total pages " + " and " + fr.getPageSequences().size() + " page sequences ...");
          int startPage = 1;
          mypPageNumberKvpList = new ArrayList<KeyValuePair>();
          int index = 0;
          List<PageSequenceResults> psrList = fr.getPageSequences();
          int pageSequenceResultsIndex = 0;

          while (pageSequenceResultsIndex < psrList.size())
          {
            if (index < multiYearProcurementList.getMultiYearProcurements().size())
            {
              log.trace("This is better, we should do this all the time");
              // Get the set of pages from the PDF's MYP
              PageSequenceResults pageSequenceResults = psrList.get(pageSequenceResultsIndex);

              // Get the MYP's
              MultiYearProcurement myp = multiYearProcurementList.getMultiYearProcurements().get(index);
              String mypID = myp.getBusinessId();

              myp.setPdfStartPage(startPage);
              myp.setPdfTotalPageCount(pageSequenceResults.getPageCount());

              log.trace("MYP " + mypID + " built with " + pageSequenceResults.getPageCount() + " pages and id " + pageSequenceResults.getID() + " starts on page " + startPage);

              startPage += pageSequenceResults.getPageCount();

              String pageNumberText = Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(myp.getPdfStartPage()));
              // Save the page # info for use in the toc later
              mypID = mypID + "_TITLE-" + myp.getSystemName();

              log.trace("Processing myp: " + mypID);
              ++pageSequenceResultsIndex;
              KeyValuePair keyValuePair = new KeyValuePair(mypID, pageNumberText);
              mypPageNumberKvpList.add(keyValuePair);

              ++index;
            }
            else
            {
              ++pageSequenceResultsIndex;
              log.error("Well this is odd... how did we get here? The multiyear procurement index is " + index + ".");
            }
          }

          log.trace("Setting pdf start page to: " + multiYearProcurementList.getMultiYearProcurements().get(0).getPdfStartPage());
          multiYearProcurementList.setPdfStartPage(multiYearProcurementList.getMultiYearProcurements().get(0).getPdfStartPage());
        }
        multiYearProcurementList.setPdfPaginationGroup(pg);
      }
    }
  }


  @SuppressWarnings("unchecked")
  protected void createJb() throws DocumentException, IOException
  {

	log.trace("inside JusfificationBook createJb");
    OutputStream pdfOutputStream = null;
    PdfReader pdfReader = null;
    PdfStamper pdfStamper = null;

    try
    {
      log.trace("About to page number and watermark JB...");

      String tmpFileName = FileUtil.createPdfFileName(getFileNamePrefix(), "final");
      File tmpOutputFile = new File(workingFolder, tmpFileName);
      pdfOutputStream = new BufferedOutputStream(new FileOutputStream(tmpOutputFile));

      pdfReader = new PdfReader(absoluteFileName);
      pdfStamper = new PdfStamper(pdfReader, pdfOutputStream);

      if (standalone)
      {
        // Apply security constraints: 1) disallow changes, 2) use random string
        // for password
        boolean passwordEnabled = BudgesContext.getConfigService().getJbPdfPasswordEnable(budgetCycle, budgetYear);
        if (passwordEnabled)
          pdfStamper.setEncryption(PdfWriter.STANDARD_ENCRYPTION_40, null, BudgesContext.getConfigService().getJbPdfPassword(budgetCycle, budgetYear), Constants.PDF_READ_ONLY_PERMISSIONS);

        // Set document properties
        pdfStamper.setMoreInfo((HashMap<String, String>) getPdfPropertiesToApply(pdfStamper.getMoreInfo()));
      }
      numberPagesAndWatermark(pgList, pdfReader, pdfStamper);
      log.trace("inside JusfificationBook createJb finished numberPagesAndWatermark");
      decoratePdf(pdfStamper);
      
      
      absoluteFileName = tmpOutputFile.getAbsolutePath();
    }
    finally
    {
      PdfUtil.closePdfStamper(pdfStamper);
      PdfUtil.closePdfReader(pdfReader);
      FileUtil.close(pdfOutputStream);
    }

    log.trace("Finished page numbering and watermarking JB...");

  }


  protected void decoratePdf(PdfStamper pdfStamper) throws IOException
  {
    if (standalone)
    {
      // Set bookmarks
      JbPdfBookMarkBuilder jbbb = new JbPdfBookMarkBuilder();
      List<HashMap<String, Object>> outlineList = jbbb.getBookmarkList(this);
      pdfStamper.setOutlines(outlineList);
      pdfStamper.setViewerPreferences(PdfWriter.PageModeUseOutlines);

      // Embed xml file as attachment
      for (EmbedableFile fileToEmbed : fileToEmbedList)
      {
        pdfStamper.addFileAttachment(fileToEmbed.getDisplayDescription(), null, fileToEmbed.getFileLocation(), fileToEmbed.getDisplayFileName());
      }
      pdfStamper.setViewerPreferences(PdfWriter.PageModeUseAttachments);
    }
  }


  @Override
  protected void createCoverPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException
  {
    docCreationParams.setBookGroupLabelAndNumber(getBookGroupLabelAndNumber());
    super.createCoverPdf(pg);
  }


  protected void setTotalCoverVolumes(String totalVolumes)
  {
    docCreationParams.setTotalVolumes(totalVolumes);
  }


  public void createPaginationGroupsCont() throws IOException, DocumentException, SQLException
  {
    log.trace("About to prepare JB docs...");

    log.trace("Creating pagination groups...");

    // Prepare the pagination sections
    PaginationGroup pg1 = new PaginationGroup(Constants.JBPageNumbering.RESTART, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);
    PaginationGroup pg2 = new PaginationGroup(Constants.JBPageNumbering.CONTINUE, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);
    PaginationGroup pg3 = new PaginationGroup(Constants.JBPageNumbering.CONTINUE, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);

    pgList = new ArrayList<PaginationGroup>();
    pgList.add(pg1);
    pgList.add(pg2);
    pgList.add(pg3);
    //MYP will go in Pagination Group 4, if it exists.
    PaginationGroup pg4;
    if (multiYearProcurementsExist())
    {
      pg4 = new PaginationGroup(Constants.JBPageNumbering.CONTINUE, Constants.JBPageNumberingStyle.ARABIC_NUMERALS, true);
      pgList.add(pg4);
      populatePaginationGroupsCont(pg1, pg2, pg3, pg4);
    }
    else
    {
       populatePaginationGroupsCont(pg1, pg2, pg3);
    }
    finalizePaginationGroups();
    updatePdfTotalPageCount();
  }


  public void populatePaginationGroupsCont(PaginationGroup pg1, PaginationGroup pg2, PaginationGroup pg3) throws IOException, DocumentException, SQLException
  {
    log.trace("Popuating pagination groups...");

    log.trace("Creating cover...");
    createCoverPdf(pg1);

    if (r2sExist())
      createInitialR2PageNumberKvp();

    if (lineItemsExist())
      createInitialP40PageNumberKvp();
    
    log.trace("Preparing user supplied introduction doc...");
    prepareUserSuppliedDoc(costDoc, pg3);

    log.trace("Preparing user supplied introduction doc...");
    prepareUserSuppliedDoc(introductionDoc, pg3);

    log.trace("Preparing user supplied comptroller r1 doc...");
    prepareUserSuppliedDoc(userR1Doc, pg3);

    log.trace("Preparing user supplied comptroller p1 doc...");
    prepareUserSuppliedDoc(userP1Doc, pg3);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterProgramElementTocByBA())
        {
          log.trace("Adding master PE TOC by BA #...");
          masterPeTocByBa = mjb.getPeTocByBa();
          pg3.addJbPart(masterPeTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterProgramElementTocByTitle())
        {
          log.trace("Adding master PE TOC by PE Title...");
          masterPeTocByTitle = mjb.getPeTocByTitle();
          pg3.addJbPart(masterPeTocByTitle);
        }
      }
      if (docAssemblyOptions.isGenerateProgramElementTocByBA())
      {
        log.trace("Creating PE TOC by BA #...");
        createPeTocByBa(pg3);
      }
      if (docAssemblyOptions.isGenerateProgramElementTocByTitle())
      {
        log.trace("Creating PE TOC by PE Title...");
        createPeTocByTitle(pg3);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterLineItemTocByBA())
        {
          log.trace("Adding master LI TOC by BA #...");
          masterLiTocByBa = mjb.getLiTocByBa();
          pg3.addJbPart(masterLiTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterLineItemTocByTitle())
        {
          log.trace("Adding master LI TOC by LI Title...");
          masterLiTocByTitle = mjb.getLiTocByTitle();
          pg3.addJbPart(masterLiTocByTitle);
        }
      }
      if (docAssemblyOptions.isGenerateLineItemTocByBA())
      {
        log.trace("Creating LI TOC by BA #...");
        createLiTocByBa(pg3);
      }
      if (docAssemblyOptions.isGenerateLineItemTocByTitle())
      {
        log.trace("Creating LI TOC by LI Title...");
        createLiTocByTitle(pg3);
      }
    }

    log.trace("Preparing user supplied summary doc...");
    prepareUserSuppliedDoc(summaryDoc, pg3);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterR1Summary())
        {
          log.trace("Including master R1 Summary...");
          masterR1Summary = mjb.getR1Summary();
          pg3.addJbPart(masterR1Summary);
        }

        if (docAssemblyOptions.isIncludeMasterR1())
        {
          log.trace("Including master R1...");
          masterR1 = mjb.getR1();
          pg3.addJbPart(masterR1);
        }

        if (docAssemblyOptions.isIncludeMasterR1c())
        {
          log.trace("Including master R1C...");
          masterR1c = mjb.getR1c();
          pg3.addJbPart(masterR1c);
        }

        if (docAssemblyOptions.isIncludeMasterR1d())
        {
          log.trace("Including master R1D...");
          masterR1d = mjb.getR1d();
          pg3.addJbPart(masterR1d);
        }
      }
      if (docAssemblyOptions.isGenerateR1Summary())
      {
        log.trace("Creating R1 Summary...");
        createR1SummaryPdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1())
      {
        log.trace("Creating R1...");
        createR1Pdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1c())
      {
        log.trace("Creating R1C...");
        createR1cPdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1d())
      {
        log.trace("Creating R1D...");
        createR1dPdf(pg3);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterP1())
        {
          log.trace("Including master P1...");
          masterP1 = mjb.getP1();
          pg3.addJbPart(masterP1);
        }
        if (docAssemblyOptions.isIncludeMasterP1m())
        {
          log.trace("Including master P1m...");
          masterP1m = mjb.getP1m();
          pg3.addJbPart(masterP1m);
          log.trace("... included master P1m");
        }
      }
      if (docAssemblyOptions.isGenerateP1())
      {
        log.trace("Creating P1...");
        createP1Pdf(pg3);
      }
      if (docAssemblyOptions.isGenerateP1m())
      {
        log.trace("Creating P1m...");
        createP1mPdf(pg3);
      }
    }

    if (supplementalDocCollection != null)
    {
      log.trace("Preparing user supplied supplemental docs...");
      prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg3);
      supplementalDocCollection.setPdfStartPage(supplementalDocCollection.getSupplementalDocList().get(0).getPdfStartPage());
      supplementalDocCollection.setPdfPaginationGroup(pg3);
    }

    log.trace("Preparing user supplied acronyms doc...");
    prepareUserSuppliedDoc(acronymDoc, pg3);

    if (r2sExist())
    {
      log.trace("Creating R2's...");
      createR2Pdfs(pg3);
    }

    if (lineItemsExist())
    {
      log.trace("Creating P40's...");
      createP40Pdfs(pg3);
    }

    log.trace("Creating TOC...");
    createToc(pg2);

  }

  public void populatePaginationGroupsCont(PaginationGroup pg1, PaginationGroup pg2, PaginationGroup pg3, PaginationGroup pg4) throws IOException, DocumentException, SQLException
  {
    log.trace("Popuating pagination groups...");

    log.trace("Creating cover...");
    createCoverPdf(pg1);

    if (r2sExist())
      createInitialR2PageNumberKvp();

    if (lineItemsExist())
      createInitialP40PageNumberKvp();

    if (multiYearProcurementsExist())
      createInitialMYPPageNumberKvp();

    log.trace("Preparing user supplied cost doc...");
    prepareUserSuppliedDoc(costDoc, pg3);

    log.trace("Preparing user supplied introduction doc...");
    prepareUserSuppliedDoc(introductionDoc, pg3);

    log.trace("Preparing user supplied comptroller r1 doc...");
    prepareUserSuppliedDoc(userR1Doc, pg3);

    log.trace("Preparing user supplied comptroller p1 doc...");
    prepareUserSuppliedDoc(userP1Doc, pg3);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterProgramElementTocByBA())
        {
          log.trace("Adding master PE TOC by BA #...");
          masterPeTocByBa = mjb.getPeTocByBa();
          pg3.addJbPart(masterPeTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterProgramElementTocByTitle())
        {
          log.trace("Adding master PE TOC by PE Title...");
          masterPeTocByTitle = mjb.getPeTocByTitle();
          pg3.addJbPart(masterPeTocByTitle);
        }
      }
      if (docAssemblyOptions.isGenerateProgramElementTocByBA())
      {
        log.trace("Creating PE TOC by BA #...");
        createPeTocByBa(pg3);
      }
      if (docAssemblyOptions.isGenerateProgramElementTocByTitle())
      {
        log.trace("Creating PE TOC by PE Title...");
        createPeTocByTitle(pg3);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterLineItemTocByBA())
        {
          log.trace("Adding master LI TOC by BA #...");
          masterLiTocByBa = mjb.getLiTocByBa();
          pg3.addJbPart(masterLiTocByBa);
        }

        if (docAssemblyOptions.isIncludeMasterLineItemTocByTitle())
        {
          log.trace("Adding master LI TOC by LI Title...");
          masterLiTocByTitle = mjb.getLiTocByTitle();
          pg3.addJbPart(masterLiTocByTitle);
        }
      }
      if (docAssemblyOptions.isGenerateLineItemTocByBA())
      {
        log.trace("Creating LI TOC by BA #...");
        createLiTocByBa(pg3);
      }
      if (docAssemblyOptions.isGenerateLineItemTocByTitle())
      {
        log.trace("Creating LI TOC by LI Title...");
        createLiTocByTitle(pg3);
      }
    }

    log.trace("Preparing user supplied summary doc...");
    prepareUserSuppliedDoc(summaryDoc, pg3);

    if (r2sExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterR1Summary())
        {
          log.trace("Including master R1 Summary...");
          masterR1Summary = mjb.getR1Summary();
          pg3.addJbPart(masterR1Summary);
        }

        if (docAssemblyOptions.isIncludeMasterR1())
        {
          log.trace("Including master R1...");
          masterR1 = mjb.getR1();
          pg3.addJbPart(masterR1);
        }

        if (docAssemblyOptions.isIncludeMasterR1c())
        {
          log.trace("Including master R1C...");
          masterR1c = mjb.getR1c();
          pg3.addJbPart(masterR1c);
        }

        if (docAssemblyOptions.isIncludeMasterR1d())
        {
          log.trace("Including master R1D...");
          masterR1d = mjb.getR1d();
          pg3.addJbPart(masterR1d);
        }
      }
      if (docAssemblyOptions.isGenerateR1Summary())
      {
        log.trace("Creating R1 Summary...");
        createR1SummaryPdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1())
      {
        log.trace("Creating R1...");
        createR1Pdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1c())
      {
        log.trace("Creating R1C...");
        createR1cPdf(pg3);
      }
      if (docAssemblyOptions.isGenerateR1d())
      {
        log.trace("Creating R1D...");
        createR1dPdf(pg3);
      }
    }

    if (lineItemsExist())
    {
      if (mjb != null && !mjb.getDocAssemblyOptions().isUseLegacyMJBFormat())
      {
        if (docAssemblyOptions.isIncludeMasterP1())
        {
          log.trace("Including master P1...");
          masterP1 = mjb.getP1();
          pg3.addJbPart(masterP1);
        }
        if (docAssemblyOptions.isIncludeMasterP1m())
        {
          log.trace("Including master P1m...");
          masterP1m = mjb.getP1m();
          pg3.addJbPart(masterP1m);
          log.trace("... included master P1m");
        }
      }
      if (docAssemblyOptions.isGenerateP1())
      {
        log.trace("Creating P1...");
        createP1Pdf(pg3);
      }
      if (docAssemblyOptions.isGenerateP1m())
      {
        log.trace("Creating P1m...");
        createP1mPdf(pg3);
      }
    }

    if (supplementalDocCollection != null)
    {
      log.trace("Preparing user supplied supplemental docs...");
      prepareUserSuppliedDoc(supplementalDocCollection.getSupplementalDocList(), pg3);
      supplementalDocCollection.setPdfStartPage(supplementalDocCollection.getSupplementalDocList().get(0).getPdfStartPage());
      supplementalDocCollection.setPdfPaginationGroup(pg3);
    }

    log.trace("Preparing user supplied acronyms doc...");
    prepareUserSuppliedDoc(acronymDoc, pg3);

    if (r2sExist())
    {
      log.trace("Creating R2's...");
      createR2Pdfs(pg3);
    }

    if (lineItemsExist())
    {
      log.trace("Creating P40's...");
      createP40Pdfs(pg3);
    }

    if (multiYearProcurementsExist())
    {
      log.trace("Creating P40's...");
      createMYPPdfs(pg4);
      pg4.adjustStartPages(pg3.getTotalPageCount());
    }

    log.trace("Creating TOC...");
    createToc(pg2);

  }

  public void finalizePaginationGroups() throws IOException, DocumentException, SQLException
  {
    int startPageOffset = pdfPageOffset;

    log.trace("Adjusting start page numbers for all items in all pagination groups...");
    for (PaginationGroup pg : pgList)
    {
      pg.adjustStartPages(startPageOffset);
      startPageOffset += pg.getTotalPageCount();
    }

    if (r2sExist())
    {
      log.trace("Regenerating R2 page # KVP list...");

      updateR2PageNumberKvp();
      Util.dumpKvpList(r2PageNumberKvpList);
      if (peTocByBa != null)
      {
        peTocByBa.removeContent();
        createPeTocByBa(null);
      }

      if (peTocByTitle != null)
      {
        peTocByTitle.removeContent();
        createPeTocByTitle(null);
      }

    }

    if (lineItemsExist())
    {
      log.trace("Regenerating LI page # KVP list...");

      updateP40PageNumberKvp();
      Util.dumpKvpList(p40PageNumberKvpList);
      if (liTocByBa != null)
      {
        liTocByBa.removeContent();
        createLiTocByBa(null);
      }

      if (liTocByTitle != null)
      {
        liTocByTitle.removeContent();
        createLiTocByTitle(null);
      }

      if (multiYearProcurementsExist())
      {
        log.trace("Regenerating MYP page # KVP list...");

        updateMYPPageNumberKvp();
        Util.dumpKvpList(mypPageNumberKvpList);
      }

    }

    log.trace("Re-creating TOC...");
    createToc(null);

  }


  protected void createInitialR2PageNumberKvp()
  {
    r2PageNumberKvpList = new ArrayList<KeyValuePair>();

    for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits())
    {
      String r2Id = r2Exhibit.getBusinessId();
      KeyValuePair kvp = new KeyValuePair(r2Id, "0");
      r2PageNumberKvpList.add(kvp);
    }
  }


  protected void updateR2PageNumberKvp()
  {
    int index = 0;
    for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits())
    {
      String r2Id = r2Exhibit.getBusinessId();
      KeyValuePair kvp = r2PageNumberKvpList.get(index);
      assert r2Id.equals(kvp.getKey());
      String pageNumberText = Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(r2Exhibit.getPdfStartPage()));
      kvp.setValue(pageNumberText);
      ++index;
    }
  }


  protected void createInitialP40PageNumberKvp()
  {
    p40PageNumberKvpList = new ArrayList<KeyValuePair>();

    for (LineItemWrapper lineItem : lineItemList.getLineItems())
    {
      String liId = lineItem.getBusinessId() + "_TITLE-" + lineItem.getLineItem().getLineItemTitle();
      if (false == lineItem.getLineItem().isAPP40Standalone()){
        p40PageNumberKvpList.add(new KeyValuePair(liId , "0"));
      }
      if (lineItem.getLineItem().hasAdvanceProcurement()){
        p40PageNumberKvpList.add(new KeyValuePair("AP" + liId , "0"));
      }
    }
  }


  protected void updateP40PageNumberKvp()
  {
    int pageNumberKvpIndex = 0;
    int lineItemIndex = 0;
    while(pageNumberKvpIndex < p40PageNumberKvpList.size())
    {
      LineItemWrapper lineItemWrapper = lineItemList.getLineItems().get(lineItemIndex);

      if (false == lineItemWrapper.getLineItem().isAPP40Standalone()){
        KeyValuePair kvp = p40PageNumberKvpList.get(pageNumberKvpIndex);
        kvp.setValue(Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(lineItemWrapper.getPdfStartPage())));
        log.trace("setting advance kvp: " + kvp.getKey() + ";  startPage: " + lineItemWrapper.getPdfStartPage());

        ++pageNumberKvpIndex;
      }

      if(lineItemWrapper.getLineItem().hasAdvanceProcurement())
      {
        KeyValuePair apKvp = p40PageNumberKvpList.get(pageNumberKvpIndex);
        apKvp.setValue(Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(
            lineItemWrapper.getPdfStartPage() + (lineItemWrapper.getLineItem().isAPP40Standalone()? 0:lineItemWrapper.getPdfTotalPageCount()))));
        log.trace("setting advance kvp: " + apKvp.getKey() + ";  startPage: " + lineItemWrapper.getPdfStartPage() + "; totalpageCount: " + lineItemWrapper.getPdfTotalPageCount() +"; adtotal pages: " + lineItemWrapper.getLineItem().getAdvanceProcurementTotalPages());
        ++pageNumberKvpIndex;
      }
      ++lineItemIndex;
    }
  }


  protected void createInitialMYPPageNumberKvp()
  {
    mypPageNumberKvpList = new ArrayList<KeyValuePair>();

    for (MultiYearProcurement myp : multiYearProcurementList.getMultiYearProcurements())
    {
      String mypID = myp.getBusinessId() + "_TITLE-" + myp.getSystemName();
      mypPageNumberKvpList.add(new KeyValuePair(mypID , "0"));
    }
  }


  protected void updateMYPPageNumberKvp()
  {
    int pageNumberKvpIndex = 0;
    int mypIndex = 0;
    while(pageNumberKvpIndex < mypPageNumberKvpList.size())
    {
      MultiYearProcurement multiYearProcurement = multiYearProcurementList.getMultiYearProcurements().get(mypIndex);
      KeyValuePair kvp = mypPageNumberKvpList.get(pageNumberKvpIndex);
      kvp.setValue(Util.addPrefix(getPageNumberPrefix(), Util.formatJbPageNumber(multiYearProcurement.getPdfStartPage())));
      log.trace("setting advance kvp: " + kvp.getKey() + ";  startPage: " + multiYearProcurement.getPdfStartPage());

      ++pageNumberKvpIndex;
      ++mypIndex;
    }
  }


  @Override
  protected boolean showWarningMessage(PaginationGroup pg) {
      return ((mjb != null && mjb.showWarningMessage(pg)) || (super.showWarningMessage(pg) && (mjb == null || !mjb.getServiceAgency().isSuppressPdfWarning())));
  }
  
  @Override
  protected boolean showPrePrcpMessage(PaginationGroup pg) {
      return (null != mjb && mjb.isHasWarnings() && mjb.isOnlyPrcpWarnings()); 
  }


  @Override
  public EmbedableFile createEmbedableZipFile(File zipFile)
  {
    return new DefaultEmbedableFile(FileUtil.createZzzFileName(getBusinessId()), "Justification Book Zip File (save & rename to .zip to open)", zipFile);
  }


  public JustificationBookInfo getJbi()
  {
    return jbi;
  }


  public void setJbi(JustificationBookInfo jbi)
  {
    this.jbi = jbi;
  }


  public MasterJustificationBook getMjb()
  {
    return mjb;
  }


  public void setMjb(MasterJustificationBook mjb)
  {
    this.mjb = mjb;
  }


  public boolean isStandalone()
  {
    return standalone;
  }


  public void setStandalone(boolean standalone)
  {
    this.standalone = standalone;
  }


  public GenericToc getMasterVolumeToc()
  {
    return masterVolumeToc;
  }


  public void setMasterVolumeToc(GenericToc masterVolumeToc)
  {
    this.masterVolumeToc = masterVolumeToc;
  }


  public JBPeToc getMasterPeTocByBa()
  {
    return masterPeTocByBa;
  }


  public void setMasterPeTocByBa(JBPeToc masterPeTocByBa)
  {
    this.masterPeTocByBa = masterPeTocByBa;
  }


  public JBPeToc getMasterPeTocByTitle()
  {
    return masterPeTocByTitle;
  }


  public void setMasterPeTocByTitle(JBPeToc masterPeTocByTitle)
  {
    this.masterPeTocByTitle = masterPeTocByTitle;
  }


  public R1Summary getMasterR1Summary()
  {
    return masterR1Summary;
  }


  public void setMasterR1Summary(R1Summary masterR1Summary)
  {
    this.masterR1Summary = masterR1Summary;
  }


  public R1 getMasterR1()
  {
    return masterR1;
  }


  public void setMasterR1(R1 masterR1)
  {
    this.masterR1 = masterR1;
  }


  public R1C getMasterR1c()
  {
    return masterR1c;
  }


  public void setMasterR1c(R1C masterR1c)
  {
    this.masterR1c = masterR1c;
  }


  public R1D getMasterR1d()
  {
    return masterR1d;
  }


  public void setMasterR1d(R1D masterR1d)
  {
    this.masterR1d = masterR1d;
  }


  public JBLiToc getMasterLiTocByBa()
  {
    return masterLiTocByBa;
  }


  public void setMasterLiTocByBa(JBLiToc masterLiTocByBa)
  {
    this.masterLiTocByBa = masterLiTocByBa;
  }


  public JBLiToc getMasterLiTocByTitle()
  {
    return masterLiTocByTitle;
  }


  public void setMasterLiTocByTitle(JBLiToc masterLiTocByTitle)
  {
    this.masterLiTocByTitle = masterLiTocByTitle;
  }


  public P1 getMasterP1()
  {
    return masterP1;
  }


  public void setMasterP1(P1 masterP1)
  {
    this.masterP1 = masterP1;
  }


  public P1M getMasterP1m()
  {
    return masterP1m;
  }


  public void setMasterP1m(P1M masterP1m)
  {
    this.masterP1m = masterP1m;
  }

  public String getClassificationLabel()
  {
      return Util.getClassificationLabel();
  }

  public void dumpPaginationGroups()
  {
    StringBuilder sb = new StringBuilder();
    int index = 0;
    for (PaginationGroup pg : pgList)
    {
      sb.append("\nPagination Group " + index++);
      for (JBPart jbPart : pg.getJbPartList())
      {
        sb.append("\n\tJB Part: " + jbPart.getTitle() + ", start page = " + jbPart.getPdfStartPage() + ", " + jbPart.getPdfTotalPageCount() + ", " + jbPart.getAbsoluteFileName() + ")");
      }
    }
    log.trace(sb);
  }

  @Override
  public byte[] toXml(InvalidXMLListener l) throws IOException {
    byte[] xmlData = JavaToXml.toXml(this);
    XmlUtil.sanityValidateXml(xmlData, l);
    return xmlData;
  }

}



