package mil.dtic.cbes.p40.vo;


/**
 *
 */
public interface HasTotalCosts extends HasContinuing
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    Costs getTotalCosts();

 
    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasTotalCost();
    
    public void jibx_setTotalCosts(Costs c);


}
