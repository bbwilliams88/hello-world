package mil.dtic.cbes.p40.vo;

import java.util.Date;

import mil.dtic.cbes.enums.DateAlternateOptionsType;

public class DateWithOptions extends Date
{
  /**
   * This class is used for P-35 SCN Date fields to support other options besides dates, such as "Various" or "TBD".
   */

  private static final long serialVersionUID = 1L;
  private DateAlternateOptionsType option;
  
  public DateWithOptions()
  {
    super();
  }
  
  public DateWithOptions(Long date)
  {
    super(date);
  }
  
  public void setOption(DateAlternateOptionsType option)
  {
    this.option = option;
  }
  
  public DateAlternateOptionsType getOption()
  {
    return this.option;
  }
}
