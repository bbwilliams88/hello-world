package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._SubmissionDate;

public class SubmissionDate extends _SubmissionDate {

}
