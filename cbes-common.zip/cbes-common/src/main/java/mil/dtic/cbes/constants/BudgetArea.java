package mil.dtic.cbes.constants;

public enum BudgetArea {
	RDTE("Research, Developement, Test, and Evaluation", "RDTE"),
	PROC("Procurment", "PROC");
	
	private String name;
	private String code;
	
	private BudgetArea(String name, String code) {
		this.name = name;
		this.code = code;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getCode() {
		return this.code;
	}
}
