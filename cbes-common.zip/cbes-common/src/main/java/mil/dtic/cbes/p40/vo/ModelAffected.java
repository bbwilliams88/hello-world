package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.p40.vo.auto._ModelAffected;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

/**
 *
 */
public class ModelAffected extends _ModelAffected implements Equivalence<ModelAffected>
{
    private static final long serialVersionUID = 1L;

    @Override
    public void onPostAdd()
    {
      setDisplayOrder(0);
    }
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
    
    @Override
    public int equivalenceHashCode() {
      return new HashCodeBuilder().append(toLowerAndTrim(getTitle())).toHashCode();
    }

    @Override
    public boolean equivalentTo(ModelAffected other) {
      return new EqualsBuilder().append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle())).isEquals();
    }
}
