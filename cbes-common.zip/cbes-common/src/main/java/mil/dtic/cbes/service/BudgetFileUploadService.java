package mil.dtic.cbes.service;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;


import mil.dtic.cbes.submissions.ValueObjects.UploadedBudgetFile;

public interface BudgetFileUploadService<F extends UploadedBudgetFile> {
    
    public static int RFR_DECRYPT_VALUE = 22;

	void saveNewFile(File file, String fileName,
			String userName, String description, Date date) throws ValidationException, IOException;

	List<F> getAllFiles();
	
	List<F> getAllFiles(Boolean b);
	
	F getLatestFile();
	
	F getFile(Integer id);
	
	void deleteFile(Integer id);

}