package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectMilestone;

public class ProductionSupportFacilityProjectMilestone extends _ProductionSupportFacilityProjectMilestone
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0); //not used
  }

  public void shiftForwardInTime(int years)
  {

  }
}
