package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._OtherPe;

public class OtherPe extends _OtherPe
{
    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasPENumber()
    {
        return StringUtils.isNotEmpty(getProgramElementNumber());
    }
    
    public boolean jibx_hasPEFunding()
    {
        return jibx_hasQuantity() || jibx_hasTotalCost();
    }
}
