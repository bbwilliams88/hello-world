package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._ShipCharacteristics;

/**
 *
 */
public class ShipCharacteristics extends _ShipCharacteristics
{
    private static final long serialVersionUID = 1L;
    
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.
    

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    
    public boolean jibx_hasShipOne()
    {
      return jibx_hasShipOneHeader() || jibx_hasShipOneLength() || jibx_hasShipOneBeam() || jibx_hasShipOneDisplacement() || jibx_hasShipOneDraft();
    }
    
    public boolean jibx_hasShipTwo()
    {
      return jibx_hasShipTwoHeader() || jibx_hasShipTwoLength() || jibx_hasShipTwoBeam() || jibx_hasShipTwoDisplacement() || jibx_hasShipTwoDraft();
    }
    
    public boolean jibx_hasShipOneHeader()
    {
      return StringUtils.isNotEmpty(getShipOneHeader());
    }
    
    public boolean jibx_hasShipTwoHeader()
    {
      return StringUtils.isNotEmpty(getShipTwoHeader());
    }
    
    public boolean jibx_hasShipOneLength()
    {
      return StringUtils.isNotEmpty(getShipOneLength());
    }
    
    public boolean jibx_hasShipTwoLength()
    {
      return StringUtils.isNotEmpty(getShipTwoLength());
    }
    
    public boolean jibx_hasShipOneBeam()
    {
      return StringUtils.isNotEmpty(getShipOneBeam());
    }
    
    public boolean jibx_hasShipTwoBeam()
    {
      return StringUtils.isNotEmpty(getShipTwoBeam());
    }
    
    public boolean jibx_hasShipOneDisplacement()
    {
      return StringUtils.isNotEmpty(getShipOneDisplacement());
    }
    
    public boolean jibx_hasShipTwoDisplacement()
    {
      return StringUtils.isNotEmpty(getShipTwoDisplacement());
    }
    
    public boolean jibx_hasShipOneDraft()
    {
      return StringUtils.isNotEmpty(getShipOneDraft());
    }
    
    public boolean jibx_hasShipTwoDraft()
    {
      return StringUtils.isNotEmpty(getShipTwoDraft());
    }
    
    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
