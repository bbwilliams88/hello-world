package mil.dtic.cbes.p40.vo;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ResourceSummaryEntryType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._P40aCategory;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.Util;

public class P40aCategory extends _P40aCategory implements HasDisplayOrder, Equivalence<P40aCategory>, HasTotalCosts, IsSubtotalParent, RollupParent
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
        setupP40aCategory();
    }

    @Override
    protected void onPostLoad()
    {
        setupP40aCategory();
    }

    @Override
    protected void onPrePersist()
    {
      Util.cleanupContinuingTotal(this);
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public void clearOutYears()
    {
        for (Item item : getItems())
        {
            item.clearOutYears();
            // Clear each Category's Item UC/Q/TC.
//            Costs.clearOutYears(item.getResourceSummary().getGrossWeaponSystemUnitCost().getCosts());
//            Costs.clearOutYears(item.getResourceSummary().getQuantity().getCosts());
//            Costs.clearOutYears(item.getResourceSummary().getGrossWeaponSystemCost().getCosts());
        }

        Costs.clearOutYears(getUnitCosts());
        Costs.clearOutYears(getQuantities());
        Costs.clearOutYears(getTotalCosts());

    }

    protected void setupP40aCategory()
    {
        if (getTotalCosts() == null)
            setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        for (Item item : this.getItems())
        {
            item.shiftForwardInTime(years);
        }
        if (getCosts() != null)
          getCosts().shiftForwardInTime(years);
    }

    public List<Item> getOrderedItems()
    {
        return getSortedByDisplayOrder(getItems());
    }

    public Item addItem()
    {
        Item item = getObjectContext().newObject(Item.class);

        for (ResourceSummaryEntryType entryType : ResourceSummaryEntryType.baseRows)
            item.addToResourceSummaryRows(ResourceSummaryRow.create(getObjectContext(), entryType));

        addToItems(item);

        Util.generateDisplayOrder(getItems());

        return item;
    }

    public void addItem(Item item)
    {
    	item.setDisplayOrder(Util.getNextDisplayOrderValue(getOrderedItems()));
    	addToItems(item);
    }

    public String getDisplayTitle()
    {
        if ("".equals(getTitle()))
            return "Uncategorized";
        else if (getTitle() == null)
            return "Uncategorized";
        else
            return getTitle();
    }

    public void setDisplayTitle(String newVal)
    {
        if ("Uncategorized".equals(newVal))
            setTitle("");
        if (newVal == null)
            setTitle("");
        else
            setTitle(newVal);
    }

    // FIXME: Call this deleteItem since it does more than remove.
    public void removeItem(Item i)
    {
        removeFromItems(i);
        getObjectContext().deleteObjects(i);
    }

    @Override
    public int equivalenceHashCode()
    {
        return new HashCodeBuilder().append(toLowerAndTrim(getTitle())).toHashCode();
    }

    @Override
    public boolean equivalentTo(P40aCategory other)
    {
        return new EqualsBuilder().append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle())).isEquals();
    }

    /**
     * Sets the Category's Total Costs (the category subtotal) to the sum of all
     * the Item's Costs
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    @Override
    public void calculateSubtotals() throws MethodDispatchException
    {
//        boolean isAnyItemContinuing = false;
        Costs   subtotalCosts       = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
        addToSubtotalInDollars(subtotalCosts, getItems());
//        for (Item item : getItems())
//        {
//            subtotalCosts =
//                addChildToSubtotal(subtotalCosts,
//                                   CostUtil.getCalculatedCosts(item.getCosts(),
//                                                               item.getUnitCosts(),
//                                                               item.getQuantities(),
//                                                               getParentLineItem().getQuantityUnits(),
//                                                               getParentLineItem().getUnitCostUnits(),
//                                                               getParentLineItem().getTotalCostUnits()));
//
//            if (isChildContinuing(getItems()))
//                isAnyItemContinuing = true;
//        }
//
//        subtotalCosts.setContinuing(isAnyItemContinuing);
        replaceCosts(setSubtotalValuesInMillion(subtotalCosts), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
    }

    @Override
    public List<? extends CostContainer> getChildren()
    {
      return getItems();
    }

    @Override
    public Costs getCosts()
    {
      return getTotalCosts();
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // FIXME: Call this jibx_hasItems()?  Or better yet, make it beans-compliant.
    public boolean jibx_hasItem()
    {
        return getItems().size() > 0;
    }

    @Override
    public boolean isContinuing()
    {
        if(getTotalCosts() != null)
          return getTotalCosts().isContinuing();
        return false;
    }


    @Override
    public boolean jibx_hasTotalCost()
    {
        if (getTotalCosts() != null)
            return true;

        return false;
    }


    @Override
    public String jibx_getContinuingFootnote()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void jibx_setContinuingFootnote(String s)
    {
        // TODO Auto-generated method stub

    }

    public Iterator<Item> jibx_itemIterator()
    {
        return getIterator(getOrderedItems());
    }

    // test method is here to make "" an allowable value that generates no tag
    public boolean jibx_hasTitle()
    {
        return StringUtils.isNotEmpty(getTitle());
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(getItems());
    }

    @Override
    public void jibx_setTotalCosts(Costs totalCosts)
    {
        if (totalCosts != null)
            setTotalCosts(totalCosts);
    }

    @Override
    public Costs getQuantities()
    {
      return null;
    }

    @Override
    public Costs getUnitCosts()
    {
      return null;
    }
}
