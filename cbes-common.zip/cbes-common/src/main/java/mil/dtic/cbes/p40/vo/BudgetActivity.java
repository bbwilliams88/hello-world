package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._BudgetActivity;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

/**
 *
 */
public class BudgetActivity extends _BudgetActivity implements Equivalence<BudgetActivity>
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return The <b>active</b> BSAs for this BA.
     */
    public List<BudgetSubActivity> getActiveBudgetSubActivityList()
    {
        Expression exp = ExpressionFactory.matchExp(BudgetSubActivity.STATUS_PROPERTY, StatusType.ACTIVE);

        return exp.filterObjects(getBudgetSubActivityList());
    }

    /**
     * @return The Budget Activity's number and and title, separated by a dash.
     *         Useful for labels in T5 dropdown lists.
     */
    public String getNumberPlusTitle()
    {
        return getNumber() + " - " + getTitle();
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * @param serviceAgency
     *            The service or agency the Budget Activity must belong to.
     * @return A list of all Budget Activities that match the given service or
     *         agency.
     */
    public static List<BudgetActivity> fetchForAgency(ServiceAgency serviceAgency)
    {
        return fetch(serviceAgency.getObjectContext(),
                     BudgetActivity.class,
                     Expression.IN,
                     new Ordering[0],
                     makePath(BudgetActivity.APPROPRIATION_RELATIONSHIP_PROPERTY,
                              Appropriation.SERVICE_AGENCY_LIST_RELATIONSHIP_PROPERTY),
                     new ServiceAgency[] { serviceAgency });
    }

    /**
     * @param context Cayenne ObjectContext to fetch the BA into.
     * @param appropriation BA Appropriation to match.
     * @param number BA Number to match.
     * @return The BA matching the given BA Appropriation and BA Number.
     */
    public static BudgetActivity fetchWithAppropriationAndNumber(ObjectContext context, Appropriation appropriation, String number)
    {
      return Base.fetchOne(context,
                           BudgetActivity.class,
                           BudgetActivity.APPROPRIATION_RELATIONSHIP_PROPERTY,
                           BudgetActivity.NUMBER_PROPERTY,
                           appropriation,
                           number);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getTitle()));
        builder.append(getNumber());
        builder.append(getAppropriation());

        return builder.toHashCode();
    }

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(BudgetActivity obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        BudgetActivity other   = obj;
        EqualsBuilder  builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
        builder.append(getNumber(), other.getNumber());
        builder.append(getAppropriation(), other.getAppropriation());

        return builder.isEquals();
    }
}
