package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ShipCategoryItemType;
import mil.dtic.cbes.p40.vo.auto._ShipCostCategory;

/**
 *
 */
public class ShipCostCategory extends _ShipCostCategory
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.
    private List<ShipCategoryItem> getItemsByType(ShipCategoryItemType type)
    {
      List<ShipCategoryItem> itemList = new ArrayList<ShipCategoryItem>();
      for (ShipCategoryItem item : getShipCategoryItems())
        if (item.getType().equals(type))
          itemList.add(item);
      return itemList;
    }
    
    private void addToItemsByType(ShipCategoryItem item, ShipCategoryItemType type)
    {
      if (type == null)
        throw new IllegalArgumentException("You MUST provide a type for the Ship Category Item object.");
      
      if (item != null)
      {
        item.setType(type);
        addToShipCategoryItems(item);
      }
    }
    
    public void addToP35Items(ShipCategoryItem item)
    {
      addToItemsByType(item, ShipCategoryItemType.P35);
    }
    
    public void addToMajorItems(ShipCategoryItem item)
    {
      addToItemsByType(item, ShipCategoryItemType.MAJOR_ITEM);
    }
    
    public void addToCostElements(ShipCategoryItem item)
    {
      addToItemsByType(item, ShipCategoryItemType.COST_ELEMENT);
    }
    
    public List<ShipCategoryItem> getP35Items()
    {
      return getItemsByType(ShipCategoryItemType.P35);
    }
    
    public List<ShipCategoryItem> getMajorItems()
    {
      return getItemsByType(ShipCategoryItemType.MAJOR_ITEM);
    }
    
    public List<ShipCategoryItem> getCostElements()
    {
      return getItemsByType(ShipCategoryItemType.COST_ELEMENT);
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public void jibx_setTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setTotalCost(totalCost);
      }
    }
    
    public void jibx_setQuantity(ExtendedPYSCosts quantity)
    {
      if (quantity != null)
      {
        quantity.setType(CostRowType.QUANTITY);
        super.setQuantity(quantity);
      }
    }
    
    public void jibx_setP8aTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setP8aTotalCost(totalCost);
      }
    }
    
    public void jibx_setP8aTotalQuantity(ExtendedPYSCosts quantity)
    {
      if (quantity != null)
      {
        quantity.setType(CostRowType.QUANTITY);
        super.setP8aTotalQuantity(quantity);
      }
    }
    
    public boolean jibx_hasTotalCost()
    {
      return getTotalCost() != null;
    }
    
    public boolean jibx_hasQuantity()
    {
      return getQuantity() != null;
    }
        
    public boolean jibx_hasCategorySubtotal()
    {
      return jibx_hasTotalCost() || jibx_hasQuantity(); 
    }
    
    public boolean jibx_hasP8aTotalCost()
    {
      return getP8aTotalCost() != null;
    }
    
    public boolean jibx_hasP8aTotalQuantity()
    {
      return getP8aTotalQuantity() != null;
    }
        
    public boolean jibx_hasP8aTotal()
    {
      return jibx_hasP8aTotalCost() || jibx_hasP8aTotalQuantity(); 
    }
    
    public boolean jibx_hasName()
    {
      return StringUtils.isNotEmpty(getName());
    }
    
    public boolean jibx_hasCostElementAnalysis()
    {
      return jibx_hasP35Items()           ||
             jibx_hasMajorItems()         ||
             jibx_hasCostElements()       ||
             jibx_hasP35TotalCost()       ||
             jibx_hasMajorItemTotalCost() ||
             jibx_hasOtherCostElementTotalCost();
    }
    
    public boolean jibx_hasP35Items()
    {
      return CollectionUtils.isNotEmpty(getP35Items());
    }
    
    public boolean jibx_hasMajorItems()
    {
      return CollectionUtils.isNotEmpty(getMajorItems());
    }
    
    public boolean jibx_hasCostElements()
    {
      return CollectionUtils.isNotEmpty(getCostElements());
    }
    
    public Iterator<ShipCategoryItem> jibx_p35ItemIterator()
    {
      return getP35Items().iterator();
    }
    
    public Iterator<ShipCategoryItem> jibx_majorItemIterator()
    {
      return getMajorItems().iterator();
    }
    
    public Iterator<ShipCategoryItem> jibx_costElementIterator()
    {
      return getCostElements().iterator();
    }
    
    public boolean jibx_hasP35TotalCost()
    {
      return getP35TotalCost() != null;
    }
    
    public boolean jibx_hasMajorItemTotalCost()
    {
      return getMajorItemTotalCost() != null;
    }
    
    public boolean jibx_hasOtherCostElementTotalCost()
    {
      return getOtherCostElementTotalCost() != null;
    }
    
    public void jibx_setP35TotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setP35TotalCost(totalCost);
      }
    }
    
    public void jibx_setMajorItemTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setMajorItemTotalCost(totalCost);
      }
    }
    
    public void jibx_setOtherCostElementTotalCost(ExtendedPYSCosts totalCost)
    {
      if (totalCost != null)
      {
        totalCost.setType(CostRowType.TOTALCOST);
        super.setOtherCostElementTotalCost(totalCost);
      }
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
