package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;



public class CostListImpl
{
  private BigDecimal priorYears;
  private BigDecimal priorYear;
  private BigDecimal currentYear;
  private BigDecimal by1Base;
  private BigDecimal by1Ooc;
  private BigDecimal by1;
  private BigDecimal by2;
  private BigDecimal by3;
  private BigDecimal by4;
  private BigDecimal by5;
  
  
  public BigDecimal getPriorYears()
  {
    return priorYears;
  }
  public void setPriorYears(BigDecimal priorYears)
  {
    this.priorYears = priorYears;
  }
  public BigDecimal getPriorYear()
  {
    return priorYear;
  }
  public void setPriorYear(BigDecimal priorYear)
  {
    this.priorYear = priorYear;
  }
  public BigDecimal getCurrentYear()
  {
    return currentYear;
  }
  public void setCurrentYear(BigDecimal currentYear)
  {
    this.currentYear = currentYear;
  }
  public BigDecimal getBy1Base()
  {
    return by1Base;
  }
  public void setBy1Base(BigDecimal by1Base)
  {
    this.by1Base = by1Base;
  }
  public BigDecimal getBy1Ooc()
  {
    return by1Ooc;
  }
  public void setBy1Ooc(BigDecimal by1Ooc)
  {
    this.by1Ooc = by1Ooc;
  }
  public BigDecimal getBy1()
  {
    return by1;
  }
  public void setBy1(BigDecimal by1)
  {
    this.by1 = by1;
  }
  public BigDecimal getBy2()
  {
    return by2;
  }
  public void setBy2(BigDecimal by2)
  {
    this.by2 = by2;
  }
  public BigDecimal getBy3()
  {
    return by3;
  }
  public void setBy3(BigDecimal by3)
  {
    this.by3 = by3;
  }
  public BigDecimal getBy4()
  {
    return by4;
  }
  public void setBy4(BigDecimal by4)
  {
    this.by4 = by4;
  }
  public BigDecimal getBy5()
  {
    return by5;
  }
  public void setBy5(BigDecimal by5)
  {
    this.by5 = by5;
  }
  
  
  
}