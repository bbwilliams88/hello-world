/*
 * $Id: JBPeToc.java 44901 2010-08-15 23:22:47Z aibrahim $
 */
package mil.dtic.cbes.jb;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;


public class JBLiToc extends JBPeToc
{
  private static final Logger log = CbesLogFactory.getLog(JBLiToc.class);

  public JBLiToc(FileSetting pdfFileSetting, String titlePrefix)
  {
    super(pdfFileSetting, titlePrefix);
  }
}
