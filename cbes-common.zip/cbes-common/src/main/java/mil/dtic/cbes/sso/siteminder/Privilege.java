package mil.dtic.cbes.sso.siteminder;


public enum Privilege
{
  BASIC_USER,         //Access to basic user pages
  
  EXHIBITLIST_SHOW_SET_WRITEABLE, //button next to full pdf/xml
  SHOW_MODIFYING_USER, //Created/Modified by columns in pe lists
  MANAGE_USERS,       //Allow mgmt of R2Users in organization(s)
  MANAGE_ANALYST_USERS, //Allow management of analyst users
  FREEZE_PE,          //entire pe lock
  
  MANAGE_LOCAL_ADMINS,//Allow mgmt of R2LocalSiteAdmin41s in organization(s)
  SHOW_ALL_PES_IN_AGENCY,//PE lists will always show all the PEs in the org regardless of perms
  EDIT_ALL_PES_IN_AGENCY,//Full control over any PEs in agency
  ALWAYS_CAN_CREATE,  //createPeAllowed flag will have no effect
  R1PAGE,             // PRPC page access
  TRACK_ASYNC_JOBS_FOR_OWN_AGENCIES, // Can see all async jobs for own agencies
  LOGODEFAULT,        //Set default logos for JB
  
  SHOW_ADMIN_TOOLS,   //Can access Admin Tools page
  MANAGE_ALL_USERS,   //All users show up in user admin pages
  SHOW_TEST_PE,       //Whether to show test pes
  ADD_USER_NO_ORG,    //is adding a user w/o selecting an organization allowed. also controls adding of D flagged users
  SHOW_ALL_PES,       //PE lists will show all PEs in the db, test pes are optional
  EDIT_ALL_PES,       //Full control over any PEs
  DISABLE_SET_PERM_ON_CREATEPE,//normally a viewedit of true/true would be assigned on create
  ADMIN_ALL_AGENCIES, //Whether agency selection boxes should show all agencies
                      //or just the agencies this user is a member of
  SHOW_LDAP_UPDATE_BUTTON,//that button in AdminUsers to fill in cached ldap stuffs
  ADMIN_VIEW_FILES,   //debug access to logs
  LOGIN_AS_ANOTHER_USER,//debug can log in as another user  
  EDIT_ANNOUNCEMENTS, //Can edit the announcements bulletin board contents
  EDIT_WHATS_NEW,     //Can edit the contents of the What's New page
  EDIT_HELP,          //Can edit the contents of the Help page
  ACCESS_IN_MAINTENANCE_MODE, //Can access the website during maintenance windows (so we can test while we lock out external users)
  SHOW_USER_DATES,    //Show the created/modified dates for each user in user list/profile
  ALWAYS_SHOW_UNLOCK, //Can override other user's edit locks
  EDIT_MASTER_TOC,    //Can edit the master TOC contents when building a Master JB
  VIEW_SERVER_INFO,   //Can see the host name
  CAN_DO_PRCP,
  MANAGE_ALL_ASYNC_JOBS, // Can see all async jobs
  UNFREEZE_ANY,          //unfreeze even if it wasn't frozen by you
  DELETE_PE,          // Can delete a program element
  TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES,  // Can see any specified asynch job for any agency
  DELETE_BUDGES_JOB // Can delete a job from the tracking page
}
