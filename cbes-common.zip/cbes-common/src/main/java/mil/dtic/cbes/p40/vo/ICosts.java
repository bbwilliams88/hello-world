package mil.dtic.cbes.p40.vo;



public interface ICosts<T>
{
  T getPriorYears();


  void setPriorYears(T priorYears);


  T getPriorYear();


  void setPriorYear(T priorYear);


  T getCurrentYear();


  void setCurrentYear(T currentYear);


  T getBy1Base();


  void setBy1Base(T by1Base);


  T getBy1Ooc();


  void setBy1Ooc(T by1Ooc);


  T getBy1();


  void setBy1(T by1);


  T getBy2();


  void setBy2(T by2);


  T getBy3();


  void setBy3(T by3);


  T getBy4();


  void setBy4(T by4);


  T getBy5();


  void setBy5(T by5);


  T getToComplete();


  void setToComplete(T toComplete);


  T getTotal();


  void setTotal(T total);


  boolean isContinuing();


  void setContinuing(boolean continuing);

}