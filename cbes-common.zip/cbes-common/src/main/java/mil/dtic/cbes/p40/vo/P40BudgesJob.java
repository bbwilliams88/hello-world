package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P40BudgesJob;

public class P40BudgesJob extends _P40BudgesJob
{
    private static final long serialVersionUID = 1L;
}
