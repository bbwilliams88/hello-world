package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.List;



public class RandomCostElement
{
  private List<CostListImpl> costs;
//  private CostListImpl unitCost;
//  private CostListImpl quantity;
//  private CostListImpl totalCost;

  public RandomCostElement()
  {
    costs = new ArrayList<CostListImpl>();
    costs.add(new CostListImpl());
    costs.add(new CostListImpl());
    costs.add(new CostListImpl());
  }
  
  public List<CostListImpl> getCosts()
  {
    return costs;
  }

  public void setCosts(List<CostListImpl> costs)
  {
    this.costs = costs;
  }

  public CostListImpl getUnitCosts()
  {
    return costs.get(0);
  }

  public void setUnitCosts(CostListImpl cli)
  {
    costs.set(0, cli);
  }

  public CostListImpl getQuantities()
  {
    return costs.get(1);
  }

  public void setQuantities(CostListImpl cli)
  {
    costs.set(1, cli);
  }

  public CostListImpl getTotalCosts()
  {
    return costs.get(2);
  }

  public void setTotalCosts(CostListImpl cli)
  {
    costs.set(2, cli);
  }
}