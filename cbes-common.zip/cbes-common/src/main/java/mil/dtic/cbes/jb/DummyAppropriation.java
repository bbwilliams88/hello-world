/*
 * $Id: Appropriation.java 40766 2010-05-11 13:57:15Z tmanders $
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.submissions.ValueObjects.AppropriationBase;


public class DummyAppropriation extends AppropriationBase
{
  private static final long serialVersionUID = 1L;
}