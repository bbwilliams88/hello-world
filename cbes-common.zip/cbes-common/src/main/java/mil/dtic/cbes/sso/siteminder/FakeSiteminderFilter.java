package mil.dtic.cbes.sso.siteminder;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;

@SuppressWarnings("unused")
public final class FakeSiteminderFilter implements Filter
{
  private FilterConfig filterConfig = null;
  private final  ConfigService config;


  public FakeSiteminderFilter(ConfigService config)
  {
    this.config = config;
  }

  @Override
  public void destroy()
  {
    filterConfig = null;
  }


  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
  {
    if (config.isLocal())
    {
      FakeSiteminderRequestWrapper newRequest = new FakeSiteminderRequestWrapper((HttpServletRequest) request, filterConfig);
      chain.doFilter(newRequest, response);
    }
    else
    {
      chain.doFilter(request, response);
    }
  }


  @Override
  public void init(FilterConfig filterConfig) throws ServletException
  {
    this.filterConfig = filterConfig;
  }

  class FakeSiteminderRequestWrapper extends HttpServletRequestWrapper
  {
    FilterConfig filterConfig;
    String siteminderId;


    public FakeSiteminderRequestWrapper(HttpServletRequest request, FilterConfig filterConfig)
    {
      super(request);
      this.filterConfig = filterConfig;
      siteminderId = config.getLdapUser().getLdapUserId();
    }


    @Override
    public String getHeader(String name)
    {
      if (Constants.HTTP_HEADER_REMOTE_USER.equals(name))
      {
        return siteminderId;
      }
      else
      {
        return super.getHeader(name);
      }
    }
  }


}
