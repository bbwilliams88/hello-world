/*
 * $Id: XmlSchemaBean.java 31303 2008-12-01 17:38:56Z aibrahim $
 */
package mil.dtic.cbes.constants;


public class XmlSchemaBean
{
  private String name;
  private String schemaDir;
  private String schemaFile;
  
  public String getName()
  {
    return name;
  }
  public void setName(String name)
  {
    this.name = name;
  }
  public String getSchemaDir()
  {
    return schemaDir;
  }
  public void setSchemaDir(String schemaPath)
  {
    this.schemaDir = schemaPath;
  }
  public String getSchemaFile()
  {
    return schemaFile;
  }
  public void setSchemaFile(String schemaFile)
  {
    this.schemaFile = schemaFile;
  }
}