package mil.dtic.cbes.p40.vo;

import static mil.dtic.cbes.enums.ItemExhibitType.P40A;
import static mil.dtic.cbes.enums.ItemExhibitType.P5;

import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class Exhibit extends _Exhibit implements HasDisplayOrder
{
    private static final long serialVersionUID = 1L;

    MultiYearProcurement mypGroupType;


    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    /**
     * Calculate subtotals for this exhibit.
     *
     * @return True if the exhibit was modified, false if not.
     * @throws ReflectiveOperationException
     */
    public boolean calculateSubtotals() throws MethodDispatchException
    {
        if (getItemExhibitType() != null)
        {
            if (getP40aItemGroup() != null)
                getP40aItemGroup().calculateSubtotals();
            else if (getP5Item() != null)
                for (CostElement costElement : getP5Item().getCostElements())
                    costElement.calculateSubtotals();
            else if (getModsItemGroup() != null)
                getModsItemGroup().calculateSubtotals();
            else if (getP18Item() != null)
                getP18Item().calculateSubtotals();

            return true;
        }

        return false;
    }

    public Facility getFacility()
    {
        if (getProductionFacility() != null)
            return getProductionFacility();
        else if (getInactiveFacility() != null)
            return getInactiveFacility();
        else if (getLayawayFacility() != null)
            return getLayawayFacility();
        else
            return null;
    }

    /**
     * the actual object with the stuff in it (Item/ItemGroup/whatevs)
     *
     * @return
     */
    public ItemExhibitType getItemExhibitType()
    {
        if (getP40aItemGroup() != null)
            return getP40aItemGroup();
        else if (getP5Item() != null)
            return getP5Item();
        else if (getModsItemGroup() != null)
            return getModsItemGroup();
        else if (getP18Item() != null)
            return getP18Item();
        else if (getFacility() != null)
            return getFacility();
        else if (getP5ShipClass() != null)
            return getP5ShipClass();
        else if (getP29P30Combined() != null)
            return getP29P30Combined();
        else
            return null;
    }

    @Override
    public String getLockIdentifyingString()
    {
        String exhibitCode;

        if (getItemExhibit().getCode() == P5)
            exhibitCode = "P-5/P-5A/P-21";
        else if (getItemExhibit().getCode() == P40A)
            exhibitCode = "P-40A/P-5A/P-21";
        else
            exhibitCode = getItemExhibit().getCode().getDatabaseValue();

        String exhibitIdentifyingString = getItemExhibitType().getIdentifyingString();

        return exhibitCode + " (" + exhibitIdentifyingString + ")";
    }

    public MultiYearProcurement getMypGroupType()
    {
        return mypGroupType;
    }

    public void setMypGroupType(MultiYearProcurement mypGroupType)
    {
        this.mypGroupType = mypGroupType;
    }

    /**
     * @param years
     */
    public void shiftForwardInTime(int years)
    {
        if (this.getFacility() != null)
            this.getFacility().shiftForwardInTime(years);

        if (this.getModsItemGroup() != null)
            this.getModsItemGroup().shiftForwardInTime(years);

        if (this.getP18Item() != null)
            this.getP18Item().shiftForwardInTime(years);

        if (this.getP40aItemGroup() != null)
            this.getP40aItemGroup().shiftForwardInTime(years);

        if (this.getP5Item() != null)
            this.getP5Item().shiftForwardInTime(years);

        if (this.getP5ShipClass() != null)
            this.getP5ShipClass().shiftForwardInTime(years);
    }
}
