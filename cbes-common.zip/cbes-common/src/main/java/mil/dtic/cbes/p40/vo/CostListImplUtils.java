package mil.dtic.cbes.p40.vo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Iterator;

import org.apache.logging.log4j.Logger;
import org.jibx.runtime.IUnmarshallingContext;

import mil.dtic.cbes.p40.vo.util.CostListExtendedIterator;
import mil.dtic.cbes.p40.vo.util.CostListIterator;
import mil.dtic.utility.CbesLogFactory;


public class CostListImplUtils
{
  private static final Logger log = CbesLogFactory.getLog(CostListImplUtils.class);

  public static final String PYS = "PriorYears";
  public static final String PY = "PriorYear";
  public static final String CY = "CurrentYear";
  public static final String BY1BASE = "By1Base";
  public static final String BY1OOC = "By1Ooc";
  public static final String BY1 = "By1";
  public static final String BY2 = "By2";
  public static final String BY3 = "By3";
  public static final String BY4 = "By4";
  public static final String BY5 = "By5";
  public static final String TC = "ToComplete";
  public static final String TOTAL = "Total";

  private static Object invokeMethod(Object o, String method, Class<?>[] params, Object ... args)
  {
    try {
      Method m = o.getClass().getMethod(method, params);
      return m.invoke(o, args);
    } catch (InvocationTargetException e) {
      throw new RuntimeException(e.getCause());
    } catch (NoSuchMethodException e) {
      log.error("no such method", e);
    } catch (IllegalAccessException e) {
      log.error("illegal access", e);
    }
    return null;
  }

  private static void sanityCheckNonExtendedYearValidity(String year)
  {
    for (String y : new String[] {PYS,PY,CY,BY1,BY1BASE,BY1OOC})
    {
      if (y.equals(year)) return;
    }
    log.error("A year not in the nonextended year list was passed in " + year);
  }

  private static Cost maybeCreateCostImpl(CostListExtended cle, BigDecimal unitCost, BigDecimal quantity, BigDecimal totalCost, String year)
  {
    if (unitCost==null && quantity==null && totalCost==null) return null; //make jibx not create this element
    //return new CostImpl(unitCost, quantity, totalCost, year);
    return new RWCost(cle, year);
  }


  static Cost getToComplete(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getToCompleteUnitCost(), cle.getToCompleteQuantity(), cle.getToCompleteTotalCost(), TC);
  }

  static Cost getTotal(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getTotalUnitCost(), cle.getTotalQuantity(), cle.getTotalTotalCost(), TOTAL);
  }

  static void setToComplete(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setToCompleteUnitCost(c.getUnitCost());
      cle.setToCompleteQuantity(c.getQuantity());
      cle.setToCompleteTotalCost(c.getTotalCost());
    }
  }

  static void setTotal(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setTotalUnitCost(c.getUnitCost());
      cle.setTotalQuantity(c.getQuantity());
      cle.setTotalTotalCost(c.getTotalCost());
    }
  }

  static Cost getPriorYears(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getPriorYearsUnitCost(), cle.getPriorYearsQuantity(), cle.getPriorYearsTotalCost(), PYS);
  }
  static void setPriorYears(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setPriorYearsUnitCost(c.getUnitCost());
      cle.setPriorYearsQuantity(c.getQuantity());
      cle.setPriorYearsTotalCost(c.getTotalCost());
    }
  }

  static Cost getPriorYear(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getPriorYearUnitCost(), cle.getPriorYearQuantity(), cle.getPriorYearTotalCost(), PY);
  }
  static void setPriorYear(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setPriorYearUnitCost(c.getUnitCost());
      cle.setPriorYearQuantity(c.getQuantity());
      cle.setPriorYearTotalCost(c.getTotalCost());
    }
  }

  static Cost getCurrentYear(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getCurrentYearUnitCost(), cle.getCurrentYearQuantity(), cle.getCurrentYearTotalCost(), CY);
  }
  static void setCurrentYear(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setCurrentYearUnitCost(c.getUnitCost());
      cle.setCurrentYearQuantity(c.getQuantity());
      cle.setCurrentYearTotalCost(c.getTotalCost());
    }
  }

  static Cost getBy1(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy1UnitCost(), cle.getBy1Quantity(), cle.getBy1TotalCost(), BY1);
  }
  static void setBy1(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy1UnitCost(c.getUnitCost());
      cle.setBy1Quantity(c.getQuantity());
      cle.setBy1TotalCost(c.getTotalCost());
    }
  }

  static Cost getBy1Base(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy1BaseUnitCost(), cle.getBy1BaseQuantity(), cle.getBy1BaseTotalCost(), BY1BASE);
  }
  static void setBy1Base(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy1BaseUnitCost(c.getUnitCost());
      cle.setBy1BaseQuantity(c.getQuantity());
      cle.setBy1BaseTotalCost(c.getTotalCost());
    }
  }

  static Cost getBy1Ooc(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy1OocUnitCost(), cle.getBy1OocQuantity(), cle.getBy1OocTotalCost(), BY1OOC);
  }
  static void setBy1Ooc(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy1OocUnitCost(c.getUnitCost());
      cle.setBy1OocQuantity(c.getQuantity());
      cle.setBy1OocTotalCost(c.getTotalCost());
    }
  }

  static Cost getBy2(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy2UnitCost(), cle.getBy2Quantity(), cle.getBy2TotalCost(), BY2);
  }
  static void setBy2(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy2UnitCost(c.getUnitCost());
      cle.setBy2Quantity(c.getQuantity());
      cle.setBy2TotalCost(c.getTotalCost());
    }
  }

  static Cost getBy3(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy3UnitCost(), cle.getBy3Quantity(), cle.getBy3TotalCost(), BY3);
  }
  static void setBy3(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy3UnitCost(c.getUnitCost());
      cle.setBy3Quantity(c.getQuantity());
      cle.setBy3TotalCost(c.getTotalCost());
    }
  }

  static Cost getBy4(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy4UnitCost(), cle.getBy4Quantity(), cle.getBy4TotalCost(), BY4);
  }
  static void setBy4(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy4UnitCost(c.getUnitCost());
      cle.setBy4Quantity(c.getQuantity());
      cle.setBy4TotalCost(c.getTotalCost());
    }
  }

  static Cost getBy5(ICostListExtendedImpl cle)
  {
    return maybeCreateCostImpl(cle, cle.getBy5UnitCost(), cle.getBy5Quantity(), cle.getBy5TotalCost(), BY5);
  }
  static void setBy5(ICostListExtendedImpl cle, Cost c)
  {
    if (c!=null)
    {
      cle.setBy5UnitCost(c.getUnitCost());
      cle.setBy5Quantity(c.getQuantity());
      cle.setBy5TotalCost(c.getTotalCost());
    }
  }


  //a read-write cost.
  public static class RWCost implements Cost
  {
    private static final Logger log = CbesLogFactory.getLog(RWCost.class);
    private final CostList cayenneCostList;
    private final String year;

    public RWCost(CostList cayenneCostList, String year)
    {
      log.trace("RWCost CL " + cayenneCostList + " " + year);
      this.cayenneCostList = cayenneCostList;
      this.year = year;
      sanityCheckNonExtendedYearValidity(year);
    }
    public RWCost(CostListExtended cayenneCostListExtended, String year)
    {
      //log.trace("RWCost CLE " + cayenneCostListExtended + " " + year);
      this.cayenneCostList = cayenneCostListExtended;
      this.year = year;
    }
    @SuppressWarnings("unchecked")
    private <T> T get(String which)
    {
//      return _get(cayenneCostList, year, which);
      return (T)invokeMethod(cayenneCostList, "get" + year + which, null, (Object[])null);
    }
    private <T> void set(String which, Class<T> clazz, T obj)
    {
//      _set(cayenneCostList, year, which, clazz, obj);
      invokeMethod(cayenneCostList, "set" + year + which, new Class<?>[]{clazz}, obj);
    }
    @Override
	public BigDecimal getUnitCost()
    {
      return get("UnitCost");
    }
    @Override
	public void setUnitCost(BigDecimal bd)
    {
      set("UnitCost", BigDecimal.class, bd);
    }
    @Override
	public BigDecimal getQuantity()
    {
      return get("Quantity");
    }
    @Override
	public void setQuantity(BigDecimal i)
    {
      set("Quantity", BigDecimal.class, i);
    }
    @Override
	public BigDecimal getTotalCost()
    {
      return get("TotalCost");
    }
    @Override
	public void setTotalCost(BigDecimal bd)
    {
      set("TotalCost", BigDecimal.class, bd);
    }
    @Override
    public boolean anyExist()
    {
      return getQuantity()!=null || getTotalCost()!=null || getUnitCost()!=null;
    }
    @Override
    public String getYear()
    {
      return year;
    }


    @Override
	public String toString()
    {
      StringBuffer sb = new StringBuffer();
      sb.append("[Unit Cost: ").append(getUnitCost()).append(", Quantity: ").append(getQuantity()).append(", Total Cost: ").append(getTotalCost()).append("]");
      return sb.toString();
    }
    @Override
    public void postset(IUnmarshallingContext ctx)
    {
      // TODO Auto-generated method stub

    }
  }


  static Iterator<Cost> getIterator(CostList cl)
  {
    return new CostListIterator(cl, true);
  }

  static Iterator<Cost> getIterator(CostListExtended cle)
  {
    return new CostListExtendedIterator(cle, true);
  }


  public static boolean numberEqual(Comparable n1, Comparable n2)
  {
    if (n1 == n2)
      return true;
    if (n1 == null || n2 == null)
      return false;
    if (n1.compareTo(n2) != 0)
      return false;
    return true;
  }

  //compare all three properties
  private static boolean eq(Cost c1, Cost c2)
  {
    if (c1==c2) return true;
    if (c1!=c2 && (c1==null || c2==null)) return false;
    if (!numberEqual(c1.getTotalCost(), c2.getTotalCost()))
      return false;
    if (!numberEqual(c1.getQuantity(), c2.getQuantity()))
      return false;
    if (!numberEqual(c1.getUnitCost(), c2.getUnitCost()))
      return false;
    return true;
  }

  /**
   * Util equals method.  Compares two CostLists, is null safe for both lists.
   *
   * @param cle1 The first cost list.
   * @param cle2 The second cost list.
   * @return True if the two lists are equal, false otherwise.
   */
  static boolean equals(CostListExtended cle1, CostListExtended cle2) //NOSONAR
  {
    boolean eq = true;
    eq &= eq(cle1.getPriorYear(), cle2.getPriorYear());
    eq &= eq(cle1.getCurrentYear(), cle2.getCurrentYear());
    eq &= eq(cle1.getBy1(), cle2.getBy1());
    eq &= eq(cle1.getBy1Base(), cle2.getBy1Base());
    eq &= eq(cle1.getBy1Ooc(), cle2.getBy1Ooc());
    eq &= eq(cle1.getBy2(), cle2.getBy2());
    eq &= eq(cle1.getBy3(), cle2.getBy3());
    eq &= eq(cle1.getBy4(), cle2.getBy4());
    eq &= eq(cle1.getBy5(), cle2.getBy5());
    eq &= eq(cle1.getToComplete(), cle2.getToComplete());
    eq &= eq(cle1.getTotal(), cle2.getTotal());
    return eq;
  }
}