/*
 * $Id: JBToc.java,v 1.7 2009/06/08 01:41:06 aibrahim Exp $
 */
package mil.dtic.cbes.jb;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.factories.RomanNumberFactory;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.Util;


public class BaseToc extends GenericToc {
  private static final Logger log = CbesLogFactory.getLog(BaseToc.class);

  JBBase jbb;
  boolean appendTocToEnd = false;


  public BaseToc() {}

  public BaseToc(JBBase jbb, FileSetting fs){
      super(fs);
      
      if (fs != null){
          setTitle(Util.addPrefix(jbb.getPageNumberPrefix(), fileSetting.getTitle(), " "));
      }
      
      this.jbb = jbb;
  }

  public FormattingResults createPdf() throws IOException, DocumentException, SQLException {
      log.trace("BaseToc(): createPdf - start building toc");
      prepareTocContents();
      docCreationParams.setTocKvpList(tocItemList);
      FormattingResults fr = super.createPdf();
      return fr;
  }

  public void prepareTocContents() {
      JustificationBook jb = null;
      
      if (jbb instanceof JustificationBook){
          jb = (JustificationBook)jbb;
      }    
    
      log.debug("Preparing TOC items...");
      tocItemList = new ArrayList<KeyValuePair>();
      addTocItem(tocItemList, jbb.getCostDoc()); 
      addTocItem(tocItemList, jbb.getIntroductionDoc());
      addTocItem(tocItemList, jbb.getUserR1Doc());
      addTocItem(tocItemList, jbb.getUserP1Doc());    
    
      if (jb != null){
          addTocItem(tocItemList, jb.getMasterPeTocByBa());
          addTocItem(tocItemList, jb.getMasterPeTocByTitle());    
      }
      
      addTocItem(tocItemList, jbb.getPeTocByBa());
      addTocItem(tocItemList, jbb.getPeTocByTitle());
    
      if (jb != null){
          addTocItem(tocItemList, jb.getMasterLiTocByBa());
          addTocItem(tocItemList, jb.getMasterLiTocByTitle());    
      }
      
      addTocItem(tocItemList, jbb.getLiTocByBa());
      addTocItem(tocItemList, jbb.getLiTocByTitle());
      addTocItem(tocItemList, jbb.getSummaryDoc());
      
      if (jb != null){
          addTocItem(tocItemList, jb.getMasterR1Summary());
          addTocItem(tocItemList, jb.getMasterR1());        
          addTocItem(tocItemList, jb.getMasterR1c());
          addTocItem(tocItemList, jb.getMasterR1d());    
      }
      
      addTocItem(tocItemList, jbb.getR1Summary());
      addTocItem(tocItemList, jbb.getR1());        
      addTocItem(tocItemList, jbb.getR1c());
      addTocItem(tocItemList, jbb.getR1d());

      if (jb != null){
          addTocItem(tocItemList, jb.getMasterP1());
          addTocItem(tocItemList, jb.getMasterP1m());
      }    
    
      addTocItem(tocItemList, jbb.getP1());
      addTocItem(tocItemList, jbb.getP1m());
    
      JBSupplementalDocCollection supplementalDocumentation = jbb.getSupplementalDocCollection();
    
      if (null != supplementalDocumentation && supplementalDocumentation.getSupplementalDocList().size() > 0 && null != jbb.getDocAssemblyOptions()){
          log.trace("prepareTocContents(): test to determine positioning");
          if (!determineAlternateDocumentPagination()){
              addTocItem(tocItemList, jbb.getSupplementalDocCollection().getSupplementalDocList());
          }
      }
    
      addTocItem(tocItemList, jbb.getAcronymDoc());
    
  }

  protected void addTocItem(List<KeyValuePair> tocItemList, JBPart jbPart){
      if (jbPart != null && jbPart.hasContent()) {
          log.debug("Adding " + jbPart.getTitle() + ", " + jbPart.getAbsoluteFileName() + ", to TOC...");
          KeyValuePair kvp = new KeyValuePair();
          tocItemList.add(kvp);
          kvp.setKey(jbPart.getTitle());
          
          if (null != jbPart.getPdfPaginationGroup()){
              if (Constants.JBPageNumberingStyle.ROMAN_NUMERALS.equals(jbPart.getPdfPaginationGroup().getPageNumberingStyle())){
                  kvp.setValue(Util.addPrefix(jbb.getPageNumberPrefix(), Util.formatJbPageNumber(RomanNumberFactory.getLowerCaseString(jbPart.getPdfStartPage()))));
              }
              else{
                  kvp.setValue(Util.addPrefix(jbb.getPageNumberPrefix(), Util.formatJbPageNumber(jbPart.getPdfStartPage())));
              }
          }
          else {
              log.error("failed to generate a pdfPaginationGroup for jbPart" + jbPart.getTitle());
          }
      }
  }

  protected void addTocItem(List<KeyValuePair> tocItemList, List<? extends JBPart> jbPartList) {
      if (jbPartList != null) {
          for (JBPart jbPart : jbPartList){
              addTocItem(tocItemList, jbPart);
          }
      }
  }

  protected void addTocItem(List<KeyValuePair> tocItemList, KeyValuePair kvp){
      tocItemList.add(kvp);
  }
  
  //CXE-4197.3
  private boolean determineAlternateDocumentPagination(){
      log.trace("determineAlternateDocumentPagination(): start");
      boolean alternatePagination = false;
      
      if (jbb.getDocAssemblyOptions().isPositionAttachmentsAfterExhibits()){
          setAppendTocToEnd(true);
          alternatePagination = true;
      }
      setAppendTocToEnd(alternatePagination);  //this variable read by JBToc
      
      log.trace("determinedAlternateDocumentPagination(): " + alternatePagination); 
      return alternatePagination;
  }

  // called from children (JBToc)
  protected boolean isAppendTocToEnd() {
    return appendTocToEnd;
  }

  protected void setAppendTocToEnd(boolean appendTocToEnd) {
    this.appendTocToEnd = appendTocToEnd;
  }
 
}
