package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._CompoSplit;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;


/**
 *
 */
public class CompoSplit extends _CompoSplit implements HasDisplayOrder, HasTripletCosts, CostContainer, Equivalence<CompoSplit>
{
  private static final long serialVersionUID = 1L;

  private String xmlComponent;
  private String xmlAgency;
  
  private Costs unitCosts;
  private boolean unitCostsForRollupOnly = false;
  


  /***********************************************************************/
  /*** Cayenne Callbacks ***/
  /***********************************************************************/

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);

    setQuantities(Costs.create(getObjectContext(), CostRowType.QUANTITY));
    setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

    setupModsOutYearsDeltas();
  }


  @Override
  protected void onPrePersist()
  {
  }


  private void setupModsOutYearsDeltas()
  {
    if (getModsOutYearsDelta() == null)
      setModsOutYearsDelta(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

    if (getModsOutYearsQuantityDelta() == null)
      setModsOutYearsQuantityDelta(Costs.create(getObjectContext(), CostRowType.QUANTITY));
  }


  /***********************************************************************/
  /*** Custom Accessors ***/
  /***********************************************************************/

  @Override
  public boolean isContinuing()
  {
    return getTotalCosts() != null && getTotalCosts().isContinuing();
  }


  @Override
  public Costs getCosts()
  {
    return getTotalCosts();
  }


  @Override
  public Costs getUnitCosts()
  {
    // unused so just make jibx shut up
    return unitCosts;
  }


  @Override
  public void setUnitCosts(Costs c)
  {
	  this.unitCosts = c;
    // ignore since it doesn't exist here
  }


  public boolean isOutYearsPresent()
  {
    if (getTotalCosts() != null && getTotalCosts().hasOutYears())
      return true;

    if (this.getQuantities() != null && getQuantities().hasOutYears())
      return true;

    return false;
  }


  /***********************************************************************/
  /*** Business Logic ***/
  /***********************************************************************/

  @Override
  public void shiftForwardInTime(int years)
  {
    if (this.getTotalCosts() != null)
      this.getTotalCosts().shiftForwardInTimeNoApys(years);

    if (this.getQuantities() != null)
      this.getQuantities().shiftForwardInTimeNoApys(years);
  }


  /***********************************************************************/
  /*** JiBX Support ***/
  /***********************************************************************/

  public void jibx_setServiceComponent(String name)
  {
    // Cache the name for later use in an error message.
    xmlComponent = name;

    setServiceComponent(ServiceComponent.fetchWithTitle(getObjectContext(), name));
  }


  public String jibx_getServiceComponent()
  {
    if (getServiceComponent() == null)
    {
      if (xmlComponent == null)
        return "";

      return xmlComponent;
    }

    return getServiceComponent().getTitle();
  }


  public void jibx_setServiceAgencyName(String name)
  {
    // Cache the name for later use in an error message.
    xmlAgency = name;

    if (name != null)
      setServiceAgency(ServiceAgency.fetchWithName(getObjectContext(), name));
  }


  public String jibx_getServiceAgencyName()
  {
    if (getServiceAgency() == null)
      return xmlAgency;

    return getServiceAgency().getName();
  }


  @Override
  public String jibx_getContinuingFootnote()
  {
    return getTotalCosts().getContinuingFootnote();
  }


  @Override
  public void jibx_setContinuingFootnote(String s)
  {
    getTotalCosts().setContinuingFootnote(s);
  }


  @Override
  public boolean jibx_hasQuantity()
  {
    return getQuantities() != null && !getQuantities().isEmpty();
  }


  @Override
  public boolean jibx_hasTotalCost()
  {
    return getTotalCosts() != null && !getTotalCosts().isEmpty();
  }


  @Override
  public boolean jibx_hasUnitCost()
  {
    return getUnitCosts() != null && !getUnitCosts().isEmpty() && !getUnitCostsForRollupOnly();
  }


  public boolean jibx_hasServiceAgencyName()
  {
    return getServiceAgency() != null && !StringUtils.isEmpty(jibx_getServiceAgencyName());
  }


  public boolean jibx_hasServiceAgencySuffix()
  {
    return !StringUtils.isEmpty(getAgencySuffix());
  }


  public boolean jibx_hasTitle()
  {
    return !StringUtils.isEmpty(jibx_getServiceComponent());
  }


  public void jibx_setQuantities(Costs quantities)
  {
    if (quantities != null)
      setQuantities(quantities);
  }


  public void jibx_setTotalCosts(Costs totalCosts)
  {
    if (totalCosts != null)
      setTotalCosts(totalCosts);
  }


  public void jibx_setUnitCosts(Costs unitCosts)
  {
    if (unitCosts != null)
      setUnitCosts(unitCosts);
  }


  public boolean jibx_hasModsOutYearsDelta()
  {
    // Check if there is a Mods Delta for this Line Item.
    if (jibx_hasModsOutYearsCostDelta() || jibx_hasModsOutYearsQuantityDelta())
      return true;

    return false;
  }


  public boolean jibx_hasModsOutYearsCostDelta()
  {
    if (getModsOutYearsDelta() != null && !getModsOutYearsDelta().isEmpty())
      return true;

    return false;
  }


  public boolean jibx_hasModsOutYearsQuantityDelta()
  {
    if (getModsOutYearsQuantityDelta() != null && !getModsOutYearsQuantityDelta().isEmpty())
      return true;

    return false;
  }


  public void jibx_setModsOutYearsDelta(Costs modsOutYearsDelta)
  {
    if (modsOutYearsDelta != null)
      setModsOutYearsDelta(modsOutYearsDelta);
  }


  public void jibx_setModsOutYearsQuantityDelta(Costs modsOutYearsQuantityDelta)
  {
    if (modsOutYearsQuantityDelta != null)
      setModsOutYearsQuantityDelta(modsOutYearsQuantityDelta);
  }


  /***********************************************************************/
  /*** Validation Support ***/
  /***********************************************************************/

  /**
   * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
   */
  @Override
  public int equivalenceHashCode()
  {
    HashCodeBuilder builder = new HashCodeBuilder();

    builder.append(getLineItem());
    builder.append(getItem());
    builder.append(getModsItemGroup());
    builder.append(getModsItem());
    builder.append(getServiceAgency()); // This may be redundant since component
                                        // names are unique to agencies.
    builder.append(getServiceComponent());
    builder.append(getAgencySuffix());

    return builder.toHashCode();
  }


  /**
   * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
   */
  @Override
  public boolean equivalentTo(CompoSplit obj)
  {
    if (this == obj)
      return true;
    else if (obj == null)
      return false;
    else if (getClass() != obj.getClass())
      return false;

    EqualsBuilder builder = new EqualsBuilder();
    CompoSplit other = obj;

    builder.append(getLineItem(), other.getLineItem());
    builder.append(getItem(), other.getItem());
    builder.append(getModsItemGroup(), other.getModsItemGroup());
    builder.append(getModsItem(), other.getModsItem());
    // This may be redundant since component names are unique to agencies.
    builder.append(getServiceAgency(), other.getServiceAgency());
    builder.append(getServiceComponent(), other.getServiceComponent());
    builder.append(getAgencySuffix(), other.getAgencySuffix());

    return builder.isEquals();
  }


public boolean getUnitCostsForRollupOnly() {
	return unitCostsForRollupOnly;
}


public void setUnitCostsForRollupOnly(boolean unitsForRollup) {
	this.unitCostsForRollupOnly = unitsForRollup;
}
  
  
}
