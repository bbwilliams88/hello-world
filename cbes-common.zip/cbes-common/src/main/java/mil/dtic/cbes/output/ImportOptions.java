/*
 * $Id$
 */
package mil.dtic.cbes.output;

import java.io.Serializable;

public class ImportOptions implements Serializable
{
  private static final long serialVersionUID = -2330047899570185760L;

  private String userDefinedTag;
  private boolean ignoreDuplicates;
  private boolean testExhibit;


  public String getUserDefinedTag()
  {
    return userDefinedTag;
  }


  public void setUserDefinedTag(String userDefinedTag)
  {
    this.userDefinedTag = userDefinedTag;
  }


  public boolean isIgnoreDuplicates()
  {
    return ignoreDuplicates;
  }


  public void setIgnoreDuplicates(boolean ignoreDuplicates)
  {
    this.ignoreDuplicates = ignoreDuplicates;
  }

  /**
   * Sets that this exhibit should be flagged as a test exhibit after importing.
   * 
   * @param testExhibit True if a test exhibit, false otherwise.
   */
  public void setTestExhibit(boolean testExhibit)
  {
    this.testExhibit = testExhibit;
  }

  /**
   * Indicates whether this exhibit should be imported as a test exhibit.
   * 
   * @return Whether this should be a test exhibit.
   */
  public boolean isTestExhibit()
  {
    return testExhibit;
  }

}
