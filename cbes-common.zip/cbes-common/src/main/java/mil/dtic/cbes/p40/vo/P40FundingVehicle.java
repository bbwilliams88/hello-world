package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P40FundingVehicle;

public class P40FundingVehicle extends _P40FundingVehicle {
  public String toString()
  {
    return getName();
  }
}
