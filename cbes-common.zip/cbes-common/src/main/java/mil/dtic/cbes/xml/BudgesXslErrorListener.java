package mil.dtic.cbes.xml;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

public class BudgesXslErrorListener implements ErrorListener
{
  private static final Logger log = CbesLogFactory.getLog(BudgesXslErrorListener.class);


  @Override
  public void error(TransformerException e) throws TransformerException
  {
    log.error("Error during CBES XSLT transformation", e);

  }


  @Override
  public void fatalError(TransformerException e) throws TransformerException
  {
    log.fatal("Fatal error during CBES XSLT transformation", e);
  }


  @Override
  public void warning(TransformerException e) throws TransformerException
  {
    log.warn("Message (or Warning) from CBES XSLT transformation", e);
  }

}
