package mil.dtic.cbes.rule;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringUtils;

import mil.dtic.utility.Util;

/**
 * Builds a exhibit path string for presentation with rule violation messages.
 * 
 * ExhibitPath ep = new ExhibitPath().append("JustificationBook");
 * ep = ep.appendIdentified("ProgramElement", "DARPA", ExhibitSet.Index);
 * String s = ep.toString();
 * 
 * s will be
 * "[JustificationBook] [1st ProgramElement "DARPA"]"
 * 
 * Permits each component to be associated with a key, consisting
 * of the identifier and the index.
 * 
 */
public class ExhibitPath {
  private boolean subIndex;
  private String currentExhibitKey;  
  private Stack<Component> components;  
  private Map<String, Integer> pathIndexCount = new HashMap<String, Integer>();
  private Integer subIndexCount;
  private MultiMap indexReset = new MultiValueMap(); //<String,String>, parent to indexed child
private String ruleMessage;
    
  public enum ExhibitSet {
    Index,
    NoIndex
  };
  
  private enum ComponentType {
    Base,
    Identified,
    Indexed,
    IdentifiedIndexed
  };
  
  private static class Component {
    ComponentType type;
    String componentName;
    int index;
    String identifier;
    boolean keyed;
    
    Component(ComponentType type, String componentName) {
      this.type = type;
      this.componentName = componentName;
    }
    Component(ComponentType type, String componentName, int index) {
      this.type = type;
      this.componentName = componentName;
      this.index = index;
    }
    Component(ComponentType type, String componentName, String identifier) {
      this.type = type;
      this.componentName = componentName;
      this.identifier = identifier;
    }
    Component(ComponentType type, String componentName, int index, String identifier) {
      this.type = type;
      this.componentName = componentName;
      this.index = index;
      this.identifier = identifier;
    }
        
    @Override
    public String toString() {
      switch (type) {
      case Identified:
        return String.format("[%s \"%s\"]", componentName, identifier);
      case Indexed:
        return String.format("[%s %s]", Util.formatIndex(index), componentName);
      case IdentifiedIndexed:      
        return String.format("[%s %s \"%s\"]", Util.formatIndex(index), componentName, identifier);
      default:
        return String.format("[%s]", componentName);
      }
    }
    
    public boolean isKeyed() {
      return keyed;
    }

    /**
     * Associate the component with a key.
     * 
     */
    public void markKeyed() {
      keyed = true;
    }    
    
    /**
     * Get the associated key with this component.
     * 
     * @return
     */
    public String key() {
      return Util.createPeMapKey(identifier, index);
    }
  }

  public ExhibitPath() {
    this.components = new Stack<Component>();
  }

  @Override
  public String toString() {
    String pathAsString = StringUtils.join(components.toArray(), " ");
    return pathAsString;
  }

  public ExhibitPath append(String component) {
    components.push(new Component(ComponentType.Base, component));
    return this;
  }

  /**
   * Adds a components to the path, optionally indexing
   * 
   * For example, the path [R2] becomes [R2][1st foo] upon append("foo", true)
   * In contrast, the path [R2] becomes [R2][foo] upon append("foo")
   * 
   * @param component
   * @param addIndex
   * @return
   */
  public ExhibitPath append(String component, ExhibitSet addIndex) {
    if (ExhibitSet.Index == addIndex) {
      Integer index = subIndex ? getSubIndex(component) : getIndex(component);
      components.push(new Component(ComponentType.Indexed, component, index));      
    }
    else {
      components.push(new Component(ComponentType.Base, component));      
    }
    return this;
  }
  
  /**
   * Add an identifiable component to the path, optionally indexing
   * 
   * For example, the path [R2] becomes [R2][1st PE "foo"] upon appendIdentified("PE", "foo", true)
   * In contrast, the path [R2] becomes [R2][PE "foo"] upon appendIdentified("PE", "foo")
   * 
   * @param component
   * @param identifier
   * @param addIndex
   * @return
   */
  public ExhibitPath appendIdentified(String component, String identifier, ExhibitSet addIndex) {
    if (ExhibitSet.Index == addIndex) {
      Integer index = subIndex ? getSubIndex(component) : getIndex(component);
      components.push(new Component(ComponentType.IdentifiedIndexed, component, index, identifier));      
    }
    else {
      components.push(new Component(ComponentType.Identified, component, identifier));      
    }
    return this;
  }
  
  public ExhibitPath appendIdentified(String component, String identifier) {
    components.push(new Component(ComponentType.Identified, component, identifier));      
    return this;
  }

  public ExhibitPath pop() {
    if (CollectionUtils.isNotEmpty(components))
    {
      resetDownstreamIndicies();
      resetExhibitKey();
      components.pop();
    }
    return this;
  }
  
  public void generateExhibitKey() {
    components.peek().markKeyed();
    currentExhibitKey = components.peek().key();
  }
  
  public String getExhibitKey() {
    return currentExhibitKey;
  }
  
  public boolean hasExhibitKey() {
    return currentExhibitKey != null;
  }
  
  /**
   * Reset index counts for downstream components
   */
  @SuppressWarnings("unchecked")
  private void resetDownstreamIndicies() {
    String componentName = components.peek().componentName;
    if (indexReset.containsKey(componentName)) {
      Collection<String> indexedComponents = (Collection<String>) indexReset.get(componentName);
      for (String indexedComponent : indexedComponents) {
        pathIndexCount.remove(indexedComponent);
      }
      indexReset.remove(componentName);
    }
  }
  
  public void subIndex() {
    subIndex = true;
  }
  
  public void clearSubIndex() {
    subIndex = false;
    subIndexCount = null;
  }
  
  /**
   * Generate a numerical index to prepend to the component name
   * 
   * @param component
   * @return
   */
  private Integer getIndex(String component) {
    Integer index = Integer.valueOf(0);
    if (pathIndexCount.containsKey(component)) {
      index = pathIndexCount.get(component);
    }
    else if (!components.isEmpty()) {
      // Track index resets
      indexReset.put(components.peek().componentName, component);
    }
    index = Integer.valueOf(index.intValue() + 1);
    pathIndexCount.put(component, index);

    return index;
  }
  
  /**
   * Generate a numerical index to prepend to the component name
   * 
   * @param component
   * @return
   */
  private Integer getSubIndex(String component) {
    if (subIndexCount == null) {
      subIndexCount = Integer.valueOf(0);
    }
    subIndexCount = Integer.valueOf(subIndexCount.intValue() + 1);
    return subIndexCount;
  }
  
  private void resetExhibitKey() {
    if (components.peek().isKeyed()) {
      currentExhibitKey = null;
    }
  }
}