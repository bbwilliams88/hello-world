package mil.dtic.cbes.p40.vo;

import java.util.Iterator;

import mil.dtic.cbes.p40.vo.auto._IndividualModInstallation;

/**
 *
 */
public class IndividualModInstallation extends _IndividualModInstallation
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    
    
    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasManufacturer()
    {
        return getManufacturer() != null;
    }

    public boolean jibx_hasTotalCost()
    {
        return jibx_hasInstallationCosts() || jibx_hasInstallationQuantity();
    }
    
    public boolean jibx_hasImplementationMethod()
    {
        return getImplementationMethod() != null;
    }
    
    public Iterator<CostElement> jibx_costElementIterator()
    {
        return getIterator(getCostElements());
    }
    
    public boolean jibx_hasInstallationQuantity()
    {
        return getInstallationQuantities() != null && !getInstallationQuantities().isEmpty();
    }

    public boolean jibx_hasInstallationCosts()
    {
        return getInstallationCosts() != null && !getInstallationCosts().isEmpty();
    }
    
    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
