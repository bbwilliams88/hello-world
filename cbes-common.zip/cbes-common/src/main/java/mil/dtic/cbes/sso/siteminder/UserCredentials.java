package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.api.UserCredentialsIntf;
import mil.dtic.cbes.submissions.ValueObjects.LockableExhibit;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.utility.CbesLogFactory;

public class UserCredentials implements UserCredentialsIntf, Serializable {
  private static final long serialVersionUID = -1030327781085699222L;
  private static final Logger log = CbesLogFactory.getLog(UserCredentials.class);

  protected UserInfo userInfo;
  private final PrivilegeChecker privs = new PrivilegeChecker(this);


  public UserCredentials() {}


  @Override
  public UserInfo getUserInfo(){
    return this.userInfo;
  }


  @Override
  public void setUserInfo(UserInfo userInfo) {
    this.userInfo = userInfo;
  }

  // convenience method for tapestry pages
  @Override
  public PrivilegeChecker getPrivs(){
    return privs;
  }

  @Override
  public boolean checkPrivilege(Privilege p) {
    if (userInfo != null) {
      return userInfo.checkPrivilege(p);
    }
    return false;
  }

  @Override
  public boolean canAccessSiteInMaintenanceMode() {
    boolean canAccess = false;
    if (userInfo != null) {
      canAccess = checkPrivilege(Privilege.ACCESS_IN_MAINTENANCE_MODE);
    }
    return canAccess;
  }

  // FIXME: Bad Name
  @Override
  public boolean createLiAllowed() {
    return createPeAllowed();
  }

  @Override
  public boolean savePeAllowed(ProgramElementBase pe) {
    if (userInfo != null){
      return userInfo.savePeAllowed(pe);
    }
    return false;
  }

  @Override
  public boolean deletePeAllowed(ProgramElementBase pe) {
    if (userInfo != null){
    	return userInfo.deletePeAllowed(pe);
    }
    return false;
  }

  @Override
  public boolean editPeUsersAllowed(ProgramElementBase pe){
    if (userInfo != null) {
      log.debug("userInfo.editPeUsersAllowed(pe):" + userInfo.editPeUsersAllowed(pe));
      return userInfo.editPeUsersAllowed(pe);
    }
    log.debug("userInfo.editPeUsersAllowed(pe): userinfo = NULL?");
    return false;
  }

  @Override
  public boolean viewPeAllowed(ProgramElementBase pe){
    if (userInfo != null) {
      return userInfo.viewPeAllowed(pe);
    }
    return false;
  }

  // FIXME: Bad Name
  @Override
  public boolean createPeAllowed() {
    if (userInfo != null) {
      return userInfo.createPeAllowed();
    }
    return false;
  }

  @Override
  public boolean isLockedByOther(LockableExhibit exhibit) {
    if (userInfo != null){
      return userInfo.isLockedByOther(exhibit);
    }
    return false;
  }

  @Override
  public boolean isLockedByMe(LockableExhibit exhibit) {
    if (userInfo != null) {
    	return userInfo.isLockedByMe(exhibit);
    }
    return false;
  }

  @Override
  public boolean isNotLocked(LockableExhibit exhibit)  {
    if (userInfo != null) {
      return userInfo.isNotLocked(exhibit);
    }
    return false;
  }

  @Override
  public boolean isEntireLockedByOther(ProgramElementBase pe) {
    if (userInfo != null) {
      return userInfo.isEntireLockedByOther(pe);
    }
    return false;
  }

  @Override
  public boolean isEntireLockedByMe(ProgramElementBase pe) {
    if (userInfo != null) {
      return userInfo.isEntireLockedByMe(pe);
    }
    return false;
  }
  
  @Override
  public boolean canDeleteBudgesJob(){
    boolean canDelete = false;
    if(userInfo != null){
      canDelete = userInfo.canDeleteBudgesJob();
    }
    return canDelete;
  }

  @Override
  public String toString() {
    return "UserCredentials{" + userInfo + "}";
  }
}