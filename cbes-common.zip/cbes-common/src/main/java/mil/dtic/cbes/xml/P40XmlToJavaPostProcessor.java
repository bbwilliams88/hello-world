/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.InitialSourceType;
import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.enums.ResourceSummaryEntryType;
import mil.dtic.cbes.enums.ShipsOutfittingDeliveryCostType;
import mil.dtic.cbes.jb.IAppropriation;
import mil.dtic.cbes.p40.service.exception.PostProcessException;
import mil.dtic.cbes.p40.service.exception.PostProcessException.ErrorType;
import mil.dtic.cbes.p40.service.exception.ProcurementServiceException;
import mil.dtic.cbes.p40.vo.Appropriation;
import mil.dtic.cbes.p40.vo.Base;
import mil.dtic.cbes.p40.vo.BudgetActivity;
import mil.dtic.cbes.p40.vo.BudgetSubActivity;
import mil.dtic.cbes.p40.vo.ContractMethodTypeFundingVehicle;
import mil.dtic.cbes.p40.vo.CostElement;
import mil.dtic.cbes.p40.vo.Exhibit;
import mil.dtic.cbes.p40.vo.ExtendedHistoryPlanning;
import mil.dtic.cbes.p40.vo.HasContractMethodFundingVehicle;
import mil.dtic.cbes.p40.vo.HasManufacturers;
import mil.dtic.cbes.p40.vo.HistoryPlanning;
import mil.dtic.cbes.p40.vo.Item;
import mil.dtic.cbes.p40.vo.ItemGroup;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.Manufacturer;
import mil.dtic.cbes.p40.vo.ModsItemGroup;
import mil.dtic.cbes.p40.vo.P10AdvanceProcurement;
import mil.dtic.cbes.p40.vo.P10CostElement;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.ServiceAgency;
import mil.dtic.cbes.p40.vo.ServiceAgencyAcct;
import mil.dtic.cbes.p40.vo.ShipCategoryItem;
import mil.dtic.cbes.p40.vo.ShipClass;
import mil.dtic.cbes.p40.vo.ShipContract;
import mil.dtic.cbes.p40.vo.ShipCostCategory;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryCostCategory;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryCostElem;
import mil.dtic.cbes.p40.vo.ShipsOutfittingDeliveryExhibit;
import mil.dtic.cbes.p40.vo.SparesBudgetActivity;
import mil.dtic.cbes.p40.vo.SparesList;
import mil.dtic.cbes.p40.vo.jibx.LineItemPostprocessData;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class P40XmlToJavaPostProcessor
{
  private static final Logger log = CbesLogFactory.getLog(P40XmlToJavaPostProcessor.class);
  private final XmlToJavaPostProcessor xtjpp;
  private final ObjectContext objectContext;


  public P40XmlToJavaPostProcessor(XmlToJavaPostProcessor xtjpp, ObjectContext objectContext)
  {
    this.xtjpp = xtjpp;
    this.objectContext = objectContext;
  }


  public void process(P40User userForAuditFields, LineItem li, int liIndex)
  {
    LineItemPostprocessData data = li.getJibxData();
    if (data == null)
    {
      log.error("Postprocess data not found");
      return;
    }
    // do cayenne-specific postprocessing
    try
    {
      _postProcessSaAndBsa(liIndex, li, data);
      _postProcessP18Ba(liIndex, li);
      _postProcessHistoryPlannings(li);
      _postProcessImportedResourceSummaries(li);
    }
    catch (RuntimeException e)
    {
      log.error("CODE_47", e);
      xtjpp.logError("System Error");
    }
    catch (ProcurementServiceException e)
    {
      log.error(e);
      xtjpp.logError(e.getMessage());
    }
    // do other things like dates
    li.setInitialSource(InitialSourceType.IMPORTED);
    if (userForAuditFields != null)
    {
      Util.setAuditFields(li, userForAuditFields);
    }
    li.updateExhibitCount();
  }


  private Map<String, Object> _parsepv(Object[] pvs) throws ProcurementServiceException
  {
    if (pvs == null) return new HashMap<String, Object>(0);
    if (pvs.length % 2 != 0) throw new ProcurementServiceException("Odd numbers property-values for _parsepv");
    Map<String, Object> m = new HashMap<String, Object>(pvs.length / 2);
    for (int i = 0, j = pvs.length / 2; j < pvs.length; i++, j++)
    {
      if (pvs[i] == null) throw new ProcurementServiceException(new NullPointerException());
      m.put(pvs[i].toString(), pvs[j]);
    }
    return m;
  }


  public <T extends Base> T cachedQuery(boolean preloadWholeTable, Class<T> t, Object... propertiesthenvalues) throws ProcurementServiceException
  {
    SelectQuery one = new SelectQuery(t, ExpressionFactory.matchAllExp(_parsepv(propertiesthenvalues), Expression.EQUAL_TO));
    SelectQuery all = new SelectQuery(t);
    one.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
    all.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
    if (preloadWholeTable)
      objectContext.performQuery(all);
    @SuppressWarnings("unchecked")
    List<T> l = objectContext.performQuery(one);
    if (l.size() == 0)
      return null;
    if (l.size() > 1)
      log.warn("select returned more than one");
    return l.get(0);
  }


  public IAppropriation findAppropriation(String code) throws ProcurementServiceException
  {
    return cachedQuery(true, Appropriation.class, Appropriation.CODE_PROPERTY, code);
  }


  private void _postProcessSaAndBsa(int liIndex, LineItem li, LineItemPostprocessData data) throws ProcurementServiceException
  {
    // fetch agency from db
    ServiceAgency sa = cachedQuery(true, ServiceAgency.class, ServiceAgency.NAME_PROPERTY, data.getServiceAgencyName());
    if (sa == null)
      throw buildException(ErrorType.BAD_AGENCY, data);
    li.setServiceAgency(sa);
    // fetch bsa from db
    // check bsa/ba/app, maybe throw PostProcessException
    BudgetSubActivity bsa = getBsa(data);
    li.setBudgetSubActivity(bsa);
  }


  private void _postProcessP18Ba(int liIndex, LineItem li) throws ProcurementServiceException
  {
    if (li.getBudgetSubActivity() == null)
    {
      log.error("line item bsa failed, skipping p18 ba");
      return;
    }
    Appropriation appr = li.getBudgetSubActivity().getBudgetActivity().getAppropriation();
    for (Exhibit e : li.getExhibits())
    {
      if (e.getP18Item() != null)
        for (SparesList sl : e.getP18Item().getSparesLists())
          for (SparesBudgetActivity sba : sl.getSparesBudgetActivities())
            _postProcessP18Ba(liIndex, appr, sba);
    }
  }


  private void _postProcessP18Ba(int liIndex, Appropriation appr, SparesBudgetActivity sba) throws ProcurementServiceException
  {
    BudgetActivity ba =
      cachedQuery(true, BudgetActivity.class, BudgetActivity.APPROPRIATION_RELATIONSHIP_PROPERTY, BudgetActivity.NUMBER_PROPERTY, appr, sba.getJibxBudgetActivityNumber());
    sba.setBudgetActivity(ba);
    // TODO: better error messages
    if (sba.getBudgetActivity() == null)
    {
      // return 0 on fail
      short baNum = (short) NumberUtils.toInt(sba.getJibxBudgetActivityNumber());
      throw new PostProcessException(ErrorType.BAD_BA, "", "", "", baNum, sba.getJibxBudgetActivityTitle(), (short) 0, "");
    }
    if (!sba.getBudgetActivity().getTitle().equals(sba.getJibxBudgetActivityTitle()))
      throw new PostProcessException(ErrorType.BAD_BA, "", "", "", sba.getBudgetActivity().getNumber(), sba.getBudgetActivity().getTitle(), (short) 0, "");
  }


  private void _postProcessHistoryPlannings(LineItem li) throws ProcurementServiceException
  {
    for (Exhibit e : li.getExhibits())
    {
      if (e.getItemExhibitType() instanceof Item)
      {
        Item item = (Item) e.getItemExhibitType();
        for (CostElement ce : (item.getCostElements()))
          _postProcessHistoryPlanningsForCostElement(ce);

        P10AdvanceProcurement p10 = item.getAdvanceProcurement();
        if (p10 != null)
        {
          for (P10CostElement ce : p10.getCostElements())
          {
            _postProcessHistoryPlannings(ce);
          }
        }
      }
      if (e.getItemExhibitType() instanceof ItemGroup)
      {
        for (Item i : ((ItemGroup) e.getItemExhibitType()).getAllItemsInOrder())
          _postProcessHistoryPlannings(i);
      }
      if (e.getItemExhibitType() instanceof ModsItemGroup)
      {
        ModsItemGroup mg = (ModsItemGroup) e.getItemExhibitType();
        if (mg.getAdvanceProcurement() != null)
        {
          P10AdvanceProcurement p10 = mg.getAdvanceProcurement();
          if (p10 != null)
          {
            for (P10CostElement ce : p10.getCostElements())
            {
              _postProcessHistoryPlannings(ce);
            }
          }
        }
      }
      if (e.getItemExhibitType() instanceof ShipClass)
      {
        ShipClass shipClass = (ShipClass) e.getItemExhibitType();
        _postProcessShipContractsForShipClass(shipClass);
        for (ShipCostCategory shipCostCategory : shipClass.getShipCostCategories())
          for (ShipCategoryItem shipCategoryItem : shipCostCategory.getShipCategoryItems())
            _postProcessHistoryPlannings(shipCategoryItem);
        P10AdvanceProcurement p10 = shipClass.getAdvanceProcurement();
        if (p10 != null)
        {
          for (P10CostElement ce : p10.getCostElements())
          {
            _postProcessHistoryPlannings(ce);
          }
        }
      }
      if (e.getItemExhibitType() instanceof ShipsOutfittingDeliveryExhibit)
      {
        ShipsOutfittingDeliveryExhibit outfittingDelivery = (ShipsOutfittingDeliveryExhibit) e.getItemExhibitType();
        for (ShipsOutfittingDeliveryCostCategory category : outfittingDelivery.getOutfittingDeliveryCostCategory())
        {
          for (ShipsOutfittingDeliveryCostElem elem : category.getOutfittingDeliveryCostElementSubList(ShipsOutfittingDeliveryCostType.SHIP_CLASS))
          {
            _postProcessContractData(elem.getContract());
          }
        }
      }
    }
  }


  private void _postProcessHistoryPlanningsForCostElement(CostElement ce) throws ProcurementServiceException
  {
    _postProcessHistoryPlannings(ce);
    if (ce.getCostElementList() != null)
    {
      for (CostElement ce2 : ce.getCostElementList())
        _postProcessHistoryPlanningsForCostElement(ce2);
    }
  }


  private void _postProcessHistoryPlannings(HasManufacturers hm) throws ProcurementServiceException
  {
    for (Manufacturer m : hm.getManufacturerList())
    {
      for (HistoryPlanning hp : m.getHistoryPlanningList())
      {
        if (hp instanceof ExtendedHistoryPlanning) {
          ExtendedHistoryPlanning ehp = (ExtendedHistoryPlanning) hp;
          if (ehp.jibx_hasContractMethodAndTypeList()) {
            // handle contract method and type list
            _postProcessContractDataList(ehp);
          }
          else {
            // handle funding vehicle
            _postProcessContractData(hp);
          }
        }
        else {
          _postProcessContractData(hp);
        }
      }
    }
  }

  private void _postProcessContractDataList(ExtendedHistoryPlanning ehp) throws ProcurementServiceException {
    Iterator<ContractMethodTypeFundingVehicle> iter = ehp.jibx_contractMethodAndTypeListIterator();
    // copy
    List<ContractMethodTypeFundingVehicle> listCopy = new ArrayList<ContractMethodTypeFundingVehicle>();
    while (iter.hasNext()) {
      listCopy.add(iter.next());
    }
    // delete from HistoryPlanning List
    iter = listCopy.iterator();
    while (iter.hasNext()) {
      ehp.removeFromContractMethodAndTypeList(iter.next());
    }
    // Add ContractMethodTypeFundingVehicle created through database lookup
    iter = listCopy.iterator();
    while (iter.hasNext()) {
      ContractMethodTypeFundingVehicle contract = iter.next();
      ContractMethodTypeFundingVehicle cmtfv =
          cachedQuery(true, ContractMethodTypeFundingVehicle.class,
            ContractMethodTypeFundingVehicle.CONTRACT_METHOD_RELATIONSHIP_PROPERTY,
            ContractMethodTypeFundingVehicle.CONTRACT_TYPE_RELATIONSHIP_PROPERTY,
            ContractMethodTypeFundingVehicle.FUNDING_VEHICLE_RELATIONSHIP_PROPERTY,
            contract._getJibxContractMethod(), contract._getJibxContractType(), null);
      ehp.addToContractMethodAndTypeList(cmtfv);
      if (cmtfv == null)
      {
        String cm = contract._getJibxContractMethod() == null ? "" : contract._getJibxContractMethod().getName();
        String ct = contract._getJibxContractType() == null ? "" : contract._getJibxContractType().getName();
        String fv = "";
        throw new PostProcessException(ErrorType.BAD_CMTFV, cm, ct, fv);
      }
    }
  }

  private void _postProcessContractData(HasContractMethodFundingVehicle hcmfv) throws ProcurementServiceException
  {
    if (hcmfv._getJibxContractMethod() != null || hcmfv._getJibxContractType() != null || hcmfv._getJibxFundingVehicle() != null)
    {
      ContractMethodTypeFundingVehicle cmtfv =
        cachedQuery(true, ContractMethodTypeFundingVehicle.class,
          ContractMethodTypeFundingVehicle.CONTRACT_METHOD_RELATIONSHIP_PROPERTY,
          ContractMethodTypeFundingVehicle.CONTRACT_TYPE_RELATIONSHIP_PROPERTY,
          ContractMethodTypeFundingVehicle.FUNDING_VEHICLE_RELATIONSHIP_PROPERTY,
          hcmfv._getJibxContractMethod(), hcmfv._getJibxContractType(), hcmfv._getJibxFundingVehicle());
      hcmfv.setContractMethodTypeFundingVehicle(cmtfv);
      if (cmtfv == null)
      {
        String cm = hcmfv._getJibxContractMethod() == null ? "" : hcmfv._getJibxContractMethod().getName();
        String ct = hcmfv._getJibxContractType() == null ? "" : hcmfv._getJibxContractType().getName();
        String fv = hcmfv._getJibxFundingVehicle() == null ? "" : hcmfv._getJibxFundingVehicle().getName();
        throw new PostProcessException(ErrorType.BAD_CMTFV, cm, ct, fv);
      }
    }
  }

  private void _postProcessShipContractsForShipClass(ShipClass sc) throws ProcurementServiceException
  {
    for (ShipContract contract : sc.getShipContracts())
      _postProcessContractData(contract);
  }


  // Add empty resource summary rows to everything
  private void _postProcessImportedResourceSummaries(LineItem li) throws ProcurementServiceException
  {
    li.getResourceSummary().generateMissingRows(li.getObjectContext(), ResourceSummaryEntryType.lineItemRows);
    for (Exhibit e : li.getExhibits())
    {
      if (e.getItemExhibitType() instanceof Item)
      {
        ((Item) e.getItemExhibitType()).getResourceSummary().generateMissingRows(li.getObjectContext(), ResourceSummaryEntryType.itemRows);
      }
      if (e.getItemExhibitType() instanceof ItemGroup)
      {
        for (Item i : ((ItemGroup) e.getItemExhibitType()).getAllItemsInOrder())
          i.getResourceSummary().generateMissingRows(li.getObjectContext(), ResourceSummaryEntryType.baseRows);
      }
      if (e.getItemExhibitType() instanceof ModsItemGroup)
      {
        ((ModsItemGroup) e.getItemExhibitType()).getResourceSummary().generateMissingRows(li.getObjectContext(), ResourceSummaryEntryType.p3aRows);
      }
    }
  }


  private PostProcessException buildException(ErrorType type, LineItemPostprocessData data)
  {
    return new PostProcessException(type, data.getServiceAgencyName(), data.getAppropriationTitle(), data.getAppropriationNumber(), data.getBudgetActivityNumber(), data.getBudgetActivityTitle(), data.getBudgetSubActivityNumber(),
      data.getBudgetSubActivityTitle());
  }


  private BudgetSubActivity getBsa(LineItemPostprocessData data) throws ProcurementServiceException
  {

    // fetch agency from db
    ServiceAgency saForCorrespondenceTest = cachedQuery(true, ServiceAgency.class, ServiceAgency.NAME_PROPERTY, ServiceAgency.STATUS_PROPERTY, data.getServiceAgencyName(), StatusFlag.ACTIVE);
    if (saForCorrespondenceTest == null)
      throw buildException(ErrorType.BAD_AGENCY, data);

    // TODO: Check App title?
    Appropriation app = cachedQuery(true, Appropriation.class, Appropriation.CODE_PROPERTY, Appropriation.STATUS_PROPERTY, data.getAppropriationNumber(), StatusFlag.ACTIVE);
    if (app == null || !app.getName().equals(data.getAppropriationTitle()))
      throw buildException(ErrorType.BAD_APP, data);

    // test correspondence between saForCorrespondenceTest and app:
    ServiceAgencyAcct saa = cachedQuery(true, ServiceAgencyAcct.class, ServiceAgencyAcct.APPROPRIATION_RELATIONSHIP_PROPERTY, ServiceAgencyAcct.AGENCY_RELATIONSHIP_PROPERTY, ServiceAgencyAcct.STATUS_PROPERTY, app, saForCorrespondenceTest, StatusFlag.ACTIVE);
    if (saa == null)
      throw buildException(ErrorType.BAD_AGENCY_APP_MISMATCH, data);

    // TODO: check baTitle?
    BudgetActivity ba = cachedQuery(true, BudgetActivity.class, BudgetActivity.APPROPRIATION_RELATIONSHIP_PROPERTY, BudgetActivity.NUMBER_PROPERTY, BudgetActivity.STATUS_PROPERTY, app, data.getBudgetActivityNumber(), StatusFlag.ACTIVE);
    if (ba == null || !ba.getTitle().equals(data.getBudgetActivityTitle()))
      throw buildException(ErrorType.BAD_BA, data);
    // TODO: check bsaTitle?
    BudgetSubActivity bsa = cachedQuery(true, BudgetSubActivity.class, BudgetSubActivity.BUDGET_ACTIVITY_RELATIONSHIP_PROPERTY, BudgetSubActivity.NUMBER_PROPERTY, BudgetSubActivity.STATUS_PROPERTY, BudgetSubActivity.TITLE_PROPERTY, ba, data.getBudgetSubActivityNumber(), StatusFlag.ACTIVE, data.getBudgetSubActivityTitle());
    if (bsa == null || !bsa.getTitle().equals(data.getBudgetSubActivityTitle()))
      throw buildException(ErrorType.BAD_BSA, data);
    return bsa;
  }
}
