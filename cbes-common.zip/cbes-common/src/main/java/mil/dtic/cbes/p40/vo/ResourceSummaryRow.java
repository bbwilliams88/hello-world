package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.ObjectContext;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ResourceSummaryEntryType;
import mil.dtic.cbes.enums.ResourceSummaryPlusOrLessType;
import mil.dtic.cbes.p40.vo.auto._ResourceSummaryRow;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class ResourceSummaryRow extends _ResourceSummaryRow implements HasDisplayOrder, Equivalence<ResourceSummaryRow>
{
  private static final long serialVersionUID = 1L;
  public static final String ENTRY_ENUM = "entryEnum";

  @Override
  protected void onPostAdd()
  {
    //!!! TODO set the display format
    setCosts(getObjectContext().newObject(Costs.class));
    setDisplayOrder(0); //I feel like this shouldn't be required
  }

  @Override
  protected void onPrePersist()
  {
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
  }

  public String getPrcpCostType() {
    return this.getEntryEnum().getP1CostType();
  }


  //jibx post sets
  public void jibx_qty()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.Quantity));
    getCosts().setType(CostRowType.QUANTITY);
  }

  public void jibx_gross()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.GrossWSCost));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_less()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.LessPY));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_net()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.NetP1));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_plus()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusCY));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_total()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.Total));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_initial()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.InitialSpares));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_other()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.Other));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public void jibx_flyaway()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.Flyaway));
    getCosts().setType(CostRowType.UNITCOST);
  }

  public void jibx_grossunit()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.GrossWSUnitCost));
    getCosts().setType(CostRowType.UNITCOST);
  }
  
  public void jibx_lessCtc()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.LessCTC));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_lessHurricane()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.LessHurricane));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_lessSyFf()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.LessSubsequentYearFF));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_plusSyFf()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusSubsequentYearFF));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_lessPyFf()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.LessPriorYearFF));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_plusPyFf()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusPriorYearFF));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_fullFundingTOA()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.FFTOA));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_plusCtc()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusCTC));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_plusHurricane()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusHurricane));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_plusOapd()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.PlusOutfittingDelivery));
    getCosts().setType(CostRowType.TOTALCOST);
  }
  
  public void jibx_allLiTotal()
  {
    setEntryType(fetchEntryCached(ResourceSummaryEntryType.AllLITotal));
    getCosts().setType(CostRowType.TOTALCOST);
  }

  public static ResourceSummaryRow create(ObjectContext context, ResourceSummaryEntryType entryType)
  {
    ResourceSummaryRow rsr = context.newObject(ResourceSummaryRow.class);
    rsr.setEntryType(ResourceSummaryEntry.fetchWithCode(context, entryType.getDatabaseValue()));
    if (rsr.getEntryType() == null)
      throw new NullPointerException(entryType.toString());
    if (rsr.getEntryEnum() == ResourceSummaryEntryType.Quantity)
      rsr.getCosts().setType(CostRowType.QUANTITY);
    else if (rsr.getEntryEnum() == ResourceSummaryEntryType.GrossWSUnitCost || rsr.getEntryEnum() == ResourceSummaryEntryType.Flyaway)
      rsr.getCosts().setType(CostRowType.UNITCOST);
    else
      rsr.getCosts().setType(CostRowType.TOTALCOST);
    return rsr;
  }

  public ResourceSummaryEntry fetchEntryCached(ResourceSummaryEntryType entryType)
  {
    ResourceSummaryEntry rse = ResourceSummaryEntry.fetchWithCodeCached(getObjectContext(), entryType.getDatabaseValue());
    if (rse == null)
      throw new NullPointerException("RSE with name " + entryType.getDatabaseValue() + " not found");
    return rse;
  }

  public ResourceSummaryEntryType getEntryEnum()
  {
    return getEntryType().getTitle();//getEnum();
  }

//FIXME this should be a is* method name
  public boolean hasAny()
  {
    return getCosts() != null && !getCosts().isEmpty();
  }
  
  public boolean isEmptyBesidesPYS()
  {
    return getCosts() == null || getCosts().isEmptyBesidesPYS();
  }
  
  public boolean isInYearsEmpty()
  {
    return getCosts() == null || getCosts().isInYearsEmpty();
  }

  public boolean isRequired()
  {
    return ResourceSummaryEntryType.NetP1 == getEntryEnum() || ResourceSummaryEntryType.GrossWSCost == getEntryEnum() || ResourceSummaryEntryType.Total == getEntryEnum();
  }
  
  public boolean jibx_hasPlusOrLess()
  {
    return getPlusOrLess() != null;
  }
  
  public String jibx_getPlusOrLess()
  {
    return getPlusOrLess() != null ? getPlusOrLess().getXmlValue() : null;
  }
  
  public void jibx_setPlusOrLess(String plusOrLess)
  {
      if (StringUtils.equals(plusOrLess, ResourceSummaryPlusOrLessType.LESS.getXmlValue()))
        setPlusOrLess(ResourceSummaryPlusOrLessType.LESS);
      else if (StringUtils.equals(plusOrLess, ResourceSummaryPlusOrLessType.PLUS.getXmlValue()))
        setPlusOrLess(ResourceSummaryPlusOrLessType.PLUS);
      else if (StringUtils.equals(plusOrLess, ResourceSummaryPlusOrLessType.PLUSFF.getXmlValue()))
        setPlusOrLess(ResourceSummaryPlusOrLessType.PLUSFF); 
  }

@Override
public int equivalenceHashCode() {
	HashCodeBuilder builder = new HashCodeBuilder();
    builder.append(toLowerAndTrim(getTitle()));
    builder.append(getPlusOrLess());
    return builder.toHashCode();
}

@Override
public boolean equivalentTo(ResourceSummaryRow other) {
	if (this == other){
	      return true;
	    }
	    if (other == null){
	      return false;
	    }
	    if (getClass() != other.getClass()){
	      return false;
	    }
	    
	    EqualsBuilder builder = new EqualsBuilder();
	    builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
	    builder.append(getPlusOrLess(), other.getPlusOrLess());
	    return builder.isEquals();
}
  
  
}