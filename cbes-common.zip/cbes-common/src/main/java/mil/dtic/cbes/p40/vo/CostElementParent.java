package mil.dtic.cbes.p40.vo;

import java.util.List;

/**
 *
 */
public interface CostElementParent
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    List<CostElement> getCostElements();
    CostElement addCostElement();
    void removeCostElement(CostElement ce);
}
