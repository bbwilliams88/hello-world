/*
 * $Id: P40ImportMessage.java 31493 2009-04-22 23:38:46Z bhicks $
 */
package mil.dtic.cbes.output;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.service.XmlRulesValidationMessage;


public class P40ImportMessage extends XmlRulesValidationMessage
{

  public P40ImportMessage(String lineItemNumber, int lineItemIndex, int lineNum, int colNum, String message)
  {
    super(lineItemNumber, lineItemIndex, lineNum, colNum, message);
  }

  public P40ImportMessage(String lineItemNumber, int lineItemIndex, String message)
  {
    super(lineItemNumber, lineItemIndex, NO_VALUE, NO_VALUE, message);
  }

  @Override
  public String toString()
  {
    StringBuffer sb = new StringBuffer("[");
    if (StringUtils.isNotEmpty(getLineItemNumber()))
    {
      sb.append(toWord(getLineItemIndex()) + " Line Item ");
      sb.append("# \"" + getLineItemNumber() + "\"");
    }

    sb.append("] : ");

    sb.append(getMessage());

    return sb.toString();
  }

	protected String getLineItemNumber() {
		return super.getProgramElementNumber();
	}

	protected int getLineItemIndex() {
		return super.getProgramElementIndex();
	}
}
