/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.utility.FileUtil;

public class JBDefaultSystemGeneratedPart extends JBPart
        implements
            BudgesDownloadableObject {

    private static final long serialVersionUID = -9148562639452888106L;
    protected boolean hasErrors;
    protected boolean hasWarnings;
    protected boolean onlyPrcpWarnings;

    public Map<String, String> getPdfPropertiesToApply(
            Map<String, String> existingProps) {
        Map<String, String> props = existingProps;

        if (props == null) {
            props = new HashMap<String, String>();
        }
        props.put(Constants.PDF_PROPS_TITLE_KEY, title);
        props.put(Constants.PDF_PROPS_AUTHOR_KEY,
                "Office of the Under Secretary of Defense (Comptroller)");
        props.put(Constants.PDF_PROPS_SUBJECT_KEY, "Budget Justification");
        props.put(Constants.PDF_PROPS_KEYWORDS_KEY, "Budget");

        return props;
    }

    public String getBusinessId() {
        return title;
    }

    public EmbedableFile createEmbedableZipFile(File zipFile) {
        return new DefaultEmbedableFile(
                FileUtil.createZzzFileName(getBusinessId()),
                title + " XML (save & rename to .zip to open)", zipFile);
    }

    public InputStream getInputStream() throws IOException {
        return new BufferedInputStream(
                new FileInputStream(getAbsoluteFileName()));
    }

    public File getDataFilePath() {
        return new File(getAbsoluteFileName());
    }

    public String getUserVisibleLabel() {
        return FileUtil.createFileName(getContentType().getFileExtension(),
                getFileSetting().getFileNamePrefix());
    }

    public long getTotalSizeInBytes() throws IOException {
        return (new File(getAbsoluteFileName())).length();
    }

    public BudgesContentType getBudgesContentType() {
        return super.getContentType();
    }

    public boolean isHasErrors() {
        return this.hasErrors;
    }

    public void setHasErrors(boolean hasErrors) {
        this.hasErrors = hasErrors;
    }

    public boolean isHasWarnings() {
        return this.hasWarnings;
    }

    public void setHasWarnings(boolean hasWarnings) {
        this.hasWarnings = hasWarnings;
    }

    public void setOnlyPrcpWarnings(boolean onlyPrcpWarnings) {
        this.onlyPrcpWarnings = onlyPrcpWarnings;
    }

    public boolean isOnlyPrcpWarnings() {
        return onlyPrcpWarnings;
    }

}
