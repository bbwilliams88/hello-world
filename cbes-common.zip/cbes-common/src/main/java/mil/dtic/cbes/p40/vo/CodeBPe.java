package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._CodeBPe;

/**
 *
 */
public class CodeBPe extends _CodeBPe
{
    private static final long serialVersionUID = 1L;
}
