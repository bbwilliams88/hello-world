package mil.dtic.cbes.p40.vo;

public interface ShipP8aItemCostParent
{
  boolean jibx_hasCosts();
  boolean jibx_hasTotalCost();
  boolean jibx_hasQuantity();
  void jibx_setQuantity(ExtendedPYSCosts quantity);
  void jibx_setTotalCost(ExtendedPYSCosts totalCost);
  ExtendedPYSCosts getQuantity();
  ExtendedPYSCosts getTotalCost();
  String getTitle();
  void setTitle(String title);
  boolean jibx_hasTitle();
  String getTitleFootnote();
  void setTitleFootnote(String titleFootnote);
  Boolean getIsSignificant();
  void setIsSignificant(Boolean isSignificant);
  boolean jibx_hasIsSignificant();
}
