package mil.dtic.cbes.rule;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * Holds a set of rules.
 *
 * @author AZumkhaw
 *
 */
public class RuleRepository {
  private static final Logger log = LogManager.getLogger(RuleRepository.class);
  private Map<String, Rule> rules = new HashMap<String, Rule>();

  /**
   * Create a new repository, narrowed to a smaller set of rules.
   *
   * @param ruleCodes
   * @return
   */
  public RuleRepository narrowTo(String... ruleNumbers) {
    RuleRepository narrowedRepository = new RuleRepository();
    for (String ruleNumber : ruleNumbers) {
      if (!rules.containsKey(ruleNumber)) {
        throw new IllegalArgumentException("'" + ruleNumber + "' was not found in rule definitions.");
      }
      Rule r = rules.get(ruleNumber);
      narrowedRepository.addRule(r);
    }
    return narrowedRepository;
  }

  /**
   * Add a rule to the repository.
   *
   * @param rule
   */
  public void addRule(Rule rule) {
    String ruleKey = rule.getRuleNumber();
    if (rules.containsKey(ruleKey)) {
      log.error("Rule number collision: " + ruleKey);
    }
    rules.put(ruleKey, rule);
  }

  /**
   * Return all rules for a rule group.
   *
   * @param group
   * @return
   */
  public Set<Rule> rules(String group) {
    Set<Rule> ruleGroupRules = new HashSet<Rule>();
    for (Rule r : rules.values()) {
      if (group.equals(r.getRuleGroup())) {
        ruleGroupRules.add(r);
      }
    }
    return ruleGroupRules;
  }

  public Collection<Rule> getRules() {
    return rules.values();
  }

    /**
     * Useful when a rule repository has been narrowed to a specific rule, which
     * is quite common in the administration editors/functions.
     *
     * @return The first rule present in the rule repository or {@code null} if
     *         no rule is present.
     * @see narrowTo()
     */
    public Rule getFirstRule()
    {
        if (getRules().size() > 0)
            return getRules().iterator().next();
        else
            return null;

    }
    public void addExemptOrganization(String organizationCode, String ruleNumber)
    {
        Rule rule = rules.get(ruleNumber);

        if (rule != null)
            rule.addExemptOrganization(organizationCode);
    }

    public void removeExemptOrganization(String organizationCode, String ruleNumber)
    {
        Rule rule = rules.get(ruleNumber);

        if (rule != null)
            rule.removeExemptOrganization(organizationCode);
    }

    public void disableRule(String ruleNumber)
    {
        Rule rule = rules.get(ruleNumber);

        if (rule != null)
            rule.setActive(false);

//        rules.remove(ruleNumber);
    }

  /**
   * Return rule groups with associated rules in this repository.
   *
   * @return
   */
  private Set<String> ruleGroups() {
    Set<String> ruleBuckets = new HashSet<String>();
    for (Rule r : rules.values()) {
      ruleBuckets.add(r.getRuleGroup());
    }
    return ruleBuckets;
  }

  @Override
public String toString() {
	  StringBuilder sb = new StringBuilder();

	  Set<String>ruleGroups = ruleGroups();
	  for (String group : ruleGroups){
		  if (sb.length()>0){
			  sb.append(",");
		  }
		  sb.append("'");
		  sb.append(group);
		  sb.append("':");
		  Set<Rule> rules = rules(group);
		  StringBuilder rSb = new StringBuilder();
		  for (Rule r : rules){
			  if (rSb.length()>0){
				  rSb.append(",");
			  }
			  rSb.append("'");
			  rSb.append(r.getRuleNumber());
			  rSb.append("'");
		  }
		  rSb.append("]");
		  rSb.insert(0,"[");
		  sb.append(rSb.toString());
	  }

	  sb.append("}");
	  sb.insert(0, "{");
	  return sb.toString();
  }
}
