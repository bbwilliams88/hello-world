package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.ObjectContext;

import mil.dtic.cbes.enums.BudgetYearType;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._InstallationCost;
import mil.dtic.utility.Util;

public class InstallationCost extends _InstallationCost implements HasTripletCosts, CostContainer
{
  private static final long serialVersionUID = 1L;


  /***********************************************************************/
  /*** Cayenne Callbacks ***/
  /***********************************************************************/

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);

    setQuantities(Costs.create(getObjectContext(), CostRowType.QUANTITY));
    setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
  }


  @Override
  protected void onPrePersist()
  {
    Util.cleanupContinuingTriplet(this);
  }


  /***********************************************************************/
  /*** Business Logic / Custom Accessors ***/
  /***********************************************************************/

  public void jibx_postSet()
  {
  }


  // FIXME: Should be an is* method.
  public boolean hasAny()
  {
    return !getQuantities().isEmpty() || !getTotalCosts().isEmpty();
  }


  @Override
  public boolean isContinuing()
  {
    return getTotalCosts() != null && getTotalCosts().isContinuing();
  }


  public Costs getCosts()
  {
    return getTotalCosts();
  }


  @Override
  public Costs getUnitCosts()
  {
    return new Costs(); // unused, shut up jibx
  }


  @Override
  public void setUnitCosts(Costs c)
  {
    // unused, no unit costs in mods
  }


  public void shiftForwardInTime(int years)
  {
    if (this.getTotalCosts() != null)
      this.getTotalCosts().shiftForwardInTime(years);

    if (this.getQuantities() != null)
      this.getQuantities().shiftForwardInTime(years);
  }


  /***********************************************************************/
  /*** Utilities ***/
  /***********************************************************************/

  public static InstallationCost create(ObjectContext context, BudgetYearType year)
  {
    InstallationCost installationCost = context.newObject(InstallationCost.class);

    installationCost.setYear(year);

    return installationCost;
  }


  /***********************************************************************/
  /*** JiBX Support ***/
  /***********************************************************************/

  public boolean jibx_hasPriorYears()
  {
    return getQuantities().jibx_isPriorYears() || getTotalCosts().jibx_isPriorYears();
  }


  public boolean jibx_hasPriorYear()
  {
    return getQuantities().jibx_isPriorYear() || getTotalCosts().jibx_isPriorYear();
  }


  public boolean jibx_hasCurrentYear()
  {
    return getQuantities().jibx_isCurrentYear() || getTotalCosts().jibx_isCurrentYear();
  }


  public boolean jibx_hasBy1Base()
  {
    return getQuantities().getBy1Base() != null || getTotalCosts().getBy1Base() != null;
  }


  public boolean jibx_hasBy1Ooc()
  {
    return getQuantities().getBy1Ooc() != null || getTotalCosts().getBy1Ooc() != null;
  }


  public boolean jibx_hasBy1()
  {
    return getQuantities().jibx_isBy1() || getTotalCosts().jibx_isBy1();
  }


  public boolean jibx_hasBy2()
  {
    return getQuantities().jibx_isBy2() || getTotalCosts().jibx_isBy2();
  }


  public boolean jibx_hasBy3()
  {
    return getQuantities().jibx_isBy3() || getTotalCosts().jibx_isBy3();
  }


  public boolean jibx_hasBy4()
  {
    return getQuantities().jibx_isBy4() || getTotalCosts().jibx_isBy4();
  }


  public boolean jibx_hasBy5()
  {
    return getQuantities().jibx_isBy5() || getTotalCosts().jibx_isBy5();
  }


  public boolean jibx_hasToComplete()
  {
    return !isContinuing() && (getQuantities().jibx_isToComplete() || getTotalCosts().jibx_isToComplete());
  }


  public boolean jibx_hasTotal()
  {
    return !isContinuing() && (getQuantities().jibx_isTotal() || getTotalCosts().jibx_isTotal());
  }


  @Override
  public String jibx_getContinuingFootnote()
  {
    return getTotalCosts().getContinuingFootnote();
  }


  @Override
  public void jibx_setContinuingFootnote(String s)
  {
    getTotalCosts().setContinuingFootnote(s);
  }


  @Override
  public boolean jibx_hasQuantity()
  {
    return getQuantities() != null && !getQuantities().isEmpty();
  }


  @Override
  public boolean jibx_hasTotalCost()
  {
    return getTotalCosts() != null && !getTotalCosts().isEmpty();
  }


  @Override
  public boolean jibx_hasUnitCost()
  {
    return getUnitCosts() != null && !getUnitCosts().isEmpty();
  }


  public void jibx_setQuantities(Costs quantities)
  {
    if (quantities != null)
      setQuantities(quantities);
  }


  public void jibx_setTotalCosts(Costs totalCosts)
  {
    if (totalCosts != null)
      setTotalCosts(totalCosts);
  }


  public void jibx_setUnitCosts(Costs unitCosts)
  {
    if (unitCosts != null)
      setUnitCosts(unitCosts);
  }
}
