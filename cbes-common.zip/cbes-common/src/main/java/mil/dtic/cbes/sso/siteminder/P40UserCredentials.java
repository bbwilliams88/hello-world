package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.utility.CbesLogFactory;

public class P40UserCredentials implements Serializable {
  private static final long serialVersionUID = -1030327781085699222L;
  private static final Logger log = CbesLogFactory.getLog(UserCredentials.class);

  protected P40UserInfo p40UserInfo;
  private final P40PrivilegeChecker privs = new P40PrivilegeChecker(this);


  public P40UserCredentials() {}

  public P40UserInfo getP40UserInfo(){
    return this.p40UserInfo;
  }

  public void setP40UserInfo(P40UserInfo p40UserInfo) {
    this.p40UserInfo = p40UserInfo;
  }

  // convenience method for tapestry pages
  public P40PrivilegeChecker getPrivs(){
    return privs;
  }

  public boolean checkPrivilege(Privilege p) {
    if (p40UserInfo != null) {
      return p40UserInfo.checkPrivilege(p);
    }
    return false;
  }

  
  public boolean canAccessSiteInMaintenanceMode() {
    boolean canAccess = false;
    if (p40UserInfo != null) {
      canAccess = checkPrivilege(Privilege.ACCESS_IN_MAINTENANCE_MODE);
    }
    return canAccess;
  }

  public boolean saveLiAllowed(LineItem li) {
    if (p40UserInfo != null){
      return p40UserInfo.saveLiAllowed(li);
    }
    return false;
  }

  
  public boolean deleteLiAllowed(LineItem li) {
    if (p40UserInfo != null){
    	return p40UserInfo.deleteLiAllowed(li);
    }
    return false;
  }

  
  public boolean editLiUsersAllowed(LineItem li){
    if (p40UserInfo != null) {
      log.debug("p40UserInfo.editLiUsersAllowed(li):" + p40UserInfo.editLiUsersAllowed(li));
      return p40UserInfo.editLiUsersAllowed(li);
    }
    log.debug("p40UserInfo.editLiUsersAllowed(li): p40UserInfo = NULL?");
    return false;
  }

  
  public boolean viewLiAllowed(LineItem li){
    if (p40UserInfo != null) {
      return p40UserInfo.viewLiAllowed(li);
    }
    return false;
  }

  // FIXME: Bad Name
  
  public boolean createLiAllowed() {
    if (p40UserInfo != null) {
      return p40UserInfo.createLiAllowed();
    }
    return false;
  }

  
  public boolean isLockedByOther(LineItem exhibit) {
    if (p40UserInfo != null){
      return p40UserInfo.isLockedByOther(exhibit);
    }
    return false;
  }

  
  public boolean isLockedByMe(LineItem exhibit) {
    if (p40UserInfo != null) {
    	return p40UserInfo.isLockedByMe(exhibit);
    }
    return false;
  }

  
  public boolean isNotLocked(LineItem exhibit)  {
    if (p40UserInfo != null) {
      return p40UserInfo.isNotLocked(exhibit);
    }
    return false;
  }

  
  public boolean isEntireLockedByOther(LineItem li) {
    if (p40UserInfo != null) {
      return p40UserInfo.isEntireLockedByOther(li);
    }
    return false;
  }

  
  public boolean isEntireLockedByMe(LineItem li) {
    if (p40UserInfo != null) {
      return p40UserInfo.isEntireLockedByMe(li);
    }
    return false;
  }
  
  
  public boolean canDeleteBudgesJob(){
    boolean canDelete = false;
    if(p40UserInfo != null){
      canDelete = p40UserInfo.canDeleteBudgesJob();
    }
    return canDelete;
  }

  
  public String toString() {
    return "UserCredentials{" + p40UserInfo + "}";
  }
}