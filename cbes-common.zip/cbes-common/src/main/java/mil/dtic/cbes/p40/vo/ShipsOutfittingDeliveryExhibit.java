package mil.dtic.cbes.p40.vo;

import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ShipsOutfittingDeliveryExhibit;
import mil.dtic.utility.CbesLogFactory;

/**
 *
 */
public class ShipsOutfittingDeliveryExhibit extends _ShipsOutfittingDeliveryExhibit  implements ItemExhibitType
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(ShipsOutfittingDeliveryExhibit.class);

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/
    // Put is*/get*/set* methods here.
    @Override
    public Costs getCosts()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Costs getUnitCosts()
    {
      return null;
    }

    @Override
    public Costs getQuantities()
    {
      return null;
    }

    @Override
    public void shiftForwardInTime(int years)
    {
      // TODO Auto-generated method stub
      
    }

    @Override
    public String getIdentifyingString()
    {
      return "Shipbuilding and Conversion, Navy";
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public void jibx_setToaDeliveryCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setToaDeliveryCosts(costs);
      }
    }
    
    public void jibx_setToaOutfittingCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setToaOutfittingCosts(costs);
      }
    }
    
    public void jibx_setToaFirstDestinationCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setToaFirstDestinationCosts(costs);
      }
    }
    
    public void jibx_setP29outfittingCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setP29outfitting(costs);
      }
    }
    
    public void jibx_setP30deliveryCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setP30delivery(costs);
      }
    }
    
    public void jibx_setP30destinationCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setP30destination(costs);
      }
    }
    
    public boolean jibx_hasToaDeliveryCosts()
    {
      return getToaDeliveryCosts() != null;
    }
    
    public boolean jibx_hasToaOutfittingCosts()
    {
      return getToaOutfittingCosts() != null;
    }
    
    public boolean jibx_hasToaFirstDestinationCosts()
    {
      return getToaFirstDestinationCosts() != null;
    }
    
    public boolean jibx_hasShipsOutfittingDeliveryCostCategory()
    {
      return CollectionUtils.isNotEmpty(getOutfittingDeliveryCostCategory());
    }
    
    public boolean jibx_hasP29outfittingCosts()
    {
      return getP29outfitting() != null;
    }
    
    public boolean jibx_hasP30deliveryCosts()
    {
      return getP30delivery() != null;
    }
    
    public boolean jibx_hasP30destinationCosts()
    {
      return getP30destination() != null;
    }
    
    public Iterator<ShipsOutfittingDeliveryCostCategory> jibx_shipsOutfittingDeliveryCostCategoryIterator()
    {
      return getOutfittingDeliveryCostCategory().iterator();
    }
    
    public void jibx_postSet()
    {
      
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
