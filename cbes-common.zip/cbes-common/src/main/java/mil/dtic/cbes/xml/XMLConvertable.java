package mil.dtic.cbes.xml;

import java.io.IOException;
import java.sql.SQLException;

import mil.dtic.utility.InvalidXMLListener;

public interface XMLConvertable
{
  public JavaToXmlResult toZip(InvalidXMLListener l) throws IOException, SQLException;
  public byte[] toXml(InvalidXMLListener l) throws IOException;
}