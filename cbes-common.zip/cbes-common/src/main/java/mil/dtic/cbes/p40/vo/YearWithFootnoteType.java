
package mil.dtic.cbes.p40.vo;

import java.math.BigInteger;

/** 
 * MYP Object generated with JiBX
 * This class is not to be committed to the DB
 */
public class YearWithFootnoteType
{
    private BigInteger integer;
    private String footnote;

    /** 
     * Get the extension value.
     * 
     * @return value
     */
    public BigInteger getInteger() {
        return integer;
    }

    /** 
     * Set the extension value.
     * 
     * @param integer
     */
    public void setInteger(BigInteger integer) {
        this.integer = integer;
    }

    /** 
     * Get the 'footnote' attribute value.
     * 
     * @return value
     */
    public String getFootnote() {
        return footnote;
    }

    /** 
     * Set the 'footnote' attribute value.
     * 
     * @param footnote
     */
    public void setFootnote(String footnote) {
        this.footnote = footnote;
    }
}
