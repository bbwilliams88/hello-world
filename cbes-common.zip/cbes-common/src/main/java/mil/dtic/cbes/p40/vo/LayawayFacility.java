package mil.dtic.cbes.p40.vo;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.p40.vo.auto._LayawayFacility;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 *
 */
public class LayawayFacility extends _LayawayFacility
{
    private static final Logger log = CbesLogFactory.getLog(LayawayFacility.class);
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    public void onPrePersist()
    {

    }

    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    @Override
    public Costs getCosts()
    {
        Costs costs = new Costs();

        for (LayawayDistributionProject project : getFacilityProjectList())
            costs.add(project.getCosts());

        return costs;
    }

    public List<LayawayDistributionProject> getFacilityProjectList()
    {
        return getLayawayDistributionProjectList();
    }

    public void setFacilityProjectList(List<LayawayDistributionProject> layawayDistributionProjects)
    {
        log.trace("Collection setters not implemented " + (layawayDistributionProjects == null ? null : layawayDistributionProjects.size()));
    }

    @Override
    public List<LayawayDistributionProject> getLayawayDistributionProjectList()
    {
        return getSortedByDisplayOrder(super.getLayawayDistributionProjectList());
    }

    @Override
    public Costs getQuantities()
    {
      return null;
    }

    @Override
    public Costs getUnitCosts()
    {
      return null;
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        for (LayawayDistributionProject layawayDistributionProject : this.getLayawayDistributionProjectList())
            layawayDistributionProject.shiftForwardInTime(years);
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasLayawayDistributionProjectList()
    {
        return CollectionUtils.isNotEmpty(super.getLayawayDistributionProjectList());
    }

    public Iterator<LayawayDistributionProject> jibx_LayawayDistributionProjectIterator()
    {
        return getIterator(super.getLayawayDistributionProjectList());
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(super.getLayawayDistributionProjectList());
    }
}
