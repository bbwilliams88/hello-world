package mil.dtic.cbes.p40.vo;

import java.io.Serializable;

import mil.dtic.cbes.p40.vo.auto._ManufacturerQuantity;

/**
 *
 */
public class ManufacturerQuantity extends _ManufacturerQuantity implements Serializable
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasAdminLeadTimeBeforeOct()
    {
        return getAdminLeadTimeBeforeOct1() != null;
    }

    public boolean jibx_adminLeadTimeBeforeOctGreaterThanZero()
    {
        return getAdminLeadTimeBeforeOct1() > 0;
    }

    public boolean jibx_hasAdminLeadTimeAfterOct1()
    {
        return getAdminLeadTimeAfterOct1() != null;
    }

    public boolean jibx_adminLeadTimeAfterOct1GreaterThanZero()
    {
        return getAdminLeadTimeAfterOct1() > 0;
    }

    public boolean jibx_hasProductionLeadTimeAfterOct1()
    {
        return getMFGAfterOct1() != null;
    }

    public boolean jibx_productionLeadTimeAfterOct1GreaterThanZero()
    {
        return getMFGAfterOct1() > 0;
    }

    public boolean jibx_hasTotalAfterOct1()
    {
        return getTotalAfterOct1() != null;
    }

    public boolean jibx_totalAfterOct1GreaterThanZero()
    {
        return getTotalAfterOct1() > 0;
    }
}