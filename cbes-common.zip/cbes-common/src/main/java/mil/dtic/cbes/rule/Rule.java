package mil.dtic.cbes.rule;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Represents a business rule, comprised of a rule number, a rule message, and a
 * rule group to associate with.
 */
public class Rule implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String ruleNumber;
    private String ruleMessage;
    private String ruleGroup;

    private boolean active = true;

    private Set<String> exemptOrganizations = new HashSet<>();

    public Rule(String ruleNumber, String ruleMessage, String ruleGroup)
    {
        this.ruleNumber = ruleNumber;
        this.ruleMessage = ruleMessage;
        this.ruleGroup = ruleGroup;
    }

    public String getRuleGroup()
    {
        return this.ruleGroup;
    }

    public String getRuleNumber()
    {
        return ruleNumber;
    }

    public String getRuleMessage()
    {
        return ruleMessage;
    }

    public boolean isActive()
    {
        return active;
    }

    public Set<String> getExemptOrganizations()
    {
        return exemptOrganizations;
    }

    public void setActive(boolean active)
    {
        this.active = active;
    }

    public void addExemptOrganization(String organizationCode)
    {
        exemptOrganizations.add(organizationCode);
    }

    public void removeExemptOrganization(String organizationCode)
    {
        exemptOrganizations.remove(organizationCode);
    }

    public boolean isExempt(String organizationCode)
    {
        if (exemptOrganizations.contains(organizationCode))
            return true;

        return false;
    }

    public boolean isNotExempt(String organizationCode)
    {
        return isExempt(organizationCode) == false;
    }

    @Override
    public String toString()
    {
        return "[" + ruleNumber + "] " + ruleMessage;
    }
}
