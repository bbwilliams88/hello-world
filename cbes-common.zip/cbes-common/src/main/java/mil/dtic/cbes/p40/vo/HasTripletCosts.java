package mil.dtic.cbes.p40.vo;


/**
 *
 */
public interface HasTripletCosts extends HasTotalCostsAndQuantities, HasUnitCosts
{
}
