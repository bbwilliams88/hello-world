/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.Util;


public class JBPeToc extends JBDefaultSystemGeneratedPart
{
  private static final Logger log = CbesLogFactory.getLog(JBPeToc.class);

  List<KeyValuePair> pageNumberKvpList = null;


  public JBPeToc(FileSetting pdfFileSetting, String titlePrefix)
  {
    setFileSetting(pdfFileSetting);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, pdfFileSetting.getTitle()));
  }


  public FormattingResults createPdf() throws IOException, DocumentException, SQLException
  {
    if (pageNumberKvpList != null)
    {
      docCreationParams.setPageNumberKvpList(pageNumberKvpList);
    }
    FormattingResults fr = super.createPdf();
    return fr;
  }


  public List<KeyValuePair> getPageNumberKvpList()
  {
    return pageNumberKvpList;
  }


  public void setPageNumberKvpList(List<KeyValuePair> pageNumberKvpList)
  {
    this.pageNumberKvpList = pageNumberKvpList;
  }

}
