package mil.dtic.cbes.jobs;

import java.io.Serializable;


/**
 * AsynchJobBudgetCycle created per CXE-6470/1
 * provides Tracking Page capability to view/search asynchronis jobs by budget cycle.
 *
 */
public class AsynchJobBudgetCycle implements Serializable{
    private static final long serialVersionUID = -5529170791029678644L;

    public AsynchJobBudgetCycle(){}
    
    public AsynchJobBudgetCycle(int id, String label){
        this.sortId = id;
        this.label = label;
    }
    
    private int sortId;
    private String label;
    
    public int getSortId() {
        return sortId;
    }
    
    public void setSortId(int sortId) {
        this.sortId = sortId;
    }
    
    public String getLabel() {
        return label;
    }
    
    public void setLabel(String label) {
        this.label = label;
    }
    
    @Override
    public String toString() {
        return "AsynchJobBudgetCycle [sortId=" + sortId + ", label=" + label + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + sortId;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AsynchJobBudgetCycle other = (AsynchJobBudgetCycle) obj;
        if (label == null) {
            if (other.label != null)
                return false;
        } else if (!label.equals(other.label))
            return false;
        if (sortId != other.sortId)
            return false;
        return true;
    }
    
    
    
    
}
