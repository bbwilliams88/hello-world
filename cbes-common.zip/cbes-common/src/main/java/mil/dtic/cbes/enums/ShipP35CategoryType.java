package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ShipP35CategoryType implements ExtendedEnumeration
{
    MAJOR_HARDWARE                    ("MajorHardware",                 "MAJOR_HARDWARE",                   "Major Hardware"), 
    ANCILLARY_EQUIPMENT               ("AncillaryEquipment",            "ANCILLARY_EQUIPMENT",              "Ancillary Equipment"),
    TECHNICAL_DATA_AND_DOCUMENTATION  ("TechnicalDataAndDocumentation", "TECHNICAL_DATA_AND_DOCUMENTATION", "Technical Data and Documentation"),
    SPARES                            ("Spares",                        "SPARES",                           "Spares"), 
    SYSTEM_ENGINEERING                ("SystemEngineering",             "SYSTEM_ENGINEERING",               "System Engineering"),
    TECHNICAL_ENGINEERING_SERVICES    ("TechnicalEngineeringServices",  "TECHNICAL_ENGINEERING_SERVICES",   "Technical Engineering Services"),
    ASSEMBLY_AND_INTEGRATION          ("AssemblyAndIntegration",        "ASSEMBLY_AND_INTEGRATION",         "Assembly and Integration"), 
    OTHER_COSTS                       ("OtherCosts",                    "OTHER_COSTS",                      "Other Costs"),
    USER_DEFINED                      ("",                              "USER_DEFINED",                     "User Defined P-35 Cost Categories");

    private final String xmlName;
    private final String dbName;
    private final String description;

    private ShipP35CategoryType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static ShipP35CategoryType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ShipP35CategoryType.class, databaseValue);
    }

    public static ShipP35CategoryType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ShipP35CategoryType.class, enumValue);
    }
}
