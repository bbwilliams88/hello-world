/*
 * $Id$
 */
package mil.dtic.cbes.service;

public class ValidationMessageImpl implements ValidationMessage
{
  protected String message;
  protected String errorCode;
  protected int lineNum;
  protected int colNum;
  protected int severity;

  protected ValidationMessageImpl()  
  {
    message = null;
    errorCode = null;
    lineNum = NO_VALUE;    
    colNum = NO_VALUE;    
    severity = NO_VALUE;
  }

  public ValidationMessageImpl(String message)
  {
    this();
    this.message = message;
  }

  public ValidationMessageImpl(String message, String errorCode)
  {
    this(message);
    this.errorCode = errorCode;
  }
  
  public ValidationMessageImpl(String message, String errorCode, int lineNum)
  {
    this(message, errorCode);
    this.lineNum = lineNum;
  }

  public ValidationMessageImpl(String message, String errorCode, int lineNum, int colNum)
  {
    this(message, errorCode, lineNum);
    this.colNum = colNum;
  }

  public ValidationMessageImpl(String message, String errorCode, int lineNum, int colNum, int severity)
  {
    this(message, errorCode, lineNum, colNum);
    this.severity = severity;
  }
  
  public String getMessage()
  {
    return this.message;
  }

  public void setMessage(String message)
  {
    this.message = message;
  }

  public String getErrorCode()
  {
    return this.errorCode;
  }

  public void setErrorCode(String errorCode)
  {
    this.errorCode = errorCode;
  }

  public int getLineNum()
  {
    return this.lineNum;
  }

  public void setLineNum(int lineNum)
  {
    this.lineNum = lineNum;
  }

  public int getColNum()
  {
    return this.colNum;
  }

  public void setColNum(int colNum)
  {
    this.colNum = colNum;
  }

  public int getSeverity()
  {
    return this.severity;
  }

  public void setSeverity(int severity)
  {
    this.severity = severity;
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer("[");

    if (getLineNum() > 0)
    {
      sb.append("Line " + getLineNum());
    }

    if (getColNum() > 0)
    {
      if (sb.length() > 1)
        sb.append(", ");
      sb.append("Col " + getColNum());
    }

    if (getErrorCode() != null)
    {
      if (sb.length() > 1)
        sb.append(", ");

      sb.append("ERR# " + getErrorCode());
    }

    sb.append("] : ");

    sb.append(getMessage());

    return sb.toString();
  }
}
