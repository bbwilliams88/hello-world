/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.util.List;

import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.utility.KeyValuePair;

public class XmlToJavaResult
{
  private MasterJustificationBook mjb;
  private JustificationBook jb;
  private R2ExhibitList r2ExhibitList;
  private List<KeyValuePair> r4KvpList;
  private LineItemList lineItemList;
  private XMLConvertable xmlConvertable;


  public MasterJustificationBook getMjb()
  {
    return mjb;
  }


  public void setMjb(MasterJustificationBook mjb)
  {
    this.mjb = mjb;
  }


  public JustificationBook getJb()
  {
    return jb;
  }


  public void setJb(JustificationBook jb)
  {
    this.jb = jb;
  }



  public R2ExhibitList getR2ExhibitList()
  {
    return r2ExhibitList;
  }


  public void setR2ExhibitList(R2ExhibitList exhibitList)
  {
    r2ExhibitList = exhibitList;
  }


  public List<KeyValuePair> getR4KvpList()
  {
    return r4KvpList;
  }


  public void setR4KvpList(List<KeyValuePair> kvpList)
  {
    r4KvpList = kvpList;
  }


  public LineItemList getLineItemList()
  {
    return lineItemList;
  }
  
  
  public void setLineItemList(LineItemList lineItemList)
  {
    this.lineItemList = lineItemList;
  }


  public XMLConvertable getXmlConvertable()
  {
    return xmlConvertable;
  }


  public void setXmlConvertable(XMLConvertable xmlConvertable)
  {
    this.xmlConvertable = xmlConvertable;
  }
}
