package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.jb.IAppropriation;
import mil.dtic.cbes.p40.vo.auto._Appropriation;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

/**
 *
 */
public class Appropriation extends _Appropriation implements IAppropriation, Equivalence<Appropriation>
{
    private static final long serialVersionUID = 1L;

    // FIXME: The following isn't use? Commenting out unless it breaks.
    // public static final String CODE_PLUS_NAME_PROPERTY = "codePlusName";

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return The active Budget Activities for this Appropriation.
     */
    public List<BudgetActivity> getActiveBudgetActivityList()
    {
        Expression expression = ExpressionFactory.matchExp(BudgetActivity.STATUS_PROPERTY, StatusType.ACTIVE);

        return expression.filterObjects(getBudgetActivityList());
    }

    /**
     * @return The active Service Agencies for this Appropriation.
     */
    public List<ServiceAgency> getActiveServiceAgencyList()
    {
        Expression expression = ExpressionFactory.matchExp(ServiceAgency.STATUS_PROPERTY, StatusType.ACTIVE);

        return expression.filterObjects(getServiceAgencyList());
    }

    /**
     * @return The Appropration's code and name, separated by a dash.
     */
    public String getCodePlusName()
    {
        return getCode() + " - " + getName();
    }

    /**
     * Ignored operation. Cayenne doesn't allow attributes to be set as
     * read-only, but we do not want this attribute to be changed via the
     * application, so ignore any attempts.
     */
    @Override
    public void setCode(String code)
    {
    }

    /**
     * Ignored operation. Cayenne doesn't allow attributes to be set as
     * read-only, but we do not want this attribute to be changed via the
     * application, so ignore any attempts.
     */
    @Override
    public void setName(String name)
    {
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * Fetch a single Appropriation.
     *
     * @param dataContext
     *            The DataContext used to perform the fetch.
     * @param appropriationCode
     *            The appropriation code to match.
     *
     * @return The matching appropriation or null if no matches. If there are
     *         multiple matches, only the first match is returned.
     */
    // FIXME: Rename to fetchWithCode.
    public static Appropriation getWithCode(DataContext dataContext, String appropriationCode)
    {
        return Base.fetchOne(dataContext, Appropriation.class, Appropriation.CODE_PROPERTY, appropriationCode);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        if (this.isDeleted())
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getName()));
        builder.append(toLowerAndTrim(getCode()));

        return builder.toHashCode();
    }

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(Appropriation obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        Appropriation other = obj;

        if (this.isDeleted() || other.isDeleted())
            return super.equals(obj);

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName()));
        builder.append(toLowerAndTrim(getCode()), toLowerAndTrim(other.getCode()));

        return builder.isEquals();
    }
    
    @Override
    public boolean equals(Object object)
    {
        return equivalentTo((Appropriation)object);
    }
}
