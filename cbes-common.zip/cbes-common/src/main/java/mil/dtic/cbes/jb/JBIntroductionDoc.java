/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBIntroductionDoc extends JBDefaultUserSuppliedPart {
  public JBIntroductionDoc() {
    setFileSetting(FileSetting.INTRODUCTON_DOC); 
    setTitle(fileSetting.getTitle());    
    setFixedTitle(true); // title cannot be changed by user    
  } 
}
