package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._OtherBasicItems;

/**
 *
 */
public class OtherBasicItems extends _OtherBasicItems
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    
    public boolean jibx_hasName()
    {
      return StringUtils.isNotEmpty(getName());
    }
    
    public boolean jibx_hasAmount()
    {
      return getAmount() != null;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
