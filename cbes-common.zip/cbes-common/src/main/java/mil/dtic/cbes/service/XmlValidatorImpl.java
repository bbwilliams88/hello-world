/*
 * $Id$
 */
package mil.dtic.cbes.service;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.transform.sax.SAXSource;

import org.apache.logging.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.Util;

public abstract class XmlValidatorImpl implements XmlValidator
{
  private static final Logger log = CbesLogFactory.getLog(XmlValidatorImpl.class);

  protected List<String> warningList = new ArrayList<String>();;
  protected List<String> errorList = new ArrayList<String>();

  protected InputStream xmlInputStream;
  protected File xmlFile;
  protected String xmlString;


  public XmlValidatorImpl()
  {
  }


  public XmlValidatorImpl(InputStream xmlInputStream)
  {
    if (xmlInputStream == null)
      Util.throwRuntimeException("Xml input stream is null.");

    this.xmlInputStream = xmlInputStream;
  }


  public XmlValidatorImpl(File xmlFile)
  {
    this.xmlFile = xmlFile;
  }


  public XmlValidatorImpl(String xmlString)
  {
    this.xmlString = xmlString;
  }


  @Override
abstract public boolean validate(String organizationCode);


  @Override
public boolean hasWarnings()
  {
    return(warningList.size() > 0);
  }


  @Override
public boolean hasErrors()
  {
    return(errorList.size() > 0);
  }


  public SAXSource getInputXmlAsSAXSource()
  {
    SAXSource ss = null;
    if (xmlFile != null)
    {
      InputStream fileInputStream = null;
      InputStream bufferedInputStream = null;
      try
      {
        fileInputStream = new FileInputStream(xmlFile);
        bufferedInputStream = new BufferedInputStream(fileInputStream);
        ss = new SAXSource(new InputSource(bufferedInputStream));
        XMLReader xmlReader = XMLReaderFactory.createXMLReader();
        xmlReader.setFeature("http://xml.org/sax/features/external-general-entities", false);
        ss.setXMLReader(xmlReader);
      }
      catch (SAXException xe) {
        log.error("XML Reader had an exception: " + xe.getMessage());
      } catch (FileNotFoundException e) {
        log.error("Could not get SAX source for xml file: " + xmlFile.getAbsolutePath());
      } catch(RuntimeException e) {
        log.error("Exception while creating XML reader: " + e.getMessage());
        FileUtil.close(bufferedInputStream);
        FileUtil.close(fileInputStream);
        throw e;
      }
    }
    else if (xmlInputStream != null) {
      log.debug("Getting xml from inputstream");
      ss = new SAXSource(new InputSource(xmlInputStream));
      try {
        XMLReader xmlReader = XMLReaderFactory.createXMLReader();
        xmlReader.setFeature("http://xml.org/sax/features/external-general-entities", false);
        ss.setXMLReader(xmlReader);
      } catch (SAXException e) {
        log.error("XML Reader had an exception: " + e.getMessage());
      }
    }
    else if (xmlString != null)
    {
      InputStream is = null;
      try
      {
        is = Util.getResourceFromClassPath(xmlString);
        ss = new SAXSource(new InputSource(is));
      }
      catch (RuntimeException e)
      {
        log.error("XML Reader had an exception: " + xmlString);
        FileUtil.close(is);
        throw e;
      }
    }

    return ss;
  }


  protected void addError(String msg)
  {
    errorList.add(msg);
  }


  protected void addWarning(String msg)
  {
    warningList.add(msg);
  }


  @Override
public List<String> getWarningList()
  {
    return this.warningList;
  }


  @Override
public List<String> getErrorList()
  {
    // log.trace("pdoc39_125_" + errorList.toString()); //we're still on jboss 4
    // with no TRACE
    return this.errorList;
  }


  @Override
public Map<String, List<String>> getErrorListMap()
  {
    return null;
  }


  @Override
public Map<String, List<String>> getWarningListMap()
  {
    return null;
  }


  public InputStream getXmlInputStream()
  {
    return this.xmlInputStream;
  }


  public File getXmlFile()
  {
    return this.xmlFile;
  }


  public String getXmlString()
  {
    return this.xmlString;
  }

}
