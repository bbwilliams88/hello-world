package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.util.EqualsBuilder;
import org.apache.cayenne.util.HashCodeBuilder;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.auto._Manufacturer;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.BigDecimalUtil;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class Manufacturer extends _Manufacturer implements HasDisplayOrder, Equivalence<Manufacturer>
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(Manufacturer.class);
    private static final String TBD_RATE = "TBD";

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
        setInitialQuantity(new ManufacturerQuantity());
        setReorderQuantity(new ManufacturerQuantity());
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public HistoryPlanning addHistoryPlanning()
    {
        HistoryPlanning hp = getObjectContext().newObject(HistoryPlanning.class);
        addToHistoryPlanningList(hp);
        return hp;
    }

    public void deleteHistoryPlanning(HistoryPlanning historyPlanning)
    {
        removeFromHistoryPlanningList(historyPlanning);
        getObjectContext().deleteObjects(historyPlanning);
    }

    // Need to override the getReorderQuantity and getInitialQuantity to handle
    // the constructs of the UI vs Web Services.

    @Override
    public ManufacturerQuantity getInitialQuantity()
    {
        if (super.getInitialQuantity() == null)
            return new ManufacturerQuantity();

        return super.getInitialQuantity();
    }

    @Override
    public ManufacturerQuantity getReorderQuantity()
    {
        if (super.getReorderQuantity() == null)
            return new ManufacturerQuantity();

        return super.getReorderQuantity();
    }

    public String getNameAndLocation()
    {
        String name     = getName() == null ? "NA" : getName();
        String location = getLocation() == null ? "NA" : getLocation();

        return name + " / " + location;
    }

    public HasManufacturers getParent()
    {
        if (getCostElement() != null)
            return getCostElement();
        else if (getItem() != null)
            return getItem();
        else
            return getP10CostElement();
    }
    
    public boolean isMinimumSustainingRateTBD()
    {
      return BooleanUtils.isTrue(getMinimumSustainingRateTBD());
    }
    
    public boolean isMaximumProductionRateTBD()
    {
      return BooleanUtils.isTrue(getMaximumProductionRateTBD());
    }
    
    public boolean isRate185TBD()
    {
      return BooleanUtils.isTrue(getRate185TBD());
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    @SuppressWarnings("unchecked")
    public static List<Manufacturer> searchName(ObjectContext context, String name)
    {
        if (name != null)
        {
            Expression expression = ExpressionFactory.likeExp(NAME_PROPERTY, name + "%");

            SelectQuery query = new SelectQuery(Manufacturer.class, expression);

            return context.performQuery(query);
        }

        return Collections.emptyList();
    }
    
    @SuppressWarnings("unchecked")
    public static List<Manufacturer> searchLocation(ObjectContext context, String location)
    {
        if (location != null)
        {
            Expression expression = ExpressionFactory.likeExp(LOCATION_PROPERTY, location + "%");

            SelectQuery query = new SelectQuery(Manufacturer.class, expression);

            return context.performQuery(query);
        }

        return Collections.emptyList();
    }
    
    @SuppressWarnings("unchecked")
    public static List<Manufacturer> search(ObjectContext context, String name, String location)
    {
        if (name != null)
        {
            Expression expression = ExpressionFactory.likeExp(NAME_PROPERTY, name + "%");

            if (location != null)
                expression = expression.andExp(ExpressionFactory.likeExp(LOCATION_PROPERTY, location + "%"));

            SelectQuery query = new SelectQuery(Manufacturer.class, expression);

            return context.performQuery(query);
        }

        return Collections.emptyList();
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasName()
    {
        return getName() != null;
    }

    public boolean jibx_hasLocation()
    {
        return getLocation() != null;
    }

    // do a shortcut check for just the one required element
    // (TotalLeadTimeAfterOct1InMonths)
    public boolean jibx_hasInitialQuantity()
    {
        return getInitialQuantity() != null && (getInitialQuantity().getTotalAfterOct1() != null || getInitialQuantity().getMFGAfterOct1() != null);
    }

    public boolean jibx_hasReorderQuantity()
    {
        return getReorderQuantity() != null && getReorderQuantity().getTotalAfterOct1() != null;
    }

    public boolean jibx_hasHistoryPlanningList()
    {
        return CollectionUtils.isNotEmpty(super.getHistoryPlanningList());
    }

    public Iterator<HistoryPlanning> jibx_historyPlanningListIterator()
    {
        return getIterator(super.getHistoryPlanningList());
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    public Iterator<ExtendedHistoryPlanning> jibx_extendedHistoryPlanningListIterator()
    {
        List<HistoryPlanning> hpList = super.getHistoryPlanningList();
        List<ExtendedHistoryPlanning> ehpList = (List) hpList;
        return getIterator(ehpList);
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(super.getHistoryPlanningList());
    }

    public boolean jibx_hasMinimumSustainingRate()
    {
        return getMinimumSustainingRate() != null || isMinimumSustainingRateTBD();
    }

    public boolean jibx_hasMaximumProductionRate()
    {
        return getMaximumProductionRate() != null || isMaximumProductionRateTBD();
    }

    public boolean jibx_hasRate185()
    {
        return getRate185() != null || isRate185TBD();
    }

    public boolean jibx_minimumSustainingRateGreaterThanZero()
    {
        return BigDecimalUtil.isPositive(getMinimumSustainingRate());
    }

    public boolean jibx_maximumProductionRateGreaterThanZero()
    {
        return BigDecimalUtil.isPositive(getMaximumProductionRate());
    }

    public boolean jibx_rate185GreaterThanZero()
    {
        return BigDecimalUtil.isPositive(getRate185());
    }
    
    public boolean jibx_hasProductionLeadTime()
    {
        return getInitialQuantity() != null ? getInitialQuantity().jibx_hasProductionLeadTimeAfterOct1() : false;
    }
    
    public String jibx_getMinimumSustainingRate()
    {
      if (isMinimumSustainingRateTBD())
        return TBD_RATE;
      else
        return getMinimumSustainingRate() == null ? null : getMinimumSustainingRate().toPlainString(); 
    }
    
    public void jibx_setMinimumSustainingRate(String rate)
    {
      if (StringUtils.equals(rate, TBD_RATE))
        setMinimumSustainingRateTBD(Boolean.TRUE);
      else if (StringUtils.isNotEmpty(rate))
        setMinimumSustainingRate(new BigDecimal(rate));
    }
    
    public String jibx_getMaximumProductionRate()
    {
      if (isMaximumProductionRateTBD())
        return TBD_RATE;
      else
        return getMaximumProductionRate() == null ? null : getMaximumProductionRate().toPlainString(); 
    }
    
    public void jibx_setMaximumProductionRate(String rate)
    {
      if (StringUtils.equals(rate, TBD_RATE))
        setMaximumProductionRateTBD(Boolean.TRUE);
      else if (StringUtils.isNotEmpty(rate))
        setMaximumProductionRate(new BigDecimal(rate));
    }
    
    public String jibx_getRate185()
    {
      if (isRate185TBD())
        return TBD_RATE;
      else
        return getRate185() == null ? null : getRate185().toPlainString(); 
    }
    
    public void jibx_setRate185(String rate)
    {
      if (StringUtils.equals(rate, TBD_RATE))
        setRate185TBD(Boolean.TRUE);
      else if (StringUtils.isNotEmpty(rate))
        setRate185(new BigDecimal(rate));
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getName()));
        builder.append(toLowerAndTrim(getLocation()));
        builder.append(getCostElement());
        builder.append(getItem());

        return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(Manufacturer otherManufacturer)
    {
        if (this == otherManufacturer)
            return true;
        if (otherManufacturer == null)
            return false;
        if (getClass() != otherManufacturer.getClass())
            return false;

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getName()), toLowerAndTrim(otherManufacturer.getName()));
        builder.append(toLowerAndTrim(getLocation()), toLowerAndTrim(otherManufacturer.getLocation()));
        builder.append(getCostElement(), otherManufacturer.getCostElement());
        builder.append(getItem(), otherManufacturer.getItem());

        return builder.isEquals();
    }
}
