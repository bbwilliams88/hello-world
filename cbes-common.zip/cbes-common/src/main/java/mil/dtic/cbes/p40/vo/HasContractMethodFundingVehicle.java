package mil.dtic.cbes.p40.vo;

public interface HasContractMethodFundingVehicle
{
  public abstract P40ContractType getJibxContractType();

  public abstract P40ContractType _getJibxContractType();

  public abstract void setJibxContractType(P40ContractType jibxContractType);

  public abstract P40ContractMethod getJibxContractMethod();

  public abstract P40ContractMethod _getJibxContractMethod();

  public abstract void setJibxContractMethod(P40ContractMethod jibxContractMethod);

  public abstract P40FundingVehicle getJibxFundingVehicle();

  public abstract P40FundingVehicle _getJibxFundingVehicle();
  
  public abstract void setJibxFundingVehicle(P40FundingVehicle jibxFundingVehicle);
  
  public abstract void setContractMethodTypeFundingVehicle(ContractMethodTypeFundingVehicle contractMethodTypeFundingVehicle);
  
  public abstract ContractMethodTypeFundingVehicle getContractMethodTypeFundingVehicle();
}
