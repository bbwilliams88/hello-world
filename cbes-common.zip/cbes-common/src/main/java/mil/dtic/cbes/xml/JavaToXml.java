/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.jibx.runtime.BindingDirectory;
import org.jibx.runtime.IBindingFactory;
import org.jibx.runtime.IMarshallingContext;
import org.jibx.runtime.JiBXException;

import mil.dtic.cbes.jb.JBCover;
import mil.dtic.cbes.jb.JBDefaultUserSuppliedPart;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.MultiYearProcurementList;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.R4Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.Util;

public class JavaToXml
{
  private final static Logger log = CbesLogFactory.getLog(JavaToXml.class);

  private final File workingFolder;
  private JavaToXmlResult jtxResult;
  // Use this hashset to check for dup entries in zip file, which are not
  // allowed
  private Set<String> zipEntrySet;
  private final boolean excludeExternalObjectsInZip;


  public JavaToXml(File workingFolder)
  {
    this(workingFolder, false);
  }


  public JavaToXml(File workingFolder, boolean excludeExternalObjectsInZip){
      
      this.workingFolder = workingFolder;
      jtxResult = new JavaToXmlResult();
      this.excludeExternalObjectsInZip = excludeExternalObjectsInZip;
  }


  public static boolean toXml(Object obj, OutputStream os)
  {
    log.debug("Marshalling (Java to XML) from object: " + obj.getClass().getSimpleName());
    IMarshallingContext mctx = null;
    try
    {
      IBindingFactory bfact = BindingDirectory.getFactory(obj.getClass());
      mctx = bfact.createMarshallingContext();
      mctx.setIndent(4);
      mctx.marshalDocument(obj, "UTF-8", null, os);
      return true;
    }
    catch (JiBXException e)
    {
      log.error("Failed to marshall Java to XML from object: " + obj.getClass().getSimpleName(), e);
      if (mctx != null)
      {
        try
        {
          mctx.getXmlWriter().flush();
        }
        catch (IOException e2)
        {
          log.error("flushing", e2);
        }
      }
      return false;
    }
    finally
    {
      FileUtil.close(os);
    }
  }


  public static byte[] toXml(Object obj)
  {
    log.debug("Marshalling (Java to XML) to byte[] from object: " + obj.getClass().getSimpleName());

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    toXml(obj, bos);
    log.debug("Marshalling size: " + bos.size());
    return bos.toByteArray();
  }


  private void prep()
  {
    if (zipEntrySet == null)
      zipEntrySet = new HashSet<String>();
    else
      zipEntrySet.clear();
  }


  private boolean checkDupZipEntry(String zipEntryName)
  {
    return(!zipEntrySet.add(zipEntryName.toLowerCase()));
  }


  public JavaToXmlResult toZip(MasterJustificationBook mjb) throws IOException, SQLException {
    prep();

    String baseFileName = "MasterJB_File";

    File xmlFile = new File(workingFolder, FileUtil.createXmlFileName(baseFileName));
    jtxResult.setXmlFile(xmlFile);

    OutputStream os = new BufferedOutputStream(new FileOutputStream(xmlFile));
    toXml(mjb, os);

    ZipOutputStream zipFileStream = null;
    try
    {
      File zipFile = new File(workingFolder, FileUtil.createZzzFileName(baseFileName));
      jtxResult.setZipFile(zipFile);
      zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
      if(mjb.getBusinessId() == null)
        throw new FileNotFoundException("Unable to create filename: invalid or missing ID info");
      ZipEntry zipEntry = new ZipEntry(FileUtil.createXmlFileName(mjb.getBusinessId()));
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(xmlFile, zipFileStream, false);

      // TODO this line was redundant since it's done for each jb also, test &
      // permanently remove
      // writeExternalFile(mjb.getR2ExhibitList(), zipFileStream);
      if (!excludeExternalObjectsInZip)
      {
        writeExternalFile(mjb.getCoverDoc(), zipFileStream);
        writeExternalFile(mjb.getCostDoc(), zipFileStream);
        writeExternalFile(mjb.getIntroductionDoc(), zipFileStream);
        writeExternalFile(mjb.getSummaryDoc(), zipFileStream);
        writeExternalFile(mjb.getAcronymDoc(), zipFileStream);
        writeExternalFile(mjb.getUserR1Doc(), zipFileStream);
        writeExternalFile(mjb.getUserP1Doc(), zipFileStream);

        if (mjb.getSupplementalDocCollection() != null)
          writeExternalFile(mjb.getSupplementalDocCollection().getSupplementalDocList(), zipFileStream);
      }
      if (CollectionUtils.isNotEmpty(mjb.getJbgList()))
      {
        for (JustificationBookGroup jbg : mjb.getJbgList())
        {
          for (JustificationBookInfo jbi : jbg.getJbiList())
          {
            JustificationBook jb = jbi.getJb();
            log.debug("Now writing out JB external files for " + jb.getServiceAgency());
            writeExternalFile(jb.getR2ExhibitList(), zipFileStream);
            if (!excludeExternalObjectsInZip){
              writeExternalFile(jb.getCoverDoc(), zipFileStream);
              writeExternalFile(jb.getCostDoc(), zipFileStream);
              writeExternalFile(jb.getIntroductionDoc(), zipFileStream);
              writeExternalFile(jb.getSummaryDoc(), zipFileStream);
              writeExternalFile(jb.getAcronymDoc(), zipFileStream);
              writeExternalFile(jb.getUserR1Doc(), zipFileStream);
              writeExternalFile(jb.getUserP1Doc(), zipFileStream);
              if (jb.getSupplementalDocCollection() != null)
                writeExternalFile(jb.getSupplementalDocCollection().getSupplementalDocList(), zipFileStream);
            }
          }
        }
      }
    }
    catch (IOException e) {
      log.error("Could not create zip file for JB after java to xml.", e);
      throw e;
    } catch (SQLException e) {
      log.error("Could not create zip file for JB after java to xml.", e);
      throw e;
    }
    finally
    {
      FileUtil.close(zipFileStream);
    }
    return jtxResult;
  }


  public JavaToXmlResult toZip(JustificationBook jb) throws IOException, SQLException
  {
    prep();

    String baseFileName = "JB_File_" + jb.getPartIndex();

    File xmlFile = new File(workingFolder, FileUtil.createXmlFileName(baseFileName));
    jtxResult.setXmlFile(xmlFile);

    OutputStream os = new BufferedOutputStream(new FileOutputStream(xmlFile));
    toXml(jb, os);

    File zipFile = new File(workingFolder, FileUtil.createZzzFileName(baseFileName));
    try (ZipOutputStream zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile))))
    {
      jtxResult.setZipFile(zipFile);

      if(jb.getBusinessId() == null)
        throw new FileNotFoundException("Unable to create filename: invalid or missing ID info");
      ZipEntry zipEntry = new ZipEntry(FileUtil.createXmlFileName(jb.getBusinessId()));
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(xmlFile, zipFileStream, false);
      writeExternalFile(jb.getR2ExhibitList(), zipFileStream);

      if (!excludeExternalObjectsInZip)
      {
        writeExternalFile(jb.getCoverDoc(), zipFileStream);
        writeExternalFile(jb.getCostDoc(), zipFileStream);
        writeExternalFile(jb.getIntroductionDoc(), zipFileStream);
        writeExternalFile(jb.getSummaryDoc(), zipFileStream);
        writeExternalFile(jb.getAcronymDoc(), zipFileStream);
        writeExternalFile(jb.getUserR1Doc(), zipFileStream);
        writeExternalFile(jb.getUserP1Doc(), zipFileStream);
        if (jb.getSupplementalDocCollection() != null)
          writeExternalFile(jb.getSupplementalDocCollection().getSupplementalDocList(), zipFileStream);
      }
    }
    catch (FileNotFoundException e)
    {
      Util.error(log, "Could not create zip file for JB after java to xml.", e);
    }
//    finally
//    {
//      FileUtil.close(zipFileStream);
//    }
    return jtxResult;
  }


  public JavaToXmlResult toZip(R2ExhibitList r2ExhibitList) throws IOException, SQLException
  {
    prep();

    String baseFileName = "R2_File";
    if (r2ExhibitList != null && r2ExhibitList.getR2Exhibits().size() == 1) {
      baseFileName = r2ExhibitList.getR2Exhibits().get(0).getProgramElement().getBusinessId();
      if(baseFileName == null)
        throw new FileNotFoundException("Unable to create filename: invalid or missing ID info in first program element");
    }
    File xmlFile = new File(workingFolder, FileUtil.createXmlFileName(baseFileName));
    jtxResult.setXmlFile(xmlFile);
    if(r2ExhibitList != null) {
      OutputStream os = new BufferedOutputStream(new FileOutputStream(xmlFile));
      toXml(r2ExhibitList, os);
    }

    File zipFile = new File(workingFolder, FileUtil.createZzzFileName(baseFileName));
    try (ZipOutputStream zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile))))
    {
      jtxResult.setZipFile(zipFile);

      ZipEntry zipEntry = new ZipEntry(xmlFile.getName());
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(xmlFile, zipFileStream, false);
      writeExternalFile(r2ExhibitList, zipFileStream);
    }
    catch (IOException e)
    {
      Util.error(log, "Could not create zip file for r2 after java to xml.", e);
    }
//    finally
//    {
//      FileUtil.close(zipFileStream);
//    }
    return jtxResult;
  }


  private void writeExternalFile(R2ExhibitList r2ExhibitList, ZipOutputStream zipFileStream) throws IOException, SQLException
  {
    // loop through and include in the zip any files referenced by the xml
    if (r2ExhibitList != null && CollectionUtils.isNotEmpty(r2ExhibitList.getR2Exhibits()))
    {
      List<KeyValuePair> r4KvpList = jtxResult.getR4KvpList();
      if (r4KvpList == null)
      {
        r4KvpList = new ArrayList<KeyValuePair>();
        jtxResult.setR4KvpList(r4KvpList);
      }
      for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits())
      {
        ProgramElement pe = r2Exhibit.getProgramElement();
        if (pe != null && CollectionUtils.isNotEmpty(pe.getProjects()))
        {
          for (Project project : pe.getProjects())
          {
            R4Exhibit r4Exhibit = project.getR4Exhibit();
            if (r4Exhibit != null && CollectionUtils.isNotEmpty(r4Exhibit.getScheduleProfiles()))
            {
              int index = 1;
              for (ScheduleProfile sp : r4Exhibit.getScheduleProfiles())
              {
                String key = Util.underscoreConcat(pe.getBusinessId(), project.getBusinessId(), index++, "R4");

                if (sp.getTmpImagePath() != null)
                {
                  KeyValuePair kvp = new KeyValuePair(key, new File(sp.getTmpImagePath()).toURI().toURL().toString());
                  r4KvpList.add(kvp);
                  log.debug("Adding R4 KVP " + kvp);

                  if (!excludeExternalObjectsInZip && !checkDupZipEntry(sp.getImageFileName()))
                  {
                    ZipEntry zipEntry = new ZipEntry(sp.getImageFileName());
                    zipFileStream.putNextEntry(zipEntry);
                    FileUtil.writeFileContents(sp.getTmpImagePath(), zipFileStream, false);
                  }
                }
                else
                {
                  Blob blob = sp.getImageData();
                  if (blob != null)
                  {
                    File r4OutputFile = new File(workingFolder, FileUtil.createFileNameOfSameType(sp.getImageFileName(), key));
                    // save the key/value pair of the r4
                    KeyValuePair kvp = new KeyValuePair(key, r4OutputFile.toURI().toURL().toString());
                    r4KvpList.add(kvp);
                    log.debug("Adding R4 KVP from DB " + kvp);

                    // first write out the image file, then add it to the zip
                    // (if
                    // no dups)
                    ;
                    try (InputStream imageInputStream = blob.getBinaryStream())
                    {
                      FileUtil.writeFileContents(imageInputStream, r4OutputFile);
                      if (!excludeExternalObjectsInZip && !checkDupZipEntry(sp.getImageFileName()))
                      {
                        ZipEntry zipEntry = new ZipEntry(sp.getImageFileName());
                        zipFileStream.putNextEntry(zipEntry);
                        FileUtil.writeFileContents(r4OutputFile, zipFileStream, false);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }


  private void writeExternalFile(JBCover coverDoc, ZipOutputStream zipFileStream) throws IOException
  {
    if (coverDoc != null && StringUtils.isNotEmpty(coverDoc.getLogoFileName()) && !checkDupZipEntry(coverDoc.getLogoFileName()))
    {
      ZipEntry zipEntry = new ZipEntry(coverDoc.getLogoFileName());
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(coverDoc.getLogoAbsoluteFileName(), zipFileStream, false);
    }
  }


  private void writeExternalFile(JBDefaultUserSuppliedPart jbPart, ZipOutputStream zipFileStream) throws IOException
  {
    if (jbPart != null && StringUtils.isNotEmpty(jbPart.getFileName()) && !checkDupZipEntry(jbPart.getFileName()))
    {
      ZipEntry zipEntry = new ZipEntry(jbPart.getFileName());
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(jbPart.getAbsoluteFileName(), zipFileStream, false);
    }
  }


  private void writeExternalFile(List<? extends JBDefaultUserSuppliedPart> jbPartList, ZipOutputStream zipFileStream) throws IOException
  {
    if (jbPartList != null)
    {
      for (JBDefaultUserSuppliedPart jbPart : jbPartList)
        writeExternalFile(jbPart, zipFileStream);
    }
  }


  public JavaToXmlResult getJtxResult()
  {
    return jtxResult;
  }


  public void setJtxResult(JavaToXmlResult jtxResult)
  {
    this.jtxResult = jtxResult;
  }




  private JavaToXmlResult _toZip(LineItemList o, String baseFileName) throws FileNotFoundException, IOException
  {
    prep();

    File xmlFile = new File(workingFolder, FileUtil.createXmlFileName(baseFileName));
    jtxResult.setXmlFile(xmlFile);
    OutputStream os = new BufferedOutputStream(new FileOutputStream(xmlFile));
    toXml(o, os);

    ZipOutputStream zipFileStream = null;
    try
    {
      File zipFile = new File(workingFolder, FileUtil.createZzzFileName(baseFileName));
      jtxResult.setZipFile(zipFile);
      zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
      ZipEntry zipEntry = new ZipEntry(xmlFile.getName());
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(xmlFile, zipFileStream, false);
    }
    catch (IOException e)
    {
      log.error("Could not create zip file after java to xml.", e);
      throw e;
    }
    finally
    {
      FileUtil.close(zipFileStream);
    }
    return jtxResult;
  }


  public JavaToXmlResult toZip(LineItemList lil) throws FileNotFoundException, IOException
  {
    String baseFileName = "P40_";
    if (lil != null && lil.getLineItems().size() >= 1)
    {
      baseFileName = lil.getLineItems().get(0).getBusinessId();
      if(baseFileName == null)
        throw new FileNotFoundException("Unable to create filename: invalid or missing ID info in first line item");
    }
    else if (lil == null)
    {
      log.error("No Line Item found.");
      throw new FileNotFoundException("Cannot generate file.");
    }
//    else
//    {
//      log.error("Multiple line items found.");
//      throw new FileNotFoundException("Cannot generate file.");
//    }
    return _toZip(lil, baseFileName);
  }


  public JavaToXmlResult toZip(MultiYearProcurementList mypList) throws FileNotFoundException, IOException
  {
    String baseFileName = "P40_";
    if (mypList != null && mypList.getMultiYearProcurements().size() >= 1)
    {
      baseFileName = mypList.getMultiYearProcurements().get(0).getSystemName();
    }
    else if (mypList == null)
    {
      log.error("No MultiYearProcurement found.");
      throw new FileNotFoundException("Cannot generate file.");
    }
//    else
//    {
//      log.error("Multiple line items found.");
//      throw new FileNotFoundException("Cannot generate file.");
//    }
    prep();

    File xmlFile = new File(workingFolder, FileUtil.createXmlFileName(baseFileName));
    jtxResult.setXmlFile(xmlFile);
    OutputStream os = new BufferedOutputStream(new FileOutputStream(xmlFile));
    toXml(mypList, os);

    ZipOutputStream zipFileStream = null;
    try
    {
      File zipFile = new File(workingFolder, FileUtil.createZzzFileName(baseFileName));
      jtxResult.setZipFile(zipFile);
      zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
      ZipEntry zipEntry = new ZipEntry(xmlFile.getName());
      zipFileStream.putNextEntry(zipEntry);
      FileUtil.writeFileContents(xmlFile, zipFileStream, false);
    }
    catch (IOException e)
    {
      log.error("Could not create zip file after java to xml.", e);
      throw e;
    }
    finally
    {
      FileUtil.close(zipFileStream);
    }
    return jtxResult;
  }
}
