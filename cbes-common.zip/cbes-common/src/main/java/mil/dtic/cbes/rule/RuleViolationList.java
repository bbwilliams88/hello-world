/**
 * 
 */
package mil.dtic.cbes.rule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Container for a set of rule violations.
 * 
 * @author AZumkhaw
 *
 */
public class RuleViolationList {
  
  public static final String SYSTEM_ERROR_NUMBER = "SYSTEM#100";
  
  /**
   * Represents a system error.
   */
  private static class SystemErrorViolation extends RuleViolation {
    static Rule SYSTEM_ERROR = new Rule(SYSTEM_ERROR_NUMBER, "Could not run all business rules due to a system error: ''{0}''", "");   
    public SystemErrorViolation(ExhibitPath path, String ruleNumber) {
      super(SYSTEM_ERROR, path.toString(), ruleNumber);
    }
  }
  
  protected List<RuleViolation> violations = new ArrayList<RuleViolation>();
  private ExhibitPath violationPath;

  /**
   * Add a violation for the rule, formatting the rule's message
   * with the provided messageBinding objects.
   * 
   * Provide a ExhibitPath via setViolationPath() prior.
   * 
   * @param rule
   * @param messageBindings
   */
  public void add(Rule rule, Object... messageBindings) {
    RuleViolation v = new RuleViolation(rule, (violationPath == null) ? "" : violationPath.toString(), messageBindings);
    violations.add(v);    
    // Setup keys for violation to PE/LI mapping, when exhibit key is provided
    if (violationPath != null && violationPath.hasExhibitKey()) {

      // Setup keys for violation to PE/LI mapping
      v.setExhibitKey(violationPath.getExhibitKey());
    }
  }
  
  /**
   * Add a system error message.
   * 
   * @param path
   * @param ruleNumber
   */
  public void addSystemError(ExhibitPath path, String ruleNumber) {
    violations.add(new SystemErrorViolation(path, ruleNumber));
  }

  /**
   * Get a cached violation path to create rule
   * violations with.
   */
  public ExhibitPath getViolationPath() {
    return violationPath;
  }

  /**
   * Cache a violation path that to create rule violations with.
   * 
   */
  public void setViolationPath(ExhibitPath violationPath) {
    this.violationPath = violationPath;
  }

  /**
   * Returns number of violations.
   * 
   * @return
   */
  public int count() {
    return violations.size();
  }
  
  public boolean isEmpty() {
    return violations.isEmpty();
  }
  
  /**
   * Returns true if at least one rule violation present 
   * with the provided ruleNumber. 
   * 
   * @param ruleNumber
   * @return
   */
  public boolean contains(String ruleNumber) {
    boolean matches = false;
    Iterator<RuleViolation> i = violations.iterator();
    while (i.hasNext() && !matches) {
      RuleViolation v = i.next();
      matches = ruleNumber.equals(v.getRuleNumber());
    }
    return matches;
  }
  
  /**
   * Converts the violations to a list of strings,
   * for display to a user.
   * 
   * @return
   */
  public List<String> asList() {
    ArrayList<String> list = new ArrayList<String>(violations.size());
    for (RuleViolation violation : violations) {
      list.add(violation.toString());
    }
    return list;
  }
  
  /**
   * Converts the list to a parse friendly list of strings.
   * 
   * @return
   */
  public List<String> asParseFriendlyList() {
    ArrayList<String> list = new ArrayList<String>(violations.size());
    for (RuleViolation violation : violations) {
      list.add(violation.parseFriendly());
    }
    return list;
  }
  
  /**
   * Converts the list into a list of lines that can be included in a csv file.
   * 
   * @return
   */
  public List<String> asCsvLineList() {
    ArrayList<String> list = new ArrayList<String>(violations.size());
    for (RuleViolation violation : violations) {
      list.add(violation.csvLine());
    }
    return list;
  }
  
  /**
   * Concatenate this list with another.
   * 
   * @param otherViolations
   */
  public void concatenate(RuleViolationList otherViolations) {
    this.violations.addAll(otherViolations.violations);
  }
  
  /**
   * Generate a mapping
   * 
   * @return
   */
  public Map<String, List<String>> generateKeyToViolationMap() {
    Map<String, List<String>> mappings = new HashMap<String, List<String>>();
    for (RuleViolation violation : violations) {
      String exhibitKey = violation.getExhibitKey();
      List<String> mappedViolations = null;
      if (mappings.containsKey(exhibitKey)) {
        mappedViolations = mappings.get(exhibitKey);        
      }
      else {
        mappedViolations = new ArrayList<String>();
        mappings.put(exhibitKey, mappedViolations);
      }
      mappedViolations.add(violation.toString());
    }
    return mappings;
  }
}
