package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._Facility;

/**
 *
 */
public abstract class Facility extends _Facility implements ItemExhibitType
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public String getIdentifyingString()
    {
        return getName();
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public abstract void shiftForwardInTime(int years);
}
