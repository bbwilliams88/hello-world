package mil.dtic.cbes.jb;

import java.io.Serializable;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.utility.CbesLogFactory;


public class DocumentAssemblyOptions implements Cloneable, Serializable{ 
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(DocumentAssemblyOptions.class);
  
  private boolean forceEvenPages;
  private boolean p1mCheckbox;
  private String watermark;
  private String trackingHeader;
  
  private boolean positionAttachmentsAfterExhibits;
  private String volumeTitleAggregation;
  private String workFlowStatus;
  private String jobReference;
  private String analystReference;
  private String finalNotes;
  
  private boolean honorSubordinateDocumentAssemblyOptions; // change this to say override if it makes sense  
  private boolean suppressSubExhibits;
  private boolean includeTov;
  private boolean useLegacyMJBFormat;
  
  // RDT&E fields
  private boolean generateR1;
  private boolean generateR1Summary;
  private boolean generateR1c;
  private boolean generateR1d;
  private boolean generateProgramElementTocByTitle;
  private boolean generateProgramElementTocByBA;
  private boolean includeMasterR1;
  private boolean includeMasterR1Summary;
  private boolean includeMasterR1c;
  private boolean includeMasterR1d;
  private boolean includeMasterProgramElementTocByTitle;
  private boolean includeMasterProgramElementTocByBA;
  
  // Procurement fields
  private boolean generateP1;
  private boolean generateP1m;
  private boolean generateLineItemTocByTitle;
  private boolean generateLineItemTocByBA;
  private boolean includeMasterP1;
  private boolean includeMasterP1m;
  private boolean includeMasterLineItemTocByTitle;
  private boolean includeMasterLineItemTocByBA;
  
  public DocumentAssemblyOptions clone(){
    DocumentAssemblyOptions docAssemblyOptions = null;
    
    try{
        docAssemblyOptions = (DocumentAssemblyOptions) super.clone();
    }
    catch (CloneNotSupportedException e){
        log.error("Could not clone Document Assembly Options", e);
    }
    return docAssemblyOptions;
  }
  
  public void setAllDocumentAssemblyOptions(JBFormData formData){
      setForceEvenPages(formData.isForceEvenPages());
      setSuppressSubExhibits(formData.isSuppressSubExhibits());
      setP1mCheckbox(formData.isP1mCheckbox());
      setGenerateP1m(formData.isGenerateP1m());
      setIncludeMasterP1m(formData.isIncludeMasterP1m());
      setWatermark(formData.getWatermark());
      setTrackingHeader(formData.getTrackingHeader());
      setVolumeTitleAggregation(formData.getVolumeTitleAggregation());
      setWorkFlowStatus(formData.getWorkFlowStatus());
      setJobReference(formData.getJobReference());
      setAnalystReference(formData.getAnalystReference());
      setFinalNotes(formData.getFinalNotes());
      setPositionAttachmentsAfterExhibits(formData.isPositionAttachmentsAfterExhibits());
      setGenerateLineItemTocByBA(formData.isGenerateLineItemTocByBA());
      setGenerateLineItemTocByTitle(formData.isGenerateLineItemTocByTitle());
      setGenerateP1(formData.isGenerateP1());
      setGenerateProgramElementTocByBA(formData.isGenerateProgramElementTocByBA());
      setGenerateProgramElementTocByTitle(formData.isGenerateProgramElementTocByTitle());
      setGenerateR1(formData.isGenerateR1());
      setGenerateR1c(formData.isGenerateR1c());
      setGenerateR1d(formData.isGenerateR1d());
      setGenerateR1Summary(formData.isGenerateR1Summary());
      setIncludeTov(formData.isIncludeTov());
      setUseLegacyMJBFormat(formData.isUseLegacyMJBFormat());
      setIncludeMasterProgramElementTocByBA(formData.isIncludeMasterProgramElementTocByBA());
      setIncludeMasterProgramElementTocByTitle(formData.isIncludeMasterProgramElementTocByTitle());
      setIncludeMasterLineItemTocByBA(formData.isIncludeMasterLineItemTocByBA());
      setIncludeMasterLineItemTocByTitle(formData.isIncludeMasterLineItemTocByTitle());      
  }

  public boolean isForceEvenPages() {
    return forceEvenPages;
  }

  public void setForceEvenPages(boolean forceEvenPages) {
    this.forceEvenPages = forceEvenPages;
  }
  
  public boolean isP1mCheckbox(){
    return p1mCheckbox;
  }

  public void setP1mCheckbox(boolean p1mCheckbox) {
    this.p1mCheckbox = p1mCheckbox;
  }
  
  public String getWatermark() {
    return watermark;
  }

  public void setWatermark(String watermark) {
    this.watermark = watermark;
  }

  public String getTrackingHeader() {
    return trackingHeader;
  }


  public void setTrackingHeader(String trackingHeader) {
    this.trackingHeader = trackingHeader;
  }
  
  public void setWorkFlowStatus(String workFlowStatus){
	  this.workFlowStatus = workFlowStatus;
  }
  
  public String getWorkFlowStatus(){
	  return workFlowStatus;
  }
  public boolean isHonorSubordinateDocumentAssemblyOptions() {
    return honorSubordinateDocumentAssemblyOptions;
  }

  public void setHonorSubordinateDocumentAssemblyOptions(boolean honorSubordinateDocumentAssemblyOptions) {
    this.honorSubordinateDocumentAssemblyOptions = honorSubordinateDocumentAssemblyOptions;
  }
  
  public boolean isSuppressSubExhibits() {
    return suppressSubExhibits;
  }
  
  public void setSuppressSubExhibits(boolean suppressSubExhibits) {
    this.suppressSubExhibits = suppressSubExhibits;
  }
  
  public boolean isGenerateR1() {
    return generateR1;
  }

  public void setGenerateR1(boolean generateR1){
    this.generateR1 = generateR1;
  }

  public boolean isGenerateR1Summary(){
    return generateR1Summary;
  }

  public void setGenerateR1Summary(boolean generateR1Summary){
    this.generateR1Summary = generateR1Summary;
  }

  public boolean isGenerateR1c() {
    return generateR1c;
  }

  public void setGenerateR1c(boolean generateR1c) {
    this.generateR1c = generateR1c;
  }

  public boolean isGenerateR1d()  {
    return generateR1d;
  }

  public void setGenerateR1d(boolean generateR1d) {
    this.generateR1d = generateR1d;
  }

  public boolean isGenerateProgramElementTocByTitle() {
    return generateProgramElementTocByTitle;
  }

  public void setGenerateProgramElementTocByTitle(boolean generateProgramElementTocByTitle) {
    this.generateProgramElementTocByTitle = generateProgramElementTocByTitle;
  }

  public boolean isGenerateProgramElementTocByBA() {
    return generateProgramElementTocByBA;
  }

  public void setGenerateProgramElementTocByBA(boolean generateProgramElementTocByBA) {
    this.generateProgramElementTocByBA = generateProgramElementTocByBA;
  }

  public boolean isIncludeMasterR1() {
    return includeMasterR1;
  }

  public void setIncludeMasterR1(boolean includeMasterR1) {
    this.includeMasterR1 = includeMasterR1;
  }

  public boolean isIncludeMasterR1Summary() {
    return includeMasterR1Summary;
  }

  public void setIncludeMasterR1Summary(boolean includeMasterR1Summary) {
    this.includeMasterR1Summary = includeMasterR1Summary;
  }

  public boolean isIncludeMasterR1c() {
    return includeMasterR1c;
  }

  public void setIncludeMasterR1c(boolean includeMasterR1c) {
    this.includeMasterR1c = includeMasterR1c;
  }

  public boolean isIncludeMasterR1d() {
    return includeMasterR1d;
  }

  public void setIncludeMasterR1d(boolean includeMasterR1d){
    this.includeMasterR1d = includeMasterR1d;
  }

  public boolean isIncludeMasterProgramElementTocByTitle(){
    return includeMasterProgramElementTocByTitle;
  }

  public void setIncludeMasterProgramElementTocByTitle(boolean includeMasterProgramElementTocByTitle){
    this.includeMasterProgramElementTocByTitle = includeMasterProgramElementTocByTitle;
  }

  public boolean isIncludeMasterProgramElementTocByBA() {
    return includeMasterProgramElementTocByBA;
  }

  public void setIncludeMasterProgramElementTocByBA(boolean includeMasterProgramElementTocByBA){
    this.includeMasterProgramElementTocByBA = includeMasterProgramElementTocByBA;
  }

  public boolean isIncludeTov() {
    return includeTov;
  }

  public void setIncludeTov(boolean includeTov) {
    this.includeTov = includeTov;
  }

  public boolean isUseLegacyMJBFormat() {
    return useLegacyMJBFormat;
  }

  public void setUseLegacyMJBFormat(boolean useLegacyMJBFormat) {
    this.useLegacyMJBFormat = useLegacyMJBFormat;
  }

  public boolean isGenerateP1(){
    return generateP1;
  }

  public void setGenerateP1(boolean generateP1) {
    this.generateP1 = generateP1;
  }

  public boolean isGenerateP1m() {
    return generateP1m;
  }

  public void setGenerateP1m(boolean generateP1m) {
    this.generateP1m = generateP1m;
  }

  public boolean isGenerateLineItemTocByTitle() {
    return generateLineItemTocByTitle;
  }

  public void setGenerateLineItemTocByTitle(boolean generateLineItemTocByTitle) {
    this.generateLineItemTocByTitle = generateLineItemTocByTitle;
  }

  public boolean isGenerateLineItemTocByBA() {
    return generateLineItemTocByBA;
  }

  public void setGenerateLineItemTocByBA(boolean generateLineItemTocByBA) {
    this.generateLineItemTocByBA = generateLineItemTocByBA;
  }

  public boolean isIncludeMasterP1(){
    return includeMasterP1;
  }

  public void setIncludeMasterP1(boolean includeMasterP1) {
    this.includeMasterP1 = includeMasterP1;
  }

  public boolean isIncludeMasterP1m(){
    return includeMasterP1m;
  }

  public void setIncludeMasterP1m(boolean includeMasterP1m) {
    this.includeMasterP1m = includeMasterP1m;
  }

  public boolean isIncludeMasterLineItemTocByTitle() {
    return includeMasterLineItemTocByTitle;
  }

  public void setIncludeMasterLineItemTocByTitle(boolean includeMasterLineItemTocByTitle) {
    this.includeMasterLineItemTocByTitle = includeMasterLineItemTocByTitle;
  }

  public boolean isIncludeMasterLineItemTocByBA() {
    return includeMasterLineItemTocByBA;
  }

  public void setIncludeMasterLineItemTocByBA(boolean includeMasterLineItemTocByBA) {
    this.includeMasterLineItemTocByBA = includeMasterLineItemTocByBA;
  }

    public String getJobReference() {
        return jobReference;
    }
    
    public void setJobReference(String jobReference) {
        this.jobReference = jobReference;
    }
    
    public String getAnalystReference() {
        return analystReference;
    }
    
    public void setAnalystReference(String analystReference) {
        this.analystReference = analystReference;
    }
    
    public String getFinalNotes() {
        return finalNotes;
    }
    
    public void setFinalNotes(String finalNotes) {
        this.finalNotes = finalNotes;
    }
    
    public String getVolumeTitleAggregation() {
        return volumeTitleAggregation;
    }
    
    public void setVolumeTitleAggregation(String volumeTitleAggregation) {
        this.volumeTitleAggregation = volumeTitleAggregation;
    }
    
    public boolean isPositionAttachmentsAfterExhibits() {
        return positionAttachmentsAfterExhibits;
    }
    
    public void setPositionAttachmentsAfterExhibits(boolean positionAttachmentsAfterExhibits) {
        this.positionAttachmentsAfterExhibits = positionAttachmentsAfterExhibits;
    }

    @Override
    public String toString() {
        return "DocumentAssemblyOptions [forceEvenPages=" + forceEvenPages + ", p1mCheckbox=" + p1mCheckbox + ", watermark=" + watermark
                + ", trackingHeader=" + trackingHeader + ", positionAttachmentsAfterExhibits=" + positionAttachmentsAfterExhibits
                + ", volumeTitleAggregation=" + volumeTitleAggregation + ", workFlowStatus=" + workFlowStatus + ", jobReference=" + jobReference
                + ", analystReference=" + analystReference + ", finalNotes=" + finalNotes + ", honorSubordinateDocumentAssemblyOptions="
                + honorSubordinateDocumentAssemblyOptions + ", suppressSubExhibits=" + suppressSubExhibits + ", includeTov=" + includeTov
                + ", useLegacyMJBFormat=" + useLegacyMJBFormat + ", generateR1=" + generateR1 + ", generateR1Summary=" + generateR1Summary
                + ", generateR1c=" + generateR1c + ", generateR1d=" + generateR1d + ", generateProgramElementTocByTitle="
                + generateProgramElementTocByTitle + ", generateProgramElementTocByBA=" + generateProgramElementTocByBA + ", includeMasterR1="
                + includeMasterR1 + ", includeMasterR1Summary=" + includeMasterR1Summary + ", includeMasterR1c=" + includeMasterR1c
                + ", includeMasterR1d=" + includeMasterR1d + ", includeMasterProgramElementTocByTitle=" + includeMasterProgramElementTocByTitle
                + ", includeMasterProgramElementTocByBA=" + includeMasterProgramElementTocByBA + ", generateP1=" + generateP1 + ", generateP1m="
                + generateP1m + ", generateLineItemTocByTitle=" + generateLineItemTocByTitle + ", generateLineItemTocByBA=" + generateLineItemTocByBA
                + ", includeMasterP1=" + includeMasterP1 + ", includeMasterP1m=" + includeMasterP1m + ", includeMasterLineItemTocByTitle="
                + includeMasterLineItemTocByTitle + ", includeMasterLineItemTocByBA=" + includeMasterLineItemTocByBA + "]";
    }
    
    
 }
