package mil.dtic.cbes.p40.vo;




public interface FacilityProjectExtended extends FacilityProject, CostContainer
{
  public abstract Costs getCosts();
  public abstract void setDescription(String description);
  public abstract String getDescription();
}