package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum ResourceSummaryPlusOrLessType implements ExtendedEnumeration 
{
  PLUS("plus", "Plus", "Funding added to the Net P-1 Procurement Cost to give you the Total Obligation Authority. However, this funding is NOT included for the Full Funding Total Obligation Authority."), 
  LESS("less", "Less", "Funding subtracted from the Gross Weapon/System Cost to give you the Net P-1 Procurement Cost."), 
  PLUSFF("plusff", "PlusFF", "Funding added to the Net P-1 Procurement Cost that gets incorporated into the Full Funding Total Obligation Authority which is then rolled into the Total Obligation Authority.");

  private final String databaseValue;
  private final String xmlValue;
  private final String description;

  private ResourceSummaryPlusOrLessType(String databaseValue, String xmlValue, String description)
  {
      this.databaseValue = databaseValue;
      this.xmlValue = xmlValue;
      this.description = description;
  }

  @Override
  public String getDatabaseValue()
  {
      return databaseValue;
  }
  
  public String getXmlValue()
  {
      return xmlValue;
  }
  
  public String getDescription()
  {
	  return description;
  }
}
