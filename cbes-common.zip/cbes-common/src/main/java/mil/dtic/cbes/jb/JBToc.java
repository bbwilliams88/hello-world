/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;


public class JBToc extends BaseToc{
    private static final Logger log = CbesLogFactory.getLog(JBToc.class);
    private JustificationBook jb;

    public JBToc() {
        this(null);
    }
  
    public JBToc(JustificationBook jb){
        super(jb, FileSetting.TOC);
        this.jb = jb;
    }

  public void prepareTocContents(){
      log.debug("Preparing JB TOC items...");
      super.prepareTocContents();
      addTocItem(tocItemList, jb.getR2ExhibitList());
      addTocItem(tocItemList, jb.getLineItemList());
      addTocItem(tocItemList, jb.getMultiYearProcurementList());
    
      //CXE-4197
      if (isAppendTocToEnd()){
          log.trace("prepareTocContents(): appending supplemental docs to end of JBook");
          addTocItem(tocItemList, jbb.getSupplementalDocCollection().getSupplementalDocList());
      }
  }

}
