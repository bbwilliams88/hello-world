package mil.dtic.cbes.rule;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Associates a class with a rule group.
 * 
 * Example:
 * 
 * @RuleGroupName("R3")
 * class R3ExhibitValidator implements RuleGroup
 * 
 * @author AZumkhaw
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface RuleGroupName {
  String value();
}
