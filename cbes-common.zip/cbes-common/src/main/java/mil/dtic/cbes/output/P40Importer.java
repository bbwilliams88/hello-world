package mil.dtic.cbes.output;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.InitialSourceType;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.Role;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.validation.backend.SubmissionDateValidator;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.submissiondate.SubmissionDateProcessorFactory;
import mil.dtic.utility.submissiondate.exception.SubmissionDateProcessorException;

public class P40Importer
{
  private static final Logger log = CbesLogFactory.getLog(P40Importer.class);

  protected UserCredentials userCredentials;
  protected ImportOptions importOptions;
  protected P40User p40User;


  public P40Importer(UserCredentials userCredentials, ImportOptions importOptions)
  {
    this.userCredentials = userCredentials;
    this.importOptions = importOptions;
  }

  public P40Importer(P40User p40User, ImportOptions importOptions)
  {
    this.p40User = p40User;
    this.importOptions = importOptions;
  }


  public boolean prepareForImport(P40ImportItem importItem)
  {
    LineItem li = importItem.getLineItem();

    li.setErrorCount((short)importItem.getErrorList().size());
    li.setWarningCount((short)importItem.getWarningList().size());
    li.setInitialSource(InitialSourceType.IMPORTED);

    // Check to see whether the LineItem already exists in the database
    String dbgmsg = "" + li.getBudgetCycle() + li.getBudgetYear() + li.getLineItemNumber();
    try {
      if (LineItem.alreadyExists(li.getBudgetCycle(), li.getBudgetYear(), li.getLineItemNumber(),
          li.getServiceAgency(), li.getBudgetSubActivity(), li.getTest()))
      {
        log.trace("Line Item already exists in the database " + dbgmsg);
        logLiError(li, importItem, "Already exists in the database");
        return fail(importItem);
      }
    } catch (RuntimeException e) {
      log.error("Duplicate check failed", e);
      return fail(importItem);
    }
    // Create privilege?
    if ( (userCredentials!=null && !userCredentials.createLiAllowed()) ||
      (p40User!=null && StringUtils.equals("N", p40User.getCreateLiPriv())))
    {
      logLiError(li, importItem, "could not be created because you do not have create permission");
      return fail(importItem);
    }

    // can't create LIs in another agency
    String p40AgencyCode = li.getServiceAgency().getCode();
    ServiceAgency r2Agency = BudgesContext.getServiceAgencyDAO().findByCode(p40AgencyCode);

    // no agency listed in imported file
    if (r2Agency==null)
    {
      log.trace("P40 Import Agency: NULL Code:" + p40AgencyCode);
      logLiError(li, importItem, "is not under your agency");
      return fail(importItem);
    }
    //  If user is not an app mgr, check if user is in same agency as agency in imported file
    else if ((userCredentials!=null && userCredentials.getUserInfo()!=null && !userCredentials.getUserInfo().checkPrivilege(Privilege.ADMIN_ALL_AGENCIES) && !userCredentials.getUserInfo().getAvailableProcurementAgencies().contains(r2Agency)) ||
      p40User!=null && !p40User.hasRole(Role.APPMGR) && !p40User.hasAgency(p40AgencyCode)){
      log.trace("P40 Import Agency: " + r2Agency + " Code:" + p40AgencyCode);
      logLiError(li, importItem, "is not under your agency");
      return fail(importItem);
    }

    // Check submission date
    BudgetCycle bc = BudgesContext.getBudgetCycleDAO().findByCycleAndBudgetYear(li.getBudgetCycle(), li.getBudgetYear());
    
    SubmissionDate sd = new SubmissionDate();
    
    try {
        li.setSubmissionDate(SubmissionDateProcessorFactory.getSubmissionDateProcessor().getDate(li.getBudgetCycle(), li.getBudgetYear()));
    }
    catch(SubmissionDateProcessorException sdpe){
        log.error(String.format("failure processing cycle: %s and year: %s ", li.getBudgetCycle(), li.getBudgetYear()));
    }
    
    sd.setValue(new SimpleDateFormat(Constants.SUBMISSION_DATE_FORMAT).format(li.getSubmissionDate()));

    if (bc == null || ! (new SubmissionDateValidator(sd, bc).isValidSubmissionDate()))
    {
    	log.trace("Invalid Submission Date: " + sd.getValue() + " for cycle" + li.getBudgetCycleAndYear());
        logLiError(li, importItem, "has invalid submission date of " + sd.getValue());
        return fail(importItem);
    }

    // If document assembly options are not set, then set them to these default values
    if (importItem.getLineItem().getP40aItemScheduleFlag() == null || importItem.getLineItem().getP40aItemScheduleFlag().isEmpty()) {
    	importItem.getLineItem().setGenerateItemSchedule(true);
    	importItem.getLineItem().setP40aItemScheduleFlag("expandItemSuppressExhibit");
    	importItem.getLineItem().setExpandP40AInItemSchedule(true);
    	importItem.getLineItem().setSuppressP40As(true);
    }

 // set user defined tags
    if (StringUtils.isNotEmpty(importOptions.getUserDefinedTag()))
    {
      li.setTag(importOptions.getUserDefinedTag());
    }
    // set test exhibit
    li.setTest(importOptions.isTestExhibit());

    li.setDateCreated(new Date());
    li.setDateModified(new Date());
    P40User localUser = null;
    if (p40User!=null)
    {
        localUser = CayenneUtils.copyToContext(p40User, li.getObjectContext());
//        localUser = (P40User)li.getObjectContext().localObject(p40User.getObjectId(), null);
    }
    else if (userCredentials!=null)
    {
      String userLdapId = userCredentials.getUserInfo().getLdapUser().getLdapUserId();
      localUser = P40User.fetchWithLdapId(li.getObjectContext(), userLdapId);
    }
    li.setCreatedBy(localUser);
    li.setModifiedBy(localUser);

    return true;
  }


  private boolean fail(P40ImportItem item)
  {
    item.setImportable(false);
    return false;
  }


  private void logLiError(LineItem li, P40ImportItem importItem, String partialMessage)
  {
    logError("LineItemNumber", importItem, "Line Item with LineItemNumber='" + li.getLineItemNumber() + "' and BudgetCycle='" + li.getBudgetCycle() + "' and BudgetYear='" + li.getBudgetYear() + "' and Agency='"
      + li.getServiceAgency().getName() + "' " + partialMessage + ".");
  }


  public void logError(String elementName, P40ImportItem importItem, String message)
  {
    P40ImportMessage errorMessage = new P40ImportMessage(importItem.getLineItem().getLineItemNumber(), importItem.getXmlIndex(), message);
    importItem.getErrorList().add(errorMessage.toString());
  }
}
