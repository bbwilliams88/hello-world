package mil.dtic.cbes.p40.vo;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.Cayenne;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;

import com.google.common.collect.Lists;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._LineItemView;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.utility.Util;

public class LineItemView extends _LineItemView implements HasValidity
{
  private static final long serialVersionUID = 1L;

  public static List<LineItemView> fetchAll(ObjectContext context)
  {
    return fetchAllForClass(context, LineItemView.class);
  }

  public static List<LineItemView> fetchByAgencies(
    ObjectContext context, List<ServiceAgency> agencies, BudgetCycle cycle, boolean includeTest, boolean includeDeleted)
  {
      return fetchByAgencies(context, agencies, cycle, includeTest, includeDeleted, true);
  }
  
  public static List<LineItemView> fetchByAgencies(
    ObjectContext context, List<ServiceAgency> agencies, BudgetCycle cycle, boolean includeTest, boolean includeDeleted, boolean asc, String...sortBy)
  {
    Set<String> codes = new HashSet<String>();
    Ordering[] orderings = new Ordering[sortBy.length];
    
    for(int i = 0; i < sortBy.length; i++) {
      orderings[i] = new Ordering(sortBy[i], asc ? SortOrder.ASCENDING : SortOrder.DESCENDING);
    }
    
    for (ServiceAgency sa : agencies)
      codes.add(sa.getCode());
      if (codes.isEmpty())
        return Collections.emptyList();
      return fetch(context, LineItemView.class, Expression.IN, orderings,
        LineItemView.AGENCY_CODE_PROPERTY, LineItemView.TEST_PROPERTY, LineItemView.STATUS_PROPERTY,
        LineItemView.BUDGET_CYCLE_PROPERTY, LineItemView.BUDGET_YEAR_PROPERTY,
        codes,
        (includeTest ? new Boolean[] {true, false} : new Boolean[] { false }),
        (includeDeleted ? Lists.newArrayList(StatusType.ACTIVE, StatusType.DELETED) : Lists.newArrayList(StatusType.ACTIVE)),
        new String[]{cycle.getCycle()}, new Integer[] {cycle.getBudgetYear()}
        );
  }

  public static List<LineItemView> fetchByAgenciesForAllCycles(
		    ObjectContext context, List<ServiceAgency> agencies, boolean includeTest, boolean includeDeleted)
  {
  	Set<String> codes = new HashSet<String>();
  	for (ServiceAgency sa : agencies)
  		 codes.add(sa.getCode());
  	if (codes.isEmpty())
  		 return Collections.emptyList();
  	return fetch(context, LineItemView.class, Expression.IN, null,
  		        LineItemView.AGENCY_CODE_PROPERTY, LineItemView.TEST_PROPERTY, LineItemView.STATUS_PROPERTY,
  		        codes,
  		        (includeTest ? new Boolean[] {true, false} : new Boolean[] { false }),
  		        (includeDeleted ? Lists.newArrayList(StatusType.ACTIVE, StatusType.DELETED) : Lists.newArrayList(StatusType.ACTIVE))
  	);
  }
  
  public static List<LineItemView> fetchByAgenciesForAllCycles(
    ObjectContext context, List<ServiceAgency> agencies, boolean includeTest, boolean includeDeleted, boolean asc, String...sortBy)
  {
    Set<String> codes = new HashSet<String>();
    Ordering[] orderings = new Ordering[sortBy.length];
    
    for(int i = 0; i < sortBy.length; i++) {
      orderings[i] = new Ordering(sortBy[i], asc ? SortOrder.ASCENDING : SortOrder.DESCENDING);
    }

    for (ServiceAgency sa : agencies)
     codes.add(sa.getCode());
    if (codes.isEmpty()) 
      return Collections.emptyList();
    return fetch(context, LineItemView.class, Expression.IN, orderings,
              LineItemView.AGENCY_CODE_PROPERTY, LineItemView.TEST_PROPERTY, LineItemView.STATUS_PROPERTY,
              codes,
              (includeTest ? new Boolean[] {true, false} : new Boolean[] { false }),
              (includeDeleted ? Lists.newArrayList(StatusType.ACTIVE, StatusType.DELETED) : Lists.newArrayList(StatusType.ACTIVE))
    );
  }


  public static List<LineItemView> fetchWithIds(ObjectContext context, Collection<Integer> ids)
  {
    return fetchWithIds(context, LineItemView.class, LI_ID_PK_COLUMN, ids.toArray(new Object[0]));
  }

  public String getBudgetCycleAndYear()
  {
    return getBudgetCycle() + " " + getBudgetYear();
  }

  public String getCreatorDisplayName()
  {
    return Util.formatName(this.getCreatedByLastName(), this.getCreatedByFirstName(), this.getCreatedByMiddleInitial(), this.getCreatedByUserLdapId());
  }

  public String getModifierDisplayName()
  {
    return Util.formatName(this.getModifiedByLastName(), this.getModifiedByFirstName(), this.getModifiedByMiddleInitial(), this.getModifiedByUserLdapId());
  }

  public String getIdentifyingString()
  {
    String p1 = getP1LineItemNumber() == null ? "" : getP1LineItemNumber()+"";
    return p1 + " " + getLineItemNumber() + " " + getBudgetCycle() + getBudgetYear();
  }

  @Override
  public boolean isValid()
  {
    return getErrorCount() != null && getErrorCount() == 0 && getWarningCount() != null && getWarningCount() == 0;
  }

  @Override
  public boolean isErrors()
  {
    return getErrorCount() != null && getErrorCount() > 0;
  }

  @Override
  public boolean isWarnings()
  {
    return getWarningCount() != null && getWarningCount() > 0;
  }

  public boolean hasEditLock()
  {
    return getP40Locked() || getSubExhibitLocks() > 0;
  }

  public boolean isFrozen()
  {
    return getAllExhibitsLocked();
  }
  
  // Select using DataObjectUtils. In contrast, following the relationship 
  // via _LineItemView::getLineItem() generates a slow cayenne query that 
  // joins the view on the line item table.
  static private LineItem getLineItemFromLineItemView(LineItemView lineItemView)
  {    
    LineItem lineItem = Cayenne.objectForPK(lineItemView.getObjectContext(), LineItem.class, Cayenne.intPKForObject(lineItemView));   
    return lineItem;
  }
  
  @Override
  public LineItem getLineItem()
  {
    return getLineItemFromLineItemView(this);
  }
}
