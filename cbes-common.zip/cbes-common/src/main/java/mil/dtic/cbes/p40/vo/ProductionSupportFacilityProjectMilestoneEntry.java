package mil.dtic.cbes.p40.vo;

import java.util.List;

import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectMilestoneEntry;
import mil.dtic.cbes.p40.vo.wrappers.CayenneListWrapper;

/**
 *
 */
public class ProductionSupportFacilityProjectMilestoneEntry extends _ProductionSupportFacilityProjectMilestoneEntry
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectMilestoneEntry#getMilestoneList()
     */
    @Override
    public List<ProductionSupportFacilityProjectMilestone> getMilestoneList()
    {
        return new CayenneListWrapper<ProductionSupportFacilityProjectMilestone>(this, super.getMilestoneList(), MILESTONE_LIST_RELATIONSHIP_PROPERTY, true);
    }
}
