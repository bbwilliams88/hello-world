package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.lang.StringUtils;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.enums.ManufacturerRateUnitType;
import mil.dtic.cbes.enums.MonetaryUnitType;
import mil.dtic.cbes.enums.QuantityUnitNameType;
import mil.dtic.cbes.enums.QuantityUnitType;
import mil.dtic.cbes.jb.JBDefaultSystemGeneratedPart;
import mil.dtic.cbes.p40.vo.jibx.LineItemPostprocessData;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.Util;



/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
/**
 * @author EDaniels
 *
 */
/**
 * @author EDaniels
 *
 */
public class MultiYearProcurement extends JBDefaultSystemGeneratedPart
{

  /**
   * 
   */
  private static final long serialVersionUID = 9087323677617060883L;
  private QuantityUnitNameType quantityUnitName;
  private QuantityUnitType quantityUnits;
  private MonetaryUnitType totalCostUnits;
  private MonetaryUnitType unitCostUnits;
  private ManufacturerRateUnitType manufacturerRateUnits;
  private Integer budgetYear;
  private LineItemPostprocessData lineItemPostprocessData;
  private Date submissionDate;
  private String systemName;
  private List<MYPAgencyFundingDetails> MYPAgencyFundingDetailsList = new ArrayList<MYPAgencyFundingDetails>();
  private MultiYearProcurementCriteria multiYearProcurementCriteria;
  private MultiYearProcurementFundingPlanType totalProgramFundingPlan;
  private MultiYearProcurementFundingPlanType contractFundingPlan;
  private MultiYearProcurementValueAnalysis presentValueAnalysis;
  private List<MYPLineItemDetails> MYPLineItemDetailsList = new ArrayList<MYPLineItemDetails>();

  
  public MultiYearProcurement()
  {
    setFileSetting(FileSetting.MYP);
    setTitle(fileSetting.getTitle());
  }
  
  
  @Override
  public String getPdfBookmarkLabel()
  {
    return "MYP " + lineItemPostprocessData.getAppropriationNumber() + " " + systemName;
  }

  
  @Override
  public String getPdfOutputFileName()
  {
    return FileUtil.createPdfFileName(getFileSetting().getFileNamePrefix(), getBusinessId());
  }
  
  
  @Override
  public String getBusinessId()
  {
    return Util.underscoreConcat("MYP", lineItemPostprocessData.getServiceAgencyName(), "APP-" + lineItemPostprocessData.getAppropriationNumber(), "BA-" + lineItemPostprocessData.getBudgetActivityNumber(), getBudgetYear());
  }
  
  
  /**
   * @return the budgetYear
   */
  public Integer getBudgetYear()
  {
    return budgetYear;
  }


  /**
   * @param budgetYear
   *          the budgetYear to set
   */
  public void setBudgetYear(Integer budgetYear)
  {
    this.budgetYear = budgetYear;
  }


  /**
   * @return the lineItemPostprocessData
   */
  public LineItemPostprocessData getLineItemPostprocessData()
  {
    return lineItemPostprocessData;
  }


  /**
   * @param lineItemPostprocessData
   *          the lineItemPostprocessData to set
   */
  public void setLineItemPostprocessData(LineItemPostprocessData lineItemPostprocessData)
  {
    this.lineItemPostprocessData = lineItemPostprocessData;
  }


  /**
   * @return the submissionDate
   */
  public Date getSubmissionDate()
  {
    return submissionDate;
  }


  /**
   * @param submissionDate
   *          the submissionDate to set
   */
  public void setSubmissionDate(Date submissionDate)
  {
    this.submissionDate = submissionDate;
  }


  /**
   * @return the systemName
   */
  public String getSystemName()
  {
    return systemName;
  }


  /**
   * @param systemName
   *          the systemName to set
   */
  public void setSystemName(String systemName)
  {
    this.systemName = systemName;
  }


  /**
   * @return the mYPAgencyFundingDetailsList
   */
  public List<MYPAgencyFundingDetails> getMYPAgencyFundingDetailsList()
  {
    return MYPAgencyFundingDetailsList;
  }


  /**
   * @param mYPAgencyFundingDetailsList
   *          the mYPAgencyFundingDetailsList to set
   */
  public void setMYPAgencyFundingDetailsList(List<MYPAgencyFundingDetails> MYPAgencyFundingDetailsList)
  {
    this.MYPAgencyFundingDetailsList = MYPAgencyFundingDetailsList;
  }
  
  
  public void addToMYPAgencyFundingDetailsList(MYPAgencyFundingDetails mypAgencyFundingDetails)
  {
    getMYPAgencyFundingDetailsList().add(mypAgencyFundingDetails);
  }
  
  
  @SuppressWarnings("unchecked")
  public Iterator<MYPAgencyFundingDetails> jibx_MYPAgencyFundingDetailsListIterator()
  {
    return IteratorUtils.unmodifiableIterator(getMYPAgencyFundingDetailsList().iterator());
  }


  /**
   * @return the multiYearProcurementCriteria
   */
  public MultiYearProcurementCriteria getMultiYearProcurementCriteria()
  {
    return multiYearProcurementCriteria;
  }


  /**
   * @param multiYearProcurementCriteria
   *          the multiYearProcurementCriteria to set
   */
  public void setMultiYearProcurementCriteria(MultiYearProcurementCriteria multiYearProcurementCriteria)
  {
    this.multiYearProcurementCriteria = multiYearProcurementCriteria;
  }


  /**
   * @return the totalProgramFundingPlan
   */
  public MultiYearProcurementFundingPlanType getTotalProgramFundingPlan()
  {
    return totalProgramFundingPlan;
  }


  /**
   * @param totalProgramFundingPlan
   *          the totalProgramFundingPlan to set
   */
  public void setTotalProgramFundingPlan(MultiYearProcurementFundingPlanType totalProgramFundingPlan)
  {
    this.totalProgramFundingPlan = totalProgramFundingPlan;
  }


  /**
   * @return the contractFundingPlan
   */
  public MultiYearProcurementFundingPlanType getContractFundingPlan()
  {
    return contractFundingPlan;
  }


  /**
   * @param contractFundingPlan
   *          the contractFundingPlan to set
   */
  public void setContractFundingPlan(MultiYearProcurementFundingPlanType contractFundingPlan)
  {
    this.contractFundingPlan = contractFundingPlan;
  }


  /**
   * @return the presentValueAnalysis
   */
  public MultiYearProcurementValueAnalysis getPresentValueAnalysis()
  {
    return presentValueAnalysis;
  }


  /**
   * @param presentValueAnalysis
   *          the presentValueAnalysis to set
   */
  public void setPresentValueAnalysis(MultiYearProcurementValueAnalysis presentValueAnalysis)
  {
    this.presentValueAnalysis = presentValueAnalysis;
  }


  /**
   * @return the mYPLineItemDetailsList
   */
  public List<MYPLineItemDetails> getMYPLineItemDetailsList()
  {
    return MYPLineItemDetailsList;
  }


  /**
   * @param mYPLineItemDetailsList
   *          the mYPLineItemDetailsList to set
   */
  public void setMYPLineItemDetailsList(List<MYPLineItemDetails> MYPLineItemDetailsList)
  {
    this.MYPLineItemDetailsList = MYPLineItemDetailsList;
  }
  
  
  public void addToMYPLineItemDetailsList(MYPLineItemDetails mypLineItemDetails)
  {
    getMYPLineItemDetailsList().add(mypLineItemDetails);
  }
  
  
  @SuppressWarnings("unchecked")
  public Iterator<MYPLineItemDetails> jibx_MYPLineItemDetailsListIterator()
  {
    return IteratorUtils.unmodifiableIterator(getMYPLineItemDetailsList().iterator());
  }
  
  
  public boolean jibx_hasMYPLineItemDetails()
  {
    return CollectionUtils.isNotEmpty(getMYPAgencyFundingDetailsList());
  }
  
  
  public void jibx_setManufacturerRateUnits(String value)
  {
    setManufacturerRateUnits(ManufacturerRateUnitType.fromEnumValue(value));
  }


  public String jibx_getManufacturerRateUnits()
  {
    if (getManufacturerRateUnits() != null)
      return getManufacturerRateUnits().getLabel();
    else
      return null;
  }


  /**
   * @return the quantityUnitName
   */
  public QuantityUnitNameType getQuantityUnitName()
  {
    return quantityUnitName;
  }


  /**
   * @param quantityUnitName the quantityUnitName to set
   */
  public void setQuantityUnitName(QuantityUnitNameType quantityUnitName)
  {
    this.quantityUnitName = quantityUnitName;
  }


  /**
   * @return the quantityUnits
   */
  public QuantityUnitType getQuantityUnits()
  {
    return quantityUnits;
  }


  /**
   * @param quantityUnits the quantityUnits to set
   */
  public void setQuantityUnits(QuantityUnitType quantityUnits)
  {
    this.quantityUnits = quantityUnits;
  }


  /**
   * @return the totalCostUnits
   */
  public MonetaryUnitType getTotalCostUnits()
  {
    return totalCostUnits;
  }


  /**
   * @param totalCostUnits the totalCostUnits to set
   */
  public void setTotalCostUnits(MonetaryUnitType totalCostUnits)
  {
    this.totalCostUnits = totalCostUnits;
  }


  /**
   * @return the unitCostUnits
   */
  public MonetaryUnitType getUnitCostUnits()
  {
    return unitCostUnits;
  }


  /**
   * @param unitCostUnits the unitCostUnits to set
   */
  public void setUnitCostUnits(MonetaryUnitType unitCostUnits)
  {
    this.unitCostUnits = unitCostUnits;
  }


  /**
   * @return the manufacturerRateUnits
   */
  public ManufacturerRateUnitType getManufacturerRateUnits()
  {
    return manufacturerRateUnits;
  }


  /**
   * @param manufacturerRateUnits the manufacturerRateUnits to set
   */
  public void setManufacturerRateUnits(ManufacturerRateUnitType manufacturerRateUnits)
  {
    this.manufacturerRateUnits = manufacturerRateUnits;
  }


  /**
   * Check to see if this MYP exhibit includes a particular Line Item.  Will match off of the Line Item number and the Appropriation Code.
   * @param lineItem the Line Item to check.
   * @return true if the Line Item is found in this MYP, false otherwise.
   */
  public boolean hasLineItem(LineItem lineItem)
  {
    for (MYPAgencyFundingDetails mypAgencyFundingDetails : getMYPAgencyFundingDetailsList())
    {
      for (MYPLineItemDetails mypLineItemDetails : mypAgencyFundingDetails.getMYPLineItemDetailsList())
      {
        if (StringUtils.equals(mypLineItemDetails.getLineItemNumber(), lineItem.getLineItemNumber()) && 
          lineItem.getBudgetSubActivity() != null && lineItem.getBudgetSubActivity().getBudgetActivity() != null && lineItem.getBudgetSubActivity().getBudgetActivity().getAppropriation() != null &&
          StringUtils.equals(mypAgencyFundingDetails.getAppropriationNumber(), lineItem.getBudgetSubActivity().getBudgetActivity().getAppropriation().getCode()))
          return true;
      }
    }
    return false;
  }
}
