
package mil.dtic.cbes.rule;

import java.text.MessageFormat;

/**
 * Represents a rule violation. 
 * Prepares a formatted rule message for presentation.
 * 
 * @author AZumkhaw
 *
 */
public class RuleViolation {
  private String message;
  private String location;
  private Rule rule;
  private String exhibitKey;
  
  public RuleViolation(Rule ruleInfo, String location, Object... messageVariableBinding) {
    this.location = location;
    this.message = MessageFormat.format(ruleInfo.getRuleMessage(), messageVariableBinding);
    this.rule = ruleInfo;
  }
  
  protected RuleViolation(String messageLocation, String formattedMessage) {
    location = messageLocation;
    message = formattedMessage;
  }
  
  @Override
  public String toString() {
    String s = "[" + rule.getRuleNumber() + "] " + location + " " + message;
    return s;
  }
  
  // For import into excel
  public String parseFriendly() {
    String s = "[" + rule.getRuleNumber() + "]|" + location + "|" + message;
    return s;
  }
  
  // For inclusion in a csv file
  public String csvLine() {
    String s = rule.getRuleNumber() + "," + location + ",\"" + message + "\"\r\n";
    return s;
  }
  
  public String getRuleNumber() {
    return rule.getRuleNumber();
  }
  
  public String getExhibitKey() {
    return exhibitKey;
  }
  
  public boolean hasExhibitKey() {
    return exhibitKey != null;
  }
  
  public void setExhibitKey(String key) {
    exhibitKey = key;
  }
}