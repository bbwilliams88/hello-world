package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ShipFiscalYearFundingType implements ExtendedEnumeration
{
    ADVANCE_PROCUREMENT("PYAdvanceProcurement", "ADVANCE_PROCUREMENT", "Less Prior Year Advance Procurement Funding"), 
    SUBSEQUENT_YEAR_FULL_FUNDING("SubsequentYearFullFunding", "SUBSEQUENT_YEAR_FULL_FUNDING", "Less Subsequent Year Full Funding"),
    COST_TO_COMPLETE("CostToCompleteFunding", "COST_TO_COMPLETE", "Less Cost To Complete Funding"),
    CUSTOM("OtherFunding", "CUSTOM", "Custom Less Funding Rows");

    private final String xmlName;
    private final String dbName;
    private final String description;

    private ShipFiscalYearFundingType(String xmlName, String dbName, String description)
    {
        this.xmlName = xmlName;
        this.description = description;
        this.dbName = dbName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    @Override
    public String toString()
    {
        return xmlName;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }

    public static ShipFiscalYearFundingType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ShipFiscalYearFundingType.class, databaseValue);
    }

    public static ShipFiscalYearFundingType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ShipFiscalYearFundingType.class, enumValue);
    }
}
