package mil.dtic.cbes.p40.vo;

/**
 *
 */
public interface CostList
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    Cost getPriorYears();
    void setPriorYears(Cost priorYears);

    Cost getBy1();
    void setBy1(Cost by1);

    Cost getBy1Base();
    void setBy1Base(Cost by1Base);

    Cost getBy1Ooc();
    void setBy1Ooc(Cost by1Ooc);

    boolean isContinuing();
    void setContinuing(boolean continuing);

    Cost getCurrentYear();
    void setCurrentYear(Cost currentYear);

    Cost getPriorYear();
    void setPriorYear(Cost priorYear);

    Cost getToComplete();
    void setToComplete(Cost c);

    Cost getTotal();
    void setTotal(Cost c);
}
