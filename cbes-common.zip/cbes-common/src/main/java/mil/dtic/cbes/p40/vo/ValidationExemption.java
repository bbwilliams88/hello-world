package mil.dtic.cbes.p40.vo;

import java.util.Date;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.cayenne.PersistenceState;

import mil.dtic.cbes.p40.vo.auto._ValidationExemption;

/**
 *
 */
public class ValidationExemption extends _ValidationExemption
{
    private static final long serialVersionUID = 1L;

    public enum StatusType implements ExtendedEnumeration
    {
        ACTIVE("A"), INACTIVE("I");

        private final String databaseValue;

        private StatusType(String databaseValue)
        {
            this.databaseValue = databaseValue;
        }

        @Override
        public Object getDatabaseValue()
        {
            return databaseValue;
        }
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public boolean isExempt()
    {
        return getStatus() == StatusType.ACTIVE;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public void activate(P40User user)
    {
        updateAuditTrail(user, StatusType.ACTIVE);
    }

    public void deactivate(P40User user)
    {
        updateAuditTrail(user, StatusType.INACTIVE);
    }

    private void updateAuditTrail(P40User user, StatusType status)
    {
        setStatus(status);
        setDateModified(new Date());
        setUserModified(user.getFullName());

        if (getPersistenceState() == PersistenceState.NEW)
        {
            setDateCreated(new Date());
            setUserCreated(user.getFullName());
        }
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
