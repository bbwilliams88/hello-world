/*
 * $Id$
 */
package mil.dtic.cbes.service;

import java.util.List;
import java.util.Map;

public interface XmlValidator
{

//    public boolean validate();
    public boolean validate(String organizationCode);

  public boolean hasWarnings();

  public boolean hasErrors();

  public List<String> getWarningList();

  public List<String> getErrorList();

  public Map<String, List<String>> getErrorListMap();

  public Map<String, List<String>> getWarningListMap();
}
