package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._InstallationSchedule;

public class InstallationSchedule extends _InstallationSchedule
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
        setSchedule(getObjectContext().newObject(QuarterlySchedule.class));
    }

    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    public void shiftForwardInTime(int years)
    {
        if (this.getSchedule() != null)
            this.getSchedule().shiftForwardInTime(years);
    }

}
