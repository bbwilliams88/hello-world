package mil.dtic.cbes.job;

import java.io.File;

import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.utility.BudgesContext;

public class BudgesJobControl
{
  private File jobFolder = new File("/upload/r2/jobs/");
  
  public BudgesJob createJobInDB(JobTypeFlag type, String inputFile)
  {
    if (type==null || inputFile==null) throw new IllegalArgumentException();
    if (!new File(jobFolder, inputFile).exists()) throw new IllegalArgumentException("Source file does not exist.");
    
    BudgesJob job = new BudgesJob();
    BudgesContext.getBudgesJobDAO().saveOrUpdate(job);
    return job;
  }
}
