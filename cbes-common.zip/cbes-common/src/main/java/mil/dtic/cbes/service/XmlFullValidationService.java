/*
 * $Id$
 */
package mil.dtic.cbes.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.validation.LineItemListValidator;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.validation.backend.JustificationBookValidator;
import mil.dtic.cbes.submissions.validation.backend.MasterJustificationBookValidator;
import mil.dtic.cbes.submissions.validation.backend.R2ExhibitListRulesValidator;
import mil.dtic.cbes.submissions.validation.backend.ValidationMessages;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class XmlFullValidationService {
    private static final Logger log = CbesLogFactory.getLog(XmlFullValidationService.class);
    private static final String PRCP_MARKER = "#PRCP";
    
	protected XmlSchemaValidator schemaValidator;
	protected XmlRulesValidator rulesValidator = new XmlRulesValidator();
	protected ValidationMessages p40ValidationMessages;
	protected File xmlFile;
	protected byte[] xmlInputByteArray;
	protected InputStream xmlInputStream;
	protected List<String> xsdPathList;
	protected List<String> xslPathList;
	protected String schemaName;

	public XmlFullValidationService(String schemaName) {
	    log.debug("creating new XmlFullValidatonService for schemaName: " + schemaName);
		this.schemaName = schemaName;
	}

	public File getXmlFile() {
		return xmlFile;
	}

	public void setXmlFile(File xmlFile) {
		this.xmlFile = xmlFile;
	}

	public byte[] getXmlInputByteArray() {
		return xmlInputByteArray;
	}

	public void setXmlInputByteArray(byte[] xmlInputByteArray) {
		this.xmlInputByteArray = ArrayUtils.clone(xmlInputByteArray);
	}

	public InputStream getXmlInputStream()
  {
    return xmlInputStream;
  }

  public void setXmlInputStream(InputStream xmlInputStream)
  {
    this.xmlInputStream = xmlInputStream;
  }

  public List<String> getXsdPathList() {
		return xsdPathList;
	}

	public void setXsdPathList(List<String> xsdPathList) {
		this.xsdPathList = xsdPathList;
	}

	public List<String> getXslPathList()
	{
	  return xslPathList;
	}

	public void setXslPathList(List<String> xslPathList)
	{
	  this.xslPathList = xslPathList;
	}

    protected XmlValidator createR2SchemaValidator() {
        
        if (schemaValidator == null && xmlInputStream != null) {
            schemaValidator = new XmlSchemaValidator(xmlInputStream, schemaName);
        }
        
        if (schemaValidator == null && xmlInputByteArray != null) {
            InputStream xmlInputStream = new ByteArrayInputStream(xmlInputByteArray);
            schemaValidator = new XmlSchemaValidator(xmlInputStream, schemaName);
        }
        
        if (schemaValidator == null && xmlFile != null) {
            schemaValidator = new XmlSchemaValidator(xmlFile, schemaName);
        }
        
        return schemaValidator;
    }
    
	public boolean validateSchema() {
		boolean success = false;
		if (createR2SchemaValidator() != null){
			success = schemaValidator.validate();
		}
		return success;
	}

	 public boolean validateSchema(List<String> xsdPathList, List<String> xslPathList) {
	    boolean success = false;
	    if (createR2SchemaValidator() != null){
	      success = schemaValidator.validate(xsdPathList, xslPathList);
	    }
	    return success;
	  }
	 

	public void validateRules(MasterJustificationBook mjb, boolean onlyRunVerifiedRules) {
	    
		if (mjb != null) {
			rulesValidator = new XmlRulesValidator(new MasterJustificationBookValidator(mjb, onlyRunVerifiedRules));
			boolean hasWarnings = rulesValidator.isWarningsPresent(mjb.getServiceAgency().getCode());
			mjb.setHasWarnings(hasWarnings);  
			
			if (hasWarnings){
			    mjb.setOnlyPrcpWarnings(isOnlyPrcpWarnings(rulesValidator.getWarningListMap()));
			}
		}
		// dummy value, this ought to be fixed up.
//		return false;
	}

	public void validateRules(JustificationBook jb, boolean onlyRunVerifiedRules) {
	    
		if (jb != null) {
			rulesValidator = new XmlRulesValidator(new JustificationBookValidator(jb, onlyRunVerifiedRules));
			boolean hasWarnings = rulesValidator.isWarningsPresent(jb.getServiceAgency().getCode());
			jb.setHasWarnings(hasWarnings);
			
	         if (hasWarnings){
	             jb.setOnlyPrcpWarnings(isOnlyPrcpWarnings(rulesValidator.getWarningListMap()));
	         }
		}
		//return false;
	}
	
	/*CXE-5956: bulk rule exemption need service agency in order to execute exemptions.  JBook derivation should call this method, vice	the next one.*/
	public void validateRules(R2ExhibitList r2ExhibitList, ServiceAgency sa){
	    if (null == sa){
	        validateRules(r2ExhibitList);
	    }
	    else {
	        if (r2ExhibitList != null) {
	            rulesValidator = new XmlRulesValidator(new R2ExhibitListRulesValidator(r2ExhibitList, false));
	            boolean hasWarnings = rulesValidator.isWarningsPresent(sa.getCode()); 
	            r2ExhibitList.setHasWarnings(hasWarnings);
	            
	            if (hasWarnings){
	                r2ExhibitList.setOnlyPrcpWarnings(isOnlyPrcpWarnings(rulesValidator.getWarningListMap()));
	            }
	        }

	        //return false;
	        
	    }
	}

	public void validateRules(R2ExhibitList r2ExhibitList) {
		if (r2ExhibitList != null) {
			rulesValidator = new XmlRulesValidator(new R2ExhibitListRulesValidator(r2ExhibitList, false));
			boolean hasWarnings = rulesValidator.isWarningsPresent(""); // TODO: Hope this works.
			r2ExhibitList.setHasWarnings(hasWarnings);
			
            if (hasWarnings){
                r2ExhibitList.setOnlyPrcpWarnings(isOnlyPrcpWarnings(rulesValidator.getWarningListMap()));
            }
		}

		//return false;
	}

	public ValidationMessages validateRules(LineItemList lineItemList, boolean onlyRunVerifiedRules) {
		if (lineItemList != null) {
		  LineItemListValidator validator = BudgesContext.getLineItemListValidator();
			p40ValidationMessages = validator.validate(lineItemList, onlyRunVerifiedRules, false);
			return p40ValidationMessages;
		}

		return null;
	}

	public boolean isValid() {
		return (isSchemaValid() && isRulesValid());
	}

	public boolean isSchemaValid() {
		return (schemaValidator != null && !schemaValidator.hasErrors());
	}

	public boolean isFullyValid() {
		return (isValid() && !hasSchemaWarnings() && !hasRulesWarnings());
	}

	public boolean hasSchemaWarnings() {
		return (schemaValidator != null && schemaValidator.hasWarnings());
	}

	public boolean hasSchemaErrors() {
		return (schemaValidator != null && schemaValidator.hasErrors());
	}

	public List<String> getSchemaWarningList() {
		return (schemaValidator == null ? null : schemaValidator
				.getWarningList());
	}

	public List<String> getSchemaErrorList() {
		return (schemaValidator == null ? null : schemaValidator.getErrorList());
	}

	public boolean isRulesValid() {
		return (rulesValidator != null || p40ValidationMessages != null) && !hasRulesErrors();
	}

	public boolean hasRulesWarnings() {
	    if ((rulesValidator != null && rulesValidator.hasWarnings()) || (p40ValidationMessages != null && p40ValidationMessages.hasWarnings())){
	        List<String> warningList = getRulesWarningList();
	        isOnlyPrcpWarnings(warningList);
	        return true;
	    }
	    else { 
	        return false;
	    }
	}

	public boolean hasRulesErrors() {
		return ((rulesValidator != null && rulesValidator.hasErrors())
		    || (p40ValidationMessages != null && p40ValidationMessages.hasErrors()));
	}

	public List<String> getRulesWarningList() {
	  if(p40ValidationMessages != null) {
	    return p40ValidationMessages.getWarningStrings();
	  }
		return (rulesValidator == null) ? null : rulesValidator.getWarningList();
	}

	public List<String> getRulesErrorList() {
	  if(p40ValidationMessages != null) {
	    return p40ValidationMessages.getErrorStrings();
	  }
		return (rulesValidator == null) ? null : rulesValidator.getErrorList();
	}

	public Map<String, List<String>> getRulesErrorListMap() {
	  if(p40ValidationMessages != null) {
	    return p40ValidationMessages.getErrorStringMap();
	  }
		return (rulesValidator == null) ? null : rulesValidator.getErrorListMap();
	}

	public Map<String, List<String>> getRulesWarningListMap() {
	  if(p40ValidationMessages != null) {
	    return p40ValidationMessages.getWarningStringMap();
	  }
		return (rulesValidator == null) ? null : rulesValidator
				.getWarningListMap();
	}

	public ValidationMessages getP40ValidationMessages() {
	  return p40ValidationMessages;
	}

	public XmlSchemaValidator getSchemaValidator() {
		return schemaValidator;
	}

	public XmlRulesValidator getRulesValidator() {
		return rulesValidator;
	}

	public String getSchemaName() {
		return schemaName;
	}
	
	/**
	 * 
	 * @param warnings - List<String>
	 * @return  boolean - boolean
	 */
	private boolean isOnlyPrcpWarnings(List<String> warnings){
        if (null == warnings){
            return false;
        }
	    log.debug("determine if warnings are uniquely PRCP");
	    boolean rValue = true;
	    int i = 0;
        for (String ruleViolation : warnings){
            log.debug(String.format("warning rule (%s): %s", i++, ruleViolation));
            if (ruleViolation.contains(XmlFullValidationService.PRCP_MARKER)){
                continue;
            }
            else{
                rValue = false;
                break;
            }
        }
        log.debug("isOnlyPrcpWarnings list processing is: " + rValue);
	    return rValue;
	}

	/**
	 * List of warnings can be contained in a map or list. This
	 * method will handle maps and redirect values in the List<String> method.
	 * @param warnings - Map<String, List<String>>
	 * @return - boolean - boolean
	 */
    private boolean isOnlyPrcpWarnings(Map<String, List<String>> warnings){
        if (null == warnings){
            return false;
        }
        log.debug("processing warning from warning map of size: " + warnings.size());
        boolean rValue = true;
        for (Map.Entry<String, List<String>> entry : warnings.entrySet()){
            rValue = isOnlyPrcpWarnings(entry.getValue());
            if (rValue == false){
                break;
            }
        }
        log.debug("isOnlyPrcpWarnings map processing is: " + rValue);
        return rValue;
    }
	
}
