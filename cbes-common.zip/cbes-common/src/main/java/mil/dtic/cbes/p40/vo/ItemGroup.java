package mil.dtic.cbes.p40.vo;

import static mil.dtic.cbes.enums.ItemExhibitType.P40A;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._ItemGroup;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ItemGroup extends _ItemGroup implements ItemExhibitType, CostContainer, HasTotalCosts, IsSubtotalParent, RollupParent
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(ItemGroup.class);


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setItemExhibit(ItemExhibit.byCode(getObjectContext(), P40A)); // still a hack
        setDisplayOrder(0);
        setupItemGroupTotal();
    }

    @Override
    protected void onPostLoad()
    {
        setupItemGroupTotal();
    }

    private void setupItemGroupTotal()
    {
        if(getTotalCosts() == null)
            setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
    }

    @Override
    protected void onPrePersist()
    {
      //Util.cleanupContinuingTriplet(this);
      Util.cleanupContinuingTotal(this);
    }
    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    @Override
    public List<? extends CostContainer> getChildren()
    {
        List<Item> items = new ArrayList<Item>();

        for (P40aCategory category : getCategories())
            items.addAll(category.getItems());

        return items;
    }

    @Override
    public Costs getCosts()
    {
        return super.getTotalCosts();
    }

    @Override
    public void calculateSubtotals() throws MethodDispatchException
    {
//        boolean isAnyCategoryContinuing = false;
        Costs   subtotals               = Costs.create(getObjectContext(), CostRowType.TOTALCOST);

        for (P40aCategory category : getCategories())
        {
            category.calculateSubtotals();
            addToSubtotalInDollars(subtotals, category.getItems());
//            for (Item item : category.getItems())
//            {
//                subtotals = addChildToSubtotal(subtotals,
//                                               CostUtil.getCalculatedCosts(item.getCosts(),
//                                                                           item.getUnitCosts(),
//                                                                           item.getQuantities(),
//                                                                           getParentLineItem().getQuantityUnits(),
//                                                                           getParentLineItem().getUnitCostUnits(),
//                                                                           getParentLineItem().getTotalCostUnits()));
//
//                if (item.isContinuing())
//                    isAnyCategoryContinuing = true;
//            }
        }
//
//        subtotals.setContinuing(isAnyCategoryContinuing);
        replaceCosts(setSubtotalValuesInMillion(subtotals), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
    }

    public boolean containsCaseInsensitive(String aCatgory)
    {
      for (P40aCategory category : getCategories())
        if (StringUtils.equalsIgnoreCase(category.getTitle(), aCatgory))
          return true;

      return false;
    }

    // FIXME: DO NOT SORT HERE!!!!!!!!!!!!!!
    @Override
    public List<P40aCategory> getCategories()
    {
        return getSortedByDisplayOrder(super.getCategories());
    }

    public List<P40aCategory> getOrderedCategories()
    {
        return getSortedByDisplayOrder(super.getCategories());
    }

    public P40aCategory addCategory(String name)
    {
      P40aCategory cat = getObjectContext().newObject(P40aCategory.class);
      if ("uncategorized".equalsIgnoreCase(name))
        cat.setTitle("");
      else
        cat.setTitle(name);
      addToCategories(cat);
      return cat;
    }

    public void removeCategory(P40aCategory i)
    {
      removeFromCategories(i);
      getObjectContext().deleteObjects(i);
    }

    public List<Item> getAllItemsInOrder()
    {
      //sort by categories display order then item display order
      List<Ordering> orderings = new ArrayList<Ordering>();
      orderings.add(new Ordering(makePath(Item.P40A_CATEGORY_RELATIONSHIP_PROPERTY, P40aCategory.DISPLAY_ORDER_PROPERTY), SortOrder.ASCENDING));
      orderings.add(new Ordering(Item.DISPLAY_ORDER_PROPERTY, SortOrder.ASCENDING));
      List<Item> items = new ArrayList<Item>();
      for (P40aCategory cat : getCategories()) {
        items.addAll(cat.getOrderedItems());
      }
      Ordering.orderList(items, orderings);
      return items;
    }

    @Override
    public String getIdentifyingString()
    {
      return getName();
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        for (P40aCategory category : this.getCategories())
            category.shiftForwardInTime(years);
        if (getTotalCosts() != null)
          getTotalCosts().shiftForwardInTime(years);
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public Iterator<P40aCategory> jibx_categoriesIterator()
    {
        return getIterator(getCategories());
    }

    public boolean jibx_hasCategoryList()
    {
    	if(getCategories().isEmpty())
    		return false;
    	else
    		return true;
    }

    public boolean jibx_testName(){
      return !StringUtils.isEmpty(getName());
    }

    public void jibx_postSet()
    {
        log.debug("calling the on post set for jibx");
        Util.generateDisplayOrder(getCategories());
    }

    public boolean jibx_hasCategory()
    {
        return !org.springframework.util.CollectionUtils.isEmpty(getCategories());
    }

    @Override
    public boolean isContinuing()
    {
      // TODO Need to add Continuing to the DB and Cayenne Mapping
      return false;
    }

    @Override
    public String jibx_getContinuingFootnote()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public void jibx_setContinuingFootnote(String s)
    {
      // TODO Auto-generated method stub

    }

    @Override
    public boolean jibx_hasTotalCost()
    {
      return getTotalCosts() != null && !getTotalCosts().isEmpty();
    }

    @Override
    public void jibx_setTotalCosts(Costs totalCosts)
    {
      if (totalCosts != null)
        setTotalCosts(totalCosts);
    }

    @Override
    public Costs getUnitCosts()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Costs getQuantities()
    {
      // TODO Auto-generated method stub
      return null;
    }


}
