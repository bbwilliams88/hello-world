package mil.dtic.cbes.jb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;

public class PdfBookMarkBuilder2 {
    JustificationBook jb;

    public PdfBookMarkBuilder2(JustificationBook jb) {
        this.jb = jb;
    }

    public List<HashMap<String, Object>> getBookmarkList() {
        List<HashMap<String, Object>> jbOutlineList = new ArrayList<HashMap<String, Object>>();
        List<HashMap<String, Object>> outlineList = new ArrayList<HashMap<String, Object>>();

        jbOutlineList.add(createBookmarkEntry(jb, outlineList));
        outlineList.add(createBookmarkEntry(jb.getCoverDoc()));
        outlineList.add(createBookmarkEntry(jb.getToc()));

        if (jb.getCostDoc() != null) {
            outlineList.add(createBookmarkEntry(jb.getCostDoc()));
        }

        if (jb.getIntroductionDoc() != null) {
            outlineList.add(createBookmarkEntry(jb.getIntroductionDoc()));
        }

        if (jb.getSummaryDoc() != null) {
            outlineList.add(createBookmarkEntry(jb.getSummaryDoc()));
        }

        if (jb.getPeTocByBa() != null) {
            outlineList.add(createBookmarkEntry(jb.getPeTocByBa()));
        }

        if (jb.getPeTocByTitle() != null) {
            outlineList.add(createBookmarkEntry(jb.getPeTocByTitle()));
        }

        if (jb.getUserR1Doc() != null) {
            outlineList.add(createBookmarkEntry(jb.getUserR1Doc()));
        }

        if (jb.getR1Summary() != null) {
            outlineList.add(createBookmarkEntry(jb.getR1Summary()));
        }

        if (jb.getR1() != null) {
            outlineList.add(createBookmarkEntry(jb.getR1()));
        }

        if (jb.getR1c() != null) {
            outlineList.add(createBookmarkEntry(jb.getR1c()));
        }

        if (jb.getR1d() != null) {
            outlineList.add(createBookmarkEntry(jb.getR1d()));
        }

        if (jb.getSupplementalDocCollection() != null) {
            List<HashMap<String, Object>> suppOutlineList = new ArrayList<HashMap<String, Object>>();
            for (JBSupplementalDoc suppDoc : jb.getSupplementalDocCollection()
                    .getSupplementalDocList()) {
                suppOutlineList.add(createBookmarkEntry(suppDoc));
            }
            outlineList.add(createBookmarkEntry(
                    jb.getSupplementalDocCollection(), suppOutlineList));
        }

        if (jb.getAcronymDoc() != null) {
            outlineList.add(createBookmarkEntry(jb.getAcronymDoc()));
        }

        if (jb.r2sExist()) {
            List<HashMap<String, Object>> r2OutlineList = new ArrayList<HashMap<String, Object>>();
            for (R2Exhibit r2Exhibit : jb.getR2ExhibitList().getR2Exhibits()) {
                List<HashMap<String, Object>> projectOutlineList = new ArrayList<HashMap<String, Object>>();
                for (Project project : r2Exhibit.getProgramElement()
                        .getProjects()) {
                    projectOutlineList
                            .add(createBookmarkEntry(r2Exhibit, project));
                }
                r2OutlineList.add(
                        createBookmarkEntry(r2Exhibit, projectOutlineList));
            }
            outlineList.add(
                    createBookmarkEntry(jb.getR2ExhibitList(), r2OutlineList));
        }

        return jbOutlineList;
    }

    private HashMap<String, Object> createBookmarkEntry(JBPart jbPart) {
        return createBookmarkEntry(jbPart, null);
    }

    private HashMap<String, Object> createBookmarkEntry(JBPart jbPart,
            List<HashMap<String, Object>> kidsList) {
        HashMap<String, Object> bookmarkEntryMap = new HashMap<String, Object>();
        bookmarkEntryMap.put("Title", jbPart.getPdfBookmarkLabel());
        bookmarkEntryMap.put("Action", "GoTo");
        bookmarkEntryMap.put("Page", jbPart.getPdfAbsoluteStartPage() + " Fit");
        if (kidsList != null) {
            bookmarkEntryMap.put("Kids", kidsList);
        }

        return bookmarkEntryMap;
    }

    private HashMap<String, Object> createBookmarkEntry(R2Exhibit r2Exhibit,
            Project project) {
        HashMap<String, Object> bookmarkEntryMap = new HashMap<String, Object>();
        bookmarkEntryMap.put("Title", project.getPdfBookmarkLabel());
        bookmarkEntryMap.put("Action", "GoTo");
        // We don't have page # at the project level, so just use the
        // container's page #
        bookmarkEntryMap.put("Page",
                r2Exhibit.getPdfAbsoluteStartPage() + " Fit");
        return bookmarkEntryMap;
    }

}
