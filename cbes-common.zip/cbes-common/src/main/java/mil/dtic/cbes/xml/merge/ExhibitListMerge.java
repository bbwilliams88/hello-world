package mil.dtic.cbes.xml.merge;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;

/**
 * Merges exhibits from exhibit xml documents.
 * Collates a set of books by exhibit type and Service/DefenseWide.
 * Generates a unified file for a budget, P40 or R2.
 *
 * @author AZumkhaw
 *
 */
public class ExhibitListMerge {
  public static final String NOT_A_VALID_EXHIBIT_LIST = "_NOT_A_VALID_";

  protected static final String RDTE = "_RDTE_";
  protected static final String LI = "_LI_";
  protected static final String DW = "_DW_";
  protected static final String AIR_FORCE = "_Air_Force_";
  protected static final String NAVY = "_Navy_";
  protected static final String ARMY = "_Army_";

  private static final String MERGED_FILES_ZIP_NAME = "merged-exhibit-files";
  private static final Logger log = CbesLogFactory.getLog(ExhibitListMerge.class);

  public enum BudgetType {
    R2, P40;
  }

  public enum Organization {
    Navy, Army, AirForce, DW;
  }

  final private Organizer<File> organizer = new Organizer<File>();
  private String outputDirectory;
  private File zipArchive;

  /** Organize xml files by file names into budget type and service branch */
  private static class Organizer<T> {
    private Map<String, T> exhibitCountMap = new LinkedHashMap<String, T>();

    public void record(String path, T ec) {
      String key = buildKey(path);
      exhibitCountMap.put(key, ec);
    }

    /** Examine the xml file name and determine with it P40, R2. Also determine service branch or DW. */
    public String buildKey(String fileUrl) {
      String type = fileUrl.contains("RDTE") ? BudgetType.R2.toString() : BudgetType.P40.toString();
      String organization = null;
      if (fileUrl.contains(NAVY)) {
        organization = Organization.Navy.toString();
      }
      else if (fileUrl.contains(ARMY)) {
        organization = Organization.Army.toString();
      }
      else if (fileUrl.contains(AIR_FORCE)) {
        organization = Organization.AirForce.toString();
      }
      else {
        organization = Organization.DW.toString();
      }
      String key = type + "_" + organization + "_" + fileUrl;
      return key;
    }

    /** Return items that match a {BudgetType, Organization} eg. P40 Army, R2 Navy */
    public LinkedList<String> keysForSection(BudgetType budgetType, Organization organization) {
      LinkedList<String> matching = new LinkedList<String>();

      Iterator<String> iterator = exhibitCountMap.keySet().iterator();
      while (iterator.hasNext()) {
        String key = iterator.next();
        if (key.startsWith(budgetType.toString()) && key.contains("_" + organization.toString() + "_")) {
          matching.add(key);
        }
      }

      return matching;
    }

    public T get(String key) {
      return exhibitCountMap.get(key);
    }
  }

  /**
   * Merges one or more XML files with exhibits into an exhibit list.
   */
  private static class ExhibitXmlMerge {
    private DocumentBuilder builder;
    private XPath xPath;
    private Organization organization;
    private BudgetType budgetType;
    private String listTagName;
    private String exhibitTagName;
    private String nm;
    private String nmURL;
    private Element mergeDocumentRootNode;
    private String mergeXmlPath;
    private boolean hasTargetSchema;
    private ExhibitDeduper deduper;

    public ExhibitXmlMerge(Organization organization, BudgetType budgetType) {
      this(budgetType);
      this.organization = organization;
    }

    public ExhibitXmlMerge(BudgetType budgetType) {
      this.budgetType = budgetType;
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      try {
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        builder = factory.newDocumentBuilder();
        xPath = XPathFactory.newInstance().newXPath();
      } catch (ParserConfigurationException e) {
        log.debug("Unable to merge xml files for " + budgetType, e);
      }
      configureForBudgetType(budgetType);
      mergeDocumentRootNode = newMergeRootElementNode(listTagName, nm, nmURL, hasTargetSchema);
      deduper = new ExhibitDeduper(xPath, builder, this.budgetType);
    }

    public String getMergedXmlFilePath() { return mergeXmlPath; }

    public BudgetType getBudgetType() { return budgetType; }

    public Organization getOrganization() { return organization; }

    public void mergeXML(File[] files) throws SAXException, IOException, XPathExpressionException {
      for (File exhibitXmlFile : files) {
        mergeDomElements(exhibitXmlFile.getAbsolutePath());
      }
      mergeXmlPath = createMergedXmlFilePath();
      writeMergeToFile(mergeDocumentRootNode.getOwnerDocument());
      deduper.debugInfo();
    }

    private void configureForBudgetType(BudgetType budgetType) {
      // setup the merged xml document for either R2 or P40
      if (this.budgetType == BudgetType.R2) {
        listTagName = "ProgramElementList";
        exhibitTagName = "ProgramElement";
        nm = "r2";
        nmURL = "http://www.dtic.mil/comptroller/xml/schema/022009/r2";
        hasTargetSchema = true;
      }
      else {
        listTagName = "LineItemList";
        exhibitTagName = "LineItem";
        nm = "proc";
        nmURL = "http://www.dtic.mil/comptroller/xml/schema/20100219/procurement";
        hasTargetSchema = false;
      }
    }

    private Element newMergeRootElementNode(String listTagName, String nm, String nmURL, boolean hasTargetSchema) {
      Document mergedXML = builder.newDocument();
      Element root = mergedXML.createElement(nm + ":"+ listTagName);
      root.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + nm, nmURL);
      if (hasTargetSchema) {
        root.setAttribute("targetSchemaVersion", "1.0");
      }
      mergedXML.appendChild(root);
      return root;
    }

    /** Merges exhibits from an xml exhibit file to a root dom element */
    private void mergeDomElements(String exhibitXmlFile) throws SAXException, IOException, XPathExpressionException {
      Document exhibitListDoc = builder.parse(exhibitXmlFile);
      XPathExpression xPathExpr = xPath.compile("*//" + exhibitTagName);
      NodeList exhibitList = (NodeList) xPathExpr.evaluate(exhibitListDoc, XPathConstants.NODESET);
      int length = exhibitList.getLength();
      Document mergedDocument = mergeDocumentRootNode.getOwnerDocument();
      for (int i=0; i < length; i++) {
        Node exhibitNodeCopy = deduper.copyIfUnique(exhibitList.item(i));
        if (exhibitNodeCopy != null) {
          mergeDocumentRootNode.appendChild(mergedDocument.adoptNode(exhibitNodeCopy));
        }
      }
    }

    // write DOM document to xml file on disk
    private void writeMergeToFile(Document mergedXML) {
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer;
      try {
        transformer = transformerFactory.newTransformer();
        mergedXML.setXmlStandalone(true);
        DOMSource source = new DOMSource(mergedXML);
        StreamResult result = new StreamResult(new File(mergeXmlPath));
        transformer.transform(source, result);
      } catch (TransformerException e) {
        log.debug("Exception writing merged file", e);
      }
    }

    /**
     * Generate a file name for the merge file.
     */
    private String createMergedXmlFilePath() throws IOException {
      String prefix = (organization != null) ? budgetType + "_" + organization + "_" : budgetType + "__MERGED_";
      return File.createTempFile("-^-", ".xml").getAbsolutePath().replace("-^-", prefix);
    }
  }

  public ExhibitListMerge(File[] uncollatedXmlFiles) {
    collate(uncollatedXmlFiles);
  }

  public void setOutputDirectory(String outputDirectory) {
    this.outputDirectory = outputDirectory;
  }

  public File getZipArchive() {
    return zipArchive;
  }

  private void collate(File[] uncollatedXmlFiles)  {
    // organize the files by service, DW
    for (File f : uncollatedXmlFiles) {
      organizer.record(f.getAbsolutePath(), f);
    }
  }

  public void create() throws XPathExpressionException, SAXException, IOException {
    // create a set of merged exhibit list xml files
    List<String> generatedFiles = new ArrayList<String>();
    for (BudgetType budgetType : BudgetType.values()) {
      int organizationCount = 0;
      List<File> budgetTypeFiles = new ArrayList<File>();
      for (Organization organization : Organization.values()) {
        // generate a merge specific to a service or defense wide
        ExhibitXmlMerge merge = new ExhibitXmlMerge(organization, budgetType);
        File[] filesToMerge = filesForExhibitMerge(organizer, merge);
        if (filesToMerge.length > 0) {
          log.debug("Merging " + filesToMerge.length + " files, " + budgetType + " " + organization);
          organizationCount++;
          merge.mergeXML(filesToMerge);
          generatedFiles.add(merge.getMergedXmlFilePath());
          for (File f : filesToMerge) {
            budgetTypeFiles.add(f);
          }
        }
        else {
          log.debug("No xml files discovered for " + budgetType + " " + organization);
        }
      }

      // Generate single merge file for the entire budget
      if (organizationCount > 1) {
        log.debug("Required, merging " + budgetTypeFiles.size() + " files for "+ budgetType);
        ExhibitXmlMerge merge = new ExhibitXmlMerge(budgetType);
        merge.mergeXML(budgetTypeFiles.toArray(new File[budgetTypeFiles.size()]));
        generatedFiles.add(merge.getMergedXmlFilePath());
      }
    }
    zipArchive = createZip(generatedFiles);
  }

  private File createZip(List<String> filesToZip) {
    File zipFile = null;
    if (CollectionUtils.isNotEmpty(filesToZip)) {
      ZipOutputStream zipFileStream = null;
      zipFile = new File(outputDirectory, FileUtil.createZipFileName(MERGED_FILES_ZIP_NAME + "_" + UUID.randomUUID().toString()));
      try
      {
        zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
        File fileToAddToZip = null;
        for (String filePath : filesToZip)
        {
          log.debug("archiving " + filePath + " into " + zipFile.getAbsolutePath());
          ZipEntry zipEntry = new ZipEntry(FileUtil.getFileNameWithoutPath(filePath));
          zipFileStream.putNextEntry(zipEntry);
          fileToAddToZip = new File(filePath);
          FileUtil.writeFileContents(fileToAddToZip, zipFileStream, false);
        }
        log.debug("Finished packaging merge");
      }
      catch (IOException e) {
        log.error("Could not create zip file for master JB(s).", e);
      }
      finally
      {
        FileUtil.close(zipFileStream);
      }
    }
    return zipFile;
  }

  private File[] filesForExhibitMerge(Organizer<File> organizer, ExhibitXmlMerge merge) throws XPathExpressionException, SAXException, IOException {
    File[] files = new File[0];
    LinkedList<String> keys = organizer.keysForSection(merge.getBudgetType(), merge.getOrganization());
    if (!keys.isEmpty()) {
      ArrayList<File> a = new ArrayList<File>();
      for (String key : keys) {
        File exhibitXmlFile = organizer.get(key);
        a.add(exhibitXmlFile);
      }
      files = a.toArray(new File[0]);
    }
    return files;
  }
}
