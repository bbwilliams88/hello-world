package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectRelatedProject;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class ProductionSupportFacilityProjectRelatedProject extends _ProductionSupportFacilityProjectRelatedProject implements HasDisplayOrder
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);
  }

  public void shiftForwardInTime(int years)
  {

  }
}
