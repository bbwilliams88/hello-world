package mil.dtic.cbes.xml;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.jb.JBBase;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.service.XmlRulesValidationMessage;
import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.CongressionalAddDetail;
import mil.dtic.cbes.submissions.ValueObjects.ContractMethod;
import mil.dtic.cbes.submissions.ValueObjects.ContractType;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryGroup;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryGroupName;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryItem;
import mil.dtic.cbes.submissions.ValueObjects.FundingVehicle;
import mil.dtic.cbes.submissions.ValueObjects.JointFunding;
import mil.dtic.cbes.submissions.ValueObjects.MajorPerformer;
import mil.dtic.cbes.submissions.ValueObjects.OtherAdjustmentDetail;
import mil.dtic.cbes.submissions.ValueObjects.OtherProgramFundingSummary;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.R3Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R4Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R4aExhibit;
import mil.dtic.cbes.submissions.ValueObjects.R5Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleDetail;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubProjectSchedule;
import mil.dtic.cbes.submissions.validation.backend.CacheFactory;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.submissiondate.SubmissionDateProcessorFactory;
import mil.dtic.utility.submissiondate.exception.SubmissionDateProcessorException;
import mil.dtic.utility.submissiondate.synch.SubmissionDateProcessor;

public class XmlToJavaPostProcessor
{
  private static final Logger log = CbesLogFactory.getLog(XmlToJavaPostProcessor.class);

  private List<String> errorList;
  private Map<String, List<String>> errorListMap;
  private final BudgesUser budgesUserForAuditFields;
  private final P40User p40UserForAuditFields;
  private Map<String, ServiceAgency> saCache;
  private Map<String, ContractMethod> cmCache;
  private Map<String, ContractType> ctCache;
  private Map<String, FundingVehicle> fvCache;
  private Map<String, CostCategoryGroupName> ccgnCache;


  public XmlToJavaPostProcessor(BudgesUser budgesUserForAuditFields, P40User p40UserForAuditFields){
    this.budgesUserForAuditFields = budgesUserForAuditFields;
    this.p40UserForAuditFields = p40UserForAuditFields;
    errorList = new ArrayList<String>();
    errorListMap = new HashMap<String, List<String>>();
  }

  private Map<String, ServiceAgency> getSaCache(){
      
    if (saCache == null) {
      saCache = CacheFactory.getServiceAgencyCache();
    }
    return saCache;
  }


  private Map<String, ContractMethod> getCmCache(){
    if (cmCache == null) {
      cmCache = CacheFactory.getContractMethodCache();
    }
    return cmCache;
  }

  private Map<String, ContractType> getCtCache(){
    if (ctCache == null) {
      ctCache = CacheFactory.getContractTypeCache();
    }
    return ctCache;
  }

  private Map<String, FundingVehicle> getFvCache() {
    if (fvCache == null) {
      fvCache = CacheFactory.getFundingVehicleCache();
    }
    return fvCache;
  }

  private Map<String, CostCategoryGroupName> getCcgnCache() {
    if (ccgnCache == null) {
      ccgnCache = CacheFactory.getCCGNameCache();
    }
    return ccgnCache;
  }

  public boolean hasErrors() {
    return(errorList != null && errorList.size() > 0);
  }

  public List<String> getErrorList() {
    return errorList;
  }

  public void setErrorList(List<String> errorList)  {
    this.errorList = errorList;
  }

  protected void populateAgency(JBBase jbb) {
    if (jbb.getServiceAgency() != null)  {
      List<ServiceAgency> saList = BudgesContext.getServiceAgencyDAO().findByName(jbb.getServiceAgency().getName());
      if (saList.size() > 1) {
        log.error("Too many agencies found for " + jbb.getServiceAgency().getName() + ": " + saList);
      }
      if (CollectionUtils.isNotEmpty(saList)) {
        jbb.setServiceAgency(saList.get(0));
      }
      else {
        logError("Service/Agency name is invalid: " + jbb.getServiceAgency().getName());
      }
    }
  }

  protected void populateBuiltinLogoFileName(JBBase jbb) {
    if (jbb.getServiceAgency() != null)  {
      String fileName = jbb.getServiceAgency().getLogoFileName();
      jbb.setBuiltinLogoFileName(fileName);
      if (jbb.getCoverDoc() != null) {
        jbb.getCoverDoc().setBuiltinLogoFileName(fileName);
      }
    }
  }


  protected void process(MasterJustificationBook mjb) {
    populateAgency(mjb);
    populateBuiltinLogoFileName(mjb);
    if (mjb.getJbgList() != null) {
      int jbIndex = 0;
      for (JustificationBookGroup jbg : mjb.getJbgList())
      {
        for (JustificationBookInfo jbi : jbg.getJbiList())
        {
          JustificationBook jb = jbi.getJb();
          jb.setMjb(mjb);
          DocumentAssemblyOptions docAssemblyOptions = mjb.getDocAssemblyOptions();
          if (docAssemblyOptions == null)
          {
            docAssemblyOptions = new DocumentAssemblyOptions();
            docAssemblyOptions.setForceEvenPages(true);
            mjb.setDocAssemblyOptions(docAssemblyOptions);
          }

          process(jb);

          if (!docAssemblyOptions.isUseLegacyMJBFormat())
          {
            if (jbIndex == 0)
            {
              // These should only be set if any of the JB's within a Master JB
              // indicate to "include" the Master JB level counterparts
              docAssemblyOptions.setGenerateProgramElementTocByBA(false);
              docAssemblyOptions.setGenerateProgramElementTocByTitle(false);
              docAssemblyOptions.setGenerateR1Summary(false);
              docAssemblyOptions.setGenerateR1(false);
              docAssemblyOptions.setGenerateR1c(false);
              docAssemblyOptions.setGenerateR1d(false);

              docAssemblyOptions.setGenerateLineItemTocByBA(false);
              docAssemblyOptions.setGenerateLineItemTocByTitle(false);
              docAssemblyOptions.setGenerateP1(false);

            }
            DocumentAssemblyOptions jbDocAssemblyOptions = jb.getDocAssemblyOptions();
            docAssemblyOptions.setGenerateProgramElementTocByBA(docAssemblyOptions.isGenerateProgramElementTocByBA() | jbDocAssemblyOptions.isIncludeMasterProgramElementTocByBA());
            docAssemblyOptions.setGenerateProgramElementTocByTitle(docAssemblyOptions.isGenerateProgramElementTocByTitle() | jbDocAssemblyOptions.isIncludeMasterProgramElementTocByTitle());
            docAssemblyOptions.setGenerateR1Summary(docAssemblyOptions.isGenerateR1Summary() | jbDocAssemblyOptions.isIncludeMasterR1Summary());
            docAssemblyOptions.setGenerateR1(docAssemblyOptions.isGenerateR1() | jbDocAssemblyOptions.isIncludeMasterR1());
            docAssemblyOptions.setGenerateR1c(docAssemblyOptions.isGenerateR1c() | jbDocAssemblyOptions.isIncludeMasterR1c());
            docAssemblyOptions.setGenerateR1d(docAssemblyOptions.isGenerateR1d() | jbDocAssemblyOptions.isIncludeMasterR1d());
            docAssemblyOptions.setSuppressSubExhibits(docAssemblyOptions.isSuppressSubExhibits() | jbDocAssemblyOptions.isSuppressSubExhibits());

            docAssemblyOptions.setGenerateLineItemTocByBA(docAssemblyOptions.isGenerateLineItemTocByBA() | jbDocAssemblyOptions.isIncludeMasterLineItemTocByBA());
            docAssemblyOptions.setGenerateLineItemTocByTitle(docAssemblyOptions.isGenerateLineItemTocByTitle() | jbDocAssemblyOptions.isIncludeMasterLineItemTocByTitle());
            docAssemblyOptions.setGenerateP1(docAssemblyOptions.isGenerateP1() | jbDocAssemblyOptions.isIncludeMasterP1());
            docAssemblyOptions.setGenerateP1m(docAssemblyOptions.isGenerateP1m() | jbDocAssemblyOptions.isIncludeMasterP1m());
          }
          ++jbIndex;
        }
      }
    }
  }


  protected void process(JustificationBook jb)
  {
    DocumentAssemblyOptions docAssemblyOptions = jb.getDocAssemblyOptions();

    if (docAssemblyOptions == null)
    {
      docAssemblyOptions = new DocumentAssemblyOptions();
      jb.setDocAssemblyOptions(docAssemblyOptions);

      if (jb.getMjb() == null)
      {
        // we've got a standalone jb (not inside mjb)
        if (jb.r2sExist())
        {
          docAssemblyOptions.setGenerateR1(false);
          docAssemblyOptions.setGenerateProgramElementTocByBA(true);
          docAssemblyOptions.setGenerateProgramElementTocByTitle(true);
        }

        if (jb.lineItemsExist())
        {
          docAssemblyOptions.setGenerateP1(false);
          docAssemblyOptions.setGenerateLineItemTocByBA(true);
          docAssemblyOptions.setGenerateLineItemTocByTitle(true);
        }
        docAssemblyOptions.setForceEvenPages(true);

      }
      else
      {
        // jb is inside mjb
        DocumentAssemblyOptions mjbDocAssemblyOptions = jb.getMjb().getDocAssemblyOptions();
        if (mjbDocAssemblyOptions.isUseLegacyMJBFormat())
        {
          // The old (bes/pb 2011) MJB format (MJB prelude followed by the JB
          // book for each JB volume)
          if (jb.r2sExist())
          {
            docAssemblyOptions.setGenerateR1(false);
            docAssemblyOptions.setGenerateProgramElementTocByBA(true);
            docAssemblyOptions.setGenerateProgramElementTocByTitle(true);
          }

          if (jb.lineItemsExist())
          {
            docAssemblyOptions.setGenerateP1(false);
            docAssemblyOptions.setGenerateLineItemTocByBA(true);
            docAssemblyOptions.setGenerateLineItemTocByTitle(true);
          }
        }
        else
        {
          // The new (bes/pb 2012 +) consolidatd format (each volume is a
          // consolidated MJB/JB)
          if (jb.r2sExist())
          {
            docAssemblyOptions.setIncludeMasterR1(false);
            docAssemblyOptions.setIncludeMasterProgramElementTocByBA(true);
            docAssemblyOptions.setIncludeMasterProgramElementTocByTitle(true);
          }

          if (jb.lineItemsExist())
          {
            docAssemblyOptions.setIncludeMasterP1(false);
            docAssemblyOptions.setIncludeMasterLineItemTocByBA(true);
            docAssemblyOptions.setIncludeMasterLineItemTocByTitle(true);
          }

          docAssemblyOptions.setIncludeTov(true);
        }

      }

    }

    if (jb.getMjb() != null)
    {
      DocumentAssemblyOptions mjbDocAssemblyOptions = jb.getMjb().getDocAssemblyOptions();
      if (!mjbDocAssemblyOptions.isHonorSubordinateDocumentAssemblyOptions())
      {
        docAssemblyOptions.setForceEvenPages(mjbDocAssemblyOptions.isForceEvenPages());
        docAssemblyOptions.setWatermark(mjbDocAssemblyOptions.getWatermark());
        docAssemblyOptions.setTrackingHeader(mjbDocAssemblyOptions.getTrackingHeader());
        docAssemblyOptions.setSuppressSubExhibits(mjbDocAssemblyOptions.isSuppressSubExhibits());
      }
    }

    populateAgency(jb);
    populateBuiltinLogoFileName(jb);
    process(jb.getR2ExhibitList());
    process(jb.getLineItemList());

//    if (jb.isClassifiedChildrenPresent())
//    {
//      jb.setClassified(true);
//    }

    if (jb.multiYearProcurementsExist())
    {
      jb.getLineItemList().addAssociatedMultiYearProcurement(jb.getMultiYearProcurementList());
    }
  }


  /*
  protected void process(R2ExhibitList r2ExhibitList)
  {
    if (r2ExhibitList != null)
    {
      int peIndex = 1;
      for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits())
      {
        process(r2Exhibit.getProgramElement(), peIndex++);
      }
    }
  }
*/

  protected void process(R2ExhibitList r2ExhibitList) { //CXE-6607
    Date submissionDate = null;
    
    if (r2ExhibitList != null && r2ExhibitList.count() > 0){
        try {
            submissionDate = getSubmissionDate(r2ExhibitList.getR2Exhibits().get(0).getProgramElement());
            if (null == submissionDate) {
                log.error("failed to capture a submissiondate, no R2exhibit processing occured.");
                return;
              }
        }
        catch(SubmissionDateProcessorException sdpe) {
            log.error("failed to capture current submissiondate, no R2exhibit processing - msg: " + sdpe.getMessage());
            return;
        }
    
        int peIndex = 1;
        
        for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits()){
            ProgramElement pe = r2Exhibit.getProgramElement();
            pe.setSubmissionDate(submissionDate);
            process(pe, peIndex++);
        }
    }
    
  }

  protected void process(ProgramElement pe, int peIndex) {
    BudgetActivity ba = convertBudgetActivity(pe.getBudgetActivity(), pe.getServiceAgency(), pe.getNumber(), peIndex);
    ServiceAgency sa = convertServiceAgencyName(pe.getServiceAgency(), pe.getNumber(), peIndex);
    pe.setBudgetActivity(ba);
    pe.setServiceAgency(sa);

    Util.setAuditFieldsForNewObject(pe, budgesUserForAuditFields);
    pe.setOverallDateModified(pe.getDateModified());
    pe.setOverallModifiedByUser(pe.getModifiedByBudgesUser());

    int oadIndex = 0;
    if (CollectionUtils.isNotEmpty(pe.getOtherAdjustmentDetails()))
    {
      for (OtherAdjustmentDetail oad : pe.getOtherAdjustmentDetails())
      {
        Util.setAuditFieldsForNewObject(oad, budgesUserForAuditFields);
        oad.setDisplayOrder(Util.getInitDisplayOrder(oadIndex++));
        oad.setProgramElement(pe);
      }
    }

    processProjects(pe, peIndex);
  }


  protected void processProjects(ProgramElement pe, int peIndex)
  {
    if(CollectionUtils.isNotEmpty(pe.getProjects())) {
      int projIndex = 0;
      for (Project project : pe.getProjects())
      {
        Util.setAuditFieldsForNewObject(project, budgesUserForAuditFields);
        project.setDisplayOrder(Util.getInitDisplayOrder(projIndex++));
        project.setIncludeInMergedPdf(true);

        project.setProgramElement(pe);
        if (project.getR2aExhibit() != null)
        {
          Util.setAuditFieldsForNewObject(project.getR2aExhibit(), budgesUserForAuditFields);
          if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getAccomplishmentsPlannedPrograms()))
          {
            int appIndex = 0;
            for (AccomplishmentPlannedProgram app : project.getR2aExhibit().getAccomplishmentsPlannedPrograms())
            {
              Util.setAuditFieldsForNewObject(app, budgesUserForAuditFields);
              app.setDisplayOrder(Util.getInitDisplayOrder(appIndex++));
              app.setProject(project);
              // TODO Set the JSF "other funding" fields to null for the time
              // being, until they are removed from the schema;
              // This will ensure that if they had values before, the XML that we
              // regenerate and embed in an R2 PDF will not include them
              app.setOtherFundingPy(null);
              app.setOtherFundingCy(null);
              app.setOtherFundingBy1(null);
              app.setOtherFundingBy1Base(null);
              app.setOtherFundingBy1Ooc(null);
            }
          }
          if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getCongressionalAddDetails()))
          {
            int cadIndex = 0;
            for (CongressionalAddDetail cad : project.getR2aExhibit().getCongressionalAddDetails())
            {
              Util.setAuditFieldsForNewObject(cad, budgesUserForAuditFields);
              cad.setDisplayOrder(Util.getInitDisplayOrder(cadIndex++));
              cad.setProject(project);
            }
          }
          if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getOtherProgramFundingSummaries()))
          {
            int opfsIndex = 0;
            for (OtherProgramFundingSummary opfs : project.getR2aExhibit().getOtherProgramFundingSummaries())
            {
              Util.setAuditFieldsForNewObject(opfs, budgesUserForAuditFields);
              opfs.setDisplayOrder(Util.getInitDisplayOrder(opfsIndex++));
              opfs.setProject(project);
            }
          }
          if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getMajorPerformers()))
          {
            int mpIndex = 0;
            for (MajorPerformer mp : project.getR2aExhibit().getMajorPerformers())
            {
              Util.setAuditFieldsForNewObject(mp, budgesUserForAuditFields);
              mp.setDisplayOrder(Util.getInitDisplayOrder(mpIndex++));
              mp.setProject(project);
            }
          }
          if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getJointFundings()))
          {
            int index = 0;
            for (JointFunding obj : project.getR2aExhibit().getJointFundings())
            {
              Util.setAuditFieldsForNewObject(obj, budgesUserForAuditFields);
              obj.setDisplayOrder(Util.getInitDisplayOrder(index++));
              obj.setProject(project);
            }
          }
        }

        R3Exhibit r3Exhibit = project.getR3Exhibit();
        if (r3Exhibit != null && (CollectionUtils.isNotEmpty(r3Exhibit.getCostCategoryGroups()) || r3Exhibit.getR3Remarks() != null))
        {
          Util.setAuditFieldsForNewObject(r3Exhibit, budgesUserForAuditFields);
          r3Exhibit.setProject(project);
          if (CollectionUtils.isNotEmpty(r3Exhibit.getCostCategoryGroups()))
          {
            int ccgIndex = 0;
            for (CostCategoryGroup ccg : r3Exhibit.getCostCategoryGroups())
            {
              Util.setAuditFieldsForNewObject(ccg, budgesUserForAuditFields);
              ccg.setDisplayOrder(Util.getInitDisplayOrder(ccgIndex++));
              ccg.setProject(project);
              CostCategoryGroupName ccgName = convertCostCategoryGroupName(ccg.getCostCategoryGroupName(), pe.getNumber(), peIndex);
              ccg.setCostCategoryGroupName(ccgName);
              if (CollectionUtils.isNotEmpty(ccg.getCostCategoryItems()))
              {
                int cciIndex = 0;
                for (CostCategoryItem cci : ccg.getCostCategoryItems())
                {
                  Util.setAuditFieldsForNewObject(cci, budgesUserForAuditFields);
                  cci.setDisplayOrder(Util.getInitDisplayOrder(cciIndex++));
                  cci.setCostCategoryGroup(ccg);
                  ContractMethod cm = convertContractMethod(cci.getContractMethod(), pe.getNumber(), peIndex);
                  ContractType ct = convertContractType(cci.getContractType(), pe.getNumber(), peIndex);
                  FundingVehicle fv = convertFundingVehicle(cci.getFundingVehicle(), pe.getNumber(), peIndex);
                  cci.setContractMethod(cm);
                  cci.setContractType(ct);
                  cci.setFundingVehicle(fv);
                }
              }
            }
          }
        }

        R4Exhibit r4Exhibit = project.getR4Exhibit();
        if (r4Exhibit != null && CollectionUtils.isNotEmpty(r4Exhibit.getScheduleProfiles()))
        {
          Util.setAuditFieldsForNewObject(r4Exhibit, budgesUserForAuditFields);
          int displayOrderIndex = 0;
          for (ScheduleProfile sp : r4Exhibit.getScheduleProfiles())
          {
            sp.setProject(project);
            sp.setDisplayOrder(Util.getInitDisplayOrder(displayOrderIndex++));
            Util.setAuditFieldsForNewObject(sp, budgesUserForAuditFields);
          }
        }
        R4aExhibit r4aExhibit = project.getR4aExhibit();
        if (r4aExhibit != null && CollectionUtils.isNotEmpty(r4aExhibit.getSubProjectSchedules()))
        {
          Util.setAuditFieldsForNewObject(r4aExhibit, budgesUserForAuditFields);
          r4aExhibit.setProject(project);

          // If there is only one schedule profile with no title, must be the old
          // style schedule details (with no schedule profile), so give it a title
          // since the db title field for the sub project table is required.
          if (r4aExhibit.getSubProjectSchedules().size() == 1)
          {
            SubProjectSchedule sps = r4aExhibit.getSubProjectSchedules().iterator().next();
            if (StringUtils.isEmpty(sps.getTitle()))
            {
              sps.setTitle(Constants.DEFAULT_SCHEDULE_PROFILE_TITLE);
            }
          }

          int displayOrderIndex = 0;
          for (SubProjectSchedule sps : r4aExhibit.getSubProjectSchedules())
          {
            sps.setProject(project);
            sps.setDisplayOrder(Util.getInitDisplayOrder(displayOrderIndex++));
            Util.setAuditFieldsForNewObject(sps, budgesUserForAuditFields);

            if (CollectionUtils.isNotEmpty(sps.getScheduleDetails()))
            {
              int displayOrderIndex2 = 0;
              for (ScheduleDetail sd : sps.getScheduleDetails())
              {
                sd.setSubProjectSchedule(sps);
                sd.setDisplayOrder(Util.getInitDisplayOrder(displayOrderIndex2++));
                Util.setAuditFieldsForNewObject(sd, budgesUserForAuditFields);
              }
            }
          }
        }
        R5Exhibit r5Exhibit = project.getR5Exhibit();
        if (r5Exhibit != null && r5Exhibit.getTerminationLiability() != null)
        {
          Util.setAuditFieldsForNewObject(r5Exhibit, budgesUserForAuditFields);
          r5Exhibit.setProject(project);
          r5Exhibit.getTerminationLiability().setProject(project);
        }
      }
    }
  }


  protected CostCategoryGroupName convertCostCategoryGroupName(CostCategoryGroupName ccgName, String peNumber, Integer peIndex)
  {
    if(ccgName != null) {
      CostCategoryGroupName dbccgName = getCcgnCache().get(ccgName.getName());
      if (dbccgName == null)
      {
        logError("Cost Category Group Name '" + ccgName.getName() + "' is invalid.", peNumber, peIndex);
        return null;
      }
      return dbccgName;
    }
    else {
      logError("No Cost Category Group Name provided.", peNumber, peIndex);
      return null;
    }
  }


  protected ContractMethod convertContractMethod(ContractMethod cm, String peNumber, Integer peIndex)
  {
    if (cm != null)
    {
      ContractMethod dbcm = getCmCache().get(cm.getName());
      if (dbcm == null)
      {
        logError("ContractMethod '" + cm.getName() + "' is invalid.", peNumber, peIndex);
      }
      else
      {
        return dbcm;
      }
    }
    return null;
  }


  protected ContractType convertContractType(ContractType ct, String peNumber, Integer peIndex)
  {
    if (ct != null)
    {
      ContractType dbct = getCtCache().get(ct.getName());
      if (dbct == null)
      {
        logError("ContractType '" + ct.getName() + "' is invalid.", peNumber, peIndex);
      }

      else
      {
        return dbct;
      }
    }
    return null;
  }


  protected FundingVehicle convertFundingVehicle(FundingVehicle fv, String peNumber, Integer peIndex)
  {
    if (fv != null)
    {
      FundingVehicle dbfv = getFvCache().get(fv.getName());
      if (dbfv == null)
      {
        logError("ContractMethod '" + fv.getName() + "' is invalid.", peNumber, peIndex);
      }
      else
      {
        return dbfv;
      }
    }
    return null;
  }


  protected BudgetActivity convertBudgetActivity(BudgetActivity baToCheck, ServiceAgency saToCheck, 
          String peNumber, Integer peIndex) {
      
      ServiceAgency sa = getSaCache().get(saToCheck.getName());
    
      if (sa == null) {
          logConversionCacheIssue(saToCheck.getName());
          return null;
      }
      
      for (BudgetActivity currentBa : sa.getRDTEBudgetActivities()){
          if (currentBa.equals(baToCheck)) {
              return currentBa;
          }
      }
    
      logError("Budget Activity with BudgetActivityTitle='" + baToCheck.getTitle() + "', BudgetActivityNumber='" + baToCheck.getNumber() + 
            "' and Appropriation with AppropriationName='" + baToCheck.getAppropriation().getName() + "' and AppropriationCode='" + 
            baToCheck.getAppropriation().getCode() + "' is invalid.", peNumber, peIndex);
      return null;
  }


  protected ServiceAgency convertServiceAgencyName(ServiceAgency saToCheck, String peNumber, Integer peIndex) {

    ServiceAgency sa = getSaCache().get(saToCheck.getName());
    if (sa == null){
      logError("ServiceAgencyName '" + saToCheck.getName() + "' is invalid.", peNumber, peIndex);
      logConversionCacheIssue(saToCheck.getName());
    }
    return sa;
  }

  public void process(LineItemList lil){
    if (lil != null) {
      int index = 1;
      for (LineItemWrapper liw : lil.getLineItems()){
        process(liw.getLineItem(), index++);
      }
    }
  }


  public void process(LineItem li, int liIndex){
    P40User user = p40UserForAuditFields;
    if (user == null){
      if (budgesUserForAuditFields != null)
      { // fetch from R2 username to allow P40 import in R2
        user = P40User.fetchWithLdapId(li.getObjectContext(), budgesUserForAuditFields.getUserLdapId());
      }
      else
      {
        log.warn("No user found for import");
      }
    }
    new P40XmlToJavaPostProcessor(this, li.getObjectContext()).process(user, li, liIndex);
  }


  private void logError(String message, String peNumber, Integer peIndex)
  {
    log.trace("pdoc39_595_" + message);
    if (peNumber != null && peIndex != null)
    {
      String peKey = peNumber + "." + peIndex;
      XmlRulesValidationMessage newMessage = new XmlRulesValidationMessage(peNumber, peIndex, message);
      errorList.add(newMessage.toString());
      List<String> peErrors = errorListMap.get(peKey);
      if (peErrors == null)
      {
        peErrors = new ArrayList<String>();
        errorListMap.put(peKey, peErrors);
      }
      peErrors.add(newMessage.toString());
    }
    else
    {
      errorList.add(message);
    }
    log.trace("pdoc39_596_" + errorList.toString());
  }

  protected void logError(String message) {
    logError(message, null, null);
  }

  public Map<String, List<String>> getErrorListMap() {
    return errorListMap;
  }

  public void setErrorListMap(Map<String, List<String>> errorListMap) {
    this.errorListMap = errorListMap;
  }
  
  //CXE-6607
  private Date getSubmissionDate(ProgramElement pe) throws SubmissionDateProcessorException{
      SubmissionDateProcessor sdp = (SubmissionDateProcessor) SubmissionDateProcessorFactory.getSubmissionDateProcessor();
      return sdp.getSubmissionDate(pe.getBudgetCycle(), pe.getBudgetYear()).getDate();
  }

  private void logConversionCacheIssue(String serviceAgencyName) {
      if (log.isDebugEnabled()) {
          StringBuilder sb = new StringBuilder("logConversionCacheIssue: service agency cache - ");
          for (ServiceAgency value : getSaCache().values()) {
              sb.append(value.getName() + " | ");
          }
          if (sb.toString().contains(serviceAgencyName)) {
              log.debug("logConversionCacheIssue:: service agency name: " + serviceAgencyName + " found within cached service agencies");
          }
          else {
              log.debug("logConversionCacheIssue:: service agency name: " + serviceAgencyName + 
                  " NOT found with cached service agencies: " + sb.toString());
          }
      }
  }

  

}
