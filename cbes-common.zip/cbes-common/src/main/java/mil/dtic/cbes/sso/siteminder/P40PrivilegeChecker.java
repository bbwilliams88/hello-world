package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;

import mil.dtic.cbes.p40.vo.LineItem;

//Convenience class that just has privilege-checker methods
//Used by tapestry pages
public class P40PrivilegeChecker implements Serializable
{
  private static final long serialVersionUID = -7730804872283223744L;

  private final P40UserCredentials creds;

  public P40PrivilegeChecker(P40UserCredentials creds) {
    this.creds = creds;
  }

  public boolean showModifyingUsers() {
    return creds.checkPrivilege(Privilege.SHOW_MODIFYING_USER);
  }

  public boolean showTestLiBox() {
    return creds.checkPrivilege(Privilege.SHOW_TEST_PE);
  }

  public boolean showSetWriteable() {
    return creds.checkPrivilege(Privilege.EXHIBITLIST_SHOW_SET_WRITEABLE);
  }

  public boolean showAdminTools() {
    return creds.checkPrivilege(Privilege.SHOW_ADMIN_TOOLS);
  }

  public boolean showEditAnnouncements() {
    return creds.checkPrivilege(Privilege.EDIT_ANNOUNCEMENTS);
  }

  public boolean showEditWhatsNew() {
    return creds.checkPrivilege(Privilege.EDIT_WHATS_NEW);
  }

  public boolean showEditHelp() {
    return creds.checkPrivilege(Privilege.EDIT_HELP);
  }

  public boolean showLdapUpdate() {
    return creds.checkPrivilege(Privilege.SHOW_LDAP_UPDATE_BUTTON);
  }

  public boolean showUserDates() {
    return creds.checkPrivilege(Privilege.SHOW_USER_DATES);
  }

  public boolean showLiEditButtons(LineItem li) {
    return creds.saveLiAllowed(li);
  }

  public boolean showUnlockAlways() {
    return creds.checkPrivilege(Privilege.ALWAYS_SHOW_UNLOCK);
  }

  public boolean showLiDeleteButtons(LineItem li) {
    //disabled for performance reasons
    //return creds.saveLiAllowed(pe);
    return true;
  }

  public boolean showHostInfo() {
    return creds.checkPrivilege(Privilege.VIEW_SERVER_INFO);
  }

  public boolean showCreateLi() {
    return creds.createLiAllowed();
  }

  public boolean showCopyLi() {
    return creds.createLiAllowed();
  }

  public boolean showImportLi() {
    return creds.createLiAllowed();
  }

  public boolean showR1Link() {
    return creds.checkPrivilege(Privilege.R1PAGE);
  }

  public boolean showAdminViewFiles() {
    return creds.checkPrivilege(Privilege.ADMIN_VIEW_FILES);
  }
}
