/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBAcronymDoc extends JBDefaultUserSuppliedPart
{
  public JBAcronymDoc()
  {
    setFileSetting(FileSetting.ACRONYM_DOC); 
    setTitle(fileSetting.getTitle());    
    setFixedTitle(true); // title cannot be changed by user
  } 

}
