package mil.dtic.cbes.exceptions;

public class ApiRequestException extends Exception
{
    private static final long serialVersionUID = 1L;

    public ApiRequestException() { super(); }
    public ApiRequestException(String message) { super(message); }
    public ApiRequestException(String message, Throwable cause) { super(message, cause); }
    public ApiRequestException(Throwable cause) { super(cause); }
}
