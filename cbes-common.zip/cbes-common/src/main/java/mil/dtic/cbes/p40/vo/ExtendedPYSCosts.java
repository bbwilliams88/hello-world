package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

import mil.dtic.cbes.p40.vo.auto._ExtendedPYSCosts;
import mil.dtic.utility.BigDecimalUtil;

/**
 *
 */
public class ExtendedPYSCosts extends _ExtendedPYSCosts
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.
    
    @Override
    public BigDecimal getPy20()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy20());
    }
    @Override
    public BigDecimal getPy19()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy19());
    }
    @Override
    public BigDecimal getPy18()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy18());
    }
    @Override
    public BigDecimal getPy17()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy17());
    }
    @Override
    public BigDecimal getPy16()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy16());
    }
    @Override
    public BigDecimal getPy15()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy15());
    }
    @Override
    public BigDecimal getPy14()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy14());
    }
    @Override
    public BigDecimal getPy13()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy13());
    }
    @Override
    public BigDecimal getPy12()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy12());
    }
    @Override
    public BigDecimal getPy11()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy11());
    }
    @Override
    public BigDecimal getPy10()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy10());
    }
    @Override
    public BigDecimal getPy9()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy9());
    }
    @Override
    public BigDecimal getPy8()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy8());
    }
    @Override
    public BigDecimal getPy7()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy7());
    }
    @Override
    public BigDecimal getPy6()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy6());
    }
    @Override
    public BigDecimal getPy5()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy5());
    }
    @Override
    public BigDecimal getPy4()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy4());
    }
    @Override
    public BigDecimal getPy3()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy3());
    }
    @Override
    public BigDecimal getPy2()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPy2());
    }
    
    @Override
    public boolean isEmpty()
    {
        return getPy20()          == null &&
               getPy19()          == null &&
               getPy18()          == null &&
               getPy17()          == null &&
               getPy16()          == null &&
               getPy15()          == null &&
               getPy14()          == null &&
               getPy13()          == null &&
               getPy12()          == null &&
               getPy11()          == null &&
               getPy10()          == null &&
               getPy9()           == null &&
               getPy8()           == null &&
               getPy7()           == null &&
               getPy6()           == null &&
               getPy5()           == null &&
               getPy4()           == null &&
               getPy3()           == null &&
               getPy2()           == null &&
               getPriorYears()    == null &&
               getPriorYear()     == null &&
               getCurrentYear()   == null &&
               getBy1Base()       == null &&
               getBy1Ooc()        == null &&
               getBy1()           == null &&
               getBy2()           == null &&
               getBy3()           == null &&
               getBy4()           == null &&
               getBy5()           == null &&
               getToComplete()    == null &&
               getTotal()         == null &&
               isContinuing()     == false;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_isPy20()
    {
        return getPy20() != null;
    }    
    public boolean jibx_isPy19()
    {
        return getPy19() != null;
    }
    public boolean jibx_isPy18()
    {
        return getPy18() != null;
    }
    public boolean jibx_isPy17()
    {
        return getPy17() != null;
    }
    public boolean jibx_isPy16()
    {
        return getPy16() != null;
    }
    public boolean jibx_isPy15()
    {
        return getPy15() != null;
    }
    public boolean jibx_isPy14()
    {
        return getPy14() != null;
    }
    public boolean jibx_isPy13()
    {
        return getPy13() != null;
    }
    public boolean jibx_isPy12()
    {
        return getPy12() != null;
    }
    public boolean jibx_isPy11()
    {
        return getPy11() != null;
    }
    public boolean jibx_isPy10()
    {
        return getPy10() != null;
    }
    public boolean jibx_isPy9()
    {
        return getPy9() != null;
    }
    public boolean jibx_isPy8()
    {
        return getPy8() != null;
    }
    public boolean jibx_isPy7()
    {
        return getPy7() != null;
    }
    public boolean jibx_isPy6()
    {
        return getPy6() != null;
    }
    public boolean jibx_isPy5()
    {
        return getPy5() != null;
    }
    public boolean jibx_isPy4()
    {
        return getPy4() != null;
    }
    public boolean jibx_isPy3()
    {
        return getPy3() != null;
    }    
    public boolean jibx_isPy2()
    {
        return getPy2() != null;
    }


    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
