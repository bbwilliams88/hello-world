package mil.dtic.cbes.p40.vo;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;

import org.apache.cayenne.util.EqualsBuilder;
import org.apache.cayenne.util.HashCodeBuilder;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.auto._ModsManufacturer;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ModsManufacturer extends _ModsManufacturer implements HasDisplayOrder, Equivalence<ModsManufacturer>
{
    private static final long serialVersionUID = 1L;

    private static final Logger log = CbesLogFactory.getLog(ModsManufacturer.class);

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
    }

    public boolean jibx_hasContractDates()
    {
        return getDateContractedPriorYears() != null || // NOSONAR
               getDateContractedPy()         != null ||
               getDateContractedCy()         != null ||
               getDateContractedBy1()        != null ||
               getDateContractedBy1Base()    != null ||
               getDateContractedBy1Ooc()     != null ||
               getDateContractedBy2()        != null ||
               getDateContractedBy3()        != null ||
               getDateContractedBy4()        != null ||
               getDateContractedBy5()        != null;
    }

    public boolean isOutYearContractDatesPresent()
    {
        return getDateContractedBy2()        != null ||
               getDateContractedBy3()        != null ||
               getDateContractedBy4()        != null ||
               getDateContractedBy5()        != null;
    }

    public boolean jibx_hasDateContractedPy()
    {
        return getDateContractedPy() != null;
    }

    public boolean jibx_hasDateContractedCy()
    {
        return getDateContractedCy() != null;
    }

    public boolean jibx_hasDateContractedBy1()
    {
        return getDateContractedBy1() != null;
    }

    public boolean jibx_hasDateContractedBy2()
    {
        return getDateContractedBy2() != null;
    }

    public boolean jibx_hasDateContractedBy3()
    {
        return getDateContractedBy3() != null;
    }

    public boolean jibx_hasDateContractedBy4()
    {
        return getDateContractedBy4() != null;
    }

    public boolean jibx_hasDateContractedBy5()
    {
        return getDateContractedBy5() != null;
    }

    public boolean jibx_hasDeliveryDates()
    {
        return getDateDeliveredPriorYears() != null || // NOSONAR
               getDateDeliveredPy()         != null ||
               getDateDeliveredCy()         != null ||
               getDateDeliveredBy1()        != null ||
               getDateDeliveredBy1Base()    != null ||
               getDateDeliveredBy1Ooc()     != null ||
               getDateDeliveredBy2()        != null ||
               getDateDeliveredBy3()        != null ||
               getDateDeliveredBy4()        != null ||
               getDateDeliveredBy5()        != null;
    }

    public boolean isOutYearDeliveryDatesPresent()
    {
        return getDateDeliveredBy2()        != null ||
               getDateDeliveredBy3()        != null ||
               getDateDeliveredBy4()        != null ||
               getDateDeliveredBy5()        != null;
    }

    public boolean jibx_hasDateDeliveredPy()
    {
        return getDateDeliveredPy() != null;
    }

    public boolean jibx_hasDateDeliveredCy()
    {
        return getDateDeliveredCy() != null;
    }

    public boolean jibx_hasDateDeliveredBy1()
    {
        return getDateDeliveredBy1() != null;
    }

    public boolean jibx_hasDateDeliveredBy2()
    {
        return getDateDeliveredBy2() != null;
    }

    public boolean jibx_hasDateDeliveredBy3()
    {
        return getDateDeliveredBy3() != null;
    }

    public boolean jibx_hasDateDeliveredBy4()
    {
        return getDateDeliveredBy4() != null;
    }

    public boolean jibx_hasDateDeliveredBy5()
    {
        return getDateDeliveredBy5() != null;
    }

    public boolean jibx_hasAdminLeadTime()
    {
        return getAdminLeadTime() != null;
    }

    public boolean jibx_hasProductionLeadTime()
    {
        return getProductionLeadTime() != null;
    }

    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getName()));
        builder.append(toLowerAndTrim(getLocation()));
        builder.append(getProductionLeadTime());
        builder.append(getAdminLeadTime());
        builder.append(getModsItem());

        return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(ModsManufacturer otherManufacturer)
    {
        if (this == otherManufacturer)
            return true;
        else if (otherManufacturer == null)
            return false;
        else if (getClass() != otherManufacturer.getClass())
            return false;

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getName()), toLowerAndTrim(otherManufacturer.getName()));
        builder.append(toLowerAndTrim(getLocation()), toLowerAndTrim(otherManufacturer.getLocation()));
        builder.append(getProductionLeadTime(), otherManufacturer.getProductionLeadTime());
        builder.append(getAdminLeadTime(), otherManufacturer.getAdminLeadTime());
        builder.append(getModsItem(), otherManufacturer.getModsItem());

        return builder.isEquals();
    }

    /**
     * Method which will shift this exhibit and it's information back when it is copied into a new Fiscal Year.
     * @param years the number of Fiscal Years to shift, almost always one.
     */
    public void shiftForwardInTime(int years)
    {
      try
      {
        for (int i = 0; i < years; i++){
          for (int j = 0; j < Util.getFyModsManufacturerList().length - 1; j++){
            shiftContractAndDeliveryDatesPlusFootnotes(Util.getFyModsManufacturerList()[j+1], Util.getFyModsManufacturerList()[j]);
          }
        }  

        //Null out final Fiscal Year after shift
        ModsManufacturer.class.getMethod("setDateContracted" + Util.getFyModsManufacturerList()[Util.getFyModsManufacturerList().length - 1], Date.class).invoke(this, new Object[]{null});
        ModsManufacturer.class.getMethod("setDateContracted" + Util.getFyModsManufacturerList()[Util.getFyModsManufacturerList().length - 1] + "Footnote", String.class).invoke(this, new Object[]{null});
        ModsManufacturer.class.getMethod("setDateDelivered" + Util.getFyModsManufacturerList()[Util.getFyModsManufacturerList().length - 1], Date.class).invoke(this, new Object[]{null});
        ModsManufacturer.class.getMethod("setDateDelivered" + Util.getFyModsManufacturerList()[Util.getFyModsManufacturerList().length - 1] + "Footnote", String.class).invoke(this, new Object[]{null});
      }
      catch (NoSuchMethodException e)
      {
        log.fatal("Method not found in ModsManufacturer object. This should never happen.", e);
      }
      catch (InvocationTargetException e)
      {
        log.error("An exception was thrown while executing method", e.getCause());
      }
      catch (IllegalAccessException e)
      {
        log.fatal("An illegal access execption was thrown when executing method on the ModsManufacturer object. This should never happen", e);
      }
    }
    /**
     * Set up getter and setters to invoke for the four sets of method calls: DateContracted and its footnote and DateDelivered and its footnote.
     * Pass the result of the get call from the next year to the set parameter of the last year, moving it back in time one year.
     * @param nextFy The Fiscal Year it's being copied from.
     * @param lastFy The Fiscal Year it's being copied to.
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    private void shiftContractAndDeliveryDatesPlusFootnotes(String nextFy, String lastFy) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException
    {
      //Get Contract Date from next year.
      Date date = (Date) ModsManufacturer.class.getMethod("getDateContracted" + nextFy, (Class<?>[]) null).invoke(this);
      //Set Contract Date to last year.
      ModsManufacturer.class.getMethod("setDateContracted" + lastFy, Date.class).invoke(this, date);

      //Repeat for footnote.
      String footnote = (String) ModsManufacturer.class.getMethod("getDateContracted" + nextFy + "Footnote", (Class<?>[]) null).invoke(this);
      ModsManufacturer.class.getMethod("setDateContracted" + lastFy + "Footnote", String.class).invoke(this, footnote);

      //Now do the same for the Delivery Date.
      date = (Date) ModsManufacturer.class.getMethod("getDateDelivered" + nextFy, (Class<?>[]) null).invoke(this);
      ModsManufacturer.class.getMethod("setDateDelivered" + lastFy, Date.class).invoke(this, date);

      //Repeat for footnote.
      footnote = (String) ModsManufacturer.class.getMethod("getDateDelivered" + nextFy + "Footnote", (Class<?>[]) null).invoke(this);
      ModsManufacturer.class.getMethod("setDateDelivered" + lastFy + "Footnote", String.class).invoke(this, footnote);
    }
}
