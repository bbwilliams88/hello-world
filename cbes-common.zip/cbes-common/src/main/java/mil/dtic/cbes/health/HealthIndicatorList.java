/*
 * $Id: HealthIndicatorList.java 34525 2010-03-05 11:44:24Z bhicks $
 */
package mil.dtic.cbes.health;

import java.util.Date;

public class HealthIndicatorList
{
  public static final String USER_LDAP_ID = "userLdapId";
  public static final String ROLE = "role";
  private String userLdapId;
  private String role;
  private Date lastAccessedTime;
  private String sessionId; // only used in AdminToolsPage

  private boolean dbRowReadOK;
  private boolean dbRowUpdateOK;
  private boolean dbTriggerOK;
  private boolean commandLineRMIOK;
  private boolean diskSpaceOK;
  private boolean partitionUploadReadOK;
  private boolean partitionUploadWriteOK;
  private boolean partitionSandboxReadOK;
  private boolean partitionSandboxWriteOK;
  private boolean partitionTmpReadOK;
  private boolean partitionTmpWriteOK;
  private boolean partitionJBossReadOK;
  private boolean partitionJBossWriteOK;
  private boolean partitionIOReadOK;
  private boolean partitionIOWriteOK;
  private boolean virusGreenOK;
  private boolean virusRedOK;
  private boolean ldapReadOK;
  private boolean overallOK;

  private String dbRowReadDetail;
  private String dbRowUpdateDetail;
  private String dbTriggerDetail;
  private String commandLineRMIDetail;
  private String diskSpaceDetail;
  private String partitionUploadReadDetail;
  private String partitionUploadWriteDetail;
  private String partitionSandboxReadDetail;
  private String partitionSandboxWriteDetail;
  private String partitionTmpReadDetail;
  private String partitionTmpWriteDetail;
  private String partitionJBossReadDetail;
  private String partitionJBossWriteDetail;
  private String partitionIOReadDetail;
  private String partitionIOWriteDetail;
  private String virusGreenDetail;
  private String virusRedDetail;
  private String ldapReadDetail;
  private String overallDetail;

  private Date dbRowReadTimestamp;
  private Date dbRowUpdateTimestamp;
  private Date dbTriggerTimestamp;
  private Date commandLineRMITimestamp;
  private Date diskSpaceTimestamp;
  private Date partitionUploadReadTimestamp;
  private Date partitionUploadWriteTimestamp;
  private Date partitionSandboxReadTimestamp;
  private Date partitionSandboxWriteTimestamp;
  private Date partitionTmpReadTimestamp;
  private Date partitionTmpWriteTimestamp;
  private Date partitionJBossReadTimestamp;
  private Date partitionJBossWriteTimestamp;
  private Date partitionIOReadTimestamp;
  private Date partitionIOWriteTimestamp;
  private Date virusGreenTimestamp;
  private Date virusRedTimestamp;
  private Date ldapReadTimestamp;
  private Date overallTimestamp;

  private float dbRowReadReliability = 0.5f;
  private float dbRowUpdateReliability = 0.5f;
  private float dbTriggerReliability = 0.5f;
  private float commandLineRMIReliability = 0.5f;
  private float diskSpaceReliability = 0.5f;
  private float partitionUploadReadReliability = 0.5f;
  private float partitionUploadWriteReliability = 0.5f;
  private float partitionSandboxReadReliability = 0.5f;
  private float partitionSandboxWriteReliability = 0.5f;
  private float partitionTmpReadReliability = 0.5f;
  private float partitionTmpWriteReliability = 0.5f;
  private float partitionJBossReadReliability = 0.5f;
  private float partitionJBossWriteReliability = 0.5f;
  private float partitionIOReadReliability = 0.5f;
  private float partitionIOWriteReliability = 0.5f;
  private float virusGreenReliability = 0.5f;
  private float virusRedReliability = 0.5f;
  private float ldapReadReliability = 0.5f;
  private float overallReliability = 0.5f;


  public static HealthIndicatorList createTransient()
  {
    HealthIndicatorList hil = new HealthIndicatorList();
    return hil;
  }


  public String getUserLdapId()
  {
    return userLdapId;
  }


  public void setUserLdapId(String userLdapId)
  {
    this.userLdapId = userLdapId;
  }


  /** the cached one r2 group */
  public String getRole()
  {
    return role;
  }


  public void setRole(String role)
  {
    this.role = role;
  }


  public Date getLastAccessedTime()
  {
    return lastAccessedTime;
  }


  public void setLastAccessedTime(Date lastAccessTime)
  {
    this.lastAccessedTime = lastAccessTime;
  }


  public String getSessionId()
  {
    return sessionId;
  }


  public void setSessionId(String sessionId)
  {
    this.sessionId = sessionId;
  }


  public void setDbRowReadOK(boolean dbRowReadOK)
  {
    this.dbRowReadOK = dbRowReadOK;
  }


  public boolean getDbRowReadOK()
  {
    return dbRowReadOK;
  }


  public void setDbRowUpdateOK(boolean dbRowUpdateOK)
  {
    this.dbRowUpdateOK = dbRowUpdateOK;
  }


  public boolean getDbRowUpdateOK()
  {
    return dbRowUpdateOK;
  }


  public void setDbTriggerOK(boolean dbTriggerOK)
  {
    this.dbTriggerOK = dbTriggerOK;
  }


  public boolean getDbTriggerOK()
  {
    return dbTriggerOK;
  }


  public void setCommandLineRMIOK(boolean commandLineRMIOK)
  {
    this.commandLineRMIOK = commandLineRMIOK;
  }


  public boolean getCommandLineRMIOK()
  {
    return commandLineRMIOK;
  }


  public void setDiskSpaceOK(boolean diskSpaceOK)
  {
    this.diskSpaceOK = diskSpaceOK;
  }


  public boolean getDiskSpaceOK()
  {
    return diskSpaceOK;
  }


  public void setPartitionUploadReadOK(boolean partitionUploadReadOK)
  {
    this.partitionUploadReadOK = partitionUploadReadOK;
  }


  public boolean getPartitionUploadReadOK()
  {
    return partitionUploadReadOK;
  }


  public void setPartitionUploadWriteOK(boolean partitionUploadWriteOK)
  {
    this.partitionUploadWriteOK = partitionUploadWriteOK;
  }


  public boolean getPartitionUploadWriteOK()
  {
    return partitionUploadWriteOK;
  }


  public void setPartitionSandboxReadOK(boolean partitionSandboxReadOK)
  {
    this.partitionSandboxReadOK = partitionSandboxReadOK;
  }


  public boolean getPartitionSandboxReadOK()
  {
    return partitionSandboxReadOK;
  }


  public void setPartitionSandboxWriteOK(boolean partitionSandboxWriteOK)
  {
    this.partitionSandboxWriteOK = partitionSandboxWriteOK;
  }


  public boolean getPartitionSandboxWriteOK()
  {
    return partitionSandboxWriteOK;
  }


  public void setPartitionTmpReadOK(boolean partitionTmpReadOK)
  {
    this.partitionTmpReadOK = partitionTmpReadOK;
  }


  public boolean getPartitionTmpReadOK()
  {
    return partitionTmpReadOK;
  }


  public void setPartitionTmpWriteOK(boolean partitionTmpWriteOK)
  {
    this.partitionTmpWriteOK = partitionTmpWriteOK;
  }


  public boolean getPartitionTmpWriteOK()
  {
    return partitionTmpWriteOK;
  }


  public void setPartitionJBossReadOK(boolean partitionJBossReadOK)
  {
    this.partitionJBossReadOK = partitionJBossReadOK;
  }


  public boolean getPartitionJBossReadOK()
  {
    return partitionJBossReadOK;
  }


  public void setPartitionJBossWriteOK(boolean partitionJBossWriteOK)
  {
    this.partitionJBossWriteOK = partitionJBossWriteOK;
  }


  public boolean getPartitionJBossWriteOK()
  {
    return partitionJBossWriteOK;
  }


  public void setPartitionIOReadOK(boolean partitionIOReadOK)
  {
    this.partitionIOReadOK = partitionIOReadOK;
  }


  public boolean getPartitionIOReadOK()
  {
    return partitionIOReadOK;
  }


  public void setPartitionIOWriteOK(boolean partitionIOWriteOK)
  {
    this.partitionIOWriteOK = partitionIOWriteOK;
  }


  public boolean getPartitionIOWriteOK()
  {
    return partitionIOWriteOK;
  }


  public void setVirusGreenOK(boolean virusGreenOK)
  {
    this.virusGreenOK = virusGreenOK;
  }


  public boolean getVirusGreenOK()
  {
    return virusGreenOK;
  }


  public void setVirusRedOK(boolean virusRedOK)
  {
    this.virusRedOK = virusRedOK;
  }


  public boolean getVirusRedOK()
  {
    return virusRedOK;
  }


  public void setLdapReadOK(boolean ldapReadOK)
  {
    this.ldapReadOK = ldapReadOK;
  }


  public boolean getLdapReadOK()
  {
    return ldapReadOK;
  }


  public void setOverallOK(boolean overallOK)
  {
    this.overallOK = overallOK;
  }


  public boolean getOverallOK()
  {
    return overallOK;
  }


  public void setDbRowReadTimestamp(Date dbRowReadTimestamp)
  {
    this.dbRowReadTimestamp = dbRowReadTimestamp;
  }


  public Date getDbRowReadTimestamp()
  {
    return dbRowReadTimestamp;
  }


  public void setDbRowUpdateTimestamp(Date dbRowUpdateTimestamp)
  {
    this.dbRowUpdateTimestamp = dbRowUpdateTimestamp;
  }


  public Date getDbRowUpdateTimestamp()
  {
    return dbRowUpdateTimestamp;
  }


  public void setDbTriggerTimestamp(Date dbTriggerTimestamp)
  {
    this.dbTriggerTimestamp = dbTriggerTimestamp;
  }


  public Date getDbTriggerTimestamp()
  {
    return dbTriggerTimestamp;
  }


  public void setCommandLineRMITimestamp(Date commandLineRMITimestamp)
  {
    this.commandLineRMITimestamp = commandLineRMITimestamp;
  }


  public Date getCommandLineRMITimestamp()
  {
    return commandLineRMITimestamp;
  }


  public void setDiskSpaceTimestamp(Date diskSpaceTimestamp)
  {
    this.diskSpaceTimestamp = diskSpaceTimestamp;
  }


  public Date getDiskSpaceTimestamp()
  {
    return diskSpaceTimestamp;
  }


  public void setPartitionUploadReadTimestamp(Date partitionUploadReadTimestamp)
  {
    this.partitionUploadReadTimestamp = partitionUploadReadTimestamp;
  }


  public Date getPartitionUploadReadTimestamp()
  {
    return partitionUploadReadTimestamp;
  }


  public void setPartitionUploadWriteTimestamp(Date partitionUploadWriteTimestamp)
  {
    this.partitionUploadWriteTimestamp = partitionUploadWriteTimestamp;
  }


  public Date getPartitionUploadWriteTimestamp()
  {
    return partitionUploadWriteTimestamp;
  }


  public void setPartitionSandboxReadTimestamp(Date partitionSandboxReadTimestamp)
  {
    this.partitionSandboxReadTimestamp = partitionSandboxReadTimestamp;
  }


  public Date getPartitionSandboxReadTimestamp()
  {
    return partitionSandboxReadTimestamp;
  }


  public void setPartitionSandboxWriteTimestamp(Date partitionSandboxWriteTimestamp)
  {
    this.partitionSandboxWriteTimestamp = partitionSandboxWriteTimestamp;
  }


  public Date getPartitionSandboxWriteTimestamp()
  {
    return partitionSandboxWriteTimestamp;
  }


  public void setPartitionTmpReadTimestamp(Date partitionTmpReadTimestamp)
  {
    this.partitionTmpReadTimestamp = partitionTmpReadTimestamp;
  }


  public Date getPartitionTmpReadTimestamp()
  {
    return partitionTmpReadTimestamp;
  }


  public void setPartitionTmpWriteTimestamp(Date partitionTmpWriteTimestamp)
  {
    this.partitionTmpWriteTimestamp = partitionTmpWriteTimestamp;
  }


  public Date getPartitionTmpWriteTimestamp()
  {
    return partitionTmpWriteTimestamp;
  }


  public void setPartitionJBossReadTimestamp(Date partitionJBossReadTimestamp)
  {
    this.partitionJBossReadTimestamp = partitionJBossReadTimestamp;
  }


  public Date getPartitionJBossReadTimestamp()
  {
    return partitionJBossReadTimestamp;
  }


  public void setPartitionJBossWriteTimestamp(Date partitionJBossWriteTimestamp)
  {
    this.partitionJBossWriteTimestamp = partitionJBossWriteTimestamp;
  }


  public Date getPartitionJBossWriteTimestamp()
  {
    return partitionJBossWriteTimestamp;
  }


  public void setPartitionIOReadTimestamp(Date partitionIOReadTimestamp)
  {
    this.partitionIOReadTimestamp = partitionIOReadTimestamp;
  }


  public Date getPartitionIOReadTimestamp()
  {
    return partitionIOReadTimestamp;
  }


  public void setPartitionIOWriteTimestamp(Date partitionIOWriteTimestamp)
  {
    this.partitionIOWriteTimestamp = partitionIOWriteTimestamp;
  }


  public Date getPartitionIOWriteTimestamp()
  {
    return partitionIOWriteTimestamp;
  }


  public void setVirusGreenTimestamp(Date virusGreenTimestamp)
  {
    this.virusGreenTimestamp = virusGreenTimestamp;
  }


  public Date getVirusGreenTimestamp()
  {
    return virusGreenTimestamp;
  }


  public void setVirusRedTimestamp(Date virusRedTimestamp)
  {
    this.virusRedTimestamp = virusRedTimestamp;
  }


  public Date getVirusRedTimestamp()
  {
    return virusRedTimestamp;
  }


  public void setLdapReadTimestamp(Date ldapReadTimestamp)
  {
    this.ldapReadTimestamp = ldapReadTimestamp;
  }


  public Date getLdapReadTimestamp()
  {
    return ldapReadTimestamp;
  }


  public void setOverallTimestamp(Date overallTimestamp)
  {
    this.overallTimestamp = overallTimestamp;
  }


  public Date getOverallTimestamp()
  {
    return overallTimestamp;
  }


  public void setDbRowReadReliability(float dbRowReadReliability)
  {
    this.dbRowReadReliability = dbRowReadReliability;
  }


  public float getDbRowReadReliability()
  {
    return dbRowReadReliability;
  }


  public void setDbRowUpdateReliability(float dbRowUpdateReliability)
  {
    this.dbRowUpdateReliability = dbRowUpdateReliability;
  }


  public float getDbRowUpdateReliability()
  {
    return dbRowUpdateReliability;
  }


  public void setDbTriggerReliability(float dbTriggerReliability)
  {
    this.dbTriggerReliability = dbTriggerReliability;
  }


  public float getDbTriggerReliability()
  {
    return dbTriggerReliability;
  }


  public void setCommandLineRMIReliability(float commandLineRMIReliability)
  {
    this.commandLineRMIReliability = commandLineRMIReliability;
  }


  public float getCommandLineRMIReliability()
  {
    return commandLineRMIReliability;
  }


  public void setDiskSpaceReliability(float diskSpaceReliability)
  {
    this.diskSpaceReliability = diskSpaceReliability;
  }


  public float getDiskSpaceReliability()
  {
    return diskSpaceReliability;
  }


  public void setPartitionUploadReadReliability(float partitionUploadReadReliability)
  {
    this.partitionUploadReadReliability = partitionUploadReadReliability;
  }


  public float getPartitionUploadReadReliability()
  {
    return partitionUploadReadReliability;
  }


  public void setPartitionUploadWriteReliability(float partitionUploadWriteReliability)
  {
    this.partitionUploadWriteReliability = partitionUploadWriteReliability;
  }


  public float getPartitionUploadWriteReliability()
  {
    return partitionUploadWriteReliability;
  }


  public void setPartitionSandboxReadReliability(float partitionSandboxReadReliability)
  {
    this.partitionSandboxReadReliability = partitionSandboxReadReliability;
  }


  public float getPartitionSandboxReadReliability()
  {
    return partitionSandboxReadReliability;
  }


  public void setPartitionSandboxWriteReliability(float partitionSandboxWriteReliability)
  {
    this.partitionSandboxWriteReliability = partitionSandboxWriteReliability;
  }


  public float getPartitionSandboxWriteReliability()
  {
    return partitionSandboxWriteReliability;
  }


  public void setPartitionTmpReadReliability(float partitionTmpReadReliability)
  {
    this.partitionTmpReadReliability = partitionTmpReadReliability;
  }


  public float getPartitionTmpReadReliability()
  {
    return partitionTmpReadReliability;
  }


  public void setPartitionTmpWriteReliability(float partitionTmpWriteReliability)
  {
    this.partitionTmpWriteReliability = partitionTmpWriteReliability;
  }


  public float getPartitionTmpWriteReliability()
  {
    return partitionTmpWriteReliability;
  }


  public void setPartitionIOReadReliability(float partitionIOReadReliability)
  {
    this.partitionIOReadReliability = partitionIOReadReliability;
  }


  public float getPartitionIOReadReliability()
  {
    return partitionIOReadReliability;
  }


  public void setPartitionIOWriteReliability(float partitionIOWriteReliability)
  {
    this.partitionIOWriteReliability = partitionIOWriteReliability;
  }


  public float getPartitionIOWriteReliability()
  {
    return partitionIOWriteReliability;
  }


  public void setVirusGreenReliability(float virusGreenReliability)
  {
    this.virusGreenReliability = virusGreenReliability;
  }


  public float getVirusGreenReliability()
  {
    return virusGreenReliability;
  }


  public void setVirusRedReliability(float virusRedReliability)
  {
    this.virusRedReliability = virusRedReliability;
  }


  public float getVirusRedReliability()
  {
    return virusRedReliability;
  }


  public void setLdapReadReliability(float ldapReadReliability)
  {
    this.ldapReadReliability = ldapReadReliability;
  }


  public float getLdapReadReliability()
  {
    return ldapReadReliability;
  }


  public void setOverallReliability(float overallReliability)
  {
    this.overallReliability = overallReliability;
  }


  public float getOverallReliability()
  {
    return overallReliability;
  }


  public void setDbRowReadDetail(String dbRowReadDetail)
  {
    this.dbRowReadDetail = dbRowReadDetail;
  }


  public String getDbRowReadDetail()
  {
    return dbRowReadDetail;
  }


  public void setDbRowUpdateDetail(String dbRowUpdateDetail)
  {
    this.dbRowUpdateDetail = dbRowUpdateDetail;
  }


  public String getDbRowUpdateDetail()
  {
    return dbRowUpdateDetail;
  }


  public void setDbTriggerDetail(String dbTriggerDetail)
  {
    this.dbTriggerDetail = dbTriggerDetail;
  }


  public String getDbTriggerDetail()
  {
    return dbTriggerDetail;
  }


  public void setCommandLineRMIDetail(String commandLineRMIDetail)
  {
    this.commandLineRMIDetail = commandLineRMIDetail;
  }


  public String getCommandLineRMIDetail()
  {
    return commandLineRMIDetail;
  }


  public void setDiskSpaceDetail(String diskSpaceDetail)
  {
    this.diskSpaceDetail = diskSpaceDetail;
  }


  public String getDiskSpaceDetail()
  {
    return diskSpaceDetail;
  }


  public void setPartitionUploadReadDetail(String partitionUploadReadDetail)
  {
    this.partitionUploadReadDetail = partitionUploadReadDetail;
  }


  public String getPartitionUploadReadDetail()
  {
    return partitionUploadReadDetail;
  }


  public void setPartitionUploadWriteDetail(String partitionUploadWriteDetail)
  {
    this.partitionUploadWriteDetail = partitionUploadWriteDetail;
  }


  public String getPartitionUploadWriteDetail()
  {
    return partitionUploadWriteDetail;
  }


  public void setPartitionSandboxReadDetail(String partitionSandboxReadDetail)
  {
    this.partitionSandboxReadDetail = partitionSandboxReadDetail;
  }


  public String getPartitionSandboxReadDetail()
  {
    return partitionSandboxReadDetail;
  }


  public void setPartitionSandboxWriteDetail(String partitionSandboxWriteDetail)
  {
    this.partitionSandboxWriteDetail = partitionSandboxWriteDetail;
  }


  public String getPartitionSandboxWriteDetail()
  {
    return partitionSandboxWriteDetail;
  }


  public void setPartitionTmpReadDetail(String partitionTmpReadDetail)
  {
    this.partitionTmpReadDetail = partitionTmpReadDetail;
  }


  public String getPartitionTmpReadDetail()
  {
    return partitionTmpReadDetail;
  }


  public void setPartitionTmpWriteDetail(String partitionTmpWriteDetail)
  {
    this.partitionTmpWriteDetail = partitionTmpWriteDetail;
  }


  public String getPartitionTmpWriteDetail()
  {
    return partitionTmpWriteDetail;
  }


  public void setPartitionJBossReadDetail(String partitionJBossReadDetail)
  {
    this.partitionJBossReadDetail = partitionJBossReadDetail;
  }


  public String getPartitionJBossReadDetail()
  {
    return partitionJBossReadDetail;
  }


  public void setPartitionJBossWriteDetail(String partitionJBossWriteDetail)
  {
    this.partitionJBossWriteDetail = partitionJBossWriteDetail;
  }


  public String getPartitionJBossWriteDetail()
  {
    return partitionJBossWriteDetail;
  }


  public void setPartitionIOReadDetail(String partitionIOReadDetail)
  {
    this.partitionIOReadDetail = partitionIOReadDetail;
  }


  public String getPartitionIOReadDetail()
  {
    return partitionIOReadDetail;
  }


  public void setPartitionIOWriteDetail(String partitionIOWriteDetail)
  {
    this.partitionIOWriteDetail = partitionIOWriteDetail;
  }


  public String getPartitionIOWriteDetail()
  {
    return partitionIOWriteDetail;
  }


  public void setVirusGreenDetail(String virusGreenDetail)
  {
    this.virusGreenDetail = virusGreenDetail;
  }


  public String getVirusGreenDetail()
  {
    return virusGreenDetail;
  }


  public void setVirusRedDetail(String virusRedDetail)
  {
    this.virusRedDetail = virusRedDetail;
  }


  public String getVirusRedDetail()
  {
    return virusRedDetail;
  }


  public void setLdapReadDetail(String ldapReadDetail)
  {
    this.ldapReadDetail = ldapReadDetail;
  }


  public String getLdapReadDetail()
  {
    return ldapReadDetail;
  }


  public void setOverallDetail(String overallDetail)
  {
    this.overallDetail = overallDetail;
  }


  public String getOverallDetail()
  {
    return overallDetail;
  }

}