package mil.dtic.cbes.exceptions;

public class LockingException extends Exception
{
    private static final long serialVersionUID = 1L;

    public LockingException() { super(); }
    public LockingException(String message) { super(message); }
    public LockingException(String message, Throwable cause) { super(message, cause); }
    public LockingException(Throwable cause) { super(cause); }
}
