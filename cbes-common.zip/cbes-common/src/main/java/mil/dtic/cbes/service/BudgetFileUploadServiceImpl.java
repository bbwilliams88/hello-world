package mil.dtic.cbes.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
//import java.util.Iterator;
import java.util.List;

//import org.apache.logging.log4j.Logger;
//import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.submissions.ValueObjects.UploadedBudgetFile;
import mil.dtic.cbes.submissions.dao.UploadedBudgetFileDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;


public abstract class BudgetFileUploadServiceImpl<F extends UploadedBudgetFile> implements BudgetFileUploadService<F> {

    
    protected AppDefaults appDefaults;
    protected int maxNumberOfFiles;
    protected UploadedBudgetFileDAO<F> uploadedFileDAO;
    private String uploadDirectoryLocation;

    public void saveNewFile(File file, String fileName, String userName, String description, Date date)
            throws ValidationException, IOException {
        File uploadDirectory = new File(
                BudgesContext.getConfigService().getUploadFileStoragePath() + "/" + uploadDirectoryLocation);
        if (!uploadDirectory.exists()) {
            uploadDirectory.mkdir();
        }

        File newFile = new File(uploadDirectory.getAbsolutePath() + "/" + generateFileName(fileName, userName));
        BudgesFile budgesFile = new BudgesFile(fileName, newFile, file, null);
        VirusScanService virusScanService = new VirusScanService(appDefaults);
        virusScanService.virusScan(budgesFile);
        if (virusScanService.hasErrors()) {
            List<ValidationMessage> errorMessages = virusScanService.getErrorList();
            throw new ValidationException("There was an error virus scanning the file uploaded by " + userName,
                    errorMessages);
        } else if (virusScanService.virusFound()) {
            ValidationMessage validationMessage = new ValidationMessageImpl(
                    "There was a virus detected in the uploaded file");
            List<ValidationMessage> errorMessages = new ArrayList<ValidationMessage>();
            errorMessages.add(validationMessage);
            throw new ValidationException("There was a virus detected in the file uploaded by " + userName,
                    errorMessages);
        } else {
            storeFile(newFile, fileName, userName, description, date);
            removeOldFiles();
        }
    }

    protected abstract String generateFileName(String fileName, String userName);

    protected abstract void storeFile(File file, String fileName, String userName, String description, Date date) throws IOException;

    private void removeOldFiles() {
        List<F> files = uploadedFileDAO.findAllSortedByDate(false);
        if (files.size() > maxNumberOfFiles) {
            List<F> filesToRemove = files.subList(maxNumberOfFiles / 2, files.size());
            for (F uploadedFile : filesToRemove) {
                File file = new File(uploadedFile.getFileURI());
                file.delete();
                uploadedFileDAO.delete(uploadedFile);
            }
        }
    }
    
    @Override
    public List<F> getAllFiles() {
        return getAllFiles(Boolean.FALSE);
    }

    /**
     * Support for R2Analyst download files functionality.
     */
    @Override
    public List<F> getAllFiles(Boolean isRfr){
        
        if (null == isRfr){
            isRfr = Boolean.FALSE;
        }
        
        List<F> files = getRfrFiles(isRfr);
        checkFilesExist(files);
        return files;
        
    }
    
    public F getLatestFile() {
        return uploadedFileDAO.getLatestFile();
    }

    public F getFile(Integer id) {
        return uploadedFileDAO.findById(id);
    }

    public void deleteFile(Integer id) {
        F budgetFile = getFile(id);
        File file = new File(budgetFile.getFileURI());
        if (file != null) {
            file.delete();
        }
        uploadedFileDAO.delete(getFile(id));
    }

    public AppDefaults getAppDefaults() {
        return appDefaults;
    }

    public void setAppDefaults(AppDefaults appDefaults) {
        this.appDefaults = appDefaults;
    }

    public int getMaxNumberOfFiles() {
        return maxNumberOfFiles;
    }

    public void setMaxNumberOfFiles(int maxNumberOfFiles) {
        this.maxNumberOfFiles = maxNumberOfFiles;
    }

    public UploadedBudgetFileDAO<F> getUploadedFileDAO() {
        return uploadedFileDAO;
    }

    public void setUploadedFileDAO(UploadedBudgetFileDAO<F> uploadedFileDAO) {
        this.uploadedFileDAO = uploadedFileDAO;
    }

    private void checkFilesExist(List<F> uploadedBudgetFiles) {
        for (F uploadedBudgetFile : uploadedBudgetFiles) {
            File file = new File(uploadedBudgetFile.getFileURI());
            uploadedBudgetFile.setAvailableOnFilesystem(file.exists());
            if (file.exists()) {
                uploadedBudgetFile.setSize(file.length());
            }
        }
    }

    public String getUploadDirectoryLocation() {
        return uploadDirectoryLocation;
    }

    public void setUploadDirectoryLocation(String uploadDirectoryLocation) {
        this.uploadDirectoryLocation = uploadDirectoryLocation;
    }
    

    /**
     * process download files for R2Analsyst or Other users.
     * @param rfr - Boolean
     * @return files - List<F> 
     */
    private List<F> getRfrFiles(Boolean rfr){
        List<F> files = uploadedFileDAO.findAllSortedByDate(false);
        if (files.size() == 0){
            return files;
        }

        List<F> rfrFiles = new ArrayList<>();
        List<F> nonRfrFiles = new ArrayList<>();
        
        for (F file : files){
            if (isRfr(file)){
                rfrFiles.add(file); 
            }
            else{
                nonRfrFiles.add(file);
            }
        }
        
        if (rfr && rfrFiles.size()>0){
            checkFilesExist(rfrFiles);
            return rfrFiles;
        }
        else{ 
            checkFilesExist(nonRfrFiles);
            return nonRfrFiles;
        }
        
    }
    
    /**
     * Inspect file to determine if it is RFR type.
     * @param F - file
     * @return boolean  - 
     */
    private boolean isRfr(F file){
        boolean rfr = false;
        char symbol1;
        char symbol2;
        char[] cArray;
        
        if (null == file.getDescription()){
            return false;
        }
        else {
            cArray = file.getDescription().toCharArray();
        }        
        
        
        if(cArray.length > 1){
            if (cArray.length == 2){
                symbol1 = cArray[0];
                symbol2 = cArray[1];
            }
            else {
                symbol1 = cArray[cArray.length-2];
                symbol2 = cArray[cArray.length-1]; 
            }
            
            if (BudgetFileUploadService.RFR_DECRYPT_VALUE == symbol1 + symbol2){
                rfr = true;  
            }
        }
        
        return rfr;
        
    }
    

}
