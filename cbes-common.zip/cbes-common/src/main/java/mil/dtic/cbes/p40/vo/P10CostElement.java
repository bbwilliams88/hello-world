package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.PersistenceState;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.P10CostElementCategoryType;
import mil.dtic.cbes.p40.vo.auto._P10CostElement;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.CbesLogFactory;

public class P10CostElement extends _P10CostElement implements Equivalence<P10CostElement>, HasDisplayOrder, HasManufacturers, RollupParent
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(P10CostElement.class);

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);

        setupP10Costs();
    }

    @Override
    protected void onPostLoad()
    {
        setupP10Costs();
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    @Override
    // FIXME This could be named a bit better.
    public List<HistoryPlanning> getAllHistoryPlanningsSorted()
    {
        // FIXME Use Cost Element to figure out how we are sorting.
        List<HistoryPlanning> allHistoryPlannings = new ArrayList<HistoryPlanning>();

        for (Manufacturer manufacturer : getManufacturerList())
            allHistoryPlannings.addAll(manufacturer.getHistoryPlanningList()); // FIXME Rename to getHistoryPlannings().

        return allHistoryPlannings;
    }
    
    public List<QuantityForBudgetYear> getOrderedQuantityForBudgetYear()
    {
        return getSortedByDisplayOrder(super.getQuantityForBudgetYear());
    }

    public BigDecimal getBudgetYearUnitCost()
    {
        /*Costs unitCosts = getUnitCosts();

        if (unitCosts != null)
            return unitCosts.getBy1();*/
    	for (Manufacturer manufacturer : getManufacturerList())
    	{
    		for (HistoryPlanning hp : manufacturer.getHistoryPlanningList())
    		{
    			if (ObjectUtils.equals(hp.getFiscalYear(), getParentLineItem().getBudgetYear().longValue()))
    				return hp.getUnitCost();
    		}
    	}

        return null;
    }

    public BigDecimal getBudgetYearQuantity()
    {
    	for (Manufacturer manufacturer : getManufacturerList())
    	{
    		for (HistoryPlanning hp : manufacturer.getHistoryPlanningList())
    		{
    			if (ObjectUtils.equals(hp.getFiscalYear(), getParentLineItem().getBudgetYear().longValue()))
    				return hp.getQuantity();
    		}
    	}

        return null;
    }

    public List<? extends CostContainer> getChildren()
    {
        return getQuantityForBudgetYear();
    }

    public boolean isContinuing()
    {
        return getTotalCosts().isContinuing();
    }

    public void setContinuing(boolean b)
    {
        getTotalCosts().setContinuing(b);
    }

    public Costs getCosts()
    {
        return getTotalCosts();
    }

    public List<HistoryPlanning> getHistoryPlanningByYear(Long budgetYear)
    {
        List<HistoryPlanning> historyPlanningsByYear = new ArrayList<HistoryPlanning>();

        if (budgetYear != null) // Skip the loop if unnecessary.
            for (HistoryPlanning historyPlanning : getAllHistoryPlanningsSorted())
                if (ObjectUtils.equals(historyPlanning.getFiscalYear(), budgetYear))
                    historyPlanningsByYear.add(historyPlanning);

        return historyPlanningsByYear;
    }

    @Override
    public String getLongName()
    {
        if (getCategory() != null)
            return getCategory().name() + " / " + getName();
        return null;
    }
    
    public Short getProductionLeadtime()
    {
      for (Manufacturer manufacturer : getManufacturerList())
      {
        if(manufacturer.getInitialQuantity() != null && manufacturer.getInitialQuantity().getMFGAfterOct1() != null)
        {
          for (HistoryPlanning hp : manufacturer.getHistoryPlanningList())
            {
              if (ObjectUtils.equals(hp.getFiscalYear(), getParentLineItem().getBudgetYear().longValue()))
            	  return manufacturer.getInitialQuantity().getMFGAfterOct1().shortValue();
            }
        }
      }
      return null;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    @Override
    public Manufacturer addManufacturer()
    {
        Manufacturer newManufacturer = getObjectContext().newObject(Manufacturer.class);

        addToManufacturerList(newManufacturer);

        return newManufacturer;
    }

    public QuantityForBudgetYear addQuantityForBudgetYear()
    {
        QuantityForBudgetYear newQuantityForBudgetYear = getObjectContext().newObject(QuantityForBudgetYear.class);

        addToQuantityForBudgetYear(newQuantityForBudgetYear);

        return newQuantityForBudgetYear;
    }

    @Override
    public void removeManufacturer(Manufacturer m)
    {
        removeFromManufacturerList(m);
        getObjectContext().deleteObjects(m);
    }

    private void setupP10Costs()
    {
        log.info("Creating the Costs Objects for the UI if needed");

        if (getTotalCosts() == null)
        {
            setTotalCosts(getObjectContext().newObject(Costs.class));
            getTotalCosts().setType(CostRowType.TOTALCOST);
        }

        if (getTerminationLiabilityCosts() == null)
        {
            setTerminationLiabilityCosts(getObjectContext().newObject(Costs.class));
            getTerminationLiabilityCosts().setType(CostRowType.TOTALCOST);
        }
    }

    public void shiftForwardInTime(int years)
    {
        if (this.getTotalCosts() != null)
            this.getTotalCosts().shiftForwardInTime(years, false);

        if (this.getTerminationLiabilityCosts() != null)
            this.getTerminationLiabilityCosts().shiftForwardInTime(years, false);

        if (CollectionUtils.isNotEmpty(this.getQuantityForBudgetYear()))
            for(QuantityForBudgetYear quantityForBudgetYear : getQuantityForBudgetYear())
                quantityForBudgetYear.shiftForwardInTime(years);
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    public static P10CostElement createWithCategory(ObjectContext context, P10CostElementCategoryType category)
    {
        P10CostElement ce = context.newObject(P10CostElement.class);

        ce.setCategory(category);

        return ce;
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasCosts()
    {
        return getTotalCosts() != null && !getTotalCosts().isEmpty();
    }

    public boolean jibx_hasRemarks()
    {
        return getRemarks() != null;
    }

    public boolean jibx_hasManufacturerList()
    {
        return CollectionUtils.isNotEmpty(getManufacturerList());
    }

    public Iterator<Manufacturer> jibx_manufacturerIterator()
    {
      return getIterator(super.getManufacturerList());
    }

    public boolean jibx_hasTerminationLiabilityCosts()
    {
        return !getTerminationLiabilityCosts().isEmpty();
    }

    public Iterator<QuantityForBudgetYear> jibx_quantityForBudgetYearIterator()
    {
        if (getQuantityForBudgetYear() != null)
            return getQuantityForBudgetYear().iterator();
        return null;
    }

    public boolean jibx_hasQuantityForBudgetYear()
    {
        return CollectionUtils.isNotEmpty(getQuantityForBudgetYear());
    }

    public boolean jibx_hasForFiscalYear()
    {
        return (getForFiscalYear() != null);
    }

    public boolean jibx_hasName()
    {
        return (getName() != null);
    }

    public boolean jibx_hasWhenRequiredInMonths()
    {
        return StringUtils.isNotEmpty(getWhenRequired());
    }
    
    public boolean jibx_hasSCNProductionLeadtime()
    {
        return StringUtils.isNotEmpty(getSCNProductionLeadtime());
    }

    public boolean jibx_hasQuantityPerAssembly()
    {
        return (getQuantityPerAssembly() != null);
    }

    public boolean jibx_hasProductionLeadtime()
    {
        return (getProductionLeadtime() != null);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    @Override
    public int equivalenceHashCode()
    {
        if (this.getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();
        builder.append(toLowerAndTrim(getName()));
        builder.append(getAdvanceProcurement());

        return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(P10CostElement obj)
    {
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        P10CostElement other = obj;

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        EqualsBuilder builder = new EqualsBuilder();

        builder.append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName()));
        builder.append(this.getAdvanceProcurement(), other.getAdvanceProcurement());

        return builder.isEquals();
    }

	@Override
	public Costs getUnitCosts() {
		// Need to have these methods to succesfully implement the RollupParent interface since that extends CostContainer
		return null;
	}

	@Override
	public Costs getQuantities() {
		// Need to have these methods to succesfully implement the RollupParent interface since that extends CostContainer
		return null;
	}
}
