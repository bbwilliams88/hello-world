package mil.dtic.cbes.jb;

import java.util.Date;
import java.util.List;

import mil.dtic.cbes.constants.Constants.BUDGET_AREA;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.KeyValuePair;

public class DocumentCreationParams {
    private Integer budgetYear; 
    private String budgetCycle; 
    private Date submissionDate;
    private String serviceAgencyName;
    private String appropriationName;
    private String appropriationCode;
    private String docTitle;
    private boolean includeSubExhibits;
    private boolean suppressOocColumn;
    private boolean collapseOocColumn;
    private String classificationLabel;
    private String classificationSymbol;
    private List<KeyValuePair> pageNumberKvpList;
    private List<KeyValuePair> tocKvpList;
    private List<KeyValuePair> tovKvpList;
    private List<KeyValuePair> r4KvpList;
    private String docToGenerate;
    private String logoSource;
    private boolean pdfPerExhibit;
    private String bookGroupLabelAndNumber;
    private BUDGET_AREA budgetArea;
    private String totalVolumes;

    public DocumentCreationParams(){
        ConfigService configurationService = BudgesContext.getConfigService();
        includeSubExhibits = true;
        suppressOocColumn  = configurationService.isOocSuppressed();
        collapseOocColumn  = configurationService.isOocCollapse();
        setClassificationLabel(configurationService.getClassificationLabel());
        setClassificationSymbol(configurationService.getClassificationSymbol());
    }

    public DocumentCreationParams(LineItem lineItem) {
        this();
        setBudgetYear(lineItem.getBudgetYear());
        setBudgetCycle(lineItem.getBudgetCycle());
        setServiceAgencyName(lineItem.getServiceAgency().getName());
    }

    public DocumentCreationParams(ProgramElement programElement){
        this();
        setBudgetYear(programElement.getBudgetYear());
        setBudgetCycle(programElement.getBudgetCycle());
        setServiceAgencyName(programElement.getServiceAgency().getName());
    }

    public DocumentCreationParams(JBFormData formData){
        this();
        setBudgetYear(formData.getBudgetCycle().getBudgetYear());
        setBudgetCycle(formData.getBudgetCycle().getCycle());
        setSubmissionDate(formData.parseSubmissionDate());
    }

    public DocumentCreationParams(JBFormData formData, JBDefaultSystemGeneratedPart defaultSystemGeneratePart){
        this(formData);
        setDocToGenerate(defaultSystemGeneratePart.getFileSetting().getFileNamePrefix());
    }

    public Integer getBudgetYear() {
        return budgetYear;
    }

    public void setBudgetYear(Integer budgetYear) {
        this.budgetYear = budgetYear;
    }

    public String getBudgetCycle() {
        return budgetCycle;
    }

    public void setBudgetCycle(String budgetCycle) {
        this.budgetCycle = budgetCycle;
    }

    public Date getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(Date submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getServiceAgencyName() {
        return serviceAgencyName;
    }

    public void setServiceAgencyName(String serviceAgencyName) {
        this.serviceAgencyName = serviceAgencyName;
    }

    public String getAppropriationName() {
        return appropriationName;
    }

    public void setAppropriationName(String appropriationName) {
        this.appropriationName = appropriationName;
    }

    public String getAppropriationCode() {
        return appropriationCode;
    }

    public void setAppropriationCode(String appropriationCode) {
        this.appropriationCode = appropriationCode;
    }

    public String getDocTitle() {
        return docTitle;
    }

    public void setDocTitle(String docTitle) {
        this.docTitle = docTitle;
    }

    public boolean isIncludeSubExhibits() {
        return includeSubExhibits;
    }

    public void setIncludeSubExhibits(boolean includeSubExhibits) {
        this.includeSubExhibits = includeSubExhibits;
    }

    public boolean isCollapseOocColumn() {
        return collapseOocColumn;
    }

    public void setCollapseOocColumn(boolean collapseOocColumn){
        this.collapseOocColumn = collapseOocColumn;
    }

    public boolean isSuppressOocColumn() {
        return suppressOocColumn;
    }

    public void setSuppressOocColumn(boolean suppressOocColumn) {
        this.suppressOocColumn = suppressOocColumn;
    }

    public String getClassificationLabel() {
        return classificationLabel;
    }

    public void setClassificationLabel(String classificationLabel) {
        if (classificationLabel != null)
            this.classificationLabel = classificationLabel;
    }
    public String getClassificationSymbol() {
        return classificationSymbol;
    }

    public void setClassificationSymbol(String classificationSymbol) {
        if (classificationSymbol != null)
            this.classificationSymbol = classificationSymbol;
    }

    public List<KeyValuePair> getPageNumberKvpList() {
        return pageNumberKvpList;
    }

    public void setPageNumberKvpList(List<KeyValuePair> pageNumberKvpList) {
        this.pageNumberKvpList = pageNumberKvpList;
    }

    public List<KeyValuePair> getTocKvpList() {
        return tocKvpList;
    }

    public void setTocKvpList(List<KeyValuePair> tocKvpList) {
        this.tocKvpList = tocKvpList;
    }

    public List<KeyValuePair> getTovKvpList() {
        return tovKvpList;
    }

    public void setTovKvpList(List<KeyValuePair> tovKvpList) {
        this.tovKvpList = tovKvpList;
    }

    public List<KeyValuePair> getR4KvpList() {
        return r4KvpList;
    }

    public void setR4KvpList(List<KeyValuePair> kvpList) {
        r4KvpList = kvpList;
    }

    public String getDocToGenerate() {
        return docToGenerate;
    }

    public void setDocToGenerate(String docToGenerate) {
        this.docToGenerate = docToGenerate;
    }

    public String getLogoSource() {
        return logoSource;
    }

    public void setLogoSource(String logoSource) {
        this.logoSource = logoSource;
    }

    public boolean isPdfPerExhibit() {
        return pdfPerExhibit;
    }

    public void setPdfPerExhibit(boolean pdfPerExhibit) {
        this.pdfPerExhibit = pdfPerExhibit;
    }

    public String getBookGroupLabelAndNumber() {
        return bookGroupLabelAndNumber;
    }

    public void setBookGroupLabelAndNumber(String bookGroupLabelAndNumber) {
        this.bookGroupLabelAndNumber = bookGroupLabelAndNumber;
    }

    public String getTotalVolumes() {
        return totalVolumes;
    }

    public void setTotalVolumes(String totalVolumes) {
        this.totalVolumes = totalVolumes;
    }

    public BUDGET_AREA getBudgetArea() {
        return budgetArea;
    }

    public void setBudgetArea(BUDGET_AREA budgetArea) {
        this.budgetArea = budgetArea;
    }

    @Override
    public String toString() {
        return "DocumentCreationParams [budgetYear=" + budgetYear + ", budgetCycle=" + budgetCycle + ", submissionDate=" + submissionDate
                + ", serviceAgencyName=" + serviceAgencyName + ", appropriationName=" + appropriationName + ", appropriationCode=" + appropriationCode
                + ", docTitle=" + docTitle + ", includeSubExhibits=" + includeSubExhibits + ", suppressOocColumn=" + suppressOocColumn
                + ", collapseOocColumn=" + collapseOocColumn + ", classificationLabel=" + classificationLabel + ", classificationSymbol="
                + classificationSymbol + ", pageNumberKvpList=" + pageNumberKvpList + ", tocKvpList=" + tocKvpList + ", tovKvpList=" + tovKvpList
                + ", r4KvpList=" + r4KvpList + ", docToGenerate=" + docToGenerate + ", logoSource=" + logoSource + ", pdfPerExhibit=" + pdfPerExhibit
                + ", bookGroupLabelAndNumber=" + bookGroupLabelAndNumber + ", budgetArea=" + budgetArea + ", totalVolumes=" + totalVolumes + "]";
    }

}
