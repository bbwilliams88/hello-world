package mil.dtic.cbes.rule;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.RDTERuleStatus;
import mil.dtic.cbes.submissions.ValueObjects.ValidationExemption;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

/**
 * Creates a rule repository.
 *
 * @author AZumkhaw
 *
 */
public class RuleRepositoryFactory {
  private static final Logger log = CbesLogFactory.getLog(RuleRepositoryFactory.class);

  private static final String RDTE_RULES_FILE = "RDTE-rules.json";

  static private RuleRepository r2_rdte_repository;
  static private RuleRepository r2_rdte_base_repository;

  /**
   * Rebuilds the rule repository cache.
   *
   */
  static public void rebuild() {
    r2_rdte_repository = buildAdministeredRepository();
    log.debug("Rebuilt rule repository: " + r2_rdte_repository.getRules().size() + " enabled rules.");
  }

  /**
   * Builds a rule repository for the application.
   *
   * @return
   */
  static public RuleRepository makeRepository() {
    if (r2_rdte_repository == null) {
      r2_rdte_repository = buildAdministeredRepository();
      log.debug("Initialized rule repository from " + RDTE_RULES_FILE + " including administered rule status.");
    }
    return r2_rdte_repository;
  }

  /**
   * Builds a rule repository for unit tests.
   *
   * @return
   */
  static public RuleRepository makeBaseRepository() {
    if (r2_rdte_base_repository == null) {
      r2_rdte_base_repository = buildBaseRepository();
      log.debug("Initialized rule repository factory with rules from " + RDTE_RULES_FILE);
    }
    return r2_rdte_base_repository;
  }

  /**
   * Build a repository for use by the business rule engine.
   * Builds a set of rules, removing rules disabled via administration.
   *
   * @return
   */
    static private RuleRepository buildAdministeredRepository()
    {
        RuleRepository repository = buildBaseRepository();

        List<RDTERuleStatus>      ruleStatuses         = BudgesContext.getRDTERuleStatusDAO().findAll();
        List<ValidationExemption> validationExemptions = BudgesContext.getValidationExemptionDAO().findAll();
//        RDTERuleStatusDAO ruleStatusDAO        = BudgesContext.getRDTERuleStatusDAO();

        for (RDTERuleStatus ruleStatus : ruleStatuses)
            if (ruleStatus.isActive() == false)
                repository.narrowTo(ruleStatus.getRuleNumber()).disableRule(ruleStatus.getRuleNumber());

        for (ValidationExemption validationExemption : validationExemptions)
            if (StringUtils.isNotBlank(validationExemption.getRdteRule()))
                if (validationExemption.getStatus() == StatusFlag.ACTIVE)
                    repository.narrowTo(validationExemption.getRdteRule()).getFirstRule().addExemptOrganization(validationExemption.getOrganization().getCode());

        return repository;
    }

    /**
     * Build a base repository of all rules in the JSON configuration.
     *
     * @return
     */
    static private RuleRepository buildBaseRepository()
    {
        RuleRepository repository = null;

        try
        {
            ClassLoader classLoader = RuleGroupVisitorFactory.class.getClassLoader();
            if(classLoader != null) 
            {
                try (InputStream rulesStream = classLoader.getResourceAsStream(RDTE_RULES_FILE))
                {
                    if (rulesStream != null)
                    {
                        repository = RuleFileReader.makeRuleRepository(rulesStream);
                    }
                }
            }
        }
        catch (SecurityException | IOException e)
        {
            log.error("Error while creating rule repository", e);
        }

        return repository;
    }
}