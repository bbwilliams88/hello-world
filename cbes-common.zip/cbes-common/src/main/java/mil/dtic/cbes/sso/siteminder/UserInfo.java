/*
 * $Id$
 */
package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.LockableExhibit;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.Util;

public class UserInfo implements Serializable{
  private static final long serialVersionUID = -1959917163146661426L;
  //private static final Map<String, Map<Privilege, Boolean>> configuredPrivileges = new HashMap<String, Map<Privilege, Boolean>>();
  private static final Map<String, Map<Privilege, Boolean>> configuredPrivileges = new HashMap<>();
  private final LdapUser ldapUser;
  private final BudgesUser budgesUser;
  private final Map<Privilege, Boolean> privileges;
  
  private List<ServiceAgency> availableRdteAgencies;
  private List<ServiceAgency> availableProcurementAgencies;
  private List<ServiceAgency> allAvailableAgencies;
  private Set<Integer> availableRdteAgencyIds;
  private Set<Integer> availableProcurementAgencyIds;
  private Set<Integer> allAvailableAgencyIds;
  
  /**
   * UserInfo constructor.
   * Neither ldapUser nor budgesUser will be null.
   * @param ldapUser - LdapUser
   * @param budgesUser - BudgesUser
   */
  public UserInfo(LdapUser ldapUser, BudgesUser budgesUser) {
      this.ldapUser = ldapUser;
      this.budgesUser = budgesUser;
      this.privileges = configuredPrivileges.get(ldapUser.getR2Role());
      init();
  }
  
  /**
   * CXE-6416 SuperAdmin enhancement. 
   * This method enables AppManager capability to modify key super admin features 
   * and see the changes without restarting the application.
   * @param role - String
   */
  public void reinit(String role){
      if (getLdapUser().getR2Role().equals(role) && 
              getLdapUser().getR2Role().equals(LdapDAO.GROUP_R2_APP_ADMIN)){
          init();
      }
  }
  
  public boolean checkManageRole(String r2Role) {
      boolean canManage = checkPrivilege(Privilege.MANAGE_USERS);
    
      if (LdapDAO.GROUP_R2_LOCALSITEADMIN.equals(r2Role)){
          canManage &= checkPrivilege(Privilege.MANAGE_LOCAL_ADMINS);
      }
    
      if (LdapDAO.GROUP_R2_SITEADMIN.equals(r2Role) || LdapDAO.GROUP_R2_APP_ADMIN.equals(r2Role)){
          canManage &= checkPrivilege(Privilege.MANAGE_ALL_USERS);
      }
      
      if(LdapDAO.GROUP_OMB_ANALYST.equalsIgnoreCase(r2Role)  || LdapDAO.GROUP_R2_ANALYST.equalsIgnoreCase(r2Role)) {
    	  canManage &= checkPrivilege(Privilege.MANAGE_ANALYST_USERS);
      }
      
      return canManage;
  }

  public LdapUser getLdapUser() {
      return this.ldapUser;
  }

  public BudgesUser getBudgesUser() {
      return this.budgesUser;
  }

  public List<ServiceAgency> getAvailableRdteAgencies() {
      return availableRdteAgencies;
  }

  public List<ServiceAgency> getAvailableProcurementAgencies() {
      return availableProcurementAgencies;
  }

  public List<ServiceAgency> getAllAvailableAgencies() {
      return allAvailableAgencies;
  }

  public boolean isLoggedIn() {
      return(ldapUser != null);
  }

  public boolean checkPrivilege(Privilege priv) {
    
    if (null == priv){
        return false;
    }
    return privileges.get(priv) != null && privileges.get(priv);
  }

  public boolean hasAgencies(){
      return budgesUser != null && CollectionUtils.isNotEmpty(budgesUser.getBudgesUserAndServiceAgencyLinks());
  }

  @SuppressWarnings("deprecation")
  public boolean hasAccessToMainUi(){
     return budgesUser != null && 
    	budgesUser.getStatusFlag().isActive() && 
    	checkPrivilege(Privilege.BASIC_USER) && 
    	(hasAgencies() || checkPrivilege(Privilege.ADMIN_ALL_AGENCIES));
  }

  public boolean canManageUsers() {
      return checkPrivilege(Privilege.MANAGE_USERS);
  }

  public boolean savePeAllowed(ProgramElementBase pe){
      return hasEditPermission(pe.getId(), pe.getServiceAgency().getId()) && !isEntireLocked(pe);
  }

  //CXE-5891 prevent all but R2AppMgr to delete PE.
  public boolean deletePeAllowed(ProgramElementBase pe) {
	  return checkPrivilege(Privilege.DELETE_PE);
  }

  public boolean editPeUsersAllowed(ProgramElementBase pe) {
	  return checkPrivilege(Privilege.MANAGE_USERS) && 
			  hasEditPermission(pe.getId(), pe.getServiceAgency().getId());
  }

  private boolean hasEditPermission(Integer peId, Integer agencyId) {
      if (peId == null) return true; 

      BudgesUserAndProgramElementLink userPe = BudgesContext.getBudgesUserAndProgramElementLinkDAO().
              findByUserAndPeId(getBudgesUser(), peId);

      if (userPe == null || (!userPe.isEdit())){
          boolean editIfInAgency = checkPrivilege(Privilege.EDIT_ALL_PES_IN_AGENCY);
        
          if (checkPrivilege(Privilege.EDIT_ALL_PES)){
              return true;
          }
        
          if (editIfInAgency){
              if (availableRdteAgencyIds.contains(agencyId)) return true;
          }

          return false;
      }
      else { 
          return true;
      }
  }

  private boolean isEntireLocked(ProgramElementBase pe) {
      return pe != null && pe.getEntirePeLockedBy() != null && 
              !pe.getEntirePeLockedBy().getId().equals(getBudgesUser().getId());
  }


  public boolean viewPeAllowed(ProgramElementBase pe) {
      if (pe.getId() == null) return true; // new pe
    
      BudgesUserAndProgramElementLink userPe = BudgesContext.getBudgesUserAndProgramElementLinkDAO().
            findByUserAndPeId(getBudgesUser(), pe.getId());

      if (userPe == null || (!userPe.isView()))  {
          boolean viewIfInAgency = checkPrivilege(Privilege.EDIT_ALL_PES_IN_AGENCY);
          
          if (checkPrivilege(Privilege.EDIT_ALL_PES)) return true;
        
          if (viewIfInAgency) {
              if (availableRdteAgencyIds.contains(pe.getServiceAgency().getId())) return true;
          }

          return false;
      }
      else { 
          return true;
      }
  }

  public boolean createPeAllowed() {
      if (budgesUser == null) {
    	  return false;
      }
      if (checkPrivilege(Privilege.ALWAYS_CAN_CREATE)) {
    	  return true;
      }
      return budgesUser.isCreatePeAllowed();
  }

  @Override
  public String toString() {
      final String TAB = "    ";
      String retValue = "";

      retValue = "UserInfo ( " + super.toString() + TAB + "ldapUser = " + this.ldapUser + TAB
              + "budgesUser = " + this.budgesUser + TAB + "rdteAgencies = " 
              + this.availableRdteAgencies + TAB + "procurementAgencies = " 
              + this.availableProcurementAgencies + TAB + " )";

      return retValue;
  }


  public boolean isLockedByOther(LockableExhibit exhibit) {
      Integer thisUsersId = getBudgesUser().getId();
      return(exhibit != null && exhibit.getLockedBy() != null && !exhibit.getLockedBy().getId().equals(thisUsersId));
  }

  public boolean isLockedByMe(LockableExhibit exhibit){
      Integer thisUsersId = getBudgesUser().getId();
      return(exhibit != null && exhibit.getLockedBy() != null && exhibit.getLockedBy().getId().equals(thisUsersId));
  }

  public boolean isNotLocked(LockableExhibit exhibit){
      return exhibit != null && exhibit.getLockedBy() == null;
  }

  public boolean isEntireLockedByOther(ProgramElementBase pe) {
      Integer thisUsersId = getBudgesUser().getId();
      return pe != null && pe.getEntirePeLockedBy() != null && !pe.getEntirePeLockedBy().getId().equals(thisUsersId);
  }
  
  public boolean isEntireLockedByMe(ProgramElementBase pe) {
      Integer thisUsersId = getBudgesUser().getId();
      return pe != null && pe.getEntirePeLockedBy() != null && pe.getEntirePeLockedBy().getId().equals(thisUsersId);
  }

  public boolean canDoPrcp() {
      return checkPrivilege(Privilege.CAN_DO_PRCP);
  }
  
  public boolean canDeleteBudgesJob(){
    return checkPrivilege(Privilege.DELETE_BUDGES_JOB);
  }
  
  /**
   * CXE-6416 SuperAdmin enhancement
   */
  private void init(){
      if (checkPrivilege(Privilege.ADMIN_ALL_AGENCIES) || checkPrivilege(Privilege.TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES)){
          this.availableRdteAgencies = BudgesContext.getServiceAgencyDAO().findAllRDTE();
          this.availableProcurementAgencies = BudgesContext.getServiceAgencyDAO().findAllProcurement();
          this.allAvailableAgencies = BudgesContext.getServiceAgencyDAO().findAllRDTEAndProcurement();
      }
      else {
          if (budgesUser != null){
              this.availableRdteAgencies = Util.toArrayList(budgesUser.getRDTEAgencies());
              this.availableProcurementAgencies = Util.toArrayList(budgesUser.getProcurementAgencies());
              this.allAvailableAgencies = Util.toArrayList(budgesUser.getAllAgencies());
          }
          else{
              this.availableRdteAgencies = new ArrayList<ServiceAgency>(0);
              this.availableProcurementAgencies = new ArrayList<ServiceAgency>(0);
              this.allAvailableAgencies = new ArrayList<ServiceAgency>(0);
          }
      } 
      if (null != budgesUser && budgesUser.isTestUser()) {
    	  this.privileges.put(Privilege.ACCESS_IN_MAINTENANCE_MODE, true);
      }

      this.availableRdteAgencyIds = new HashSet<Integer>(availableRdteAgencies.size());
      this.availableProcurementAgencyIds = new HashSet<Integer>(availableProcurementAgencies.size());
      this.allAvailableAgencyIds = new HashSet<Integer>(allAvailableAgencies.size());

      for (ServiceAgency sa : availableRdteAgencies){
          availableRdteAgencyIds.add(sa.getId());
      }

      for (ServiceAgency sa : availableProcurementAgencies){
          availableProcurementAgencyIds.add(sa.getId());
       }

      for (ServiceAgency sa : allAvailableAgencies){
          allAvailableAgencyIds.add(sa.getId());
      }
  }
  
  static {
      configuredPrivileges.put(LdapDAO.GROUP_NONE, new HashMap<Privilege, Boolean>());
      for (String role : LdapDAO.VALID_GROUPS_SET) {
        configuredPrivileges.put(role, new HashMap<Privilege, Boolean>());
      }

      for (Privilege p : Privilege.values()){
        configuredPrivileges.get(LdapDAO.GROUP_R2_APP_ADMIN).put(p, true);
      }
      
      configuredPrivileges.get(LdapDAO.GROUP_OMB_ANALYST).put(Privilege.TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES,true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_ANALYST).put(Privilege.TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES,true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_ANALYST).put(Privilege.DELETE_BUDGES_JOB,true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.BASIC_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.MANAGE_USERS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.MANAGE_LOCAL_ADMINS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.SHOW_ALL_PES_IN_AGENCY, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.EDIT_ALL_PES_IN_AGENCY, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.SHOW_MODIFYING_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.ALWAYS_CAN_CREATE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DISABLE_SET_PERM_ON_CREATEPE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.FREEZE_PE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.R1PAGE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.TRACK_ASYNC_JOBS_FOR_OWN_AGENCIES, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.LOGODEFAULT, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DELETE_PE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DELETE_BUDGES_JOB, true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.BASIC_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.MANAGE_USERS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.SHOW_MODIFYING_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.FREEZE_PE, false);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_USER).put(Privilege.BASIC_USER, true);
    }
}
