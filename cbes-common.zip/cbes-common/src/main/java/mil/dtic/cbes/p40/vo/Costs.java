package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.commons.lang.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._Costs;
import mil.dtic.utility.BigDecimalUtil;

/**
 *
 */
public class Costs extends _Costs implements ICosts<BigDecimal>, ModsOutYearDifference
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Constructors                                                    ***/
    /***********************************************************************/

    public Costs()
    {
    }

    public Costs(Costs costs)
    {
        costs.copyTo(this);
    }

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        // setType(CostRowType.TOTALCOST);
        setTonysParentTable("ce");
        setLineItemId(0);
    }

    @Override
    protected void onPostLoad()
    {
    }


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public boolean isNotEmpty()
    {
        return isEmpty() == false;
    }

    /**
     * @return <tt>true</tt> if all values are <tt>null</tt> and continuing is <tt>false</tt>, otherwise <tt>false</tt>.
     */
    public boolean isEmpty()
    {
        return getPriorYears()    == null &&
               getPriorYear()     == null &&
               getCurrentYear()   == null &&
               getBy1Base()       == null &&
               getBy1Ooc()        == null &&
               getBy1()           == null &&
               getBy2()           == null &&
               getBy3()           == null &&
               getBy4()           == null &&
               getBy5()           == null &&
               getToComplete()    == null &&
               getTotal()         == null &&
               isContinuing()     == false;
    }

    public boolean isEmptyBesidesPYS()
    {
        return BigDecimalUtil.isZeroOrNull(getPriorYear())   &&
               BigDecimalUtil.isZeroOrNull(getCurrentYear()) &&
               BigDecimalUtil.isZeroOrNull(getBy1Base())     &&
               BigDecimalUtil.isZeroOrNull(getBy1Ooc())      &&
               BigDecimalUtil.isZeroOrNull(getBy1())         &&
               BigDecimalUtil.isZeroOrNull(getBy2())         &&
               BigDecimalUtil.isZeroOrNull(getBy3())         &&
               BigDecimalUtil.isZeroOrNull(getBy4())         &&
               BigDecimalUtil.isZeroOrNull(getBy5())         &&
               BigDecimalUtil.isZeroOrNull(getToComplete())  &&
               !isContinuing();
    }

    public boolean isInYearsEmpty()
    {
        return BigDecimalUtil.isZeroOrNull(getPriorYear())   &&
               BigDecimalUtil.isZeroOrNull(getCurrentYear()) &&
               BigDecimalUtil.isZeroOrNull(getBy1Base())     &&
               BigDecimalUtil.isZeroOrNull(getBy1Ooc())      &&
               BigDecimalUtil.isZeroOrNull(getBy1());
    }

    public boolean isAllNullOrZero()
    {
        return BigDecimalUtil.isZeroOrNull(getPriorYears())  &&
               BigDecimalUtil.isZeroOrNull(getPriorYear())   &&
               BigDecimalUtil.isZeroOrNull(getCurrentYear()) &&
               BigDecimalUtil.isZeroOrNull(getBy1Base())     &&
               BigDecimalUtil.isZeroOrNull(getBy1Ooc())      &&
               BigDecimalUtil.isZeroOrNull(getBy1())         &&
               BigDecimalUtil.isZeroOrNull(getBy2())         &&
               BigDecimalUtil.isZeroOrNull(getBy3())         &&
               BigDecimalUtil.isZeroOrNull(getBy4())         &&
               BigDecimalUtil.isZeroOrNull(getBy5())         &&
               BigDecimalUtil.isZeroOrNull(getToComplete())  &&
               BigDecimalUtil.isZeroOrNull(getTotal());
    }

    public boolean isAllNullOrZeroExceptTotal()
    {
        return BigDecimalUtil.isZeroOrNull(getPriorYears())  &&
               BigDecimalUtil.isZeroOrNull(getPriorYear())   &&
               BigDecimalUtil.isZeroOrNull(getCurrentYear()) &&
               BigDecimalUtil.isZeroOrNull(getBy1Base())     &&
               BigDecimalUtil.isZeroOrNull(getBy1Ooc())      &&
               BigDecimalUtil.isZeroOrNull(getBy1())         &&
               BigDecimalUtil.isZeroOrNull(getBy2())         &&
               BigDecimalUtil.isZeroOrNull(getBy3())         &&
               BigDecimalUtil.isZeroOrNull(getBy4())         &&
               BigDecimalUtil.isZeroOrNull(getBy5())         &&
               BigDecimalUtil.isZeroOrNull(getToComplete());
    }

    public boolean isAllNullExceptTotal()
    {
    	return getPriorYears() 	== null &&
    		   getPriorYear()  	== null &&
    		   getCurrentYear() == null &&
    		   getBy1Base() 	== null &&
    		   getBy1Ooc() 		== null &&
    		   getBy1() 		== null &&
    		   getBy2() 		== null &&
    		   getBy3() 		== null &&
    		   getBy4() 		== null &&
    		   getBy5() 		== null &&
    		   getToComplete() 	== null;
    }

    public boolean isAllNullExceptBY1()
    {
    	return getPriorYears() 	== null &&
    		   getPriorYear()  	== null &&
    		   getCurrentYear() == null &&
    		   getBy2() 		== null &&
    		   getBy3() 		== null &&
    		   getBy4() 		== null &&
    		   getBy5() 		== null &&
    		   getToComplete() 	== null;
    }

    public List<BigDecimal> getAllYearsList()
    {
        List<BigDecimal> costList = new ArrayList<BigDecimal>();
        if (getPriorYears() != null)
            costList.add(getPriorYears());
        if (getPriorYear() != null)
            costList.add(getPriorYear());
        if (getCurrentYear() != null)
            costList.add(getCurrentYear());
        if (getBy1Base() != null)
            costList.add(getBy1Base());
        if (getBy1Ooc() != null)
            costList.add(getBy1Ooc());
        if (getBy1() != null)
            costList.add(getBy1());
        if (getBy2() != null)
            costList.add(getBy2());
        if (getBy3() != null)
            costList.add(getBy3());
        if (getBy4() != null)
            costList.add(getBy4());
        if (getBy5() != null)
            costList.add(getBy5());
        if (getToComplete() != null)
            costList.add(getToComplete());
        return costList;
    }

    // This method is similar to getAllYearsList except...
    // it allows for nulls and includes ToComplete
    public List<BigDecimal> getAllYearsListWithNulls()
    {
        List<BigDecimal> costList = new ArrayList<BigDecimal>();

        costList.add(getPriorYears());
        costList.add(getPriorYear());
        costList.add(getCurrentYear());
        costList.add(getBy1Base());
        costList.add(getBy1Ooc());
        costList.add(getBy1());
        costList.add(getBy2());
        costList.add(getBy3());
        costList.add(getBy4());
        costList.add(getBy5());
        costList.add(getToComplete());

        return costList;
    }

    // FIXME: Should be an is* method.
    public boolean hasOutYears()
    {
        return !BigDecimalUtil.isZeroOrNull(getBy2())         ||
               !BigDecimalUtil.isZeroOrNull(getBy3())         ||
               !BigDecimalUtil.isZeroOrNull(getBy4())         ||
               !BigDecimalUtil.isZeroOrNull(getBy5())         ||
               !BigDecimalUtil.isZeroOrNull(getToComplete())  ||
               !BigDecimalUtil.isZeroOrNull(getTotal())       ||
               isContinuing();
    }

    public boolean isNonNullTotalWithNonZeroFyCost()
    {
        return getTotal() != null && !isFiscalYearCostsEmpty();
    }

    public boolean isFiscalYearCostsEmpty()
    {
        return BigDecimalUtil.isZeroOrNull(getPriorYears())   &&
               BigDecimalUtil.isZeroOrNull(getPriorYear())    &&
               BigDecimalUtil.isZeroOrNull(getCurrentYear())  &&
               BigDecimalUtil.isZeroOrNull(getBy1())          &&
               BigDecimalUtil.isZeroOrNull(getBy2())          &&
               BigDecimalUtil.isZeroOrNull(getBy3())          &&
               BigDecimalUtil.isZeroOrNull(getBy4())          &&
               BigDecimalUtil.isZeroOrNull(getBy5());
    }

    @Override
    public BigDecimal getPriorYears()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPriorYears());
    }

    @Override
    public BigDecimal getPriorYear()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getPriorYear());
    }

    @Override
    public BigDecimal getCurrentYear()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getCurrentYear());
    }

    @Override
    public BigDecimal getBy1Base()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy1Base());
    }

    @Override
    public BigDecimal getBy1Ooc()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy1Ooc());
    }

    @Override
    public BigDecimal getBy1()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy1());
    }

    @Override
    public BigDecimal getBy2()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy2());
    }

    @Override
    public BigDecimal getBy3()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy3());
    }

    @Override
    public BigDecimal getBy4()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy4());
    }

    @Override
    public BigDecimal getBy5()
    {
        return BigDecimalUtil.stripTrailingZeros(super.getBy5());
    }

    @Override
    public BigDecimal getToComplete()
    {
        if (isContinuing())
            return null;

        return BigDecimalUtil.stripTrailingZeros(super.getToComplete());
    }

    @Override
    public BigDecimal getTotal()
    {
        if (isContinuing())
            return null;

        return BigDecimalUtil.stripTrailingZeros(super.getTotal());
    }

    @Override
    public String getToCompleteFootnote()
    {
        if (isContinuing())
            return null;

        return super.getToCompleteFootnote();
    }

    @Override
    public String getTotalCostFootnote()
    {
        if (isContinuing())
            return null;

        return super.getTotalCostFootnote();
    }

    public List<BigDecimal> getOutYears()
    {
        List<BigDecimal> outYearsList = new ArrayList<BigDecimal>();

        if (getBy2() != null)
            outYearsList.add(getBy2());

        if (getBy3() != null)
            outYearsList.add(getBy2());

        if (getBy4() != null)
            outYearsList.add(getBy2());

        if (getBy5() != null)
            outYearsList.add(getBy2());

        if (getToComplete() != null)
            outYearsList.add(getToComplete());

        if (getTotal() != null)
            outYearsList.add(getTotal());

        return outYearsList;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    /**
     * Copy a Costs object into the destination Costs object.
     *
     * @param destination The destination Costs object to overwrite.
     */
    public void copyTo(Costs destination)
    {
        // FIXME: Should this copy footnotes?
        destination.setPriorYears(getPriorYears());
        destination.setPriorYear(getPriorYear());
        destination.setCurrentYear(getCurrentYear());
        destination.setBy1Base(getBy1Base());
        destination.setBy1Ooc(getBy1Ooc());
        destination.setBy1(getBy1());
        destination.setBy2(getBy2());
        destination.setBy3(getBy3());
        destination.setBy4(getBy4());
        destination.setBy5(getBy5());
        destination.setToComplete(getToComplete());
        destination.setTotal(getTotal());
        destination.setContinuing(isContinuing());
    }

    /**
     * Clear out the values in this Costs object.
     */
    public void clearValues()
    {
        // FIXME: Should this null out footnotes?
        this.setPriorYears(null);
        this.setPriorYear(null);
        this.setCurrentYear(null);
        this.setBy1Base(null);
        this.setBy1Ooc(null);
        this.setBy1(null);
        this.setBy2(null);
        this.setBy3(null);
        this.setBy4(null);
        this.setBy5(null);
        this.setToComplete(null);
        this.setTotal(null);
        this.setContinuing(false);
    }

    public static void clearOutYears(Costs costs)
    {
        if (costs != null)
            costs.clearOutYears();
    }

    public void clearOutYears()
    {
        setBy2(null);
        setBy2Footnote(null);

        setBy3(null);
        setBy3Footnote(null);

        setBy4(null);
        setBy4Footnote(null);

        setBy5(null);
        setBy5Footnote(null);

        setToComplete(null);
        setToCompleteFootnote(null);

        setTotal(null);
        setTotalCostFootnote(null); // FIXME: This footnaote name is inconsistent with others.

        setContinuing(false);
        setContinuingFootnote(null);
    }

    public void add(Costs other)
    {
        if (getObjectContext() != null)
            throw new IllegalStateException("Don't change real things from the db");
        if (other != null)
            add(this, other);
    }

    public void subtract(Costs other)
    {
        if (getObjectContext() != null)
            throw new IllegalStateException("Don't change real things from the db");
        subtract(this, other);
    }

    public void removeOutYears()
    {
        if (getObjectContext() != null)
            throw new IllegalStateException("Don't change real things from the db");
        setBy2(null);
        setBy3(null);
        setBy4(null);
        setBy5(null);
        setToComplete(null);
        setTotal(null);
        setContinuing(false);
    }

    // shift 'forward in time' by shifting costs 'back in time'
    // add py to apy
    // and move by1 to py
    public void shiftForwardInTime(int years, boolean includeBaseAndOoc)
    {
        for (int i = 0; i < years; i++)
        {
            if (getPriorYears() != null)
            {
                if (getPriorYear() != null && !getType().equals(CostRowType.UNITCOST))
                    setPriorYears(getPriorYears().add(getPriorYear()));
                else if (getPriorYear() != null)
                {
                    setPriorYears(null);
                    setPriorYearsFootnote(null);
                }
            }
            else
                setPriorYears(getPriorYear());

            setPriorYear(getCurrentYear());
            setCurrentYear(getBy1());
            setBy1(getBy2());
            if (includeBaseAndOoc)
            {
              setBy1Base(getBy2());
              setBy1Ooc(null);
            }
            setBy2(getBy3());
            setBy3(getBy4());
            setBy4(getBy5());
            setBy5(null);

            setPriorYearFootnote(getCurrentYearFootnote());
            setCurrentYearFootnote(getBy1Footnote());
            setBy1Footnote(getBy2Footnote());
            setBy2Footnote(getBy3Footnote());
            setBy3Footnote(getBy4Footnote());
            setBy4Footnote(getBy5Footnote());

            // totals etc don't change as long as everything is collected in All
            // Prior Years correctly
        }
    }

    public void shiftForwardInTime(int years)
    {
      shiftForwardInTime(years, true);
    }


    // shift 'forward in time' by shifting costs 'back in time'
    // and move by1 to py
    public void shiftForwardInTimeNoApys(int years)
    {
        for (int i = 0; i < years; i++)
        {
            setPriorYear(getCurrentYear());
            setCurrentYear(getBy1());
            setBy1(getBy2());
            setBy1Base(getBy2());
            setBy1Ooc(null);
            setBy2(getBy3());
            setBy3(getBy4());
            setBy4(getBy5());
            setBy5(null);

            setPriorYearFootnote(getCurrentYearFootnote());
            setCurrentYearFootnote(getBy1Footnote());
            setBy1Footnote(getBy2Footnote());
            setBy2Footnote(getBy3Footnote());
            setBy3Footnote(getBy4Footnote());
            setBy4Footnote(getBy5Footnote());

            // totals etc don't change as long as everything is collected in All
            // Prior Years correctly
        }
    }

    public void shiftForwardInTimeNoApysOrBase(int years)
    {
        for (int i = 0; i < years; i++)
        {
            setPriorYear(getCurrentYear());
            setCurrentYear(getBy1());
            setBy1(getBy2());
            setBy2(getBy3());
            setBy3(getBy4());
            setBy4(getBy5());
            setBy5(null);

            setPriorYearsFootnote(getPriorYearsFootnote() + getPriorYearFootnote());
            setPriorYearFootnote(getCurrentYearFootnote());
            setCurrentYearFootnote(getBy1Footnote());
            setBy1Footnote(getBy2Footnote());
            setBy2Footnote(getBy3Footnote());
            setBy3Footnote(getBy4Footnote());
            setBy4Footnote(getBy5Footnote());

            // totals etc don't change as long as everything is collected in All
            // Prior Years correctly
        }
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * @param objectContext
     *            The ObjectContext to create and register the Costs object
     *            into.
     * @param type
     *            The CostRowType for the new Costs object.
     * @return A new Costs object registered in the given objectContext and
     *         initialized with the given row type.
     */
    public static Costs create(ObjectContext objectContext, CostRowType type)
    {
        if (type == null)
            throw new NullPointerException("Cannot create a Costs with a null row type.");

        Costs c = objectContext.newObject(Costs.class);

        c.setType(type);

        return c;
    }

    /**
     * Adds cost2 Costs to cost1 (cost1 is updated).
     *
     * @param cost1
     * @param cost2
     */
    public static void add(Costs cost1, Costs cost2)
    {
        cost1.setPriorYears(BigDecimalUtil.add(cost1.getPriorYears(), cost2.getPriorYears()));
        cost1.setPriorYear(BigDecimalUtil.add(cost1.getPriorYear(), cost2.getPriorYear()));
        cost1.setCurrentYear(BigDecimalUtil.add(cost1.getCurrentYear(), cost2.getCurrentYear()));
        cost1.setBy1(BigDecimalUtil.add(cost1.getBy1(), cost2.getBy1()));
        cost1.setBy1Base(BigDecimalUtil.add(cost1.getBy1Base(), cost2.getBy1Base()));
        cost1.setBy1Ooc(BigDecimalUtil.add(cost1.getBy1Ooc(), cost2.getBy1Ooc()));
        cost1.setBy2(BigDecimalUtil.add(cost1.getBy2(), cost2.getBy2()));
        cost1.setBy3(BigDecimalUtil.add(cost1.getBy3(), cost2.getBy3()));
        cost1.setBy4(BigDecimalUtil.add(cost1.getBy4(), cost2.getBy4()));
        cost1.setBy5(BigDecimalUtil.add(cost1.getBy5(), cost2.getBy5()));
        cost1.setToComplete(BigDecimalUtil.add(cost1.getToComplete(), cost2.getToComplete()));
        cost1.setTotal(BigDecimalUtil.add(cost1.getTotal(), cost2.getTotal()));

        if (cost2.isContinuing())
            cost1.setContinuing(true);
    }

    /**
     * Subtracts cost2 Costs from cost1 (cost1 is updated).
     *
     * @param cost1
     * @param cost2
     */
    public static void subtract(Costs cost1, Costs cost2)
    {
        cost1.setPriorYears(BigDecimalUtil.subtract(cost1.getPriorYears(), cost2.getPriorYears()));
        cost1.setPriorYear(BigDecimalUtil.subtract(cost1.getPriorYear(), cost2.getPriorYear()));
        cost1.setCurrentYear(BigDecimalUtil.subtract(cost1.getCurrentYear(), cost2.getCurrentYear()));
        cost1.setBy1(BigDecimalUtil.subtract(cost1.getBy1(), cost2.getBy1()));
        cost1.setBy1Base(BigDecimalUtil.subtract(cost1.getBy1Base(), cost2.getBy1Base()));
        cost1.setBy1Ooc(BigDecimalUtil.subtract(cost1.getBy1Ooc(), cost2.getBy1Ooc()));
        cost1.setBy2(BigDecimalUtil.subtract(cost1.getBy2(), cost2.getBy2()));
        cost1.setBy3(BigDecimalUtil.subtract(cost1.getBy3(), cost2.getBy3()));
        cost1.setBy4(BigDecimalUtil.subtract(cost1.getBy4(), cost2.getBy4()));
        cost1.setBy5(BigDecimalUtil.subtract(cost1.getBy5(), cost2.getBy5()));
        cost1.setToComplete(BigDecimalUtil.subtract(cost1.getToComplete(), cost2.getToComplete()));
        cost1.setTotal(BigDecimalUtil.subtract(cost1.getTotal(), cost2.getTotal()));
    }


//    @SuppressWarnings({ "rawtypes", "unchecked" })
//    private static boolean eq(Comparable n1, Comparable n2)
//    {
//        if (n1 == n2)
//            return true;
//        if (n1 == null && n2 == null)
//            return true;
//        if (n1 == null || n2 == null)
//            return false;
//        if (n1.compareTo(n2) != 0)
//            return false;
//        return true;
//    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_isPriorYears()
    {
        return getPriorYears() != null;
    }

    public boolean jibx_isPriorYear()
    {
        return getPriorYear() != null;
    }

    public boolean jibx_isCurrentYear()
    {
        return getCurrentYear() != null;
    }

    public boolean jibx_isBy1Base()
    {
        return getBy1Base() != null;
    }

    public boolean jibx_isBy1Ooc()
    {
        return getBy1Ooc() != null;
    }

    public boolean jibx_isBy1()
    {
        return getBy1() != null;
    }

    public boolean jibx_isBy2()
    {
        return getBy2() != null;
    }

    public boolean jibx_isBy3()
    {
        return getBy3() != null;
    }

    public boolean jibx_isBy4()
    {
        return getBy4() != null;
    }

    public boolean jibx_isBy5()
    {
        return getBy5() != null;
    }

    public boolean jibx_isToComplete()
    {
        return getToComplete() != null;
    }

    public boolean jibx_isTotal()
    {
        return getTotal() != null;
    }

    public boolean jibx_hasContinuingFootnote()
    {
      return !StringUtils.isEmpty(getContinuingFootnote());
    }

    @Override
    public String toString()
    {
        return "Type = "        + getType()        + ", " +
               "PYS = "         + getPriorYears()  + ", " +
               "PY = "          + getPriorYear()   + ", " +
               "CY = "          + getCurrentYear() + ", " +
               "BY1 = "         + getBy1()         + ", " +
               "BY1 Base = "    + getBy1Base()     + ", " +
               "BY1 OOC = "     + getBy1Ooc()      + ", " +
               "BY2 = "         + getBy2()         + ", " +
               "BY3 = "         + getBy3()         + ", " +
               "BY4 = "         + getBy4()         + ", " +
               "BY5 = "         + getBy5()         + ", " +
               "Total = "       + getTotal()       + ", " +
               "To Complete = " + getToComplete()  + ", " +
               "Continuing? "   + isContinuing();
    }
}
