package mil.dtic.cbes.p40.vo;

import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._ShipContract;

/**
 *
 */
public class ShipContract extends _ShipContract implements HasContractMethodFundingVehicle
{
    private static final long serialVersionUID = 1L;
    
    private P40ContractType jibxContractType;
    private P40ContractMethod jibxContractMethod;
    private P40FundingVehicle jibxFundingVehicle;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasShipHulls()
    {
      return CollectionUtils.isNotEmpty(getShipHulls());
    }
    
    public boolean jibx_hasContractData()
    {
      return jibx_hasShipbuilder()                ||
             jibx_hasFiscalYearAuthorizedDate()   ||
             jibx_hasContractAwardDate()          ||
             jibx_hasOptionAwardDate()            ||
             jibx_hasConstructionStartDate()      ||
             jibx_hasDeliveryDate()               ||
             jibx_hasCompletionOfFittingOutDate() ||
             jibx_hasObligationWorkLimitingDate() ||
             jibx_hasActualAwardDate()            ||
             jibx_hasRequestForProposalDates()    ||
             getJibxContractMethod() != null      ||
             getJibxContractType()   != null      ||
             getJibxFundingVehicle() != null;
    }
    
    public boolean jibx_hasEscalation()
    {
      return jibx_hasBaseDate()             ||
             jibx_hasTerminationDate()      ||
             jibx_hasRequirement()          ||
             jibx_hasLaborSplit()           ||
             jibx_hasMaterialSplit()        ||
             jibx_hasAllowableOverheadRate();
    }
    
    public boolean jibx_hasShipbuilder()
    {
      return StringUtils.isNotEmpty(getShipbuilder());
    }
    
    public boolean jibx_hasFiscalYearAuthorizedDate()
    {
      return getFiscalYearAuthorizedDate() != null;
    }
    
    public boolean jibx_hasContractAwardDate()
    {
      return getContractAwardDate() != null;
    }
    
    public boolean jibx_hasOptionAwardDate()
    {
      return getOptionAwardDate() != null;
    }
    
    public boolean jibx_hasConstructionStartDate()
    {
      return getConstructionStartDate() != null;
    }
    
    public boolean jibx_hasDeliveryDate()
    {
      return getDeliveryDate() != null;
    }
    
    public boolean jibx_hasCompletionOfFittingOutDate()
    {
      return getCompletionOfFittingOutDate() != null;
    }
    
    public boolean jibx_hasObligationWorkLimitingDate()
    {
      return getObligationWorkLimitingDate() != null;
    }
    
    public boolean jibx_hasActualAwardDate()
    {
      return getActualAwardDate() != null;
    }
    
    public boolean jibx_hasRequestForProposalDates()
    {
      return getRequestForProposalDates() != null;
    }
    
    // jibx unmarshal calls setters
    // postprocess reads _getters and sets ContractMethodTypeFundingVehicle
    // jibx marshal calls getters which read from
    // ContractMethodTypeFundingVehicle
    public P40ContractType getJibxContractType()
    {
      if (getContractMethodTypeFundingVehicle() != null)
        return getContractMethodTypeFundingVehicle().getContractType();
      else
        return null;
    }

    public P40ContractType _getJibxContractType()
    {
      return jibxContractType;
    }

    public void setJibxContractType(P40ContractType jibxContractType)
    {
      this.jibxContractType = jibxContractType;
    }

    public P40ContractMethod getJibxContractMethod()
    {
      if (getContractMethodTypeFundingVehicle() != null)
        return getContractMethodTypeFundingVehicle().getContractMethod();
      else
        return null;
    }

    public P40ContractMethod _getJibxContractMethod()
    {
      return jibxContractMethod;
    }

    public void setJibxContractMethod(P40ContractMethod jibxContractMethod)
    {
      this.jibxContractMethod = jibxContractMethod;
    }

    public P40FundingVehicle getJibxFundingVehicle()
    {
      if (getContractMethodTypeFundingVehicle() != null)
        return getContractMethodTypeFundingVehicle().getFundingVehicle();
      else
        return null;
    }

    public P40FundingVehicle _getJibxFundingVehicle()
    {
      return jibxFundingVehicle;
    }

    public void setJibxFundingVehicle(P40FundingVehicle jibxFundingVehicle)
    {
      this.jibxFundingVehicle = jibxFundingVehicle;
    }
    
    public boolean jibx_hasBaseDate()
    {
      return getBaseDate() != null;
    }
    
    public boolean jibx_hasTerminationDate()
    {
      return getTerminationDate() != null;
    }
    
    public boolean jibx_hasRequirement()
    {
      return getRequirement() != null;
    }
    
    public boolean jibx_hasLaborSplit()
    {
      return getLaborSplit() != null;
    }
    
    public boolean jibx_hasMaterialSplit()
    {
      return getMaterialSplit() != null;
    }
    
    public boolean jibx_hasAllowableOverheadRate()
    {
      return getAllowableOverhead() != null;
    }
        
    public boolean jibx_hasIsSignificant()
    {
      return getIsSignificant() != null;
    }
    
    public boolean jibx_hasPostShakedownAvailabilityStart()
    {
      return getPostShakedownAvailabilityStart() != null;
    }
        
    public boolean jibx_hasPostShakedownAvailabilityFinish()
    {
      return getPostShakedownAvailabilityFinish() != null;
    }
    
    public boolean jibx_hasShipOtherBasicItems()
    {
      return CollectionUtils.isNotEmpty(getShipOtherBasicItems());
    }
    
    public Iterator<ShipHull> jibx_shipHullsIterator()
    {
      return getShipHulls().iterator();
    }
    
    public Iterator<OtherBasicItems> jibx_shipOtherBasicItemsIterator()
    {
      return getShipOtherBasicItems().iterator();
    }
    
    
    

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
