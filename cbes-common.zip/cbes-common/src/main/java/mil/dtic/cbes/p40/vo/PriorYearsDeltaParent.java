package mil.dtic.cbes.p40.vo;


import java.math.BigDecimal;


/**
 *
 */
public interface PriorYearsDeltaParent
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    BigDecimal getPysDelta();
    void setPysDelta(BigDecimal priorYearsDelta);

    BigDecimal getPysQuantityDelta();
    void setPysQuantityDelta(BigDecimal priorYearsQuantityDelta);


    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    boolean jibx_hasPysCostDelta();
    boolean jibx_hasPysDelta();
    boolean jibx_hasPysQuantityDelta();
}
