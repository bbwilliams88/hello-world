package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._SparesRequirement;
import mil.dtic.cbes.p40.vo.util.EqualsPredicate;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.CbesLogFactory;

public class SparesRequirement extends _SparesRequirement implements HasDisplayOrder, ItemExhibitType, RollupParent, IsSubtotalParent, PriorYearsDeltaParent
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(SparesRequirement.class);


  @Override
  protected void onPostAdd()
  {
    setupP18();
  }


  @Override
  protected void onPostLoad()
  {
    setupP18();
  }


  public void setupP18()
  {
    if (getDisplayOrder() == null)
      this.setDisplayOrder(0);

    if (getTotalCosts() == null)
    {
      Costs cost = getObjectContext().newObject(Costs.class);
      cost.setType(CostRowType.TOTALCOST);
      this.setTotalCosts(cost);
    }

    if (getWorkingCapitalFundCosts() == null)
    {
      Costs workingCapitalFundCosts = getObjectContext().newObject(Costs.class);
      workingCapitalFundCosts.setType(CostRowType.TOTALCOST);
      this.setWorkingCapitalFundCosts(workingCapitalFundCosts);
    }

    if (getTotalExemptCosts() == null)
    {
      Costs totalExemptCosts = getObjectContext().newObject(Costs.class);
      totalExemptCosts.setType(CostRowType.TOTALCOST);
      this.setTotalExemptCosts(totalExemptCosts);
    }

    List<SparesList> sList = getSparesLists();
    if (sList != null && !sList.isEmpty())
    {
    	for (SparesList sl:sList) {
    		if (sl != null && sl.getSubtotalCosts() == null) { //why this is happening? just fix the bug for now
    			sl.setupSparesList();
    		}
    	}
    } else {
	    SparesList sl;
	    if (getInitialSparesList() == null)
	    {
	      sl = getObjectContext().newObject(SparesList.class);
	      //System.out.println(CostElementCategoryType.InitialSpares.toString());
	      //System.out.println("CEC CATEGORY HERE!!! : " + CostElementCategory.fetchByTitle(getObjectContext(), CostElementCategoryType.InitialSpares).getTitle());
	      sl.setCategory(CostElementCategory.fetchByTitle(getObjectContext(), CostElementCategoryType.InitialSpares));
	      this.addToSparesLists(sl);
	    }
	    if (getReplenishmentSparesList() == null)
	    {
	      sl = getObjectContext().newObject(SparesList.class);
	      sl.setCategory(CostElementCategory.fetchByTitleCached(getObjectContext(), CostElementCategoryType.ReplenishmentSpares));
	      this.addToSparesLists(sl);
	    }
    }
  }


  @Override
public void shiftForwardInTime(int years)
  {
    if (this.getTotalCosts() != null)
      this.getTotalCosts().shiftForwardInTime(years);
    for (SparesList sl : this.getSparesLists())
    {
      sl.shiftForwardInTime(years);
    }
    if (this.getWorkingCapitalFundCosts() != null)
      this.getWorkingCapitalFundCosts().shiftForwardInTime(years);
    if (this.getTotalExemptCosts() != null)
      this.getTotalExemptCosts().shiftForwardInTime(years);
  }


  public boolean jibx_hasInitial()
  {
    return(getInitialSparesList() != null && getInitialSparesList().getSparesBudgetActivities() != null && !getInitialSparesList().getSparesBudgetActivities().isEmpty());
  }


  public boolean jibx_hasReplenishment()
  {
    return(getReplenishmentSparesList() != null && getReplenishmentSparesList().getSparesBudgetActivities() != null && !getReplenishmentSparesList().getSparesBudgetActivities().isEmpty());
  }


  @Override
public boolean jibx_hasPysDelta()
  {
      // Check if there is a Prior Years Delta for this Line Item.
      if (getPysDelta() != null)
          return true;

      return false;
  }

  @Override
  public boolean jibx_hasPysQuantityDelta()
  {
    return false;
  }

  @Override
  public boolean jibx_hasPysCostDelta()
  {
    if(getPysDelta() != null)
      return true;
    else
      return false;
  }


  private SparesList getFixed(CostElementCategoryType cat)
  {
    // this probably throws an interesting exception when stuff corrupts
    return (SparesList) CollectionUtils.find(getSparesLists(),
      new EqualsPredicate(cat,
        makePath(SparesList.CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY)));
  }


  private void setFixed(SparesList sl, CostElementCategoryType cat)
  {
    SparesList existing = getFixed(cat);
    if (existing == null && sl != null)
    {
      sl.setCategory(CostElementCategory.fetchByTitleCached(getObjectContext(), cat));
      if (sl.getCategory() == null)
        log.error("category not found: " + cat, new NullPointerException("q"));
      addToSparesLists(sl);
    }
    else
    {
      log.debug("Don't use this to replace existing fixed cost elements");
    }
  }


  public SparesList getInitialSparesList()
  {
    return getFixed(CostElementCategoryType.InitialSpares);
  }


  public void setInitialSparesList(SparesList sl)
  {
    setFixed(sl, CostElementCategoryType.InitialSpares);
  }


  public SparesList getReplenishmentSparesList()
  {
    return getFixed(CostElementCategoryType.ReplenishmentSpares);
  }


  public void setReplenishmentSparesList(SparesList sl)
  {
    setFixed(sl, CostElementCategoryType.ReplenishmentSpares);
  }


  @Override
  public Costs getCosts()
  {
    return getTotalCosts();
  }


  @Override
  public List<? extends CostContainer> getChildren()
  {
    List<SparesItem> sparesItems = new ArrayList<SparesItem>();
    for(SparesList sparesList : getSparesLists())
    {
      for(SparesBudgetActivity activity : sparesList.getSparesBudgetActivities())
      {
        sparesItems.addAll(activity.getSparesItems());
      }
    }
    return sparesItems;
  }


  @Override
public String getIdentifyingString()
  {
    return getName();
  }


  @Override
  public Costs getUnitCosts()
  {
    return null;
  }


  @Override
  public Costs getQuantities()
  {
    return null;
  }


  public boolean jibx_hasTotalCosts()
  {
    return getTotalCosts() != null && !getTotalCosts().isEmpty();
  }


  public boolean jibx_hasName()
  {
    return(getName() != null);
  }


  public boolean jibx_hasWorkingCapitalFundCosts()
  {
    return getWorkingCapitalFundCosts() != null && !getWorkingCapitalFundCosts().isEmpty();
  }


  public boolean jibx_hasTotalExemptCosts()
  {
    return getTotalExemptCosts() != null && !getTotalExemptCosts().isEmpty();
  }


  @Override
  public void calculateSubtotals() throws MethodDispatchException
  {
    Costs subtotal = Costs.create(getObjectContext(), CostRowType.TOTALCOST);

    for (SparesList list : getSparesLists())
    {
      list.calculateSubtotals();
    }
    addToSubtotalInDollars(subtotal, getSparesLists());

//TODO: big question, why add pysdelta to subtotal?
//    BigDecimal pysDelta = getPysDelta();
//    if (pysDelta != null)
//    {
//      if (subtotal.getPriorYears() != null)
//        subtotal.setPriorYears(subtotal.getPriorYears().add(pysDelta));
//      else
//        subtotal.setPriorYears(new BigDecimal(pysDelta));
//      if (subtotal.getTotal() != null)
//        subtotal.setTotal(subtotal.getTotal().add(pysDelta));
//      else
//        subtotal.setTotal(new BigDecimal(pysDelta));
//    }
//    subtotal.setContinuing(isChildContinuing(getSparesLists()));
    replaceCosts(setSubtotalValuesInMillion(subtotal), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
  }

  @Override
  public void setPysQuantityDelta(BigDecimal value)
  {
    return;
  }

  @Override
  public BigDecimal getPysQuantityDelta()
  {
    return null;
  }
}
