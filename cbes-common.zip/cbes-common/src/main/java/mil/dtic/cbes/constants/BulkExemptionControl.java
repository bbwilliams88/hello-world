package mil.dtic.cbes.constants;
/**
 * Supports BulkExemption processing. Repository for constants and translations.
 */
public enum BulkExemptionControl {

    PROC("PROC", "PROC"), RDTE("RDTE", "RDTE"), ALL("ALL", "ALL"), ADD("ADD", "Add/Activate Exemptions"),
        REMOVE("REMOVE","Inactivate Exemptions"), STATUSA("A", "Active"), STATUSI("I", "Inactive");
    
    private String code;
    private String name;
    

    BulkExemptionControl(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

}
