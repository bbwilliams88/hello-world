package mil.dtic.cbes.exceptions;

// FIXME: In the future, make this a checked exception by subclassing
// Exception, which will require changes to other parts of the application.
public class InvalidFileTypeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public InvalidFileTypeException() { super(); }
    public InvalidFileTypeException(String message) { super(message); }
    public InvalidFileTypeException(String message, Throwable cause) { super(message, cause); }
    public InvalidFileTypeException(Throwable cause) { super(cause); }
}
