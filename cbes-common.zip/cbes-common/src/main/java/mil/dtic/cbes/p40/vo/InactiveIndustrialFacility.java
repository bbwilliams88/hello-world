package mil.dtic.cbes.p40.vo;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.auto._InactiveIndustrialFacility;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 *
 */
public class InactiveIndustrialFacility extends _InactiveIndustrialFacility
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(InactiveIndustrialFacility.class);


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    public void onPrePersist()
    {
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return
     */
    public List<InactiveIndustrialFacilityProject> getFacilityProjectList()
    {
        return getInactiveFacilityProjectList();
    }

    /**
     * @param inactiveIndustrialFacilityProjects
     */
    // FIXME: If this isn't implemented, why is it here?
    public void setFacilityProjectList(List<InactiveIndustrialFacilityProject> inactiveIndustrialFacilityProjects)
    {
        log.trace("Collection setters not implemented " +
                  (inactiveIndustrialFacilityProjects == null ? "- no facilities." : inactiveIndustrialFacilityProjects.size()));
    }

    /**
     * @see mil.dtic.cbes.p40.vo.auto._InactiveIndustrialFacility#getInactiveFacilityProjectList()
     */
    @Override
    public List<InactiveIndustrialFacilityProject> getInactiveFacilityProjectList()
    {
        return getSortedByDisplayOrder(super.getInactiveFacilityProjectList());
    }

    @Override
    public Costs getCosts()
    {
        Costs costs = new Costs();

        for (InactiveIndustrialFacilityProject project : getFacilityProjectList())
            costs.add(project.getCosts());

        return costs;
    }

    @Override
    public Costs getUnitCosts()
    {
        return null;
    }

    @Override
    public Costs getQuantities()
    {
        return null;
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    @Override
    public void shiftForwardInTime(int years)
    {
        for (InactiveIndustrialFacilityProject fp : this.getInactiveFacilityProjectList())
        {
            fp.shiftForwardInTime(years);
        }
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasInactiveFacilityProjectList()
    {
        return CollectionUtils.isNotEmpty(super.getInactiveFacilityProjectList());
    }

    public Iterator<InactiveIndustrialFacilityProject> jibx_InactiveFacilityProjectIterator()
    {
        return getIterator(super.getInactiveFacilityProjectList());
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(super.getInactiveFacilityProjectList());
    }
}
