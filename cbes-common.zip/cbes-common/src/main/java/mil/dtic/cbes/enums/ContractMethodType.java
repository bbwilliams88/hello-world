package mil.dtic.cbes.enums;


public enum ContractMethodType
{
  SS, C, TBD, Various;
}
