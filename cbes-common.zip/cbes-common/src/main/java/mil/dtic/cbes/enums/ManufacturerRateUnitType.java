package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ManufacturerRateUnitType implements ExtendedEnumeration
{
  /*
   * Note that the DB Enum supports QUARTERLY("Q")
   */
    MONTHLY("M", "Monthly"), YEARLY("A", "Yearly");

    private final String databaseValue, label;

    private ManufacturerRateUnitType(String dbName, String label)
    {
      this.databaseValue = dbName;
      this.label = label;
    }

    public String getDatabaseValue()
    {
      return databaseValue;
    }
    
    public String getLabel(){
      return this.label;
    }
    
    public static ManufacturerRateUnitType fromEnumValue(String enumValue)
    {
        return StringUtils.isNotEmpty(enumValue) ? EnumUtils.fromEnumValue(ManufacturerRateUnitType.class, StringUtils.upperCase(enumValue)) : null;
    }
}
