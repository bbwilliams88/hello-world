package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ShipFiscalYearFunding;

/**
 *
 */
public class ShipFiscalYearFunding extends _ShipFiscalYearFunding
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    
    public boolean jibx_hasFundingFromFiscalYear()
    {
      return getFundingFromFiscalYear() != null;
    }
    
    public void jibx_setFundingFromFiscalYear(ExtendedPYSCosts costs)
    {
      if (costs != null)
        costs.setType(CostRowType.TOTALCOST);
      setFundingFromFiscalYear(costs);
    }
    
    public boolean jibx_hasFiscalYearFundingObtainedFootnote()
    {
      return StringUtils.isNotEmpty(getFiscalYearFundingObtainedFootnote());
    }
    

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
