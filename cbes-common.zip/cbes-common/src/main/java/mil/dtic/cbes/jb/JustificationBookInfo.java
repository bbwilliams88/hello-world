/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.p40.vo.IBase;

public class JustificationBookInfo implements IBase
{
  private static final long serialVersionUID = -491979958392494576L;
  private String description;
  private String label;
  private String number;
  private JustificationBook jb;
  private String t5Id;

  public JustificationBookInfo()
  {
    
  }
    
  public String getDescription()
  {
    return description;
  }


  public void setDescription(String description)
  {
    this.description = description;
  }


  public String getLabel()
  {
    return label;
  }


  public void setLabel(String label)
  {
    this.label = label;
  }


  public String getNumber()
  {
    return number;
  }


  public void setNumber(String number)
  {
    this.number = number;
  }


  public JustificationBook getJb()
  {
    return jb;
  }


  public void setJb(JustificationBook jb)
  {
    this.jb = jb;
  }


  public String getT5Id()
  {
    return t5Id;
  }


  public void setT5Id(String t5Id)
  {
    this.t5Id = t5Id;
  }

  public Integer getId()
  {
    return null;
  }
  
}
