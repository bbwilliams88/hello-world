package mil.dtic.cbes.exceptions;

public class MethodDispatchException extends Exception
{
    private static final long serialVersionUID = 1L;

    public MethodDispatchException() { super(); }                                              // NOSONAR
    public MethodDispatchException(String message) { super(message); }                         // NOSONAR
    public MethodDispatchException(String message, Throwable cause) { super(message, cause); } // NOSONAR
    public MethodDispatchException(Throwable cause) { super(cause); }                          // NOSONAR
}
