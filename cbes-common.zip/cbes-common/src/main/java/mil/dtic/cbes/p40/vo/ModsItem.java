package mil.dtic.cbes.p40.vo;

import static java.math.BigDecimal.ZERO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.InstallationScheduleType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._ModsItem;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.Util;

/**
 *
 */
public class ModsItem extends _ModsItem implements HasTripletCosts, CostElementParent, HasDisplayOrder, CostContainer, IsSubtotalParent, Equivalence<ModsItem>, RollupParent
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    /**
     * The UI requires child relationships to be present and needs the display
     * order to be set, so this is done automatically whenever a new item is
     * created.
     *
     * @see mil.dtic.cbes.p40.vo.auto._ModsItem#onPostAdd()
     */
    @Override
    protected void onPostAdd()
    {
        initializeChildRelationships();
        setDisplayOrder(0);
    }

    /**
     * The UI requires child relationships to be present, so this is done
     * automatically whenever an existing item is loaded. Normally, these would
     * already be present because they are added upon item creation, but
     * historical items may lack the relationships, especially when imported
     * from XML.
     *
     * @see mil.dtic.cbes.p40.vo.auto._ModsItem#onPostLoad()
     */
    @Override
    protected void onPostLoad()
    {
        initializeChildRelationships();
    }

    /**
     * When saving a new item, clear out non-organic installation totals if
     * there are no non-organic installations present.
     *
     * @see mil.dtic.cbes.p40.vo.auto._ModsItem#onPrePersist()
     */
    @Override
    protected void onPrePersist()
    {
        if (isNonOrganicInstallationPresent() == false)
            clearNonOrganicInstallationTotals();
    }

    /**
     * When saving a existing item, clear out non-organic installation totals if
     * there are no non-organic installations present.
     *
     * @see mil.dtic.cbes.p40.vo.auto._ModsItem#onPreUpdate()
     */
    @Override
    protected void onPreUpdate()
    {
        if (isNonOrganicInstallationPresent() == false)
            clearNonOrganicInstallationTotals();
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    public CostElement getAKitCategory()
    {
        return getFixed(CostElementCategoryType.AKit);
    }

    public void setAKitCategory(CostElement costElement)
    {
        setFixed(costElement, getAKitCategory(), CostElementCategoryType.AKit);
    }

    public CostElement getBKitCategory()
    {
        return getFixed(CostElementCategoryType.BKit);
    }

    public void setBKitCategory(CostElement costElement)
    {
        setFixed(costElement, getBKitCategory(), CostElementCategoryType.BKit);
    }

    @Override
    public boolean isContinuing()
    {
        return getTotalCosts() != null && getTotalCosts().isContinuing();
    }


    /**
     * @see mil.dtic.cbes.p40.vo.auto._ModsItem#getCostElements()
     *
     * @return Returns the cost elements sorted by display order.
     */
    // FIXME: Rename method to getOrderedCostElements.
    @Override
    public List<CostElement> getCostElements()
    {
        return getSortedByDisplayOrder(super.getCostElements());
    }

    //FIXME We should change the getTotalCosts() to getCosts()
    @Override
    public Costs getCosts()
    {
        return getTotalCosts();
    }

    private CostElement getFixed(CostElementCategoryType costElementCategory)
    {
        return getFixedCe(COST_ELEMENTS_RELATIONSHIP_PROPERTY, costElementCategory);
    }

    // FIXME: Existing must be null or this method fails.
    private void setFixed(CostElement costElement, CostElement existing, CostElementCategoryType costElementCategory)
    {
        setFixedCe(COST_ELEMENTS_RELATIONSHIP_PROPERTY, costElement, existing, costElementCategory);
    }

    @Override
    // FIXME: This should be getOrderedImplementationMethods().
    public List<ModsImplementationMethod> getImplementationMethods()
    {
        return getSortedByDisplayOrder(super.getImplementationMethods());
    }

    public boolean isInstallContinuing()
    {
        return getInstallationCosts().isContinuing();
    }

    public void setInstallContinuing(boolean b)
    {
        if (getInstallationCosts() != null)
            getInstallationCosts().setContinuing(b);

        if (getInstallationQuantities() != null)
            getInstallationQuantities().setContinuing(b);
    }

    /**
     * Override to prevent JiBX from nulling out the relationship created in
     * onPostAdd().
     */
    @Override
    public void setInstallationCosts(Costs installationCosts)
    {
        if (installationCosts == null)
            return;
        else
            super.setInstallationCosts(installationCosts);
    }

    /**
     * Override to prevent JiBX from nulling out the relationship created in
     * onPostAdd().
     */
    @Override
    public void setInstallationQuantities(Costs installationQuantities)
    {
        if (installationQuantities == null)
            return;
        else
            super.setInstallationQuantities(installationQuantities);
    }

    @Override
    public List<ModsManufacturer> getManufacturers()
    {
        return getSortedByDisplayOrder(super.getManufacturers());
    }

    public boolean isNonOrganicInstallationPresent()
    {
        if (getImplementationMethods() != null && !getImplementationMethods().isEmpty())
            for (ModsImplementationMethod implMethod : getImplementationMethods())
                if (implMethod.isNonOrganic())
                    return true;

        return false;
    }

    // FIXME: This is poorly named. Should be an is* method to be JavaBean
    // compliant.
    public boolean hasNonOrganicInstallation()
    {
        return isNonOrganicInstallationPresent();
    }

    @Override
    public List<OtherPe> getOtherPes()
    {
        return getSortedByDisplayOrder(super.getOtherPes());
    }

//    public P10AdvanceProcurement addAdvanceProcurement()
//    {
//      if(getAdvanceProcurement() != null)
//        getAdvanceProcurement().delete();
//      setAdvanceProcurement(getObjectContext().newObject(P10AdvanceProcurement.class));
//
//      return getAdvanceProcurement();
//    }
    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    public CostElement addAKit()
    {
        if (getAKitCategory() == null)
            setAKitCategory(getObjectContext().newObject(CostElement.class));

        if (getAKitCategory().getRecurring() == null)
            getAKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));

        return getAKitCategory().getRecurring().addCostElement("");
    }

    public CostElement addAKitRecurring()
    {
        if (getAKitCategory() == null)
            setAKitCategory(getObjectContext().newObject(CostElement.class));

        if (getAKitCategory().getRecurring() == null)
            getAKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));

        return getAKitCategory().getRecurring().addCostElement("");
    }

    public CostElement addAKitNonRecurring()
    {
        if (getAKitCategory() == null)
            setAKitCategory(getObjectContext().newObject(CostElement.class));

        if (getAKitCategory().getNonRecurring() == null)
            getAKitCategory().setNonRecurring(getObjectContext().newObject(CostElement.class));

        return getAKitCategory().getNonRecurring().addCostElement("");
    }

    public List<CostElement> getAKitRecurringNonRecurrings()
    {
        List<CostElement> recNonRecList = null;
        CostElement       aKitCategory  = getAKitCategory();

        if (aKitCategory != null)
            recNonRecList = aKitCategory.getCostElementList();

        return (recNonRecList == null ? new ArrayList<CostElement>() : recNonRecList);
    }

    public CostElement addBKitRecurring()
    {
        if (getBKitCategory() == null)
            setBKitCategory(getObjectContext().newObject(CostElement.class));

        if (getBKitCategory().getRecurring() == null)
            getBKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));

        return getBKitCategory().getRecurring().addCostElement("");
    }

    public CostElement addBKitNonRecurring()
    {
        if (getBKitCategory() == null)
            setBKitCategory(getObjectContext().newObject(CostElement.class));

        if (getBKitCategory().getNonRecurring() == null)
            getBKitCategory().setNonRecurring(getObjectContext().newObject(CostElement.class));

        return getBKitCategory().getNonRecurring().addCostElement("");
    }

    public List<CostElement> getBKitRecurringNonRecurrings()
    {
        List<CostElement> recNonRecList = null;
        CostElement       bKitCategory  = getBKitCategory();

        if (bKitCategory != null)
            recNonRecList = bKitCategory.getCostElementList();

        return (recNonRecList == null ? new ArrayList<CostElement>() : recNonRecList);
    }

    public List<CostElement> getAllAKitBKitRecurringNonRecurringCostElements()
    {
        List<CostElement> allLowestLevelCostElements = new ArrayList<CostElement>();
        if(getAKitCategory() != null && getAKitCategory().getRecurring() != null)
          allLowestLevelCostElements.addAll(getAKitCategory().getRecurring().getCostElementList());
        if(getAKitCategory() != null && getAKitCategory().getNonRecurring() != null)
          allLowestLevelCostElements.addAll(getAKitCategory().getNonRecurring().getCostElementList());
        if(getBKitCategory() != null && getBKitCategory().getRecurring() != null)
          allLowestLevelCostElements.addAll(getBKitCategory().getRecurring().getCostElementList());
        if(getBKitCategory() != null && getBKitCategory().getNonRecurring() != null)
          allLowestLevelCostElements.addAll(getBKitCategory().getNonRecurring().getCostElementList());

        return allLowestLevelCostElements;
    }

    public void removeAKit(CostElement kit)
    {
        CostElement sub = kit.getParentCostElement();

        sub.deleteCostElement(kit);
    }

    public CostElement addBKit()
    {
        if (getBKitCategory() == null)
            setBKitCategory(getObjectContext().newObject(CostElement.class));
        if (getBKitCategory().getRecurring() == null)
            getBKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));
        return getBKitCategory().getRecurring().addCostElement("");
    }

    public void removeBKit(CostElement kit)
    {
        CostElement sub = kit.getParentCostElement();

        sub.deleteCostElement(kit);
    }

    public void cleanUpABKit()
    {
        if (getAKitCategory() != null)
        {
            cleanUpCategory(getAKitCategory().getNonRecurring());
            cleanUpCategory(getAKitCategory().getRecurring());
            cleanUpCategory(getAKitCategory());
        }
        if (getBKitCategory() != null)
        {
            cleanUpCategory(getBKitCategory().getNonRecurring());
            cleanUpCategory(getBKitCategory().getRecurring());
            cleanUpCategory(getBKitCategory());
        }
    }

    private void cleanUpCategory(CostElement category)
    {
        if (category != null && (category.getCostElementList() == null || category.getCostElementList().isEmpty())) // no children
        {
            category.getTotalCosts().clearValues();
            category.getQuantities().clearValues();
            category.getUnitCosts().clearValues();
        }
    }

    /**
     * Creates a new empty CostElement and adds it to the to-many CostElement
     * relationship.
     *
     * @see mil.dtic.cbes.p40.vo.CostElementParent#addCostElement()
     */
    @Override
    public CostElement addCostElement()
    {
        CostElement costElement = getObjectContext().newObject(CostElement.class);

        addToCostElements(costElement);
        Util.generateDisplayOrder(super.getCostElements());

        return costElement;
    }

    /**
     * Removes the given CostElement from the to-many relationship and flags it
     * for deletion in the ObjectContext.
     *
     * @see mil.dtic.cbes.p40.vo.CostElementParent#removeCostElement(mil.dtic.cbes.p40.vo.CostElement)
     */
    @Override
    public void removeCostElement(CostElement costElement)
    {
        removeFromCostElements(costElement);
        getObjectContext().deleteObjects(costElement);
    }

    /**
     * Clears the values in installation costs/quantities.
     */
    public void clearNonOrganicInstallationTotals()
    {
        getInstallationQuantities().clearValues();
        getInstallationCosts().clearValues();
    }

    /**
     * Creates a new implementation method, of the type specified by the 'organic' flag.  Will auto create and add an in and out installation schedule
     * and add them to a new non-organic implementation.  Does not create installation costs.  Organic installations must always have a non-null value
     * for quantity, defaults to zero.
     *
     * @param organic flag to indicate whether the new installation method should be of the organic or non organic type. Organic will only have a name
     * and quantity, non-organic will have an entire cost table and installation schedule.
     * @return the newly created installation schedule.
     */
    public ModsImplementationMethod addImplementationMethod(boolean organic)
    {
        ModsImplementationMethod method = getObjectContext().newObject(ModsImplementationMethod.class);

        if (organic)
        {
            method.setOrganicQuantity(ZERO);
        }
        else
        {
            method.addToInstallationSchedules(getObjectContext().newObject(InstallationSchedule.class));
            method.addToInstallationSchedules(getObjectContext().newObject(InstallationSchedule.class));
            method.getInstallationSchedules().get(0).setType(InstallationScheduleType.IN);
            method.getInstallationSchedules().get(1).setType(InstallationScheduleType.OUT);
        }

        method.setDisplayOrder(Util.getNextDisplayOrderValue(super.getImplementationMethods()));
        addToImplementationMethods(method);

        return method;
    }

    /**
     * Removes the given implementation method from the to-many relationship and
     * flags it for deletion in the ObjectContext.
     *
     * @param implementationMethod
     */
    public void removeImplementationMethod(ModsImplementationMethod implementationMethod)
    {
        removeFromImplementationMethods(implementationMethod);
        getObjectContext().deleteObjects(implementationMethod);
    }

    /**
     * The UI expects several relationships to exist. This method creates all of
     * the expected relationships.
     */
    private void initializeChildRelationships()
    {
        if (getQuantities() == null)
            setQuantities(Costs.create(getObjectContext(), CostRowType.QUANTITY));

        if (getTotalCosts() == null)
            setTotalCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

        if (getInstallationQuantities() == null)
            setInstallationQuantities(Costs.create(getObjectContext(), CostRowType.QUANTITY));

        if (getInstallationCosts() == null)
            setInstallationCosts(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

        if (getAKitCategory() == null)
            setAKitCategory(getObjectContext().newObject(CostElement.class));
        if (getAKitCategory().getRecurring() == null)
            getAKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));
        if (getAKitCategory().getNonRecurring() == null)
            getAKitCategory().setNonRecurring(getObjectContext().newObject(CostElement.class));

        if (getBKitCategory() == null)
            setBKitCategory(getObjectContext().newObject(CostElement.class));
        if (getBKitCategory().getRecurring() == null)
            getBKitCategory().setRecurring(getObjectContext().newObject(CostElement.class));
        if (getBKitCategory().getNonRecurring() == null)
            getBKitCategory().setNonRecurring(getObjectContext().newObject(CostElement.class));
    }

    public ModsManufacturer addManufacturer()
    {
        ModsManufacturer manufacturer = getObjectContext().newObject(ModsManufacturer.class);

        addToManufacturers(manufacturer);

        return manufacturer;
    }

    @Override
    public void addToManufacturers(ModsManufacturer obj)
    {
    	super.addToManufacturers(obj);
    	Util.generateDisplayOrder(super.getManufacturers());
    }

    /**
     * Removes the given manufacturer from the to-many relationship and flags it
     * for deletion in the ObjectContext.
     *
     * @param manufacturer
     */
    public void removeManufacturer(ModsManufacturer manufacturer)
    {
        removeFromManufacturers(manufacturer);
        getObjectContext().deleteObjects(manufacturer);
    }

    public OtherPe addPe()
    {
        OtherPe programElement = getObjectContext().newObject(OtherPe.class);

        programElement.jibx_FundingPreSet();
        addToOtherPes(programElement);
        Util.generateDisplayOrder(getOtherPes());

        return programElement;
    }

    /**
     * Removes the given program element from the to-many relationship and flags
     * it for deletion in the ObjectContext.
     *
     * @param programElement
     */
    public void removePe(OtherPe programElement)
    {
        removeFromOtherPes(programElement);
        getObjectContext().deleteObjects(programElement);
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        for (CostElement ce : this.getCostElements())
            ce.shiftForwardInTime(years);

        for (ModsImplementationMethod mim : this.getImplementationMethods())
            mim.shiftForwardInTime(years);

        for (OtherPe op : this.getOtherPes())
            op.shiftForwardInTime(years);

        for (ModsManufacturer modManu : this.getManufacturers())
            modManu.shiftForwardInTime(years);

        if (this.getInstallationCosts() != null)
            this.getInstallationCosts().shiftForwardInTime(years);

        if (this.getInstallationQuantities() != null)
            this.getInstallationQuantities().shiftForwardInTime(years);

        if (this.getTotalCosts() != null)
            this.getTotalCosts().shiftForwardInTime(years);

        if (this.getQuantities() != null)
            this.getQuantities().shiftForwardInTime(years);

//        if (this.getAdvanceProcurement() != null)
//            this.getAdvanceProcurement().shiftForwardInTime(years);
    }

    /**
     * Calculating the Subtotals for each category. Uses the CostElement to
     * calculate the subtotals for both the A kits and B Kits
     * @throws MethodDispatchException
     */
    @Override
    public void calculateSubtotals() throws MethodDispatchException
    {
        getAKitCategory().calculateSubtotals();
        getBKitCategory().calculateSubtotals();

        Costs procurementSubtotal = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
        Costs installationSubtotal = Costs.create(getObjectContext(), CostRowType.TOTALCOST);

        // Can use the Total Cost here instead of calculating it because there is no UC.
        addToSubtotalInDollars(procurementSubtotal, getAKitCategory().getCostElementList());

        // Can use the Total Cost here instead of calculating it because there is no UC.
        addToSubtotalInDollars(procurementSubtotal, getBKitCategory().getCostElementList());

        List<CostContainer> installCosts = new ArrayList<CostContainer>();
        for (ModsImplementationMethod implementationMethod : getImplementationMethods())
        {
          installCosts.addAll(implementationMethod.getInstallationCostsForRollup());
        }
        addToSubtotalInDollars(installationSubtotal, installCosts);

        replaceCosts(setSubtotalValuesInMillion(procurementSubtotal), TOTAL_COSTS_RELATIONSHIP_PROPERTY);
        replaceCosts(setSubtotalValuesInMillion(installationSubtotal), INSTALLATION_COSTS_RELATIONSHIP_PROPERTY);
    }

    private boolean hasChildren(List<CostElement> costElements)
    {
        boolean hasChildren = false;

        if (costElements != null)
        {
            for (CostElement costElement : costElements)
            {
                hasChildren = costElement != null && costElement.getCostElementList() != null && !costElement.getCostElementList().isEmpty();

                if (hasChildren)
                    return hasChildren;
            }
        }

        return hasChildren;
    }

    public List<? extends CostContainer> getChildrenWithoutAdvanceProcurement()
    {
        // This is used to calcuate the Procurement Rollup
        List<CostContainer> children = new ArrayList<CostContainer>();

        for(CostElement kit : getCostElements())
        {
          for(CostElement category : kit.getCostElementList())
          {
            children.addAll(category.getCostElementList());
          }
        }

        return children;
    }

    @Override
    public List<? extends CostContainer> getChildren()
    {
        // This is used to calcuate the Procurement Rollup
        List<CostContainer> children = new ArrayList<CostContainer>();

        for(CostElement kit : getCostElements())
        {
          for(CostElement category : kit.getCostElementList())
          {
            children.addAll(category.getCostElementList());
          }
        }
//
//        if (this.getAdvanceProcurement() != null)
//        {
//          children.addAll(this.getAdvanceProcurement().getChildren());
//        }

        return children;
    }

    @Override
    public Costs getUnitCosts()
    {
        // FIXME This needs to use HasTotalCostAndQuantity not HasTripletCost
        return null;
    }

    @Override
    public void setUnitCosts(Costs c)
    {
        // FIXME This needs to use HasTotalCostAndQuantity not HasTripletCost
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasTitle()
    {
      return getTitle() != null;
    }

    public boolean jibx_hasProcurement()
    {
      return jibx_hasTotalCostsOrQuantities() || jibx_hasManufacturer() || jibx_hasAKitCategory() || jibx_hasBKitCategory();
    }

    public boolean jibx_hasAKitCategory()
    {
        return getAKitCategory() != null && getAKitCategory().getCostElementList() != null && !getAKitCategory().getCostElementList().isEmpty() && hasChildren(getAKitCategory().getCostElementList());
    }

    public boolean jibx_hasBKitCategory()
    {
        return getBKitCategory() != null && getBKitCategory().getCostElementList() != null && !getBKitCategory().getCostElementList().isEmpty() && hasChildren(getBKitCategory().getCostElementList());
    }

    public void jibx_postSet()
    {
        Util.generateDisplayOrder(super.getOtherPes());
        Util.generateDisplayOrder(super.getManufacturers());
        Util.generateDisplayOrder(super.getImplementationMethods());
    }

    public boolean jibx_hasOtherPes()
    {
        return CollectionUtils.isNotEmpty(getOtherPes());
    }

    public Iterator<OtherPe> jibx_OtherPeIterator()
    {
        return getOtherPes().iterator();
    }

    public Iterator<ModsManufacturer> jibx_ManufacturerIterator()
    {
        return getIterator(getManufacturers());
    }

    public Iterator<ModsImplementationMethod> jibx_ImplementationMethodIterator()
    {
        return getIterator(getImplementationMethods());
    }

    public Iterator<IndividualModInstallation> jibx_IndividualModInstallationIterator()
    {
      // should this be ordered
      return getIndividualModInstallations().iterator();
    }

    @Override
    public boolean jibx_hasQuantity()
    {
        return getQuantities() != null && getQuantities().isNotEmpty();
    }

    @Override
    public boolean jibx_hasTotalCost()
    {
        return getTotalCosts() != null && getTotalCosts().isNotEmpty();
    }

    @Override
    public boolean jibx_hasUnitCost()
    {
        // P3a Mod Items do not have Unit Cost!
        return false;
    }

    public boolean jibx_hasInstallationPriorYears()
    {
        return jibx_hasInstallationPriorYearsQuantities() || jibx_hasInstallationPriorYearsCosts();
    }

    public boolean jibx_hasInstallationPriorYear()
    {
        return jibx_hasInstallationPriorYearQuantities() || jibx_hasInstallationPriorYearCosts();
    }

    public boolean jibx_hasInstallationCurrentYear()
    {
        return jibx_hasInstallationCurrentYearQuantities() || jibx_hasInstallationCurrentYearCosts();
    }

    public boolean jibx_hasInstallationBy1Base()
    {
        return jibx_hasInstallationBy1BaseQuantities() || jibx_hasInstallationBy1BaseCosts();
    }

    public boolean jibx_hasInstallationBy1Ooc()
    {
        return jibx_hasInstallationBy1OocQuantities() || jibx_hasInstallationBy1OocCosts();
    }

    public boolean jibx_hasInstallationBy1()
    {
        return jibx_hasInstallationBy1Quantities() || jibx_hasInstallationBy1Costs();
    }

    public boolean jibx_hasInstallationBy2()
    {
        return jibx_hasInstallationBy2Quantities() || jibx_hasInstallationBy2Costs();
    }

    public boolean jibx_hasInstallationBy3()
    {
        return jibx_hasInstallationBy3Quantities() || jibx_hasInstallationBy3Costs();
    }

    public boolean jibx_hasInstallationBy4()
    {
        return jibx_hasInstallationBy4Quantities() || jibx_hasInstallationBy4Costs();
    }

    public boolean jibx_hasInstallationBy5()
    {
        return jibx_hasInstallationBy5Quantities() || jibx_hasInstallationBy5Costs();
    }

    public boolean jibx_hasInstallationToComplete()
    {
        return ((getInstallationQuantities() != null && getInstallationQuantities().jibx_isToComplete()) || (getInstallationCosts() != null && getInstallationCosts().jibx_isToComplete()));
    }

    public boolean jibx_hasInstallationTotal()
    {
        return ((getInstallationQuantities() != null && getInstallationQuantities().jibx_isTotal()) || (getInstallationCosts() != null && getInstallationCosts().jibx_isTotal()));
    }

    @Override
    public String jibx_getContinuingFootnote()
    {
        return getTotalCosts().getContinuingFootnote();
    }

    @Override
    public void jibx_setContinuingFootnote(String s)
    {
        getTotalCosts().setContinuingFootnote(s);
    }

    public boolean jibx_hasInstallationPriorYearsQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isPriorYears();
    }

    public boolean jibx_hasInstallationPriorYearQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isPriorYear();
    }

    public boolean jibx_hasInstallationCurrentYearQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isCurrentYear();
    }

    public boolean jibx_hasInstallationBy1BaseQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().getBy1Base() != null;
    }

    public boolean jibx_hasInstallationBy1OocQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().getBy1Ooc() != null;
    }

    public boolean jibx_hasInstallationBy1Quantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isBy1();
    }

    public boolean jibx_hasInstallationBy2Quantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isBy2();
    }

    public boolean jibx_hasInstallationBy3Quantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isBy3();
    }

    public boolean jibx_hasInstallationBy4Quantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isBy4();
    }

    public boolean jibx_hasInstallationBy5Quantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return getInstallationQuantities().jibx_isBy5();
    }

    public boolean jibx_hasInstallationToCompleteQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return !getInstallationCosts().isContinuing() && getInstallationQuantities().jibx_isToComplete();
    }

    public boolean jibx_hasInstallationTotalQuantities()
    {
        if (getInstallationQuantities() == null)
            return false;

        return !getInstallationCosts().isContinuing() && getInstallationQuantities().jibx_isTotal();
    }

    public boolean jibx_hasInstallationPriorYearsCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isPriorYears();
    }

    public boolean jibx_hasInstallationPriorYearCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isPriorYear();
    }

    public boolean jibx_hasInstallationCurrentYearCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isCurrentYear();
    }

    public boolean jibx_hasInstallationBy1BaseCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().getBy1Base() != null;
    }

    public boolean jibx_hasInstallationBy1OocCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().getBy1Ooc() != null;
    }

    public boolean jibx_hasInstallationBy1Costs()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isBy1();
    }

    public boolean jibx_hasInstallationBy2Costs()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isBy2();
    }

    public boolean jibx_hasInstallationBy3Costs()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isBy3();
    }

    public boolean jibx_hasInstallationBy4Costs()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isBy4();
    }

    public boolean jibx_hasInstallationBy5Costs()
    {
        if (getInstallationCosts() == null)
            return false;

        return getInstallationCosts().jibx_isBy5();
    }

    public boolean jibx_hasInstallationToCompleteCosts()
    {
        if (getInstallationCosts() == null)
            return false;

        return !getInstallationCosts().isContinuing() && getInstallationCosts().jibx_isToComplete();
    }

    public boolean jibx_hasIndividualModInstallations()
    {
        return getIndividualModInstallations() != null && !getIndividualModInstallations().isEmpty();
    }

    // public boolean jibx_hasInstallationTotalCosts()
    // {
    // if (getInstallationCosts() == null)
    // return false;
    //
    // return ! getInstallationCosts().isContinuing() &&
    // getInstallationCosts().jibx_isTotal();
    // }
    public boolean jibx_hasInstallationQuantity()
    {
        return getInstallationQuantities() != null && !getInstallationQuantities().isEmpty();
    }

    public boolean jibx_hasInstallationCosts()
    {
        return getInstallationCosts() != null && !getInstallationCosts().isEmpty();
    }

    public boolean jibx_hasInstallationCategorySubtotal()
    {
        return (getInstallationCosts() != null && !getInstallationCosts().isEmpty()) || (getInstallationQuantities() != null && !getInstallationQuantities().isEmpty());
    }

    public boolean jibx_hasProcurementTotalCost()
    {
        return jibx_hasTotalCostsOrQuantities();
    }

    public boolean jibx_hasManufacturer()
    {
        return !CollectionUtils.isEmpty(getManufacturers());
    }

    public boolean jibx_hasInstallation()
    {
        return !CollectionUtils.isEmpty(getImplementationMethods());
    }

    public boolean jibx_hasTotalCostsOrQuantities()
    {
        return (getTotalCosts() != null && !getTotalCosts().isEmpty()) || (getQuantities() != null && !getQuantities().isEmpty());
    }

    public boolean jibx_hasTotalCostsOrQuantitiesOrUnitCosts()
    {
        return (getTotalCosts() != null && !getTotalCosts().isEmpty()) || (getQuantities() != null && !getQuantities().isEmpty()) || (getUnitCosts() != null && !getUnitCosts().isEmpty());
    }

    @Override
    public void jibx_setQuantities(Costs quantities)
    {
        if (quantities != null)
            setQuantities(quantities);
    }

    @Override
    public void jibx_setTotalCosts(Costs totalCosts)
    {
        if (totalCosts != null)
            setTotalCosts(totalCosts);
    }

    @Override
    public void jibx_setUnitCosts(Costs unitCosts)
    {
        if (unitCosts != null)
            setUnitCosts(unitCosts);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        if (this.getPersistenceState() == PersistenceState.DELETED)
            return super.hashCode();

        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(toLowerAndTrim(getTitle()));
        builder.append(getItemGroup());

        return builder.toHashCode();
    }

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(ModsItem obj)
    {
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        EqualsBuilder builder = new EqualsBuilder();
        ModsItem      other  = obj;

        if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
            return super.equals(obj);

        builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
        builder.append(getItemGroup(), other.getItemGroup());

        return builder.isEquals();
    }
}
