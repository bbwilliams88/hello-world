package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._RelatedPe;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.Util;

public abstract class RelatedPe extends _RelatedPe implements HasTripletCosts, HasDisplayOrder, Equivalence<RelatedPe>
{
  private static final long serialVersionUID = 1L;



  @Override
  public void onPostAdd()
  {
    setDisplayOrder(0);
  }

  @Override
  public void onPrePersist()
  {
    Util.cleanupContinuingTriplet(this);
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getTotalCosts() != null)
      this.getTotalCosts().shiftForwardInTime(years);
    if (this.getQuantities() != null)
      this.getQuantities().shiftForwardInTime(years);
  }

  public void jibx_FundingPreSet()
  {
    setQuantities(getObjectContext().newObject(Costs.class));
    setTotalCosts(getObjectContext().newObject(Costs.class));
    getQuantities().setType(CostRowType.QUANTITY);
    getTotalCosts().setType(CostRowType.TOTALCOST);
  }

  public boolean jibx_hasPriorYears() {
    return getQuantities().jibx_isPriorYears() || getTotalCosts().jibx_isPriorYears();
  }

  public boolean jibx_hasPriorYear() {
    return getQuantities().jibx_isPriorYear() || getTotalCosts().jibx_isPriorYear();
  }

  public boolean jibx_hasCurrentYear() {
    return getQuantities().jibx_isCurrentYear() || getTotalCosts().jibx_isCurrentYear();
  }

  public boolean jibx_hasBy1Base() {
    return getQuantities().getBy1Base() != null || getTotalCosts().getBy1Base() != null;
  }

  public boolean jibx_hasBy1Ooc() {
    return getQuantities().getBy1Ooc() != null || getTotalCosts().getBy1Ooc() != null;
  }

  public boolean jibx_hasBy1() {
    return getQuantities().jibx_isBy1() || getTotalCosts().jibx_isBy1();
  }

  public boolean jibx_hasBy2() {
    return getQuantities().jibx_isBy2() || getTotalCosts().jibx_isBy2();
  }

  public boolean jibx_hasBy3() {
    return getQuantities().jibx_isBy3() || getTotalCosts().jibx_isBy3();
  }

  public boolean jibx_hasBy4() {
    return getQuantities().jibx_isBy4() || getTotalCosts().jibx_isBy4();
  }

  public boolean jibx_hasBy5() {
    return getQuantities().jibx_isBy5() || getTotalCosts().jibx_isBy5();
  }

  public boolean jibx_hasToComplete() {
    return !isContinuing() && (getQuantities().jibx_isToComplete() || getTotalCosts().jibx_isToComplete());
  }

  public boolean jibx_hasTotal() {
    return !isContinuing() && (getQuantities().jibx_isTotal() || getTotalCosts().jibx_isTotal());
  }

  @Override
  public String jibx_getContinuingFootnote()
  {
    return getTotalCosts().getContinuingFootnote();
  }


  @Override
  public void jibx_setContinuingFootnote(String s)
  {
    getTotalCosts().setContinuingFootnote(s);
  }

  @Override
  public Costs getUnitCosts()
  {
    return new Costs(); //unused, shut up jibx
  }

  @Override
  public void setUnitCosts(Costs c)
  {
    //no unit costs in mods
  }

  @Override
  public boolean isContinuing()
  {
    return getTotalCosts() != null && getTotalCosts().isContinuing();
  }


  /**
   * HashCode based on Business Rule [E-XML-PROC#U150]
   */
  @Override
  public int equivalenceHashCode()
  {
    HashCodeBuilder builder = new HashCodeBuilder();
    builder.append(toLowerAndTrim(getProgramElementNumber()));
    return builder.toHashCode();
  }


  /**
   * Equality based on Business Rule [E-XML-PROC#U150]
   */
  @Override
  public boolean equivalentTo(RelatedPe obj)
  {
    if (this == obj){
      return true;
    }
    if (obj == null){
      return false;
    }
    if (getClass() != obj.getClass()){
      return false;
    }
    RelatedPe other = obj;
    EqualsBuilder builder = new EqualsBuilder();
    builder.append(toLowerAndTrim(getProgramElementNumber()), toLowerAndTrim(other.getProgramElementNumber()));
    return builder.isEquals();
  }

  @Override
  public boolean jibx_hasQuantity()
  {
    return getQuantities() != null && !getQuantities().isEmpty();
  }

  @Override
  public boolean jibx_hasTotalCost()
  {
    return getTotalCosts() != null && !getTotalCosts().isEmpty();
  }

  @Override
  public boolean jibx_hasUnitCost()
  {
    return getUnitCosts()!= null && !getUnitCosts().isEmpty();
  }


  @Override
public void jibx_setQuantities(Costs quantities)
  {
    if (quantities != null)
      setQuantities(quantities);
  }


  @Override
public void jibx_setTotalCosts(Costs totalCosts)
  {
    if (totalCosts != null)
      setTotalCosts(totalCosts);
  }

  @Override
public void jibx_setUnitCosts(Costs unitCosts)
  {
      if (unitCosts != null)
          setUnitCosts(unitCosts);
  }
}
