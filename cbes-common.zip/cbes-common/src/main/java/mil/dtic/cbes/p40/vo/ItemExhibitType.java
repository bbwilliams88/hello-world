package mil.dtic.cbes.p40.vo;


public interface ItemExhibitType extends CostContainer
{
  Exhibit getExhibit();
  void setExhibit(Exhibit e);
  String getIdentifyingString();
}
