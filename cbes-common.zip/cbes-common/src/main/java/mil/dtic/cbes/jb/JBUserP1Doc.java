/*
 * $Id: JBUserR1Doc.java 32873 2009-10-23 17:51:02Z aibrahim $
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBUserP1Doc extends JBDefaultUserSuppliedPart
{
  public JBUserP1Doc()
  {
    setFileSetting(FileSetting.USER_P1); 
    setTitle(fileSetting.getTitle());    
    setFixedTitle(true); // title cannot be changed by user
  } 

}