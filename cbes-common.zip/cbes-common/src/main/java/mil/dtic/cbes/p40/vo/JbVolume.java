package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.query.SelectQuery;

import mil.dtic.cbes.p40.vo.auto._JbVolume;
import mil.dtic.utility.Util;

/**
 *
 */
public class JbVolume extends _JbVolume
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.
    
    public String getBookLabelAndNumber()
    {
      return Util.concat(" ", this.getBookLabel(), this.getBookNumber());
    }

    public String getAgencyCode()
    {
      if(this.getJbVolumeServiceAgency() != null)
        return this.getJbVolumeServiceAgency().getCode();
      else
        return "";
    }
    
    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.
    
    @SuppressWarnings("unchecked")
    public static List<JbVolume> fetchAll(ObjectContext objectContext)
    {
        return objectContext.performQuery(new SelectQuery(JbVolume.class));
    }
    
    public static List<JbVolume> fetchR2AgencyVolumes(ObjectContext context)
    {
      return fetch(context, JbVolume.class, Expression.EQUAL_TO, null, JbVolume.P40VOLUME_PROPERTY, JbVolume.AGENCY_VOLUME_PROPERTY, false, true);
    }
    
    public static List<JbVolume> fetchP40AgencyVolumes(ObjectContext context)
    {
      return fetch(context, JbVolume.class, Expression.EQUAL_TO, null, JbVolume.P40VOLUME_PROPERTY, JbVolume.AGENCY_VOLUME_PROPERTY, true, true);
    }
    
    public static List<JbVolume> fetchR2ServiceVolumes(ObjectContext context)
    {
      return fetch(context, JbVolume.class, Expression.EQUAL_TO, null, JbVolume.P40VOLUME_PROPERTY, JbVolume.AGENCY_VOLUME_PROPERTY, false, false);
    }
    
    public static List<JbVolume> fetchP40ServiceVolumes(ObjectContext context)
    {
      return fetch(context, JbVolume.class, Expression.EQUAL_TO, null, JbVolume.P40VOLUME_PROPERTY, JbVolume.AGENCY_VOLUME_PROPERTY, true, false);
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
