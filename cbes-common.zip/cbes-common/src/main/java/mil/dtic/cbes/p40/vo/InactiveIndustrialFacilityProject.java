package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._InactiveIndustrialFacilityProject;
import mil.dtic.cbes.p40.vo.wrappers.CayenneListWrapper;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.utility.Util;

public class InactiveIndustrialFacilityProject extends _InactiveIndustrialFacilityProject implements FacilityProjectExtended, Equivalence<InactiveIndustrialFacilityProject>
{
  private static final long serialVersionUID = 1L;

  // !!! TODO
  private Costs maintenanceCost;
  private Costs recurringCost;
  private Costs environmentalCost;
  private Costs otherCost;


  @Override
  protected void onPostAdd()
  {
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
    setDisplayOrder(0);
  }


  public void shiftForwardInTime(int years)
  {
    if (this.maintenanceCost != null)
      this.maintenanceCost.shiftForwardInTime(years);
    if (this.recurringCost != null)
      this.recurringCost.shiftForwardInTime(years);
    if (this.environmentalCost != null)
      this.environmentalCost.shiftForwardInTime(years);
    if (this.otherCost != null)
      this.otherCost.shiftForwardInTime(years);


    for (InactiveIndustrialFacilityProjectFunding fpf : this.getFundingList())
    {
      fpf.shiftForwardInTime(years);
    }

  }


  @Override
  protected void onPostLoad()
  {
    for (InactiveIndustrialFacilityProjectFunding funding : this.getFundingList())
    {
      if ("MAINTENANCE".equals(funding.getFundingCategory().getTitle()))
      {
        this.maintenanceCost = funding.getCosts();
      }
      else if ("RECURRING".equals(funding.getFundingCategory().getTitle()))
      {
        this.recurringCost = funding.getCosts();
      }
      else if ("ENVIRONMENTAL".equals(funding.getFundingCategory().getTitle()))
      {
        this.environmentalCost = funding.getCosts();
      }
      else if ("OTHER".equals(funding.getFundingCategory().getTitle()))
      {
        this.otherCost = funding.getCosts();
      }
    }
  }


  @Override
  protected void onPrePersist()
  {
  }


  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getFundingList());
  }


  public Costs getMaintenanceCost()
  {
    return maintenanceCost;
  }


  public void setMaintenanceCost(Costs cost)
  {
    setFacilityCostList(cost, "MAINTENANCE");
    this.maintenanceCost = cost;
  }


  public Costs getRecurringCost()
  {
    return recurringCost;
  }


  public void setRecurringCost(Costs cost)
  {
    setFacilityCostList(cost, "RECURRING");
    this.recurringCost = cost;
  }


  public Costs getEnvironmentalCost()
  {
    return environmentalCost;
  }


  public void setEnvironmentalCost(Costs cost)
  {
    setFacilityCostList(cost, "ENVIRONMENTAL");
    this.environmentalCost = cost;
  }


  public Costs getOtherCost()
  {
    return otherCost;
  }


  public void setOtherCost(Costs cost)
  {
    setFacilityCostList(cost, "OTHER");
    this.otherCost = cost;
  }


  private void setFacilityCostList(Costs cost, String costType)
  {
    SelectQuery query = new SelectQuery(
      InactiveIndustrialFacilityProjectFundingCategory.class, Expression
        .fromString("title = '" + costType + "'"));
    InactiveIndustrialFacilityProjectFundingCategory costCategory = (InactiveIndustrialFacilityProjectFundingCategory) this.objectContext
      .performQuery(query).get(0);
    if (this.getFundingList() != null)
    {
      for (InactiveIndustrialFacilityProjectFunding currentCost : this
        .getFundingList())
      {
        if (currentCost.getFundingCategory().equals(
          costCategory))
        {
          this.getFundingList().remove(currentCost);
          break;
        }
      }
    }
    if (cost != null)
    {
      InactiveIndustrialFacilityProjectFunding funding = this.objectContext.newObject(InactiveIndustrialFacilityProjectFunding.class);
      funding.setCosts(cost);
      funding.setFundingCategory(costCategory);
      this.addToFundingList(funding);
    }
  }


  @Override
  public List<InactiveIndustrialFacilityProjectFunding> getFundingList()
  {
    return new CayenneListWrapper<InactiveIndustrialFacilityProjectFunding>(this, super.getFundingList(), FUNDING_LIST_RELATIONSHIP_PROPERTY, true);
  }


  /**
   * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
   *
   *      HashCode based on Business Rule [E-XML-PROC#P26-100]
   */
  @Override
  public int equivalenceHashCode()
  {
    return new HashCodeBuilder()
      .append(getFacility())
      .append(toLowerAndTrim(getCategory()))
      .append(toLowerAndTrim(getContractor()))
      .toHashCode();
  }


  /**
   * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
   *
   *      Equality based on Business Rule [E-XML-PROC#P26-100]
   */
  @Override
  public boolean equivalentTo(InactiveIndustrialFacilityProject other)
  {
    return new EqualsBuilder()
      .append(getFacility(), other.getFacility())
      .append(toLowerAndTrim(getCategory()), toLowerAndTrim(other.getCategory()))
      .append(toLowerAndTrim(getContractor()), toLowerAndTrim(other.getContractor()))
      .isEquals();
  }


  @Override
  public Costs getUnitCosts()
  {
    return null;
  }


  @Override
  public Costs getQuantities()
  {
    return null;
  }

}
