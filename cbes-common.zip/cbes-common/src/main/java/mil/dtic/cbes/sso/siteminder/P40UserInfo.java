/*
 * $Id$
 */
package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.ServiceAgency;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.Util;

public class P40UserInfo implements Serializable{
  private static final long serialVersionUID = -1959917163146661426L;
  //private static final Map<String, Map<Privilege, Boolean>> configuredPrivileges = new HashMap<String, Map<Privilege, Boolean>>();
  private static final Map<String, Map<Privilege, Boolean>> configuredPrivileges = new HashMap<>();
  private final LdapUser ldapUser;
  private final P40User p40User;
  private final Map<Privilege, Boolean> privileges;
  
  private List<ServiceAgency> allAvailableAgencies;
  private Set<Integer> allAvailableAgencyIds;
  
  /**
   * UserInfo constructor.
   * Neither ldapUser nor budgesUser will be null.
   * @param ldapUser - LdapUser
   * @param budgesUser - BudgesUser
   */
  public P40UserInfo(LdapUser ldapUser, P40User p40User) {
      this.ldapUser = ldapUser;
      this.p40User = p40User;
      this.privileges = configuredPrivileges.get(ldapUser.getR2Role());
      init();
  }
  
  /**
   * CXE-6416 SuperAdmin enhancement. 
   * This method enables AppManager capability to modify key super admin features 
   * and see the changes without restarting the application.
   * @param role - String
   */
  public void reinit(String role){
      if (getLdapUser().getR2Role().equals(role) && 
              getLdapUser().getR2Role().equals(LdapDAO.GROUP_R2_APP_ADMIN)){
          init();
      }
  }
  
  public boolean checkManageRole(String r2Role) {
      boolean canManage = checkPrivilege(Privilege.MANAGE_USERS);
    
      if (LdapDAO.GROUP_R2_LOCALSITEADMIN.equals(r2Role)){
          canManage &= checkPrivilege(Privilege.MANAGE_LOCAL_ADMINS);
      }
    
      if (LdapDAO.GROUP_R2_SITEADMIN.equals(r2Role) || LdapDAO.GROUP_R2_APP_ADMIN.equals(r2Role)){
          canManage &= checkPrivilege(Privilege.MANAGE_ALL_USERS);
      }
      
      if(LdapDAO.GROUP_OMB_ANALYST.equalsIgnoreCase(r2Role)  || LdapDAO.GROUP_R2_ANALYST.equalsIgnoreCase(r2Role)) {
    	  canManage &= checkPrivilege(Privilege.MANAGE_ANALYST_USERS);
      }
      
      return canManage;
  }

  public LdapUser getLdapUser() {
      return this.ldapUser;
  }

  public P40User getP40User() {
      return this.p40User;
  }

  public List<ServiceAgency> getAllAvailableAgencies() {
      return allAvailableAgencies;
  }

  public boolean isLoggedIn() {
      return(ldapUser != null);
  }

  public boolean checkPrivilege(Privilege priv) {
    
    if (null == priv){
        return false;
    }
    return privileges.get(priv) != null && privileges.get(priv);
  }

  public boolean hasAgencies(){
      return this.p40User != null && CollectionUtils.isNotEmpty(this.p40User.getActiveAgencies());
  }

  @SuppressWarnings("deprecation")
  public boolean hasAccessToMainUi(){
     return this.p40User != null && 
    	this.p40User.getStatus().isActive() && 
    	checkPrivilege(Privilege.BASIC_USER) && 
    	(hasAgencies() || checkPrivilege(Privilege.ADMIN_ALL_AGENCIES));
  }

  public boolean canManageUsers() {
      return checkPrivilege(Privilege.MANAGE_USERS);
  }

  public boolean saveLiAllowed(LineItem li){
      return hasEditPermission(li.getId(), li.getServiceAgency().getId()) && !isEntireLocked(li);
  }

  //CXE-5891 prevent all but R2AppMgr to delete PE.
  public boolean deleteLiAllowed(LineItem pe) {
	  return checkPrivilege(Privilege.DELETE_PE);
  }

  public boolean editLiUsersAllowed(LineItem li) {
	  return checkPrivilege(Privilege.MANAGE_USERS) && 
			  hasEditPermission(li.getId(), li.getServiceAgency().getId());
  }

  private boolean hasEditPermission(Integer liId, Integer agencyId) {
      if (liId == null) return true;

      List<LineItem> lineItems = getP40User().getEditableLineItems();

      boolean canEdit = false;
      for (LineItem li : lineItems)
      {
        if (li.getId() == liId) canEdit = true;
      }

      if (!canEdit){
          boolean editIfInAgency = checkPrivilege(Privilege.EDIT_ALL_PES_IN_AGENCY);
        
          if (checkPrivilege(Privilege.EDIT_ALL_PES)){
              return true;
          }
        
          if (editIfInAgency){
              if (allAvailableAgencyIds.contains(agencyId)) return true;
          }

          return false;
      }
      else { 
          return true;
      }
  }

  private boolean isEntireLocked(LineItem li) {
      return li != null && li.getAllLockedBy() != null && 
              !li.getAllLockedBy().getId().equals(getP40User().getId());
  }


  public boolean viewLiAllowed(LineItem lineItem) {
      if (lineItem.getId() == null) return true; // new pe
    
      List<LineItem> lineItems = getP40User().getViewableLineItems();

      boolean canView = false;
      for (LineItem li : lineItems)
      {
        if (li.getId() == lineItem.getId()) canView = true;
      }

      if (canView)  {
          boolean viewIfInAgency = checkPrivilege(Privilege.EDIT_ALL_PES_IN_AGENCY);
          
          if (checkPrivilege(Privilege.EDIT_ALL_PES)) return true;
        
          if (viewIfInAgency) {
              if (allAvailableAgencyIds.contains(lineItem.getServiceAgency().getId())) return true;
          }

          return false;
      }
      else { 
          return true;
      }
  }

  public boolean createLiAllowed() {
      if (this.p40User == null) {
    	  return false;
      }
      if (checkPrivilege(Privilege.ALWAYS_CAN_CREATE)) {
    	  return true;
      }
      return this.p40User.getCreateLiPriv().equals("Y");
  }

  @Override
  public String toString() {
      final String TAB = "    ";
      String retValue = "";

      retValue = "UserInfo ( " + super.toString() + TAB + "ldapUser = " + this.ldapUser + TAB
              + "p40User = " + this.p40User + TAB + "Agencies = " 
              + this.allAvailableAgencies + TAB + " )";

      return retValue;
  }


  public boolean isLockedByOther(LineItem exhibit) {
      Integer thisUsersId = getP40User().getId();
      return(exhibit != null && exhibit.getLockedBy() != null && !exhibit.getLockedBy().getId().equals(thisUsersId));
  }

  public boolean isLockedByMe(LineItem exhibit){
      Integer thisUsersId = this.p40User.getId();
      return(exhibit != null && exhibit.getLockedBy() != null && exhibit.getLockedBy().getId().equals(thisUsersId));
  }

  public boolean isNotLocked(LineItem exhibit){
      return exhibit != null && exhibit.getLockedBy() == null;
  }

  public boolean isEntireLockedByOther(LineItem li) {
      Integer thisUsersId = getP40User().getId();
      return li != null && li.getAllLockedBy() != null && !li.getAllLockedBy().getId().equals(thisUsersId);
  }
  
  public boolean isEntireLockedByMe(LineItem li) {
      Integer thisUsersId = getP40User().getId();
      return li != null && li.getAllLockedBy() != null && li.getAllLockedBy().getId().equals(thisUsersId);
  }

  public boolean canDoPrcp() {
      return checkPrivilege(Privilege.CAN_DO_PRCP);
  }
  
  public boolean canDeleteBudgesJob(){
    return checkPrivilege(Privilege.DELETE_BUDGES_JOB);
  }
  
  /**
   * CXE-6416 SuperAdmin enhancement
   */
  private void init(){
    if (p40User != null){
        this.allAvailableAgencies = this.p40User.getActiveAgencies();
    }
    else{
        this.allAvailableAgencies = new ArrayList<ServiceAgency>(0);
    }

    this.allAvailableAgencyIds = new HashSet<Integer>(allAvailableAgencies.size());

    for (ServiceAgency sa : allAvailableAgencies){
        allAvailableAgencyIds.add(sa.getId());
    }
  }
  
  static {
      configuredPrivileges.put(LdapDAO.GROUP_NONE, new HashMap<Privilege, Boolean>());
      for (String role : LdapDAO.VALID_GROUPS_SET) {
        configuredPrivileges.put(role, new HashMap<Privilege, Boolean>());
      }

      for (Privilege p : Privilege.values()){
        configuredPrivileges.get(LdapDAO.GROUP_R2_APP_ADMIN).put(p, true);
      }
      
      configuredPrivileges.get(LdapDAO.GROUP_OMB_ANALYST).put(Privilege.TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES,true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_ANALYST).put(Privilege.TRACK_ASYNC_JOBS_FOR_ALL_AGENCIES,true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_ANALYST).put(Privilege.DELETE_BUDGES_JOB,true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.BASIC_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.MANAGE_USERS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.MANAGE_LOCAL_ADMINS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.SHOW_ALL_PES_IN_AGENCY, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.EDIT_ALL_PES_IN_AGENCY, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.SHOW_MODIFYING_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.ALWAYS_CAN_CREATE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DISABLE_SET_PERM_ON_CREATEPE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.FREEZE_PE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.R1PAGE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.TRACK_ASYNC_JOBS_FOR_OWN_AGENCIES, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.LOGODEFAULT, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DELETE_PE, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_SITEADMIN).put(Privilege.DELETE_BUDGES_JOB, true);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.BASIC_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.MANAGE_USERS, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.SHOW_MODIFYING_USER, true);
      configuredPrivileges.get(LdapDAO.GROUP_R2_LOCALSITEADMIN).put(Privilege.FREEZE_PE, false);
      
      configuredPrivileges.get(LdapDAO.GROUP_R2_USER).put(Privilege.BASIC_USER, true);
    }
}
