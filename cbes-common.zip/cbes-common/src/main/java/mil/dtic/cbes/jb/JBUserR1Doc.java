/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBUserR1Doc extends JBDefaultUserSuppliedPart
{
  public JBUserR1Doc()
  {
    setFileSetting(FileSetting.USER_R1); 
    setTitle(fileSetting.getTitle());    
    setFixedTitle(true); // title cannot be changed by user
  } 

}