package mil.dtic.cbes.p40.vo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.PersistenceState;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.p40.vo.auto._MonthlyDelivery;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

public class MonthlyDelivery extends _MonthlyDelivery implements Equivalence<MonthlyDelivery>
{
  private static final long serialVersionUID = 1L;


  public static MonthlyDelivery create(ObjectContext context, Calendar calWithYearAndMonth)
  {
    MonthlyDelivery monthlyDelivery = context.newObject(MonthlyDelivery.class);
    monthlyDelivery.setMonth(calWithYearAndMonth.getTime());
    return monthlyDelivery;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#hashCode()
   *
   * HashCode based on Business Rule [E-XML-PROC#U130]
   */
  @Override
  public int equivalenceHashCode()
  {
    if (this.getPersistenceState() == PersistenceState.DELETED)
      return super.hashCode();
    HashCodeBuilder builder = new HashCodeBuilder();
    builder.append(getMonth());
    builder.append(getDeliverySchedule());
    return builder.toHashCode();
  }


  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#equals(java.lang.Object)
   *
   * Equality based on Business Rule [E-XML-PROC#U130]
   */
  @Override
  public boolean equivalentTo(MonthlyDelivery obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MonthlyDelivery other = obj;
    if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
      return super.equals(obj);
    EqualsBuilder builder = new EqualsBuilder();
    builder.append(getMonth(), other.getMonth());
    builder.append(getDeliverySchedule(), other.getDeliverySchedule());
    return builder.isEquals();
  }

  public static String formatMonthlyDeliveryDate(Date month)
  {
    if (month == null)
      return "";
    else
      return new SimpleDateFormat(Constants.XML_MONTH_DATE_FORMAT).format(month);
  }

  public static Comparator<MonthlyDelivery> getMonthDeliveryComparator()
  {
    return new Comparator<MonthlyDelivery> ()
    {
      public int compare(MonthlyDelivery md1, MonthlyDelivery md2)
      {
        if (md1 == null && md2 == null){
          return 0;
        } else if (md1 == null){
          return -1;
        } else if (md2 == null){
          return 1;
        } else {
          return md1.getMonth().compareTo(md2.getMonth());
        }
      }
    };
  }
  
  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  public boolean isMonthExist()
  {
    if(getMonth() != null)
      return true;
    return false;
  }
  
  public boolean isAmountExist()
  {
    if(getAmount() != null)
      return true;
    return false;
  }
}
