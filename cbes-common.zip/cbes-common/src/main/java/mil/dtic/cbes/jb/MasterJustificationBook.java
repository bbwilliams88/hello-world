package mil.dtic.cbes.jb;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.xml.JavaToXml;
import mil.dtic.cbes.xml.JavaToXmlResult;
import mil.dtic.cbes.xml.XMLConvertable;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.InvalidXMLListener;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.XmlUtil;

public class MasterJustificationBook extends JBBase implements XMLConvertable {
  //@formatter:off
    private static final long serialVersionUID = -8579289880674672019L;
    private static final Logger log = CbesLogFactory.getLog(MasterJustificationBook.class);
    
    private List<JustificationBookGroup> jbgList;
    private GenericToc volumeToc;
    private Map<String, JustificationBook> jbMapByServiceAgencyName;
    private boolean rfr = false;

    public MasterJustificationBook() {
        
        targetSchemaVersion = Constants.JB_XML_VERSION;
        setFileSetting(FileSetting.MASTER_JB);
        setTitle(FileSetting.MASTER_JB.getTitle());
        // since partIndex is used to create part pdf's, set it to an arbitrary but high number to avoid collision with jb's parts
        partIndex = 99999; 
        jbPageNumberingModel = Constants.JBPageNumberingModel.CONTINUOUS;
        jbMapByServiceAgencyName = new HashMap<String, JustificationBook>();
      //@formatter:on
    }

    /**********************************************************************************************************
     * START Java-to-XML binding methods. These methods are used by JiBX for
     * Java-to-XML binding at runt time (not needed for XML-to-Java).
     **********************************************************************************************************
     */

    public boolean hasJustificationBookGroups_xml() {
        return CollectionUtils.isNotEmpty(jbgList);
    }

    public boolean hasTableOfContents_xml() {
        return volumeToc != null;
    }

    public String getClassificationLabel() {
        return Util.getClassificationLabel();
    }

    /**********************************************************************************************************
     * END Java-to-XML binding methods.
     * 
     * @throws SQLException
     * @throws IOException
     **********************************************************************************************************
     */

    @Override
    public JavaToXmlResult toZip(InvalidXMLListener invalidXMLListener, 
            boolean excludeExternalObjectsFromZip)
            throws IOException, SQLException {
        JavaToXml jtx = new JavaToXml(workingFolder,
                excludeExternalObjectsFromZip);
        JavaToXmlResult jtxResult = jtx.toZip(this);
        if (invalidXMLListener != null)
            XmlUtil.sanityValidateXml(jtxResult.getXmlFile(),
                    invalidXMLListener);
        return jtxResult;
    }

    @Override
    public String getUserVisibleLabel() {
        if (FileUtil.isZipFile(absoluteFileName))
            return FileUtil.createZipFileName(getBusinessId());
        else
            return FileUtil.createPdfFileName(getBusinessId());
    }

    @Override
    public String getPdfBookmarkLabel() {
        return FileSetting.MASTER_JB.getTitle() + " - "
                + super.getPdfBookmarkLabel();
    }

    @Override
    public boolean r3sExist() {
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    if (jbi.getJb().r3sExist()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean r2sExist() {
        boolean r2sExist = false;
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    r2sExist |= jbi.getJb().r2sExist();
                    if (r2sExist)
                        break;
                }
            }
        }
        return r2sExist;
    }

    @Override
    public boolean lineItemsExist() {
        boolean lineItemsExist = false;
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    lineItemsExist |= jbi.getJb().lineItemsExist();
                    if (lineItemsExist)
                        break;
                }
            }
        }
        return lineItemsExist;
    }

    @Override
    public boolean multiYearProcurementsExist() {
        return multiYearProcurementList != null && CollectionUtils.isNotEmpty(
                multiYearProcurementList.getMultiYearProcurements());
    }

    @Override
    public boolean p21sExist() {
        boolean p21Exist = false;
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    p21Exist |= jbi.getJb().p21sExist();
                    if (p21Exist)
                        break;
                }
            }
        }
        return p21Exist;
    }

    @Override
    public boolean secondaryDistributionsExist() {
        boolean secondaryDistributionsExist = false;
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    secondaryDistributionsExist |= jbi.getJb()
                            .secondaryDistributionsExist();
                    if (secondaryDistributionsExist)
                        break;
                }
            }
        }
        return secondaryDistributionsExist;
    }

    @Override
    protected String getPageNumberPrefix() {
        return "";
    }

    @Override
    public String getBusinessId() {
        if (super.getBusinessId() == null) {
            return null;
        }
        String fileTag = getFileMetaTag(this);
        log.trace("fileTag: " + fileTag);
        String fileName = Util.underscoreConcat(Util.getClassificationSymbol(), getBudgetArea(), JBBase.META_MJB, fileTag, super.getBusinessId());
        log.trace("fileName: " + fileName);
        return fileName;
    }

    @Override
    public FormattingResults createPdf() throws IOException, SQLException, DocumentException {
        log.trace("createPdf(); - start");
        docCreationParams.setBudgetArea(getBudgetArea());

        if (docCreationParams.getBudgetCycle() == null)
            docCreationParams.setBudgetCycle(budgetCycle);

        if (docCreationParams.getBudgetYear() == null)
            docCreationParams.setBudgetYear(budgetYear);

        if (docAssemblyOptions.isUseLegacyMJBFormat()) {
            //@formatter:off
            log.trace("legacy - Creating JB documents for master JB...");
            createJbs();
            log.trace("legacy - Preparing JB documents...");
            createPaginationGroups();
            log.trace("legacy - Concatenating JB documents...");
            concatPdfs();
            log.trace("legacy - Setting absolute page numbers for all JB pages...");
            setPdfAbsoluteStartPages();
            log.trace("legacy - Page numbering and watermarking JB document...");
            createMasterJbPrelude();
            log.trace("legacy - Creating master JB Pdf's");
            createMasterJbs();
            log.trace("legacy - Packaging Pdf's");
            packageMasterJbs();
            log.trace("legacy - Finished building master JB document...");
        } else {
            setTitlePrefix("Master");
            log.trace("Creating JB documents for master JB...");
            createJbs();
            log.trace("Preparing JB documents...");
            createMasterJbParts();
            log.trace("Creating JB documents for master JB...");
            completeCreatingJbs();
            log.trace("Packaging Pdf's");
            packageMasterJbs();
            log.trace("Finished building master JB document...");
          //@formatter:on
        }

        rfr = isRfr();
        return null;
    }

    private String getHighestVolume() {
        String volumePrefix = "Volume ";
        String volumeNumber = "1";

        for (JustificationBookGroup jbg : jbgList) {
            for (JustificationBookInfo jbi : jbg.getJbiList()) {
                // Loop through ToC volumes to try and find the highest volume
                // number.
                for (KeyValuePair kvp : volumeToc.getTocItemList())
                    if (StringUtils.startsWith(kvp.getValue(), volumePrefix))
                        if (kvp.getValue().substring(volumePrefix.length())
                                .compareTo(volumeNumber) > 0)
                            volumeNumber = kvp.getValue()
                                    .substring(volumePrefix.length());

                // See if current JBI volume number is highest.
                if (jbi.getNumber().compareTo(volumeNumber) > 0)
                    volumeNumber = jbi.getNumber();

                // See if volume number contains letter, like "3a" and just
                // compare to "3".
                if (containsLetter(volumeNumber))
                    for (int i = 0; i < volumeNumber.length(); i++)
                        if (Character.isLetter(volumeNumber.charAt(i)))
                            volumeNumber = volumeNumber.substring(0, i);
            }
        }

        return volumeNumber;
    }

    protected void createJbs()
            throws IOException, SQLException, DocumentException {
        if (CollectionUtils.isNotEmpty(jbgList)) {
            // volumeValue is used to store highest Volume Number
            String volumeValue = getHighestVolume();
            int index = 0;

            for (JustificationBookGroup jbg : jbgList) {
                int startPageOffset = 1;
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    JustificationBook jb = jbi.getJb();
                    jb.setPartIndex(index++);
                    if (this.getDocAssemblyOptions().isUseLegacyMJBFormat()) {
                        jb.setJbPageNumberingModel(
                                jbPageNumberingModel.CONTINUOUS);
                    } else {
                        jb.setJbPageNumberingModel(
                                jbPageNumberingModel.SECTIONED);
                    }
                    jb.setPdfPageOffset(startPageOffset);
                    jb.setMjb(this); // TODO remove since it's already set by
                                     // the time we
                                     // get here
                    jb.setJbi(jbi);
                    jb.setWorkingFolder(workingFolder);
                    jb.setDocCreationParams(docCreationParams);

                    jb.setTotalCoverVolumes(volumeValue);

                    // if setting standalone to false ==> we don't want xml file
                    // to be embedded, bookmarks created, etc.
                    jb.setStandalone(
                            !docAssemblyOptions.isUseLegacyMJBFormat());

                    // We are going to pass only the jb xml to each jb to create
                    // the jb pdf
                    if (docAssemblyOptions.isUseLegacyMJBFormat()) {
                        jb.setXmlFile(null);
                        byte[] jbXmlData = JavaToXml.toXml(jb);
                        jb.setXmlData(jbXmlData);

                    } else {

                        JavaToXmlResult jtxResult = jb.toZip();
                        jb.setXmlFile(jtxResult.getXmlFile());
                        jb.addFileToEmbed(jb.createEmbedableZipFile(
                                jtxResult.getZipFile()));
                        // jb.addFileToEmbed(jb.creatEmbedableR1DExcel());
                    }

                    if (r2sExist()) {
                        if (docAssemblyOptions.isUseLegacyMJBFormat())
                            jb.createPdf();
                        else
                            jb.preCreateR2Pdfs();

                        // Keep track of all r2 page numbers (along with Volume
                        // #'s), we'll need them when building the master PE TOC's
                        if (r2PageNumberKvpList == null) {
                            r2PageNumberKvpList = jb.getR2PageNumberKvpList();
                        } else {
                            if (jb.getR2PageNumberKvpList() != null)
                                r2PageNumberKvpList
                                        .addAll(jb.getR2PageNumberKvpList());
                        }
                    }

                    if (lineItemsExist()) {
                        if (docAssemblyOptions.isUseLegacyMJBFormat())
                            jb.createPdf();
                        else
                            jb.preCreateP40Pdfs();

                        // Keep track of all p40 page numbers (along with Volume
                        // #'s), we'll need them when building the master LI TOC's
                        if (p40PageNumberKvpList == null) {
                            p40PageNumberKvpList = jb.getP40PageNumberKvpList();
                        } else {
                            if (jb.getP40PageNumberKvpList() != null)
                                p40PageNumberKvpList
                                        .addAll(jb.getP40PageNumberKvpList());
                        }
                    }

                    startPageOffset += jb.getPdfTotalPageCount();
                }
            }
        }
    }

    public void completeCreatingJbs()
            throws DocumentException, IOException, SQLException {
        log.trace("completeCreatingJbs(): - start");
        if (CollectionUtils.isNotEmpty(jbgList)) {
            for (JustificationBookGroup jbg : jbgList) {
                int i = 0;
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    JustificationBook jb = jbi.getJb();
                    log.trace(
                            "** completeCreatingJbs(): created JustificationBook no: "
                                    + i++);
                    jb.addFilesToEmbed(fileToEmbedList);
                    log.trace("completeCreatingJbs(): calling jb.createPdf()");
                    jb.createPdf();
                }
            }
        }
    }

    public void createMasterJbParts()
            throws IOException, DocumentException, SQLException {
        log.trace("About to prepare master JB parts for consolidated JB...");

        log.trace("Creating master volume TOC...");
        createVolumeToc(null);

        if (r2sExist()) {
            if (docAssemblyOptions.isGenerateProgramElementTocByBA()) {
                log.trace("Creating master PE TOC by BA #...");
                createPeTocByBa(null);
            }
            if (docAssemblyOptions.isGenerateProgramElementTocByTitle()) {
                log.trace("Creating master PE TOC by PE Title...");
                createPeTocByTitle(null);
            }
        }

        if (lineItemsExist()) {
            if (docAssemblyOptions.isGenerateLineItemTocByBA()) {
                log.trace("Creating master LI TOC by BA #...");
                createLiTocByBa(null);
            }
            if (docAssemblyOptions.isGenerateLineItemTocByTitle()) {
                log.trace("Creating master LI TOC by LI Title...");
                createLiTocByTitle(null);
            }
        }

        if (r2sExist()) {
            if (docAssemblyOptions.isGenerateR1Summary()) {
                log.trace("Creating master R1 Summary...");
                createR1SummaryPdf(null);
            }
            if (docAssemblyOptions.isGenerateR1()) {
                log.trace("Creating master R1...");
                createR1Pdf(null);
            }
            if (docAssemblyOptions.isGenerateR1c()) {
                log.trace("Creating master R1C...");
                createR1cPdf(null);
            }
            if (docAssemblyOptions.isGenerateR1d()) {
                log.trace("Creating master R1D...");
                createR1dPdf(null);
            }
        }

        if (lineItemsExist()) {
            if (docAssemblyOptions.isGenerateP1()) {
                log.trace("Creating master P1...");
                createP1Pdf(null);
            }

            if (docAssemblyOptions.isGenerateP1m()) {
                log.trace("Creating master P1m...");
                createP1mPdf(null);
            }
        }

    }

    public void createPaginationGroups()
            throws IOException, DocumentException, SQLException {
        log.trace("About to prepare master JB docs...");

        log.trace("Creating pagination groups for master jb...");
        // prepare the pagination sections
        PaginationGroup pg1 = new PaginationGroup(
                Constants.JBPageNumbering.NONE, true);
        PaginationGroup pg2 = new PaginationGroup(
                Constants.JBPageNumbering.RESTART,
                Constants.JBPageNumberingStyle.ROMAN_NUMERALS, true);

        pgList = new ArrayList<PaginationGroup>();
        pgList.add(pg1);
        pgList.add(pg2);

        log.trace("Creating master cover...");
        coverDoc.setPdfTotalPageCount(
                docAssemblyOptions.isForceEvenPages() ? 2 : 1);
        pg1.addJbPart(coverDoc);

        log.trace("Creating master volume TOC...");
        createVolumeToc(pg2);

        log.trace("Creating place holder for master TOC...");
        // Put a place holder for the 1-page (if blank pages are suppressed) or
        // 2-page (if blank pages are not suppressed) TOC
        BaseToc jbTocDummy = new BaseToc();
        jbTocDummy.setPdfTotalPageCount(
                docAssemblyOptions.isForceEvenPages() ? 2 : 1);
        pg2.addJbPart(jbTocDummy);
        log.trace("Created " + jbTocDummy.getPdfTotalPageCount()
                + "-page place holder for master TOC...");

        log.trace(
                "Preparing master user supplied introduction doc for master jb...");
        prepareUserSuppliedDoc(costDoc, pg2);

        log.trace(
                "Preparing master user supplied introduction doc for master jb...");
        prepareUserSuppliedDoc(introductionDoc, pg2);

        log.trace("Preparing user supplied comptroller r1 doc in master jb...");
        prepareUserSuppliedDoc(userR1Doc, pg2);

        log.trace("Preparing user supplied comptroller p1 doc in master jb...");
        prepareUserSuppliedDoc(userP1Doc, pg2);

        if (r2sExist()) {
            if (docAssemblyOptions == null
                    || docAssemblyOptions.isGenerateProgramElementTocByBA()) {
                log.trace("Creating master PE TOC by BA #...");
                createPeTocByBa(pg2);
            }
            if (docAssemblyOptions == null || docAssemblyOptions
                    .isGenerateProgramElementTocByTitle()) {
                log.trace("Creating master PE TOC by PE Title...");
                createPeTocByTitle(pg2);
            }
        }

        if (lineItemsExist()) {
            if (docAssemblyOptions == null
                    || docAssemblyOptions.isGenerateLineItemTocByBA()) {
                log.trace("Creating master LI TOC by BA #...");
                createLiTocByBa(pg2);
            }
            if (docAssemblyOptions == null
                    || docAssemblyOptions.isGenerateLineItemTocByTitle()) {
                log.trace("Creating master LI TOC by LI Title...");
                createLiTocByTitle(pg2);
            }
        }

        log.trace(
                "Preparing master user supplied summary doc for master jb...");
        prepareUserSuppliedDoc(summaryDoc, pg2);

        if (r2sExist()) {
            if (docAssemblyOptions.isGenerateR1Summary()) {
                log.trace("Creating master R1 Summary...");
                createR1SummaryPdf(pg2);
            }
            if (docAssemblyOptions.isGenerateR1()) {
                log.trace("Creating master R1...");
                createR1Pdf(pg2);
            }
            if (docAssemblyOptions.isGenerateR1c()) {
                log.trace("Creating master R1C...");
                createR1cPdf(pg2);
            }
            if (docAssemblyOptions.isGenerateR1d()) {
                log.trace("Creating master R1D...");
                createR1dPdf(pg2);
            }
        }

        if (lineItemsExist()) {
            if (docAssemblyOptions.isGenerateP1()) {
                log.trace("Creating master P1...");
                createP1Pdf(pg2);
            }

            if (docAssemblyOptions.isGenerateP1m()) {
                log.trace("Creating master P1m...");
                createP1mPdf(pg2);
            }
        }

        if (supplementalDocCollection != null) {
            log.trace(
                    "Preparing master user supplied supplemental docs in master jb...");
            prepareUserSuppliedDoc(
                    supplementalDocCollection.getSupplementalDocList(), pg2);
            supplementalDocCollection.setPdfStartPage(supplementalDocCollection
                    .getSupplementalDocList().get(0).getPdfStartPage());
            supplementalDocCollection.setPdfPaginationGroup(pg2);
        }

        log.trace("Preparing master user supplied acronyms doc in master ...");
        prepareUserSuppliedDoc(acronymDoc, pg2);

        log.trace("Creating master TOC...");
        createToc(null);

        log.trace("Replacing TOC place holder with actual TOC...");
        pg2.replace(1, toc);

        updatePdfTotalPageCount();

    }

    protected void createCoverPdf(PaginationGroup pg, String coverTitle)
            throws IOException, DocumentException, SQLException {
        docCreationParams.setBookGroupLabelAndNumber(coverTitle);
        super.createCoverPdf(pg);
    }

    protected void createToc(PaginationGroup pg)
            throws IOException, DocumentException, SQLException {
        toc = new MasterJBToc(this, volumeToc);
        createPartPdf(toc, pg);
    }

    protected void createVolumeToc(PaginationGroup pg)
            throws IOException, DocumentException, SQLException {
        if (volumeToc != null) {
            log.trace(
                    "Master table of contents (table of volumes) was supplied...");
            if (Constants.JBPageNumberingModel.CONTINUOUS
                    .equals(jbPageNumberingModel)) {
                addPageNumbersToVolumeToc();
            }
        } else {
            log.trace(
                    "Master table of contents (table of volumes) was NOT supplied, creating an empty one...");
            volumeToc = new GenericToc();
            if (CollectionUtils.isNotEmpty(jbgList)) {
                List<KeyValuePair> tocItemList = new ArrayList<KeyValuePair>();
                volumeToc.setTocItemList(tocItemList);
                for (JustificationBookGroup jbg : jbgList) {
                    for (JustificationBookInfo jbi : jbg.getJbiList()) {
                        KeyValuePair kvp = new KeyValuePair(
                                jbi.getDescription(),
                                jbi.getLabel() + " " + jbi.getNumber());
                        log.trace(
                                "Adding synthesized entry to toc of table of volumes : "
                                        + kvp);
                        tocItemList.add(kvp);
                    }
                }
            }
        }
        volumeToc.setFileSetting(FileSetting.GENERIC_TOC);
        volumeToc.setTitle("Table of Volumes");
        createPartPdf(volumeToc, pg);
    }

    protected void addPageNumbersToVolumeToc() {
        List<KeyValuePair> tovKvpList = volumeToc.getTocItemList();
        if (CollectionUtils.isNotEmpty(tovKvpList)) {
            for (KeyValuePair kvp : tovKvpList) {
                JustificationBook jb = jbMapByServiceAgencyName
                        .get(kvp.getKey().toLowerCase().trim());
                if (jb != null)
                    kvp.setValue(Util.concat(" - ", kvp.getValue(),
                            Util.formatJbPageNumber(jb.getPdfStartPage())));
            }
        }
    }

    protected void createMasterJbPrelude()
            throws IOException, DocumentException {
        log.trace("inside createMasterJbPrelude");
        OutputStream pdfOutputStream = null;
        PdfReader pdfReader = null;
        PdfStamper pdfStamper = null;

        try {
            log.trace(
                    "About to page number and watermark JB (creating master JB prelude document)...");

            String tmpFileName = FileUtil.createPdfFileName(getFileNamePrefix(),
                    "prelude");
            File tmpOutputFile = new File(workingFolder, tmpFileName);
            pdfOutputStream = new BufferedOutputStream(
                    new FileOutputStream(tmpOutputFile));

            pdfReader = new PdfReader(absoluteFileName);
            pdfStamper = new PdfStamper(pdfReader, pdfOutputStream);

            numberPagesAndWatermark(pgList, pdfReader, pdfStamper);
            log.trace(
                    "inside createMasterJbPrelude completed numberPagesAndWatermark");

            absoluteFileName = tmpOutputFile.getAbsolutePath();
        } finally {
            PdfUtil.closePdfStamper(pdfStamper);
            PdfUtil.closePdfReader(pdfReader);
            FileUtil.close(pdfOutputStream);
        }

        log.trace("Finished page numbering and watermarking JB...");

    }

    /**
     * @throws IOException
     * @throws DocumentException
     * @throws SQLException
     */
    protected void createMasterJbs()
            throws DocumentException, IOException, SQLException {

        if (CollectionUtils.isNotEmpty(jbgList)) {
            log.trace("About to create " + jbgList.size()
                    + " master JB document(s)...");

            List<String> concatFileNameList = new ArrayList<String>();
            int index = 0;
            for (JustificationBookGroup jbg : jbgList) {
                concatFileNameList.clear();
                String tmpFileName = FileUtil.createPdfFileName(
                        getFileNamePrefix(), "final_group", index);
                log.trace("Creating master JB document: " + tmpFileName);
                log.trace("Creating master cover...");
                // String test =
                // jbg.getJbiList().get(index).getJb().getBookGroupLabelAndNumber();
                // String test2 =
                // jbg.getJbiList().get(index).getJb().getBookGroupNumber();
                // String test3 =
                // jbg.getJbiList().get(index).getJb().getMjb().getCoverDoc().getTitle();
                // String test4 = jbg.getJbiList().get(index).getNumber();
                // TODO FIX THIS SO IT REFLECTS NUMBER OF BOOKS
                createMjbCover(jbg.getJbiList().get(0).getJb()
                        .getBookGroupLabelAndNumber(), index);

                concatFileNameList.add(coverDoc.getAbsoluteFileName());

                File masterJbOutputFile = new File(workingFolder, tmpFileName);
                jbg.setMasterJbFile(masterJbOutputFile);
                concatFileNameList.add(absoluteFileName);
                for (JustificationBookInfo jbi : jbg.getJbiList()) {
                    if (jbi.getJb().hasContent())
                        concatFileNameList
                                .add(jbi.getJb().getAbsoluteFileName());
                    else
                        log.trace("(Not adding "
                                + jbi.getJb().getFileSetting().getTitle()
                                + " to concatenation list since it's null).");

                }
                log.trace(
                        "MasterJustificationBook:createMasterJbs - calling PdfUti.concatPdfs");
                PdfUtil.concatPdfs(masterJbOutputFile, concatFileNameList);

                log.trace(
                        "Decorating master JB with attachments and bookmarks...");

                // Decorate master JB pdf by attaching XML of master JB and
                // bookmarks
                MasterJbPdfBookMarkBuilder pbb = new MasterJbPdfBookMarkBuilder();
                List<HashMap<String, Object>> bookmarkList = pbb
                        .getBookmarkList(this, jbg);
                List<EmbedableFile> embedList = null;
                // Embed the XML zip file only in the first volume
                if (index == 0)
                    embedList = fileToEmbedList;
                PdfUtil.attachFileAndBookmarksToPdf(masterJbOutputFile,
                        embedList, bookmarkList);

                PdfUtil.applyPdfProperties(masterJbOutputFile,
                        (HashMap<String, String>) getPdfPropertiesToApply(null),
                        Constants.PDF_READ_ONLY_PERMISSIONS, budgetCycle,
                        budgetYear);
                ++index;
            }
            log.trace("Finished creating master JB document(s)...");
        }
    }

    protected void createMjbCover(String coverTitle, int index)
            throws IOException, DocumentException, SQLException {
        log.trace("inside createMjbCover");
        createCoverPdf(null, coverTitle);

        PaginationGroup pg = new PaginationGroup(Constants.JBPageNumbering.NONE,
                true);
        pg.addJbPart(coverDoc);
        List<PaginationGroup> coverPgList = new ArrayList<PaginationGroup>();
        coverPgList.add(pg);

        OutputStream pdfOutputStream = null;
        PdfReader pdfReader = null;
        PdfStamper pdfStamper = null;

        try {
            log.trace("About to page number and watermark MJB cover...");

            String tmpFileName = FileUtil.createPdfFileName(
                    coverDoc.getFileNamePrefix(), "mjb", index);
            File tmpOutputFile = new File(workingFolder, tmpFileName);
            pdfOutputStream = new BufferedOutputStream(
                    new FileOutputStream(tmpOutputFile));

            pdfReader = new PdfReader(coverDoc.getAbsoluteFileName());
            pdfStamper = new PdfStamper(pdfReader, pdfOutputStream);

            numberPagesAndWatermark(coverPgList, pdfReader, pdfStamper);
            log.trace("inside createMjbCover finished numberPagesandWaterMark");

            coverDoc.setAbsoluteFileName(tmpOutputFile.getAbsolutePath());
        } finally {
            PdfUtil.closePdfStamper(pdfStamper);
            PdfUtil.closePdfReader(pdfReader);
            FileUtil.close(pdfOutputStream);
        }

        log.trace("Finished page numbering and watermarking MJB cover...");

    }

    protected void packageMasterJbs() throws IOException {
        log.trace("packageMasterJbs: - start");
        if (CollectionUtils.isNotEmpty(jbgList)) {
            //ZipOutputStream zipFileStream = null;
            if (getBusinessId() == null) {
                throw new FileNotFoundException("Unable to create filename: invalid or missing ID info");
            }
            File zipFile = new File(workingFolder, FileUtil.createZipFileName(getBusinessId()));
            log.trace("About to package master JB document(s): " + zipFile.getAbsolutePath());
            
            try (ZipOutputStream zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)))){
                //zipFileStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)));
                File fileToAddToZip = null;
                int index = 0;
                for (JustificationBookGroup jbg : jbgList) {
                    ZipEntry zipEntry = new ZipEntry(getPdfFileNameInZip(jbg, ++index));
                    zipFileStream.putNextEntry(zipEntry);
                    if (docAssemblyOptions.isUseLegacyMJBFormat()) {
                        fileToAddToZip = jbg.getMasterJbFile();
                    }
                    else {
                        fileToAddToZip = new File(jbg.getJbiList().get(0).getJb().getAbsoluteFileName());
                    }

                    FileUtil.writeFileContents(fileToAddToZip, zipFileStream, false);
                }
                log.trace("Finished packaging master JB...");
                absoluteFileName = zipFile.getAbsolutePath();
            } 
            catch (IOException e) {
                log.error("Could not create zip file for master JB(s).", e);
                throw e;
            } 
        }
    }

    @Override
    public EmbedableFile createEmbedableZipFile(File zipFile) {
        return new DefaultEmbedableFile(
                FileUtil.createZzzFileName(getBusinessId()),
                "Master Justification Book Zip File (save & rename to .zip to open)",
                zipFile);
    }

    protected String getPdfFileNameInZip(JustificationBookGroup jbg,
            int groupIndex) {

        return FileUtil.createPdfFileName(getBusinessId(), groupIndex);
    }

    public List<JustificationBookGroup> getJbgList() {
        return jbgList;
    }

    public void setJbgList(List<JustificationBookGroup> jbgList) {
        this.jbgList = jbgList;
    }

    public GenericToc getVolumeToc() {
        return volumeToc;
    }

    public void setVolumeToc(GenericToc volumeToc) {
        this.volumeToc = volumeToc;
    }

    public Map<String, JustificationBook> getJbMapByServiceAgencyName() {
        return jbMapByServiceAgencyName;
    }

    public void setJbMapByServiceAgencyName(
            Map<String, JustificationBook> jbMapByServiceAgencyName) {
        this.jbMapByServiceAgencyName = jbMapByServiceAgencyName;
    }

    @Override
    public byte[] toXml(InvalidXMLListener l) throws IOException {
        byte[] xmlData = JavaToXml.toXml(this);
        XmlUtil.sanityValidateXml(xmlData, l);
        return xmlData;
    }

    public boolean isRfr() {
        return rfr;
    }

    public void setRfr(boolean rfr) {
        this.rfr = rfr;
    }

}
