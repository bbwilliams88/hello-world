package mil.dtic.cbes.exceptions;

public class DuplicateExhibitException extends Exception
{
    private static final long serialVersionUID = 1L;

    public DuplicateExhibitException() { super(); }
    public DuplicateExhibitException(String message) { super(message); }
    public DuplicateExhibitException(String message, Throwable cause) { super(message, cause); }
    public DuplicateExhibitException(Throwable cause) { super(cause); }
}
