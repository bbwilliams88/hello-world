package mil.dtic.cbes.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.exceptions.InvalidFileTypeException;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.CmdLineUtil;
import mil.dtic.utility.FileUtil;

public class VirusScanService {

    private static final Logger log = CbesLogFactory.getLog(VirusScanService.class);

    protected AppDefaults appDefaults;
    protected List<ValidationMessage> errorList;

    public VirusScanService(AppDefaults appDefaults) {
        this.appDefaults = appDefaults;
        errorList = new ArrayList<ValidationMessage>();
    }

    public boolean virusFound() {
        return hasErrors();
    }

    public boolean hasErrors() {
        return errorList.size() > 0;
    }

    public List<ValidationMessage> getErrorList() {
        return errorList;
    }

    public void virusScan(BudgesFile dirToScan, List<BudgesFile> fileToScanList) {
        virusScan(dirToScan.getVirusScanFile(), fileToScanList, dirToScan.getFile());
    }

    public void virusScan(BudgesFile fileToScan) {
        virusScan(fileToScan.getVirusScanFile(), null, fileToScan.getFile());
    }

    public void virusScan(File dirOrFileToScan, List<BudgesFile> fileToScanList, File destDir)
    {
        if (dirOrFileToScan != null && dirOrFileToScan.exists())
        {
            if (dirOrFileToScan.isFile())
                if (FileUtil.isNotWhitelisted(dirOrFileToScan, BudgesContext.getConfigService().getWhitelist()))
                    throw new InvalidFileTypeException("File type is not supported.");

            if (isValidDestination(destDir))
            {
                if (fileToScanList != null)
                {
                    if (dirOrFileToScan.isDirectory() == false)
                        throw new RuntimeException("Found a file, but expected a directory.");

                    for (BudgesFile fileToScan : fileToScanList)
                    {
                        if (fileToScan.getFile().getParentFile().equals(dirOrFileToScan))
                            throw new RuntimeException("File is not in correct location.");
                        else if (FileUtil.isNotWhitelisted(fileToScan.getFile(), BudgesContext.getConfigService().getWhitelist()))
                            throw new InvalidFileTypeException("File type is not supported.");
                    }
                }

                log.debug("About to virus scan: " + dirOrFileToScan.getAbsolutePath());

                try
                {
                    String vscanCommand = BudgesContext.getConfigService().getVscanCommandPath();
                    boolean success = CmdLineUtil.runCmd(vscanCommand, dirOrFileToScan.getAbsolutePath());
                    
                    if (success) {
                        // No viruses found, so move the file/dir
                        log.debug("About to move successfully virus scanned file: " + dirOrFileToScan.getAbsolutePath() + " to "
                                + destDir.getAbsolutePath());
                        
                        try {
                            log.debug("Moving with fileutils instead of commandline");
                            if (destDir.isDirectory()) {
                                FileUtils.copyDirectoryToDirectory(dirOrFileToScan, destDir);
                            } else {
                                FileUtils.moveFile(dirOrFileToScan, destDir);
                            }
                        } catch (IOException exception) {
                            throw new RuntimeException("Failed to move dir/file: " + dirOrFileToScan.getAbsolutePath() + " to "
                                    + destDir.getAbsolutePath(), exception);
                        }
                        log.debug("Successfully virus scanned and moved file: " + dirOrFileToScan.getAbsolutePath() + " to "
                                + destDir.getAbsolutePath());
                    } 
                    else
                    {
                        // Here we are assuming any failures running the virus
                        // scanner implies viruses found (virus scanner
                        // application can fail without finding viruses -- e.g.,
                        // integrity check on DAT file, etc.)
                        StringBuffer sb = new StringBuffer("Virus(es) found in file/dir: " + dirOrFileToScan.getAbsolutePath() + "\n");

                        if (fileToScanList == null)
                        {
                            addError(sb.toString());
                        }
                        else
                        {
                            for (BudgesFile fileToScan : fileToScanList)
                            {
                                String err = "File may be virus infected: " + fileToScan.getOriginalName();
                                addError(err);
                                sb.append(err + " (" + fileToScan.getFile().getAbsolutePath() + ")\n");
                            }
                        }

                        log.error(sb);
                    }
                }
                finally
                {
                    // Make sure the src file is deleted when we're done
                    if (dirOrFileToScan.exists())
                        FileUtils.deleteQuietly(dirOrFileToScan);

                    if (dirOrFileToScan.exists())
                        log.debug("Could not delete from sandbox: " + dirOrFileToScan.getAbsolutePath());
                    else
                        log.debug("Successufully deleted from sandbox: " + dirOrFileToScan.getAbsolutePath());
                }
            }
            else
            {
                throw new RuntimeException("Destination directory must exist.");
            }
        }
        else
        {
            throw new RuntimeException("File or directory to scan must exist.");
        }
    }
    
    public void virusScan(File file) {
	    String vscanCommand = BudgesContext.getConfigService().getVscanCommandPath();
	    
	    boolean success = CmdLineUtil.runCmd(vscanCommand, file.getAbsolutePath());
	    
	    if (!success) {
	    	// Here we are assuming any failures running the virus
	        // scanner implies viruses found (virus scanner
	        // application can fail without finding viruses -- e.g.,
	        // integrity check on DAT file, etc.)
	        StringBuffer sb = new StringBuffer("Virus(es) found in file/dir: " + file.getAbsolutePath() + "\n");
	
	        if (file == null) {
	            addError(sb.toString());
	        }
	        
	        else {
	        	String err = "File may be virus infected: " + file.getName();
	        	addError(err);
	        	sb.append(err + " (" + file.getAbsolutePath() + ")\n");
	        }
	
	        log.error(sb);
	    } 
	}

    public void addError(String msg)
    {
        errorList.add(new ValidationMessageImpl(msg));
    }
    
    private boolean isValidDestination(File destination) {
        if ( null == destination) {
            return false;
        } else if ( destination.isDirectory()) {
            return destination.exists(); 
        } else {
            return destination.getParentFile().exists();
        }
    }
    
}
