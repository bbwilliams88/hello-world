package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.ObjectContext;

import mil.dtic.cbes.enums.ResourceSummaryEntryType;

public interface ResourceSummaryParent
{
    void sortByDisplayOrder(String string);

    ResourceSummary getResourceSummary();
    ResourceSummaryRow addResourceSummaryRow(ResourceSummaryEntryType entryType);
    void removeResourceSummaryRow(ResourceSummaryRow rsr);

    ObjectContext getObjectContext();

    /**
     * Clear out Resource Summary Out Years.
     */
    default void clearOutYears()
    {
        for (ResourceSummaryRow resourceSummaryRow : getResourceSummary())
            Costs.clearOutYears(resourceSummaryRow.getCosts());
    }
}
