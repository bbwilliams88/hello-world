package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.data.config.InitialSourceType;
import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._LineItemHistory;

public class LineItemHistory extends _LineItemHistory implements HasValidity
{
  private static final long serialVersionUID = 1L;


  @Override
  public Boolean getTest()
  {
    return false;
  }

  @Override
  public InitialSourceType getInitialSource()
  {
    return InitialSourceType.WEB;
  }

  @Override
  public StatusType getStatus()
  {
    return StatusType.ACTIVE;
  }

  @Override
  public boolean isValid()
  {
    return getValidity().isValid();
  }

  @Override
  public boolean isErrors()
  {
    return getValidity().hasErrors();
  }

  @Override
  public boolean isWarnings()
  {
    return getValidity().isInvalid();
  }

  @Override
  public boolean hasEditLock()
  {
    return false;
  }

  @Override
  public boolean isFrozen()
  {
    return false;
  }

  @Override
  public Short getErrorCount()
  {
    return (short) (isErrors() ? 1 : 0);
  }

  @Override
  public Short getWarningCount()
  {
    return (short) (isWarnings() ? 1 : 0);
  }

  @Override
  public Short getP10Count()
  {
    return 0;
  }

  @Override
  public Short getP18Count()
  {
    return 0;
  }

  @Override
  public Short getP20Count()
  {
    return 0;
  }

  @Override
  public Short getP21Count()
  {
    return 0;
  }

  @Override
  public Short getP3aCount()
  {
    return 0;
  }

  @Override
  public Short getP40aCount()
  {
    return 0;
  }

  @Override
  public Short getP5Count()
  {
    return 0;
  }

  @Override
  public Short getP5aCount()
  {
    return 0;
  }

  @Override
  public Short getP17Count()
  {
    return 0;
  }

  @Override
  public Short getP23Count()
  {
    return 0;
  }

  @Override
  public Short getP25Count()
  {
    return 0;
  }

  @Override
  public Short getP26Count()
  {
    return 0;
  }
}
