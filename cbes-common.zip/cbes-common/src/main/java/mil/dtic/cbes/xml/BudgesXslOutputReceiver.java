package mil.dtic.cbes.xml;

import java.io.StringWriter;

import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;
import net.sf.saxon.event.XMLEmitter;
import net.sf.saxon.trans.XPathException;

/**
 * MessageWarner is a receiver for XSLT xsl:message output that will send the
 * output to the logger. Copied and modified Saxon's MessageWarner class.
 */
public class BudgesXslOutputReceiver extends XMLEmitter {
  private static final Logger log = CbesLogFactory.getLog(BudgesXslOutputReceiver.class);
  private static final String XSL_LOG_PREFIX = "XSL OUTPUT: ";  

  @Override
  public void startDocument(int properties) throws XPathException {
    super.setWriter(new StringWriter());
    super.startDocument(properties);
  }

  @Override
  public void endDocument() throws XPathException {
    log.trace(XSL_LOG_PREFIX + getWriter().toString());
  }

  @Override
  public void close() throws XPathException {
    try{
      if (writer != null){
        writer.flush();
      }
    }
    catch (java.io.IOException err){
      throw new XPathException(err);
    }
  }

}
