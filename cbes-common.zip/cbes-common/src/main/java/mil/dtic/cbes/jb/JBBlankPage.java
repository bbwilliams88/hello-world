/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.CbesLogFactory;


public class JBBlankPage extends JBPart implements Cloneable
{
  private static final Logger log = CbesLogFactory.getLog(JBBlankPage.class);


  public JBBlankPage()
  {
    setFileSetting(FileSetting.BLANK);
    setTitle(FileSetting.BLANK.getTitle());
  }


  public JBBlankPage newInstance()
  {
    JBBlankPage jbp = null;
    try
    {
      jbp = (JBBlankPage) super.clone();
    }
    catch (CloneNotSupportedException e)
    {
      log.error("Could not clone JBBlankPage object.", e);
    }
    return jbp;
  }
}
