/*
 * $Id$
 */
package mil.dtic.cbes.output;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;

public class R2ImportItem
{
  protected ProgramElement programElement;
  protected int xmlIndex;
  protected List<String> errorList;
  protected boolean hasWarnings;
  protected boolean importable;

  public R2ImportItem(ProgramElement programElement, int xmlIndex, List<String> errorList, boolean hasWarnings)
  {
    this.programElement = programElement;
    this.xmlIndex = xmlIndex;
    this.errorList = (errorList == null ? new ArrayList<String>() : errorList);
    this.hasWarnings = hasWarnings;
  }


  public boolean isDoImport()
  {
    return CollectionUtils.isEmpty(errorList);
  }


  public boolean isImportSuccessful()
  {
    return programElement.getId() != null && CollectionUtils.isEmpty(errorList);
  }


  public ProgramElement getProgramElement()
  {
    return programElement;
  }


  public void setProgramElement(ProgramElement programElement)
  {
    this.programElement = programElement;
  }


  public int getXmlIndex()
  {
    return xmlIndex;
  }


  public void setXmlIndex(int xmlIndex)
  {
    this.xmlIndex = xmlIndex;
  }


  public List<String> getErrorList()
  {
    return errorList;
  }


  public void setErrorList(List<String> errorList)
  {
    this.errorList = errorList;
  }


  public boolean isHasWarnings()
  {
    return hasWarnings;
  }


  public void setHasWarnings(boolean hasWarnings)
  {
    this.hasWarnings = hasWarnings;
  }


  public boolean isImportable()
  {
    return importable;
  }


  public void setImportable(boolean importable)
  {
    this.importable = importable;
  }

}