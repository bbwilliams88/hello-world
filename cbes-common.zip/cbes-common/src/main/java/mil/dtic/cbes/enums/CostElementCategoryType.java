package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

/**
 *
 */
public enum CostElementCategoryType implements ExtendedEnumeration
{
    // FIXME: These don't correspond to the Java naming convention.

    //p5
    FLYAWAY("Flyaway"),
    HARDWARE("Hardware"),
    SOFTWARE("Software"),
    PACKAGE_FIELDING("Package Fielding"),
    LOGISTICS("Logistics"),
    LAUNCH("Launch"),
    STAGE("Stage"),
    SPACE_VEHICLE("Space Vehicle"),
    VEHICLES("Vehicles"),
    ANCILLARY_EQUIPMENT("Ancillary Equipment"),
    COMMAND_AND_LAUNCH("Command and Launch"),
    CHECKOUT_AND_LAUNCH("Checkout and Launch"),
    SUPPORT("Support"),
    SHIPBUILDINGCTC("Shipbuilding Cost to Complete"), //SCN support for Completion of Prior Year Shipbuilding Programs
    RECURRING("Recurring"),  //p3a also
    NONRECURRING("Non-Recurring"), //p3a also
    //p3a
    AKit("A-Kit"),
    BKit("B-Kit"),
    //p18
    InitialSpares("Initial Spares"),
    OutfittingSpares("OUTFITTING"),
    ReplenishmentSpares("Replenishment Spares"),
    //p20
    OtherGains("Other Gains"),
    UsageLosses("Usage/Losses"),
    TotalAssets("Total Assets On Hand"),
    InventoryObjectives("Inventory Objective (IO)"),
    Training("Training Expenditures"),
    NonTraining("Non-Training Expenditures"),
    EligibleForReplacement("Eligible for Replacement"),
    AircraftInventory("Aircraft Inventory"),
    //p10
    CFE,
    GFE,
    EOQ,
    Other,
    //p23
    ActiveForceInventory("Active Force Inventory"),
    School("Schools"),
    OtherTraining("Other Training"),
    TotalRequirement("Total Requirements"),
    ;

    private final String databaseValue;

    private CostElementCategoryType()
    {
        this.databaseValue = toString();
    }

    private CostElementCategoryType(String dbName)
    {
        this.databaseValue = dbName;
    }

    public String getDatabaseValue()
    {
        return databaseValue;
    }

    public static CostElementCategoryType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(CostElementCategoryType.class, databaseValue);
    }

    public static CostElementCategoryType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(CostElementCategoryType.class, enumValue);
    }
}
