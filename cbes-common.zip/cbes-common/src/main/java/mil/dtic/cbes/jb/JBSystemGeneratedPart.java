/*
 * $Id$
 */
package mil.dtic.cbes.jb;

public interface JBSystemGeneratedPart
{

}
