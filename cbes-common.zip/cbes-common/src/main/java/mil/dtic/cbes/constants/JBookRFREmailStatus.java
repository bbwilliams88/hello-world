package mil.dtic.cbes.constants;

import java.util.HashMap;
import java.util.Map;

public enum JBookRFREmailStatus {
	
	EMAIL_FAIL(0,"Email Failure, RFR Email not attempted"),
	EMAIL_SUCCESS(1, "Email Success, RFR Email not required"),
	EMAIL_RFR_FAIL(2,"Email Success, RFR Email Failure"),
	EMAIL_RFR_SUCCESS(3, "Email Success, RFR Email Success");
	
	private static Map<Integer, JBookRFREmailStatus> map = new HashMap<>();
	
	static {
		for (JBookRFREmailStatus jBookRFREmailStatus : JBookRFREmailStatus.values()){
			map.put(jBookRFREmailStatus.code, jBookRFREmailStatus);
		}
	}
	
	private JBookRFREmailStatus(Integer code, String displayMessage){
		this.code = code;
		this.displayMessage = displayMessage;
	}
	
	private final Integer code;
	private final String displayMessage;
	
	public Integer getCode() {
		return code;
	}
	public String getDisplayMessage() {
		return displayMessage;
	}
	
	public static JBookRFREmailStatus valueOf(int code){
		return map.get(code);
	}

}
