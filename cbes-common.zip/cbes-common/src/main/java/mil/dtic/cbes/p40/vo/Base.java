package mil.dtic.cbes.p40.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.cayenne.Cayenne;
import org.apache.cayenne.CayenneDataObject;
import org.apache.cayenne.DataObject;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.PersistenceState;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.map.ObjRelationship;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import com.google.common.base.Function;

import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.service.exception.NotFoundException;
import mil.dtic.cbes.p40.vo.util.EqualsPredicate;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.validation.backend.AllowedRangeCost;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;


/**
 *
 */
public abstract class Base extends CayenneDataObject implements IBase, Serializable
{
    private static final Logger log = CbesLogFactory.getLog(Base.class);
    private static final long serialVersionUID = 1L;

    private static final List<Class<?>> lineItemClasses =
            Collections.unmodifiableList(Arrays.asList(new Class<?>[]
                    { LineItem.class,
                      ResourceSummaryRow.class,
                      CompoSplit.class,
                      OtherPe.class,
                      CodeBPe.class,
                      ItemGroup.class,
                      P40aCategory.class,
                      Item.class,
                      CostElement.class,
                      Manufacturer.class,
                      HistoryPlanning.class,
                      DeliverySchedule.class,
                      MonthlyDelivery.class,
                      Facility.class,
                      InactiveIndustrialFacility.class,
                      LayawayFacility.class,
                      ProductionSupportFacility.class,
                      ModsItemGroup.class,
                      ModsItem.class,
                      ModsManufacturer.class,
                      ModsImplementationMethod.class,
                      InstallationCost.class,
                      InstallationSchedule.class,
                      QuarterlySchedule.class,
                      SparesRequirement.class,
                      SparesBudgetActivity.class,
                      SparesItem.class,
                      P10AdvanceProcurement.class,
                      P10CostElement.class,
                      ShipClass.class,
                      ShipCostCategory.class,
                      ShipCategoryItem.class,
                      ShipsOutfittingDeliveryExhibit.class }));

    /**
     * A private Tapestry 5 ID used mainly in AJAX calls to identify objects
     * uniquely without exposing primary key details. It is temporary and unique
     * every time an object is loaded/created (loading the same object a second
     * time will produce a new ID).
     */
    private String t5id;


    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.IBase#getId()
     *
     * @return The primary key for this object or <tt>null</tt> if it is a new
     *         non-persisted object.
     */
    @Override
    public Integer getId()
    {
        if (super.getObjectId() == null || super.getObjectId().isTemporary())
            return null;

        return Cayenne.intPKForObject(this);
    }

    /**
     * @see mil.dtic.cbes.p40.vo.IBase#getT5Id()
     *
     * @return The unique Tapestry 5 ID for this object, creating one if needed.
     */
    @Override
    public String getT5Id()
    {
        if (t5id == null)
            t5id = UUID.randomUUID().toString();

        return t5id;
    }

    /**
     * @see mil.dtic.cbes.p40.vo.IBase#setT5Id(java.lang.String)
     *
     * @return Sets the Tapestry 5 ID for this object. This ID should be unique,
     *         but no test is performed to ensure it is.
     */
    @Override
    public void setT5Id(String t5id)
    {
        this.t5id = t5id;
    }

    // public void setDummy(Object o) {}


    /**
     * Assumes the property is called displayOrder, and that relName is an
     * actual list. Logs error on failure.
     */
    public void sortByDisplayOrder(String relName)
    {
		List<?> l = (List<?>) readProperty(relName);
		new Ordering("displayOrder", SortOrder.ASCENDING).orderList(l);
    }

    public LineItem getParentLineItem()
    {
      if (!isLineitemClass(getClass())) {
        log.error("getParentLineItem called on wrong class? " + getClass());
        return null;
      }
      return (LineItem)getParentLineItem(getContext(), this);
    }

    private static Base getParentLineItem(ObjectContext ctx, Base obj)
    {
      if (obj instanceof CostElement) //cost element has dual parents.
        return getParentLineItemForCostElement((CostElement)obj);
      if (obj instanceof Item)
        return getParentLineItemForItem((Item)obj);
      if (obj instanceof P10AdvanceProcurement && ((P10AdvanceProcurement) obj).getItem() != null)
        return getParentLineItemForItem(((P10AdvanceProcurement)obj).getItem());
      if (obj instanceof P10AdvanceProcurement && ((P10AdvanceProcurement) obj).getModsItemGroup() != null)
        return getParentLineItemForModsItemGroup(((P10AdvanceProcurement)obj).getModsItemGroup());
      if (obj instanceof LineItem)
        return obj;
      if (obj instanceof ItemExhibitType && ((ItemExhibitType)obj).getExhibit() != null)
        return ((ItemExhibitType)obj).getExhibit().getLineItem();
      Collection<ObjRelationship> rels =
        ctx.getEntityResolver().lookupObjEntity(obj.getClass()).getRelationships();
      for (ObjRelationship rel : rels) {
        if (!rel.isToMany() && rel.getReverseRelationship().isToMany()) {
          Base b = (Base)obj.readProperty(rel.getName());
          if (b==null || b instanceof LookupBase || b instanceof Costs) //ContractMethodTypeFundingVehicle & Costs are toMany
            continue;
          return getParentLineItem(ctx, b);
        }
      }
      log.error("parent rel not found");
      return null;
    }


    public Costs setSubtotalValuesInMillion(Costs subtotals) throws MethodDispatchException {
      for (int i = 0; i < Util.getFyMethodList().length;i++) {
        BigDecimal currentValue = Util.getDecimalCost(subtotals, Util.getFyMethodList()[i]);
        if (currentValue != null) {
          Util.setDecimalCost(subtotals, Util.getFySetMethodList()[i], new BigDecimal(currentValue.movePointLeft(6).setScale(3, BigDecimal.ROUND_HALF_EVEN).toPlainString()));
        }
      }
      return subtotals;
    }

    public void addToSubtotalInDollars(Costs subtotals, Costs childCost) throws MethodDispatchException {
      for (int i = 0; i < Util.getFyMethodList().length;i++) {
        BigDecimal value = Util.getDecimalCost(childCost, Util.getFyMethodList()[i]);
        AllowedRangeCost rangeCost = new AllowedRangeCost(value, null, null, getParentLineItem());
        if (!rangeCost.isEmpty()) {
          BigDecimal currentValueInDollars = Util.getDecimalCost(subtotals, Util.getFyMethodList()[i]);
          if (currentValueInDollars != null)
            Util.setDecimalCost(subtotals, Util.getFySetMethodList()[i], currentValueInDollars.add(rangeCost.getMiddleValueInDollars()));
          else
            Util.setDecimalCost(subtotals, Util.getFySetMethodList()[i], rangeCost.getMiddleValueInDollars());
        }
      }
      if (childCost != null && childCost.isContinuing()) {
        subtotals.setContinuing(true);
      }
      if (subtotals.getTotal() != null && subtotals.isContinuing())
        subtotals.setTotal(null);
    }

    public void addToSubtotalInDollars(Costs subtotals, List<? extends CostContainer> children) throws MethodDispatchException
    {
      for (int i = 0; i < Util.getFyMethodList().length;i++) {
         AllowedRangeCost rangeCost = new AllowedRangeCost(children, Util.getFyMethodList()[i], getParentLineItem());
         if (!rangeCost.isEmpty()) {
           BigDecimal currentValue = Util.getDecimalCost(subtotals, Util.getFyMethodList()[i]);
           if (currentValue != null)
             Util.setDecimalCost(subtotals, Util.getFySetMethodList()[i], new BigDecimal(currentValue.add(rangeCost.getMiddleValueInDollars()).toPlainString()));
           else
             Util.setDecimalCost(subtotals, Util.getFySetMethodList()[i], new BigDecimal(rangeCost.getMiddleValueInDollars().toPlainString()));
         }
      }
      if (subtotals != null && children != null && isChildContinuing(children)) {
        subtotals.setContinuing(true);
      }
      if (subtotals != null && subtotals.getTotal() != null && subtotals.isContinuing()){
        subtotals.setTotal(null);
      }
    }


    /**
     * Adds one child cost to the subtotal cost that is passed in. Used for
     * calculating subtotals in the UI.
     *
     * @param subtotalCosts
     *            Costs of the subtotal being updated
     * @param childCosts
     *            Costs of one of the children used to calculate the subtotal
     *            (like CostElements or Items)
     */
    //TODO: Remove this method after next release
    public Costs addChildToSubtotal(Costs subtotalCosts, Costs childCosts)
    {
      if(childCosts != null)
      {
        if(subtotalCosts == null)
          subtotalCosts = getContext().newObject(Costs.class);
        if (subtotalCosts.getPriorYears() != null && childCosts.getPriorYears() != null)
            subtotalCosts.setPriorYears(subtotalCosts.getPriorYears().add(childCosts.getPriorYears()));
        else if (subtotalCosts.getPriorYears() == null)
            subtotalCosts.setPriorYears(childCosts.getPriorYears());

        if (subtotalCosts.getPriorYear() != null && childCosts.getPriorYear() != null)
            subtotalCosts.setPriorYear(subtotalCosts.getPriorYear().add(childCosts.getPriorYear()));
        else if (subtotalCosts.getPriorYear() == null)
            subtotalCosts.setPriorYear(childCosts.getPriorYear());

        if (subtotalCosts.getCurrentYear() != null && childCosts.getCurrentYear() != null)
            subtotalCosts.setCurrentYear(subtotalCosts.getCurrentYear().add(childCosts.getCurrentYear()));
        else if (subtotalCosts.getCurrentYear() == null)
            subtotalCosts.setCurrentYear(childCosts.getCurrentYear());

        if (subtotalCosts.getBy1() != null && childCosts.getBy1() != null)
            subtotalCosts.setBy1(subtotalCosts.getBy1().add(childCosts.getBy1()));
        else if (subtotalCosts.getBy1() == null)
            subtotalCosts.setBy1(childCosts.getBy1());

        if (subtotalCosts.getBy1Ooc() != null && childCosts.getBy1Ooc() != null)
            subtotalCosts.setBy1Ooc(subtotalCosts.getBy1Ooc().add(childCosts.getBy1Ooc()));
        else if (subtotalCosts.getBy1Ooc() == null)
            subtotalCosts.setBy1Ooc(childCosts.getBy1Ooc());

        if (subtotalCosts.getBy1Base() != null && childCosts.getBy1Base() != null)
            subtotalCosts.setBy1Base(subtotalCosts.getBy1Base().add(childCosts.getBy1Base()));
        else if (subtotalCosts.getBy1Base() == null)
            subtotalCosts.setBy1Base(childCosts.getBy1Base());

        if (subtotalCosts.getBy2() != null && childCosts.getBy2() != null)
            subtotalCosts.setBy2(subtotalCosts.getBy2().add(childCosts.getBy2()));
        else if (subtotalCosts.getBy2() == null)
            subtotalCosts.setBy2(childCosts.getBy2());

        if (subtotalCosts.getBy3() != null && childCosts.getBy3() != null)
            subtotalCosts.setBy3(subtotalCosts.getBy3().add(childCosts.getBy3()));
        else if (subtotalCosts.getBy3() == null)
            subtotalCosts.setBy3(childCosts.getBy3());

        if (subtotalCosts.getBy4() != null && childCosts.getBy4() != null)
            subtotalCosts.setBy4(subtotalCosts.getBy4().add(childCosts.getBy4()));
        else if (subtotalCosts.getBy4() == null)
            subtotalCosts.setBy4(childCosts.getBy4());

        if (subtotalCosts.getBy5() != null && childCosts.getBy5() != null)
            subtotalCosts.setBy5(subtotalCosts.getBy5().add(childCosts.getBy5()));
        else if (subtotalCosts.getBy5() == null)
            subtotalCosts.setBy5(childCosts.getBy5());

        if (subtotalCosts.getToComplete() != null && childCosts.getToComplete() != null)
            subtotalCosts.setToComplete(subtotalCosts.getToComplete().add(childCosts.getToComplete()));
        else if (subtotalCosts.getToComplete() == null)
            subtotalCosts.setToComplete(childCosts.getToComplete());

        if (subtotalCosts.isContinuing() || childCosts.isContinuing())
        {
            subtotalCosts.setContinuing(true);
        }
        else
        {
            if (subtotalCosts.getTotal() != null && childCosts.getTotal() != null)
                subtotalCosts.setTotal(subtotalCosts.getTotal().add(childCosts.getTotal()));
            else if (subtotalCosts.getTotal() == null)
                subtotalCosts.setTotal(childCosts.getTotal());
        }
      }
        return subtotalCosts;
    }

    public boolean isChildContinuing(List<? extends CostContainer> costs)
    {
        for (CostContainer cost : costs)
            if (cost != null && cost.getCosts() != null && cost.getCosts().isContinuing())
                return true;

        return false;
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * Fetches all objects of a certain type into the supplied object context.
     *
     * @param context
     *            The Cayenne ObjectContext to fetch objects into. If null, uses
     *            the thread's ObjectContext.
     * @param type
     *            The Cayenne DataObject subclass to fetch.
     * @return A list of Cayenne objects.
     */
    @SuppressWarnings("unchecked")
    protected static <T extends DataObject> List<T> fetchAllForClass(ObjectContext context, Class<T> type)
    {
        if (context == null)
            context = CayenneUtils.createDataContext();

        return context.performQuery(new SelectQuery(type));
    }

  /**
   * Fetches all objects of a certain type into the object context of the caller.
   *
   * @param type The Cayenne DataObject subclass to fetch.
   * @return A list of Cayenne objects.
   */
    // FIXME: This seems awkward telling an object to fetch all objects of a different arbitrary class.
    public <T extends DataObject> List<T> fetchAll(Class<T> type)
    {
        return fetchAllForClass(getContext(), type);
    }

    protected static <T extends DataObject> List<T> fetchAllWithClassForPropertyAndOrdering(ObjectContext context, Class<T> type, String sortProperty,
            SortOrder order)
    {
        return fetch(context, type, Expression.EQUAL_TO, new Ordering[] { new Ordering(sortProperty, order) });
    }

    @SuppressWarnings("unchecked")
    protected static <T extends DataObject> List<T> fetchWithIds(ObjectContext context, Class<T> type, String idCol, Object... ids)
    {
        SelectQuery sq = new SelectQuery(type, ExpressionFactory.inDbExp(idCol, ids));
        return context.performQuery(sq);
    }

    /** marked protected for testcase */
    protected static Map<String, Object> _parsepv(Object[] pvs)
    {
        if (pvs == null)
            return new HashMap<String, Object>(0);
        if (pvs.length % 2 != 0)
            throw new IllegalArgumentException("Odd numbers property-values for _parsepv");
        Map<String, Object> m = new HashMap<String, Object>(pvs.length / 2);
        for (int i = 0, j = pvs.length / 2; j < pvs.length; i++, j++)
        {
            if (pvs[i] == null)
                throw new NullPointerException();
            m.put(pvs[i].toString(), pvs[j]);
        }
        return m;
    }

    @SuppressWarnings("unchecked")
    protected static <T extends DataObject> List<T> fetch(ObjectContext context,
                                                          Class<T>      dataObjectClass,
                                                          int           expressionOperator,
                                                          Ordering[]    orderings,
                                                          Object...     propertiesThenValues)
    {
        SelectQuery query =
                new SelectQuery(dataObjectClass, ExpressionFactory.matchAllExp(_parsepv(propertiesThenValues), expressionOperator));

        if (orderings != null)
            for (Ordering order : orderings)
                query.addOrdering(order);

        return context.performQuery(query);
    }

  //  protected static Ordering[] getOrdering(String property, boolean asc)
  //  {
  //    if (property==null) return null;
  //    return new Ordering[]{new Ordering(property, asc ? SortOrder.ASCENDING : SortOrder.DESCENDING)};
  //  }

    /**
     * Null if not found, random one if more than one.
     *
     * @throws IllegalArgumentException
     *             if the properties couldn't be parsed
     */
    protected static <T extends DataObject> T fetchOne(ObjectContext context, Class<T> dataObjectClass, Object... propertiesThenValues)
    {
        List<T> l = fetch(context, dataObjectClass, Expression.EQUAL_TO, null, propertiesThenValues);
        if (l.size() == 0)
            return null;
        if (l.size() > 1)
            log.error("More than one object in fetchOne");
        return l.get(0);
    }

    private static Base getParentLineItemForCostElement(CostElement ce)
    {
        // if both are set, die instead of stack overflow
        if (ce.getParentCostElement() != null && ce.getItem() != null)
            throw new RuntimeException("both parentCostElement and item are set. That should not happen.");
        if (ce.getParentCostElement() != null)
      	    return getParentLineItemForCostElement(ce.getParentCostElement());
        if (ce.getItem() != null)
            return ce.getItem().getParentLineItem();
        if (ce.getModsItemGroup() != null)
            return ce.getModsItemGroup().getParentLineItem();
        if (ce.getModsItem() != null)
            return ce.getModsItem().getParentLineItem();
        throw new RuntimeException("Oops I messed up CostElement.getParentLineItem");
    }

    private static Base getParentLineItemForItem(Item it)
    {
        if (it != null && it.getExhibit() != null)
            return it.getExhibit().getLineItem();
        else if(it != null && it.getP40aCategory() != null &&  it.getP40aCategory().getItemGroup() != null && it.getP40aCategory().getItemGroup().getExhibit() != null)
            return it.getP40aCategory().getItemGroup().getExhibit().getLineItem();
        return null;
    }

    private static Base getParentLineItemForModsItemGroup(ModsItemGroup modsItemGroup)
    {
        if (modsItemGroup != null && modsItemGroup.getExhibit() != null)
            return modsItemGroup.getExhibit().getLineItem();
        return null;
    }


    public static boolean isLineitemClass(Class<? extends Base> cayenneDataObject)
    {
        return lineItemClasses.contains(cayenneDataObject);
    }

    public String toLowerAndTrim(String string)
    {
        return StringUtils.lowerCase(StringUtils.trim(string));
    }

    protected ResourceSummaryEntry getRse(String title)
    {
        return fetchOne(getContext(), ResourceSummaryEntry.class, ResourceSummaryEntry.TITLE_PROPERTY, title);
    }

//    @SuppressWarnings("unchecked")
//    public <T extends Base> T getInOtherContext(ObjectContext otherContext)
//    {
//        return (T) otherContext.localObject(getObjectId(), this);
//    }
//    /** Return version of this object in the same datacontext as b */
//    @SuppressWarnings("unchecked")
//    public <T> T inContextOf(Base b)
//    {
//        return (T) b.getContext().localObject(getObjectId(), this);
//    }

    // jibx fixed cost element stuff
    @SuppressWarnings("unchecked")
    protected CostElement getFixedCe(String relName, CostElementCategoryType cat)
    {
        // this probably throws an interesting exception when stuff corrupts
        return (CostElement) CollectionUtils.find((List<CostElement>) readProperty(relName),
                new EqualsPredicate(cat, makePath(CostElement.CATEGORY_RELATIONSHIP_PROPERTY, CostElementCategory.TITLE_PROPERTY)));
    }

    protected void setFixedCe(String relName, CostElement ce, CostElement existing, CostElementCategoryType cat)
    {
        if (existing == null && ce != null)
        {
            ce.setCategory(CostElementCategory.fetchByTitleCached(getContext(), cat));
            if (ce.getCategory() == null)
                log.error("category not found: " + cat, new NotFoundException("q"));
            addToManyTarget(relName, ce, true);
        }
        else
        {
            log.debug("Don't use this to replace existing fixed cost elements");
        }
    }

    @SuppressWarnings("unchecked")
    public static <T extends Base> List<T> cachedQuery(ObjectContext context, Class<T> t, Object... propertiesthenvalues)
    {
        SelectQuery one = new SelectQuery(t, ExpressionFactory.matchAllExp(_parsepv(propertiesthenvalues), Expression.EQUAL_TO));
        one.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        return context.performQuery(one);
    }

    public static <T extends Base> T fetchOneCached(ObjectContext context, Class<T> t, Object... propertiesthenvalues)
    {
        List<T> l = cachedQuery(context, t, propertiesthenvalues);
        if (l.size() == 0)
            return null;
        if (l.size() > 1)
            log.warn("select returned more than one " + t.getSimpleName() + ", " + ArrayUtils.toString(propertiesthenvalues));
        return l.get(0);
    }

    public static <T extends HasDisplayOrder> Iterator<T> getIterator(List<T> l)
    {
        return getSortedByDisplayOrder(l).iterator();
    }

    public static <T extends HasDisplayOrder> List<T> getSortedByDisplayOrder(List<T> l)
    {
        return Util.getSortedByDisplayOrder(l);
    }

    public static String makePath(String... pathParts)
    {
        return StringUtils.join(pathParts, '.');
    }

    /** wrapper around CollectionUtils.find */
    @SuppressWarnings("unchecked")
    public static <T> T commonsfind(List<T> l, Predicate p)
    {
        return (T) CollectionUtils.find(l, p);
    }

    public boolean isDeleted()
    {
        return getPersistenceState() == PersistenceState.DELETED;
    }

    public boolean isTransient()
    {
        return getPersistenceState() == PersistenceState.TRANSIENT;
    }

    public boolean isNew()
    {
        return getPersistenceState() == PersistenceState.NEW;
    }

    @SuppressWarnings("unchecked")
    protected String getPeText(String relName)
    {
        if (readProperty(relName) == null || ((List<RelatedPe>) readProperty(relName)).isEmpty())
            return "";

        List<String> parts = new ArrayList<String>();

        for (RelatedPe pe : (List<RelatedPe>) readProperty(relName))
        {
            parts.add(pe.getProgramElementNumber());
        }

        return StringUtils.join(parts, ',');
    }

    @SuppressWarnings("unchecked")
    protected void setPeText(Class<? extends RelatedPe> dataObjectClass, String relName, String oldText, String newVal)
    {
        if (newVal == null)
        {
            if (oldText == null)
                return;
            else
                newVal = "";
        }

        // if nothing changed, do nothing
        if (newVal.equals(oldText))
            return;

        String[] tokens = newVal.split(",");

        // remove all the old ones
        for (RelatedPe pe : new ArrayList<RelatedPe>((List<RelatedPe>) readProperty(relName)))
        {
            removeToManyTarget(relName, pe, true);
            getContext().deleteObjects(pe);
        }

        if (StringUtils.isBlank(newVal))
            return;

        for (String token : tokens)
        {
            token = token.trim();

            if (!"".equals(token))
            {
                RelatedPe newPe = getContext().newObject(dataObjectClass);
                newPe.setProgramElementNumber(token.trim());
                addToManyTarget(relName, newPe, true);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public String getModelsAffectedText()
    {
      List<ModelAffected> modelsAffected;
      if (this instanceof Item)
          modelsAffected = ((Item) this).getModelsAffected();
        else if (this instanceof ModsItemGroup)
          modelsAffected = ((ModsItemGroup) this).getModelsAffected();
        else
          throw new IllegalArgumentException("You are trying to get a list of models affected in a class that does not contain the field for it.");

        if (modelsAffected.isEmpty())
            return "";

        List<String> parts = new ArrayList<String>();

        for (ModelAffected ma : modelsAffected)
        {
            parts.add(ma.getTitle());
        }

        return StringUtils.join(parts, ',');
    }

    @SuppressWarnings("unchecked")
    public void setModelsAffectedText(String newVal)
    {
        String oldVal = getModelsAffectedText();

        if (StringUtils.equals(oldVal, newVal))
            return; // Nothing changed.

        String[] tokens = StringUtils.split(newVal == null ? "" : newVal, ",");
        List<String> parts = new ArrayList<String>(tokens.length);

        for (String aToken : tokens)
          parts.add(aToken.trim());

        if (StringUtils.equals(oldVal, StringUtils.join(parts, ',')))
          return; // Nothing changed (probably).

        List<ModelAffected> modelsAffected = new ArrayList<ModelAffected>(0);

        if (this instanceof Item)
          modelsAffected = ((Item) this).getModelsAffected();
        else if (this instanceof ModsItemGroup)
          modelsAffected = ((ModsItemGroup) this).getModelsAffected();

        // remove all the old ones
        for (ModelAffected ma : new ArrayList<ModelAffected>(modelsAffected))
        {
            ma.setModGroup(null);
            ma.setP40aItem(null);
            ma.delete();
        }

        if (StringUtils.isBlank(newVal))
            return; // No new MAs to add.

        // Add new MAs
        for (String token : tokens)
        {
            token = token.trim();

            if (!"".equals(token))
            {
                ModelAffected newMa = getContext().newObject(ModelAffected.class);
                newMa.setTitle(token);
                if (this instanceof Item)
                  ((Item) this).addToModelsAffected(newMa);
                else if (this instanceof ModsItemGroup)
                  ((ModsItemGroup) this).addToModelsAffected(newMa);
            }
        }
    }

    /** Delete object using its own datacontext */
    public void delete()
    {
      if(getContext() != null)
        getContext().deleteObjects(this);
    }

    /**
     * Create a {@link Function} that extracts the {@link Comparable} property
     * specified by relName from objects.
     */
    public static <F extends Base, T extends Comparable<?>> Function<F, T> fc(final String relName)
    {
        return new Function<F, T>()
        {
            @Override
            @SuppressWarnings("unchecked")
            public T apply(F from)
            {
              if (from != null)
              {
                return (T) from.readNestedProperty(relName);
              }
              else
              {
                NullPointerException e = new NullPointerException("Invalid 'from' parameter.");
                log.error("When trying to extract @link Comparable property an null pointer to an object was used.", e);
                throw e;
              }
            }
        };
    }

    /**
     * Create a {@link Function} that extracts the {@link Comparable} property
     * specified by relName from objects.
     */
    public static <F extends Base, T extends Base> Function<F, T> f(final String relName)
    {
        return new Function<F, T>()
        {
            @Override
            @SuppressWarnings("unchecked")
            public T apply(F from)
            {
              if (from != null)
              {
                return (T) from.readNestedProperty(relName);
              }
              else
              {
                NullPointerException e = new NullPointerException("Invalid 'from' parameter.");
                log.error("When trying to extract @link Comparable property an null pointer to an object was used.", e);
                throw e;
              }
            }
        };
    }

    public String toJson(List<String> desiredProps)
    {
        return Util.toJson(this, desiredProps);
    }

    /**
     * Replaces a costs relationship for this object. Any existing costs is
     * deleted.
     *
     * @param newCosts
     *            The new costs.
     * @param relationshipKey
     *            The relationship key for the costs object (generated by
     *            Cayenne in the superclass).
     */
    public void replaceCosts(Costs newCosts, String relationshipKey)
    {
        Costs oldCosts = (Costs) readProperty(relationshipKey);

        setToOneTarget(relationshipKey, newCosts, true);

        if (oldCosts != null)
            oldCosts.delete();
    }

    /**
     * This method exists entirely because getDataContext() is deprecated in
     * CayenneDataObject and we need access to the DataContext (without
     * deprecation warnings) to do certain operations.
     *
     * @return The DataContext for this object.
     */
    public DataContext getContext()
    {
        return (DataContext) getObjectContext();
    }
}