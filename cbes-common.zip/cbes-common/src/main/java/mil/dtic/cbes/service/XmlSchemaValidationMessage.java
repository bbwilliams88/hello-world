/*
 * $Id$
 */
package mil.dtic.cbes.service;

import org.xml.sax.SAXParseException;

public class XmlSchemaValidationMessage extends ValidationMessageImpl
{
  SAXParseException saxParseException;  
  
  public XmlSchemaValidationMessage(SAXParseException saxParseException, int severity)
  {
    super(saxParseException.getMessage(), null, saxParseException.getLineNumber(), saxParseException.getColumnNumber(), severity);
    this.saxParseException = saxParseException;
  }

  public SAXParseException getSaxParseException()
  {
    return this.saxParseException;
  }
}



