package mil.dtic.cbes.p40.vo;

import java.io.Serializable;


public interface IBase extends Serializable
{
  Integer getId();
  String getT5Id();
  void setT5Id(String t5id);
}