package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._P40User;
import mil.dtic.cbes.p40.vo.util.EqualsPredicate;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.utility.CayenneUtils;

public class P40User extends _P40User
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    //stuff whatever into these columns
    setRole(LdapDAO.GROUP_R2_USER);
    setCreatePePriv("N");
  }

  public List<ServiceAgency> getActiveAgencies() {
    Expression exp = ExpressionFactory.matchExp(ServiceAgency.STATUS_PROPERTY, StatusType.ACTIVE);
    return exp.filterObjects(super.getAgencies());
  }


  public static P40User fetchWithLdapId(ObjectContext context, String ldapid)
  {
    return Base.fetchOne(context, P40User.class, P40User.USER_LDAP_ID_PROPERTY, ldapid);
  }

  public static List<P40User> fetchAllOrderedByLdap(ObjectContext context)
  {
    return Base.fetchAllWithClassForPropertyAndOrdering(context, P40User.class, P40User.USER_LDAP_ID_PROPERTY, SortOrder.ASCENDING);
  }

  public static List<P40User> fetchAllActiveUsers(ObjectContext context)
  {
    Ordering[] ordering = new Ordering[1];
    ordering[0] = new Ordering(P40User.USER_LDAP_ID_PROPERTY, SortOrder.ASCENDING);
    List<Role> roles = Role.fetchAll(context);
    return fetch(context,P40User.class,Expression.IN, ordering, P40User.STATUS_PROPERTY, P40User.ROLES_RELATIONSHIP_PROPERTY,Lists.newArrayList(StatusType.ACTIVE), roles );
  }


  public static List<P40User> fetchAllByServiceAgency(ObjectContext context, List<ServiceAgency> organizations)
  {
    List<P40User> results = fetchAllOrderedByLdap(context);

    List<ServiceAgency> localOrganizations = new ArrayList<>();

    // Copy agencies into user context.
    for (ServiceAgency organization : organizations)
        localOrganizations.add(CayenneUtils.copyToContext(organization, context));

//    in-memory expressions may not work for some to-many relationships
    Expression exp = ExpressionFactory.inExp(P40User.AGENCIES_RELATIONSHIP_PROPERTY, localOrganizations);

    return exp.filterObjects(results);
  }

  public static P40User createNew(ObjectContext context, LdapUser luser)
  {
    P40User user = context.newObject(P40User.class);
    user.setUserLdapId(luser.getLdapUserId());
    user.setStatus(StatusType.NEW);
    user.updateFromLdap(luser);
    return user;
  }

  public void updateFromLdap(LdapUser luser)
  {
    setEmail(luser.getEmailAddress());
    setFirstName(luser.getFirstName());
    setFullName(luser.getFullName());
    setLastName(luser.getLastName());
    setMiddleInitial(luser.getMiddleInitial());
    setPhoneNum(luser.getPhoneNumber());
  }


  // FIXME: Bad Name.
  public boolean hasPermission(String permissionName)
  {
    try
    {
      if (Iterables.find(getPermissions(), new EqualsPredicate<Permission>(permissionName, Permission.NAME_PROPERTY))!=null)
      {
        return true;
      }
      return false;
    }
    catch (NoSuchElementException e)
    {
      return false;
    }
  }

  // FIXME: Bad Name.
  public boolean hasPermission(Permission p)
  {
    return hasPermission(p.getName());
  }

    // FIXME: Bad Name.
    public boolean hasRole(String roleName)
    {
        return getRoles().stream().filter(role -> role.getName().equals(roleName)).collect(Collectors.toList()).size() > 0;

//        try
//        {
//            if (Iterables.find(getRoles(), new EqualsPredicate<Role>(roleName, Role.NAME_PROPERTY)) != null)
//            {
//                return true;
//            }
//        }
//        catch (NoSuchElementException e)
//        {
//            // Log exception
//        }
//
//        return false;
    }

    // FIXME: Bad Name.
    public boolean hasRole(Role r)
    {
        return hasRole(r.getName());
    }

    public boolean isApplicationManager()
    {
        return hasRole(Role.APPMGR);
    }

    public boolean isSiteAdministrator()
    {
        return hasRole(Role.SITEADMIN);
    }

    public boolean isLocalAdministrator()
    {
        return hasRole(Role.LOCALSITEADMIN);
    }

    public boolean isUser()
    {
        return hasRole(Role.USER);
    }

    public Role getGreatestRole()
    {
        return getRoles().stream().max(Comparator.comparing(Role::getRank)).orElse(null);
    }

    public int getGreatestRoleRank()
    {
        Role greatestRole = getGreatestRole();

        if (greatestRole == null)
            return 0;
        else
            return greatestRole.getRank();
    }

  // FIXME: Bad Name.
  public boolean hasAgency(ServiceAgency agency)
  {
    return hasAgency(agency.getCode());
  }

  // FIXME: Bad Name.
  public boolean hasAgency(String code)
  {
    try
    {
      if (Iterables.find(getActiveAgencies(), new EqualsPredicate<ServiceAgency>(code, ServiceAgency.CODE_PROPERTY))!=null)
      {
        return true;
      }
      return false;
    }
    catch (NoSuchElementException e)
    {
      return false;
    }
  }

  public List<LineItem> getEditableLineItems()
  {
    List<LineItem> lineItems = new ArrayList<LineItem>();
    List<UserLineItem> userLineItems = getUserLineItems();
    for (UserLineItem ui: userLineItems)
    {
      if (ui.isEditPrivilege())
      {
        lineItems.add(ui.getLineItem());
      }
    }
    return lineItems;
  }

  public List<LineItem> getViewableLineItems()
  {
    List<LineItem> lineItems = new ArrayList<LineItem>();
    List<UserLineItem> userLineItems = getUserLineItems();
    for (UserLineItem ui: userLineItems)
    {
      if (ui.isViewPrivilege())
      {
        lineItems.add(ui.getLineItem());
      }
    }
    return lineItems;
  }

  public List<LineItem> getNonAccessibleLineItems()
  {
    List<LineItem> lineItems = new ArrayList<LineItem>();
    List<UserLineItem> userLineItems = getUserLineItems();
    for (UserLineItem ui: userLineItems)
    {
      if (!ui.isViewPrivilege() && !ui.isEditPrivilege())
      {
        lineItems.add(ui.getLineItem());
      }
    }
    return lineItems;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (obj==null)
    {
      return false;
    }
    if (obj.getClass()!= getClass())
    {
      return false;
    }
    P40User otherUser = (P40User)obj;
    return new EqualsBuilder().append(otherUser.getUserLdapId(), getUserLdapId()).isEquals();
  }

  @Override
  public int hashCode()
  {
    return new HashCodeBuilder().append(getUserLdapId()).toHashCode();
  }
}
