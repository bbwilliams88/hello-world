package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

import org.jibx.runtime.IUnmarshallingContext;

public interface Cost
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    BigDecimal getQuantity();
    void setQuantity(BigDecimal quantity);

    BigDecimal getTotalCost();
    void setTotalCost(BigDecimal totalCost);

    BigDecimal getUnitCost();
    void setUnitCost(BigDecimal unitCost);

    String getYear();

    /** Return true if any of the 3 are nonnull */
    boolean anyExist();

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // FIXME: Is this used?
    /** Return true if any of the 3 are nonnull */
    public void postset(IUnmarshallingContext ctx);
}