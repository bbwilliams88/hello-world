package mil.dtic.cbes.dto;

import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import java.util.Date;

public class StatusTrackerEntry {
	private String agencyCode;
	private String appnNumber;
	private boolean osdSelected;
	private boolean ombSelected;
	private String osdSelectedDate;
	private String ombSelectedDate;
	private String dateCreatedAj;
	private String dateFinalSubmitted;
	private String submitter;
	private Date dateCreatedFormatted;
	
	
	private JBookWorkFlowStatus status;
	
	public StatusTrackerEntry(String agencyCode, String appnNumber, boolean osdSelected, boolean ombSelected, String osdSelectedDate, String ombSelectedDate, 
			String dateCreatedAj, Date dateCreatedFormatted, String dateFinalSubmitted, String submitter, JBookWorkFlowStatus status) {
		super();
		this.agencyCode = agencyCode;
		this.appnNumber = appnNumber;
		this.osdSelected = osdSelected;
		this.ombSelected = ombSelected;
		this.osdSelectedDate = osdSelectedDate;
		this.ombSelectedDate = ombSelectedDate;
		this.dateCreatedAj = dateCreatedAj;
		this.dateCreatedFormatted = dateCreatedFormatted;
		this.dateFinalSubmitted = dateFinalSubmitted;
		this.submitter = submitter;
		this.status = status;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAppnNumber() {
		return appnNumber;
	}

	public void setAppnNumber(String appnNumber) {
		this.appnNumber = appnNumber;
	}

	public boolean isOsdSelected() {
		return osdSelected;
	}

	public void setOsdSelected(boolean osdSelected) {
		this.osdSelected = osdSelected;
	}
	
	public String getOsdSelectedDate() {
		return osdSelectedDate;
	}

	public void setOsdSelectedDate(String osdSelected) {
		this.osdSelectedDate = osdSelectedDate;
	}

	public boolean isOmbSelected() {
		return ombSelected;
	}

	public void setOmbSelected(boolean ombSelected) {
		this.ombSelected = ombSelected;
	}
	
	public String getOmbSelectedDate() {
		return ombSelectedDate;
	}

	public void setOmbSelectedDate(String ombSelectedDate) {
		this.ombSelectedDate = ombSelectedDate;
	}
	
	public String getDateCreatedAj() {
		return dateCreatedAj;
	}

	public void setDateCreatedAj(String dateCreatedAj) {
		this.dateCreatedAj = dateCreatedAj;
	}

	public Date getDateCreatedFormatted() {
		return dateCreatedFormatted;
	}

	public void setDateCreatedFormatted(Date dateCreatedFormatted) {
		this.dateCreatedFormatted = dateCreatedFormatted;
	}
	
	public String getDateFinalSubmitted() {
		return dateFinalSubmitted;
	}

	public void setDateFinalSubmitted(String dateFinalSubmitted) {
		this.dateFinalSubmitted = dateFinalSubmitted;
	}
	
	public String getSubmitter() {
		return submitter;
	}

	public void setSubmitter(String submitter) {
		this.submitter = submitter;
	}

	public JBookWorkFlowStatus getStatus() {
		return status;
	}

	public void setStatus(JBookWorkFlowStatus status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencyCode == null) ? 0 : agencyCode.hashCode());
		result = prime * result + ((appnNumber == null) ? 0 : appnNumber.hashCode());
		result = prime * result + (ombSelected ? 1231 : 1237);
		result = prime * result + ((ombSelectedDate == null) ? 0 : ombSelectedDate.hashCode());
		result = prime * result + (osdSelected ? 1231 : 1237);
		result = prime * result + ((osdSelectedDate == null) ? 0 : osdSelectedDate.hashCode());
		result = prime * result + ((dateCreatedAj == null) ? 0 : dateCreatedAj.hashCode());
		result = prime * result + ((dateCreatedFormatted == null) ? 0 : dateCreatedFormatted.hashCode());
		result = prime * result + ((dateFinalSubmitted == null) ? 0 : dateFinalSubmitted.hashCode());
		result = prime * result + ((submitter == null) ? 0 : submitter.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StatusTrackerEntry other = (StatusTrackerEntry) obj;
		if (agencyCode == null) {
			if (other.agencyCode != null)
				return false;
		} else if (!agencyCode.equals(other.agencyCode))
			return false;
		if (appnNumber == null) {
			if (other.appnNumber != null)
				return false;
		} else if (!appnNumber.equals(other.appnNumber))
			return false;
		if (ombSelected != other.ombSelected)
			return false;
		if (ombSelectedDate == null) {
			if (other.ombSelectedDate != null)
				return false;
		} else if (!ombSelectedDate.equals(other.ombSelectedDate))
			return false;
		if (osdSelected != other.osdSelected)
			return false;
		if (osdSelectedDate == null) {
			if (other.osdSelectedDate != null)
				return false;
		} else if (!osdSelectedDate.equals(other.osdSelectedDate))
			return false;
		if (dateCreatedAj == null) {
			if (other.dateCreatedAj != null)
				return false;
		} else if (!dateCreatedAj.equals(other.dateCreatedAj))
			return false;
		if (dateCreatedFormatted == null) {
			if (other.dateCreatedFormatted != null)
				return false;
		} else if (dateCreatedFormatted.compareTo(other.dateCreatedFormatted) != 0)
			return false;
		if (dateFinalSubmitted == null) {
			if (other.dateFinalSubmitted != null)
				return false;
		} else if (!dateFinalSubmitted.equals(other.dateFinalSubmitted))
			return false;
		if (submitter == null) {
			if (other.submitter != null)
				return false;
		} else if (!submitter.equals(other.submitter))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
}
