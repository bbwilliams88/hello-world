/*
 * $Id$
 */
package mil.dtic.cbes.output;

import mil.dtic.cbes.service.XmlRulesValidationMessage;


public class R2ImportMessage extends XmlRulesValidationMessage
{

  public R2ImportMessage(String programElementNumber, int programElementIndex, int lineNum, int colNum, String message)
  {
    super(programElementNumber, programElementIndex, lineNum, colNum, message);
  }

  public R2ImportMessage(String programElementNumber, int programElementIndex, String message)
  {
    super(programElementNumber, programElementIndex, NO_VALUE, NO_VALUE, message);
  }
  
}
