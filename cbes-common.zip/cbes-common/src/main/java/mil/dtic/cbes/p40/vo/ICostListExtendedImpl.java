package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;



public interface ICostListExtendedImpl extends CostListExtended
{
  public abstract void setPriorYearsQuantity(BigDecimal priorYearsQuantity);


  public abstract BigDecimal getPriorYearsQuantity();


  public abstract void setPriorYearsTotalCost(BigDecimal priorYearsTotalCost);


  public abstract BigDecimal getPriorYearsTotalCost();


  public abstract void setPriorYearsUnitCost(BigDecimal priorYearsUnitCost);


  public abstract BigDecimal getPriorYearsUnitCost();


  public abstract void setBy1BaseQuantity(BigDecimal by1BaseQuantity);


  public abstract BigDecimal getBy1BaseQuantity();


  public abstract void setBy1BaseTotalCost(BigDecimal by1BaseTotalCost);


  public abstract BigDecimal getBy1BaseTotalCost();


  public abstract void setBy1BaseUnitCost(BigDecimal by1BaseUnitCost);


  public abstract BigDecimal getBy1BaseUnitCost();


  public abstract void setBy1OocQuantity(BigDecimal by1OocQuantity);


  public abstract BigDecimal getBy1OocQuantity();


  public abstract void setBy1OocTotalCost(BigDecimal by1OocTotalCost);


  public abstract BigDecimal getBy1OocTotalCost();


  public abstract void setBy1OocUnitCost(BigDecimal by1OocUnitCost);


  public abstract BigDecimal getBy1OocUnitCost();


  public abstract void setBy1Quantity(BigDecimal by1Quantity);


  public abstract BigDecimal getBy1Quantity();


  public abstract void setBy1TotalCost(BigDecimal by1TotalCost);


  public abstract BigDecimal getBy1TotalCost();


  public abstract void setBy1UnitCost(BigDecimal by1UnitCost);


  public abstract BigDecimal getBy1UnitCost();


  public abstract void setBy2Quantity(BigDecimal by2Quantity);


  public abstract BigDecimal getBy2Quantity();


  public abstract void setBy2TotalCost(BigDecimal by2TotalCost);


  public abstract BigDecimal getBy2TotalCost();


  public abstract void setBy2UnitCost(BigDecimal by2UnitCost);


  public abstract BigDecimal getBy2UnitCost();


  public abstract void setBy3Quantity(BigDecimal by3Quantity);


  public abstract BigDecimal getBy3Quantity();


  public abstract void setBy3TotalCost(BigDecimal by3TotalCost);


  public abstract BigDecimal getBy3TotalCost();


  public abstract void setBy3UnitCost(BigDecimal by3UnitCost);


  public abstract BigDecimal getBy3UnitCost();


  public abstract void setBy4Quantity(BigDecimal by4Quantity);


  public abstract BigDecimal getBy4Quantity();


  public abstract void setBy4TotalCost(BigDecimal by4TotalCost);


  public abstract BigDecimal getBy4TotalCost();


  public abstract void setBy4UnitCost(BigDecimal by4UnitCost);


  public abstract BigDecimal getBy4UnitCost();


  public abstract void setBy5Quantity(BigDecimal by5Quantity);


  public abstract BigDecimal getBy5Quantity();


  public abstract void setBy5TotalCost(BigDecimal by5TotalCost);


  public abstract BigDecimal getBy5TotalCost();


  public abstract void setBy5UnitCost(BigDecimal by5UnitCost);


  public abstract BigDecimal getBy5UnitCost();


  public abstract void setContinuing(boolean continuing);


  public abstract boolean isContinuing();


  public abstract void setCurrentYearQuantity(BigDecimal currentYearQuantity);


  public abstract BigDecimal getCurrentYearQuantity();


  public abstract void setCurrentYearTotalCost(BigDecimal currentYearTotalCost);


  public abstract BigDecimal getCurrentYearTotalCost();


  public abstract void setCurrentYearUnitCost(BigDecimal currentYearUnitCost);


  public abstract BigDecimal getCurrentYearUnitCost();


  public abstract void setPriorYearQuantity(BigDecimal priorYearQuantity);


  public abstract BigDecimal getPriorYearQuantity();


  public abstract void setPriorYearTotalCost(BigDecimal priorYearTotalCost);


  public abstract BigDecimal getPriorYearTotalCost();


  public abstract void setPriorYearUnitCost(BigDecimal priorYearUnitCost);


  public abstract BigDecimal getPriorYearUnitCost();


  public abstract void setToCompleteQuantity(BigDecimal toCompleteQuantity);


  public abstract BigDecimal getToCompleteQuantity();


  public abstract void setToCompleteTotalCost(BigDecimal toCompleteTotalCost);


  public abstract BigDecimal getToCompleteTotalCost();


  public abstract void setToCompleteUnitCost(BigDecimal toCompleteUnitCost);


  public abstract BigDecimal getToCompleteUnitCost();


  public abstract void setTotalQuantity(BigDecimal totalQuantity);


  public abstract BigDecimal getTotalQuantity();


  public abstract void setTotalTotalCost(BigDecimal totalTotalCost);


  public abstract BigDecimal getTotalTotalCost();


  public abstract void setTotalUnitCost(BigDecimal totalUnitCost);


  public abstract BigDecimal getTotalUnitCost();

}