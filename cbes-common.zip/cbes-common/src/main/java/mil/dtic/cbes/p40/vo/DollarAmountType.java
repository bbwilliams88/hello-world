
package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

/** 
 * MYP Object generated with JiBX
 * This class is not to be committed to the DB
 */
public class DollarAmountType
{
    private BigDecimal decimal;
    private String footnote;

    /** 
     * Get the extension value.
     * 
     * @return value
     */
    public BigDecimal getDecimal() {
        return decimal;
    }

    /** 
     * Set the extension value.
     * 
     * @param decimal
     */
    public void setDecimal(BigDecimal decimal) {
        this.decimal = decimal;
    }

    /** 
     * Get the 'footnote' attribute value.
     * 
     * @return value
     */
    public String getFootnote() {
        return footnote;
    }

    /** 
     * Set the 'footnote' attribute value.
     * 
     * @param footnote
     */
    public void setFootnote(String footnote) {
        this.footnote = footnote;
    }
}
