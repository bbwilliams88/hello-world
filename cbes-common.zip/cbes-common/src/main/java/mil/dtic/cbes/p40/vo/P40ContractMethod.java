package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P40ContractMethod;

public class P40ContractMethod extends _P40ContractMethod
{
    private static final long serialVersionUID = 1L;

    @Override
    public String toString()
    {
        return getName();
    }
}
