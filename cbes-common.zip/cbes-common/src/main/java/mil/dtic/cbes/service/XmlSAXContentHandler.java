/*
 * $Id$
 */
package mil.dtic.cbes.service;

import org.apache.logging.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import mil.dtic.utility.CbesLogFactory;

public class XmlSAXContentHandler extends DefaultHandler 
{
  private static final Logger log = CbesLogFactory.getLog(XmlSAXContentHandler.class);

  protected String rootNodeName;
  
  public XmlSAXContentHandler()  
  {
  }

  public void startElement (String uri, String localName, String qName, Attributes attributes) throws SAXException
  {
    if (rootNodeName == null)
    {
      rootNodeName = localName;
      log.debug("Validating XML, found root node \"" + rootNodeName + "\".");
    }
  }

  public String getRootNodeName()
  {
    return rootNodeName;
  }
  
}
