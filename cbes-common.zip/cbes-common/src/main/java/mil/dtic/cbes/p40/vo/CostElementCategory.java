package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.enums.CostElementCategoryType;
import mil.dtic.cbes.enums.ItemExhibitType;
import mil.dtic.cbes.p40.vo.auto._CostElementCategory;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

/**
 *
 */
public class CostElementCategory extends _CostElementCategory implements Equivalence<CostElementCategory>
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return Returns the database value of the title's enum (for historical
     *         reasons -- needed in pulldowns).
     */
    public String getLabel()
    {
        return getTitle().getDatabaseValue();
    }

    /**
     * Method indicates whether a P-5 category will have recurring and
     * non-recurring sub-categories of cost elements, or simply a single list of
     * cost elements. Category types Checkout And Launch, Command And Launch,
     * and Support all are single lists, all others with have recurring and
     * non-recurring sub-lists.
     *
     * @return true if category type is Checkout And Launch, Command And Launch,
     *         and Support; false for all others.
     */
    public boolean isP5TypeWithoutRecurringNonRecurring()
    {
      switch (getTitle())
      {
        case CHECKOUT_AND_LAUNCH:
        case COMMAND_AND_LAUNCH:
        case SUPPORT:
          return true;
        default:
          return false;
      }
    }

    /**
     * Method indicates whether a P-5 category will have recurring and
     * non-recurring sub-categories of cost elements, or simply a single list of
     * cost elements. Category types Checkout And Launch, Command And Launch,
     * and Support all are single lists, all others with have recurring and
     * non-recurring sub-lists.
     *
     * @return true if category type is Flyaway, Hardware, Software, Package
     *         Fields, Logistics, Launch, Stage, Space Vehicles, Vehicles,
     *         Ancillary Equipment, Recurring, or Non-Recurring; false for all
     *         others.
     */
    public boolean isP5TypeWithRecurringNonRecurring()
    {
      switch (getTitle())
      {
        case FLYAWAY:
        case HARDWARE:
        case SOFTWARE:
        case PACKAGE_FIELDING:
        case LOGISTICS:
        case LAUNCH:
        case STAGE:
        case SPACE_VEHICLE:
        case VEHICLES:
        case ANCILLARY_EQUIPMENT:
          return true;
        default:
          return false;
      }
    }

    public boolean isP5TopLevelCategory()
    {
      return (isP5TypeWithoutRecurringNonRecurring() || isP5TypeWithRecurringNonRecurring());
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * Convenience method to fetch all categories ordered by title. Not suitable
     * for ORM manipulation.
     *
     * @param dataContext
     *            The Data Context to fetch the categories into.
     * @param exhibitType
     *            The type of exhibit to filter the cost element categories by.
     * @return The ordered list of categories.
     */
    @SuppressWarnings("unchecked") // FIXME: Rename to a fetch method!
    public static List<CostElementCategory> getOrderedCostElementCategories(ObjectContext dataContext, ItemExhibitType exhibitType)
    {
        Expression expression1 = ExpressionFactory.matchExp(STATUS_PROPERTY, StatusFlag.ACTIVE);
        Expression expression2 =
            ExpressionFactory.matchExp(makePath(CostElementCategory.COST_ELEMENT_CATEGORY_EXHIBITS_RELATIONSHIP_PROPERTY,
                                                CostElementCategoryExhibit.ITEM_EXHIBIT_RELATIONSHIP_PROPERTY,
                                                ItemExhibit.CODE_PROPERTY), exhibitType);
        Ordering ordering = new Ordering(TITLE_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        SelectQuery query = new SelectQuery(CostElementCategory.class, expression1.andExp(expression2));

        query.addOrdering(ordering);

        return dataContext.performQuery(query);
    }

    /**
     * @param objectContext
     *            The ObjectContext to fetch the CostElementCategory into.
     * @param title
     *            The title of the matching CostElementCategory.
     * @return The first (or only) matching CostElementCategory or null if
     *         nothing matches.
     */
    public static CostElementCategory fetchByTitle(ObjectContext objectContext, CostElementCategoryType title)
    {
        return fetchOne(objectContext, CostElementCategory.class, TITLE_PROPERTY, title);
    }

    /**
     * @param objectContext
     *            The ObjectContext to fetch the CostElementCategory into.
     * @param title
     *            The title of the matching CostElementCategory.
     * @return The first (or only) matching CostElementCategory or null if
     *         nothing matches.
     */
    public static CostElementCategory fetchByTitleCached(ObjectContext objectContext, CostElementCategoryType title)
    {
        return fetchOneCached(objectContext, CostElementCategory.class, TITLE_PROPERTY, title);
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(getTitle());

        return builder.toHashCode();
    }

    /**
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(CostElementCategory obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        CostElementCategory other   = obj;
        EqualsBuilder       builder = new EqualsBuilder();

        builder.append(getTitle(), other.getTitle());

        return builder.isEquals();
    }
}
