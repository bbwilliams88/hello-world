/*
 * $Id$
 */
package mil.dtic.cbes.constants;

public enum Environment {

	LOCAL (Constants.ENVIRONMENT_TYPE.LOCAL, "LOCAL", "MY LOCAL ENVIRONMENT"),
	DEV (Constants.ENVIRONMENT_TYPE.DEV, "DEV", "DEV ENVIRONMENT"),
	STAGING (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING", "STAGING ENVIRONMENT"),
	PROD (Constants.ENVIRONMENT_TYPE.PROD, "PROD", "PRODUCTION ENVIRONMENT"),
  DEV_FAILOVER (Constants.ENVIRONMENT_TYPE.DEV, "DEV_FAILOVER", "DEV FAILOVER ENVIRONMENT"),
  STAGING_FAILOVER (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_FAILOVER", "STAGING FAILOVER ENVIRONMENT"),
  STAGING_FAILOVER_1 (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_FAILOVER_1", "STAGING 1 FAILOVER ENVIRONMENT"),
  STAGING_FAILOVER_2 (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_FAILOVER_2", "STAGING 2 FAILOVER ENVIRONMENT"),
  PROD_FAILOVER (Constants.ENVIRONMENT_TYPE.PROD, "PROD_FAILOVER", "PRODUCTION FAILOVER ENVIRONMENT"),
  
  DEV_TRUNK (Constants.ENVIRONMENT_TYPE.DEV, "DEV_TRUNK", "DEV TRUNK ENVIRONMENT"),
  DEV_PREVIEW (Constants.ENVIRONMENT_TYPE.DEV, "DEV_PREVIEW", "DEV PREVIEW ENVIRONMENT"),
  DEV_RELEASE (Constants.ENVIRONMENT_TYPE.DEV, "DEV_RELEASE", "DEV RELEASE ENVIRONMENT"),

  STAGING_TRUNK (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_TRUNK", "STAGING TRUNK ENVIRONMENT"),
  STAGING_PREVIEW (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_PREVIEW", "STAGING PREVIEW ENVIRONMENT"),
  STAGING_RELEASE (Constants.ENVIRONMENT_TYPE.STAGING, "STAGING_RELEASE", "STAGING RELEASE ENVIRONMENT");

	
	private Environment(Constants.ENVIRONMENT_TYPE environmentType, String name, String desc)
	{
	  this.environmentType = environmentType;
		this.name = name;
		this.desc = desc;
	}
	
	private final Constants.ENVIRONMENT_TYPE environmentType;
	private final String name;
	private final String desc;
	
	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return desc;
	}

  public Constants.ENVIRONMENT_TYPE getEnvironmentType() {
    return environmentType;
  }
	
	@Override
  public String toString() {
		return desc;
	}
	
  public static boolean isLocal(Environment env)
  {
    return env != null && env.environmentType == Constants.ENVIRONMENT_TYPE.LOCAL;
  }
  
  public static boolean isDev(Environment env)
  {
    return env != null && env.environmentType == Constants.ENVIRONMENT_TYPE.DEV;
  }

  public static boolean isStaging(Environment env)
  {
    return env != null && env.environmentType == Constants.ENVIRONMENT_TYPE.STAGING;
  }
  
  public static boolean isProd(Environment env)
  {
    return env != null && env.environmentType == Constants.ENVIRONMENT_TYPE.PROD;
  }
  	
}
