package mil.dtic.cbes.service;

import java.util.List;

public class VirusFoundException extends VirusScanException
{
  public VirusFoundException(List<ValidationMessage> errors)
  {
    super(errors);
  }
}