package mil.dtic.cbes.constants;

/**
 * MIME types for files.
 */
public enum MimeType
{
    PDF("application/pdf"),
    WORD("application/msword"),
    EXCEL("application/vnd.ms-excel"),
    ZIP("application/zip"),
    ZZZ("application/zip"),
    XML("text/xml"),
    TEXT("text/plain"),
    GENERIC("application/octet-stream");

    private String mimeType;

    private MimeType(String mimeType)
    {
        this.mimeType = mimeType;
    }

    public String getMimeType()
    {
        return mimeType;
    }
}
