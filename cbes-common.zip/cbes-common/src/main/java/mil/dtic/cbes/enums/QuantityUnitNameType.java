package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum QuantityUnitNameType implements ExtendedEnumeration
{
  Each("EACH"), Tons("TONS"), Feet("FEET"), Lots("LOTS");
  
  private final String dbName;

  private QuantityUnitNameType(String dbName)
  {
    this.dbName = dbName;
  }

  public String getXmlName()
  {
    return toString();
  }
  
  public String getDatabaseValue()
  {
    return dbName;
  }
}
