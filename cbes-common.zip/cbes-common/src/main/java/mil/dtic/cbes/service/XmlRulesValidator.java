package mil.dtic.cbes.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mil.dtic.cbes.rule.RuleGroup;
import mil.dtic.cbes.rule.RuleGroupVisitor;
import mil.dtic.cbes.rule.RuleGroupVisitorFactory;
import mil.dtic.cbes.rule.RuleViolationList;

public class XmlRulesValidator extends XmlValidatorImpl
{
  private RuleGroup objectValidator;
  private Map<String, List<String>> warningListMap;

  public XmlRulesValidator() {
    // empty
  }

  public XmlRulesValidator(RuleGroup objectValidator)
  {
    this.objectValidator = objectValidator;
  }

  @Override
public boolean validate(String organizationCode)
  {
    errorList = new ArrayList<String>();
    warningList = new ArrayList<String>();
    warningListMap = new HashMap<String,List<String>>();

    if (objectValidator != null) {
      RuleGroupVisitor visitor = RuleGroupVisitorFactory.makeVisitor();
      visitor.visit(objectValidator, organizationCode);
      RuleViolationList violations = visitor.getRuleViolations();
      warningList = violations.asList();
      warningListMap = violations.generateKeyToViolationMap();
    }
    return warningList.isEmpty(); /** No "errors" */
  }

  public boolean isWarningsPresent(String organizationCode)
  {
    return !validate(organizationCode);
  }

  @Override
public Map<String, List<String>> getWarningListMap()
  {
    return warningListMap;
  }
}
