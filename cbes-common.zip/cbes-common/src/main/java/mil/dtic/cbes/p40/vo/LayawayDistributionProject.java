package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._LayawayDistributionProject;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

public class LayawayDistributionProject extends _LayawayDistributionProject implements FacilityProjectExtended, FacilityProjectWithTitle, Equivalence<LayawayDistributionProject>
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
    setDisplayOrder(0);
  }

  @Override
  protected void onPrePersist()
  {
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
 }


  public boolean jibx_hasProductionLinesLayaway()
  {
    return getProductionLinesLaidAwayLocation() != null || getProductionLinesLaidAwayName() != null;
  }


  /**
   * HashCode based on Business Rule [E-XML-PROC#P17-100]
   */
  @Override
  public int equivalenceHashCode()
  {
    return new HashCodeBuilder().append(getFacility()).append(toLowerAndTrim(getCode())).append(toLowerAndTrim(getTitle())).toHashCode();
  }

  /**
   * @see java.lang.Object#equals(java.lang.Object)
   *
   * Equality based on Business Rule [E-XML-PROC#P17-100]
   */
  @Override
  public boolean equivalentTo(LayawayDistributionProject other)
  {
    return new EqualsBuilder().append(getFacility(), other.getFacility()).append(toLowerAndTrim(getCode()), toLowerAndTrim(other.getCode())).append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle())).isEquals();
  }

  @Override
  public Costs getUnitCosts()
  {
    return null;
  }

  @Override
  public Costs getQuantities()
  {
    return null;
  }
}
