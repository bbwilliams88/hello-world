package mil.dtic.cbes.prcp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.service.SYSUploadServiceImpl;
import mil.dtic.cbes.service.ValidationException;
import mil.dtic.cbes.submissions.ValueObjects.SYSFile;
import mil.dtic.cbes.submissions.service.P1R1Service;
import mil.dtic.cbes.submissions.service.impl.P1R1ServiceImpl;
import mil.dtic.utility.CbesLogFactory;

public class PRCPDataFileService {
  private static final Logger log = CbesLogFactory.getLog(PRCPDataFileService.class);
  
  private SYSUploadServiceImpl budgetFileUploadService;
  public PRCPDataFileService(SYSUploadServiceImpl budgetFileUploadService) {
    this.budgetFileUploadService = budgetFileUploadService;
  }
  
  /**
   * Discovers all R-1 prcp files on the server and selects the
   * most recently uploaded.
   * 
   * @return
   * @throws FileNotFoundException
   */
  public SYSFile getPrcpR1DataFile() throws FileNotFoundException {
    return getPrcpDataFor("_R1");
  }
  
  /**
   * Discovers all P-1 prcp files on the server and selects the
   * most recently uploaded.
   * 
   * @return
   * @throws FileNotFoundException
   */
  public SYSFile getPrcpP1DataFile() throws FileNotFoundException {
    return getPrcpDataFor("_P1");
  }
  
  public SYSFile getPrcpDataFor(String filter) throws FileNotFoundException {
     List<SYSFile> allFiles = budgetFileUploadService.getAllFiles();
     SYSFile prcpFile = null;
     
     // find all excel files matching the prcp string filter
     List<SYSFile> allMatchingFiles = new ArrayList<SYSFile>();
     for (SYSFile aFile : allFiles) {
       String name = aFile.getName();
       String type = aFile.getType();
       if (!aFile.isDelete() && type != null && (type.equalsIgnoreCase("xlsx") || type.equalsIgnoreCase("xls"))) {
         if (name != null && name.contains(filter)) {
           allMatchingFiles.add(aFile);
         }
       }
     }
     log.debug("Found " + allMatchingFiles.size() + " " + filter + " files");
     if (allMatchingFiles.isEmpty()) {
       throw new FileNotFoundException("No prcp files found in system upload directory.");
     }

     // select the most recently uploaded
     Comparator<SYSFile> comparator = new Comparator<SYSFile>() {
       public int compare(SYSFile o1, SYSFile o2) {
         return o2.getDateCreated().compareTo(o1.getDateCreated());
       }
     };
     Collections.sort(allMatchingFiles, comparator);
     prcpFile = allMatchingFiles.get(0);
     log.debug("Most recent prcp " + filter + " file: " + prcpFile.getUrl() + " uploaded on " + prcpFile.getDateString());
     
     return prcpFile;
  }
  

  /**
   * Store the uploaded prcp update file in long term storage.
 * @param date 
   * 
   * @param upFile
   * @return
   */
  public boolean storeUploadedPRCPUpdateFile(File sandboxFile, String fileName, String userName, Date date) {
    boolean result = true;
    try {
      budgetFileUploadService.saveNewFile(sandboxFile, fileName, userName, "User uploaded PRCP update", date);
    } catch (ValidationException|IOException e) {
      result = false;
      log.error("Unable to store uploaded prcp update file.", e);
    } 
    return result;
  }
}
