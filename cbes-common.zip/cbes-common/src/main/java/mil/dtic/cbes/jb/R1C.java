/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;


public class R1C extends JBDefaultSystemGeneratedPart
{
  public R1C()
  {
    this(null);
  }
  
  public R1C(String titlePrefix)
  {
    setFileSetting(FileSetting.R1C);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.R1C.getTitle()));    
  }
}
