package mil.dtic.cbes.p40.vo;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ResourceSummaryEntryType;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.p40.vo.auto._ModsItemGroup;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.p40.vo.wrappers.ResourceSummaryWrapper;
import mil.dtic.cbes.submissions.ValueObjects.IsSubtotalParent;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ModsItemGroup
    extends _ModsItemGroup
    implements CompoSplitParent,
               CostElementParent,
               Equivalence<ModsItemGroup>,
               IsSubtotalParent,
               ItemExhibitType,
               PriorYearsDeltaParent,
               ResourceSummaryParent,
               RollupParent

{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(ModsItemGroup.class);

  private MultiYearProcurement jibx_MYPGroup;

  /***********************************************************************/
  /*** Cayenne Callbacks                                               ***/
  /***********************************************************************/

  /**
   * The UI expects several relationships to exist. This method creates all of
   * the expected relationships.
   */
  public void initializeChildRelationships()
  {
    if (getProcurementTotalCost() == null)
      setProcurementTotalCost(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
    if (getProcurementQuantity() == null)
      setProcurementQuantity(Costs.create(getObjectContext(), CostRowType.QUANTITY));

    if (getInstallationQuantity() == null)
      setInstallationQuantity(Costs.create(getObjectContext(), CostRowType.QUANTITY));
    if (getInstallationTotalCost() == null)
      setInstallationTotalCost(Costs.create(getObjectContext(), CostRowType.TOTALCOST));

    if (getSupportTotalCost() == null)
      setSupportTotalCost(Costs.create(getObjectContext(), CostRowType.TOTALCOST));
    if (getSupportQuantity() == null)
      setSupportQuantity(Costs.create(getObjectContext(), CostRowType.QUANTITY));
  }

  @Override
  protected void onPostAdd()
  {
    initializeChildRelationships();
    setDisplayOrder(0); // TODO lame
  }

  @Override
  protected void onPrePersist()
  {
    Util.cleanupContinuingTriplet(getResourceSummary());
  }

  @Override
  protected void onPostLoad()
  {
    initializeChildRelationships();
  }

  /***********************************************************************/
  /*** Custom Accessors                                                ***/
  /***********************************************************************/

  /**
   * @return quantities value for this component as a parent of the component
   *         split
   */
  @Override
  public Quantities getCompoSplitParentQuantities()
  {
    // TODO: Need to figure out how to populate this...
    // I don't know the correct way to populate the data here yet
    return new Quantities();
  }

  public void setResourceSummary(ResourceSummaryWrapper l)
  {
    log.trace("Collection setters not implemented " + (l == null ? null : l.size()));
  }

  @Override
public ResourceSummary getResourceSummary()
  {
    return new ResourceSummaryWrapper(this, super.getResourceSummaryRows(), RESOURCE_SUMMARY_ROWS_RELATIONSHIP_PROPERTY, true);
  }

  @Override
  public List<DevelopmentMilestone> getMilestones()
  {
    return getSortedByDisplayOrder(super.getMilestones());
  }

  @Override
  public List<ModsItem> getItems()
  {
    return getSortedByDisplayOrder(super.getItems());
  }

  @Override
  // FIXME: Rename method to getOrderedCostElements.
  public List<CostElement> getSupportCostElements()
  {
    return getSortedByDisplayOrder(super.getSupportCostElements());
  }

  @Override
  public CompoSplit addCompoSplit(String serviceComponent)
  {
    if (serviceComponent == null)
      throw new NullPointerException();

    ServiceComponent sc = fetchOne(getObjectContext(), ServiceComponent.class, ServiceComponent.TITLE_PROPERTY, serviceComponent);

    if (sc == null)
      throw new RuntimeException("ServiceComponent query returned no result");

    CompoSplit cs = getObjectContext().newObject(CompoSplit.class);

    cs.setServiceComponent(sc);
    cs.setServiceAgency(getParentLineItem().getServiceAgency());
    cs.setDisplayOrder(Util.getNextDisplayOrderValue(getComponentSplitList()));
    addToComponentSplitList(cs);

    return cs;
  }

  @Override
  public CompoSplit getCompoSplit(String serviceComponent)
  {
    for(CompoSplit cs : getComponentSplitList())
    {
      if(cs.getServiceComponent().getTitle().equals(serviceComponent))
        return cs;
    }
    return null;
  }

  @Override
  public void removeCompoSplit(CompoSplit cs)
  {
    removeFromComponentSplitList(cs);
    getObjectContext().deleteObjects(cs);
  }

  @Override
  public ResourceSummaryRow addResourceSummaryRow(ResourceSummaryEntryType entryType)
  {
    ResourceSummaryRow rsr = ResourceSummaryRow.create(getObjectContext(), entryType);
    addToResourceSummaryRows(rsr);
    return rsr;
  }

  @Override
  public void removeResourceSummaryRow(ResourceSummaryRow rsr)
  {
    removeFromResourceSummaryRows(rsr);
    getObjectContext().deleteObjects(rsr);
  }

  @Override
  public List<CostElement> getCostElements()
  {
    return getSupportCostElements();
  }

  @Override
  public CostElement addCostElement()
  {
    CostElement costElement = getObjectContext().newObject(CostElement.class);

    addToSupportCostElements(costElement);
    Util.generateDisplayOrder(super.getSupportCostElements());

    return costElement;
  }

  @Override
  public void removeCostElement(CostElement ce)
  {
    removeFromSupportCostElements(ce);
    getObjectContext().deleteObjects(ce);
  }

  public ModsItem addItem()
  {
    ModsItem item = getObjectContext().newObject(ModsItem.class);
    addToItems(item);
    return item;
  }

  public ModelAffected addModelAffected(String title)
  {
    ModelAffected model = getObjectContext().newObject(ModelAffected.class);
    model.setTitle(title);
    addToModelsAffected(model);
    return model;
  }

  public void removeItem(ModsItem item)
  {
    removeFromItems(item);
    getObjectContext().deleteObjects(item);
  }

  public DevelopmentMilestone addMilestone()
  {
    DevelopmentMilestone dm = getObjectContext().newObject(DevelopmentMilestone.class);
    addToMilestones(dm);
    return dm;
  }

  public void removeMilestone(DevelopmentMilestone milestone)
  {
    removeFromMilestones(milestone);
    getObjectContext().deleteObjects(milestone);
  }

  public String getOtherPeText()
  {
    return getPeText(OTHER_PES_RELATIONSHIP_PROPERTY);
  }

  public void setOtherPeText(String newVal)
  {
    setPeText(OtherPe.class, OTHER_PES_RELATIONSHIP_PROPERTY, getOtherPeText(), newVal);
  }

  @Override
  public String getModelsAffectedText()
  {
    String toReturn = super.getModelsAffectedText();
    if (!StringUtils.isEmpty(toReturn))
      return toReturn;
    else
      return getModel();
  }

  @Override
  public Costs getCosts()
  {
    if (getResourceSummary().getGrossWeaponSystemCost() != null)
      return getResourceSummary().getGrossWeaponSystemCost().getCosts();

    return null;
  }

  @Override
  public List<? extends CostContainer> getChildren()
  {
    List<CostContainer> children = new ArrayList<CostContainer>();

    children.addAll(getSupportCostElements());
    children.addAll(getInstallationCostsForRollup());
    children.addAll(getItems());

    if (this.getAdvanceProcurement() != null)
    {
      children.addAll(this.getAdvanceProcurement().getChildren());
    }

    return children;
  }

  public List<? extends CostContainer> getChildrenWithoutAdvanceProcurement()
  {
    List<CostContainer> children = new ArrayList<CostContainer>();

    children.addAll(getSupportCostElements());
    children.addAll(getInstallationCostsForRollup());
    children.addAll(getItems());

    return children;
  }

  private List<CostContainer> getInstallationCostsForRollup()
  {
    List<CostContainer> installationCosts = new ArrayList<CostContainer>();

    for (ModsItem item : getItems())
      for (ModsImplementationMethod method : item.getImplementationMethods())
        installationCosts.addAll(method.getInstallationCostsForRollup());

    return installationCosts;
  }

  @Override
  public Costs getQuantities()
  {
    if (getResourceSummary() != null && getResourceSummary().getQuantity() != null)
      return getResourceSummary().getQuantity().getCosts();

    return null;
  }

  @Override
  public Costs getCompoSplitCosts()
  {
    if (getResourceSummary().getTotalProcCost() != null)
      return getResourceSummary().getTotalProcCost().getCosts();

    return null;
  }

  @Override
public String getIdentifyingString()
  {
    return getTitle();
  }

  @Override
  public Costs getUnitCosts()
  {
    if (getResourceSummary() != null && getResourceSummary().getGrossWeaponSystemUnitCost() != null)
      return getResourceSummary().getGrossWeaponSystemUnitCost().getCosts();

    return null;
  }

  public P10AdvanceProcurement addAdvanceProcurement()
  {
    if(getAdvanceProcurement() != null)
      getAdvanceProcurement().delete();
    setAdvanceProcurement(getObjectContext().newObject(P10AdvanceProcurement.class));

    return getAdvanceProcurement();
  }

  /***********************************************************************/
  /*** Business Logic                                                  ***/
  /***********************************************************************/

    @Override
    public void clearOutYears()
    {
        // Clear Secondary Distributions.
        CompoSplitParent.super.clearOutYears();

        // Clear Resource Summary.
        ResourceSummaryParent.super.clearOutYears();

        // Clear Modification Items.
        for (ModsItem modificationItem : getItems())
        {
            for (OtherPe otherPE : modificationItem.getOtherPes())
            {
                Costs.clearOutYears(otherPE.getQuantities());
                Costs.clearOutYears(otherPE.getTotalCosts());
            }

            // Clear A/B-Kits (Recurring, Non-Recurring, and Total).
            CostElement.clearOutYears(modificationItem.getCostElements());

            // Clear Procurement Costs.
            Costs.clearOutYears(modificationItem.getQuantities());
            Costs.clearOutYears(modificationItem.getTotalCosts());

            // Clear Installation Costs.
            Costs.clearOutYears(modificationItem.getInstallationQuantities());
            Costs.clearOutYears(modificationItem.getInstallationCosts());

            // Clear out Non-Organic Installation Method Costs.
            for (ModsImplementationMethod modificationImplementationMethod : modificationItem.getImplementationMethods())
            {
                if (modificationImplementationMethod.isNonOrganic())
                {
                    for (InstallationCost installationCost : modificationImplementationMethod.getInstallationCosts())
                    {
                        Costs.clearOutYears(installationCost.getQuantities());
                        Costs.clearOutYears(installationCost.getTotalCosts());
                    }
                }

                if (modificationImplementationMethod.getIn() != null)
                    if (modificationImplementationMethod.getIn().getSchedule() != null)
                        modificationImplementationMethod.getIn().getSchedule().clearOutYears();

                if (modificationImplementationMethod.getOut() != null)
                    if (modificationImplementationMethod.getOut().getSchedule() != null)
                        modificationImplementationMethod.getOut().getSchedule().clearOutYears();
            }
        }

        // Clear Costs
        CostElement.clearOutYears(getCostElements());

        Costs.clearOutYears(getProcSupportUnitCost());
        Costs.clearOutYears(getProcurementAndSupportQuantity());
        Costs.clearOutYears(getInstallationQuantity());
        Costs.clearOutYears(getInstallationUnitCost());
        Costs.clearOutYears(getInstallationTotalCost());
        Costs.clearOutYears(getProcurementQuantity());
        Costs.clearOutYears(getProcurementUnitCost());
        Costs.clearOutYears(getProcurementTotalCost());
        Costs.clearOutYears(getSupportQuantity());
        Costs.clearOutYears(getSupportUnitCost());
        Costs.clearOutYears(getSupportTotalCost());
        Costs.clearOutYears(getTotalQuantity());
        Costs.clearOutYears(getTotalUnitCost());
        Costs.clearOutYears(getTotalCost());
    }

  @Override
  public void shiftForwardInTime(int years)
  {
    for (CompoSplit split : this.getComponentSplitList())
      split.shiftForwardInTime(years);

    for (ModsItem mi : this.getItems())
      mi.shiftForwardInTime(years);

    for (ResourceSummaryRow rsr : this.getResourceSummaryRows())
      rsr.shiftForwardInTime(years);

    for (CostElement ce : this.getSupportCostElements())
      ce.shiftForwardInTime(years);

    for (OtherPe op : this.getOtherPes())
      op.shiftForwardInTime(years);

    if (getProcurementTotalCost() != null)
      getProcurementTotalCost().shiftForwardInTime(years);

    if (getProcurementQuantity() != null)
      getProcurementQuantity().shiftForwardInTime(years);

    if (getSupportTotalCost() != null)
      getSupportTotalCost().shiftForwardInTime(years);

    if (getSupportQuantity() != null)
      getSupportQuantity().shiftForwardInTime(years);

    if (getInstallationTotalCost() != null)
      getInstallationTotalCost().shiftForwardInTime(years);

    if (getInstallationQuantity() != null)
      getInstallationQuantity().shiftForwardInTime(years);

    if (this.getAdvanceProcurement() != null)
        this.getAdvanceProcurement().shiftForwardInTime(years);
  }

  public void cleanUpTotalSupportCost()
  {
    if (getSupportCostElements() == null || getSupportCostElements().isEmpty())
    {
      if(getSupportTotalCost() != null)
        getSupportTotalCost().clearValues();
      if(getSupportQuantity() != null)
        getSupportQuantity().clearValues();
    }
  }

  public void cleanUpContinuingFootnotes()
  {
    if(getSupportTotalCost() != null && !getSupportTotalCost().isContinuing())
    {
      getSupportTotalCost().setContinuingFootnote(null);
    }
    if(getProcurementTotalCost() != null && !getProcurementTotalCost().isContinuing())
    {
      getProcurementTotalCost().setContinuingFootnote(null);
    }
    if(getInstallationTotalCost() != null && !getInstallationTotalCost().isContinuing())
    {
      getInstallationTotalCost().setContinuingFootnote(null);
    }
  }

  public void cleanUpSubtotalQuantitiesWhenContinuing()
  {
    if(getSupportTotalCost() != null && getSupportQuantity() != null && getSupportTotalCost().isContinuing())
    {
      getSupportQuantity().setToComplete(null);
      getSupportQuantity().setTotal(null);
      getSupportQuantity().setToCompleteFootnote(null);
      getSupportQuantity().setTotalCostFootnote(null);
    }

    if(getProcurementTotalCost() != null && getProcurementQuantity() != null && getProcurementTotalCost().isContinuing())
    {
      getProcurementQuantity().setToComplete(null);
      getProcurementQuantity().setTotal(null);
      getProcurementQuantity().setToCompleteFootnote(null);
      getProcurementQuantity().setTotalCostFootnote(null);
    }

    if(getInstallationTotalCost() != null && getInstallationQuantity() != null && getInstallationTotalCost().isContinuing())
    {
      getInstallationQuantity().setToComplete(null);
      getInstallationQuantity().setTotal(null);
      getInstallationQuantity().setToCompleteFootnote(null);
      getInstallationQuantity().setTotalCostFootnote(null);
    }
  }
  /**
   * Sets the InstallationTotalCost, ProcurementTotalCosts, and
   * ProcurementAndSupportTotalCosts using the Mod Items in the Mod Group.
   * Calculates all the subtotals for the Mod Items in the Mod Group
   * @throws ReflectiveOperationException
   * @throws InvocationTargetException
   * @throws IllegalAccessException
   */
  @Override
public void calculateSubtotals() throws MethodDispatchException
  {
    Costs installationTotalCost = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
    Costs procurementTotalCost = Costs.create(getObjectContext(), CostRowType.TOTALCOST);
    Costs supportTotalCost = Costs.create(getObjectContext(), CostRowType.TOTALCOST);

    for (ModsItem item : getItems())
    {
      item.calculateSubtotals();
      addToSubtotalInDollars(installationTotalCost, item.getInstallationCosts());
    }

    addToSubtotalInDollars(procurementTotalCost, getItems());

    for (CostElement costElement : getSupportCostElements())
    {
      costElement.calculateSubtotals();
    }
    addToSubtotalInDollars(supportTotalCost, getSupportCostElements());

    replaceCosts(setSubtotalValuesInMillion(installationTotalCost), INSTALLATION_TOTAL_COST_RELATIONSHIP_PROPERTY);
    replaceCosts(setSubtotalValuesInMillion(procurementTotalCost), PROCUREMENT_TOTAL_COST_RELATIONSHIP_PROPERTY);
    replaceCosts(setSubtotalValuesInMillion(supportTotalCost), SUPPORT_TOTAL_COST_RELATIONSHIP_PROPERTY);
  }

  /***********************************************************************/
  /*** Utilities                                                       ***/
  /***********************************************************************/

  // Put utility-type methods here, which are typically static, such as
  // fetch* type methods, which fetch Cayenne objects from the database.

  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  public boolean jibx_hasAlternateFinancialPlan() {
    return getAlternateFinancialPlan() != null;
  }

  public MultiYearProcurement jibx_getMypGroup()
  {
    return jibx_MYPGroup;
  }

  public void jibx_setMypGroup(MultiYearProcurement jibx_MYPGroup)
  {
    this.jibx_MYPGroup = jibx_MYPGroup;
  }

  @Override
public boolean jibx_hasPysDelta()
  {
    // Check if there is a Prior Years Delta for this Line Item.
    if (getPysDelta() != null || getPysQuantityDelta() != null)
      return true;

    return false;
  }

  @Override
  public boolean jibx_hasPysQuantityDelta()
  {
    if(getPysQuantityDelta() != null)
      return true;
    else
      return false;
  }

  @Override
  public boolean jibx_hasPysCostDelta()
  {
    if(getPysDelta() != null)
      return true;
    else
      return false;
  }

  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getComponentSplitList());
    Util.generateDisplayOrder(super.getOtherPes());
    Util.generateDisplayOrder(super.getMilestones());
    Util.generateDisplayOrder(super.getSupportCostElements());
    Util.generateDisplayOrder(super.getItems());
  }

  @Override
public boolean jibx_hasComponentSplit()
  {
    return CollectionUtils.isNotEmpty(getComponentSplitList());
  }

  @Override
public Iterator<CompoSplit> jibx_componentSplitIterator()
  {
    return getIterator(getComponentSplitList());
  }

  /** This jibx method is meant to test if the older node, <proc:Model>, is being used to supply a single Model Affected rather than using the new list node structure with
        with the <proc:ModelsAffectedList> node. This is for backwards compatibility to not require everyone to change their XML files if they don't wish to provide several Models Affected. **/
  public boolean jibx_hasSingleModelAffected()
  {
    return getModelsAffected().isEmpty();
  }

  public boolean jibx_hasModelsAffected()
  {
    return !getModelsAffected().isEmpty();
  }

  public Iterator<ModelAffected> jibx_ModelsAffectedIterator()
  {
    return getModelsAffected().iterator();
  }

  public boolean jibx_hasOtherPes()
  {
    return CollectionUtils.isNotEmpty(getOtherPes());
  }

  public Iterator<OtherPe> jibx_OtherPeIterator()
  {
    return getOtherPes().iterator();
  }

  public boolean jibx_hasMilestones()
  {
    return CollectionUtils.isNotEmpty(getMilestones());
  }

  public Iterator<DevelopmentMilestone> jibx_MilestoneIterator()
  {
    return getMilestones().iterator();
  }

  public boolean jibx_hasSupportCostElements()
  {
    return CollectionUtils.isNotEmpty(getSupportCostElements());
  }

  public Iterator<CostElement> jibx_SupportCostElementIterator()
  {
    return getSupportCostElements().iterator();
  }

  public boolean jibx_hasItems()
  {
    return CollectionUtils.isNotEmpty(getItems());
  }

  public boolean jibx_hasResourceSummary()
  {
    ResourceSummary theRS = getResourceSummary();

    if (theRS.hasQuantity()      == false &&
      theRS.hasGross()         == false &&
      theRS.hasGrossUnit()     == false &&
      theRS.hasPy()            == false &&
      theRS.hasNet()           == false &&
      theRS.hasCy()            == false &&
      theRS.hasTotal()         == false &&
      theRS.hasInitialSpares() == false &&
      theRS.hasFlyaway()       == false)
      return false;

    return true;
  }

  public Iterator<ModsItem> jibx_ItemIterator()
  {
    return getItems().iterator();
  }

  public boolean jibx_hasMDAPCode()
  {
    return getMdapCode() != null;
  }

  public boolean jibx_hasIdCode()
  {
    return getIdCode() != null;
  }

  public boolean jibx_hasSupportSubtotals()
  {
    return (jibx_hasSupportTotalCost() || jibx_hasSupportQuantity());
  }

  public boolean jibx_hasSupportTotalCost()
  {
    return getSupportTotalCost() != null && !getSupportTotalCost().isEmpty();
  }

  public boolean jibx_hasSupportUnitCost()
  {
    return getSupportUnitCost() != null && !getSupportUnitCost().isEmpty();
  }

  public boolean jibx_hasSupportQuantity()
  {
    return getSupportQuantity() != null && !getSupportQuantity().isEmpty();
  }

  public boolean jibx_hasProcurementSubtotal()
  {
    return (jibx_hasProcurementSubtotalQuantity() || jibx_hasProcurementSubtotalTotalCost());
  }

  public boolean jibx_hasProcurementSubtotalQuantity()
  {
    return getProcurementQuantity() != null && !getProcurementQuantity().isEmpty();
  }

  public boolean jibx_hasProcurementSubtotalTotalCost()
  {
    return getProcurementTotalCost() != null && !getProcurementTotalCost().isEmpty();
  }

  public boolean jibx_hasInstallationSubtotal()
  {
    return jibx_hasInstallationSubtotalQuantity() || jibx_hasInstallationSubtotalTotalCost();
  }

  public boolean jibx_hasInstallationSubtotalQuantity()
  {
    return getInstallationQuantity() != null && !getInstallationQuantity().isEmpty();
  }

  public boolean jibx_hasInstallationSubtotalTotalCost()
  {
    return getInstallationTotalCost() != null && !getInstallationTotalCost().isEmpty();
  }

  @Override
  public int equivalenceHashCode()
  {
    if (this.getPersistenceState() == PersistenceState.DELETED)
      return super.hashCode();
    HashCodeBuilder builder = new HashCodeBuilder();
    builder.append(toLowerAndTrim(getTitle()));
    builder.append(toLowerAndTrim(getNumber()));
    builder.append(getParentLineItem());
    return builder.toHashCode();
  }

  @Override
  public boolean equivalentTo(ModsItemGroup obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ModsItemGroup other = obj;
    EqualsBuilder builder = new EqualsBuilder();
    if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
      return super.equals(obj);
    builder.append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle()));
    builder.append(toLowerAndTrim(getNumber()), toLowerAndTrim(other.getNumber()));
    builder.append(getParentLineItem(), other.getParentLineItem());
    return builder.isEquals();
  }

}