/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.ObjectContext;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.jibx.runtime.BindingDirectory;
import org.jibx.runtime.IBindingFactory;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;

import mil.P40CayenneJibxFactory;
import mil.dtic.cbes.jb.JBBase;
import mil.dtic.cbes.jb.JBCover;
import mil.dtic.cbes.jb.JBDefaultUserSuppliedPart;
import mil.dtic.cbes.jb.JBPart;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.service.UnzipService;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.R4Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.ImageUtil;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.XmlUtil;

public class XmlToJava
{
  private static final Logger log = CbesLogFactory.getLog(XmlToJava.class);

  private BudgesUser budgesUserForAuditFields;
  private final P40User p40UserForAuditFields;
  private List<String> errorList;
  private Map<String, List<String>> errorListMap;
  private UnzipService.UnzipMap fileNameResolutionMap;
  private XmlToJavaResult xtjResult;
  private ObjectContext objectContext;

  public XmlToJava()
  {
    this(null, null, null);
  }

  public XmlToJava(BudgesUser budgesUser)
  {
    this(budgesUser, null, null);
  }

  public XmlToJava(P40User p40User)
  {
    this(null, p40User, null);
  }

  public XmlToJava(BudgesUser budgesUserForAuditFields, UnzipService.UnzipMap fileNameResolutionMap)
  {
    this(budgesUserForAuditFields, null, null);
    this.fileNameResolutionMap = fileNameResolutionMap;
  }

  public XmlToJava(BudgesUser budgesUserForAuditFields, P40User p40UserForAuditFields, Object dummy)
  {
    this.p40UserForAuditFields = p40UserForAuditFields;
    this.budgesUserForAuditFields = budgesUserForAuditFields;
    errorList = new ArrayList<String>();
    errorListMap = new HashMap<String, List<String>>();
    xtjResult = new XmlToJavaResult();
  }


  public <T> T toJava(InputStream is, Class<T> t){
    log.debug("Unmarshalling (XML to Java) from InputStream");
    
    Object o = null;
    
    try {
      IBindingFactory bfact = BindingDirectory.getFactory(t);
      IUnmarshallingContext uctx = bfact.createUnmarshallingContext();
      o = uctx.unmarshalDocument(is, null);
    }
    catch (JiBXException e){
      log.error("Failed to unmarshall XML to Java from InputStream", e);
      errorList.add("System error while parsing XML file");
      return null;
    }
    finally {
      FileUtil.close(is);
    }

    log.debug("XML was unmarshalled to type " + t.getCanonicalName());

    XmlToJavaPostProcessor xtjpp = new XmlToJavaPostProcessor(budgesUserForAuditFields, p40UserForAuditFields);
    log.trace("XmlToJava:toJava - succesfully unmarshalled xml to java - starting postProcessing");

    if (t == MasterJustificationBook.class){
      log.trace("XmlToJava:toJava - building MasterJustificationBook");
      MasterJustificationBook mjb = (MasterJustificationBook) o;
      
      String mjbWorkFlowStatus = mjb.getDocAssemblyOptions().getWorkFlowStatus();
      
      if (StringUtils.isNotEmpty(mjbWorkFlowStatus)
          && XmlUtil.isJbWorkflowStatusDisabled(mjbWorkFlowStatus)) {
        errorList.add(
            String.format("Workflow status: %s, is currently not enabled.", mjbWorkFlowStatus));
      }
      log.trace("XmlToJava:toJava - processing mjb with XmlToJavaPostProcessor");
      xtjpp.process(mjb);
      log.trace("XmlToJava:toJava - calling resolveFileNames");
      resolveFileNames(mjb);
      log.trace("XmlToJava:toJava - setting Mjb");
      xtjResult.setMjb(mjb);
      log.trace("XmlToJava:toJava - finished setMjb()");
    }
    else if (t == JustificationBook.class){
        log.trace("XmlToJava:toJava - building JustificationBook");
      JustificationBook jb = (JustificationBook) o;

      String jbWorkFlowStatus = jb.getDocAssemblyOptions().getWorkFlowStatus();

      if (StringUtils.isNotEmpty(jbWorkFlowStatus)
          && XmlUtil.isJbWorkflowStatusDisabled(jbWorkFlowStatus)) {
        errorList
            .add(String.format("Workflow status: %s, is currently not enabled.", jbWorkFlowStatus));
      }
      xtjpp.process(jb);
      resolveFileNames(jb);
      xtjResult.setJb(jb);
      xtjResult.setR2ExhibitList(jb.getR2ExhibitList());
      xtjResult.setLineItemList(jb.getLineItemList());
    }
    else if (t == R2ExhibitList.class){
        log.trace("XmlToJava:toJava - building R2ExhibitList");
      R2ExhibitList r2ExhibitList = (R2ExhibitList) o;
      xtjpp.process(r2ExhibitList);
      resolveFileNames(r2ExhibitList);
      xtjResult.setR2ExhibitList(r2ExhibitList);
    }
    else if (t == LineItemList.class){
        log.trace("XmlToJava:toJava - building LineItemList");
      LineItemList lil = (LineItemList) o;
      xtjpp.process(lil);
      //resolveFileNames(lil);
      xtjResult.setLineItemList(lil);
    }

    errorList.addAll(xtjpp.getErrorList());
    for (String item : xtjpp.getErrorListMap().keySet()) {
      if (errorListMap.containsKey(item)){
        errorListMap.get(item).addAll(xtjpp.getErrorListMap().get(item));
      }
      else {
        errorListMap.put(item, xtjpp.getErrorListMap().get(item));
      }
    }

    if (t.isInstance(o)){
        log.trace("XmlToJava:toJava - succesfully returning processed object");
      return (T) o;
    }

    log.error("isInstance failed");
    errorList.add("System error while parsing XML file");

    return null;
  }


  /*private <T> T toJava(File file, Class<T> t)
  {
    log.debug("Unmarshalling (XML to Java) from file: " + file.getAbsolutePath());
    T result = null;
    try
    {
      result = toJava(new BufferedInputStream(new FileInputStream(file)), t);
    }
    catch (FileNotFoundException e)
    {
      log.error("Failed to unmarshall XML to Java from file: " + file.getAbsolutePath(), e);
    }
    return result;
  }


  private <T> List<T> toJava(List<BudgesFile> budgesFileList, Class<T> t)
  {
    log.debug("Unmarshalling (XML to Java) from budges file list");
    List<T> tList = null;
    if (budgesFileList != null)
    {
      tList = new ArrayList<T>();

      for (BudgesFile budgesFile : budgesFileList)
      {
        T obj = toJava(budgesFile.getFile(), t);
        if (obj == null)
        {
          errorList.add("The provided XML files are not all the same type.");
          break;
        }

      }
    }
    return tList;
  }*/


  public XmlToJavaResult xmlToMasterJustificationBook(File file) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(new FileInputStream(file)), MasterJustificationBook.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToMasterJustificationBook(BudgesFile budgesFile) throws FileNotFoundException
  {
    xmlToMasterJustificationBook(budgesFile.getFile());
    return xtjResult;
  }

  public XmlToJavaResult xmlToMasterJustificationBook(InputStream is) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(is), MasterJustificationBook.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToJustificationBook(File file) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(new FileInputStream(file)), JustificationBook.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToJustificationBook(BudgesFile budgesFile) throws FileNotFoundException
  {
    xmlToJustificationBook(budgesFile.getFile());
    return xtjResult;
  }

  public XmlToJavaResult xmlToJustificationBook(InputStream is) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(is), JustificationBook.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToR2ExhibitList(byte[] data)
  {
    toJava(new ByteArrayInputStream(data), R2ExhibitList.class);
    return xtjResult;
  }


  public XmlToJavaResult xmlToR2ExhibitList(File file) throws FileNotFoundException
  {
    toJava(new BufferedInputStream(new FileInputStream(file)), R2ExhibitList.class);
    return xtjResult;

  }


  public XmlToJavaResult xmlToR2ExhibitList(BudgesFile budgesFile) throws FileNotFoundException
  {
    xmlToR2ExhibitList(budgesFile.getFile());
    return xtjResult;
  }


  public XmlToJavaResult xmlToR2ExhibitList(List<BudgesFile> budgesFileList) throws FileNotFoundException
  {
    R2ExhibitList mainR2ExhibitList = null;
    if (budgesFileList != null)
    {
      for (BudgesFile budgesFile : budgesFileList)
      {
        xmlToR2ExhibitList(budgesFile);
        if (xtjResult.getR2ExhibitList() == null)
        {
          errorList.add("At least one of the provided files is not an R2 XML file.");
          break;
        }
        else
        {
          if (mainR2ExhibitList == null)
            mainR2ExhibitList = xtjResult.getR2ExhibitList();
          else
            mainR2ExhibitList.getR2Exhibits().addAll(xtjResult.getR2ExhibitList().getR2Exhibits());
        }
      }
    }
    xtjResult.setR2ExhibitList(mainR2ExhibitList);
    return xtjResult;
  }


  public XmlToJavaResult xmlToLineItemList(File file) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(new FileInputStream(file)), LineItemList.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToLineItemList(byte[] xml) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(new ByteArrayInputStream(xml)), LineItemList.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }


  public XmlToJavaResult xmlToLineItemList(BudgesFile budgesFile) throws FileNotFoundException
  {
    xmlToLineItemList(budgesFile.getFile());
    return xtjResult;
  }


  public XmlToJavaResult xmlToLineItemList(List<BudgesFile> budgesFileList) throws FileNotFoundException
  {
    LineItemList lil = null;
    if (budgesFileList != null)
    {
      for (BudgesFile budgesFile : budgesFileList)
      {
        xmlToLineItemList(budgesFile);
        if (xtjResult.getLineItemList() == null)
        {
          errorList.add("At least one of the provided files is not an P40 XML file.");
          break;
        }
        else
        {
          if (lil == null)
            lil = xtjResult.getLineItemList();
          else
            lil.getLineItems().addAll(xtjResult.getLineItemList().getLineItems());
        }
      }
    }
    xtjResult.setLineItemList(lil);
    return xtjResult;
  }

  public XmlToJavaResult xmlToLineItemList(InputStream is) throws FileNotFoundException
  {
    P40CayenneJibxFactory.setObjectContext(getObjectContext());
    toJava(new BufferedInputStream(is), LineItemList.class);
    P40CayenneJibxFactory.setObjectContext(null);
    return xtjResult;
  }

  protected void resolveFileNames(MasterJustificationBook mjb)
  {
    log.debug("Resolving Master JB file names in xml for " + mjb.getTitle());
    if (mjb.getJbgList() != null)
    {
      for (JustificationBookGroup jbg : mjb.getJbgList())
      {
        resolveFileNames((JBBase) mjb);
        for (JustificationBookInfo jbi : jbg.getJbiList())
          resolveFileNames(jbi.getJb());
      }
    }
  }


  protected void resolveFileNames(JBBase jb)
  {
    log.debug("Resolving JB file names in xml for " + jb.getTitle() + " (" + jb.getClass().getName() + ")");
    resolveJbPartFileName(jb.getCoverDoc());
    resolveJbPartFileName(jb.getCostDoc());
    resolveJbPartFileName(jb.getIntroductionDoc());
    resolveJbPartFileName(jb.getSummaryDoc());
    resolveJbPartFileName(jb.getAcronymDoc());
    resolveJbPartFileName(jb.getUserR1Doc());
    resolveJbPartFileName(jb.getUserP1Doc());
    if (jb.getSupplementalDocCollection() != null)
      resolveJbPartFileName(jb.getSupplementalDocCollection().getSupplementalDocList());
    resolveFileNames(jb.getR2ExhibitList());
  }



  protected void resolveJbPartFileName(JBCover coverDoc) {
    log.trace("XmlToJava:resolveJbPartFileName  - JBCover - " + coverDoc);  
    if (coverDoc != null && coverDoc.getLogoFileName() != null)  {
      log.debug("Resolving cover page " + coverDoc.getTitle());

      BudgesFile bf = null;
      if (fileNameResolutionMap != null)
        bf = fileNameResolutionMap.get(coverDoc.getLogoFileName().toLowerCase());
      if (bf == null)
      {
        errorList.add("The referenced image file '" + coverDoc.getLogoFileName() + "' cannot be found.");
        log.debug("Could not resolve reference to " + coverDoc.getLogoFileName() + " for " + coverDoc.getTitle() + " in xml file.");
      }
      else
      {
        log.debug("Successfully resolved reference to " + coverDoc.getLogoFileName() + " for " + coverDoc.getTitle() + " in xml file.");
        coverDoc.setLogoAbsoluteFileName(bf.getFile().getAbsolutePath());

        log.debug("Validating image " + coverDoc.getLogoFileName() + " for " + coverDoc.getTitle() + " in xml file.");
        if (!ImageUtil.validateImageFile(bf.getFile()))
        {
          errorList.add("The logo image file is invalid; make sure it has the correct extension and content: " + coverDoc.getLogoFileName());
          log.debug("Image file " + coverDoc.getLogoFileName() + " for " + coverDoc.getTitle() + " in xml file is not valid.");
        }
      }
    }
  }


  protected void resolveJbPartFileName(JBPart jbPart){
      log.trace("XmlToJava:resolveJbPartFileName  - JBPart - " + jbPart);
    if (jbPart != null) {
      log.debug("Resolving JbPart '" + jbPart.getTitle() + "' in xml file.");

      if (jbPart.isFixedTitle())
      {
        jbPart.setTitle(jbPart.getFileSetting().getTitle());
        log.debug("Retoring JbPart title to '" + jbPart.getTitle() + "' (since it cannot be changed by user).");
      }

      BudgesFile bf = null;
      if (fileNameResolutionMap != null)
        bf = fileNameResolutionMap.get(jbPart.getFileName().toLowerCase());
      if (bf == null)
      {
        errorList.add("The referenced file '" + jbPart.getFileName() + "' cannot be found");
        log.debug("Could not resolve reference to " + jbPart.getFileName() + " for " + jbPart.getTitle() + " in xml file.");
      }
      else
      {
        log.debug("Successfully resolved reference to " + jbPart.getFileName() + " for " + jbPart.getTitle() + " in xml file.");
        jbPart.setAbsoluteFileName(bf.getFile().getAbsolutePath());
        try
        {
          log.debug("Getting page count for " + jbPart.getFileName() + " for " + jbPart.getTitle() + " in xml file.");
          jbPart.setPdfTotalPageCount(PdfUtil.getNumberOfPagesInPdf(bf.getFile()));
          log.debug("Page count for " + jbPart.getFileName() + " for " + jbPart.getTitle() + " in xml file is " + jbPart.getPdfTotalPageCount());
        }
        catch (IOException e)
        {
          errorList.add("There is an error with the file: " + jbPart.getFileName() + ". It is either corrupt or not a valid file.");
        }

      }
    }
  }


  protected void resolveJbPartFileName(List<? extends JBDefaultUserSuppliedPart> jbPartList) {
    log.trace("XmlToJava:resolveJbPartFileName - List - " + jbPartList);
    //log.debug("Resolving JBPart list in xml file.");
    if (jbPartList != null) {
      for (JBDefaultUserSuppliedPart jbPart : jbPartList)
        resolveJbPartFileName(jbPart);
    }
  }


  protected void resolveFileNames(R2ExhibitList r2ExhibitList) {
      log.trace("XmlToJava:resolveFileNames - R2ExhibitList - " + r2ExhibitList);
    String title = r2ExhibitList == null ? "null" : r2ExhibitList.getTitle();
    log.debug("Resolving R2ExhibitList file name references for " + title + " in xml file.");
      if (r2ExhibitList != null && CollectionUtils.isNotEmpty(r2ExhibitList.getR2Exhibits())) {
        List<KeyValuePair> r4KvpList = xtjResult.getR4KvpList();
        if (r4KvpList == null) {
          r4KvpList = new ArrayList<KeyValuePair>();
          xtjResult.setR4KvpList(r4KvpList);
        }
        for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits())
        {
          ProgramElement pe = r2Exhibit.getProgramElement();
          if (pe != null && CollectionUtils.isNotEmpty(pe.getProjects()))
          {
            log.debug("resolving file name references for PE " + pe.getNumber());
            for (Project project : pe.getProjects())
            {
              R4Exhibit r4Exhibit = project.getR4Exhibit();
              if (r4Exhibit != null && CollectionUtils.isNotEmpty(r4Exhibit.getScheduleProfiles()))
              {
                log.debug("Resolving " + r4Exhibit.getTitle() + " in xml file.");
                int index = 1;
                for (ScheduleProfile sp : r4Exhibit.getScheduleProfiles())
                {
                  if (fileNameResolutionMap != null && CollectionUtils.isNotEmpty(fileNameResolutionMap.keySet()))  {
                    BudgesFile bf = fileNameResolutionMap.get(sp.getImageFileName().toLowerCase());
                    
                    if (bf == null)
                    {
                      errorList.add("The file '" + sp.getImageFileName() + "' specified in the R4Exhibit cannot be found in the xml file.");
                      log.debug("Could not resolve reference to " + r4Exhibit.getTitle() + " for " + sp.getImageFileName() + " in xml file.");
                    }
                    else
                    {
                      log.debug("Successfully resolved reference to " + r4Exhibit.getTitle() + " for " + sp.getImageFileName() + " in xml file.");
                      sp.setTmpImagePath(bf.getFile().getAbsolutePath());

                      String key = Util.underscoreConcat(pe.getBusinessId(), project.getBusinessId(), index++, "R4");
                      try
                      {
                        r4KvpList.add(new KeyValuePair(key, bf.getFile().toURI().toURL().toString()));
                      }
                      catch (MalformedURLException e)
                      {
                        log.error("Could not create kvp for R4Exhibit file: " + bf);
                      }
                    }
                  }
                  else{
                    errorList.add(String.format("Image file: %s declared in the XML not found!", sp.getImageFileName()));
                  }
                }
              }
            }
          }
        }
      }
  }

  protected void resolveFileNames(LineItemList lil) {
      log.trace("XmlToJava:resolveFileNames - LineItemList - " + lil);
    //nothing here atm
    String title = lil == null ? "null" : lil.getTitle();
    log.debug("Resolving LineItemList file name references for " + title + " in xml file.");
  }


  public BudgesUser getBudgesUser()
  {
    return budgesUserForAuditFields;
  }


  public void setBudgesUser(BudgesUser budgesUser)
  {
    this.budgesUserForAuditFields = budgesUser;
  }


  public boolean hasErrors()
  {
    return(errorList != null && errorList.size() > 0);
  }


  public List<String> getErrorList()
  {
    return errorList;
  }


  public void setErrorList(List<String> errorList)
  {
    this.errorList = errorList;
  }


  public XmlToJavaResult getXtjResult()
  {
    return xtjResult;
  }


  public void setXtjResult(XmlToJavaResult xtjResult)
  {
    this.xtjResult = xtjResult;
  }

  public Map<String, List<String>> getErrorListMap()
  {
    return errorListMap;
  }

  public void setErrorListMap(Map<String, List<String>> errorListMap)
  {
    this.errorListMap = errorListMap;
  }

  public ObjectContext getObjectContext()
  {
    if (objectContext == null)
      objectContext = CayenneUtils.createDataContext();

    return objectContext;
  }
}
