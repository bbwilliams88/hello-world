package mil.dtic.cbes.p40.vo;

import java.util.HashMap;
import java.util.Map;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.p40.vo.auto._ValidationClass;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;

/**
 *
 */
public class ValidationClass extends _ValidationClass implements Equivalence<ValidationClass>
{
    private static final long serialVersionUID = 1L;

    private Map<String, ValidationRule> validationRuleMap;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return
     */
    public Map<String, ValidationRule> getValidationRuleMap()
    {
        if (validationRuleMap != null)
            return validationRuleMap;

        validationRuleMap = new HashMap<String, ValidationRule>();

        for (ValidationRule rule : getValidationRules())
            validationRuleMap.put(rule.getKey(), rule);

        return validationRuleMap;
    }

    @Override
    public int equivalenceHashCode()
    {
      if (this.getPersistenceState() == PersistenceState.DELETED)
        return super.hashCode();

      HashCodeBuilder builder = new HashCodeBuilder();

      builder.append(toLowerAndTrim(getName()));
      builder.append(toLowerAndTrim(getAlternateKey()));
      builder.append(toLowerAndTrim(getLocationMessage()));

      return builder.toHashCode();
    }

    @Override
    public boolean equivalentTo(ValidationClass obj)
    {
      if (this == obj)
        return true;
      else if (obj == null)
          return false;
      else if (getClass() != obj.getClass())
          return false;

      ValidationClass other = obj;

      if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
          return super.equals(obj);

      EqualsBuilder builder = new EqualsBuilder();

      builder.append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName()));
      builder.append(getAlternateKey(), other.getAlternateKey());
      builder.append(getLocationMessage(), other.getLocationMessage());

      return builder.isEquals();
    }
}
