package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum IdCodeType implements ExtendedEnumeration
{
  A("A"), B("B");

  
  private final String dbName;

  private IdCodeType(String dbName)
  {
    this.dbName = dbName;
  }

  public String getXmlName()
  {
    return toString();
  }
  
  public String getDatabaseValue()
  {
    return dbName;
  }
}
