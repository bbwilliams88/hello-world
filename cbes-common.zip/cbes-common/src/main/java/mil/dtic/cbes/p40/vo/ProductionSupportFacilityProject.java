package mil.dtic.cbes.p40.vo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProject;
import mil.dtic.cbes.p40.vo.wrappers.CayenneListWrapper;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ProductionSupportFacilityProject extends _ProductionSupportFacilityProject implements FacilityProjectWithTitle, RollupParent, Equivalence<ProductionSupportFacilityProject>
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(ProductionSupportFacilityProject.class);

  private ProductionSupportFacilityProjectCostElement constructionCostElement;
  private ProductionSupportFacilityProjectCostElement equipmentCostElement;
  private ProductionSupportFacilityProjectCostElement equipmentInstallationCostElement;
  private ProductionSupportFacilityProjectCostElement contractorSupportCostElement;
  private ProductionSupportFacilityProjectCostElement corpsOfEngineersSupportCostElement;
  private ProductionSupportFacilityProjectCostElement otherInHouseSupportCostElement;
  private ProductionSupportFacilityProjectCostElement totalFacilityProjectCostElement;
  private ProductionSupportFacilityProjectCostElement otherCostElement;

  private Date conceptDesignComplete;
  private Date finalDesignComplete;
  private Date initialProjectAward;
  private Date finalProjectAward;
  private Date constructionComplete;
  private Date equipmentInstallationComplete;
  private Date proveOutBegins;
  private Date proveOutComplete;


  @Override
  protected void onPostAdd()
  {
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
    setDisplayOrder(0);
  }

  @Override
  protected void onPrePersist()
  {
  }

  @Override
public void onPostLoad()
  {
    for (ProductionSupportFacilityProjectCostElement costElement : this.getCostElementList())
    {
      if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Construction Cost"))
      {
        this.constructionCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Equipment Cost"))
      {
        this.equipmentCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Equipment Installation Cost"))
      {
        this.equipmentInstallationCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Contractor Support Cost"))
      {
        this.contractorSupportCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Corps of Engineers Support Cost"))
      {
        this.corpsOfEngineersSupportCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Other In-House Support Cost"))
      {
        this.otherInHouseSupportCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Total Facility Project Cost"))
      {
        this.totalFacilityProjectCostElement = costElement;
      }
      else if (StringUtils.equals(costElement.getCostElementEntry().getTitle(), "Other Costs"))
      {
        this.otherCostElement = costElement;
      }
    }

    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Concept Design Complete"))
      {
        this.conceptDesignComplete = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Final Design Complete"))
      {
        this.finalDesignComplete = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle() ,"Initial Project Award"))
      {
        this.initialProjectAward = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Final Project Award"))
      {
        this.finalProjectAward = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Construction Complete"))
      {
        this.constructionComplete = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Equipment Installation Complete"))
      {
        this.equipmentInstallationComplete = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Prove Out Begins"))
      {
        this.proveOutBegins = milestone.getMonthYear();
      }
      else if (StringUtils.equals(milestone.getMilestoneEntry().getTitle(), "Prove Out Complete"))
      {
        this.proveOutComplete = milestone.getMonthYear();
      }
    }
  }


  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getRelatedProjectList());
  }


  @Override
  public List<ProductionSupportFacilityProjectRelatedProject> getRelatedProjectList()
  {
    return getSortedByDisplayOrder(super.getRelatedProjectList());
  }


  public ProductionSupportFacilityProjectCostElement getConstructionCostElement()
  {
    return constructionCostElement;
  }


  public ProductionSupportFacilityProjectCostElement getEquipmentCostElement()
  {
    return equipmentCostElement;
  }


  private void setCostElement(ProductionSupportFacilityProjectCostElement costElement, String costElementType)
  {
    if (costElement != null)
    {
      SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectCostElementEntry.class, Expression.fromString("title = '" + costElementType + "'"));
      ProductionSupportFacilityProjectCostElementEntry costElementEntry = (ProductionSupportFacilityProjectCostElementEntry) this.objectContext.performQuery(query).get(0);
      if (this.getCostElementList() != null)
      {
        for (ProductionSupportFacilityProjectCostElement currentCostElement : this.getCostElementList())
        {
          if (currentCostElement.getCostElementEntry().equals(costElementEntry))
          {
            this.getCostElementList().remove(currentCostElement);
            break;
          }
        }
      }
      costElement.setCostElementEntry(costElementEntry);
      this.addToCostElementList(costElement);
    }
  }


  public void setEquipmentCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Equipment Cost");
    this.equipmentCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getEquipmentInstallationCostElement()
  {
    return equipmentInstallationCostElement;
  }


  public void setEquipmentInstallationCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Equipment Installation Cost");
    this.equipmentInstallationCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getContractorSupportCostElement()
  {
    return contractorSupportCostElement;
  }


  public void setContractorSupportCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Contractor Support Cost");
    this.contractorSupportCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getCorpsOfEngineersSupportCostElement()
  {
    return corpsOfEngineersSupportCostElement;
  }


  public void setCorpsOfEngineersSupportCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Corps of Engineers Support Cost");
    this.corpsOfEngineersSupportCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getOtherInHouseSupportCostElement()
  {
    return otherInHouseSupportCostElement;
  }


  public void setOtherInHouseSupportCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Other In-House Support Cost");
    this.otherInHouseSupportCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getOtherCostElement()
  {
    return otherCostElement;
  }


  public void setOtherCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Other Costs");
    this.otherCostElement = costElement;
  }


  public void setConstructionCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Construction Cost");
    this.constructionCostElement = costElement;
  }


  public ProductionSupportFacilityProjectCostElement getTotalFacilityProjectCostElement()
  {
    return totalFacilityProjectCostElement;
  }


  public void setTotalFacilityProjectCostElement(ProductionSupportFacilityProjectCostElement costElement)
  {
    setCostElement(costElement, "Total Facility Project Cost");
    this.totalFacilityProjectCostElement = costElement;
  }


  public void setRelatedProjectList(List<ProductionSupportFacilityProjectRelatedProject> l)
  {
    log.trace("Collection setters not implemented " + (l == null ? null : l.size()));
  }


  public Date getConceptDesignComplete()
  {
    return conceptDesignComplete;
  }


  public void setConceptDesignComplete(Date conceptDesignComplete)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Concept Design Complete'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(conceptDesignComplete);
    this.getMilestoneList().add(newMilestone);
    this.conceptDesignComplete = conceptDesignComplete;
  }


  public Date getFinalDesignComplete()
  {
    return finalDesignComplete;
  }


  public void setFinalDesignComplete(Date finalDesignComplete)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Final Design Complete'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(finalDesignComplete);
    this.getMilestoneList().add(newMilestone);
    this.finalDesignComplete = finalDesignComplete;
  }


  public Date getInitialProjectAward()
  {
    return initialProjectAward;
  }


  public void setInitialProjectAward(Date initialProjectAward)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Initial Project Award'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(initialProjectAward);
    this.getMilestoneList().add(newMilestone);
    this.initialProjectAward = initialProjectAward;
  }


  public Date getFinalProjectAward()
  {
    return finalProjectAward;
  }


  public void setFinalProjectAward(Date finalProjectAward)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Final Project Award'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(finalProjectAward);
    this.getMilestoneList().add(newMilestone);
    this.finalProjectAward = finalProjectAward;
  }


  public Date getConstructionComplete()
  {
    return constructionComplete;
  }


  public void setConstructionComplete(Date constructionComplete)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Construction Complete'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(constructionComplete);
    this.getMilestoneList().add(newMilestone);
    this.constructionComplete = constructionComplete;
  }


  public Date getEquipmentInstallationComplete()
  {
    return equipmentInstallationComplete;
  }


  public void setEquipmentInstallationComplete(Date equipmentInstallationComplete)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Equipment Installation Complete'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(equipmentInstallationComplete);
    this.getMilestoneList().add(newMilestone);
    this.equipmentInstallationComplete = equipmentInstallationComplete;
  }


  public Date getProveOutBegins()
  {
    return proveOutBegins;
  }


  public void setProveOutBegins(Date proveOutBegins)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Prove Out Begins'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(proveOutBegins);
    this.getMilestoneList().add(newMilestone);
    this.proveOutBegins = proveOutBegins;
  }


  public Date getProveOutComplete()
  {
    return proveOutComplete;
  }


  public void setProveOutComplete(Date proveOutComplete)
  {
    SelectQuery query = new SelectQuery(ProductionSupportFacilityProjectMilestoneEntry.class, Expression.fromString("title = 'Prove Out Complete'"));
    ProductionSupportFacilityProjectMilestoneEntry entry = (ProductionSupportFacilityProjectMilestoneEntry) objectContext.performQuery(query).get(0);
    for (ProductionSupportFacilityProjectMilestone milestone : this.getMilestoneList())
    {
      if (milestone.getMilestoneEntry().equals(entry))
      {
        this.getMilestoneList().remove(milestone);
        break;
      }
    }
    ProductionSupportFacilityProjectMilestone newMilestone = objectContext.newObject(ProductionSupportFacilityProjectMilestone.class);
    newMilestone.setMilestoneEntry(entry);
    newMilestone.setMonthYear(proveOutComplete);
    this.getMilestoneList().add(newMilestone);
    this.proveOutComplete = proveOutComplete;
  }


  @Override
  public List<ProductionSupportFacilityProjectCostElement> getCostElementList()
  {
    return new CayenneListWrapper<ProductionSupportFacilityProjectCostElement>(this, super.getCostElementList(), COST_ELEMENT_LIST_RELATIONSHIP_PROPERTY, true);
  }


  @Override
  public List<ProductionSupportFacilityProjectMilestone> getMilestoneList()
  {
    return new CayenneListWrapper<ProductionSupportFacilityProjectMilestone>(this, super.getMilestoneList(), MILESTONE_LIST_RELATIONSHIP_PROPERTY, true);
  }

  public boolean jibx_isCostElement()
  {
    if (super.getCostElementList() != null && super.getCostElementList().size() > 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }


  public boolean jibx_hasRelatedProjectList()
  {
    return super.getRelatedProjectList().size() > 0;
  }


  public Iterator<ProductionSupportFacilityProjectRelatedProject> jibx_RelatedProjectListIterator()
  {
    return getIterator(super.getRelatedProjectList());
  }


  public boolean jibx_isMilestone()
  {
    if (super.getMilestoneList() != null && super.getMilestoneList().size() > 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public void shiftForwardInTime(int years)
  {
    for (ProductionSupportFacilityProjectCostElement ce : this.getCostElementList())
    {
      ce.shiftForwardInTime(years);
    }

    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);

    for (ProductionSupportFacilityProjectMilestone pm : this.getMilestoneList())
    {
      pm.shiftForwardInTime(years);
    }
  }

  /**
   * @see java.lang.Object#hashCode()
   *
   * HashCode based on Business Rule [E-XML-PROC#P25-100]
   */
  @Override
  public int equivalenceHashCode()
  {
    return new HashCodeBuilder().append(getFacility()).append(toLowerAndTrim(getCode())).append(toLowerAndTrim(getTitle())).toHashCode();
  }

  /**
   * Equality based on Business Rule [E-XML-PROC#P25-100]
   */
  @Override
  public boolean equivalentTo(ProductionSupportFacilityProject other)
  {
    return new EqualsBuilder().append(getFacility(), other.getFacility()).append(toLowerAndTrim(getCode()), toLowerAndTrim(other.getCode())).append(toLowerAndTrim(getTitle()), toLowerAndTrim(other.getTitle())).isEquals();
  }


  @Override
  public List<? extends CostContainer> getChildren()
  {
    return getCostElementList();
  }

  @Override
  public Costs getUnitCosts()
  {
    return null;
  }

  @Override
  public Costs getQuantities()
  {
    return null;
  }
}
