package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

import mil.dtic.cbes.p40.vo.auto._QuarterlySchedule;
import mil.dtic.cbes.p40.vo.util.CostUtil;
import mil.dtic.utility.BigDecimalUtil;

public class QuarterlySchedule extends _QuarterlySchedule
{
  private static final long serialVersionUID = 1L;


  public void shiftForwardInTime(int years)
  {
    for (int i=0 ; i<years ; i++)
    {
      setPriorYears(CostUtil.addCosts(getPriorYears(),getPriorYearQ1()));
      setPriorYears(CostUtil.addCosts(getPriorYears(),getPriorYearQ2()));
      setPriorYears(CostUtil.addCosts(getPriorYears(),getPriorYearQ3()));
      setPriorYears(CostUtil.addCosts(getPriorYears(),getPriorYearQ4()));

      setPriorYearQ1(getCurrentYearQ1());
      setPriorYearQ2(getCurrentYearQ2());
      setPriorYearQ3(getCurrentYearQ3());
      setPriorYearQ4(getCurrentYearQ4());

      //Footnotes
      setPriorYearQ1Footnote((getCurrentYearQ1Footnote()));
      setPriorYearQ2Footnote(getCurrentYearQ2Footnote());
      setPriorYearQ3Footnote(getCurrentYearQ3Footnote());
      setPriorYearQ4Footnote(getCurrentYearQ4Footnote());

      setCurrentYearQ1(getBy1Q1());
      setCurrentYearQ2(getBy1Q2());
      setCurrentYearQ3(getBy1Q3());
      setCurrentYearQ4(getBy1Q4());

      //Footnotes
      setCurrentYearQ1Footnote(getBy1Q1Footnote());
      setCurrentYearQ2Footnote(getBy1Q2Footnote());
      setCurrentYearQ3Footnote(getBy1Q3Footnote());
      setCurrentYearQ4Footnote(getBy1Q4Footnote());

      setBy1Q1(getBy2Q1());
      setBy1Q2(getBy2Q2());
      setBy1Q3(getBy2Q3());
      setBy1Q4(getBy2Q4());

      //Footnote
      setBy1Q1Footnote(getBy2Q1Footnote());
      setBy1Q2Footnote(getBy2Q2Footnote());
      setBy1Q3Footnote(getBy2Q3Footnote());
      setBy1Q4Footnote(getBy2Q4Footnote());

      setBy2Q1(getBy3Q1());
      setBy2Q2(getBy3Q2());
      setBy2Q3(getBy3Q3());
      setBy2Q4(getBy3Q4());

      //Footnote
      setBy2Q1Footnote(getBy3Q1Footnote());
      setBy2Q2Footnote(getBy3Q2Footnote());
      setBy2Q3Footnote(getBy3Q3Footnote());
      setBy2Q4Footnote(getBy3Q4Footnote());

      setBy3Q1(getBy4Q1());
      setBy3Q2(getBy4Q2());
      setBy3Q3(getBy4Q3());
      setBy3Q4(getBy4Q4());

      //Foonote
      setBy3Q1Footnote(getBy4Q1Footnote());
      setBy3Q2Footnote(getBy4Q2Footnote());
      setBy3Q3Footnote(getBy4Q3Footnote());
      setBy3Q4Footnote(getBy4Q4Footnote());

      setBy4Q1(getBy5Q1());
      setBy4Q2(getBy5Q2());
      setBy4Q3(getBy5Q3());
      setBy4Q4(getBy5Q4());

      //Footnote
      setBy4Q1Footnote(getBy5Q1Footnote());
      setBy4Q2Footnote(getBy5Q2Footnote());
      setBy4Q3Footnote(getBy5Q3Footnote());
      setBy4Q4Footnote(getBy5Q4Footnote());

      setBy5Q1(null);
      setBy5Q2(null);
      setBy5Q3(null);
      setBy5Q4(null);

      // totals etc don't change as long as everything is collected in All Prior Years correctly
    }
  }

    public void clearOutYears()
    {
        // BY 2
        setBy2Q1(null);
        setBy2Q2(null);
        setBy2Q3(null);
        setBy2Q4(null);

        // BY 2 Footnote
        setBy2Q1Footnote(null);
        setBy2Q2Footnote(null);
        setBy2Q3Footnote(null);
        setBy2Q4Footnote(null);

        // BY 3
        setBy3Q1(null);
        setBy3Q2(null);
        setBy3Q3(null);
        setBy3Q4(null);

        // BY 3 Foonote
        setBy3Q1Footnote(null);
        setBy3Q2Footnote(null);
        setBy3Q3Footnote(null);
        setBy3Q4Footnote(null);

        // BY 4
        setBy4Q1(null);
        setBy4Q2(null);
        setBy4Q3(null);
        setBy4Q4(null);

        // BY 4 Footnote
        setBy4Q1Footnote(null);
        setBy4Q2Footnote(null);
        setBy4Q3Footnote(null);
        setBy4Q4Footnote(null);

        // BY 5
        setBy5Q1(null);
        setBy5Q2(null);
        setBy5Q3(null);
        setBy5Q4(null);

        // BY 5 Footnote
        setBy5Q1Footnote(null);
        setBy5Q2Footnote(null);
        setBy5Q3Footnote(null);
        setBy5Q4Footnote(null);

        // To Complete
        setToComplete(null);
        setToCompleteFootnote(null);

        // Total
        setTotal(null);
        setTotalFootnote(null);
    }

  /**
   * Test to indicate whether any quarter of any FY has
   * @return true if any po
   */
  public boolean hasAnyQuarters()
  {
    return !BigDecimalUtil.isZeroOrNull(getPriorYears())
      || !BigDecimalUtil.isZeroOrNull(getBy1Q1())
      || !BigDecimalUtil.isZeroOrNull(getBy1Q2())
      || !BigDecimalUtil.isZeroOrNull(getBy1Q3())
      || !BigDecimalUtil.isZeroOrNull(getBy1Q4())
      || !BigDecimalUtil.isZeroOrNull(getBy2Q1())
      || !BigDecimalUtil.isZeroOrNull(getBy2Q2())
      || !BigDecimalUtil.isZeroOrNull(getBy2Q3())
      || !BigDecimalUtil.isZeroOrNull(getBy2Q4())
      || !BigDecimalUtil.isZeroOrNull(getBy3Q1())
      || !BigDecimalUtil.isZeroOrNull(getBy3Q2())
      || !BigDecimalUtil.isZeroOrNull(getBy3Q3())
      || !BigDecimalUtil.isZeroOrNull(getBy3Q4())
      || !BigDecimalUtil.isZeroOrNull(getBy4Q1())
      || !BigDecimalUtil.isZeroOrNull(getBy4Q2())
      || !BigDecimalUtil.isZeroOrNull(getBy4Q3())
      || !BigDecimalUtil.isZeroOrNull(getBy4Q4())
      || !BigDecimalUtil.isZeroOrNull(getBy5Q1())
      || !BigDecimalUtil.isZeroOrNull(getBy5Q2())
      || !BigDecimalUtil.isZeroOrNull(getBy5Q3())
      || !BigDecimalUtil.isZeroOrNull(getBy5Q4())
      || !BigDecimalUtil.isZeroOrNull(getCurrentYearQ1())
      || !BigDecimalUtil.isZeroOrNull(getCurrentYearQ2())
      || !BigDecimalUtil.isZeroOrNull(getCurrentYearQ3())
      || !BigDecimalUtil.isZeroOrNull(getCurrentYearQ4())
      || !BigDecimalUtil.isZeroOrNull(getPriorYearQ1())
      || !BigDecimalUtil.isZeroOrNull(getPriorYearQ2())
      || !BigDecimalUtil.isZeroOrNull(getPriorYearQ3())
      || !BigDecimalUtil.isZeroOrNull(getPriorYearQ4());
  }

  public BigDecimal sumQuarters()
  {
    BigDecimal sum = null;

    sum = BigDecimalUtil.add(sum, getPriorYears());
    sum = BigDecimalUtil.add(sum, getToComplete());
    sum = BigDecimalUtil.add(sum, getBy1Q1());
    sum = BigDecimalUtil.add(sum, getBy1Q2());
    sum = BigDecimalUtil.add(sum, getBy1Q3());
    sum = BigDecimalUtil.add(sum, getBy1Q4());
    sum = BigDecimalUtil.add(sum, getBy2Q1());
    sum = BigDecimalUtil.add(sum, getBy2Q2());
    sum = BigDecimalUtil.add(sum, getBy2Q3());
    sum = BigDecimalUtil.add(sum, getBy2Q4());
    sum = BigDecimalUtil.add(sum, getBy3Q1());
    sum = BigDecimalUtil.add(sum, getBy3Q2());
    sum = BigDecimalUtil.add(sum, getBy3Q3());
    sum = BigDecimalUtil.add(sum, getBy3Q4());
    sum = BigDecimalUtil.add(sum, getBy4Q1());
    sum = BigDecimalUtil.add(sum, getBy4Q2());
    sum = BigDecimalUtil.add(sum, getBy4Q3());
    sum = BigDecimalUtil.add(sum, getBy4Q4());
    sum = BigDecimalUtil.add(sum, getBy5Q1());
    sum = BigDecimalUtil.add(sum, getBy5Q2());
    sum = BigDecimalUtil.add(sum, getBy5Q3());
    sum = BigDecimalUtil.add(sum, getBy5Q4());
    sum = BigDecimalUtil.add(sum, getCurrentYearQ1());
    sum = BigDecimalUtil.add(sum, getCurrentYearQ2());
    sum = BigDecimalUtil.add(sum, getCurrentYearQ3());
    sum = BigDecimalUtil.add(sum, getCurrentYearQ4());
    sum = BigDecimalUtil.add(sum, getPriorYearQ1());
    sum = BigDecimalUtil.add(sum, getPriorYearQ2());
    sum = BigDecimalUtil.add(sum, getPriorYearQ3());
    sum = BigDecimalUtil.add(sum, getPriorYearQ4());

    return sum;
  }

  public boolean isContainingOutYears()
  {
    return !BigDecimalUtil.isZeroOrNull(getToComplete())
        || !BigDecimalUtil.isZeroOrNull(getBy2Q1())
        || !BigDecimalUtil.isZeroOrNull(getBy2Q2())
        || !BigDecimalUtil.isZeroOrNull(getBy2Q3())
        || !BigDecimalUtil.isZeroOrNull(getBy2Q4())
        || !BigDecimalUtil.isZeroOrNull(getBy3Q1())
        || !BigDecimalUtil.isZeroOrNull(getBy3Q2())
        || !BigDecimalUtil.isZeroOrNull(getBy3Q3())
        || !BigDecimalUtil.isZeroOrNull(getBy3Q4())
        || !BigDecimalUtil.isZeroOrNull(getBy4Q1())
        || !BigDecimalUtil.isZeroOrNull(getBy4Q2())
        || !BigDecimalUtil.isZeroOrNull(getBy4Q3())
        || !BigDecimalUtil.isZeroOrNull(getBy4Q4())
        || !BigDecimalUtil.isZeroOrNull(getBy5Q1())
        || !BigDecimalUtil.isZeroOrNull(getBy5Q2())
        || !BigDecimalUtil.isZeroOrNull(getBy5Q3())
        || !BigDecimalUtil.isZeroOrNull(getBy5Q4())
        || !BigDecimalUtil.isZeroOrNull(getTotal());
  }

  public boolean isAllIntegerValues()
  {
    return BigDecimalUtil.isIntegerValueOrNull(getPriorYears())
        && BigDecimalUtil.isIntegerValueOrNull(getPriorYearQ1())
        && BigDecimalUtil.isIntegerValueOrNull(getPriorYearQ2())
        && BigDecimalUtil.isIntegerValueOrNull(getPriorYearQ3())
        && BigDecimalUtil.isIntegerValueOrNull(getPriorYearQ4())
        && BigDecimalUtil.isIntegerValueOrNull(getCurrentYearQ1())
        && BigDecimalUtil.isIntegerValueOrNull(getCurrentYearQ2())
        && BigDecimalUtil.isIntegerValueOrNull(getCurrentYearQ3())
        && BigDecimalUtil.isIntegerValueOrNull(getCurrentYearQ4())
        && BigDecimalUtil.isIntegerValueOrNull(getBy1Q1())
        && BigDecimalUtil.isIntegerValueOrNull(getBy1Q2())
        && BigDecimalUtil.isIntegerValueOrNull(getBy1Q3())
        && BigDecimalUtil.isIntegerValueOrNull(getBy1Q4())
        && BigDecimalUtil.isIntegerValueOrNull(getBy2Q1())
        && BigDecimalUtil.isIntegerValueOrNull(getBy2Q2())
        && BigDecimalUtil.isIntegerValueOrNull(getBy2Q3())
        && BigDecimalUtil.isIntegerValueOrNull(getBy2Q4())
        && BigDecimalUtil.isIntegerValueOrNull(getBy3Q1())
        && BigDecimalUtil.isIntegerValueOrNull(getBy3Q2())
        && BigDecimalUtil.isIntegerValueOrNull(getBy3Q3())
        && BigDecimalUtil.isIntegerValueOrNull(getBy3Q4())
        && BigDecimalUtil.isIntegerValueOrNull(getBy4Q1())
        && BigDecimalUtil.isIntegerValueOrNull(getBy4Q2())
        && BigDecimalUtil.isIntegerValueOrNull(getBy4Q3())
        && BigDecimalUtil.isIntegerValueOrNull(getBy4Q4())
        && BigDecimalUtil.isIntegerValueOrNull(getBy5Q1())
        && BigDecimalUtil.isIntegerValueOrNull(getBy5Q2())
        && BigDecimalUtil.isIntegerValueOrNull(getBy5Q3())
        && BigDecimalUtil.isIntegerValueOrNull(getBy5Q4())
        && BigDecimalUtil.isIntegerValueOrNull(getToComplete())
        && BigDecimalUtil.isIntegerValueOrNull(getTotal());
  }

  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  public boolean jibx_hasPriorYear() {
    return getPriorYearQ1() != null || getPriorYearQ2() != null
    || getPriorYearQ3() != null || getPriorYearQ4() != null;
  }

  public boolean jibx_hasPriorYearQ1() {
    return getPriorYearQ1() != null;
  }

  public boolean jibx_hasPriorYearQ2() {
    return getPriorYearQ2() != null;
  }

  public boolean jibx_hasPriorYearQ3() {
    return getPriorYearQ3() != null;
  }

  public boolean jibx_hasPriorYearQ4() {
    return getPriorYearQ4() != null;
  }

  public boolean jibx_hasCurrentYear() {
    return getCurrentYearQ1() != null || getCurrentYearQ2() != null
    || getCurrentYearQ3() != null || getCurrentYearQ4() != null;
  }

  public boolean jibx_hasCurrentYearQ1() {
    return getCurrentYearQ1() != null;
  }

  public boolean jibx_hasCurrentYearQ2() {
    return getCurrentYearQ2() != null;
  }

  public boolean jibx_hasCurrentYearQ3() {
    return getCurrentYearQ3() != null;
  }

  public boolean jibx_hasCurrentYearQ4() {
    return getCurrentYearQ4() != null;
  }

  public boolean jibx_hasBy1() {
    return getBy1Q1() != null || getBy1Q2() != null
    || getBy1Q3() != null || getBy1Q4() != null;
  }

  public boolean jibx_hasBy1Q1() {
    return getBy1Q1() != null;
  }

  public boolean jibx_hasBy1Q2() {
    return getBy1Q2() != null;
  }

  public boolean jibx_hasBy1Q3() {
    return getBy1Q3() != null;
  }

  public boolean jibx_hasBy1Q4() {
    return getBy1Q4() != null;
  }

  public boolean jibx_hasBy2() {
    return getBy2Q1() != null || getBy2Q2() != null
    || getBy2Q3() != null || getBy2Q4() != null;
  }

  public boolean jibx_hasBy2Q1() {
    return getBy2Q1() != null;
  }

  public boolean jibx_hasBy2Q2() {
    return getBy2Q2() != null;
  }

  public boolean jibx_hasBy2Q3() {
    return getBy2Q3() != null;
  }

  public boolean jibx_hasBy2Q4() {
    return getBy2Q4() != null;
  }

  public boolean jibx_hasBy3() {
    return getBy3Q1() != null || getBy3Q2() != null
    || getBy3Q3() != null || getBy3Q4() != null;
  }


  public boolean jibx_hasBy3Q1() {
    return getBy3Q1() != null;
  }

  public boolean jibx_hasBy3Q2() {
    return getBy3Q2() != null;
  }

  public boolean jibx_hasBy3Q3() {
    return getBy3Q3() != null;
  }

  public boolean jibx_hasBy3Q4() {
    return getBy3Q4() != null;
  }

  public boolean jibx_hasBy4() {
    return getBy4Q1() != null || getBy4Q2() != null
    || getBy4Q3() != null || getBy4Q4() != null;
  }

  public boolean jibx_hasBy4Q1() {
    return getBy4Q1() != null;
  }

  public boolean jibx_hasBy4Q2() {
    return getBy4Q2() != null;
  }

  public boolean jibx_hasBy4Q3() {
    return getBy4Q3() != null;
  }

  public boolean jibx_hasBy4Q4() {
    return getBy4Q4() != null;
  }

  public boolean jibx_hasBy5() {
    return getBy5Q1() != null || getBy5Q2() != null
    || getBy5Q3() != null || getBy5Q4() != null;
  }

  public boolean jibx_hasBy5Q1() {
    return getBy5Q1() != null;
  }

  public boolean jibx_hasBy5Q2() {
    return getBy5Q2() != null;
  }

  public boolean jibx_hasBy5Q3() {
    return getBy5Q3() != null;
  }

  public boolean jibx_hasBy5Q4() {
    return getBy5Q4() != null;
  }

  public boolean jibx_hasToComplete() {
    return getToComplete() != null;
  }

  public boolean jibx_hasTotal() {
    return getTotal() != null;
  }

  public boolean jibx_hasPriorYears() {
    return getPriorYears() != null;
  }

}
