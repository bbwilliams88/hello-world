package mil.dtic.cbes.p40.vo;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.ConfigTypeFlag;
import mil.dtic.cbes.p40.vo.auto._Config;
import mil.dtic.cbes.submissions.dao.imp.ConfigDAOImpl;
import mil.dtic.utility.CbesLogFactory;

public class Config extends _Config
{
    private static final Logger log = CbesLogFactory.getLog(Config.class);
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setType(ConfigTypeFlag.STRING);
        setReadOnly(false);
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    private static String getHost()
    {
        String host = null;

        try
        {
            host = InetAddress.getLocalHost().getHostName();
        }
        catch (UnknownHostException e)
        {
            log.error(e);
        }

        return host;
    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    /**
     * @param objectContext
     *            The objectContext to create and register a new configuration
     *            object into.
     * @param name
     *            The name (key) of this configuration object.
     * @param value
     *            The value of this configuration object.
     * @return A new configuration object with the given name/value and
     *         registered in the objectContext.
     */
    public static Config createNew(ObjectContext objectContext, String name, String value)
    {
        Config configuration = objectContext.newObject(Config.class);

        configuration.setName(name);
        configuration.setValue(value);

        return configuration;
    }

    /**
     * @param objectContext
     *            The objectContext to fetch the configuration records into.
     * @return All configuration records from the database.
     */
    @SuppressWarnings("unchecked")
    public static List<Config> fetchAll(ObjectContext objectContext)
    {
        return objectContext.performQuery(new SelectQuery(Config.class));
    }

    /**
     * @param objectContext
     *            The objectContext to fetch the configuration object into.
     * @param name
     *            The name (key) of the configuration object to match in the
     *            database.
     * @return The configuration object matching the given name.
     */
    @SuppressWarnings({ "unchecked" })
    public static Config fetchByName(ObjectContext objectContext, final String name)
    {
        String      host  = getHost();
        SelectQuery query = new SelectQuery(Config.class, ExpressionFactory.matchExp(NAME_PROPERTY, name));

        query.setCacheStrategy(QueryCacheStrategy.NO_CACHE);

        List<Config> configurations       = objectContext.performQuery(query);
        Config       defaultConfiguration = null;

        for (Config configuration : configurations)
        {
            if (ConfigDAOImpl.UNASSIGNED_HOST.equals(configuration.getEnv()))
                defaultConfiguration = configuration;

            if (StringUtils.equals(host, configuration.getEnv()))
                return configuration;
        }

        if (defaultConfiguration != null)
            return defaultConfiguration;

        log.error("Config " + name + " not found");

        return null;
    }

    /**
     * Attempts to parse a configuration value into an object appropriate to the
     * value's type column, fall back to a string on failure.
     *
     * @param objectContext
     *            The ObjectContext to fetch the configuration item into.
     * @param name
     *            The name (key) of the configuration item to match.
     * @return The parsed value for the matching configuration item or null if
     *         no item could be matched.
     */
    // FIXME: Why do we need an objectContext here? Should be able to create a
    // new one and throw it away since we only care about extracting the value
    // and returning it.
    public static Object fetchValueByName(ObjectContext objectContext, String name)
    {
        Config configuration = fetchByName(objectContext, name);

        if (configuration == null)
            return null;

            switch (configuration.getType())
            {
                case BOOLEAN:
                    return Boolean.parseBoolean(configuration.getValue());
                case NUM:
                    return Integer.parseInt(configuration.getValue());
                case DATE: // TODO no idea how dates are supposed to be
                           // formatted
                    return configuration.getValue();
                    // the rest of these are strings
                case HOST:
                case EMAIL:
                case PATH:
                case URL:
                case STRING:
            }

        return configuration.getValue();
    }
}
