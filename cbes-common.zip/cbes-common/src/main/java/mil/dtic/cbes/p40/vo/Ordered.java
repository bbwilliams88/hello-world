package mil.dtic.cbes.p40.vo;



public interface Ordered
{
  Integer getDisplayOrder();
  void setDisplayOrder(Integer i);
}