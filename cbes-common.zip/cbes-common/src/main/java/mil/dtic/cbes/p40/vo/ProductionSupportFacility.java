package mil.dtic.cbes.p40.vo;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacility;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ProductionSupportFacility extends _ProductionSupportFacility
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(ProductionSupportFacility.class);


  @Override
public void onPrePersist()
  {

  }


  @Override
public void shiftForwardInTime(int years)
  {
    for (ProductionSupportFacilityProject fp : this.getProductionSupportFacilityProjectList())
    {
      fp.shiftForwardInTime(years);
    }
  }


  public boolean jibx_hasProductionSupportFacilityProjectList()
  {
    return CollectionUtils.isNotEmpty(super.getProductionSupportFacilityProjectList());
  }


  public Iterator<ProductionSupportFacilityProject> jibx_ProductionSupportFacilityProjectIterator()
  {
    return getIterator(super.getProductionSupportFacilityProjectList());
  }


  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getProductionSupportFacilityProjectList());
  }


  @Override
  public List<ProductionSupportFacilityProject> getProductionSupportFacilityProjectList()
  {
    return getSortedByDisplayOrder(super.getProductionSupportFacilityProjectList());
  }


  public void setFacilityProjectList(List<ProductionSupportFacilityProject> l)
  {
    log.trace("Collection setters not implemented " + (l == null ? null : l.size()));
  }


  public List<ProductionSupportFacilityProject> getFacilityProjectList()
  {
    return getProductionSupportFacilityProjectList();
  }


  @Override
  public Costs getCosts()
  {
    Costs costs = new Costs();
    for (ProductionSupportFacilityProject project : getFacilityProjectList())
    {
      costs.add(project.getCosts());
    }
    return costs;
  }


  @Override
  public Costs getUnitCosts()
  {
    return null;
  }


  @Override
  public Costs getQuantities()
  {
    return null;
  }
}
