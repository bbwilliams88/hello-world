/* $Id:$ */
package mil.dtic.cbes.jb;




public interface IAppropriation
{
  String getCode();
  void setCode(String code);
  String getName();
  void setName(String name);
}