package mil.dtic.cbes.jb;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.factories.RomanNumberFactory;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Constants.BUDGET_AREA;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.MultiYearProcurementList;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.xml.JavaToXmlResult;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.InvalidXMLListener;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.XmlUtil;
import mil.dtic.utility.submissiondate.SubmissionDateProcessorFactory;
import mil.dtic.utility.submissiondate.exception.SubmissionDateProcessorException;

public abstract class JBBase extends JBDefaultSystemGeneratedPart {
	private static final long serialVersionUID = 1L;
	private static final Logger log = CbesLogFactory.getLog(JBBase.class);
	private static final String SUPP_DOC = "Supplemental Document";
	private static final String META_DATE_FORMAT = "yyMMdHHmm"; 
	private static final String META_STATUS_XA = "XA";
	private static final String META_STATUS_XE = "XE";
	private static final String META_STATUS_XW = "XW";
	private static final String META_RFR_DRAFT = "YD";
	private static final String META_RFR_PRCP = "YP";
	private static final String META_RFR_RFR = "YR";
	private static final String META_RFR_FINAL = "YF";

	protected static final String META_MJB = "MJB";
	protected static final String META_JB= "JB";
	
	private static final String REVIEW_STATUS = "REVIEW";
	private static final String DRAFT_STATUS = "DRAFT";
	private static final String FINAL_STATUS = "FINAL";
	private static final String FINAL_STAMP = " ";
	private static final String PREPRCP_STATUS = "PREPRCP";
	private static final String NO_WORKFLOW_STATUS = "NONE";
	
	private static final String SETTING_SUBMISSION_DATE_ERROR_EMAIL_SUBJECT = "CXE Alert - Setting Submission Date for JB Failed.";
	private static final String SETTING_SUBMISSION_DATE_ERROR_EMAIL_BODY = "There has been an error setting the submission date for a justification book. Check the logs for more information.";
	
	protected String targetSchemaVersion;
	protected String budgetCycle;
	protected Integer budgetYear;
	protected Date submissionDate;
	protected ServiceAgency serviceAgency;
	protected IAppropriation appropriation;
	protected String builtinLogoFileName;
	protected JBCover coverDoc;
	protected JBCostDoc costDoc;
	protected JBIntroductionDoc introductionDoc;
	protected BaseToc toc;
	protected JBSummaryDoc summaryDoc;
	protected JBPeToc peTocByBa;
	protected JBPeToc peTocByTitle;
	protected R1Summary r1Summary;
	protected R1 r1;
	protected R1C r1c;
	protected R1D r1d;
	protected JBSupplementalDocCollection supplementalDocCollection;
	protected JBUserR1Doc userR1Doc;
	protected JBAcronymDoc acronymDoc;
	protected JBUserP1Doc userP1Doc;
	protected JBLiToc liTocByBa;
	protected JBLiToc liTocByTitle;
	protected P1 p1;
	protected P1M p1m;
	protected JBBlankPage blankPage;
	protected List<KeyValuePair> r2PageNumberKvpList;
	protected List<KeyValuePair> p40PageNumberKvpList;
	protected List<KeyValuePair> mypPageNumberKvpList;
	protected List<PaginationGroup> pgList;
	protected R2ExhibitList r2ExhibitList;
	protected LineItemList lineItemList;
	protected MultiYearProcurementList multiYearProcurementList;
	protected int pdfPageOffset = 1;
	protected Constants.JBPageNumberingModel jbPageNumberingModel = Constants.JBPageNumberingModel.SECTIONED;
	protected String titlePrefix;

	
	protected boolean rfr = false;
	protected Integer rfrType = null;
	private boolean tail = false;

	/**********************************************************************************************************
	 * START Java-to-XML binding methods. These methods are used by JiBX for
	 * Java-to-XML binding at runt time (not needed for XML-to-Java).
	 **********************************************************************************************************
	 */

	public boolean hasExternalDocuments_xml() {
		return introductionDoc != null || summaryDoc != null || acronymDoc != null || userR1Doc != null
				|| userP1Doc != null || supplementalDocCollection != null || costDoc != null;
	}

	public boolean hasDocAssemblyOptions_xml() {
		return docAssemblyOptions != null;
	}

	/**********************************************************************************************************
	 * END Java-to-XML binding methods.
	 **********************************************************************************************************
	 */

	public abstract boolean r3sExist();

	public abstract boolean r2sExist();

	public abstract boolean lineItemsExist();

	public abstract boolean secondaryDistributionsExist();

	public abstract boolean p21sExist();

	public abstract boolean multiYearProcurementsExist();

	protected abstract String getPageNumberPrefix();

	public abstract JavaToXmlResult toZip(InvalidXMLListener invalidXMLListener, boolean excludeExternalObjectsFromZip)
			throws IOException, SQLException;

	public JavaToXmlResult toZip(InvalidXMLListener invalidXMLListener) throws IOException, SQLException {
		return toZip(invalidXMLListener, false);
	}

	public JavaToXmlResult toZip() throws IOException, SQLException {
		return toZip(null);
	}

	@Override
	public String getUserVisibleLabel() {
		if (FileUtil.isZipFile(absoluteFileName))
			return FileUtil.createZipFileName(getBusinessId());
		else
			return FileUtil.createPdfFileName(getBusinessId());
	}

	@Override
	public Map<String, String> getPdfPropertiesToApply(Map<String, String> existingProps) {
		Map<String, String> props = super.getPdfPropertiesToApply(existingProps);
		props.put(Constants.PDF_PROPS_TITLE_KEY, FileSetting.JB.getTitle());
		return props;
	}

	@Override
	public String getPdfBookmarkLabel() {
		return serviceAgency.getName();
	}

	@Override
	public BudgesContentType getBudgesContentType() {
		return BudgesContentType.getContentType(absoluteFileName);
	}

	@Override
	public String getBusinessId() {
		if (serviceAgency == null)
			return null;
		else {
		    return Util.underscoreConcat(serviceAgency.getCode(), budgetCycle, budgetYear);
		}
	}
	
	protected String getFileMetaTag(JBBase jbBase) {
	    StringBuilder sb = new StringBuilder();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat(JBBase.META_DATE_FORMAT);
        sb.append(dateFormat.format(date));
        
        if (jbBase instanceof JustificationBook) {
            sb.append("ZZZZ"); 
            return sb.toString();
        }
        
        if (isHasErrors()){
            sb.append(JBBase.META_STATUS_XE);
        }
        else if (isHasWarnings()) {
            sb.append(JBBase.META_STATUS_XW);
        }
        else {
            sb.append(JBBase.META_STATUS_XA);
        }
        
        switch(super.getDocAssemblyOptions().getWorkFlowStatus()) {
            case JBBase.DRAFT_STATUS:
                sb.append(JBBase.META_RFR_DRAFT);
                break;
            case JBBase.PREPRCP_STATUS:
                sb.append(JBBase.META_RFR_PRCP);
                break;
            case JBBase.REVIEW_STATUS:
                sb.append(JBBase.META_RFR_RFR);
                break;
            case JBBase.FINAL_STATUS:
                sb.append(JBBase.META_RFR_FINAL);
                break;
            default:
                sb.append(JBBase.META_RFR_DRAFT);
        }
        
        return sb.toString();
	}

	protected BUDGET_AREA getBudgetArea() {
		if (lineItemsExist()) {
			return BUDGET_AREA.PROCUREMENT;
		} else if (r2sExist()) {
			return BUDGET_AREA.RDTE;
		} else {
			return BUDGET_AREA.NOEXHIBITS;
		}
	}

	protected void setPdfAbsoluteStartPages() {
	    log.trace("setPdfAbsoluteStartPages: - start");
		int absolutePageNumber = 1;
		
		setPdfAbsoluteStartPage(absolutePageNumber);

		for (PaginationGroup pg : pgList) {
		    List<JBPart> tailList = new ArrayList<>();
		    
			for (JBPart jbPart : pg.getJbPartList()) {
			    if (jbPart.getFileSetting().getTitle().equals(JBBase.SUPP_DOC) && tail) {
			        tailList.add(jbPart);
			    }
			    else {
			        absolutePageNumber = jbPart.setPdfAbsoluteStartPages(absolutePageNumber);
			        log.trace("setPdfAbsoluteStartPage: set absolutePageNumber: " + absolutePageNumber + " for: " + jbPart.getClass().getName());
			    }
			}
			if (tailList.size() > 0) {
			    for (JBPart jbPart : tailList) {
			        absolutePageNumber = jbPart.setPdfAbsoluteStartPages(absolutePageNumber);
			    }
			}
		}
	}

	public void concatPdfs() throws DocumentException, IOException {
		log.trace("concatPdfs(): About to concatenate MJB/JB documents...");
		String tmpFileName = FileUtil.createPdfFileName(getFileNamePrefix()); 
		File outputFile = new File(workingFolder, tmpFileName);
		absoluteFileName = outputFile.getAbsolutePath();
		log.trace("concatPdfs(): absolutFileName: " + absoluteFileName);

		List<String> concatFileNameList = new ArrayList<String>();
		List<JBPart> tailList = new ArrayList<>();
		
		log.trace("concatPdfs():Building list of file names for concatenation from " + pgList.size() + " pagination groups");
		int i = 0;
		for (PaginationGroup pg : pgList) {
		    log.trace("working paginationGroup " +i++);
			for (JBPart jbPart : pg.getJbPartList()) {
				log.trace("concatPdfs(): jbPart index: " + jbPart.getPartIndex() + " name: " + jbPart.getClass().getName());
				if (jbPart.hasContent()) {
				    
	                if (null != jbPart.getDocAssemblyOptions() && !tail){
	                    tail = jbPart.getDocAssemblyOptions().isPositionAttachmentsAfterExhibits();
	                    log.trace("tail: " + tail);
	                }
				    
				    if (jbPart.getFileSetting().getTitle().equals(JBBase.SUPP_DOC) && tail){
				        log.trace("concatPdfs(): adding attachment to the tailList");
				        tailList.add(jbPart);
				        continue;
				     }
				    
				    concatFileNameList.add(jbPart.getAbsoluteFileName());    
				}   
			}
		}		
		
		if(CollectionUtils.isNotEmpty(tailList)){
		    log.trace("concatPdf(): processing tailList of size: " + tailList.size());
		    i = 0;
		    for (JBPart jbPart : tailList){
		        i++;
		        concatFileNameList.add(jbPart.getAbsoluteFileName());
		        log.trace("concat(): adding JBPart from tailList document to the end of the concatFileNameList: pos: "+ 
		                i + "name: " + jbPart.getClass().getName());
		    }
		}
		
		if (CollectionUtils.isNotEmpty(concatFileNameList)){
		    log.trace("JBBase:concatPdfs - calling PdfUtil.concatPdfs with concatFileNameList size: " + concatFileNameList.size());
			PdfUtil.concatPdfs(outputFile, concatFileNameList);
		}
		log.trace("Finished concatenating... ");
	}

    protected void numberPagesAndWatermark(List<PaginationGroup> pgList, PdfReader pdfReader, PdfStamper pdfStamper) {
		log.trace("About to page number and watermark JB document...");
		log.trace("Total number of pagination groups is " + pgList.size());
		log.trace("Watermark text is '" + docAssemblyOptions.getWatermark() + "'");
		log.trace("Tracking Header text is '" + docAssemblyOptions.getTrackingHeader() + "'");

		String workFlowStatus = 
		        StringUtils.isEmpty(docAssemblyOptions.getWorkFlowStatus()) ? null : 
		            docAssemblyOptions.getWorkFlowStatus().trim();
		JBookWorkFlowStatus jBookWorkFlowStatus = null;
		boolean addWorkFlowStatus = false;

		if (workFlowStatus != null) {
			jBookWorkFlowStatus = JBookWorkFlowStatus.valueOf(workFlowStatus);
			addWorkFlowStatus = jBookWorkFlowStatus.getProcess();
		} 
		else {
			jBookWorkFlowStatus = JBookWorkFlowStatus.valueOf(JBBase.NO_WORKFLOW_STATUS);
		}

		String watermarkText = StringUtils.isEmpty(
		        docAssemblyOptions.getWatermark()) ? null : docAssemblyOptions.getWatermark().trim();
		boolean addWatermark = watermarkText != null;

		String trackingHeaderText = StringUtils.isEmpty(
		        docAssemblyOptions.getTrackingHeader()) ? null : docAssemblyOptions.getTrackingHeader().trim();
		boolean addTrackingHeader = trackingHeaderText != null;

		int absolutePageNumber = 1;
		int currentLocalPageNumber = 1;
		
		for (PaginationGroup pg : pgList) {
			log.trace("Processing pagination group, absolute page number is " + absolutePageNumber + "...");
			boolean addWarningMsg = showWarningMessage(pg);
			log.trace("addWarningMsg: " + addWarningMsg);
			boolean addPrcpOnlyWarnings = showPrePrcpMessage(pg);  
			boolean addPageNumber = true;

			if (Constants.JBPageNumbering.RESTART.equals(pg.getPageNumbering())) {
				log.trace("Restarting pagination with page number style " + pg.getPageNumberingStyle() + "...");
				if (Constants.JBPageNumberingModel.CONTINUOUS.equals(jbPageNumberingModel)){
					currentLocalPageNumber = pdfPageOffset;
				}
				else{
					currentLocalPageNumber = 1;
				}
			} 
			else if (Constants.JBPageNumbering.CONTINUE.equals(pg.getPageNumbering())) {
				log.trace("Continuing pagination with page number style " + pg.getPageNumberingStyle() + "...");
			} 
			else {
				log.trace("No page numbering will be done for this group");
				addPageNumber = false;
			}
			
			int totalPagesInPaginationGroup = 0;

			for (JBPart jbPart : pg.getJbPartList()) {
				log.trace("Processing page numbering for JB Part: " + jbPart.getAbsoluteFileName() + ", page count = "
						+ jbPart.getPdfTotalPageCount());

				if (jbPart.hasContent()) {
				    int lastPageIndex = absolutePageNumber + jbPart.getPdfTotalPageCount();
					
					for (int currPageIndex = absolutePageNumber; currPageIndex < lastPageIndex; ++currPageIndex) {
					    
					    Rectangle pageSizeRectangle;
					    try {
					        pageSizeRectangle = pdfReader.getPageSizeWithRotation(currPageIndex);
					    }
					    catch(RuntimeException re){ 
					        log.warn("failed to create a rectangle at currPageIndex: " + currPageIndex);
					        continue;
					    }

						if (addWatermark || addTrackingHeader) {
							PdfContentByte pdfUnderContentByte = pdfStamper.getUnderContent(currPageIndex);

							if (addWatermark) {
								PdfUtil.addWatermarkToPdfPage(watermarkText, pageSizeRectangle, pdfUnderContentByte);
							}

							if (addTrackingHeader) {
								PdfUtil.addTrackingHeaderToPdfPage(trackingHeaderText, pageSizeRectangle,
										pdfUnderContentByte);
							}
						}

						PdfContentByte pdfOverContentByte = pdfStamper.getOverContent(currPageIndex);

						if (addPageNumber) {
							stampPageWithPageNumber(currentLocalPageNumber, pg, pdfOverContentByte, pageSizeRectangle);
						}
						
						if (executeWarningStamp(addWarningMsg, addWorkFlowStatus, addPrcpOnlyWarnings, jBookWorkFlowStatus)){
						    stampPageWithWarningMessage(pdfOverContentByte, pageSizeRectangle, null);
						    log.warn("stamped book with warning message");
						}
						else {
						    String stampValue = getStampValue(jBookWorkFlowStatus);
							stampPageWithWarningMessage(pdfOverContentByte, pageSizeRectangle, stampValue);
							log.warn("stamped book with: " + stampValue);
						}
						
						++currentLocalPageNumber;
						++absolutePageNumber;
					}
				} 
				else {
					log.trace("JB Part '" + jbPart.getAbsoluteFileName() + "' has no content.");
					currentLocalPageNumber += jbPart.getPdfTotalPageCount();
				}

				totalPagesInPaginationGroup += jbPart.getPdfTotalPageCount();
			}

			if (totalPagesInPaginationGroup != pg.getTotalPageCount())
				throw new RuntimeException("Total page count for pagination group of " + pg.getTotalPageCount()
						+ " does not equal sum of page counts for all parts contained the pagination group of "
						+ totalPagesInPaginationGroup);
		}

		log.trace("Finished stamping JB (with page numbers, watermark, tracking header, "
		        + "privacy notice and warning message)...");

	}
    
    private boolean executeWarningStamp(boolean addWarningMsg, boolean addWorkFlowStatus, boolean addPrcpOnlyWarnings, JBookWorkFlowStatus jBookWorkFlowStatus){
        boolean executeWarningStamp = false;
        if (addWarningMsg){
            if (addWorkFlowStatus){
                if (addPrcpOnlyWarnings) {  // the warnings are only prcp
                    if (!jBookWorkFlowStatus.getCode().contains(JBBase.PREPRCP_STATUS)){ // status is not prcp so do the warning message
                        executeWarningStamp = true;
                    }
                }
                else { // warnings of various types
                    executeWarningStamp = true;
                }
            }
            else {
                executeWarningStamp = true;
            }
        }
        
        return executeWarningStamp;
    }
    
    private String getStampValue(JBookWorkFlowStatus jBookWorkFlowStatus){
        log.debug("getStampValue: " + jBookWorkFlowStatus);
        String stampValue = " ";
        
        if (jBookWorkFlowStatus.getCode().contains(JBBase.DRAFT_STATUS)){
         // stamp Draft
            setRfr(jBookWorkFlowStatus.getProcess());
            setRfrType(jBookWorkFlowStatus.getType());
            stampValue = BudgesContext.getConfigService().getJbDraftStamp();
        }
        else if (jBookWorkFlowStatus.getCode().contains(JBBase.PREPRCP_STATUS)){
            // stamp Pre-Prcp
            setRfr(jBookWorkFlowStatus.getProcess());
            setRfrType(jBookWorkFlowStatus.getType());
            if (isRfr()){
                stampValue = BudgesContext.getConfigService().getJbPrePRCPStamp();
            }
        }
        else if (jBookWorkFlowStatus.getCode().contains(JBBase.REVIEW_STATUS)){
            // stamp RFR
            setRfr(jBookWorkFlowStatus.getProcess());
            setRfrType(jBookWorkFlowStatus.getType());
            if (isRfr()){
                stampValue = BudgesContext.getConfigService().getJbReviewStamp();
            }
        }
        else if (jBookWorkFlowStatus.getCode().contains(JBBase.FINAL_STATUS)){
            // no stamp here, final book
            setRfr(jBookWorkFlowStatus.getProcess());
            setRfrType(jBookWorkFlowStatus.getType());
            stampValue = JBBase.FINAL_STAMP;
        }
        
        return stampValue;
    }

	protected void stampPageWithPageNumber(int pageNumber, PaginationGroup pg, PdfContentByte pdfOverContentByte,
			Rectangle pageSizeRectangle) {
		// Stamp the current page with its overall page #
		pdfOverContentByte.beginText();
		pdfOverContentByte.setFontAndSize(XmlUtil.getBaseFont(), Constants.PDF_STAMPING_NORMAL_FONT_SIZE);
		String pageNumberText = null;

		if (Constants.JBPageNumberingStyle.ARABIC_NUMERALS.equals(pg.getPageNumberingStyle()))
			pageNumberText = String.valueOf(pageNumber);
		else if (Constants.JBPageNumberingStyle.ROMAN_NUMERALS.equals(pg.getPageNumberingStyle()))
			pageNumberText = RomanNumberFactory.getLowerCaseString(pageNumber);

		pageNumberText = Util.addPrefix(getPageNumberPrefix(), pageNumberText);

		// Draw the rectangle around the page #
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, pageNumberText,
				pageSizeRectangle.getWidth() - 25, 30, 0);
		pdfOverContentByte.endText();
		pdfOverContentByte.setLineWidth(1f);
		pdfOverContentByte.rectangle(pageSizeRectangle.getWidth() - 118, 27, 100, 13);
		pdfOverContentByte.stroke();
	}

	protected void stampPageWithWarningMessage(PdfContentByte pdfOverContentByte, Rectangle pageSizeRectangle, String workFlowStatus) {
		String warningMessage = null;
		if (null == workFlowStatus) {
			warningMessage = BudgesContext.getConfigService().getJbWarningStamp(); 
																					
			if (StringUtils.isEmpty(warningMessage)) {
				warningMessage = Constants.PDF_INACCURATE_DATA_WARNING_MESSAGE;
			}
		} 
		else {
		    warningMessage = workFlowStatus;
		}

		pdfOverContentByte.beginText();
		pdfOverContentByte.setFontAndSize(XmlUtil.getBaseFontItalics(), Constants.PDF_STAMPING_NORMAL_FONT_SIZE);

		float warningMessageWidth = XmlUtil.getBaseFontItalics().getWidthPoint(warningMessage,
				Constants.PDF_STAMPING_NORMAL_FONT_SIZE);
		float verticalOffset = BudgesContext.getConfigService().getJbWarningStampVerticalPageOffset();
		float horizontalOffset = BudgesContext.getConfigService().getJbWarningStampHorizontalPageOffset();
		// top left
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, warningMessage,
				warningMessageWidth + horizontalOffset, pageSizeRectangle.getHeight() - horizontalOffset, 0);
		// bottom left
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, warningMessage,
				warningMessageWidth + horizontalOffset, verticalOffset, 0);
		// top right
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, warningMessage,
				pageSizeRectangle.getWidth() - horizontalOffset, pageSizeRectangle.getHeight() - horizontalOffset, 0);
		// bottom right
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, warningMessage,
				pageSizeRectangle.getWidth() - horizontalOffset, verticalOffset, 0);
		pdfOverContentByte.endText();
	}

	protected void stampPageWithPrivacyNotice(PdfContentByte pdfOverContentByte, Rectangle pageSizeRectangle) {
		pdfOverContentByte.beginText();
		pdfOverContentByte.setFontAndSize(XmlUtil.getBaseFontItalics(), Constants.PDF_STAMPING_NORMAL_FONT_SIZE);
		String privacyMessage = null;
		if (Constants.BUDGET_CYCLE_PB.equals(budgetCycle) || Constants.BUDGET_CYCLE_PB_AMENDED.equals(budgetCycle)
				|| Constants.BUDGET_CYCLE_PB_SUPPLEMENTAL.equals(budgetCycle))
			privacyMessage = Constants.PDF_PRIVATE_NOTICE_MESSAGE_PB;
		else
			privacyMessage = Constants.PDF_PRIVATE_NOTICE_MESSAGE_BES;
		XmlUtil.getBaseFontItalics().getWidthPoint(privacyMessage, Constants.PDF_STAMPING_NORMAL_FONT_SIZE);
		pdfOverContentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, privacyMessage,
				pageSizeRectangle.getWidth() - 18, 43, 0);
		pdfOverContentByte.endText();
	}

	protected boolean showWarningMessage(PaginationGroup pg) {
		return !serviceAgency.isSuppressPdfWarning() && pg.isWarningMessageAllowed() && (hasErrors || hasWarnings);
	}
	
	protected boolean showPrePrcpMessage(PaginationGroup pg) {
	    return onlyPrcpWarnings;
	}
	
	protected void updatePdfTotalPageCount() {
		if (pgList != null) {
			for (PaginationGroup pg : pgList){
				pdfTotalPageCount += pg.getTotalPageCount();
			}
		}
	}

	protected JBPart getBlankPage() throws IOException, DocumentException, SQLException {
	    
	    //CXE-6740 don't generate another blank page when were are rearranging supplemental docs.
	    if (getDocAssemblyOptions().isPositionAttachmentsAfterExhibits()) {
	        log.trace("getBlankPage: returning null");
	        return null;
	    }
	    
		if (blankPage == null) {
			blankPage = new JBBlankPage();
			createPartPdf(blankPage, null);
			log.trace("getBlankPage: returning new blankPage");
			return blankPage;
		} else {
		    log.trace("getBlankPage: returning new blankPage instance");
			return blankPage.newInstance();
		}
	}

	protected void createCoverPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		coverDoc.setServiceAgency(serviceAgency);
		createPartPdf(coverDoc, pg);
	}

	protected void createPeTocByBa(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		if (peTocByBa == null) {
			peTocByBa = new JBPeToc(FileSetting.PE_TOC_BY_BA, titlePrefix);
		}
		peTocByBa.setPageNumberKvpList(r2PageNumberKvpList);
		createPartPdf(peTocByBa, pg);
	}

	protected void createPeTocByTitle(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		if (peTocByTitle == null) {
			peTocByTitle = new JBPeToc(FileSetting.PE_TOC_BY_TITLE, titlePrefix);
		}
		peTocByTitle.setPageNumberKvpList(r2PageNumberKvpList);
		createPartPdf(peTocByTitle, pg);
	}

	protected void createR1SummaryPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		r1Summary = new R1Summary(titlePrefix);
		createPartPdf(r1Summary, pg);
	}

	protected void createR1Pdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		r1 = new R1(titlePrefix);
		createPartPdf(r1, pg);
	}

	protected void createP1Pdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		p1 = new P1(titlePrefix);
		createPartPdf(p1, pg);
	}

	protected void createP1mPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		p1m = new P1M(titlePrefix);
		createPartPdf(p1m, pg);
	}

	protected void createR1cPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		r1c = new R1C(titlePrefix);
		createPartPdf(r1c, pg);
	}

	protected void createR1dPdf(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		r1d = new R1D(titlePrefix);
		createPartPdf(r1d, pg);
	}

	protected void createLiTocByBa(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		if (liTocByBa == null) {
			liTocByBa = new JBLiToc(FileSetting.LI_TOC_BY_BA, titlePrefix);
		}
		liTocByBa.setPageNumberKvpList(p40PageNumberKvpList);
		createPartPdf(liTocByBa, pg);
	}

	protected void createLiTocByTitle(PaginationGroup pg) throws IOException, DocumentException, SQLException {
		if (liTocByTitle == null) {
			liTocByTitle = new JBLiToc(FileSetting.LI_TOC_BY_TITLE, titlePrefix);
		}
		liTocByTitle.setPageNumberKvpList(p40PageNumberKvpList);
		createPartPdf(liTocByTitle, pg);
	}

	protected FormattingResults createPartPdf(JBPart jbPart) throws IOException, DocumentException, SQLException {
		if (docCreationParams.getBudgetCycle() == null)
			docCreationParams.setBudgetCycle(budgetCycle);

		if (docCreationParams.getBudgetYear() == null)
			docCreationParams.setBudgetYear(budgetYear);

		jbPart.setPartIndex(partIndex);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(docAssemblyOptions);
		// Only either xmlFile or xmlData will be used as the xml source
		jbPart.setXmlFile(xmlFile);
		jbPart.setXmlData(xmlData);
		FormattingResults fr = jbPart.createPdf(); 
		return fr;
	}

	protected FormattingResults createPartPdf(JBPart jbPart, PaginationGroup pg) throws IOException, DocumentException, SQLException {
		FormattingResults fr = createPartPdf(jbPart);
		if (pg == null) {
			if (jbPart.getPdfStartPage() == 0)
				jbPart.setPdfStartPage(1);
		} else {
			pg.addJbPart(jbPart);
		}
		return fr;
	}

	protected void prepareUserSuppliedDoc(JBPart jbPart, PaginationGroup pg)
			throws IOException, DocumentException, SQLException {
		if (jbPart != null) {
			pg.addJbPart(jbPart);
			if (docAssemblyOptions.isForceEvenPages() && jbPart.pdfHasOddPages()) {
				JBPart blankPage = getBlankPage();
				pg.addJbPart(blankPage);
			}
		}
	}

	protected void prepareUserSuppliedDoc(List<? extends JBPart> jbPartList, PaginationGroup pg)
			throws IOException, DocumentException, SQLException {
		if (jbPartList != null) {
			for (JBPart jbPart : jbPartList) {
				prepareUserSuppliedDoc(jbPart, pg);
			}
		}
	}

	public EmbedableFile creatEmbedableR1DExcel() throws IOException {
		JBPart jbPart = creatR1DExcel();
		EmbedableFile embedableR1dExcel = new DefaultEmbedableFile(jbPart, jbPart.getAbsoluteFileName());
		return embedableR1dExcel;
	}

	protected JBPart creatR1DExcel() throws IOException {
		R1D jbPart = new R1D(titlePrefix);
		jbPart.setPartIndex(partIndex);
		DocumentCreationParams docCreationParams = new DocumentCreationParams();

		docCreationParams.setBudgetYear(budgetYear);
		docCreationParams.setBudgetCycle(budgetCycle);
		docCreationParams.setSubmissionDate(submissionDate);
		docCreationParams.setDocToGenerate(jbPart.getFileSetting().getFileNamePrefix());
		docCreationParams.setServiceAgencyName(serviceAgency.getName());
		docCreationParams.setBudgetArea(getBudgetArea());

		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(null);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setXmlFile(xmlFile);
		jbPart.setContentType(BudgesContentType.EXCEL);
		jbPart.createExcel();

		return jbPart;
	}

	public EmbedableFile creatEmbedableP1DExcel() throws IOException {
		JBPart jbPart = creatP1DExcel();
		EmbedableFile embedableP1dExcel = new DefaultEmbedableFile(jbPart, jbPart.getAbsoluteFileName());
		return embedableP1dExcel;
	}

	protected JBPart creatP1DExcel() throws IOException {
		log.info("Creating P1D Excel...");
		P1D jbPart = new P1D(titlePrefix);
		jbPart.setPartIndex(partIndex);
		DocumentCreationParams docCreationParams = new DocumentCreationParams();

		docCreationParams.setBudgetYear(budgetYear);
		docCreationParams.setBudgetCycle(budgetCycle);
		docCreationParams.setSubmissionDate(submissionDate);
		docCreationParams.setDocToGenerate(jbPart.getFileSetting().getFileNamePrefix());
		docCreationParams.setServiceAgencyName(serviceAgency.getName());
		docCreationParams.setBudgetArea(getBudgetArea());

		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(null);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setXmlFile(xmlFile);
		jbPart.setContentType(BudgesContentType.EXCEL);
		jbPart.createExcel();

		return jbPart;
	}

	public EmbedableFile createEmbedableP21Wallchart() throws IOException {
		JBPart jbPart = createP21Wallchart();
		return new DefaultEmbedableFile(jbPart, jbPart.getAbsoluteFileName());
	}

	public EmbedableFile createEmbedableSDReportExcel() throws IOException {
		JBPart jbPart = createSDReportExcel();
		EmbedableFile embedableSDReportExcel = new DefaultEmbedableFile(jbPart, jbPart.getAbsoluteFileName());
		return embedableSDReportExcel;
	}

	public EmbedableFile createEmbedableR3Overview() throws IOException {
		JBPart jbPart = createR3Overview();
		return new DefaultEmbedableFile(jbPart, jbPart.getAbsoluteFileName());
	}

	protected JBPart createP21Wallchart() throws IOException {
		P21WallChart jbPart = new P21WallChart(titlePrefix);
		jbPart.setPartIndex(partIndex);
		DocumentCreationParams docCreationParams = new DocumentCreationParams();

		docCreationParams.setBudgetYear(budgetYear);
		docCreationParams.setBudgetCycle(budgetCycle);
		docCreationParams.setSubmissionDate(submissionDate);
		docCreationParams.setDocToGenerate(jbPart.getFileSetting().getFileNamePrefix());
		docCreationParams.setServiceAgencyName(serviceAgency.getName());
		docCreationParams.setBudgetArea(getBudgetArea());

		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(null);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setXmlFile(xmlFile);
		jbPart.setContentType(BudgesContentType.EXCEL);
		jbPart.createExcel();

		return jbPart;
	}

	protected JBPart createSDReportExcel() throws IOException {
		log.info("Creating Secondary Distribution Report Excel...");
		SDReport jbPart = new SDReport(titlePrefix);
		jbPart.setPartIndex(partIndex);
		DocumentCreationParams docCreationParams = new DocumentCreationParams();

		docCreationParams.setBudgetYear(budgetYear);
		docCreationParams.setBudgetCycle(budgetCycle);
		docCreationParams.setSubmissionDate(submissionDate);
		docCreationParams.setDocToGenerate(jbPart.getFileSetting().getFileNamePrefix());
		docCreationParams.setServiceAgencyName(serviceAgency.getName());
		docCreationParams.setBudgetArea(getBudgetArea());

		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(null);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setXmlFile(xmlFile);
		jbPart.setContentType(BudgesContentType.EXCEL);
		jbPart.createExcel();

		return jbPart;
	}

	protected JBPart createR3Overview() throws IOException {
		R3Overview jbPart = new R3Overview(titlePrefix);
		jbPart.setPartIndex(partIndex);
		DocumentCreationParams docCreationParams = new DocumentCreationParams();

		docCreationParams.setBudgetYear(budgetYear);
		docCreationParams.setBudgetCycle(budgetCycle);
		docCreationParams.setSubmissionDate(submissionDate);
		docCreationParams.setDocToGenerate(jbPart.getFileSetting().getFileNamePrefix());
		docCreationParams.setServiceAgencyName(serviceAgency.getName());
		docCreationParams.setBudgetArea(getBudgetArea());

		jbPart.setDocCreationParams(docCreationParams);
		jbPart.setDocAssemblyOptions(null);
		jbPart.setWorkingFolder(workingFolder);
		jbPart.setXmlFile(xmlFile);
		jbPart.setContentType(BudgesContentType.EXCEL);
		jbPart.createExcel();

		return jbPart;
	}

	// Use this to see if the Volume Number contains any letters or any other
	// fun things that might require you to find if a string contains any letters.
	public static boolean containsLetter(String s) {
		if (s == null)
			return false;
		boolean letterFound = false;
		for (int i = 0; !letterFound && i < s.length(); i++) {
			letterFound = letterFound || Character.isLetter(s.charAt(i));
		}
		return letterFound;
	}

	public String getTargetSchemaVersion() {
		return targetSchemaVersion;
	}

	public void setTargetSchemaVersion(String targetSchemaVersion) {
		this.targetSchemaVersion = targetSchemaVersion;
	}

	public String getBudgetCycle() {
		return budgetCycle;
	}

	public void setBudgetCycle(String budgetCycle) {
		this.budgetCycle = budgetCycle;
	}

	public Integer getBudgetYear() {
		return budgetYear;
	}

	public void setBudgetYear(Integer budgetYear) {
		this.budgetYear = budgetYear;
	}

	public String getBudgetCycleAndYear() {
		return budgetCycle + " " + budgetYear;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

    //JiBX_JibxBindingMungeAdapter is providing the submissionDate.
    //overriding this value from the SubmissionDateProcessor functionality per CXE-6070.
	public void setSubmissionDate(Date submissionDate) throws SubmissionDateProcessorException{
	    try {
	        this.submissionDate = SubmissionDateProcessorFactory.getSubmissionDateProcessor().getDate(getBudgetCycleAndYear());
	    }
	    catch(SubmissionDateProcessorException sdpe){
	        log.error("failure to process submissionDate message: " +sdpe.getMessage());
	        //need to get this set to satisfy JiBx roundtrip shcema validation.
	        this.submissionDate = submissionDate;
	        
	        sendSettingSubmissionDateFailedEmail();
	    }
	}
	
	private void sendSettingSubmissionDateFailedEmail() {
		try {
			BudgesContext.getEmailUtil().sendSystemEmail(SETTING_SUBMISSION_DATE_ERROR_EMAIL_SUBJECT, 
					SETTING_SUBMISSION_DATE_ERROR_EMAIL_BODY);
		} catch (EmailException e) {
			log.error(e);
		}
	}

	public ServiceAgency getServiceAgency() {
		return serviceAgency;
	}

	public void setServiceAgency(ServiceAgency serviceAgency) {
		this.serviceAgency = serviceAgency;
	}

	public IAppropriation getAppropriation() {
		return appropriation;
	}

	public void setAppropriation(IAppropriation appropriation) {
		this.appropriation = appropriation;
	}

	public String getBuiltinLogoFileName() {
		return builtinLogoFileName;
	}

	public void setBuiltinLogoFileName(String builtinLogoFileName) {
		this.builtinLogoFileName = builtinLogoFileName;
	}

	public JBCover getCoverDoc() {
		return coverDoc;
	}

	public void setCoverDoc(JBCover coverDoc) {
		this.coverDoc = coverDoc;
	}

	public JBCostDoc getCostDoc() { //CXE-6606
	    return costDoc;
	}
	
	public void setCostDoc(JBCostDoc costDoc) { //CXE-6606
	    this.costDoc = costDoc;
	}
	
	public JBIntroductionDoc getIntroductionDoc() {
		return introductionDoc;
	}

	public void setIntroductionDoc(JBIntroductionDoc introductionDoc) {
		this.introductionDoc = introductionDoc;
	}

	public BaseToc getToc() {
		return toc;
	}

	public void setToc(BaseToc toc) {
		this.toc = toc;
	}

	public JBSummaryDoc getSummaryDoc() {
		return summaryDoc;
	}

	public void setSummaryDoc(JBSummaryDoc summaryDoc) {
		this.summaryDoc = summaryDoc;
	}

	public JBPeToc getPeTocByBa() {
		return peTocByBa;
	}

	public void setPeTocByBa(JBPeToc tocByBa) {
		this.peTocByBa = tocByBa;
	}

	public JBPeToc getPeTocByTitle() {
		return peTocByTitle;
	}

	public void setPeTocByTitle(JBPeToc tocByPe) {
		this.peTocByTitle = tocByPe;
	}

	public R1Summary getR1Summary() {
		return r1Summary;
	}

	public void setR1Summary(R1Summary summary) {
		r1Summary = summary;
	}

	public R1 getR1() {
		return r1;
	}

	public void setR1(R1 r1) {
		this.r1 = r1;
	}

	public R1C getR1c() {
		return r1c;
	}

	public void setR1c(R1C r1c) {
		this.r1c = r1c;
	}

	public R1D getR1d() {
		return r1d;
	}

	public void setR1d(R1D r1d) {
		this.r1d = r1d;
	}

	public JBSupplementalDocCollection getSupplementalDocCollection() {
		return supplementalDocCollection;
	}

	public void setSupplementalDocCollection(JBSupplementalDocCollection supplementalDocCollection) {
		this.supplementalDocCollection = supplementalDocCollection;
	}

	public JBUserR1Doc getUserR1Doc() {
		return userR1Doc;
	}

	public void setUserR1Doc(JBUserR1Doc userR1Doc) {
		this.userR1Doc = userR1Doc;
	}

	public JBAcronymDoc getAcronymDoc() {
		return acronymDoc;
	}

	public void setAcronymDoc(JBAcronymDoc acronymDoc) {
		this.acronymDoc = acronymDoc;
	}

	public List<KeyValuePair> getR2PageNumberKvpList() {
		return r2PageNumberKvpList;
	}

	public List<KeyValuePair> getP40PageNumberKvpList() {
		return p40PageNumberKvpList;
	}

	public R2ExhibitList getR2ExhibitList() {
		return r2ExhibitList;
	}

	public void setR2ExhibitList(R2ExhibitList exhibitList) {
		r2ExhibitList = exhibitList;
	}

	public LineItemList getLineItemList() {
		return lineItemList;
	}

	public void setLineItemList(LineItemList lineItemList) {
		this.lineItemList = lineItemList;
	}

	public MultiYearProcurementList getMultiYearProcurementList() {
		return multiYearProcurementList;
	}

	public void setMultiYearProcurementList(MultiYearProcurementList multiYearProcurementList) {
		this.multiYearProcurementList = multiYearProcurementList;
	}

	public int getPdfPageOffset() {
		return pdfPageOffset;
	}

	public void setPdfPageOffset(int pdfPageOffset) {
		this.pdfPageOffset = pdfPageOffset;
	}

	public Constants.JBPageNumberingModel getJbPageNumberingModel() {
		return jbPageNumberingModel;
	}

	public void setJbPageNumberingModel(Constants.JBPageNumberingModel jbPageNumberingModel) {
		this.jbPageNumberingModel = jbPageNumberingModel;
	}

	public String getTitlePrefix() {
		return titlePrefix;
	}

	public void setTitlePrefix(String titlePrefix) {
		this.titlePrefix = titlePrefix;
	}

	public JBUserP1Doc getUserP1Doc() {
		return userP1Doc;
	}

	public void setUserP1Doc(JBUserP1Doc userP1Doc) {
		this.userP1Doc = userP1Doc;
	}

	public JBLiToc getLiTocByBa() {
		return liTocByBa;
	}

	public void setLiTocByBa(JBLiToc liTocByBa) {
		this.liTocByBa = liTocByBa;
	}

	public JBLiToc getLiTocByTitle() {
		return liTocByTitle;
	}

	public void setLiTocByTitle(JBLiToc liTocByTitle) {
		this.liTocByTitle = liTocByTitle;
	}

	public P1 getP1() {
		return p1;
	}

	public void setP1(P1 p1) {
		this.p1 = p1;
	}

	public P1M getP1m() {
		return p1m;
	}

	public void setP1m(P1M p1m) {
		this.p1m = p1m;
	}

	public boolean isRfr() {
		return rfr;
	}

	private void setRfr(boolean rfr) {
		this.rfr = rfr;
	}

    public Integer getRfrType() {
        return rfrType;
    }

    private void setRfrType(Integer rfrType) {
        this.rfrType = rfrType;
    }
    
}
