/*
 * $Id$
 */
package mil.dtic.cbes.output;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R4Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.ImageUtil;
import mil.dtic.utility.UserPeUtils;

public class R2Importer
{
  private static final Logger log = CbesLogFactory.getLog(R2Importer.class);

  protected UserCredentials userCredentials;
  protected ImportOptions importOptions;
  private String referencedFileName;

  public R2Importer(UserCredentials userCredentials, ImportOptions importOptions)
  {
    this.userCredentials = userCredentials;
    this.importOptions = importOptions;
  }


  public boolean prepareForImport(R2ImportItem importItem)
  {
    ProgramElement pe = importItem.getProgramElement();

    if (importItem.isHasWarnings())
      pe.setSubmissionStatus(PeSubmissionFlag.INVALID);
    else
      pe.setSubmissionStatus(PeSubmissionFlag.VALID);

    pe.setInitialSource(Constants.PE_INITIAL_SOURCE_XML);
    pe.setState(Constants.PE_STATE_ACTIVE);
    pe.setEditable(Constants.PE_EDITABLE_TRUE);
    if (StringUtils.isNotEmpty(importOptions.getUserDefinedTag()))
      pe.setUserDefinedTag(importOptions.getUserDefinedTag());

    // Check to see whether the ProgramElement already exists in the database
    List<ProgramElement> dbPeList = BudgesContext.getProgramElementDAO().findByBusinessIdIncludingApp(pe);
    if (CollectionUtils.isNotEmpty(dbPeList))
    {
      logPeError(pe, importItem, "already exists in the database");
      return false;
    }
    // Create privilige?
    if (!userCredentials.createPeAllowed())
    {
      logPeError(pe, importItem, "could not be created because you do not have create permission");
      return false;
    }
    // can't create PEs in another agency
    ServiceAgency desiredAgency = pe.getServiceAgency();
    if (!userCredentials.getUserInfo().getAvailableRdteAgencies().contains(desiredAgency))
    {
       logPeError(pe, importItem, "is not under your agency");
       return false;
    }
    
    
    if(!isPENumberValid(pe)) {
    	 logPeError(pe, importItem, "has a PE number that contains invalid characters");
    	return false;
    }

    return true;
  }


  public boolean save(R2ImportItem importItem) throws IOException, SQLException
  {
    // Every save has it's own transaction.
    // One big transaction might time out if the import takes awhile

    ProgramElement pe = importItem.getProgramElement();

    //Special Project cannot be null - set it to default value of zero (0)
    if(pe.getProjects() != null) {
      for (Project project : pe.getProjects())
      {
        if (project.getSpecialProject() == null)
      	  project.setSpecialProject(Integer.valueOf(0));
      }
    }

    try
    {
      loadBinaryData(pe);
      BudgesContext.getProgramElementDAO().save(pe);
      UserPeUtils.grantPermsForNewPe(userCredentials, pe);
    }
    catch (NullPointerException ex)
    {
      log.error("Failed to save PE to database during import, pe # " + pe.getNumber(), ex);
      logError(null, importItem, "The File \"" +  referencedFileName + "\" referenced in the XML was not attached.");
      return false;
    }
    catch (RuntimeException ex)
    {
      log.error("Failed to save PE to database during import, pe # " + pe.getNumber(), ex);
      logError(null, importItem, "System Error occurred while saving to the database. It's probably a bug.");
      return false;
    }

    return true;
  }


  private void loadBinaryData(ProgramElement pe) throws IOException, SQLException
  {
    if(pe.getProjects() != null) {
      for (Project project : pe.getProjects())
      {
        R4Exhibit r4Exhibit = project.getR4Exhibit();
        if (project.getR4Exhibit() != null && CollectionUtils.isNotEmpty(r4Exhibit.getScheduleProfiles()))
        {
          for (ScheduleProfile sp : r4Exhibit.getScheduleProfiles())
          {
            referencedFileName = r4Exhibit.getScheduleProfile().getImageFileName();
            File imageFile = new File(sp.getTmpImagePath());
            // TODO this is not memory efficient, see if we can stream the data in
            byte[] data = FileUtil.getByteArrayFromFile(imageFile);
            sp.setImageData(new SerialBlob(data));
            sp.setThumbnailData(new SerialBlob(ImageUtil.getPngThumbnail(new ByteArrayInputStream(data), sp.getImageFileName())));
            String unpathedFilename = FilenameUtils.getName(sp.getImageFileName());
            sp.setImageFileName(unpathedFilename);
          }
        }
      }
    }
  }


  private void logPeError(ProgramElement pe, R2ImportItem importItem, String partialMessage)
  {
    logError("ProgramElementNumber", importItem, "Program Element with ProgramElementNumber='" + pe.getNumber() + "', BudgetCycle='" + pe.getBudgetCycle() + "', BudgetYear='" + pe.getBudgetYear() + "' and Budget Activity='" + pe.getBudgetActivity() + "' " + partialMessage + ".");
  }
  
  private boolean isPESuffixValid(ProgramElement pe) {
	  boolean result = true;
	  
	  String suffix = pe.getNumber().substring(7).toUpperCase();
	  
	  if(!pe.getServiceAgency().getPESuffixesAsStrings().contains(suffix)) {
		  result = false;
	  }
	  
	  return result;
  }
  
  private boolean isPENumberValid(ProgramElement pe) {
	  boolean result = true;
	  Pattern peRegex = Pattern.compile("^[0-9A-Za-z\\(\\)\\[\\]\\-\\_\\#\\@\\:\\.\\ ]*$", Pattern.CASE_INSENSITIVE);
	  Matcher matcher = peRegex.matcher(pe.getNumber());

	  if (!matcher.find()) {
		  result = false;
	  }
	  
	  return result;
  }


  public void logError(String elementName, R2ImportItem importItem, String message)
  {
    R2ImportMessage errorMessage = new R2ImportMessage(importItem.getProgramElement().getNumber(), importItem.getXmlIndex(), message);
    importItem.getErrorList().add(errorMessage.toString());
  }
}
