/*
 * $Id$
 */
package mil.dtic.cbes.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.ls.LSResourceResolver;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;

/**
 * @author EDaniels
 *
 */
public class XmlSchemaValidator extends XmlValidatorImpl
{
  private static final Logger log = CbesLogFactory.getLog(XmlSchemaValidator.class);
  private String schemaName;
  XmlSAXContentHandler xmlContentHandler;


  public XmlSchemaValidator(InputStream xmlInputStream, String schemaName)
  {
    super(xmlInputStream);
    this.schemaName = schemaName;
  }


  public XmlSchemaValidator(File xmlFile, String schemaName)
  {
    super(xmlFile);
    this.schemaName = schemaName;
  }

  public XmlSchemaValidator(String xmlString, String schemaName)
  {
    super(xmlString);
    this.schemaName = schemaName;
  }

      @Override
    public boolean validate(String organizationCode)
      {
          return validate(); // This apparently doesn't need an org?
      }

  /**
   *
   */
  public boolean validate()
  {
    LSResourceResolver schemaResourceResolver = BudgesContext.getBudgesXmlResourceResolverFactory().getSchemaResourceResolver();
    InputStream is = schemaResourceResolver.resolveResource(null, null, null, schemaName, null).getByteStream();
    StreamSource schemaSource = new StreamSource(is);
    SAXSource xmlSource = getInputXmlAsSAXSource();

    //Disable DTD to prevent XXE Processing Attack.
    //https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing
    try{
    xmlSource.getXMLReader().setFeature("http://xml.org/sax/features/external-general-entities", false);
    }
    catch (SAXNotRecognizedException e) {
      log.error(e);
  } catch (SAXNotSupportedException e) {
    log.error(e);
  } catch (NullPointerException npe){
    log.info(npe);
  }

    xmlContentHandler = new XmlSAXContentHandler();
    XmlSchemaValidationErrorHandler handler = validateSAX(schemaSource, xmlSource, xmlContentHandler, null);

    if (handler != null)
    {
      errorList.addAll(handler.getErrorList());
      warningList.addAll(handler.getWarningList());
      log.debug("\nXML Validation Errors: " + errorList + "\nXML Validation Warnings: " + warningList);
    }

    FileUtil.close(is);
    return !hasErrors();
  }


  /**
   * Overloaded method to allow for that passing in of specific paths to the xsls and xsds instead of using the default current ones.
   *
   * @param xsdPathList path to old schema to use
   * @param xslPathList path to old transforms to use
   * @return
   */
  public boolean validate(List<String> xsdPathList, List<String> xslPathList)
  {
    LSResourceResolver schemaResourceResolver = BudgesContext.getBudgesXmlResourceResolverFactory().getSchemaResourceResolver(xsdPathList, xslPathList);
    InputStream is = schemaResourceResolver.resolveResource(null, null, null, schemaName, null).getByteStream();
    StreamSource schemaSource = new StreamSource(is);
    SAXSource xmlSource = getInputXmlAsSAXSource();
    //Disable DTD to prevent XXE Processing Attack.
    //https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing
    try{
     xmlSource.getXMLReader().setFeature("http://xml.org/sax/features/external-general-entities", false);
    }
    catch (SAXNotRecognizedException e) {
      log.error(e);
  } catch (SAXNotSupportedException e) {
    log.error(e);
  } catch (NullPointerException npe){
    log.info(npe);
  }

    xmlContentHandler = new XmlSAXContentHandler();
    XmlSchemaValidationErrorHandler handler = validateSAX(schemaSource, xmlSource, xmlContentHandler, schemaResourceResolver);

    if (handler != null)
    {
      errorList.addAll(handler.getErrorList());
      warningList.addAll(handler.getWarningList());
      log.debug("\nXML Validation Errors: " + errorList + "\nXML Validation Warnings: " + warningList);
    }

    FileUtil.close(is);
    return !hasErrors();
  }

  protected XmlSchemaValidationErrorHandler validateSAX(Source schemaSource, SAXSource xmlSource, ContentHandler xmlContentHandler, LSResourceResolver schemaResolver)
  {
    log.info("Loading all schemas from " + BudgesContext.getBudgesXmlResourceResolverFactory().getXmlResourcesLoadFrom());

    XmlSchemaValidationErrorHandler handler = new XmlSchemaValidationErrorHandler();
    //HINT- hartj0000: XMCConstants may show as an error in Eclipse.  Fix: Configure Build Path -> Order and Export tab -> moved JRE to the top of the list.
    SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    
    if (schemaResolver==null){
      factory.setResourceResolver(BudgesContext.getBudgesXmlResourceResolverFactory().getSchemaResourceResolver());
    }
    else {
      factory.setResourceResolver(schemaResolver);
    }
    factory.setErrorHandler(handler);

    //Disable DTD to prevent XXE Processing Attack.
    //https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing
    try
    {
      Schema schema = factory.newSchema(schemaSource);
      try{
        xmlSource.getXMLReader().setFeature("http://xml.org/sax/features/external-general-entities", false);
      }
      catch (NullPointerException npe){
        log.info(npe);
      }
      Validator validator = schema.newValidator();
      validator.setErrorHandler(handler);
      validator.validate(xmlSource, new SAXResult(xmlContentHandler));
    }
    catch (SAXNotRecognizedException e) {
    log.error(e);
  } catch (SAXNotSupportedException e) {
    log.error(e);
  }
    catch (SAXException e)
    {
      // The error handler is already adding errors.  This duplicates some errors.
//      addError(e.getMessage());
    }
    catch (IOException e)
    {
      addErrorAndLog("Failed to validate r2 schema due to IOException.", e);
    }
    return handler;
  }


  protected void addErrorAndLog(String msg, Throwable t)
  {
    addError(msg);
    if (t == null)
      log.error(msg);
    else
      log.error(msg, t);
  }


  public String getSchemaName()
  {
    return schemaName;
  }


  public void setSchemaName(String schemaName)
  {
    this.schemaName = schemaName;
  }


  public String getRootNodeName()
  {
    if (xmlContentHandler != null)
      return xmlContentHandler.getRootNodeName();
    return null;
  }

  public boolean isMasterJustificationBookXml()
  {
    if (xmlContentHandler != null)
      return Constants.MJB_ROOT_LOCAL_NAME.equals(xmlContentHandler.getRootNodeName());
    return false;
  }

  public boolean isJustificationBookXml()
  {
    if (xmlContentHandler != null)
      return Constants.JB_ROOT_LOCAL_NAME.equals(xmlContentHandler.getRootNodeName());
    return false;
  }

  public boolean isR2ExhibitListXml()
  {
    if (xmlContentHandler != null)
      return (Constants.R2_ROOT_LOCAL_NAME.equals(xmlContentHandler.getRootNodeName())
          ||  Constants.R2_ROOT_LOCAL_NAME_LEGACY.equals(xmlContentHandler.getRootNodeName()));
    return false;
  }

  public boolean isP40ExhibitListXml()
  {
    if (xmlContentHandler != null)
      return Constants.P40_ROOT_LOCAL_NAME.equals(xmlContentHandler.getRootNodeName());
    return false;
  }


}
