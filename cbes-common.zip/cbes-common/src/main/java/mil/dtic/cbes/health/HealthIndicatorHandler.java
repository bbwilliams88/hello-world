package mil.dtic.cbes.health;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.Random;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.exceptions.InvalidFileTypeException;
import mil.dtic.cbes.service.VirusScanService;
import mil.dtic.cbes.submissions.ValueObjects.HealthCheck;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.CmdLineUtil;
import netscape.ldap.LDAPException;

public class HealthIndicatorHandler {

  private static final Logger log = CbesLogFactory.getLog(HealthIndicatorHandler.class);

  private HealthIndicatorList hil;
  private static final String HIH_PREFIX = "INFO_";
  private static final String EXCEPTION_PREFIX = ",e=";
  private static final String EXCEPTION_FREE = "none"; // e.g. " There were none."
  private static final String FMT_STR = "%.3f";
  private static final String TMP_DIR_PROPERTY = "java.io.tmpdir";

    public HealthIndicatorHandler(HealthIndicatorList hilProvided) {
      hil = hilProvided;
    }

    private float reliabilityRefined(float rel, boolean b) {
      float complementOfRel = 1.0f - rel;
      if (b) {
        complementOfRel = 1.0f / ((1.0f / complementOfRel) + 1.0f);
      } else {
        complementOfRel = (0.5f + complementOfRel) / 2.0f;
      }
      return 1.0f - complementOfRel;
    }

    private String composeReport(String methodTag, String reliabilityFormatted, String caught) {
      return methodTag + EXCEPTION_PREFIX + caught;
    }

    public void refreshAll() {
      Random jur = new SecureRandom();
      commandLineRMIRefresh(jur.nextFloat());
      dbRowReadRefresh(jur.nextFloat());
      dbRowUpdateRefresh(jur.nextFloat());
      diskSpaceRefresh(jur.nextFloat());
      partitionUploadReadRefresh(jur.nextFloat());
      partitionUploadWriteRefresh(jur.nextFloat());
      partitionSandboxReadRefresh(jur.nextFloat());
      partitionSandboxWriteRefresh(jur.nextFloat());
      partitionTmpReadRefresh(jur.nextFloat());
      partitionTmpWriteRefresh(jur.nextFloat());
      partitionIOReadRefresh(jur.nextFloat());
      partitionIOWriteRefresh(jur.nextFloat());
      virusGreenRefresh(jur.nextFloat());
      ldapReadRefresh(jur.nextFloat());
      overallRefresh(jur.nextFloat());
    }


    public float commandLineRMIRefresh(float weight) {
      String methodTag = "commandLineRMI";
      log.trace("methodTag: " + methodTag);
      String theCmd = "cmd.exe /c echo";
      String[] args = { HIH_PREFIX + methodTag };
      String caught = EXCEPTION_FREE;
      boolean success = false;
        success = CmdLineUtil.runCmd(theCmd, args);
        hil.setCommandLineRMIOK(success);
        float reliability = reliabilityRefined(hil.getCommandLineRMIReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setCommandLineRMITimestamp(new Date());
        return reliability;
    }

    public float dbRowReadRefresh(float weight) {
      String methodTag = "dbRowRead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      boolean success = false;
        success = true;
        hil.setDbRowReadOK(success);
        float reliability = reliabilityRefined(hil.getDbRowReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setDbRowReadTimestamp(new Date());
        return reliability;
    }

    public float dbRowUpdateRefresh(float weight) {
      String methodTag = "dbRowUpdate";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      boolean success = false;
        HealthCheck hc1 = new HealthCheck();
        hc1.setCreatedByUserId( "sample_created_by_user_id" );
        hc1.setModifiedByUserId( "sample_modified_by_user_id" );
        hc1.setDhcComment( "health_check" );
        hc1.setLastCheck( new Date() );
        hc1.setVersion( Integer.valueOf(1) );
        BudgesContext.getHealthCheckDAO().saveOrUpdate( hc1 );
        success = true;
        hil.setDbRowUpdateOK(success);
        float reliability = reliabilityRefined(hil.getDbRowUpdateReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setDbRowUpdateTimestamp(new Date());
        return reliability;
    }

    public float diskSpaceRefresh(float weight) {
      String methodTag = "diskSpace";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      String[] partitions = {  BudgesContext.getConfigService().getWorkingFolder(),
                    BudgesContext.getConfigService().getVscanSandboxFolder(),
                    System.getProperty(TMP_DIR_PROPERTY)
                  };
      File f;
      boolean successOnOne = false;
      boolean success = true;
        for (String par : partitions) {
          log.trace("par: " + par);
          f = new File(par);
          long us = f.getUsableSpace();
          log.trace("us: " + us);
          long ts = f.getTotalSpace();
          log.trace("ts: " + ts);
          if (us == 0L || ts == 0L) {
            successOnOne = false;
            log.trace("in 146");
          } else if (((1.0 * us) / (1.0 * ts)) < 0.1) { // ts is non-zero
            successOnOne = false;
            log.trace("in 149");
          } else {
            successOnOne = true;
            log.trace("in 152");
          }
          if (!successOnOne) {
            success = false;
            log.trace("in 156");
          }
        }
        hil.setDiskSpaceOK(success);
        float reliability = reliabilityRefined(hil.getDiskSpaceReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setDiskSpaceTimestamp(new Date());
        return reliability;
    }

    public float partitionUploadReadRefresh(float weight) {
      String methodTag = "partitionUploadRead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(BudgesContext.getConfigService().getWorkingFolder());
        success = f.canRead();
        hil.setPartitionUploadReadOK(success);
        float reliability = reliabilityRefined(hil.getPartitionUploadReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionUploadReadTimestamp(new Date());
        return reliability;
    }

    public float partitionUploadWriteRefresh(float weight) {
      String methodTag = "partitionUploadWrite";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(BudgesContext.getConfigService().getWorkingFolder());
        success = f.canWrite();
        hil.setPartitionUploadWriteOK(success);
        float reliability = reliabilityRefined(hil.getPartitionUploadWriteReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionUploadWriteTimestamp(new Date());
        return reliability;
    }

    public float partitionSandboxReadRefresh(float weight) {
      String methodTag = "partitionSandboxRead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(BudgesContext.getConfigService().getVscanSandboxFolder());
        log.trace("f: " + f);
        success = f.canRead();
        log.trace("success: " + success);
        hil.setPartitionSandboxReadOK(success);
        float reliability = reliabilityRefined(hil.getPartitionSandboxReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionSandboxReadTimestamp(new Date());
        return reliability;
    }

    public float partitionSandboxWriteRefresh(float weight) {
      String methodTag = "partitionSandboxWrite";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(BudgesContext.getConfigService().getVscanSandboxFolder());
        log.trace("f: " + f);
        success = f.canWrite();
        log.trace("success: " + success);
        hil.setPartitionSandboxWriteOK(success);
        float reliability = reliabilityRefined(hil.getPartitionSandboxWriteReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionSandboxWriteTimestamp(new Date());
        return reliability;
    }

    public float partitionTmpReadRefresh(float weight) {
      String methodTag = "partitionTmpRead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(System.getProperty(TMP_DIR_PROPERTY));
        success = f.canRead();
        hil.setPartitionTmpReadOK(success);
        float reliability = reliabilityRefined(hil.getPartitionTmpReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionTmpReadTimestamp(new Date());
        return reliability;
    }

    public float partitionTmpWriteRefresh(float weight) {
      String methodTag = "partitionTmpWrite";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(System.getProperty(TMP_DIR_PROPERTY));
        success = f.canWrite();
        hil.setPartitionTmpWriteOK(success);
        float reliability = reliabilityRefined(hil.getPartitionTmpWriteReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionTmpWriteTimestamp(new Date());
        return reliability;
    }


    public float partitionIOReadRefresh(float weight) {
      String methodTag = "partitionIORead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(System.getProperty(TMP_DIR_PROPERTY));
        success = f.canRead();
        hil.setPartitionIOReadOK(success);
        float reliability = reliabilityRefined(hil.getPartitionIOReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionIOReadTimestamp(new Date());
        return reliability;
    }

    public float partitionIOWriteRefresh(float weight) {
      String methodTag = "partitionIOWrite";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      File f;
      boolean success = false;
        f = new File(System.getProperty(TMP_DIR_PROPERTY));
        success = f.canWrite();
        hil.setPartitionIOWriteOK(success);
        float reliability = reliabilityRefined(hil.getPartitionIOWriteReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setPartitionIOWriteTimestamp(new Date());
        return reliability;
    }

    public float virusGreenRefresh(float weight) {
      String methodTag = "virusGreen";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      boolean success = false;
      try {
        AppDefaults appDefaults = BudgesContext.getAppDefaults();
        VirusScanService vss = new VirusScanService(appDefaults);
        File sandboxFile = new File(BudgesContext.getConfigService().getVscanSandboxFolder() + "/health_indicator_handler_virus_test.txt");
        File workingFile = new File(BudgesContext.getConfigService().getWorkingFolder() + "/health_indicator_handler_virus_test.txt");


        // delete the file first, normally the file should be moved by the virus
        // scanner service but sometimes there is a problem with that (see bug 6478)
        if (sandboxFile.exists())
        {
          log.error("Virus scan test file for health check already exists: " + sandboxFile);
          log.error("Successfully deleted virus scan test file: " + sandboxFile.delete());
        }
        if(workingFile.exists())
        {
          log.error("Virus scan test file for health check already exists: " + workingFile);
          log.error("Successfully deleted virus scan test file: " + workingFile.delete());
        }

        if (sandboxFile.createNewFile()) {
          BudgesFile dirToScan = new BudgesFile(
              null,
              new File(BudgesContext.getConfigService().getWorkingFolder() + "/health_indicator_handler_virus_test.txt"),
              new File(BudgesContext.getConfigService().getVscanSandboxFolder() + "/health_indicator_handler_virus_test.txt"),
              null);

          vss.virusScan(dirToScan);
          success = !(vss.virusFound() || vss.hasErrors());
        } else {
          success = false;
          log.error("create new file failed");
        }
      } catch (InvalidFileTypeException e) {
          caught = e.toString();
          log.error("caught: " + caught,e);
          success = false;
      } catch (IOException e) {
        caught = e.toString();
        log.error("caught: " + caught,e);
        success = false;
      }
        hil.setVirusGreenOK(success);
        float reliability = reliabilityRefined(hil.getVirusGreenReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setVirusGreenTimestamp(new Date());
        return reliability;
    }

    public float ldapReadRefresh(float weight) {
      String methodTag = "ldapRead";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      boolean success = false;
      try {
        String[] allAdminIds = BudgesContext.getLdapDAO().getAllAdminUserIds();
        success = (0 < allAdminIds.length);
      } catch (LDAPException e) {
        caught = e.toString();
        log.error("caught: " + caught,e);
        success = false;
      }
        hil.setLdapReadOK(success);
        float reliability = reliabilityRefined(hil.getLdapReadReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setLdapReadTimestamp(new Date());
        return reliability;
    }

    public float overallRefresh(float weight) {
      String methodTag = "overall";
      log.trace("methodTag: " + methodTag);
      String caught = EXCEPTION_FREE;
      boolean success = false;
        success = (
            hil.getDbRowReadOK() &&
            hil.getDbRowUpdateOK() &&
            hil.getCommandLineRMIOK() &&
            hil.getDiskSpaceOK() &&
            hil.getPartitionUploadReadOK() &&
            hil.getPartitionUploadWriteOK() &&
            hil.getPartitionSandboxReadOK() &&
            hil.getPartitionSandboxWriteOK() &&
            hil.getPartitionTmpReadOK() &&
            hil.getPartitionTmpWriteOK() &&
            hil.getPartitionIOReadOK() &&
            hil.getPartitionIOWriteOK() &&
            hil.getVirusGreenOK() &&
            hil.getLdapReadOK()
        );
        hil.setOverallOK(success);
        float reliability = reliabilityRefined(hil.getOverallReliability(), success);
        String reliabilityFormatted = String.format(FMT_STR, reliability);
      String theReport = composeReport(methodTag, reliabilityFormatted, caught);
        log.trace("theReport: " + theReport);
        hil.setOverallTimestamp(new Date());
        return reliability;
    }

}
