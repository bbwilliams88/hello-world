package mil.dtic.cbes.sso.siteminder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.ldap.NetLDAP;
import mil.dtic.utility.BudgesContext;
import netscape.ldap.LDAPException;

public class SiteminderUserDetailsService implements UserDetailsService
{

  private AppDefaults appDefaults;

  @Override
  public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException, DataAccessException
  {
    if (!BudgesContext.getConfigService().getAttributesFromLdapForLocalUser())
    {
      return getUserDetailsFromConfig();
    }
    else
    {
      try
      {
        String[] userGroups = NetLDAP.userGroups(userName);
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>(userGroups.length);
        for (String userGroup : userGroups)
        {
          authorities.add(new SimpleGrantedAuthority("ROLE_" + userGroup));
        }
        UserDetails userDetails = new User(userName, "password", true, true, true, true, authorities);
        return userDetails;
      }
      catch (LDAPException e)
      {
        if (BudgesContext.getConfigService().isLocal())
        {
          return getUserDetailsFromConfig();
        }
        throw new DataRetrievalFailureException("Error retrieving groups for user '" + userName + "' from LDAP", e);
      }
    }
  }

  private UserDetails getUserDetailsFromConfig()
  {
    LdapUser user = BudgesContext.getConfigService().getLdapUser();
    UserDetails userDetails = new User(user.getLdapUserId(), "password", true, true, true, true, Collections.singleton(new SimpleGrantedAuthority("ROLE_" + user.getR2Role())));
    return userDetails;
  }

  public AppDefaults getAppDefaults()
  {
    return appDefaults;
  }

  public void setAppDefaults(AppDefaults appDefaults)
  {
    this.appDefaults = appDefaults;
  }  
}
