package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._ValidationClassification;

/**
 *
 */
public class ValidationClassification extends _ValidationClassification
{
    private static final long serialVersionUID = 1L;
}
