package mil.dtic.cbes.exceptions;

public class ImportException extends Exception
{
    private static final long serialVersionUID = 1L;

    public ImportException() { super(); }                                              // NOSONAR
    public ImportException(String message) { super(message); }                         // NOSONAR
    public ImportException(String message, Throwable cause) { super(message, cause); } // NOSONAR
    public ImportException(Throwable cause) { super(cause); }                          // NOSONAR
}
