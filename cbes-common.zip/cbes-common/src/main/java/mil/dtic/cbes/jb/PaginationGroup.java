/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.util.LinkedList;
import java.util.List;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.p40.vo.MultiYearProcurement;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.p40.vo.jibx.MultiYearProcurementList;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.utility.CbesLogFactory;

public class PaginationGroup{
    private static final Logger log = CbesLogFactory.getLog(PaginationGroup.class);
    LinkedList<JBPart> jbPartList;
    int totalPageCount;
    Constants.JBPageNumbering pageNumbering;
    Constants.JBPageNumberingStyle pageNumberingStyle;
    boolean warningMessageAllowed;


  public PaginationGroup(Constants.JBPageNumbering pageNumbering, boolean warningMessageAllowed) {
      log.trace("PaginationGroup:constructor - PaginationGroup constructor that creates jbPartList - pageNumbering: " + pageNumbering);
      jbPartList = new LinkedList<JBPart>();
      this.pageNumbering = pageNumbering;
      this.warningMessageAllowed = warningMessageAllowed;
  }


  public PaginationGroup(Constants.JBPageNumbering pageNumbering, Constants.JBPageNumberingStyle pageNumberingStyle, boolean warningMessageAllowed) {
      this(pageNumbering, warningMessageAllowed);
      this.pageNumberingStyle = pageNumberingStyle;
      log.trace("PaginationGroup:constructor - PaginationGroup constructor does NOT create jbPartList - pageNumbering: " + pageNumbering);
  }


  public void addJbPart(JBPart jbPart) {
      log.trace("addJbPart: jbPart: " + jbPart);
      
      if (jbPart != null) {
          log.trace("addJbPart: jbPart: " + jbPart.getClass().getName() +" pageCount: " + jbPart.getPdfTotalPageCount());
          setPaginationInfo(jbPart, getLastJbPart(), 1);
          jbPartList.add(jbPart);
          totalPageCount += jbPart.getPdfTotalPageCount();
          jbPart.setPdfPaginationGroup(this);
      }
  }


  public void addJbPart(List<? extends JBPart> jbPartList) {
      log.trace("PaginationGroup:addJbPart - adding list of JBPart");
      if (jbPartList != null)  {
          for (JBPart jbPart : jbPartList){
              addJbPart(jbPart);
          }
      }
  }

  public void setPaginationInfo(JBPart jbPart, JBPart precedingJbPart, int startOffset) {
      if (precedingJbPart == null){
          jbPart.setPdfStartPage(startOffset);
      }
      else {
          jbPart.setPdfStartPage(precedingJbPart.getPdfStartPage() + precedingJbPart.getPdfTotalPageCount());
      }
  }

  public void adjustStartPages(int startOffset) {
      if (jbPartList != null)   {
          JBPart precedingJbPart = null;
          for (JBPart jbPart : jbPartList){
              setPaginationInfo(jbPart, precedingJbPart, startOffset);
              precedingJbPart = jbPart;
        
              if (jbPart instanceof R2ExhibitList) {
                  R2ExhibitList r2ExhibitList = (R2ExhibitList) jbPart;
                  R2Exhibit precedingR2Exhibit = null;
                  for (R2Exhibit r2Exhibit : r2ExhibitList.getR2Exhibits()) {
                      setPaginationInfo(r2Exhibit, precedingR2Exhibit, r2ExhibitList.getPdfStartPage());
                      precedingR2Exhibit = r2Exhibit;
                  }
              } 
              else if (jbPart instanceof LineItemList) {
                  LineItemList lineItemList = (LineItemList) jbPart;
                  LineItemWrapper precedingLineItem = null;
                  for (LineItemWrapper lineItem : lineItemList.getLineItems()) {
                      setPaginationInfo(lineItem, precedingLineItem, lineItemList.getPdfStartPage());
                      if (precedingLineItem != null && precedingLineItem.getLineItem() != null && precedingLineItem.getLineItem().hasAdvanceProcurement() 
                              && false == precedingLineItem.getLineItem().isAPP40Standalone()){
                          lineItem.setPdfStartPage(lineItem.getPdfStartPage() + precedingLineItem.getLineItem().getAdvanceProcurementTotalPages());
                      }
                      precedingLineItem = lineItem;
                  }
              }
              else if (jbPart instanceof MultiYearProcurementList){
                  MultiYearProcurementList multiYearProcurementList = (MultiYearProcurementList) jbPart;
                  MultiYearProcurement precedingMYP = null;
                  for (MultiYearProcurement myp : multiYearProcurementList.getMultiYearProcurements()) {
                      setPaginationInfo(myp, precedingMYP, multiYearProcurementList.getPdfStartPage());
                      precedingMYP = myp;
                  }
              }
          }
      }
  }


  public void replaceFirst(JBPart jbPart) {
      replace(0, jbPart);
  }

  public void replace(int index, JBPart jbPart) {
      if (jbPart != null) {
          // assume new doc has same total # of pages as old
          jbPartList.set(index, jbPart);
          jbPart.setPdfPaginationGroup(this);
      }
  }

  public JBPart getLastJbPart() {
      return(jbPartList.isEmpty() ? null : jbPartList.getLast());
  }

  public List<JBPart> getJbPartList() {
      return jbPartList;
  }

  public int getTotalPageCount(){
      return totalPageCount;
  }

  public Constants.JBPageNumbering getPageNumbering() {
      return pageNumbering;
  }

  public Constants.JBPageNumberingStyle getPageNumberingStyle() {
      return pageNumberingStyle;
  }

  public boolean isWarningMessageAllowed() {
      return warningMessageAllowed;
  }

}
