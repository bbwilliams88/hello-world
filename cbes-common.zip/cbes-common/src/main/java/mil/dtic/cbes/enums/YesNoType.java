package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum YesNoType implements ExtendedEnumeration
{
    YES("Y"), NO("N");

    private final String databaseValue;

    private YesNoType(String databaseValue)
    {
        this.databaseValue = databaseValue;
    }

    @Override
    public String getDatabaseValue()
    {
        return databaseValue;
    }
}
