package mil.dtic.cbes.p40.vo;



/**
 *
 */
public interface HasUnitCosts
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    Costs getUnitCosts();
    void setUnitCosts(Costs c);

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasUnitCost();
    public void jibx_setUnitCosts(Costs unitCosts);

}
