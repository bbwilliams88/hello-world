package mil.dtic.cbes.sso.siteminder;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class SpringUser<T> extends User
{
  private static final long serialVersionUID = 1L;

  private final T dbUser;

  public SpringUser(String username, Collection<? extends GrantedAuthority> authorities, T dbUser)
  {
    super(username, "password", true, true, true, true, authorities);
    this.dbUser = dbUser;
  }

  public T getDbUser()
  {
    return dbUser;
  }
}
