/**
 * 
 */
package mil.dtic.cbes.rule;

import mil.dtic.cbes.submissions.validation.backend.ValidationMessage;
import mil.dtic.cbes.submissions.validation.backend.ValidationMessages;

/**
 * Adapts a P40 set of validation messages to a
 * JSON based violation list.
 * 
 * @author AZumkhaw
 *
 */
public class ValidationMessagesAdapter {
  
  /**
   * Private class representing an ValidationMessage
   * as a RuleViolation.
   * 
   * @author AZumkhaw
   *
   */
  private static class AdaptedRuleViolation extends RuleViolation {
    String ruleNumber;
    String violationString;

    public AdaptedRuleViolation(ValidationMessage message) {
      super(message.getLocation(), message.getMessage());
      ruleNumber = message.getRuleNumber();
      violationString = message.toString();
      setExhibitKey(message.getKey());
    }
    
    @Override
    public String toString() {
      return violationString;
    }
    
    @Override
    public String getRuleNumber() {
      return ruleNumber;
    }    
  }
  
  /**
   * Private class that contains a list of adapted
   * validation messages.
   * 
   * @author AZumkhaw
   *
   */
  private static class AdaptedRuleViolationList extends RuleViolationList {
    public void add(ValidationMessage message) {
      AdaptedRuleViolation violation = new AdaptedRuleViolation(message);
      violations.add(violation);
    }
  }
  
  private RuleViolationList violations;
  
  public ValidationMessagesAdapter(ValidationMessages messages) {
    adapt(messages);
  }
  
  public RuleViolationList getList() {
    return violations;
  }
  
  private void adapt(ValidationMessages messages) {
    AdaptedRuleViolationList adaptedViolations = new AdaptedRuleViolationList();
    for (ValidationMessage violation : messages.getWarnings()) {
      adaptedViolations.add(violation);
    }
    violations = adaptedViolations;
  }
}
