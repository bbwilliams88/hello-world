package mil.dtic.cbes.p40.vo;

import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.ObjectContext;

import mil.dtic.cbes.enums.ResourceSummaryEntryType;



public interface ResourceSummary extends List<ResourceSummaryRow>, HasTripletCosts
{
  ResourceSummaryRow getQuantity();

  void setQuantity(ResourceSummaryRow quantity);

  ResourceSummaryRow getGrossWeaponSystemCost();

  void setGrossWeaponSystemCost(ResourceSummaryRow grossCost);

  ResourceSummaryRow getLessPYAdvProc();

  void setLessPYAdvProc(ResourceSummaryRow lessPyAdvProc);

  ResourceSummaryRow getPlusCYAdvProc();

  void setPlusCYAdvProc(ResourceSummaryRow plusPyAdvProc);

  ResourceSummaryRow getNetProcP1();

  void setNetProcP1(ResourceSummaryRow netProcP1);

  ResourceSummaryRow getTotalProcCost();

  void setTotalProcCost(ResourceSummaryRow totalProcCost);

  ResourceSummaryRow getInitialSpares();

  void setInitialSpares(ResourceSummaryRow initialSpares);

  ResourceSummaryRow getFlyawayUnitCost();

  void setFlyawayUnitCost(ResourceSummaryRow w);

  ResourceSummaryRow getGrossWeaponSystemUnitCost();

  void setGrossWeaponSystemUnitCost(ResourceSummaryRow grossCost);

  ResourceSummaryRow getLessCostToComplete();

  void setLessCostToComplete(ResourceSummaryRow lessCostToComplete);

  ResourceSummaryRow getLessHurricaneSupplemental();

  void setLessHurricaneSupplemental(ResourceSummaryRow lessHurricaneSupplemental);

  ResourceSummaryRow getLessSubsequentYearFullFunding();

  void setLessSubsequentYearFullFunding(ResourceSummaryRow lessSubsequentYearFullFunding);

  ResourceSummaryRow getPlusSubsequentYearFullFunding();

  void setPlusSubsequentYearFullFunding(ResourceSummaryRow plusSubsequentYearFullFunding);

  ResourceSummaryRow getLessPriorYearFullFunding();

  void setLessPriorYearFullFunding(ResourceSummaryRow lessPriorYearFullFunding);

  ResourceSummaryRow getPlusPriorYearFullFunding();

  void setPlusPriorYearFullFunding(ResourceSummaryRow plusPriorYearFullFunding);

  ResourceSummaryRow getFullFundingTOA();

  void setFullFundingTOA(ResourceSummaryRow fullFundingTOA);

  ResourceSummaryRow getPlusCostToComplete();

  void setPlusCostToComplete(ResourceSummaryRow plusCostToComplete);

  ResourceSummaryRow getPlusHurricaneSupplemental();

  void setPlusHurricaneSupplemental(ResourceSummaryRow plusHurricaneSupplemental);

  ResourceSummaryRow getPlusOutfittingAndPostDelivery();

  void setPlusOutfittingAndPostDelivery(ResourceSummaryRow plusOutfittingAndPostDelivery);

  ResourceSummaryRow getAllLineItemsTotal();

  void setAllLineItemsTotal(ResourceSummaryRow allLineItemsTotal);

  Iterator<ResourceSummaryRow> jibx_otherIterator();

  void jibx_addOther(ResourceSummaryRow rsr);

  boolean jibx_hasOther();

  List<ResourceSummaryRow> getOtherRows();

  boolean hasQuantity();

  boolean hasGross();

  boolean hasGrossUnit();

  boolean hasPy();

  boolean hasNet();

  boolean hasCy();

  boolean hasTotal();

  boolean hasInitialSpares();

  boolean hasFlyaway();

  boolean hasLessCostToComplete();

  boolean hasLessHurricaneSupplemental();

  boolean hasLessSubsequentYearFullFunding();

  boolean hasPlusSubsequentYearFullFunding();

  boolean hasLessPriorYearFullFunding();

  boolean hasPlusPriorYearFullFunding();

  boolean hasFullFundingTOA();

  boolean hasPlusCostToComplete();

  boolean hasPlusHurricaneSupplemental();

  boolean hasPlusOutfittingAndPostDelivery();

  boolean hasAllLineItemsTotal();

  void generateMissingRows(ObjectContext context, ResourceSummaryEntryType[] desiredRows);
}