package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.ObjectContext;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.auto._UserLineItem;

public class UserLineItem extends _UserLineItem 
{
  private static final long serialVersionUID = 1L;
  
  public boolean isEditPrivilege()
  {
    if (StringUtils.equals(getEditPrivilege(),"Y"))
      return true;
    else
      return false;
  }
  
  public boolean isViewPrivilege()
  {
    if (StringUtils.equals(getViewPrivilege(),"Y"))
      return true;
    else
      return false;
  }
  
  public void setEditPrivilege(boolean b)
  {
    if (b)
      setEditPrivilege("Y");
    else
      setEditPrivilege("N");
  }
  
  public void setViewPrivilege(boolean b)
  {
    if (b)
      setViewPrivilege("Y");
    else
      setViewPrivilege("N");
  }
  
  public static UserLineItem fetchByUserAndLineItem(ObjectContext context,P40User user, LineItem lineItem)
  {
   return Base.fetchOne(context, UserLineItem.class, UserLineItem.USER_RELATIONSHIP_PROPERTY, UserLineItem.LINE_ITEM_RELATIONSHIP_PROPERTY, user, lineItem); 
  }
  
}
