package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.PersistenceState;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.enums.NewOptionType;
import mil.dtic.cbes.p40.vo.auto._HistoryPlanning;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.BigDecimalUtil;
import mil.dtic.utility.Util;

/**
 *
 */
public class HistoryPlanning extends _HistoryPlanning implements HasDisplayOrder, Equivalence<HistoryPlanning>, HasContractMethodFundingVehicle
{
  private static final long serialVersionUID = 1L;

  private P40ContractType jibxContractType;
  private P40ContractMethod jibxContractMethod;
  private P40FundingVehicle jibxFundingVehicle;


  /***********************************************************************/
  /*** Cayenne Callbacks                                               ***/
  /***********************************************************************/

  @Override
  protected void onPostAdd()
  {
    setOOC(false);
    setDisplayOrder(0);
    setUpTotalDeliverySchedule();
  }

  @Override
  protected void onPostLoad()
  {
    setUpTotalDeliverySchedule();
  }

  private void setUpTotalDeliverySchedule()
  {
    if (getDeliveryScheduleTotals().isEmpty()){
      addToDeliveryScheduleTotals(getContext().newObject(DeliverySchedule.class));
    }
  }

  /***********************************************************************/
  /*** Custom Accessors                                                ***/
  /***********************************************************************/

  // FIXME: Rename to getOrderedDeliverySchedules().
  public List<DeliverySchedule> getDeliveryScheduleList()
  {
    return getSortedByDisplayOrder(super.getDeliverySchedules());
  }

  public DeliverySchedule getDeliveryScheduleForServiceAgency(ServiceAgency serviceAgency)
  {
    if (serviceAgency != null)
    {
      List<DeliverySchedule> deliveryScheduleList = new ArrayList<DeliverySchedule>(super.getDeliverySchedules());

      if (deliveryScheduleList != null)
        for (DeliverySchedule deliverySchedule : deliveryScheduleList)
          if (serviceAgency.getName().equalsIgnoreCase(deliverySchedule.getServiceAgency().getName()))
            return deliverySchedule;
    }

    return null;
  }

  public DeliverySchedule getDeliveryScheduleTotal()
  {
    if (getDeliveryScheduleTotals().size() > 0)
      return getDeliveryScheduleTotals().get(0);

    return null;
  }

  public void setDeliveryScheduleTotal(DeliverySchedule deliverySchedule)
  {
    // Only one delivery schedule is allowed, so clear out any existing ones.
    // Since jibx passes in a null value when an optional field does not
    // exist, we will only add to the DStotals when the DS is not null
    if (deliverySchedule != null)
    {
      while (getDeliveryScheduleTotals().size() > 0)
      {
        DeliverySchedule deliveryScheduleToDelete = getDeliveryScheduleTotals().get(0);

        removeFromDeliveryScheduleTotals(deliveryScheduleToDelete);
        deliveryScheduleToDelete.delete();
      }

      addToDeliveryScheduleTotals(deliverySchedule);
    }
  }

  public boolean hasSpecsAvailableNow()
  {
    return getSpecsAvailableNow() != null;
  }

  public boolean hasRevisionsAvailableDate()
  {
    return getRevisionsAvailableDate() != null;
  }

  public boolean hasRFPIssueDate()
  {
    return getRFPIssueDate() != null;
  }

  public boolean hasItemNameSuufix()
  {
    return getItemNameSuffix() != null;
  }

  public String getLabel()
  {
    return "FY " + getFiscalYear() + (getOOC() ? " OOC" : "") + (getItemNameSuffix() == null ? "" : " " + getItemNameSuffix());
  }

  /** Tapestry coercion hack to allow for null selections */
  // FIXME: Is this used?
  public void setSpecsAvailableNow2(Object o)
  {
    if (o != null)
      setSpecsAvailableNow(Boolean.valueOf(o.toString()));
    else
      setSpecsAvailableNow(null);
  }

  // FIXME: Is this used?
  public Object getSpecsAvailableNow2()
  {
    return getSpecsAvailableNow();
  }

  @Override
  public void setOOC(Boolean OOC)
  {
    if (OOC == null)
      super.setOOC(false);
    else
      super.setOOC(OOC);
  }

  /***********************************************************************/
  /*** Business Logic                                                  ***/
  /***********************************************************************/

  /**
   * @param serviceAgency
   * @return
   */
  // FIXME: Should be a create* method since "add" implies you are supplying the DS.
  public DeliverySchedule addDeliverySchedule(ServiceAgency serviceAgency)
  {
    boolean          deliverySheduleExists = false;
    DeliverySchedule newDeliveryShedule    = getObjectContext().newObject(DeliverySchedule.class);

    for (DeliverySchedule deliveryShedule : getDeliveryScheduleList())
    {
      if (deliveryShedule.getServiceAgency().getCode().equals(serviceAgency.getCode()))
      {
        deliverySheduleExists = true;
        break;
      }
    }

    newDeliveryShedule.setDisplayOrder(Util.getNextDisplayOrderValue(getDeliveryScheduleList()));
    newDeliveryShedule.setServiceAgency(serviceAgency);

    if (deliverySheduleExists)
      newDeliveryShedule.setProcQuantity(null);
    else
      newDeliveryShedule.setProcQuantity(getQuantity());

    addToDeliverySchedules(newDeliveryShedule);

    return newDeliveryShedule;
  }

  // FIXME: Rename this to deleteDeliverySchedule since it does more than remove.
  public void removeDeliverySchedule(DeliverySchedule deliveryShedule)
  {
    removeFromDeliverySchedules(deliveryShedule);
    getObjectContext().deleteObjects(deliveryShedule);
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getSchedule() != null)
      this.getSchedule().shiftForwardInTime(years);
  }

  /***********************************************************************/
  /*** JiBX Support                                                    ***/
  /***********************************************************************/

  public boolean jibx_hasDeliveryScheduleList()
  {
    return CollectionUtils.isNotEmpty(super.getDeliverySchedules());
  }

  public Iterator<DeliverySchedule> jibx_deliveryScheduleListIterator()
  {
    return getIterator(getDeliveryScheduleList());
  }

  public boolean jibx_hasOOC()
  {
    return getOOC() != null && getOOC();
  }

  public boolean jibx_hasFY()
  {
    return getFiscalYear() != null;
  }

  public boolean jibx_hasPCOLocation()
  {
    return !StringUtils.isEmpty(getPCOLocation());
  }

  public boolean jibx_hasAwardDate()
  {
    return getAwardDate() != null;
  }

  public boolean jibx_hasFirstDeliveryDate()
  {
    return getFirstDeliveryDate() != null;
  }

  public boolean jibx_hasQuantity()
  {
    return getQuantity() != null;
  }

  public boolean jibx_hasUnitCost()
  {
    return getUnitCost() != null;
  }


  public void jibx_postSet()
  {
    Util.generateDisplayOrder(super.getDeliverySchedules());
  }

  // jibx unmarshal calls setters
  // postprocess reads _getters and sets ContractMethodTypeFundingVehicle
  // jibx marshal calls getters which read from
  // ContractMethodTypeFundingVehicle
  public P40ContractType getJibxContractType()
  {
    if (getContractMethodTypeFundingVehicle() != null)
      return getContractMethodTypeFundingVehicle().getContractType();
    else
      return null;
  }

  public P40ContractType _getJibxContractType()
  {
    return jibxContractType;
  }

  public void setJibxContractType(P40ContractType jibxContractType)
  {
    this.jibxContractType = jibxContractType;
  }

  public P40ContractMethod getJibxContractMethod()
  {
    if (getContractMethodTypeFundingVehicle() != null)
      return getContractMethodTypeFundingVehicle().getContractMethod();
    else
      return null;
  }

  public P40ContractMethod _getJibxContractMethod()
  {
    return jibxContractMethod;
  }

  public void setJibxContractMethod(P40ContractMethod jibxContractMethod)
  {
    this.jibxContractMethod = jibxContractMethod;
  }

  public P40FundingVehicle getJibxFundingVehicle()
  {
    if (getContractMethodTypeFundingVehicle() != null)
      return getContractMethodTypeFundingVehicle().getFundingVehicle();
    else
      return null;
  }

  public P40FundingVehicle _getJibxFundingVehicle()
  {
    return jibxFundingVehicle;
  }

  public void setJibxFundingVehicle(P40FundingVehicle jibxFundingVehicle)
  {
    this.jibxFundingVehicle = jibxFundingVehicle;
  }

  public boolean jibx_hasMonthlyDeliveryScheduleTotalCosts()
  {
    if (getDeliveryScheduleTotal() != null && CollectionUtils.isNotEmpty(getDeliveryScheduleTotal().getMonthlyDeliveriesWithAmounts()))
      return true;
    else
      return false;
  }
  
  public boolean jibx_hasHull()
  {
    return StringUtils.isNotEmpty(getHullNumber()) || StringUtils.isNotEmpty(getHullShipType());
  }
  
  public boolean jibx_hasNewOrOption()
  {
    return getNewOrOption() != null;
  }
  
  public void jibx_setNewOrOption(String newOrOption)
  {
    if (StringUtils.equals(newOrOption, NewOptionType.NEW.getXmlName()))
      setNewOrOption(NewOptionType.NEW);
    else if (StringUtils.equals(newOrOption, NewOptionType.OPTION.getXmlName()))
      setNewOrOption(NewOptionType.OPTION);
    else if (StringUtils.equals(newOrOption, NewOptionType.VARIOUS.getXmlName()))
      setNewOrOption(NewOptionType.VARIOUS);
    else if (StringUtils.isNotEmpty(newOrOption))
      throw new IllegalArgumentException("The value provided for the NewOrOption element tag, ['" + newOrOption + "'], is not valid. Only the strings 'new', 'option', or 'various' are acceptable.");
  }
  
  public String jibx_getNewOrOption()
  {
    return jibx_hasNewOrOption() ? getNewOrOption().getXmlName() : null;
  }
  
  public boolean jibx_hasRequiredAwardDate()
  {
    return getRequiredAwardDate() != null;
  }
  
  public boolean jibx_hasMonthsRequired()
  {
    return getMonthsRequired() != null;
  }

  /***********************************************************************/
  /*** Validation Support                                              ***/
  /***********************************************************************/

  /**
   * HashCode based on Business Rule [E-XML-PROC#U160]
   */
  public int equivalenceHashCode()
  {
    if (this.getPersistenceState() == PersistenceState.DELETED)
      return super.hashCode();

    HashCodeBuilder builder = new HashCodeBuilder();

    builder.append(getFiscalYear());
    builder.append(toLowerAndTrim(getItemNameSuffix()));
    builder.append(getOOC());
    builder.append(getManufacturer());

    return builder.toHashCode();
  }

  /**
   * Equality based on Business Rule [E-XML-PROC#U160]
   */
  public boolean equivalentTo(HistoryPlanning obj)
  {
    if (this == obj)
      return true;
    else if (obj == null)
      return false;
    else if (getClass() != obj.getClass())
      return false;

    HistoryPlanning other = obj;

    if (this.getPersistenceState() == PersistenceState.DELETED || other.getPersistenceState() == PersistenceState.DELETED)
      return super.equals(obj);

    EqualsBuilder builder = new EqualsBuilder();

    builder.append(getFiscalYear(), other.getFiscalYear());
    builder.append(toLowerAndTrim(getItemNameSuffix()), toLowerAndTrim(other.getItemNameSuffix()));
    builder.append(getOOC(), other.getOOC());
    builder.append(getManufacturer(), other.getManufacturer());

    return builder.isEquals();
  }
  
  /**
   * Method that returns a list of all monthly deliveries across all agencies summed as a single list.
   * 
   * @return the combined delivery list
   */
  public List<MonthlyDelivery> getCombinedDeliveriesList()
  {
    List<MonthlyDelivery> combinedList = new ArrayList<MonthlyDelivery>();
    for (DeliverySchedule ds : getDeliveryScheduleList())
    {
      for (MonthlyDelivery md : ds.getMonthlyDeliveryList())
      {
        addDelivery(md, combinedList);
      }
    }
    
    return combinedList;
  }

  /**
   * Adds a monthly delivery into a list of deliveries.  If the month is already in the list, adds the values, otherwise adds the new month.
   * 
   * @param md the month to add.
   * @param combinedList the list to add it too.
   */
  private void addDelivery(MonthlyDelivery md, List<MonthlyDelivery> combinedList)
  {
    if (md != null && md.getMonth() != null && md.getAmount() != null)
    {
      for (MonthlyDelivery delivery : combinedList)
      {
        if (delivery.getMonth() != null && delivery.getMonth().equals(md.getMonth()))
        {
          delivery.setAmount(BigDecimalUtil.add(delivery.getAmount(), md.getAmount()));
          return;
        }
      }
      MonthlyDelivery newMd = new MonthlyDelivery();
      newMd.setAmount(md.getAmount());
      newMd.setMonth(md.getMonth());
      combinedList.add(newMd);
    }
  }
}
