package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.commons.lang.StringUtils;

import mil.dtic.cbes.p40.vo.util.EnumUtils;

public enum ResourceSummaryEntryType implements ExtendedEnumeration
{
    //TODO: These really should be capitalized
    Quantity                ("Quantity",                      "Quantity",                           "Quantity",       ""),
    GrossWSCost             ("TotalCost",                     "Gross/Weapon System Cost",           "Gross Cost",     "A"),
    LessPY                  ("PYAdvanceProcurement",          "Less PY Advance Procurement",        "Less PY AP",     "B"),
    NetP1                   ("NetProcurementP1",              "Net Procurement P-1",                "Net Cost",       ""),
    PlusCY                  ("CYAdvanceProcurement",          "Plus CY Advance Procurement",        "Plus CY AP",     "C"),
    Total                   ("TotalObligationAuthority",      "Total Obligation Authority",         "TOA",            ""),
    InitialSpares           ("InitialSpares",                 "Initial Spares",                     "Initial Spares", ""),
    Flyaway                 ("FlyawayUnitCost",               "Flyaway Unit Cost",                  "Flyaway UC",     ""),
    GrossWSUnitCost         ("UnitCost",                      "Gross Weapon System Unit Cost",      "Gross UC",       ""),
    Other                   ("",                              "",                                   "User-defined",   ""),
    LessCTC                 ("LessCostToComplete",            "Less Cost To Complete",              "Less CTC",       ""),
    LessHurricane           ("LessHurricaneSupplemental",     "Less Hurricane Supplemental",        "Less Hurricane", ""),
    LessSubsequentYearFF    ("LessSubsequentYearFullFunding", "Less Subsequent Year Full Funding",  "Less SY FF",     "E"),
    PlusSubsequentYearFF    ("PlusSubsequentYearFullFunding", "Plus Subsequent Year Full Funding",  "Plus SY FF",     "L"),
    LessPriorYearFF         ("LessPriorYearFullFunding",      "Less Prior Year Full Funding",       "Less PY FF",     ""),
    PlusPriorYearFF         ("PlusPriorYearFullFunding",      "Plus Prior Year Full Funding",       "Plus PY FF",     ""),
    FFTOA                   ("FullFundingTOA",                "Full Funding TOA",                   "FF TOA",         ""),
    PlusCTC                 ("PlusCostToComplete",            "Plus Cost To Complete",              "Plus CTC",       "N"),
    PlusHurricane           ("PlusHurricaneSupplemental",     "Plus Hurricane Supplemental",        "Plus Hurricane", ""),
    PlusOutfittingDelivery  ("PlusOutfittingAndPostDelivery", "Plus Outfitting And Post Delivery",  "Plus OAPD",      ""),
    AllLITotal              ("AllLineItemsTotal",             "Total of All Associated Line Items", "All LI Total",   "");

    //TODO: These really should be private lists that are accessed through getters
    public static final ResourceSummaryEntryType[] lineItemRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost, LessPY, NetP1,
      PlusCY, Total, InitialSpares, Flyaway };
    public static final ResourceSummaryEntryType[] allPossibleLineItemRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost, LessPY, LessCTC, LessSubsequentYearFF, LessPriorYearFF,
       FFTOA, PlusSubsequentYearFF, PlusPriorYearFF, NetP1, PlusCY, PlusCTC, Total, InitialSpares, PlusOutfittingDelivery, Flyaway, AllLITotal};
    public static final ResourceSummaryEntryType[] costTypeCRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost, NetP1, Total,
            InitialSpares, Flyaway };
    public static final ResourceSummaryEntryType[] itemRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost, LessPY, NetP1, PlusCY,
            Total, InitialSpares };
    public static final ResourceSummaryEntryType[] p3aRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost, LessPY, NetP1, PlusCY,
            Total, InitialSpares };
    public static final ResourceSummaryEntryType[] baseRows = new ResourceSummaryEntryType[] { Quantity, GrossWSCost, GrossWSUnitCost };

    private final String xmlName;
    private final String uiName;
    private final String dbName;
    private final String prcpName;

    private ResourceSummaryEntryType(String xmlName, String uiName, String dbName, String prcpName)
    {
        this.xmlName = xmlName;
        this.uiName = uiName;
        this.dbName = dbName;
        this.prcpName = prcpName;
    }

    public String getXmlName()
    {
        return xmlName;
    }

    public String getUIName()
    {
        return uiName;
    }

    public String getDatabaseValue()
    {
        return dbName;
    }
    
    public String getP1CostType()
    {
        return prcpName;
    }

    public static ResourceSummaryEntryType fromDatabaseValue(String databaseValue)
    {
        return EnumUtils.fromDatabaseValue(ResourceSummaryEntryType.class, databaseValue);
    }

    public static ResourceSummaryEntryType fromEnumValue(String enumValue)
    {
        return EnumUtils.fromEnumValue(ResourceSummaryEntryType.class, enumValue);
    }
    
    public static ResourceSummaryEntryType fromPrcpName(String prcpName) {
      if (prcpName != null && !StringUtils.isEmpty(prcpName)) {
        for (ResourceSummaryEntryType r : ResourceSummaryEntryType.values()) {
          if (r.getP1CostType().equalsIgnoreCase(prcpName)) {
            return r;
          }
        }
      }

      return null;
    }
    
    @Override
    public String toString()
    {
      return this.uiName;
    }
}
