package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class MYPAgencyFundingDetails
{
  private String serviceAgencyName;
  private String appropriationNumber;
  private MultiYearProcurementFundingPlanType totalProgramFundingPlan;
  private MultiYearProcurementFundingPlanType contractFundingPlan;
  private MultiYearProcurementValueAnalysis presentValueAnalysis;
  private List<MYPLineItemDetails> MYPLineItemDetailsList = new ArrayList<MYPLineItemDetails>();


  /**
   * @return the serviceAgencyName
   */
  public String getServiceAgencyName()
  {
    return serviceAgencyName;
  }


  /**
   * @param serviceAgencyName
   *          the serviceAgencyName to set
   */
  public void setServiceAgencyName(String serviceAgencyName)
  {
    this.serviceAgencyName = serviceAgencyName;
  }


  /**
   * @return the appropriationNumber
   */
  public String getAppropriationNumber()
  {
    return appropriationNumber;
  }


  /**
   * @param appropriationNumber
   *          the appropriationNumber to set
   */
  public void setAppropriationNumber(String appropriationNumber)
  {
    this.appropriationNumber = appropriationNumber;
  }


  /**
   * @return the mYPTwo
   */
  public MultiYearProcurementFundingPlanType getTotalProgramFundingPlan()
  {
    return totalProgramFundingPlan;
  }


  /**
   * @param mYPTwo
   *          the mYPTwo to set
   */
  public void setTotalProgramFundingPlan(MultiYearProcurementFundingPlanType totalProgramFundingPlan)
  {
    this.totalProgramFundingPlan = totalProgramFundingPlan;
  }


  /**
   * @return the mYPThree
   */
  public MultiYearProcurementFundingPlanType getContractFundingPlan()
  {
    return contractFundingPlan;
  }


  /**
   * @param mYPThree
   *          the mYPThree to set
   */
  public void setContractFundingPlan(MultiYearProcurementFundingPlanType contractFundingPlan)
  {
    this.contractFundingPlan = contractFundingPlan;
  }


  /**
   * @return the mYPFour
   */
  public MultiYearProcurementValueAnalysis getPresentValueAnalysis()
  {
    return presentValueAnalysis;
  }


  /**
   * @param mYPFour
   *          the mYPFour to set
   */
  public void setPresentValueAnalysis(MultiYearProcurementValueAnalysis presentValueAnalysis)
  {
    this.presentValueAnalysis = presentValueAnalysis;
  }


  /**
   * @return the mYPLineItemDetailsList
   */
  public Iterator<MYPLineItemDetails> jibx_MYPLineItemDetailsListIterator()
  {
    
    //TODO: Might need to implement a display order and possible an immutable list to return.
    return MYPLineItemDetailsList.iterator();
  }
  
  
  public List<MYPLineItemDetails> getMYPLineItemDetailsList()
  {
    return MYPLineItemDetailsList;
  }


  /**
   * @param mYPLineItemDetailsList
   *          the mYPLineItemDetailsList to add to the list.
   */
  public void addToMYPLineItemDetailsList(MYPLineItemDetails lineItemDetails)
  {
    MYPLineItemDetailsList.add(lineItemDetails);
  }

  public boolean jibx_hasLineItemDetails()
  {
    return CollectionUtils.isNotEmpty(MYPLineItemDetailsList);
  }
}
