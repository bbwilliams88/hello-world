package mil.dtic.cbes.jb;

import java.io.File;

public interface EmbedableFile {

	public String getDisplayFileName();

	public void setDisplayFileName(String displayFileName);

	public String getDisplayDescription();

	public void setDisplayDescription(String displayDescription);

	public String getFileToEmbedAbsolutePath();

	public void setFileToEmbedAbsolutePath(String fileToEmbedAbsolutePath);

	public File getFileToEmbed();

	public void setFileToEmbed(File fileToEmbed);
	
	public byte[] getObjectToEmbed();

	public void setObjectToEmbed(byte[] objectToEmbed);
	
	public String getFileLocation();

}
