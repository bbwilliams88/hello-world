package mil.dtic.cbes.p40.vo;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class MultiYearProcurementCriteria
{
  private String description;
  private String substantialSavings;
  private String stabilityOfRequirement;
  private String stabilityOfFunding;
  private String stableDesign;
  private String realisticCostEstimates;
  private String nationalSecurity;
  private String sourceOfSavingsDescription;
  private DollarAmountType inflation;
  private DollarAmountType vendorProcurement;
  private DollarAmountType manufacturing;
  private DollarAmountType designEngineering;
  private DollarAmountType toolDesign;
  private DollarAmountType supportEquipment;
  private DollarAmountType other;
  private DollarAmountType workloadSavings;
  private DollarAmountType total;
  private String advantages;
  private String impactOnDefenseIndustrialBase;
  private DollarAmountType annualQuantity;
  private DollarAmountType annualTotal;
  private DollarAmountType annualFundedCancellation;
  private DollarAmountType annualUnfundedCancellation;
  private DollarAmountType annualCostAvoidance;
  private DollarAmountType annualPercentCostAvoidance;
  private DollarAmountType multiYearQuantity;
  private DollarAmountType multiYearTotal;
  private DollarAmountType multiYearFundedCancellation;
  private DollarAmountType multiYearUnfundedCancellation;
  private DollarAmountType multiYearCostAvoidance;
  private DollarAmountType multiYearPercentCostAvoidance;


  /**
   * Get the 'Description' element value.
   * 
   * @return value
   */
  public String getDescription()
  {
    return description;
  }


  /**
   * Set the 'Description' element value.
   * 
   * @param description
   */
  public void setDescription(String description)
  {
    this.description = description;
  }


  /**
   * Get the 'SourceOfSavings' element value.
   * 
   * @return value
   */
  public String getSourceOfSavingsDescription()
  {
    return sourceOfSavingsDescription;
  }


  /**
   * Set the 'SourceOfSavings' element value.
   * 
   * @param sourceOfSavings
   */
  public void setSourceOfSavingsDescription(String sourceOfSavingsDescription)
  {
    this.sourceOfSavingsDescription = sourceOfSavingsDescription;
  }


  /**
   * Get the 'Advantages' element value.
   * 
   * @return value
   */
  public String getAdvantages()
  {
    return advantages;
  }


  /**
   * Set the 'Advantages' element value.
   * 
   * @param advantages
   */
  public void setAdvantages(String advantages)
  {
    this.advantages = advantages;
  }


  /**
   * Get the 'ImpactOnDIB' element value.
   * 
   * @return value
   */
  public String getImpactOnDefenseIndustrialBase()
  {
    return impactOnDefenseIndustrialBase;
  }


  /**
   * Set the 'ImpactOnDIB' element value.
   * 
   * @param impactOnDIB
   */
  public void setImpactOnDIB(String impactOnDefenseIndustrialBase)
  {
    this.impactOnDefenseIndustrialBase = impactOnDefenseIndustrialBase;
  }


  /**
   * @return the substantialSavings
   */
  public String getSubstantialSavings()
  {
    return substantialSavings;
  }


  /**
   * @param substantialSavings
   *          the substantialSavings to set
   */
  public void setSubstantialSavings(String substantialSavings)
  {
    this.substantialSavings = substantialSavings;
  }


  /**
   * @return the stabilityOfRequirement
   */
  public String getStabilityOfRequirement()
  {
    return stabilityOfRequirement;
  }


  /**
   * @param stabilityOfRequirement
   *          the stabilityOfRequirement to set
   */
  public void setStabilityOfRequirement(String stabilityOfRequirement)
  {
    this.stabilityOfRequirement = stabilityOfRequirement;
  }


  /**
   * @return the stabilityOfFunding
   */
  public String getStabilityOfFunding()
  {
    return stabilityOfFunding;
  }


  /**
   * @param stabilityOfFunding
   *          the stabilityOfFunding to set
   */
  public void setStabilityOfFunding(String stabilityOfFunding)
  {
    this.stabilityOfFunding = stabilityOfFunding;
  }


  /**
   * @return the stableDesign
   */
  public String getStableDesign()
  {
    return stableDesign;
  }


  /**
   * @param stableDesign
   *          the stableDesign to set
   */
  public void setStableDesign(String stableDesign)
  {
    this.stableDesign = stableDesign;
  }


  /**
   * @return the realisticCostEstimates
   */
  public String getRealisticCostEstimates()
  {
    return realisticCostEstimates;
  }


  /**
   * @param realisticCostEstimates
   *          the realisticCostEstimates to set
   */
  public void setRealisticCostEstimates(String realisticCostEstimates)
  {
    this.realisticCostEstimates = realisticCostEstimates;
  }


  /**
   * @return the nationalSecurity
   */
  public String getNationalSecurity()
  {
    return nationalSecurity;
  }


  /**
   * @param nationalSecurity
   *          the nationalSecurity to set
   */
  public void setNationalSecurity(String nationalSecurity)
  {
    this.nationalSecurity = nationalSecurity;
  }


  /**
   * @return the inflation
   */
  public DollarAmountType getInflation()
  {
    return inflation;
  }


  /**
   * @param inflation
   *          the inflation to set
   */
  public void setInflation(DollarAmountType inflation)
  {
    this.inflation = inflation;
  }


  /**
   * @return the vendorProcurement
   */
  public DollarAmountType getVendorProcurement()
  {
    return vendorProcurement;
  }


  /**
   * @param vendorProcurement
   *          the vendorProcurement to set
   */
  public void setVendorProcurement(DollarAmountType vendorProcurement)
  {
    this.vendorProcurement = vendorProcurement;
  }


  /**
   * @return the manufacturing
   */
  public DollarAmountType getManufacturing()
  {
    return manufacturing;
  }


  /**
   * @param manufacturing
   *          the manufacturing to set
   */
  public void setManufacturing(DollarAmountType manufacturing)
  {
    this.manufacturing = manufacturing;
  }


  /**
   * @return the designEngineering
   */
  public DollarAmountType getDesignEngineering()
  {
    return designEngineering;
  }


  /**
   * @param designEngineering
   *          the designEngineering to set
   */
  public void setDesignEngineering(DollarAmountType designEngineering)
  {
    this.designEngineering = designEngineering;
  }


  /**
   * @return the toolDesign
   */
  public DollarAmountType getToolDesign()
  {
    return toolDesign;
  }


  /**
   * @param toolDesign
   *          the toolDesign to set
   */
  public void setToolDesign(DollarAmountType toolDesign)
  {
    this.toolDesign = toolDesign;
  }


  /**
   * @return the supportEquipment
   */
  public DollarAmountType getSupportEquipment()
  {
    return supportEquipment;
  }


  /**
   * @param supportEquipment
   *          the supportEquipment to set
   */
  public void setSupportEquipment(DollarAmountType supportEquipment)
  {
    this.supportEquipment = supportEquipment;
  }


  /**
   * @return the other
   */
  public DollarAmountType getOther()
  {
    return other;
  }


  /**
   * @param other
   *          the other to set
   */
  public void setOther(DollarAmountType other)
  {
    this.other = other;
  }


  /**
   * @return the workloadSavings
   */
  public DollarAmountType getWorkloadSavings()
  {
    return workloadSavings;
  }


  /**
   * @param workloadSavings
   *          the workloadSavings to set
   */
  public void setWorkloadSavings(DollarAmountType workloadSavings)
  {
    this.workloadSavings = workloadSavings;
  }


  /**
   * @return the total
   */
  public DollarAmountType getTotal()
  {
    return total;
  }


  /**
   * @param total
   *          the total to set
   */
  public void setTotal(DollarAmountType total)
  {
    this.total = total;
  }


  /**
   * @param impactOnDefenseIndustrialBase
   *          the impactOnDefenseIndustrialBase to set
   */
  public void setImpactOnDefenseIndustrialBase(String impactOnDefenseIndustrialBase)
  {
    this.impactOnDefenseIndustrialBase = impactOnDefenseIndustrialBase;
  }


  /**
   * @return the annualQuantity
   */
  public DollarAmountType getAnnualQuantity()
  {
    return annualQuantity;
  }


  /**
   * @param annualQuantity
   *          the annualQuantity to set
   */
  public void setAnnualQuantity(DollarAmountType annualQuantity)
  {
    this.annualQuantity = annualQuantity;
  }


  /**
   * @return the annualTotal
   */
  public DollarAmountType getAnnualTotal()
  {
    return annualTotal;
  }


  /**
   * @param annualTotal
   *          the annualTotal to set
   */
  public void setAnnualTotal(DollarAmountType annualTotal)
  {
    this.annualTotal = annualTotal;
  }


  /**
   * @return the annualFundedCancellation
   */
  public DollarAmountType getAnnualFundedCancellation()
  {
    return annualFundedCancellation;
  }


  /**
   * @param annualFundedCancellation
   *          the annualFundedCancellation to set
   */
  public void setAnnualFundedCancellation(DollarAmountType annualFundedCancellation)
  {
    this.annualFundedCancellation = annualFundedCancellation;
  }


  /**
   * @return the annualUnfundedCancellation
   */
  public DollarAmountType getAnnualUnfundedCancellation()
  {
    return annualUnfundedCancellation;
  }


  /**
   * @param annualUnfundedCancellation
   *          the annualUnfundedCancellation to set
   */
  public void setAnnualUnfundedCancellation(DollarAmountType annualUnfundedCancellation)
  {
    this.annualUnfundedCancellation = annualUnfundedCancellation;
  }


  /**
   * @return the annualCostAvoidance
   */
  public DollarAmountType getAnnualCostAvoidance()
  {
    return annualCostAvoidance;
  }


  /**
   * @param annualCostAvoidance
   *          the annualCostAvoidance to set
   */
  public void setAnnualCostAvoidance(DollarAmountType annualCostAvoidance)
  {
    this.annualCostAvoidance = annualCostAvoidance;
  }


  /**
   * @return the annualPercentCostAvoidance
   */
  public DollarAmountType getAnnualPercentCostAvoidance()
  {
    return annualPercentCostAvoidance;
  }


  /**
   * @param annualPercentCostAvoidance
   *          the annualPercentCostAvoidance to set
   */
  public void setAnnualPercentCostAvoidance(DollarAmountType annualPercentCostAvoidance)
  {
    this.annualPercentCostAvoidance = annualPercentCostAvoidance;
  }


  /**
   * @return the multiYearQuantity
   */
  public DollarAmountType getMultiYearQuantity()
  {
    return multiYearQuantity;
  }


  /**
   * @param multiYearQuantity
   *          the multiYearQuantity to set
   */
  public void setMultiYearQuantity(DollarAmountType multiYearQuantity)
  {
    this.multiYearQuantity = multiYearQuantity;
  }


  /**
   * @return the multiYearTotal
   */
  public DollarAmountType getMultiYearTotal()
  {
    return multiYearTotal;
  }


  /**
   * @param multiYearTotal
   *          the multiYearTotal to set
   */
  public void setMultiYearTotal(DollarAmountType multiYearTotal)
  {
    this.multiYearTotal = multiYearTotal;
  }


  /**
   * @return the multiYearFundedCancellation
   */
  public DollarAmountType getMultiYearFundedCancellation()
  {
    return multiYearFundedCancellation;
  }


  /**
   * @param multiYearFundedCancellation
   *          the multiYearFundedCancellation to set
   */
  public void setMultiYearFundedCancellation(DollarAmountType multiYearFundedCancellation)
  {
    this.multiYearFundedCancellation = multiYearFundedCancellation;
  }


  /**
   * @return the multiYearUnfundedCancellation
   */
  public DollarAmountType getMultiYearUnfundedCancellation()
  {
    return multiYearUnfundedCancellation;
  }


  /**
   * @param multiYearUnfundedCancellation
   *          the multiYearUnfundedCancellation to set
   */
  public void setMultiYearUnfundedCancellation(DollarAmountType multiYearUnfundedCancellation)
  {
    this.multiYearUnfundedCancellation = multiYearUnfundedCancellation;
  }


  /**
   * @return the multiYearCostAvoidance
   */
  public DollarAmountType getMultiYearCostAvoidance()
  {
    return multiYearCostAvoidance;
  }


  /**
   * @param multiYearCostAvoidance
   *          the multiYearCostAvoidance to set
   */
  public void setMultiYearCostAvoidance(DollarAmountType multiYearCostAvoidance)
  {
    this.multiYearCostAvoidance = multiYearCostAvoidance;
  }


  /**
   * @return the multiYearPercentCostAvoidance
   */
  public DollarAmountType getMultiYearPercentCostAvoidance()
  {
    return multiYearPercentCostAvoidance;
  }


  /**
   * @param multiYearPercentCostAvoidance
   *          the multiYearPercentCostAvoidance to set
   */
  public void setMultiYearPercentCostAvoidance(DollarAmountType multiYearPercentCostAvoidance)
  {
    this.multiYearPercentCostAvoidance = multiYearPercentCostAvoidance;
  }
}
