package mil.dtic.cbes.enums;


/**
 *
 */
public enum P10CostElementCategoryType
{
    CFE,
    GFE,
    EOQ,
    Other,
    Custom,
}
