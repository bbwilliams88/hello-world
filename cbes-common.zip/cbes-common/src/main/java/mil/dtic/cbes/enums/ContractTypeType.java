package mil.dtic.cbes.enums;


public enum ContractTypeType
{
  FP, CPIF, CPAF, CPFF, FFP, TBD, Various;
}
