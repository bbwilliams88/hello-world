package mil.dtic.cbes.p40.vo;

import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.ObjectContext;

/**
 *
 */
public interface CompoSplitParent
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    List<CompoSplit> getComponentSplitList();
    CompoSplit addCompoSplit(String serviceComponent);
    CompoSplit getCompoSplit(String serviceComponent);
    void removeCompoSplit(CompoSplit cs);

    ObjectContext getObjectContext();

    LineItem getParentLineItem();

    String getComponentSplitRemarks();
    void setComponentSplitRemarks(String s);

    Quantities getCompoSplitParentQuantities();

    Costs getCompoSplitCosts();

    Costs getQuantities();

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    void sortByDisplayOrder(String string);

    default void clearOutYears()
    {
        for (CompoSplit componentSplit : getComponentSplitList())
        {
            Costs.clearOutYears(componentSplit.getQuantities());
            Costs.clearOutYears(componentSplit.getTotalCosts());
        }
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    void addToComponentSplitList(CompoSplit cs);
    boolean jibx_hasComponentSplit();
    Iterator<CompoSplit> jibx_componentSplitIterator();
}
