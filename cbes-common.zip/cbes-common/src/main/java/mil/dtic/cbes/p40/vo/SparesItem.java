package mil.dtic.cbes.p40.vo;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._SparesItem;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class SparesItem extends _SparesItem  implements HasDisplayOrder, CostContainer, Equivalence<SparesItem>
{
  private static final long serialVersionUID = 1L;


  @Override
protected void onPostAdd()
  {
    setDisplayOrder(0);


    Costs cost = getObjectContext().newObject(Costs.class);
    cost.setType(CostRowType.TOTALCOST);
    this.setCosts(cost);
  }

  public void shiftForwardInTime(int years)
  {
    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
 }

  @Override
  public int equivalenceHashCode()
  {
    return new HashCodeBuilder().append(toLowerAndTrim(getName())).toHashCode();
  }

  @Override
  public boolean equivalentTo(SparesItem other)
  {
    return new EqualsBuilder().append(toLowerAndTrim(getName()), toLowerAndTrim(other.getName())).isEquals();
  }

  @Override
  public Costs getUnitCosts()
  {
    return null;
  }

  @Override
  public Costs getQuantities()
  {
    return null;
  }

  public boolean jibx_hasMDAPCode() {
    return getMdapCode() != null;
  }

}
