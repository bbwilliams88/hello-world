package mil.dtic.cbes.p40.vo;

import org.apache.cayenne.ObjectContext;

import mil.dtic.cbes.enums.StatusType;
import mil.dtic.cbes.p40.vo.auto._ResourceSummaryEntry;

/**
 *
 */
public class ResourceSummaryEntry extends _ResourceSummaryEntry
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    @Override
    public void setStatus(StatusType status)
    {
        if (status == StatusType.DELETED || status == StatusType.NEW)
            throw new IllegalArgumentException("Resource Summary Entry status may only be ACTIVE or INACTIVE.");
        else
            super.setStatus(status);
    }

//    public ResourceSummaryEntryType getEnum()
//    {
//        for (ResourceSummaryEntryType rset : ResourceSummaryEntryType.values())
//        {
//            if (rset.getDatabaseValue().equals(getTitle()))
//                return rset;
//        }
//        return null;
//    }

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    public static ResourceSummaryEntry fetchWithCode(ObjectContext context, String code)
    {
        return fetchOne(context, ResourceSummaryEntry.class, ResourceSummaryEntry.TITLE_PROPERTY, code);
    }

    public static ResourceSummaryEntry fetchWithCodeCached(ObjectContext context, String code)
    {
        return fetchOneCached(context, ResourceSummaryEntry.class, ResourceSummaryEntry.TITLE_PROPERTY, code);
    }

    @Override
    public String toString()
    {
        return "Object ID: "   + getObjectId() + ", " +
               "Description: " + getDescription() + ", " +
               "Status: "      + getStatus() + ", " +
               "Title: "       + getTitle() + ", " +
               "Type: "        + getType() + ", " +
               "Context: "     + getContext();
    }
}
