package mil.dtic.cbes.p40.vo;

public enum ProductionSupportFacilityProjectCostElementType {
	
	CONSTRUCTION, EQUIPMENT, EQUIPMENT_INSTALLATION, CONTRACTOR_SUPPORT, CORPS_OF_ENGINEERS_SUPPORT, OTHER_IN_HOUSE_SUPPORT, OTHER;
	
	

}
