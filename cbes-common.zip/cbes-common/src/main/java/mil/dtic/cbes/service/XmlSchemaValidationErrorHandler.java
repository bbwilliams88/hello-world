/*
 * $Id$
 */
package mil.dtic.cbes.service;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

public class XmlSchemaValidationErrorHandler extends DefaultHandler
{  
  protected List<String> errorList;
  protected List<String> warningList;

  public XmlSchemaValidationErrorHandler()
  {
    this.errorList = new ArrayList<String>();
    this.warningList = new ArrayList<String>();
  }
 
  public void error(SAXParseException e) throws SAXException
  {
    addError(e);
  }

  public void fatalError(SAXParseException e) throws SAXException
  {
    addError(e);
  }

  public void warning(SAXParseException e) throws SAXException
  {
    addWarning(e);
  }

  public void addError(SAXParseException e)
  {
    errorList.add(new XmlSchemaValidationMessage(e, ValidationMessage.SEVERITY_ERROR).toString());
  }

  public void addWarning(SAXParseException e)
  {
    errorList.add(new XmlSchemaValidationMessage(e, ValidationMessage.SEVERITY_WARNING).toString());
  }

  public List<String> getErrorList()
  {
    return this.errorList;
  }

  public List<String> getWarningList()
  {
    return this.warningList;
  }
    
}
