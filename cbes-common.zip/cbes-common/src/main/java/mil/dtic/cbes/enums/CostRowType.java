package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum CostRowType implements ExtendedEnumeration
{
  QUANTITY("Q"), UNITCOST("U"), TOTALCOST("C");


  private final String dbName;

  private CostRowType(String dbName)
  {
    this.dbName = dbName;
  }

  public String getDatabaseValue()
  {
    return dbName;
  }
}
