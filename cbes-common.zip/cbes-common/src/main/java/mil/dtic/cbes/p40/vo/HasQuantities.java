package mil.dtic.cbes.p40.vo;


/**
 *
 */
public interface HasQuantities extends HasContinuing
{
    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    Costs getQuantities();
    void setQuantities(Costs c);


    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasQuantity();
    
    public void jibx_setQuantities(Costs c);
}
