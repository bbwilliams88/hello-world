/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;

import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.BudgesContext;

public class JBCover extends JBDefaultSystemGeneratedPart
{
  private Constants.JBPredefinedLogoSource predefinedLogoSource;
  private String builtinLogoFileName;
  private String logoFileName;
  private String logoAbsoluteFileName;
  private String title;
  private Date date;
  private ServiceAgency serviceAgency;


  public JBCover()
  {
    setFileSetting(FileSetting.COVER);
    setTitle(fileSetting.COVER.getTitle());
  }


  public String getPdfBookmarkLabel()
  {
    return FileSetting.COVER.getTitle();
  }


  public FormattingResults createPdf() throws IOException, DocumentException, SQLException 
  {
    File coverPageLogoFile = null;
    if (logoAbsoluteFileName == null)
    {
      if(builtinLogoFileName == null)
        builtinLogoFileName = "TEST.png";
      coverPageLogoFile = new File(BudgesContext.getConfigService().getLogoImagesFolder(), builtinLogoFileName);
    }
    else
    {
      coverPageLogoFile = new File(logoAbsoluteFileName);
    }

    docCreationParams.setLogoSource(coverPageLogoFile.toURI().toURL().toString());
    FormattingResults fr = super.createPdf();
    return fr;
  }


  public Constants.JBPredefinedLogoSource getPredefinedLogoSource()
  {
    return predefinedLogoSource;
  }


  public void setPredefinedLogoSource(Constants.JBPredefinedLogoSource predefinedLogoSource)
  {
    this.predefinedLogoSource = predefinedLogoSource;
  }


  public String getBuiltinLogoFileName()
  {
    return builtinLogoFileName;
  }


  public void setBuiltinLogoFileName(String builtinLogoFileName)
  {
    this.builtinLogoFileName = builtinLogoFileName;
  }


  public String getLogoFileName()
  {
    return logoFileName;
  }


  public void setLogoFileName(String logoFileName)
  {
    this.logoFileName = logoFileName;
  }


  public String getTitle()
  {
    return title;
  }


  public void setTitle(String title)
  {
    this.title = title;
  }


  public String getLogoAbsoluteFileName()
  {
    return logoAbsoluteFileName;
  }


  public void setLogoAbsoluteFileName(String logoAbsoluteFileName)
  {
    this.logoAbsoluteFileName = logoAbsoluteFileName;
  }


  public Date getDate()
  {
    return date;
  }


  public void setDate(Date date)
  {
    this.date = date;
  }


  public ServiceAgency getServiceAgency()
  {
    return serviceAgency;
  }


  public void setServiceAgency(ServiceAgency serviceAgency)
  {
    this.serviceAgency = serviceAgency;
  }


}
