package mil.dtic.cbes.service;

import java.util.List;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.dao.CachingDAO;
import mil.dtic.utility.CbesLogFactory;

public class CacheService
{
  private static final Logger log = CbesLogFactory.getLog(CacheService.class);

  private final List<CachingDAO> daos;
  
  public CacheService(List<CachingDAO> daos)
  {
    this.daos = daos;
  }
  
  public void nukeCaches()
  {
    log.trace("nukeCaches");
    if (daos!=null)
      for (CachingDAO dao : daos)
        dao.nukeCache();
  }
}
