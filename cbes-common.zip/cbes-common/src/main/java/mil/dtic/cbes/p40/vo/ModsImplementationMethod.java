package mil.dtic.cbes.p40.vo;

import static java.math.BigDecimal.ZERO;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.logging.LogFactory;

import mil.dtic.cbes.enums.BudgetYearType;
import mil.dtic.cbes.enums.InstallationScheduleType;
import mil.dtic.cbes.p40.vo.auto._ModsImplementationMethod;
import mil.dtic.cbes.p40.vo.util.EnumPredicate;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.utility.CbesLogFactory;

public class ModsImplementationMethod extends _ModsImplementationMethod implements HasDisplayOrder, CostContainer
{
    private static final Logger log = CbesLogFactory.getLog(ModsImplementationMethod.class);
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0);
    }

    /***********************************************************************/
    /*** Business Logic / Custom Accessors                               ***/
    /***********************************************************************/

    public InstallationCost getBy1()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.BY1, InstallationCost.YEAR_PROPERTY));
    }

    public void setBy1(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.BY1);
    }

    public InstallationCost getBy2()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.BY2, InstallationCost.YEAR_PROPERTY));
    }

    public void setBy2(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.BY2);
    }

    public InstallationCost getBy3()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.BY3, InstallationCost.YEAR_PROPERTY));
    }

    public void setBy3(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.BY3);
    }

    public InstallationCost getBy4()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.BY4, InstallationCost.YEAR_PROPERTY));
    }

    public void setBy4(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.BY4);
    }

    public InstallationCost getBy5()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.BY5, InstallationCost.YEAR_PROPERTY));
    }

    public void setBy5(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.BY5);
    }

    public InstallationCost getToComplete()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.ToComplete, InstallationCost.YEAR_PROPERTY));
    }

    public void setToComplete(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.ToComplete);
    }

    public InstallationCost getTotal()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.Total, InstallationCost.YEAR_PROPERTY));
    }

    public void setTotal(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.Total);
    }

    @Override
    public Costs getCosts()
    {
        if (getTotal() != null)
            return getTotal().getTotalCosts();
        return null;
    }

    public void generateNonorganicCostRows()
    {
        if (isOrganic())
            return;
        if (getPriorYears() == null)
            setPriorYears(getObjectContext().newObject(InstallationCost.class));
        if (getPriorYear() == null)
            setPriorYear(getObjectContext().newObject(InstallationCost.class));
        if (getCurrentYear() == null)
            setCurrentYear(getObjectContext().newObject(InstallationCost.class));
        if (getBy1() == null)
            setBy1(getObjectContext().newObject(InstallationCost.class));
        if (getBy2() == null)
            setBy2(getObjectContext().newObject(InstallationCost.class));
        if (getBy3() == null)
            setBy3(getObjectContext().newObject(InstallationCost.class));
        if (getBy4() == null)
            setBy4(getObjectContext().newObject(InstallationCost.class));
        if (getBy5() == null)
            setBy5(getObjectContext().newObject(InstallationCost.class));
        if (getToComplete() == null)
            setToComplete(getObjectContext().newObject(InstallationCost.class));
        if (getTotal() == null)
            setTotal(getObjectContext().newObject(InstallationCost.class));
    }

    public void cleanupInorganicCostRows()
    {
        for (InstallationCost ic : new ArrayList<InstallationCost>(getInstallationCosts()))
        {
            if (ic.getCosts().isEmpty() && ic.getQuantities().isEmpty())
            {
                removeFromInstallationCosts(ic);
                getObjectContext().deleteObjects(ic);
            }
        }
    }

    @Override
    public Costs getUnitCosts()
    {
        if (getTotal() != null)
            return getTotal().getUnitCosts();
        return null;
    }

    @Override
    public Costs getQuantities()
    {
        if (getTotal() != null)
            return getTotal().getQuantities();
        return null;
    }

    public boolean isOrganic()
    {
        return getOrganicQuantity() != null;
    }

    public boolean isNonOrganic()
    {
        return getOrganicQuantity() == null;
    }

    public List<CostContainer> getInstallationCostsForRollup()
    {
        List<CostContainer> l = new ArrayList<CostContainer>();

        if (getPriorYears() != null)
            l.add(getPriorYears());
        if (getPriorYear() != null)
            l.add(getPriorYear());
        if (getCurrentYear() != null)
            l.add(getCurrentYear());
        if (getBy1() != null)
            l.add(getBy1());
        if (getBy2() != null)
            l.add(getBy2());
        if (getBy3() != null)
            l.add(getBy3());
        if (getBy4() != null)
            l.add(getBy4());
        if (getBy5() != null)
            l.add(getBy5());
        if (getToComplete() != null)
            l.add(getToComplete());
        return l;
    }

    @Override
    public List<InstallationCost> getInstallationCosts()
    {
        List<InstallationCost> l = new ArrayList<InstallationCost>(super.getInstallationCosts());
        new Ordering(InstallationCost.YEAR_PROPERTY, SortOrder.ASCENDING).orderList(l);
        return l;
    }

    public boolean isContainingOutYears()
    {
      boolean hasOutYears = false;
      for (InstallationCost ic : getInstallationCosts())
      {
        if ((ic.getCosts() != null && ic.getCosts().hasOutYears()) || (ic.getQuantities() != null && ic.getQuantities().hasOutYears()))
        {
          hasOutYears = true;
          break;
        }
      }
      
      return hasOutYears;
    }
    
    public InstallationSchedule getIn()
    {
        return commonsfind(getInstallationSchedules(), new EnumPredicate(InstallationScheduleType.IN, InstallationSchedule.TYPE_PROPERTY));
    }

    public void setIn(InstallationSchedule is)
    {
        InstallationSchedule existing = getIn();
        if (existing == null && is != null)
        {
            is.setType(InstallationScheduleType.IN);
            addToInstallationSchedules(is);
        }
        else
        {
            log.debug("Don't use this to replace existing InstallationSchedules");
        }
    }

    public InstallationSchedule getOut()
    {
        return commonsfind(getInstallationSchedules(), new EnumPredicate(InstallationScheduleType.OUT, InstallationSchedule.TYPE_PROPERTY));
    }

    public void setOut(InstallationSchedule is)
    {
        InstallationSchedule existing = getOut();
        if (existing == null && is != null)
        {
            is.setType(InstallationScheduleType.OUT);
            addToInstallationSchedules(is);
        }
        else
        {
            log.debug("Don't use this to replace existing InstallationSchedules");
        }
    }

    private void setFixedIc(InstallationCost ic, BudgetYearType year)
    {
        InstallationCost existing = commonsfind(super.getInstallationCosts(), new EnumPredicate(year, InstallationCost.YEAR_PROPERTY));
        if (existing == null && ic != null)
        {
            ic.setYear(year);
            addToInstallationCosts(ic);
        }
        else
            log.debug("Don't use this to replace existing InstallationCosts");
    }

    public InstallationCost getPriorYears()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.PriorYears, InstallationCost.YEAR_PROPERTY));
    }

    public void setPriorYears(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.PriorYears);
    }

    public InstallationCost getPriorYear()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.PriorYear, InstallationCost.YEAR_PROPERTY));
    }

    public void setPriorYear(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.PriorYear);
    }

    public InstallationCost getCurrentYear()
    {
        return commonsfind(super.getInstallationCosts(), new EnumPredicate(BudgetYearType.CurrentYear, InstallationCost.YEAR_PROPERTY));
    }

    public void setCurrentYear(InstallationCost ic)
    {
        setFixedIc(ic, BudgetYearType.CurrentYear);
    }

    @Override
    public void setOrganicQuantity(BigDecimal organicQuantity)
    {
        if (organicQuantity == null || StringUtils.equals(organicQuantity.toString(), ""))
            super.setOrganicQuantity(ZERO);
        else
            super.setOrganicQuantity(organicQuantity);
    }

    @Override
    public void shiftForwardInTime(int years)
    {
        // Vertical shift
        for (int i = 0; i < years; i++)
        {
            InstallationCost oldApy = null;
            InstallationCost newApy = null;

            for (InstallationCost aCost : getInstallationCosts())
            {
                if (aCost.getYear() != BudgetYearType.ToComplete && aCost.getYear() != BudgetYearType.Total)
                {
                    BudgetYearType year = aCost.getYear().getShifted(-1);

                    if (year != null)
                    {
                        aCost.setYear(year);

                        if (year == BudgetYearType.PriorYears)
                            newApy = aCost;
                    }
                    else
                    {
                        oldApy = aCost;
                    }
                }
            }

            if (oldApy != null && newApy != null)
            {
                Costs oldTotalCosts = oldApy.getTotalCosts();
                Costs oldQuantities = oldApy.getQuantities();
                Costs newTotalCosts = newApy.getTotalCosts();
                Costs newQuantities = newApy.getQuantities();

                carryOverApy(oldTotalCosts, newTotalCosts);
                carryOverApy(oldQuantities, newQuantities);
            }

            // remove after shift
            if (oldApy != null)
            {
                removeFromInstallationCosts(oldApy);
                oldApy.delete();
            }

            setBy5(getObjectContext().newObject(InstallationCost.class));
        }

        for (InstallationCost installationCost : getInstallationCosts())
            installationCost.shiftForwardInTime(years);

        for (InstallationSchedule insSched : getInstallationSchedules())
            insSched.shiftForwardInTime(years);
    }

    private void carryOverApy(Costs oldCosts, Costs newCosts)
    {
        newCosts.setPriorYears(getCombinedValues(oldCosts.getPriorYears(), newCosts.getPriorYears()));
        newCosts.setPriorYearsFootnote(oldCosts.getPriorYearsFootnote());
        newCosts.setPriorYear(getCombinedValues(oldCosts.getPriorYear(), newCosts.getPriorYear()));
        newCosts.setPriorYearFootnote(oldCosts.getPriorYearFootnote());
        newCosts.setCurrentYear(getCombinedValues(oldCosts.getCurrentYear(), newCosts.getCurrentYear()));
        newCosts.setCurrentYearFootnote(oldCosts.getCurrentYearFootnote());
        newCosts.setBy1(getCombinedValues(oldCosts.getBy1(), newCosts.getBy1()));
        newCosts.setBy1Footnote(oldCosts.getBy1Footnote());
        newCosts.setBy1Base(getCombinedValues(oldCosts.getBy1Base(), newCosts.getBy1Base()));
        newCosts.setBy1BaseFootnote(oldCosts.getBy1BaseFootnote());
        newCosts.setBy1Ooc(getCombinedValues(oldCosts.getBy1Ooc(), newCosts.getBy1Ooc()));
        newCosts.setBy1OocFootnote(oldCosts.getBy1OocFootnote());
        newCosts.setBy2(getCombinedValues(oldCosts.getBy2(), newCosts.getBy2()));
        newCosts.setBy2Footnote(oldCosts.getBy2Footnote());
        newCosts.setBy3(getCombinedValues(oldCosts.getBy3(), newCosts.getBy3()));
        newCosts.setBy3Footnote(oldCosts.getBy3Footnote());
        newCosts.setBy4(getCombinedValues(oldCosts.getBy4(), newCosts.getBy4()));
        newCosts.setBy4Footnote(oldCosts.getBy4Footnote());
        newCosts.setBy5(getCombinedValues(oldCosts.getBy5(), newCosts.getBy5()));
        newCosts.setBy5Footnote(oldCosts.getBy5Footnote());
        newCosts.setToComplete(getCombinedValues(oldCosts.getToComplete(), newCosts.getToComplete()));
        newCosts.setToCompleteFootnote(oldCosts.getToCompleteFootnote());
        newCosts.setTotal(getCombinedValues(oldCosts.getTotal(), newCosts.getTotal()));
        newCosts.setTotalCostFootnote(oldCosts.getTotalCostFootnote());
    }

    private BigDecimal getCombinedValues(BigDecimal oldValue, BigDecimal newValue)
    {
        BigDecimal returnValue = newValue;

        if (newValue != null && oldValue != null)
            returnValue = newValue.add(oldValue);
        else if (newValue == null && oldValue != null)
            returnValue = oldValue;

        return returnValue;
    }

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasInstallationCost()
    {
        for(InstallationCost installationTableRow : super.getInstallationCosts())
        {
          if (installationTableRow.hasAny())
            return true;
        }
        return false;
    }

    public boolean jibx_hasInstallationSchedule()
    {
        return CollectionUtils.isNotEmpty(getInstallationSchedules());
    }

    public boolean jibx_hasImplementationMethodName()
    {
      return !StringUtils.isEmpty(getName());
    }
}
