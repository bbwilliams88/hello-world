package mil.dtic.cbes.p40.vo;

import java.util.List;

public interface RollupParent extends CostContainer
{

  public List<? extends CostContainer> getChildren();

}
