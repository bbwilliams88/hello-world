/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import java.io.IOException;
import java.util.List;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.PdfUtil;

public class JBSupplementalDocCollection extends JBDefaultUserSuppliedPart{
  List<JBSupplementalDoc> supplementalDocList;

  public JBSupplementalDocCollection(){
    setFileSetting(FileSetting.SUPPLEMENTAL_DOC_COLLECTION);
    setTitle(FileSetting.SUPPLEMENTAL_DOC_COLLECTION.getTitle());
  }

  protected int setPdfAbsoluteStartPages(int absolutePageNumber) {
      setPdfAbsoluteStartPage(absolutePageNumber);
      
      if (supplementalDocList != null) {
          for (JBSupplementalDoc supplementalDoc : supplementalDocList)  {
              supplementalDoc.setPdfAbsoluteStartPage(absolutePageNumber);
              absolutePageNumber += supplementalDoc.getPdfTotalPageCount();
          }
    }
    return absolutePageNumber;
  }

  // TODO remove this method, do we still need?
  public void updateTotalPageCount___() throws IOException {
      int totalPageCount = 0;
      if (supplementalDocList != null) {
          for (JBSupplementalDoc supplementalDoc : supplementalDocList) {
              supplementalDoc.setPdfTotalPageCount(PdfUtil.getNumberOfPagesInPdf(getAbsoluteFileName()));
              totalPageCount += supplementalDoc.getPdfTotalPageCount();
          }
          
          setPdfTotalPageCount(totalPageCount);
      }
  }

  public List<JBSupplementalDoc> getSupplementalDocList() {
      return supplementalDocList;
  }

  public void setSupplementalDocList(List<JBSupplementalDoc> supplementalDocList) {
      this.supplementalDocList = supplementalDocList;
  }

}
