package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.Cayenne;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.ValidationExemption.StatusType;
import mil.dtic.cbes.p40.vo.auto._ValidationRule;
import mil.dtic.utility.CbesLogFactory;

public class ValidationRule extends _ValidationRule
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(ValidationRule.class);

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * Checks to see if a rule is exempt from validations based upon
     * organization.
     * @param agency - vo.ServiceAgency
     * @return boolean - boolean
     */
    public boolean isExempt(ServiceAgency agency) {
    	if(null == agency){
    		log.warn("ServiceAgency argument is null; returning false.");
    		
    		return false;
    	}
    	
        for (ServiceAgency organization : getExemptOrganizations()){
            if (StringUtils.equals(agency.getName(), organization.getName())){
                log.debug(String.format("validation rule: %s %s is exempt for org: %s", getKey(), getNumber(), organization.getName()));
            	return true;
            }
        }
        return false;
    }

    /**
     * Checks to see if a rule is NOT exempt from validations based upon
     * organization.
     *
     * @param item
     *            A LineItem is expected.
     * @return True if item is a LineItem and the rule is NOT exempt, false
     *         otherwise.
     */
    public boolean isNotExempt(ServiceAgency item)
    {   	
    	log.info(String.format("Determining exemption for ServiceAgency %s", (item == null ? "ServiceAgency arg is null!" : item.getName())));
        
    	return !isExempt(item);
    }

    public List<ServiceAgency> getExemptOrganizations()
    {
        List<ServiceAgency> exemptOrganizations = new ArrayList<>();

        for (ValidationExemption validationExemption : getValidationExemptions()){
            if (validationExemption.isExempt()){
                exemptOrganizations.add(validationExemption.getOrganization());
            }
        }

        return exemptOrganizations;
    }

    public ValidationExemption addExemptOrganization(ServiceAgency organization, P40User user)
    {
        ServiceAgency       organizationInContext = Cayenne.objectForPK(getObjectContext(), ServiceAgency.class, Cayenne.intPKForObject(organization));
        P40User             userInContext         = Cayenne.objectForPK(getObjectContext(), P40User.class, Cayenne.intPKForObject(user));
        ValidationExemption validationExemption   = findExemptOrganization(organization);

        // If exempt organization record already exists, re-activate it if inactive.
        if (validationExemption != null)
        {
            if (validationExemption.getStatus() == StatusType.INACTIVE)
                validationExemption.activate(userInContext);
        }
        else
        {
            validationExemption = getObjectContext().newObject(ValidationExemption.class);

            validationExemption.activate(userInContext);
            validationExemption.setOrganization(organizationInContext);
            validationExemption.setValidationRule(this);
        }

        return validationExemption;
    }

    public void removeExemptOrganization(ServiceAgency organization, P40User user)
    {
        P40User             userInContext       = Cayenne.objectForPK(getObjectContext(), P40User.class, Cayenne.intPKForObject(user));
        ValidationExemption validationExemption = findExemptOrganization(organization);

        if (validationExemption != null){
            validationExemption.deactivate(userInContext);
        }
    }

    private ValidationExemption findExemptOrganization(ServiceAgency organization){
        for (ValidationExemption validationExemption : getValidationExemptions()){
            if (StringUtils.equals(validationExemption.getOrganization().getName(), organization.getName())){
                return validationExemption;
            }
        }

        return null;
    }

    // public void deleteExemptOrganization(ServiceAgency organization) ?

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    public static List<ValidationRule> fetchAll(ObjectContext objectContext)
    {
        return fetchAllForClass(objectContext, ValidationRule.class);
    }

    @SuppressWarnings("unchecked")
    public static List<ValidationRule> fetchAllWithClass(ObjectContext objectContext)
    {
        SelectQuery query = new SelectQuery(ValidationRule.class);

        query.addPrefetch(ValidationRule.VALIDATION_CLASS_RELATIONSHIP_PROPERTY);

        return objectContext.performQuery(query);
    }
}
