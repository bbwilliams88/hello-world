/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;


public class R1D extends JBDefaultSystemGeneratedPart
{
  public R1D()
  {
    this(null);
  }
  
  public R1D(String titlePrefix)
  {
    setFileSetting(FileSetting.R1D);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.R1D.getTitle()));    
  }
}
