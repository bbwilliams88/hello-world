package mil.dtic.cbes.xml.merge;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;

import mil.dtic.cbes.xml.merge.ExhibitListMerge.BudgetType;
import mil.dtic.utility.CbesLogFactory;

/**
 * 
 * Helper class to discover meta data attributes about a xml file merge candidate.
 *
 */
public class MergeCandidate {
  private static final Logger log = CbesLogFactory.getLog(MergeCandidate.class);
  
  private String description;
  private int exhibitCount;

  public MergeCandidate(Document doc) {
    description = ExhibitListMerge.NOT_A_VALID_EXHIBIT_LIST;
    try {
    configure(doc);
    } catch(XPathExpressionException e) {
      log.error("Unable to extract metadata from exhibit XML: " + e.getMessage());
    }
    
  }
  
  public String getDescription() {
    return description;
  }
  
  public int exhibitCount() {
    return exhibitCount;
  }
  
  private void configure(Document doc) throws XPathExpressionException {
    XPath xPath = XPathFactory.newInstance().newXPath();
    
    // count exhibits
    XPathExpression xPathExpr = xPath.compile("count(//LineItemList/LineItem)");
    Double lineItemCount = (Double) xPathExpr.evaluate(doc, XPathConstants.NUMBER);
    log.debug("Found " + lineItemCount + " line items.");
    xPathExpr = xPath.compile("count(//ProgramElementList/ProgramElement)");
    Double programElementCount = (Double) xPathExpr.evaluate(doc, XPathConstants.NUMBER);
    log.debug("Found " + programElementCount + " program elements.");
    
    if (lineItemCount == 0 && programElementCount == 0) {
      log.warn("No Line Items or Program Elements found.");
      return;
    }
    
    // determine budget type
    BudgetType type = (lineItemCount > 0) ? BudgetType.P40 : BudgetType.R2;
    exhibitCount = lineItemCount.intValue() + programElementCount.intValue();
    
    // then determine service agency 
    xPathExpr = xPath.compile("/descendant::ServiceAgencyName[1]");
    String serviceAgencyName = (String) xPathExpr.evaluate(doc, XPathConstants.STRING);
    
    // create description from budget type and service name
    description = createDescriptionFor(serviceAgencyName, type);
  }
  
  private String createDescriptionFor(String serviceAgency, BudgetType type) {
    String description = ExhibitListMerge.NOT_A_VALID_EXHIBIT_LIST;

    // organization
    String organization = "_" + serviceAgency.replace(" ", "_") + "_";
    if (!organization.equalsIgnoreCase(ExhibitListMerge.ARMY) &&
        !organization.equalsIgnoreCase(ExhibitListMerge.NAVY) &&
        !organization.equalsIgnoreCase(ExhibitListMerge.AIR_FORCE)) {
      organization = ExhibitListMerge.DW;
    }
    
    // type
    String budgetType = (type == BudgetType.R2) ? ExhibitListMerge.RDTE : ExhibitListMerge.LI;
    description = organization + budgetType;

    return description;
  }

}
