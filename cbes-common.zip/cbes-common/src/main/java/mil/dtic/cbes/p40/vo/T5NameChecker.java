package mil.dtic.cbes.p40.vo;

/**
 * This class is used to enforce non-null names for Tapestry 5; Because Tapestry
 * errors can cause data to shift in the PAjaxFormLoop, they should be used
 * sparingly; All values that are required should be validated with business
 * rules; Future versions of tapestry may allow for Object Persistence after a
 * Tapestry error;
 */
public interface T5NameChecker
{
    public String getT5Name();
    public void setT5Name(String nameTemp);
}
