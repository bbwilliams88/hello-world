package mil.dtic.cbes.dto;

import java.math.BigDecimal;

public class P1DataValidationBean
{
  private String lineNumber;
  private String costType;
  private String costTypeTitle;
  private String addNonAdd;
  private BigDecimal pyAmount;
  private BigDecimal cyAmount;
  private BigDecimal by1BaseAmount;
  private BigDecimal by1OOCAmount;  
  private BigDecimal by1Amount;
  private BigDecimal by2Amount;
  private BigDecimal by3Amount;
  private BigDecimal by4Amount;
  private BigDecimal by5Amount;
  
  public P1DataValidationBean(){}

  public String getLineNumber() {
    return lineNumber;
  }

  public void setLineNumber(String lineNumber) {
    this.lineNumber = lineNumber;
  }

  public String getCostType() {
    return costType;
  }

  public void setCostType(String costType) {
    this.costType = costType;
  }

  public String getCostTypeTitle() {
    return costTypeTitle;
  }

  public void setCostTypeTitle(String costTypeTitle) {
    this.costTypeTitle = costTypeTitle;
  }

  public String getAddNonAdd() {
    return addNonAdd;
  }

  public void setAddNonAdd(String addNonAdd) {
    this.addNonAdd = addNonAdd;
  }

  public BigDecimal getPyAmount() {
    return pyAmount;
  }

  public void setPyAmount(BigDecimal pyAmount) {
    this.pyAmount = pyAmount;
  }

  public BigDecimal getCyAmount() {
    return cyAmount;
  }

  public void setCyAmount(BigDecimal cyAmount) {
    this.cyAmount = cyAmount;
  }

  public BigDecimal getBy1BaseAmount() {
    return by1BaseAmount;
  }

  public void setBy1BaseAmount(BigDecimal by1BaseAmount) {
    this.by1BaseAmount = by1BaseAmount;
  }

  public BigDecimal getBy1OOCAmount() {
    return by1OOCAmount;
  }

  public void setBy1OOCAmount(BigDecimal by1oocAmount) {
    by1OOCAmount = by1oocAmount;
  }

  public BigDecimal getBy1Amount() {
    return by1Amount;
  }

  public void setBy1Amount(BigDecimal by1Amount) {
    this.by1Amount = by1Amount;
  }

  public BigDecimal getBy2Amount() {
    return by2Amount;
  }

  public void setBy2Amount(BigDecimal by2Amount) {
    this.by2Amount = by2Amount;
  }

  public BigDecimal getBy3Amount() {
    return by3Amount;
  }

  public void setBy3Amount(BigDecimal by3Amount) {
    this.by3Amount = by3Amount;
  }

  public BigDecimal getBy4Amount() {
    return by4Amount;
  }

  public void setBy4Amount(BigDecimal by4Amount) {
    this.by4Amount = by4Amount;
  }

  public BigDecimal getBy5Amount() {
    return by5Amount;
  }

  public void setBy5Amount(BigDecimal by5Amount) {
    this.by5Amount = by5Amount;
  }

  @Override
  public String toString() {
    return String.format(
        "P1DataValidationBean [lineNumber=%s, costType=%s, costTypeTitle=%s, addNonAdd=%s, "
        + "pyAmount=%s, cyAmount=%s, by1BaseAmount=%s, by1OOCAmount=%s, by1Amount=%s, by2Amount=%s, "
        + "by3Amount=%s, by4Amount=%s, by5Amount=%s]", lineNumber, costType, costTypeTitle, addNonAdd, 
        pyAmount, cyAmount, by1BaseAmount, by1OOCAmount, by1Amount, by2Amount, by3Amount, by4Amount, by5Amount);
  }
}
