/*
 * $Id$
 */
package mil.dtic.cbes.jb;

public class JBDefaultUserSuppliedPart extends JBPart
{

}
