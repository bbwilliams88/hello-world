package mil.dtic.cbes.enums;

import java.math.BigDecimal;

import org.apache.cayenne.ExtendedEnumeration;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

public enum QuantityUnitType implements ExtendedEnumeration
{
  Each("1"), Thousands("1000"), Millions("1000000");
  
  private static final Logger log = CbesLogFactory.getLog(QuantityUnitType.class);
  private final String dbName;

  private QuantityUnitType(String dbName)
  {
    this.dbName = dbName;
  }

  public String getXmlName()
  {
    return toString();
  }
  
  public String getDatabaseValue()
  {
    return dbName;
  }
  
  public BigDecimal getQuantityInEach(BigDecimal quantity)
  {
    switch (this)
    {
      case Each:
        return quantity;
      case Thousands:
        return quantity.multiply(new BigDecimal("1000"));
      case Millions:
        return quantity.multiply(new BigDecimal("1000000"));
      default:
        RuntimeException e = new RuntimeException("This should never happen, if it does then a new enum value has been added to QuantityUnitType without updating this method");
        log.error("This is not supposed to happen", e);
        throw e;
    }
  }
}
