package mil.dtic.cbes.p40.vo;

import java.util.Iterator;

import mil.dtic.cbes.p40.vo.jibx.CostImpl;


//Used for validator math
public class CostListExtendedImpl2 implements CostListExtended, Iterable<Cost>
{
  private Cost priorYears = new CostImpl();
  private Cost priorYear = new CostImpl();
  private Cost currentYear = new CostImpl();
  private Cost by1Base = new CostImpl();
  private Cost by1Ooc = new CostImpl();
  private Cost by1 = new CostImpl();
  private Cost by2 = new CostImpl();
  private Cost by3 = new CostImpl();
  private Cost by4 = new CostImpl();
  private Cost by5 = new CostImpl();
  private Cost toComplete = new CostImpl();
  private Cost total = new CostImpl();
  private boolean continuing;


  public CostListExtendedImpl2()
  {

  }


  @Override
  public Iterator<Cost> iterator()
  {
    return CostListImplUtils.getIterator(this);
  }


//  @Override
//  public boolean equals(Object o)
//  {
//    if (!(o instanceof CostListExtended)) return false;
//    CostListExtended other = (CostListExtended) o;
//    return CostListImplUtils.equals(this, other);
//  }
//
//
//  @Override
//  public int hashCode()
//  {
//    assert false : "hashCode not designed";
//    return 42; // any arbitrary constant will do
//  }


  public Cost getPriorYears()
  {
    return priorYears;
  }


  public void setPriorYears(Cost priorYears)
  {
    this.priorYears = priorYears;
  }


  public Cost getPriorYear()
  {
    return priorYear;
  }


  public void setPriorYear(Cost priorYear)
  {
    this.priorYear = priorYear;
  }


  public Cost getCurrentYear()
  {
    return currentYear;
  }


  public void setCurrentYear(Cost currentYear)
  {
    this.currentYear = currentYear;
  }


  public Cost getBy1Base()
  {
    return by1Base;
  }


  public void setBy1Base(Cost by1Base)
  {
    this.by1Base = by1Base;
  }


  public Cost getBy1Ooc()
  {
    return by1Ooc;
  }


  public void setBy1Ooc(Cost by1Ooc)
  {
    this.by1Ooc = by1Ooc;
  }


  public Cost getBy1()
  {
    return by1;
  }


  public void setBy1(Cost by1)
  {
    this.by1 = by1;
  }


  public Cost getBy2()
  {
    return by2;
  }


  public void setBy2(Cost by2)
  {
    this.by2 = by2;
  }


  public Cost getBy3()
  {
    return by3;
  }


  public void setBy3(Cost by3)
  {
    this.by3 = by3;
  }


  public Cost getBy4()
  {
    return by4;
  }


  public void setBy4(Cost by4)
  {
    this.by4 = by4;
  }


  public Cost getBy5()
  {
    return by5;
  }


  public void setBy5(Cost by5)
  {
    this.by5 = by5;
  }


  public Cost getToComplete()
  {
    return toComplete;
  }


  public void setToComplete(Cost toComplete)
  {
    this.toComplete = toComplete;
  }


  public Cost getTotal()
  {
    return total;
  }


  public void setTotal(Cost total)
  {
    this.total = total;
  }


  public boolean isContinuing()
  {
    return continuing;
  }


  public void setContinuing(boolean continuing)
  {
    this.continuing = continuing;
  }


  private Object tc(Cost c)
  {
    return c == null || c.getTotalCost() == null ? "" : c.getTotalCost();
  }


  @Override
public String toString()
  {
    String spc = " ";
    StringBuffer sb = new StringBuffer();
    sb.append("ALLPYS: ").append(tc(getPriorYears())).append(spc);
    sb.append("PY: ").append(tc(getPriorYear())).append(spc);
    sb.append("CY: ").append(tc(getCurrentYear())).append(spc);
    sb.append("BY1 Base: ").append(tc(getBy1Base())).append(spc);
    sb.append("BY1 OOC: ").append(tc(getBy1Ooc())).append(spc);
    sb.append("BY1 Total: ").append(tc(getBy1())).append(spc);
    sb.append("BY2: ").append(tc(getBy2())).append(spc);
    sb.append("BY3: ").append(tc(getBy3())).append(spc);
    sb.append("BY4: ").append(tc(getBy4())).append(spc);
    sb.append("BY5: ").append(tc(getBy5())).append(spc);
    sb.append("To Complete: ").append(tc(getToComplete())).append(spc);
    sb.append("Total: ").append(tc(getTotal())).append(spc);
    return sb.toString();
  }
}