package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import mil.dtic.cbes.p40.vo.auto._DeliverySchedule;
import mil.dtic.cbes.p40.vo.wrappers.Equivalence;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

/**
 *
 */
public class DeliverySchedule extends _DeliverySchedule implements HasDisplayOrder, Equivalence<DeliverySchedule>
{
    private static final long serialVersionUID = 1L;

    private String xmlServiceComponentName;
    private String xmlServiceComponentNameFootnote;
    private String xmlAgency;


    /***********************************************************************/
    /*** Cayenne Callbacks                                               ***/
    /***********************************************************************/

    @Override
    protected void onPostAdd()
    {
        setDisplayOrder(0); // seems hacky
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return
     */
    public MonthlyDelivery getLastMonthlyDelivery()
    {
        return Collections.max(super.getMonthlyDeliveryList(), MonthlyDelivery.getMonthDeliveryComparator());
    }

//    public String getXmlScName()
//    {
//        return xmlScName;
//    }
//
//    public void setXmlScName(String xmlScName)
//    {
//        this.xmlScName = xmlScName;
//    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    public boolean jibx_hasMonthlyDeliveryList()
    {
        return CollectionUtils.isNotEmpty(getMonthlyDeliveriesWithAmounts());
    }

    public List<MonthlyDelivery> getMonthlyDeliveriesWithAmounts()
    {
      List<MonthlyDelivery> monthlyDeliveries = new ArrayList<MonthlyDelivery>();
      for (MonthlyDelivery monthlyDelivery : getMonthlyDeliveryList())
      {
        if (monthlyDelivery.isAmountExist())
          monthlyDeliveries.add(monthlyDelivery);
      }
      return monthlyDeliveries;
    }

    public Iterator<MonthlyDelivery> jibx_monthlyDeliveryListIterator()
    {
        return getMonthlyDeliveriesWithAmounts().iterator();
    }
        
    public boolean jibx_hasComponentSplit()
    {
        return CollectionUtils.isNotEmpty(super.getComponentSplit());
    }

    public Iterator<DeliverySchedule> jibx_ComponentSplitIterator()
    {
        return getIterator(super.getComponentSplit());
    }

    public void jibx_setServiceComponentName(String name)
    {
        xmlServiceComponentName = name; // cache the name for later use in an error message

        if (name != null)
            setServiceComponent(ServiceComponent.fetchWithTitle(getObjectContext(), name));
    }

    public String jibx_getServiceComponentName()
    {
        if (getServiceComponent() == null)
            return xmlServiceComponentName;

        return getServiceComponent().getTitle();
    }

    public void jibx_setServiceAgencyName(String name)
    {
        xmlAgency = name; // cache the name for later use in an error message

        if (name != null)
            setServiceAgency(ServiceAgency.fetchWithName(getObjectContext(), name));
    }

    public String jibx_getServiceAgencyName()
    {
        if (getServiceAgency() == null)
        {
            return xmlAgency;
        }
        return getServiceAgency().getName();
    }

    public boolean jibx_hasServiceAgencyName()
    {
        return getServiceAgency() != null;
    }

    public boolean jibx_hasServiceAgencySuffix()
    {
        return getAgencySuffix() != null;
    }

    public boolean jibx_hasName()
    {
        return jibx_getServiceComponentName() != null;
    }

    public boolean jibx_hasProcQuantity()
    {
        return getProcQuantity() != null;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    /**
     * HashCode based on Business Rule [E-XML-PROC#U135]
     *
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalenceHashCode()
     */
    @Override
    public int equivalenceHashCode()
    {
        HashCodeBuilder builder = new HashCodeBuilder();

        builder.append(getServiceAgency());
        builder.append(getHistoryPlanning());
        builder.append(getAgencySuffix());

        return builder.toHashCode();
    }

    /**
     * Equality based on Business Rule [E-XML-PROC#U135]
     *
     * @see mil.dtic.cbes.p40.vo.wrappers.Equivalence#equivalentTo(mil.dtic.cbes.p40.vo.wrappers.Equivalence)
     */
    @Override
    public boolean equivalentTo(DeliverySchedule obj)
    {
        if (this == obj)
            return true;
        else if (obj == null)
            return false;
        else if (getClass() != obj.getClass())
            return false;

        DeliverySchedule other   = obj;
        EqualsBuilder    builder = new EqualsBuilder();

        builder.append(getServiceAgency(), other.getServiceAgency());
        builder.append(getHistoryPlanning(), other.getHistoryPlanning());
        builder.append(getAgencySuffix(), other.getAgencySuffix());

        return builder.isEquals();
    }
}
