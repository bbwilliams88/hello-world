package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;

import mil.P40CayenneJibxFactory;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

/**
 * @author Nabil Ahmed
 * 
 * This class is a wrapper for a list of P10 Cost Elements under a custom category (for SCN support).
 * The reason for this class is to have the title of the custom category associated with the list so
 * that the Custom Category subtotal, which is tied to the P10AdvanceProcurement object, can be linked
 * to the list of Cost Elements in the custom category. This is not the best way to handle this, however
 * after investigating the level of effort and the risks of revamping the way categories are handled in 
 * P-10 Advance Procurement objects, this was minimized the risk of problems. 
 *
 */
public class P10AdvanceProcurementCustomCostElementCategory extends ArrayList<P10CostElement> implements HasDisplayOrder
{
	/**
   * 
   */
  private static final long serialVersionUID = 1L;
  private String title;
  private Integer displayOrder;
	private P10AdvanceProcurement advanceProcurement;
	private P10AdvanceProcurementCustomCategorySubtotal customCategorySubtotal;
	
	public P10AdvanceProcurementCustomCostElementCategory(String title, Integer displayOrder, P10AdvanceProcurement advanceProcurement)
	{
	  this.title = title;
	  this.displayOrder = displayOrder;
		this.advanceProcurement = advanceProcurement;
		if (advanceProcurement != null)
		  customCategorySubtotal = advanceProcurement.getCategorySubtotalByTitle(title);
		else
		  customCategorySubtotal = null;
	}
	
	public P10AdvanceProcurementCustomCostElementCategory()
	{
	  this.title = null;
	  this.advanceProcurement = null;
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public void setTitle(String title)
	{
		this.title = title;
	}

	public Integer getDisplayOrder()
	{
	  return displayOrder;
	}
	
	public void setDisplayOrder(Integer displayOrder)
	{
	  this.displayOrder = displayOrder;
	}
	
  public P10AdvanceProcurement getAdvanceProcurement()
  {
    return advanceProcurement;
  }

  public void setAdvanceProcurement(P10AdvanceProcurement advanceProcurement)
  {
    this.advanceProcurement = advanceProcurement;
  }
  
  public P10AdvanceProcurementCustomCategorySubtotal getCustomCategorySubtotal()
  {
    return customCategorySubtotal;
  }
  
  public void setCustomCategorySubtotal(P10AdvanceProcurementCustomCategorySubtotal customCategorySubtotal)
  {
    this.customCategorySubtotal = customCategorySubtotal;
  }
  
  public Costs getCategorySubtotalCosts()
  {
    return getCustomCategorySubtotal() == null ? null : getCustomCategorySubtotal().getSubtotal();
  }
  
  public void setCategorySubtotalCosts (Costs subtotalCosts)
  {
    if (getCustomCategorySubtotal() == null)
      setCustomCategorySubtotal(P40CayenneJibxFactory.p10AdvanceProcurementCustomCategorySubtotal());
    getCustomCategorySubtotal().setTitle(getTitle());
    getCustomCategorySubtotal().setP10AdvanceProcurement(getAdvanceProcurement());
    getCustomCategorySubtotal().setSubtotal(subtotalCosts);
  }
  
  public void addToCostElements(P10CostElement costElement)
  {
    if(costElement != null)
      costElement.setCustomCategoryTitle(getTitle());
    this.add(costElement);
  }
  
  public Iterator<P10CostElement> jibx_costElementIterator()
  {
    return this.iterator();
  }
  
  public boolean jibx_hasCategorySubtotalCosts()
  {
    if (getCategorySubtotalCosts() != null)
      return !getCategorySubtotalCosts().isEmpty();
    return false;
  }
}
