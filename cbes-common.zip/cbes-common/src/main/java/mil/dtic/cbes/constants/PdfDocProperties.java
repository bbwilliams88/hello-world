/*
 * $Id$
 */
package mil.dtic.cbes.constants;

public enum PdfDocProperties
{
  MASTER_JB(Constants.CBES_PDF_AUTHOR, "RDT&E Budget Item Master Justification Book"),   
  JB(Constants.CBES_PDF_AUTHOR, "RDT&E Budget Item Justification Book"), 
  R1SUMMARY(Constants.CBES_PDF_AUTHOR, "Exhibit R-1 Summary"), 
  R1(Constants.CBES_PDF_AUTHOR, "Exhibit R-1"), 
  R1C(Constants.CBES_PDF_AUTHOR, "Exhibit R-1C"), 
  R1D(Constants.CBES_PDF_AUTHOR, "Exhibit R-1D"), 
  R2(Constants.CBES_PDF_AUTHOR, "Exhibit R-2: RDT&E Budget Item Justification"), 
  R2A(Constants.CBES_PDF_AUTHOR, "Exhibit R-2A: RDT&E Project Justification"),
  R3(Constants.CBES_PDF_AUTHOR, "Exhibit R-3: RDT&E Project Justification"),
  R4(Constants.CBES_PDF_AUTHOR, "Exhibit R-4: RDT&E Project Justification"),
  R4A(Constants.CBES_PDF_AUTHOR, "Exhibit R-4A: RDT&E Project Justification"),
  R5(Constants.CBES_PDF_AUTHOR, "Exhibit R-5: RDT&E Project Justification"),
  P1(Constants.CBES_PDF_AUTHOR, "Exhibit P-1"),
  P1M(Constants.CBES_PDF_AUTHOR, "Exhibit P-1M"),  
  P1D(Constants.CBES_PDF_AUTHOR, "Exhibit P-1D"),
  SD_REPORT(Constants.CBES_PDF_AUTHOR, "Secondary Distribution Report"),
  P21_WALLCHART(Constants.CBES_PDF_AUTHOR, "Delivery Schedule Wall Chart");

  private final String author;
  private final String title;
  private final String subject;
  private final String keywords;


  private PdfDocProperties(String author, String title, String subject, String keywords)
  {
    this.author = author;
    this.title = title;
    this.subject = subject;
    this.keywords = keywords;
  }


  private PdfDocProperties(String author, String title)
  {
    this(author, title, null, null);
  }


  public String getAuthor()
  {
    return author;
  }


  public String getTitle()
  {
    return title;
  }


  public String getSubject()
  {
    return subject;
  }


  public String getKeywords()
  {
    return keywords;
  }


}
