package mil.dtic.cbes.xml.merge;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import mil.dtic.cbes.xml.merge.ExhibitListMerge.BudgetType;
import mil.dtic.utility.CbesLogFactory;

/**
 * Assists in determining a unique set of exhibits from an xml document.
 *
 * @author AZumkhaw
 *
 */
public class ExhibitDeduper {
  private static final Logger log = CbesLogFactory.getLog(ExhibitDeduper.class);
  private static final String[] LINE_ITEM_IDENTIFIERS
  = {"LineItemNumber","BudgetActivityNumber", "BudgetSubActivityNumber", "AppropriationNumber"};
  private static final String[] PROGRAM_ELEMENT_IDENTIFIERS
  = {"ProgramElementNumber","BudgetActivityNumber"};
  private static final String _NOT_FOUND = "_N_F";

  private Set<String> exhibitKeys = new TreeSet<String>();
  private XPath xPath;
  private DocumentBuilder builder;
  private int ignoredCount = 0;
  private int addedCount = 0;
  private String[] identifiers;

  public ExhibitDeduper(XPath xPath, DocumentBuilder builder, BudgetType budgetType) {
    this.xPath = xPath;
    this.builder = builder;
    switch (budgetType)
    {
    case P40:
      identifiers = LINE_ITEM_IDENTIFIERS;
      break;
    case R2:
      identifiers = PROGRAM_ELEMENT_IDENTIFIERS;
      break;
    default:
    }
  }

  /**
   * Return a copy of the exhibit node if it is unique to the set
   * of prior added nodes. Returns null if it is a duplicate.
   *
   * Determines uniqueness by looking at the Line Item or Program Element
   * identifiers.
   */
  public Node copyIfUnique(Node exhibit) {
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    Node importedNode = doc.importNode(exhibit, true);
    root.appendChild(importedNode);
    List<String> exhibitIdentifiers = new ArrayList<String>();
    for (String identifierElementName : identifiers) {
      exhibitIdentifiers.add(xpathKey(identifierElementName, doc));
    }
    String exhibitIdentifier = exhibitIdentifiers.stream().collect(Collectors.joining(":"));
    boolean unique = exhibitKeys.add(exhibitIdentifier);
    if (unique) { addedCount++; } else { ignoredCount++; };
    return unique ? importedNode : null;
  }

  public void debugInfo() {
    log.debug("Added " + addedCount + " of " + (addedCount + ignoredCount) + " exhibit(s). Ignored " + ignoredCount + " duplicate exhibit(s).");
  }

  /**
   * Construct an xpath to find an exhibit element's value and execute the xpath path.
   * Returns the element's value.
   */
  private String xpathKey(String elementName, Document doc) {
    String value = _NOT_FOUND;
    try {
      value = (String) xPath.compile("//"+elementName+"[1]/text()[1]").evaluate(doc, XPathConstants.STRING);
    }
    catch (XPathExpressionException e) {
      log.debug(e);
    }
    return value;
  }
}
