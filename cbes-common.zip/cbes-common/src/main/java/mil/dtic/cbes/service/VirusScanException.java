package mil.dtic.cbes.service;

import java.util.List;

public class VirusScanException extends Exception
{

  private final List<ValidationMessage> errorsList;


  public VirusScanException(List<ValidationMessage> errorsList)
  {
    super(errorsList.toString());
    this.errorsList = errorsList;
  }


  public List<ValidationMessage> getErrorsList()
  {
    return errorsList;
  }
}