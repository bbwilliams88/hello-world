package mil.dtic.cbes.rule;

import java.lang.annotation.*;

/**
 * Annotates the name of the component, for use with ExhibitPath.
 * Example "R2Exhibit"
 *
 * @Location("R2Exhibit")
 * R2ExhibitValidator
 *
 * @Location(component="Project", index=true)
 *
 * @Location(component="Program Element", identify=true)
 * ... calls validator.getLocationIndentifier()
 * 
 * @author AZumkhaw
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface Location {
  String component();
  boolean index() default false;
  boolean identify() default false;
  boolean key() default false;
}