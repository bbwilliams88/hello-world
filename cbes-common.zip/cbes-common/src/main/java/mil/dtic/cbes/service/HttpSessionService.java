package mil.dtic.cbes.service;

import java.net.UnknownHostException;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.utility.CbesLogFactory;

/**
 * Store list of http sessions in db
 */
public class HttpSessionService
{
  private static final Logger log = CbesLogFactory.getLog(HttpSessionService.class);

  private ConfigDAO configDAO;


  public ConfigDAO getConfigDAO()
  {
    return configDAO;
  }

  public void setConfigDAO(ConfigDAO configDAO)
  {
    this.configDAO = configDAO;
  }


  //Clear out data on startup
  public void contextCreated() throws UnknownHostException
  {
    //configDAO.createHttpSessionList();
    //configDAO.saveClearedHttpSessionList();
  }

  public void sessionCreated(String sessionId)
  {
    //configDAO.addToHttpSessionList(sessionId);
  }
  
  public void sessionDestroyed(String sessionId)
  {
    //configDAO.removeFromHttpSessionList(sessionId);
  }
}
