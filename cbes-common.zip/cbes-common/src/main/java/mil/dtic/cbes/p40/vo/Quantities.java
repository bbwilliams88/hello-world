package mil.dtic.cbes.p40.vo;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.HashCodeBuilder;



public class Quantities implements ICosts<Long>
{
  protected Long priorYears;
  protected Long priorYear;
  protected Long currentYear;
  protected Long by1Base;
  protected Long by1Ooc;
  protected Long by1;
  protected Long by2;
  protected Long by3;
  protected Long by4;
  protected Long by5;
  protected Long toComplete;
  protected Long total;
  protected boolean continuing;


  public Quantities()
  {

  }


  public Quantities(Costs src)
  {
    this.priorYears = l(src.getPriorYears());
    this.priorYear = l(src.getPriorYear());
    this.currentYear = l(src.getCurrentYear());
    this.by1Base = l(src.getBy1Base());
    this.by1Ooc = l(src.getBy1Ooc());
    this.by1 = l(src.getBy1());
    this.by2 = l(src.getBy2());
    this.by3 = l(src.getBy3());
    this.by4 = l(src.getBy4());
    this.by5 = l(src.getBy5());
    this.toComplete = l(src.getToComplete());
    this.toComplete = l(src.getToComplete());
    this.continuing = src.isContinuing();
  }


  // convert BigDecimal to Long, null is null
  private Long l(BigDecimal b)
  {
    if (b == null)
      return null;
    return b.longValue();
  }


  private static Long add(Long b1, Long b2)
  {
    if (b1 == null) return b2;
    if (b2 == null) return b1;
    return b1 + b2;
  }


  private static void add(Quantities dest, Quantities l2)
  {
    dest.setPriorYears(add(dest.getPriorYears(), l2.getPriorYears()));
    dest.setPriorYear(add(dest.getPriorYear(), l2.getPriorYear()));
    dest.setCurrentYear(add(dest.getCurrentYear(), l2.getCurrentYear()));
    dest.setBy1(add(dest.getBy1(), l2.getBy1()));
    dest.setBy1Base(add(dest.getBy1Base(), l2.getBy1Base()));
    dest.setBy1Ooc(add(dest.getBy1Ooc(), l2.getBy1Ooc()));
    dest.setBy2(add(dest.getBy2(), l2.getBy2()));
    dest.setBy3(add(dest.getBy3(), l2.getBy3()));
    dest.setBy4(add(dest.getBy4(), l2.getBy4()));
    dest.setBy5(add(dest.getBy5(), l2.getBy5()));
    dest.setToComplete(add(dest.getToComplete(), l2.getToComplete()));
    dest.setTotal(add(dest.getTotal(), l2.getTotal()));
  }


  public void add(Quantities other)
  {
    add(this, other);
  }


  public Long horizontalAdd()
  {
    Long sum = 0L;
    add(sum, getPriorYears());
    add(sum, getPriorYear());
    add(sum, getCurrentYear());
    add(sum, getBy1());
    add(sum, getBy2());
    add(sum, getBy3());
    add(sum, getBy4());
    add(sum, getBy5());
    add(sum, getToComplete());
    return sum;
  }


  public Long getPriorYears()
  {
    return priorYears;
  }


  public void setPriorYears(Long priorYears)
  {
    this.priorYears = priorYears;
  }


  public Long getPriorYear()
  {
    return priorYear;
  }


  public void setPriorYear(Long priorYear)
  {
    this.priorYear = priorYear;
  }


  public Long getCurrentYear()
  {
    return currentYear;
  }


  public void setCurrentYear(Long currentYear)
  {
    this.currentYear = currentYear;
  }


  public Long getBy1Base()
  {
    return by1Base;
  }


  public void setBy1Base(Long by1Base)
  {
    this.by1Base = by1Base;
  }


  public Long getBy1Ooc()
  {
    return by1Ooc;
  }


  public void setBy1Ooc(Long by1Ooc)
  {
    this.by1Ooc = by1Ooc;
  }


  public Long getBy1()
  {
    return by1;
  }


  public void setBy1(Long by1)
  {
    this.by1 = by1;
  }


  public Long getBy2()
  {
    return by2;
  }


  public void setBy2(Long by2)
  {
    this.by2 = by2;
  }


  public Long getBy3()
  {
    return by3;
  }


  public void setBy3(Long by3)
  {
    this.by3 = by3;
  }


  public Long getBy4()
  {
    return by4;
  }


  public void setBy4(Long by4)
  {
    this.by4 = by4;
  }


  public Long getBy5()
  {
    return by5;
  }


  public void setBy5(Long by5)
  {
    this.by5 = by5;
  }


  public Long getToComplete()
  {
    return toComplete;
  }


  public void setToComplete(Long toComplete)
  {
    this.toComplete = toComplete;
  }


  public Long getTotal()
  {
    return total;
  }


  public void setTotal(Long total)
  {
    this.total = total;
  }


  public boolean isContinuing()
  {
    return continuing;
  }


  public void setContinuing(boolean continuing)
  {
    this.continuing = continuing;
  }


  @Override
  public int hashCode()
  {
    HashCodeBuilder builder = new HashCodeBuilder();

    builder.append(priorYears);
    builder.append(priorYear);
    builder.append(currentYear);
    builder.append(by1Base);
    builder.append(by1Ooc);
    builder.append(by1);
    builder.append(by2);
    builder.append(by3);
    builder.append(by4);
    builder.append(by5);
    builder.append(toComplete);
    builder.append(total);
    builder.append(continuing);

    return builder.toHashCode();
  }


  /**
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj) 
      return true;
    
    if (obj == null) 
      return false;
    
    if (getClass() != obj.getClass()) 
      return false;
    
    Quantities other = (Quantities) obj;
    
    return longEqualsCheck(priorYears, other.priorYears) &&
      longEqualsCheck(priorYear, other.priorYear) &&
      longEqualsCheck(currentYear, other.currentYear) &&
      longEqualsCheck(by1, other.by1) &&
      longEqualsCheck(by1Base, other.by1Base) &&
      longEqualsCheck(by1Ooc, other.by1Ooc) &&
      longEqualsCheck(by2, other.by2) &&
      longEqualsCheck(by3, other.by3) &&
      longEqualsCheck(by4, other.by4) &&
      longEqualsCheck(by5, other.by5) &&
      longEqualsCheck(toComplete, other.toComplete) &&
      longEqualsCheck(total, other.total) &&
      continuing == other.continuing;
  }

  private boolean longEqualsCheck(Long long1, Long long2)
  {
    if (long1 == null && long2 == null)
      return true;

    if (long1 == null || long2 == null)
      return false;

    return long1.equals(long2);

  }
}
