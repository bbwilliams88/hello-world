package mil.dtic.cbes.enums;

import org.apache.cayenne.ExtendedEnumeration;

public enum StatusType implements ExtendedEnumeration
{
    ACTIVE("A"),   // Exists in LDAP DB and CXE DB.
    DELETED("D"),  // Exists in LDAP DB and CXE DB, but status is "deleted" in CXE DB.
    INACTIVE("I"), // Does not exist in LDAP DB, but exists in CXE DB.
    NEW("N");      // Exists in LDAP DB, but not CXE DB.

    private final String databaseValue;

    private StatusType(String dbName)
    {
      this.databaseValue = dbName;
    }

    @Override
    public String getDatabaseValue()
    {
      return databaseValue;
    }

    public boolean isActive()
    {
      return this == ACTIVE;
    }

    public boolean isDeleted()
    {
      return this == DELETED;
    }

    public boolean isInactive()
    {
      return this == INACTIVE;
    }

    public boolean isNew()
    {
      return this == NEW;
    }
}
