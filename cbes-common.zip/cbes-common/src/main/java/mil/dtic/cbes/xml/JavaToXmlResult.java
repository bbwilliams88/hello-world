/*
 * $Id$
 */
package mil.dtic.cbes.xml;

import java.io.File;
import java.util.List;

import mil.dtic.utility.KeyValuePair;

public class JavaToXmlResult
{
  private File xmlFile;
  private File zipFile;
  private List<KeyValuePair> r4KvpList;
  public File getXmlFile()
  {
    return xmlFile;
  }
  public void setXmlFile(File xmlFile)
  {
    this.xmlFile = xmlFile;
  }
  public File getZipFile()
  {
    return zipFile;
  }
  public void setZipFile(File zipFile)
  {
    this.zipFile = zipFile;
  }
  public List<KeyValuePair> getR4KvpList()
  {
    return r4KvpList;
  }
  public void setR4KvpList(List<KeyValuePair> kvpList)
  {
    r4KvpList = kvpList;
  }
  
  
}
