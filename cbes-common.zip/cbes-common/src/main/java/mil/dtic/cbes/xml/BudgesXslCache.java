package mil.dtic.cbes.xml;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mil.dtic.cbes.constants.Constants.XML_RESOURCES_SOURCE;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesXmlResourceResolverFactory;
import mil.dtic.utility.CbesLogFactory;
import net.sf.saxon.FeatureKeys;

@Component("BudgesXslCache")
public class BudgesXslCache
{
  private static final Logger log = CbesLogFactory.getLog(BudgesXslCache.class);

  @Autowired
  private BudgesXmlResourceResolverFactory budgesXmlResourceResolverFactory;
  private Map<String, Templates> templatesCacheMap;
  private XML_RESOURCES_SOURCE xmlResourcesLoadFrom;
  private TransformerFactory transformerFactory;


  public BudgesXslCache()
  {
    templatesCacheMap = new HashMap<String, Templates>();
    transformerFactory = new net.sf.saxon.TransformerFactoryImpl();
    transformerFactory.setAttribute(FeatureKeys.LINE_NUMBERING, new Boolean(true));
    transformerFactory.setErrorListener(new BudgesXslErrorListener());
    // transformerFactory.setAttribute(FeatureKeys.MESSAGE_EMITTER_CLASS, new
    // BudgesXslOutputReceiver());
    // transformerFactory.setAttribute(FeatureKeys.TRACE_LISTENER, new
    // XSLTTraceListener());
  }

  public synchronized void clearXsltCache()
  {
    templatesCacheMap.clear();
  }

  public synchronized Transformer getTransformer(String xslFileName) throws TransformerException
  {
    return getTransformer(xslFileName, null, null);
  }

  public synchronized Transformer getTransformer(String xslFileName, List<String> xsdPathList, List<String> xslPathList) throws TransformerException {
      log.debug("Getting transformer for " + xslFileName);
      
      if (xmlResourcesLoadFrom == null || !xmlResourcesLoadFrom.equals(budgesXmlResourceResolverFactory.getXmlResourcesLoadFrom())){
          xmlResourcesLoadFrom = budgesXmlResourceResolverFactory.getXmlResourcesLoadFrom();
          clearXsltCache();
      }
    
      Templates templates = templatesCacheMap.get(xslFileName);

      if (templates == null || BudgesContext.getConfigService().getDisableXsltCaching()) {
          log.debug("Creating new transformer (as no cached one exists or caching is disabled -- caching disabled flag = " + BudgesContext.getConfigService().getDisableXsltCaching() + ") for " + xslFileName);
          log.debug("Loading all XSLTs from " + xmlResourcesLoadFrom);

          URIResolver xsltResourceResolver = (xsdPathList == null && xslPathList == null)  
                  ? budgesXmlResourceResolverFactory.getXsltResourceResolver() 
                  : budgesXmlResourceResolverFactory.getXsltResourceResolver(xsdPathList, xslPathList);
          
          //Source xslInputSource = xsltResourceResolver.resolve(xslFileName, null);

          StreamSource xslInputSource = null;
          
          try {    
              xslInputSource = (StreamSource) xsltResourceResolver.resolve(xslFileName, null);
      
              if(xslInputSource != null) {
                  transformerFactory.setURIResolver(xsltResourceResolver);
                  templates = transformerFactory.newTemplates(xslInputSource);
                  templatesCacheMap.put(xslFileName, templates);
              }
          }
          finally{
              IOUtils.closeQuietly(xslInputSource.getInputStream());
              log.info("==== CLOSED INPUT STREAM ======");
          }
      }
    
      if (templates !=null){
          log.debug("Found or created transformer for " + xslFileName);
      }
      else{
          throw new TransformerException("No stylesheet found for "+xslFileName);
      }
    
      Transformer transformer = templates.newTransformer();
    
      // Saxon 9.1.0.8 sends the output of xsl:message instructions to standard
      // err, so set it to our own emitter which will log it via our usual
      // logger.
      ((net.sf.saxon.Controller) transformer).setMessageEmitter(new BudgesXslOutputReceiver());
      return transformer;
  }
  
  
}