package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ShipCostCategoryType;
import mil.dtic.cbes.enums.ShipFiscalYearFundingType;
import mil.dtic.cbes.p40.vo.auto._ShipClass;
import mil.dtic.cbes.p40.vo.wrappers.ShipFiscalYearFundingMatrixWrapper;
import mil.dtic.utility.CbesLogFactory;

/**
 *
 */
public class ShipClass extends _ShipClass implements ItemExhibitType
{
    private static final long serialVersionUID = 1L;
    private static final Logger log = CbesLogFactory.getLog(ShipClass.class);

    @Override
    public Costs getCosts()
    {
      return getNetP1Cost();
    }

    @Override
    public Costs getUnitCosts()
    {
      return null;
    }

    @Override
    public Costs getQuantities()
    {
      return null;
    }

    @Override
    public void shiftForwardInTime(int years)
    {
      if (getNetP1Cost() != null)
        getNetP1Cost().shiftForwardInTime(years);
      if (getCostCategoriesTotal() != null)
        getCostCategoriesTotal().shiftForwardInTime(years);
    }

    @Override
    public String getIdentifyingString()
    {
      return getTitle();
    }

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

//    // Put is*/get*/set* methods here.
//    public void addBudgetYearForPDF(String budgetYear)
//    {
//      if(!budgetYear.trim().matches("^\\d{4}$"))
//        throw new IllegalArgumentException("The following Budget Year for PDF provided is not a valid 4-digit year: " + budgetYear);
//      ArrayList<String> budgetYearsForPDF = (ArrayList<String>) getBudgetYearsForPDFList();
//      budgetYearsForPDF.add(budgetYear.trim());
//      setBudgetYearsForPDF(StringUtils.join(budgetYearsForPDF, ","));
//    }
//    
//    public List<String> getBudgetYearsForPDFList()
//    {
//      if (StringUtils.isNotEmpty(getBudgetYearsForPDF()))
//        return new ArrayList<String>(Arrays.asList(getBudgetYearsForPDF().split("\\s*,\\s*")));
//      else
//        return new ArrayList<String>();
//    }
    
    private ShipCostCategory getShipCostCategoryByType(ShipCostCategoryType type)
    {
      for (ShipCostCategory shipCostCategory : getShipCostCategories())
        if(shipCostCategory.getCategory().equals(type))
          return shipCostCategory;
      return null;
    }
    
    private void setShipCostCategoryByType(ShipCostCategory category, ShipCostCategoryType type)
    {
      //TODO: Figure out why JiBX calls the setter for each category twice if it exists when unmarshalling
      if (getShipCostCategoryByType(type) != null)
      {
        removeFromShipCostCategories(getShipCostCategoryByType(type));
        log.debug("You already have one Ship Cost Category for " + type.getDescription() + ". The old category was deleted because you cannot have more than one of each category.");
        //throw new IllegalArgumentException("You already have one Ship Cost Category for " + type.getDescription() + ". You cannot have more than one of each category.");
      }
      
      if (category != null)
      {
        category.setCategory(type);
        addToShipCostCategories(category);
      }
    }
    
    private List<ShipCostCategory> getUserDefinedShipCostCategories()
    {
      List<ShipCostCategory> userDefinedCategories = new ArrayList<ShipCostCategory>();
      for (ShipCostCategory shipCostCategory : getShipCostCategories())
        if (shipCostCategory.getCategory().equals(ShipCostCategoryType.USER_DEFINED))
          userDefinedCategories.add(shipCostCategory);
      return userDefinedCategories;
    }
    
    public void addToUserDefinedShipCostCategories(ShipCostCategory category)
    {
      if (category != null)
      {
        category.setCategory(ShipCostCategoryType.USER_DEFINED);
        addToShipCostCategories(category);
      }
    }
    
    private ShipFiscalYearFundingMatrixWrapper getFiscalYearFundingMatrixByType(ShipFiscalYearFundingType type)
    {
//      List<ShipFiscalYearFunding> fundingList = new ArrayList<ShipFiscalYearFunding>();
//      for (ShipFiscalYearFunding funding : getShipFiscalYearFundings())
//        if (funding.getType().equals(type))
//          fundingList.add(funding);
      Expression filter = ExpressionFactory.matchExp(ShipFiscalYearFunding.TYPE_PROPERTY, type);
      return new ShipFiscalYearFundingMatrixWrapper(this, filter.filterObjects(getShipFiscalYearFundings()), type, SHIP_FISCAL_YEAR_FUNDINGS_RELATIONSHIP_PROPERTY, true);
    }
    
    private ShipFiscalYearFundingMatrixWrapper getCustomFiscalYearFundingMatrixByType(String fundingTitle)
    {
//      List<ShipFiscalYearFunding> fundingList = new ArrayList<ShipFiscalYearFunding>();
//      for (ShipFiscalYearFunding funding : getShipFiscalYearFundings())
//        if (funding.getType().equals(ShipFiscalYearFundingType.CUSTOM) && StringUtils.equals(funding.getTitle(), fundingTitle))
//          fundingList.add(funding);
      Expression exp1   = ExpressionFactory.matchExp(ShipFiscalYearFunding.TYPE_PROPERTY, ShipFiscalYearFundingType.CUSTOM);
      Expression exp2   = ExpressionFactory.matchExp(ShipFiscalYearFunding.TITLE_PROPERTY, fundingTitle);
      Expression filter = exp1.andExp(exp2);
      return new ShipFiscalYearFundingMatrixWrapper(this, filter.filterObjects(getShipFiscalYearFundings()), fundingTitle, SHIP_FISCAL_YEAR_FUNDINGS_RELATIONSHIP_PROPERTY, true);
    }
    
    public void setPYAdvanceProcurementFunding(ShipFiscalYearFundingMatrixWrapper funding)
    {
      log.trace("Setters for the matrix of PY Advance Procurement funding are not implemented because the ShipFiscalYearFundingMatrix handles it.");
    }
    
    public void setLessSubsequentYearFullFunding(ShipFiscalYearFundingMatrixWrapper funding)
    {
      log.trace("Setters for the matrix of Subsequent Year Full Funding are not implemented because the ShipFiscalYearFundingMatrix handles it.");
    }
    
    public void setLessCostToCompleteFunding(ShipFiscalYearFundingMatrixWrapper funding)
    {
      log.trace("Setters for the matrix of Cost to Complete funding are not implemented because the ShipFiscalYearFundingMatrix handles it.");
    }
    
    public ShipFiscalYearFundingMatrixWrapper getLessPYAdvanceProcurementFunding()
    {
      return getFiscalYearFundingMatrixByType(ShipFiscalYearFundingType.ADVANCE_PROCUREMENT);
    }
    
    public ShipFiscalYearFundingMatrixWrapper getLessSubsequentYearFullFunding()
    {
      return getFiscalYearFundingMatrixByType(ShipFiscalYearFundingType.SUBSEQUENT_YEAR_FULL_FUNDING);
    }
    
    public ShipFiscalYearFundingMatrixWrapper getLessCostToCompleteFunding()
    {
      return getFiscalYearFundingMatrixByType(ShipFiscalYearFundingType.COST_TO_COMPLETE);
    }
    
    public List<ShipFiscalYearFundingMatrixWrapper> getCustomFiscalYearFundingMatrices()
    {
      List<ShipFiscalYearFundingMatrixWrapper> customFiscalYearFundingMatrices = new ArrayList<ShipFiscalYearFundingMatrixWrapper>();
      List<String> customTitles = new ArrayList<String>();
      Expression filter = ExpressionFactory.matchExp(ShipFiscalYearFunding.TYPE_PROPERTY, ShipFiscalYearFundingType.CUSTOM);
      for (ShipFiscalYearFunding funding : filter.filterObjects(getShipFiscalYearFundings()))
      {
        if (!customTitles.contains(funding.getTitle()))
          customTitles.add(funding.getTitle());
      }
      for (String title : customTitles)
      {
        customFiscalYearFundingMatrices.add(getCustomFiscalYearFundingMatrixByType(title));
      }
      return customFiscalYearFundingMatrices;
    }
    
    public void addToCustomFiscalYearFundingMatrices(ShipFiscalYearFundingMatrixWrapper funding)
    {
//      ShipClass tmp = null;
      for (ShipFiscalYearFunding fundingRow : funding)
      {
//        if (tmp == null)
//          tmp = fundingRow.getShipClass();
//        fundingRow.setShipClass(this);
        addToShipFiscalYearFundings(fundingRow);
      }
//      getObjectContext().deleteObject(tmp);
    }
    
    public ShipCostCategory getPlanCostsCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.PLAN_COSTS);
    }
    
    public ShipCostCategory getBasicConstructionConversionCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.BASIC_CONSTRUCTION_CONVERSION);
    }
    
    public ShipCostCategory getChangeOrdersCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.CHANGE_ORDERS);
    }
    
    public ShipCostCategory getElectronicsCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.ELECTRONICS);
    }
    
    public ShipCostCategory getTechnologyInsertionCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.TECHNOLOGY_INSERTION);
    }
    
    public ShipCostCategory getPropulsionEquipmentCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.PROPULSION_EQUIPMENT);
    }
    
    public ShipCostCategory getHMECategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.HME);
    }
    
    public ShipCostCategory getOrdinanceCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.ORDNANCE);
    }
    
    public ShipCostCategory getEscalationCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.ESCALATION);
    }
    
    public ShipCostCategory getOtherCostCategory()
    {
      return getShipCostCategoryByType(ShipCostCategoryType.OTHER_COST);
    }
    
    public void setPlanCostsCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.PLAN_COSTS);
    }
    
    public void setBasicConstructionConversionCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.BASIC_CONSTRUCTION_CONVERSION);
    }
    
    public void setChangeOrdersCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.CHANGE_ORDERS);
    }
    
    public void setElectronicsCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.ELECTRONICS);
    }
    
    public void setTechnologyInsertionCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.TECHNOLOGY_INSERTION);
    }
    
    public void setPropulsionEquipmentCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.PROPULSION_EQUIPMENT);
    }
    
    public void setHMECategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.HME);
    }
    
    public void setOrdinanceCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.ORDNANCE);
    }
    
    public void setEscalationCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.ESCALATION);
    }
    
    public void setOtherCostCategory(ShipCostCategory category)
    {
      setShipCostCategoryByType(category, ShipCostCategoryType.OTHER_COST);
    }

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public boolean jibx_hasTitle()
    {
      return StringUtils.isNotEmpty(getTitle());
    }
    
    public boolean jibx_hasNomenclature()
    {
      return getNomenclature() != null;
    }
    
    public boolean jibx_hasShipCharacteristics()
    {
      return getShipCharacteristics() != null;
    }
    
    public boolean jibx_hasShipContracts()
    {
      return CollectionUtils.isNotEmpty(getShipContracts());
    }
    
    public Iterator<ShipContract> jibx_shipContractsIterator()
    {
      return getShipContracts().iterator();
    }
    
    public boolean jibx_hasShipCostCategories()
    {
      return CollectionUtils.isNotEmpty(getShipCostCategories());
    }
    
    public boolean jibx_hasPlanCostsCategory()
    {
      return getPlanCostsCategory() != null;
    }
    
    public boolean jibx_hasBasicConstructionConversionCategory()
    {
      return getBasicConstructionConversionCategory() != null;
    }
    
    public boolean jibx_hasChangeOrdersCategory()
    {
      return getChangeOrdersCategory() != null;
    }
    
    public boolean jibx_hasElectronicsCategory()
    {
      return getElectronicsCategory() != null;
    }
    
    public boolean jibx_hasTechnologyInsertionCategory()
    {
      return getTechnologyInsertionCategory() != null;
    }
    
    public boolean jibx_hasPropulsionEquipmentCategory()
    {
      return getPropulsionEquipmentCategory() != null;
    }
    
    public boolean jibx_hasHMECategory()
    {
      return getHMECategory() != null;
    }
    
    public boolean jibx_hasOrdinanceCategory()
    {
      return getOrdinanceCategory() != null;
    }
    
    public boolean jibx_hasEscalationCategory()
    {
      return getEscalationCategory() != null;
    }
    
    public boolean jibx_hasOtherCostCategory()
    {
      return getOtherCostCategory() != null;
    }    
    
    public boolean jibx_hasUserDefinedCostCategories()
    {
      return CollectionUtils.isNotEmpty(getUserDefinedShipCostCategories());
    }
    
    public Iterator<ShipCostCategory> jibx_userDefinedCostCategoryIterator()
    {
      return getUserDefinedShipCostCategories().iterator();
    }
    
    public void jibx_setCostCategoriesTotal(ExtendedPYSCosts costCategoriesTotal)
    {
      if (costCategoriesTotal != null)
        costCategoriesTotal.setType(CostRowType.TOTALCOST);
      super.setCostCategoriesTotal(costCategoriesTotal);
    }
    
    public void jibx_setNetP1Cost(ExtendedPYSCosts netP1Cost)
    {
      if (netP1Cost != null)
        netP1Cost.setType(CostRowType.TOTALCOST);
      super.setNetP1Cost(netP1Cost);
    }
    
    public boolean jibx_hasCostCategoriesTotal()
    {
      return getCostCategoriesTotal() != null;
    }
    
    public boolean jibx_hasNetP1Cost()
    {
      return getNetP1Cost() != null;
    }
    
    public boolean jibx_hasShipAnalysisOfCostEstimate()
    {
      return getShipAnalysisOfCostEstimate() != null;
    }
    
    public boolean jibx_hasAdvanceProcurement()
    {
      return getAdvanceProcurement() != null;
    }
    
    public boolean jibx_hasBudgetYearsForPDF()
    {
      return CollectionUtils.isNotEmpty(getBudgetYearsForPDF());
    }
    
    public Iterator<ShipBudgetYearsForPDF> jibx_budgetYearsForPDFIterator()
    {
      return getBudgetYearsForPDF().iterator();
    }
    
    public boolean jibx_hasLessPYAdvanceProcurementFunding()
    {
      return CollectionUtils.isNotEmpty(getLessPYAdvanceProcurementFunding());
    }
    
    public boolean jibx_hasLessSubsequentYearFullFunding()
    {
      return CollectionUtils.isNotEmpty(getLessSubsequentYearFullFunding());
    }
    
    public boolean jibx_hasLessCostToCompleteFunding()
    {
      return CollectionUtils.isNotEmpty(getLessCostToCompleteFunding());
    }
    
    public boolean jibx_hasCustomFiscalYearFundingMatrices()
    {
      return CollectionUtils.isNotEmpty(getCustomFiscalYearFundingMatrices());
    }
    
    public Iterator<ShipFiscalYearFunding> jibx_lessPYAdvanceProcurementFundingIterator()
    {
      return getLessPYAdvanceProcurementFunding().iterator();
    }
    
    public Iterator<ShipFiscalYearFunding> jibx_lessSubsequentYearFullFundingIterator()
    {
      return getLessSubsequentYearFullFunding().iterator();
    }
    
    public Iterator<ShipFiscalYearFunding> jibx_lessCostToCompleteFundingIterator()
    {
      return getLessCostToCompleteFunding().iterator();
    }
    
    public Iterator<ShipFiscalYearFundingMatrixWrapper> jibx_customFiscalYearFundingMatricesIterator()
    {
      return getCustomFiscalYearFundingMatrices().iterator();
    }
    
    public void jibx_postSet()
    {
        //Util.generateDisplayOrder(getCategories());
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
