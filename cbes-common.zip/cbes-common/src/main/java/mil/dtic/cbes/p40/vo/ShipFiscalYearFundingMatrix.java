package mil.dtic.cbes.p40.vo;

import java.util.List;



public interface ShipFiscalYearFundingMatrix extends List<ShipFiscalYearFunding>
{
  
}