package mil.dtic.cbes.p40.vo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.enums.ShipsOutfittingDeliveryCostType;
import mil.dtic.cbes.p40.vo.auto._ShipsOutfittingDeliveryCostCategory;

/**
 *
 */
public class ShipsOutfittingDeliveryCostCategory extends _ShipsOutfittingDeliveryCostCategory
{
    private static final long serialVersionUID = 1L;

    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    // Put is*/get*/set* methods here.

    /***********************************************************************/
    /*** Business Logic                                                  ***/
    /***********************************************************************/

    // Put non-accessor methods here.

    /***********************************************************************/
    /*** Utilities                                                       ***/
    /***********************************************************************/

    // Put utility-type methods here, which are typically static, such as
    // fetch* type methods, which fetch Cayenne objects from the database.

    /***********************************************************************/
    /*** JiBX Support                                                    ***/
    /***********************************************************************/

    // Put JiBX support methods here.
    public void jibx_setDeliveryTotalCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setDeliveryTotalCosts(costs);
      }
    }
    
    public void jibx_setOutfittingTotalCosts(Costs costs)
    {
      if (costs != null)
      {
        costs.setType(CostRowType.TOTALCOST);
        super.setOutfittingTotalCosts(costs);
      }
    }
    
    public boolean jibx_hasDeliveryTotalCosts()
    {
      return getDeliveryTotalCosts() != null;
    }
    
    public boolean jibx_hasOutfittingTotalCosts()
    {
      return getOutfittingTotalCosts() != null;
    }
    
    public boolean jibx_hasNomenclature()
    {
      return getNomenclature() != null;
    }
    
    public boolean jibx_hasShipsOutfittingDeliveryCostElementShip()
    {
      for (ShipsOutfittingDeliveryCostElem elem : getOutfittingDeliveryCostElem())
      {
        if (elem.getElementType() == ShipsOutfittingDeliveryCostType.SHIP_CLASS)
          return true;
      }
      return false;
    }
    
    public boolean jibx_hasShipsOutfittingDeliveryCostElementPubs()
    {
      for (ShipsOutfittingDeliveryCostElem elem : getOutfittingDeliveryCostElem())
      {
        if (elem.getElementType() == ShipsOutfittingDeliveryCostType.PUBS)
          return true;
      }
      return false;
    }
    
    public boolean jibx_hasShipsOutfittingDeliveryCostElementDestination()
    {
      for (ShipsOutfittingDeliveryCostElem elem : getOutfittingDeliveryCostElem())
      {
        if (elem.getElementType() == ShipsOutfittingDeliveryCostType.FIRST_DESTINATION)
          return true;
      }
      return false;
    }
    
    public void jibx_addToShipsOutfittingDeliveryCostElement(ShipsOutfittingDeliveryCostElem shipsOutfittingDeliveryCostElem)
    {
      if (shipsOutfittingDeliveryCostElem != null)
      {
        addToOutfittingDeliveryCostElem(shipsOutfittingDeliveryCostElem);
      }
    }
    
    public Iterator<ShipsOutfittingDeliveryCostElem> jibx_shipsOutfittingDeliveryCostElementIteratorShip()
    {
      return getOutfittingDeliveryCostElementSubList(ShipsOutfittingDeliveryCostType.SHIP_CLASS).iterator();
    }
    
    public Iterator<ShipsOutfittingDeliveryCostElem> jibx_shipsOutfittingDeliveryCostElementIteratorPubs()
    {
      return getOutfittingDeliveryCostElementSubList(ShipsOutfittingDeliveryCostType.PUBS).iterator();
    }
    
    public Iterator<ShipsOutfittingDeliveryCostElem> jibx_shipsOutfittingDeliveryCostElementIteratorDestination()
    {
      return getOutfittingDeliveryCostElementSubList(ShipsOutfittingDeliveryCostType.FIRST_DESTINATION).iterator();
    }
    
    public List<ShipsOutfittingDeliveryCostElem> getOutfittingDeliveryCostElementSubList(ShipsOutfittingDeliveryCostType listType)
    {
      List<ShipsOutfittingDeliveryCostElem> temp = new ArrayList<ShipsOutfittingDeliveryCostElem>();
      for (ShipsOutfittingDeliveryCostElem elem : getOutfittingDeliveryCostElem())
      {
        if (elem.getElementType() == listType)
          temp.add(elem);
      }
      return temp;
    }

    /***********************************************************************/
    /*** Validation Support                                              ***/
    /***********************************************************************/

    // Put equivalenceHashCode and equivalentTo methods here, if the class
    // implements Equivalence.
}
