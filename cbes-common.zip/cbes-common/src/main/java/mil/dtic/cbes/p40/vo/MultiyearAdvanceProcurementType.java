package mil.dtic.cbes.p40.vo;

/**
 * MYP Object generated with JiBX This class is not to be committed to the DB
 */
public class MultiyearAdvanceProcurementType
{
  private YearWithFootnoteType year;
  private MultiyearCostType cost;


  /**
   * Get the 'Year' element value.
   * 
   * @return value
   */
  public YearWithFootnoteType getYear()
  {
    return year;
  }


  /**
   * Set the 'Year' element value.
   * 
   * @param year
   */
  public void setYear(YearWithFootnoteType year)
  {
    this.year = year;
  }


  /**
   * Get the 'Cost' element value.
   * 
   * @return value
   */
  public MultiyearCostType getCost()
  {
    return cost;
  }


  /**
   * Set the 'Cost' element value.
   * 
   * @param cost
   */
  public void setCost(MultiyearCostType cost)
  {
    this.cost = cost;
  }
}
