package mil.dtic.cbes.rule;

/**
 * Interface for classes that can be visited by
 * a RuleGroupVisitor.
 *
 * @author AZumkhaw
 *
 */
public interface RuleGroup
{
    void accept(RuleGroupVisitor visitor, String organizationCode);
}
