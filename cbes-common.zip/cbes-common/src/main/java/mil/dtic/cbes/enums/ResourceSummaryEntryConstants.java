package mil.dtic.cbes.enums;


public enum ResourceSummaryEntryConstants
{
  QUANTITY("Quantity","Procurement Quantity",ResourceSummaryEntryConstants.QUANTITY_DO),
  GROSS_COST("Gross/Weapon System Cost",ResourceSummaryEntryConstants.GROSS_COST_DO),
  LESS_PY_ADV_PROC("Less PY Advance Procurement",ResourceSummaryEntryConstants.LESS_PY_ADV_PROC_DO),
  NET_PROC_P1("Net Procurement P-1",ResourceSummaryEntryConstants.NET_PROC_P1_DO),
  PLUS_CY_ADV_PROC("Plus CY Advance Procurement",ResourceSummaryEntryConstants.PLUS_CY_ADV_PROC_DO),
  INITIAL_SPARES("Initial Spares",ResourceSummaryEntryConstants.INITIAL_SPARES_DO),
  TOTAL_PROC_COST("Total Procurement Cost",ResourceSummaryEntryConstants.TOTAL_PROC_COST_DO),
  FLYAWAY_UNIT_COST("Flyaway Unit Cost",ResourceSummaryEntryConstants.FLYAWAY_UNIT_COST_DO),
  GROSS_WEAPON_SYSTEM_UNIT_COST("Gross Weapon System Unit Cost",ResourceSummaryEntryConstants.GROSS_WEAPON_SYSTEM_UNIT_COST_DO),
  OTHER("Other", -1),
  ;
  
  public static final int QUANTITY_DO = 1;
  public static final int GROSS_COST_DO = 2;
  public static final int LESS_PY_ADV_PROC_DO = 3;
  public static final int NET_PROC_P1_DO = 4;
  public static final int PLUS_CY_ADV_PROC_DO = 5;
  public static final int TOTAL_PROC_COST_DO = 6;
  public static final int INITIAL_SPARES_DO = 7;
  public static final int FLYAWAY_UNIT_COST_DO = 8;
  public static final int GROSS_WEAPON_SYSTEM_UNIT_COST_DO = 9;
  
  
  private final String dbName;
  private final String uiName;
  
  private final int displayOrder;
  
  private ResourceSummaryEntryConstants(String dbName,int displayOrder)
  {
    this.dbName = this.uiName = dbName;
    this.displayOrder = displayOrder;
  }
  private ResourceSummaryEntryConstants(String dbName, String uiName, int displayOrder)
  {
    this.dbName = dbName;
    this.uiName = uiName;
    this.displayOrder = displayOrder;
  }
  
  public static int getDisplayOrderForTitle(String title)
  {
    for (ResourceSummaryEntryConstants constant : ResourceSummaryEntryConstants.values())
    {
      if (constant.getDbName().equals(title))
        return constant.getDisplayOrder();
    }
    throw new IllegalArgumentException("unexpected rse title from db: " + title);
  }
  
  public static ResourceSummaryEntryConstants byDisplayOrder(int displayOrder)
  {
    for (ResourceSummaryEntryConstants constant : ResourceSummaryEntryConstants.values())
    {
      if (constant.getDisplayOrder() == displayOrder)
        return constant;
    }
    throw new IllegalArgumentException("unexpected rse display order: " + displayOrder);
  }
  
  public String getDbName()
  {
    return dbName;
  }
  
  public String getUiName()
  {
    return uiName;
  }
  
  public int getDisplayOrder()
  {
    return displayOrder;
  }
}
