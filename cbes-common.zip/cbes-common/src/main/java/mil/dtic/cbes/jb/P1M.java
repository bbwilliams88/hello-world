/*
 * $Id: R1.java 44901 2010-08-15 23:22:47Z aibrahim $
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.Util;


public class P1M extends JBDefaultSystemGeneratedPart
{
  public P1M()
  {
    this(null);
  }
  
  public P1M(String titlePrefix)
  {
    setFileSetting(FileSetting.P1M);
    setTitle(Util.addPrefixWithSpaceDelim(titlePrefix, FileSetting.P1M.getTitle()));    
  }
}
