package mil.dtic.cbes.jb;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.FormattingResults;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.XmlUtil;

public abstract class JBPart {
  private static final Logger log = CbesLogFactory.getLog(JBPart.class);
  protected String title;
  protected String fileName;
  protected String absoluteFileName;
  protected FileSetting fileSetting;
  protected BudgesContentType contentType;
  protected int pdfAbsoluteStartPage;
  protected int pdfStartPage;
  protected int pdfTotalPageCount;
  protected PaginationGroup pdfPaginationGroup;
  protected File workingFolder;
  protected File xmlFile;
  List<EmbedableFile> fileToEmbedList;
  protected byte[] xmlData;
  protected FopFactory fopFactory;
  protected int partIndex;
  protected boolean fixedTitle;
  protected DocumentCreationParams docCreationParams;
  protected DocumentAssemblyOptions docAssemblyOptions;

  public JBPart() {
      contentType = BudgesContentType.PDF;
  }

  public boolean removeContent() {
      boolean fileDelete = false;
      if (hasContent())  {
          log.debug("Removing content for " + title + " at " + absoluteFileName);
          File file = new File(absoluteFileName);
          
          if (file.exists()){
              fileDelete = file.delete();
          }
      }
      
      return fileDelete;
  }

  public boolean hasContent() {
      return absoluteFileName != null && new File(absoluteFileName).exists();
  }

  public String getFileNamePrefix() {
      return getFileSetting().getFileNamePrefix() + "_" + partIndex;
  }

  protected int setPdfAbsoluteStartPages(int absolutePageNumber) {
      log.trace("setPdfAbsoluteStartPages: " + absolutePageNumber + " for: " + this.getClass().getName());
      setPdfAbsoluteStartPage(absolutePageNumber);
      absolutePageNumber += getPdfTotalPageCount();
      return absolutePageNumber;
  }

  public String getPdfBookmarkLabel() {
      return title;
  }

  public boolean pdfHasOddPages(){
      return (Math.abs(pdfTotalPageCount) % 2) == 1;
  }

  public FopFactory getFopFactory(){
      if (fopFactory == null) {
          fopFactory = BudgesContext.getFopFactoryWrapper().getFopFactory();
      }
      
      return fopFactory;
  }

  public String getPdfOutputFileName() {
      return FileUtil.createPdfFileName(getFileNamePrefix());
  }


  public String getExcelOutputFileName() {
      return FileUtil.createExcelFileName(getFileNamePrefix());
  }

  public String getWordOutputFileName() {
      return FileUtil.createWordFileName(getFileNamePrefix());
  }

  protected InputStream getXmlInputStream() throws IOException {
      log.trace("JBPart:getXmlInputStream - start");
      if (xmlFile == null) {
          log.debug("Using xmlData as xml source for " + title);
          return new ByteArrayInputStream(xmlData);
      }
      else {
          log.debug("Using xmlFile as xml source for " + title);
          return new BufferedInputStream(new FileInputStream(xmlFile));
      }
  }

  public FormattingResults createPdf() throws IOException, DocumentException, SQLException  {
	  setContentType(BudgesContentType.PDF);

	  // Set file name and OOC values to be used globally by XSLT's
	  if (docCreationParams != null){
		  docCreationParams.setDocTitle(title == null ? "" : title);
		  docCreationParams.setDocToGenerate(fileSetting.getFileNamePrefix() == null ? "" : fileSetting.getFileNamePrefix());
	  }

	  File outputFile = new File(workingFolder, getPdfOutputFileName());
	  setAbsoluteFileName(outputFile.getAbsolutePath());
	  OutputStream os = null;
	  FormattingResults fr = null;
	  
	  try{
	      os = new BufferedOutputStream(new FileOutputStream(outputFile));
		  fr = XmlUtil.toPdf(getXmlInputStream(), getFileSetting().getPdfXslFileName(), os, getFopFactory(), docCreationParams, docAssemblyOptions);
	  }
	  finally {
		  FileUtil.close(os);
	  }

	  if (fr != null){
		  if (pdfTotalPageCount != fr.getPageCount()){
		      int deltaCount = fr.getPageCount() - pdfTotalPageCount;
			  pdfTotalPageCount += deltaCount;
			  
			  if (pdfPaginationGroup != null){
				  pdfPaginationGroup.totalPageCount += deltaCount;
			  }
		  }
		  
		  addWatermark();
		  addTrackingHeader();
		  embedFileInPdf();
	  }

	  return fr;
  }

  public void embedFileInPdf() {
      if (fileToEmbedList != null) {
          PdfUtil.attachFileToPdf(new File(getAbsoluteFileName()), fileToEmbedList);
      }
  }

  private void addWatermark() throws DocumentException, IOException {
      String watermark = null;
    
      if (docAssemblyOptions != null) {
          watermark = (docAssemblyOptions.getWatermark() == null) ? null : docAssemblyOptions.getWatermark().trim();
      }
      
      if (StringUtils.isEmpty(watermark)){
          log.debug("Not adding watermark to " + getAbsoluteFileName());
      }
      else{
          log.debug("Adding watermark '" + watermark + "' to " + getAbsoluteFileName());
          PdfUtil.addWatermarkToPdf(watermark, getAbsoluteFileName(), true, false);
      }
  }

  public void addTrackingHeader() throws DocumentException, IOException {
      String trackingHeader = null;
    
      if (docAssemblyOptions != null)  {
          trackingHeader = (docAssemblyOptions.getTrackingHeader() == null) ? null : docAssemblyOptions.getTrackingHeader().trim();
      }
      
      if (StringUtils.isEmpty(trackingHeader)) {
          log.debug("Not adding watermark to " + getAbsoluteFileName());
      }
      else {
          log.debug("Adding watermark '" + trackingHeader + "' to " + getAbsoluteFileName());
          PdfUtil.addWatermarkToPdf(trackingHeader, getAbsoluteFileName(), true, true);
      }
  }

  public void createExcel() throws IOException {
      setContentType(BudgesContentType.EXCEL);

      if (docCreationParams != null) {
          docCreationParams.setDocTitle(title == null ? "" : title);
          docCreationParams.setDocToGenerate(fileSetting.getFileNamePrefix() == null ? "" : fileSetting.getFileNamePrefix());
      }

      // TODO check status
      File outputFile = new File(workingFolder, getExcelOutputFileName());
      setAbsoluteFileName(outputFile.getAbsolutePath());
      OutputStream os = null;
      
      try  {
          os = new BufferedOutputStream(new FileOutputStream(outputFile));
          XmlUtil.toExcel(getXmlInputStream(), getFileSetting().getExcelXslFileName(), os, docCreationParams, docAssemblyOptions);
      }
      finally  {
          FileUtil.close(os);
      }
  }

  public void createHtml() throws IOException {
      setContentType(BudgesContentType.WORD);

      if (docCreationParams != null)  {
          docCreationParams.setDocTitle(title == null ? "" : title);
          docCreationParams.setDocToGenerate(fileSetting.getFileNamePrefix() == null ? "" : fileSetting.getFileNamePrefix());
      }

      File outputFile = new File(workingFolder, getWordOutputFileName());
      setAbsoluteFileName(outputFile.getAbsolutePath());
      XmlUtil.toHtml(getXmlInputStream(), getFileSetting().getPdfXslFileName(), getFileSetting().getHtmlXslFileName(), outputFile, docCreationParams, docAssemblyOptions);
  }

  public String getTitle(){
      return title;
  }

  public void setTitle(String title) {
      this.title = title;
  }

  public String getFileName() {
      return fileName;
  }

  public void setFileName(String fileName) {
      this.fileName = fileName;
  }

  public String getAbsoluteFileName() {
      return absoluteFileName;
  }

  public void setAbsoluteFileName(String absoluteFileName) {
      this.absoluteFileName = absoluteFileName;
  }

  public FileSetting getFileSetting() {
      return fileSetting;
  }

  public void setFileSetting(FileSetting fileSetting) {
      this.fileSetting = fileSetting;
  }

  public BudgesContentType getContentType() {
      return contentType;
  }

  public void setContentType(BudgesContentType contentType) {
      this.contentType = contentType;
  }

  public int getPdfAbsoluteStartPage() {
      return pdfAbsoluteStartPage;
  }

  public void setPdfAbsoluteStartPage(int pdfAbsoluteStartPage) {
      this.pdfAbsoluteStartPage = pdfAbsoluteStartPage;
  }

  public int getPdfStartPage() {
      return pdfStartPage;
  }

  public void setPdfStartPage(int pdfStartPage) {
      this.pdfStartPage = pdfStartPage;
  }

  public int getPdfTotalPageCount() {
      return pdfTotalPageCount;
  }

  public void setPdfTotalPageCount(int pdfTotalPageCount) {
      this.pdfTotalPageCount = pdfTotalPageCount;
  }

  public PaginationGroup getPdfPaginationGroup() {
      return pdfPaginationGroup;
  }

  public void setPdfPaginationGroup(PaginationGroup pdfPaginationGroup) {
      this.pdfPaginationGroup = pdfPaginationGroup;
  }

  public List<EmbedableFile> getFileToEmbedList() {
      return fileToEmbedList;
  }

  public void setFileToEmbedList(List<EmbedableFile> fileToEmbedList) {
      this.fileToEmbedList = fileToEmbedList;
  }

  public void addFileToEmbed(EmbedableFile fileToEmbed) {
      if (fileToEmbed != null) {
          if (fileToEmbedList == null){
              fileToEmbedList = new ArrayList<EmbedableFile>();
          }
        
          fileToEmbedList.add(fileToEmbed);
      }
  }

  public void addFilesToEmbed(List<EmbedableFile> filesToEmbed) {
      if (filesToEmbed != null)  {
          if (fileToEmbedList == null){
              fileToEmbedList = new ArrayList<EmbedableFile>();
          }
          
          fileToEmbedList.addAll(filesToEmbed);
      }
  }

  public void setWorkingFolder(File workingFolder) {
      this.workingFolder = workingFolder;
  }

  public File getXmlFile(){
      return xmlFile; 
  }

  public void setXmlFile(File xmlFile) {
      this.xmlFile = xmlFile;
  }

  public DocumentCreationParams getDocCreationParams() {
      return docCreationParams;
  }

  public void setDocCreationParams(DocumentCreationParams docCreationParams) {
      this.docCreationParams = docCreationParams;
  }

  public void setFopFactory(FopFactory fopFactory) {
      this.fopFactory = fopFactory;
  }

  public byte[] getXmlData() {
      return xmlData;
  }

  public void setXmlData(byte[] xmlData)  {
      this.xmlData = ArrayUtils.clone(xmlData);
  }

  public int getPartIndex() {
      return partIndex;
  }

  public void setPartIndex(int partIndex) {
      this.partIndex = partIndex;
  }

  public boolean isFixedTitle() {
      return fixedTitle;
  }

  public void setFixedTitle(boolean fixedTitle){
      this.fixedTitle = fixedTitle;
  }

  public DocumentAssemblyOptions getDocAssemblyOptions() {
      return docAssemblyOptions;
  }

  public void setDocAssemblyOptions(DocumentAssemblyOptions docAssemblyOptions) {
      this.docAssemblyOptions = docAssemblyOptions;
  }
  
}
