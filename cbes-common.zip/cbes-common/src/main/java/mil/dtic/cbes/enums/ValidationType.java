package mil.dtic.cbes.enums;

public enum ValidationType
{
  
  WARNING,
  ERROR;

}
