package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.enums.MonetaryUnitType;
import mil.dtic.cbes.enums.QuantityUnitNameType;
import mil.dtic.cbes.enums.QuantityUnitType;
import mil.dtic.cbes.exceptions.MethodDispatchException;

/**
 * Interface for representing metadata about a Line Item that are the key pieces
 * of information that define the Line Item. It includes the Line Item's Cycle,
 * its unit type and unit cost value, the Service Agency to which the Line Item
 * belongs, the Budget Activity and Sub Budget Activity to which the Line Item
 * is part of under that Agency.
 */
public interface HasUnitsAndBudgetYear
{
    public Integer getBudgetYear();
    public String getBudgetCycle();
    public QuantityUnitNameType getQuantityUnitName();
    public QuantityUnitType getQuantityUnits();
    public MonetaryUnitType getTotalCostUnits();
    public MonetaryUnitType getUnitCostUnits();
    public boolean suppressOutyears() throws MethodDispatchException;
    public ServiceAgency getServiceAgency();
    public BudgetSubActivity getBudgetSubActivity();
}
