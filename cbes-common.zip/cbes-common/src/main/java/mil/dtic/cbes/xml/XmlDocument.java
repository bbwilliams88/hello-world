package mil.dtic.cbes.xml;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.service.UnzipService.UnzipMap;
import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class XmlDocument {
  private InputStream originalStream;
  private InputStream migratedStream;
  private Document originalDoc;
  private Document migratedDoc;
  private R2ExhibitList r2List;
  private LineItemList p40List;
  private boolean isPreviousBudgetCycle;
  private File file;
  private File workingFolder;
  private String originalFileName;
  private UnzipMap attachmentResolutionMap;
  private ServiceAgency sa;
  private XmlToJava xtj;
  

  private static final Logger log = CbesLogFactory.getLog(XmlDocument.class);

  public static class XmlDocumentException extends Exception {
    private static final long serialVersionUID = 1L;
    public XmlDocumentException(String msg, Throwable cause)
    {
      super(msg, cause);
    }

    public XmlDocumentException(String msg)
    {
      super(msg);
    }
  }

  public XmlDocument(InputStream is, String fileName, File workingFolder) throws XmlDocumentException {
    this.originalStream = is;
    this.originalFileName = fileName;
    this.workingFolder = workingFolder;
    load();
  }

  public XmlDocument(File f, String fileName, File workingFolder) throws XmlDocumentException {
    this.file = f;
    if(fileName == null) {
      this.originalFileName = f.getName();
    } else {
      this.originalFileName = fileName;
    }
    this.workingFolder = workingFolder;
    load();
  }

  public void setAttachmentResolutionMap(UnzipMap attachmentResolutionMap) {
    this.attachmentResolutionMap = attachmentResolutionMap;
  }

  public InputStream getInputStream() {
    return originalStream;
  }

  public InputStream getMigratedInputStream() {
    return migratedStream;
  }

  public Document getDocument() {
    
    return originalDoc;
  }

  public Document getMigratedDocument() {
    return migratedDoc;
  }

  public String getOriginalFileName() {
    return originalFileName;
  }

  public boolean isPreviousBudgetCycle() {
    return isPreviousBudgetCycle;
  }

  public File getFile() {
    return file;
  }

  public void setFile(File newFile) {
    file = newFile;
  }

  public void resetAllStreams() {
    try {
      originalStream.reset();
      if(migratedStream != null) {
        migratedStream.reset();
      }
    } catch(IOException e) {
      log.warn("couldn't reset input stream", e);
    }
  }

  public void closeAllStreams() {
    IOUtils.closeQuietly(originalStream);
    if(migratedStream != null) {
      IOUtils.closeQuietly(migratedStream);
    }
  }

  public XmlFullValidationService validateXmlSchema() {
    if (originalDoc == null || originalStream == null) return null;
    return validateXmlSchema(originalDoc, originalStream, XMLToolsUtil.getBudgetCycle(originalDoc), XMLToolsUtil.getBudgetYear(originalDoc));
  }

  public XmlFullValidationService validateMigratedXmlSchema() {
    if (migratedDoc == null || migratedStream == null) return null;
    BudgetCycle currentBc = Util.getCurrentBudgetCycle();
    return validateXmlSchema(migratedDoc, migratedStream, currentBc.getCycle(), currentBc.getBudgetYear().toString());
  }

  private XmlFullValidationService validateXmlSchema(Document doc, InputStream xmlStream, String cycle, String year) {
    boolean isR2Doc = XMLToolsUtil.isR2(doc);
    // GET Schema Path based on document's cycle and year
    String schemaPath = XMLToolsUtil.getSchemaPath(cycle, year);
    List<String> xsdPathList = XMLToolsUtil.getSchemaPathList(schemaPath);
    List<String> xslPathList = XMLToolsUtil.getXslPathList(schemaPath, isR2Doc);

    String schemaName=XMLToolsUtil.getSchemaName(doc);

    // Validate Against Document's schema
    log.info("Will validate against: "+schemaName);
    XmlFullValidationService  validator = new XmlFullValidationService (schemaName);
    validator.setXmlInputStream(xmlStream);
    validator.setXsdPathList(xsdPathList);
    validator.validateSchema(xsdPathList, xslPathList);
    try {
      xmlStream.reset();
    } catch (IOException e) {
      log.warn("Couldn't reset inputstream.",e);
    }
    return validator;
  }


  public XmlFullValidationService validateBusinessRules(List<Map<String, String>> itemsList) {
    XmlFullValidationService xmlFullValidationService = validateBusinessRules();
    if(r2List != null) {
      itemsList.addAll(XMLToolsUtil.getProgramElementInfoList(r2List));
    } else if(p40List != null) {
      itemsList.addAll(XMLToolsUtil.getLineItemInfoList(p40List));
    }
    return xmlFullValidationService;
  }
  
  public boolean checkBusinessRuleErrors(){
    extractExhibitList();
    
    return xtj.hasErrors();
  }
  
  public List<String> getBusinessRuleErrors(){
    return xtj.getErrorList();
  }

  public XmlFullValidationService validateBusinessRules() {
    XmlFullValidationService xmlFullValidationService = new XmlFullValidationService(null);
 //   extractExhibitList();
    
    if(r2List != null) {
      xmlFullValidationService.validateRules(r2List, getSa());
    } 
    else if(p40List != null) {  //TODO: check if we need to incorproate sa processing to support exemptions.
      xmlFullValidationService.validateRules(p40List, true);
    }
    return xmlFullValidationService;
  }

  public boolean migrateXml() throws XmlDocumentException {
    BudgetCycle currentBc = Util.getCurrentBudgetCycle();
    return migrateXml(currentBc.getCycle(), currentBc.getBudgetYear().toString());
  }

  public boolean migrateXml(String targetCycle, String targetYear) throws XmlDocumentException {
  //Document Budget Cycle, Year and Schema
    String docCycle = XMLToolsUtil.getBudgetCycle(originalDoc);
    String docYear = XMLToolsUtil.getBudgetYear(originalDoc);
    boolean isR2Doc = XMLToolsUtil.isR2(originalDoc);

    if (Integer.parseInt(docYear)<2014){
      throw new XmlDocumentException("XML budget cycle year is prior to 2014, will not perform migration.");
    }

    int comparison = compareBudgetCycles(docCycle, docYear, targetCycle, targetYear);
    if(comparison > 0) {
      throw new XmlDocumentException("Target budget cycle must be after original budget cycle to perform migration.");
    } else if(comparison == 0) {
      // original budget cycle and target budget cycle are the same: do nothing
      return false;
    }

    // validate against document schema
    XmlFullValidationService xmlValidator = validateXmlSchema(originalDoc, originalStream, docCycle, docYear);
    try {
    originalStream.reset();
    } catch(IOException e) {
      log.warn("Couldn't reset input stream: " + e.getMessage());
    }

    if (!xmlValidator.isSchemaValid()) {
      throw new XmlDocumentException("XML is not valid, cannot perform migration.");
    }

  //now begin migration

    String destSchemaPath = XMLToolsUtil.getSchemaPath(targetCycle, targetYear);
    List<String> destXslPathList = XMLToolsUtil.getXslPathList(destSchemaPath, isR2Doc);

    String srcBc = docCycle + " " + docYear;
    String srcCycle = docCycle;
    String srcYear = docYear;
    String destBc, destCycle, destYear = "";
    String stylesheetname = "";
    InputStream srcXmlStream = originalStream;
    InputStream newXmlStream = null;
    File resultFile = null;
    Document resultDoc = null;
    Transformer transformer = null;
    boolean performedMigration = false;

    while(compareBudgetCycles(srcCycle, srcYear, targetCycle, targetYear) < 0) {
      destBc = incrementBudgetCycle(srcCycle, srcYear);
      destCycle = destBc.split(" ")[0];
      destYear = destBc.split(" " )[1];
      log.debug("Migrating from " + srcBc + " to " + destBc);
      resultFile = null;
      stylesheetname = XMLToolsUtil.getMigrationStyleSheet(srcCycle, srcYear, destCycle, destYear);
      try {
        transformer = BudgesContext.getBudgesXslCache().getTransformer(stylesheetname, null, destXslPathList);
      } catch(TransformerException e) {
        log.info("Couldn't get stylesheet - maybe it doesn't exist, moving on to the next one... " + e.getMessage());
        srcBc = incrementBudgetCycle(srcCycle, srcYear);
        srcCycle = srcBc.split(" ")[0];
        srcYear = srcBc.split(" ")[1];
        if(newXmlStream == null)
          newXmlStream = srcXmlStream;
        continue;
      }

      try {
        Source src = new StreamSource(srcXmlStream);
        String outputName = originalFileName + "_migrated_to_" + destCycle + destYear + ".xml";
        resultFile = new File(workingFolder, outputName);
        Result result = new StreamResult(resultFile);
        transformer.transform(src, result);
        performedMigration = true;
        log.debug("Completed transformation: " + workingFolder + "/" + outputName);
        BudgesContext.getBudgesXslCache().clearXsltCache();
        transformer.reset();
      } catch(TransformerException e) {
        log.error("Problem migrating with stylesheet("+stylesheetname+"): ",e);
        break;
      }

      //validate result
      log.debug("Validate against the migrated schema " + destBc);
      resultDoc = null;
      try {
        newXmlStream = readFileIntoInputStream(resultFile);
        log.debug("Loading migrated xml into document...");
        resultDoc = loadDocumentFromInputStream(newXmlStream);
      } catch(XmlDocumentException e) {
        log.error("Problem loading migrated XML from file: " + e.getMessage());
        break;
      }

      XmlFullValidationService migratedValidator = validateXmlSchema(resultDoc, newXmlStream, destCycle, destYear);
      log.debug("done validating");
      if (!migratedValidator.isSchemaValid()){
        log.error("Error validating migrated XML");
        for (String err : migratedValidator.getSchemaErrorList()){
          log.error(err);
        }
        String errStr = StringUtils.join(migratedValidator.getSchemaErrorList(), ",");
        throw new XmlDocumentException ("Migration Exception - the migrated XML has failed schema validation:" + errStr);
      }
      srcBc = incrementBudgetCycle(srcCycle, srcYear);
      srcCycle = srcBc.split(" ")[0];
      srcYear = srcBc.split(" ")[1];
      try {
        newXmlStream.reset();
      } catch(IOException e) {
        log.warn("Couldn't reset input stream", e);
      }
      srcXmlStream = newXmlStream;
    }
    migratedStream = newXmlStream;
    migratedDoc = resultDoc;
    return performedMigration;
  }

  private String incrementBudgetCycle(String srcCycle, String srcYear) {
    log.debug("incrementing " + srcCycle + srcYear + " to next budget cycle");
    int yearInt;
    try {
      yearInt = Integer.parseInt(srcYear);
      if("BES".equals(srcCycle)) {
        log.debug("PB " + srcYear);
        return "PB " + srcYear;
      } else {
        log.debug("BES " + Integer.toString(yearInt + 1));
        return "BES " + Integer.toString(yearInt + 1);
      }
    } catch(NumberFormatException e) {
      log.warn("Budget year not an integer: " + e.getMessage());
    }
    log.debug("not valid, returning empty string");
    return "";
  }

  // returns 1 if cycle 1 is more recent, 0 if same, -1 if cycle 2 more recent
  private int compareBudgetCycles(String cycle1, String year1, String cycle2, String year2) {
    if(cycle1 == null || year1 == null) {
      return -1;
    }
    else if(StringUtils.equals(year1, year2)) {
      return cycle1.compareTo(cycle2);
    }
    else {
      return year1.compareTo(year2);
    }
  }

  public R2ExhibitList getR2ExhibitList() {
    if(r2List == null && p40List == null) {
      extractExhibitList();
    }
    return r2List;
  }

  public LineItemList getLineItemList() {
    if(r2List == null && p40List == null) {
      extractExhibitList();
    }
    return p40List;
  }

  public JustificationBook getJb() {
    XmlToJava xtj = new XmlToJava(null, attachmentResolutionMap);
    InputStream is = originalStream;
    Document doc = originalDoc;
    if(migratedStream != null && migratedDoc != null) {
      is = migratedStream;
      doc = migratedDoc;
    }
    if(XMLToolsUtil.isJB(doc)) {
      try {
        return xtj.xmlToJustificationBook(is).getJb();
      } catch(FileNotFoundException e) {
        log.error("Couldn't extract justification book, stream does not exist", e);
      }
    }
    return null;
  }

  public MasterJustificationBook getMjb() {
    XmlToJava xtj = new XmlToJava(null, attachmentResolutionMap);
    InputStream is = originalStream;
    Document doc = originalDoc;
    if(migratedStream != null && migratedDoc != null) {
      is = migratedStream;
      doc = migratedDoc;
    }
    if(XMLToolsUtil.isMJB(doc)) {
      try {
        return xtj.xmlToMasterJustificationBook(is).getMjb();
      } catch(FileNotFoundException e) {
        log.error("Couldn't extract master justification book, stream does not exist", e);
      }
    }
    return null;
  }

  private void extractExhibitList() {
    // need UnzipMap for R4 image attachments
    xtj = new XmlToJava(null, attachmentResolutionMap);
    
    XmlToJavaResult xmlToJavaResult =  xtj.getXtjResult();
    
    InputStream is = originalStream;
    Document doc = originalDoc;
    if(migratedStream != null && migratedDoc != null) {
      is = migratedStream;
      doc = migratedDoc;
    }
    try {
      if(XMLToolsUtil.isR2ExhibitDoc(doc)) {
        r2List = xtj.toJava(is, R2ExhibitList.class);
      }
      else if(XMLToolsUtil.isP40ExhibitDoc(doc)) {
        p40List = xtj.xmlToLineItemList(is).getLineItemList();
      }
      else if (XMLToolsUtil.isJB(doc)) {
        JustificationBook jb = xtj.xmlToJustificationBook(is).getJb();
        setSa(jb.getServiceAgency());
        r2List = jb.getR2ExhibitList();
        p40List = jb.getLineItemList();
      }
      else if (XMLToolsUtil.isMJB(doc)) {
        List<R2Exhibit> tempR2s = new ArrayList<R2Exhibit>();
        List<LineItemWrapper> tempP40s = new ArrayList<LineItemWrapper>();
        MasterJustificationBook mjb = xtj.xmlToMasterJustificationBook(is).getMjb();
        setSa(sa = mjb.getServiceAgency());
        for (JustificationBookGroup jbg : mjb.getJbgList()){
          for (JustificationBookInfo jbi : jbg.getJbiList()){
            JustificationBook jb = jbi.getJb();
            if (jb.getLineItemList()!=null){
              tempP40s.addAll(jb.getLineItemList().getLineItems());
            }
            if (jb.getR2ExhibitList()!=null){
              tempR2s.addAll(jb.getR2ExhibitList().getR2Exhibits());
            }
          }
        }
        if(!tempR2s.isEmpty()) {
          r2List = new R2ExhibitList();
          r2List.setR2Exhibits(tempR2s);
        }
        if(!tempP40s.isEmpty()) {
          p40List = new LineItemList();
          p40List.setLineItems(tempP40s);
        }
      }
    } catch (FileNotFoundException e) {
      log.error("Couldn't extract line item list, stream does not exist", e);
    }
    try {
      is.reset();
    } catch (IOException e) {
      log.warn("Couldn't reset inputstream.",e);
    }
  }

  private void load() throws XmlDocumentException {
    if(originalStream == null && file != null) {
      originalStream = readFileIntoInputStream(file);
    }
    if(originalDoc == null && originalStream != null) {
      originalDoc = loadDocumentFromInputStream(originalStream);
    }
    BudgetCycle currentBc = Util.getCurrentBudgetCycle();
    if(!XMLToolsUtil.getBudgetCycle(originalDoc).equals(currentBc.getCycle()) || !XMLToolsUtil.getBudgetYear(originalDoc).equals(currentBc.getBudgetYear().toString())) {
      isPreviousBudgetCycle = true;
    }
  }

  private InputStream readFileIntoInputStream(File f) throws XmlDocumentException {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    FileInputStream fileInputStream = null;
    InputStream is = null;
    try {
      fileInputStream = new FileInputStream(f);
      IOUtils.copyLarge(fileInputStream, outputStream);
      is =  new ByteArrayInputStream(outputStream.toByteArray());
    } catch(FileNotFoundException e) {
      throw new XmlDocumentException("No source file to read from", e);
    } catch(IOException e) {
      throw new XmlDocumentException("Unable to read from source file", e);
    } finally {
      IOUtils.closeQuietly(outputStream);
      IOUtils.closeQuietly(fileInputStream);
    }
    return is;
  }

  private Document loadDocumentFromInputStream(InputStream is) throws XmlDocumentException {
    Document doc = null;
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    try {
      factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
      factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
      factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
      DocumentBuilder builder = factory.newDocumentBuilder();
      doc = builder.parse(is);
      is.reset();
    } catch(ParserConfigurationException|SAXException|IOException e) {
      log.error(e.getMessage());
      throw new XmlDocumentException("Unable to parse XML document", e);
    }
    return doc;
  }
 
  private void setSa(ServiceAgency sa){
      this.sa = sa;
  }
  
  private ServiceAgency getSa(){
      return sa;
  }
}