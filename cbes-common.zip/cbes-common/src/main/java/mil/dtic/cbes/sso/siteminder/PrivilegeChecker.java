package mil.dtic.cbes.sso.siteminder;

import java.io.Serializable;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;

//Convenience class that just has privilege-checker methods
//Used by tapestry pages
public class PrivilegeChecker implements Serializable
{
  private static final long serialVersionUID = -7730804872283223744L;

  private final UserCredentials creds;

  public PrivilegeChecker(UserCredentials creds) {
    this.creds = creds;
  }

  public boolean showModifyingUsers() {
    return creds.checkPrivilege(Privilege.SHOW_MODIFYING_USER);
  }

  public boolean showTestPeBox() {
    return creds.checkPrivilege(Privilege.SHOW_TEST_PE);
  }

  public boolean showSetWriteable() {
    return creds.checkPrivilege(Privilege.EXHIBITLIST_SHOW_SET_WRITEABLE);
  }

  public boolean showAdminTools() {
    return creds.checkPrivilege(Privilege.SHOW_ADMIN_TOOLS);
  }

  public boolean showEditAnnouncements() {
    return creds.checkPrivilege(Privilege.EDIT_ANNOUNCEMENTS);
  }

  public boolean showEditWhatsNew() {
    return creds.checkPrivilege(Privilege.EDIT_WHATS_NEW);
  }

  public boolean showEditHelp() {
    return creds.checkPrivilege(Privilege.EDIT_HELP);
  }

  public boolean showLdapUpdate() {
    return creds.checkPrivilege(Privilege.SHOW_LDAP_UPDATE_BUTTON);
  }

  public boolean showUserDates() {
    return creds.checkPrivilege(Privilege.SHOW_USER_DATES);
  }

  public boolean showPeEditButtons(ProgramElementBase pe) {
    return creds.savePeAllowed(pe);
  }

  public boolean showUnlockAlways() {
    return creds.checkPrivilege(Privilege.ALWAYS_SHOW_UNLOCK);
  }

  public boolean showPeDeleteButtons(ProgramElementList pe) {
    //disabled for performance reasons
    //return creds.savePeAllowed(pe);
    return true;
  }

  public boolean showHostInfo() {
    return creds.checkPrivilege(Privilege.VIEW_SERVER_INFO);
  }

  public boolean showCreatePe() {
    return creds.createPeAllowed();
  }

  public boolean showCopyPe() {
    return creds.createPeAllowed();
  }

  public boolean showImportPe() {
    return creds.createPeAllowed();
  }

  public boolean showR1Link() {
    return creds.checkPrivilege(Privilege.R1PAGE);
  }

  public boolean showAdminViewFiles() {
    return creds.checkPrivilege(Privilege.ADMIN_VIEW_FILES);
  }
}
