package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._BudgetSubActivity;

/**
 *
 */
public class BudgetSubActivity extends _BudgetSubActivity
{
    private static final long serialVersionUID = 1L;


    /***********************************************************************/
    /*** Custom Accessors                                                ***/
    /***********************************************************************/

    /**
     * @return The Budget Sub-Activity's number and and title, separated by a
     *         dash. Useful for labels in T5 dropdown lists.
     */
    public String getNumberPlusTitle()
    {
        return getNumber() + " - " + getTitle();
    }
}
