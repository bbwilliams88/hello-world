package mil.dtic.cbes.constants;

/**
 * Eventual (?) replacement of BudgesContentType...
 */
public enum FileType
{
    PDF("pdf", MimeType.PDF),
    WORD("pdf", MimeType.WORD), // TODO: PDF???
    EXCEL("xls.xml", MimeType.EXCEL),
    ZIP("zip", MimeType.ZIP),
    ZZZ("zzz", MimeType.ZZZ),
    XML("xml", MimeType.XML),
    TEXT("txt", MimeType.TEXT),
    GENERIC("", MimeType.GENERIC);

    private final String   extension;
    private final MimeType mimeType;

    private FileType(String extension, MimeType mimeType)
    {
        this.extension = extension;
        this.mimeType  = mimeType;
    }

    public String getExtension()
    {
        return extension;
    }

    public MimeType getMimeType()
    {
        return mimeType;
    }
}
