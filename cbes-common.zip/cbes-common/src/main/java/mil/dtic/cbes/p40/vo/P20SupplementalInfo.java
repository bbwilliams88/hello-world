package mil.dtic.cbes.p40.vo;

import mil.dtic.cbes.p40.vo.auto._P20SupplementalInfo;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;

public class P20SupplementalInfo extends _P20SupplementalInfo implements HasDisplayOrder
{
  private static final long serialVersionUID = 1L;

  @Override
  protected void onPostAdd()
  {
    setDisplayOrder(0);
  }
}
