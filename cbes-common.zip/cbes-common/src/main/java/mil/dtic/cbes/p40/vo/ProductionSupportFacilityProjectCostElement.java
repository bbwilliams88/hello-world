package mil.dtic.cbes.p40.vo;

import java.util.List;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.CostRowType;
import mil.dtic.cbes.p40.vo.auto._ProductionSupportFacilityProjectCostElement;
import mil.dtic.cbes.p40.vo.wrappers.CayenneListWrapper;
import mil.dtic.utility.CbesLogFactory;

public class ProductionSupportFacilityProjectCostElement extends _ProductionSupportFacilityProjectCostElement implements CostContainer, RollupParent
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(ProductionSupportFacilityProjectCostElement.class);

  @Override
  protected void onPostAdd()
  {
    setCosts(getObjectContext().newObject(Costs.class));
    getCosts().setType(CostRowType.TOTALCOST);
    setDisplayOrder(0); //not used
  }

  public void shiftForwardInTime(int years)
  {
    for (ProductionSupportFacilityProjectCostElementItem pcei : this.getCostElementItemList())
    {
      pcei.shiftForwardInTime(years);
    }

    if (this.getCosts() != null)
      this.getCosts().shiftForwardInTime(years);
 }


  @Override
  protected void onPrePersist()
  {
  }

  public void setCostElementItemList(
    List<ProductionSupportFacilityProjectCostElementItem> l) {
    log.trace("Collection setters not implemented " + (l == null ? null : l.size()));
  }

  @Override
  public List<ProductionSupportFacilityProjectCostElementItem> getCostElementItemList() {
    return new CayenneListWrapper<ProductionSupportFacilityProjectCostElementItem>(this, super.getCostElementItemList(), COST_ELEMENT_ITEM_LIST_RELATIONSHIP_PROPERTY, true);
  }

  public boolean jibx_isCostSubElement() {
    if (super.getCostElementItemList() != null && super.getCostElementItemList().size() > 0) {
      return true;
    } else {
      return false;
    }
  }

  @Override
  public List<? extends CostContainer> getChildren()
  {
    return getCostElementItemList();
  }

  @Override
  public Costs getUnitCosts()
  {
    return null;
  }

  @Override
  public Costs getQuantities()
  {
    return null;
  }
}
