/*
 * $Id$
 */
package mil.dtic.cbes.jb;

import mil.dtic.cbes.constants.FileSetting;

public class JBSummaryDoc extends JBDefaultUserSuppliedPart
{
  public JBSummaryDoc()
  {
    setFileSetting(FileSetting.SUMMARY_DOC);
    setTitle(fileSetting.getTitle());    
  }

}
