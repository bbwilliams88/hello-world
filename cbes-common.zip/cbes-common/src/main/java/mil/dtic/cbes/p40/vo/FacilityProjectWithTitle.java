package mil.dtic.cbes.p40.vo;




public interface FacilityProjectWithTitle extends FacilityProject
{
  public abstract void setCode(String code);
  public abstract String getCode();
  public abstract void setTitle(String title);
  public abstract String getTitle();
}