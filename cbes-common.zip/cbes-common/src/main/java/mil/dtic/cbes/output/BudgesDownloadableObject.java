/*
 * $Id$
 */
package mil.dtic.cbes.output;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import mil.dtic.cbes.constants.BudgesContentType;


public interface BudgesDownloadableObject extends Serializable
{
  public InputStream getInputStream() throws IOException;

  public File getDataFilePath();

  public String getUserVisibleLabel();

  public long getTotalSizeInBytes() throws IOException;

  public BudgesContentType getBudgesContentType();

}
