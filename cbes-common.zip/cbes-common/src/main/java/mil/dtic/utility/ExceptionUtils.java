package mil.dtic.utility;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.stereotype.Component;


/**
 *  Simple class that will take an exception and change it as necessary. To support better logging.
 *  @author Marlin Johnson
 */
@Component
public class ExceptionUtils {
	/**
	 * Updates the message in a constraint violation exception to better explain what is wrong with the validated object
	 * any messages that were passed to the exception prior to this method call are preserved.
	 */
	public ConstraintViolationException prepareConstraintViolationException(ConstraintViolationException e) {
			ConstraintViolationException oldCvE = (ConstraintViolationException) e;
			StringBuilder msg = new StringBuilder();
			if ( null != e.getMessage()) {
				msg.append(e.getMessage());
			}
			msg.append("\n");
			if (oldCvE.getConstraintViolations() != null) {
				for (ConstraintViolation<?> cv : oldCvE.getConstraintViolations()) {
					msg.append(cv.getRootBeanClass().getSimpleName() + " ");
					msg.append(cv.getPropertyPath());
					msg.append(" -> ");
					msg.append(cv.getMessage() +"\n");
					msg.append(cv.getRootBean().toString() + "\n");
				}
			}
			ConstraintViolationException newCvE = new ConstraintViolationException(msg.toString(),
					oldCvE.getConstraintViolations());
			newCvE.setStackTrace(oldCvE.getStackTrace());
			return newCvE;
		
	}
}
