package mil.dtic.utility;

import org.apache.logging.log4j.Logger;

import org.apache.logging.log4j.LogManager;

public class CbesLogFactory {

    /**
     * Singleton
     * 
     * Note: I had to do it like this instead of a bean because the loggers kept getting initialized
     *       before the CbesLogManager bean was being created causing nullpointer issues.
     */
    private static CbesLogManager logManager;

    /**
     * @brief Get logger for provided class
     * 
     * @param clazz class to create logger for
     * @return Logger for clazz
     */
    public static Logger getLog(Class<?> clazz) {
        Logger logger = LogManager.getLogger(clazz);
        getCbesLogManagerInstance().addLogger(logger);
        return logger;
    }
        
    /**
     * @brief Get logger for provided class name
     * 
     * @param name name of the logger
     * @return Logger with the given name
     */
    public static Logger getLog(String name) {
        Logger logger = LogManager.getLogger(name);
        getCbesLogManagerInstance().addLogger(logger);
        return logger;
    }

    /**
     * @brief Manage singleton of CbesLogManager
     * 
     * @return new CbesLogManager object if not yet created, else existing CbesLogManager object
     */
    public static CbesLogManager getCbesLogManagerInstance()
    {
        if (logManager != null) return logManager;
        logManager = new CbesLogManager();
        return logManager;
    }
}
