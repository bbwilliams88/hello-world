package mil.dtic.utility.announcement;

import javax.mail.Address;
import javax.mail.SendFailedException;

public class AnnouncmentExceptionContentManager {
    private static final String NEWLINE = "\n";
    private static final String SPACE = " ";
    private static final String TAB = "\t";
    private static final int INVALID = 0;
    private static final int VALID_NO_SEND = 1;
    private static final int VALID_SEND = 2;

    
    /**
     * Builds email content for an email that generated a SendFailedException
     * @param sfe - SendFailedException
     * @param content - StringBuilder
     */
    static synchronized void buildOutContent(SendFailedException sfe, StringBuilder content){
        
        content.append(AnnouncmentExceptionContentManager.NEWLINE + AnnouncmentExceptionContentManager.NEWLINE + "The following email addresses are INVALID: " 
        + AnnouncmentExceptionContentManager.NEWLINE + AnnouncmentExceptionContentManager.TAB);
        
        if (null != sfe.getInvalidAddresses()){
            processAddresses(AnnouncmentExceptionContentManager.INVALID, sfe, content);
        }
        else {
            content.append("NONE" + AnnouncmentExceptionContentManager.SPACE);
        }
       
        content.append(AnnouncmentExceptionContentManager.NEWLINE + AnnouncmentExceptionContentManager.NEWLINE);
        
        content.append("The following email addresses are VALID but NOT SENT: " 
                + AnnouncmentExceptionContentManager.NEWLINE + AnnouncmentExceptionContentManager.TAB);
       
        if (null != sfe.getValidUnsentAddresses()){
            processAddresses(AnnouncmentExceptionContentManager.VALID_NO_SEND, sfe, content);
        }
        else {
            content.append("NONE" + AnnouncmentExceptionContentManager.SPACE);
        }
        
        content.append(AnnouncmentExceptionContentManager.NEWLINE +  AnnouncmentExceptionContentManager.NEWLINE);
        
        content.append("The following email addresses are VALID and were SENT: "
                + AnnouncmentExceptionContentManager.NEWLINE + AnnouncmentExceptionContentManager.TAB);
        
        if (null != sfe.getValidSentAddresses()){
            processAddresses(AnnouncmentExceptionContentManager.VALID_SEND, sfe, content);
        }
        else{
            content.append("NONE" + AnnouncmentExceptionContentManager.SPACE);
        }
        content.append(AnnouncmentExceptionContentManager.NEWLINE);
        
    }
    
    
    
    private static synchronized void processAddresses(final int validationType, final SendFailedException sfe, StringBuilder content){
        
        switch(validationType){
            
            case AnnouncmentExceptionContentManager.INVALID:
                for (Address address : sfe.getInvalidAddresses()){
                    content.append(address.toString() + AnnouncmentExceptionContentManager.SPACE);
                }
                break;
                
            case  AnnouncmentExceptionContentManager.VALID_NO_SEND:
                for (Address address : sfe.getValidUnsentAddresses()){
                    content.append(address.toString() + AnnouncmentExceptionContentManager.SPACE);
                }
                break;
                
            case  AnnouncmentExceptionContentManager.VALID_SEND:
                for (Address address : sfe.getValidSentAddresses()){
                    content.append(address.toString() + AnnouncmentExceptionContentManager.SPACE);
                }
                break;
                
            default:
                break;
                
        }
        
    }

    
    
}
