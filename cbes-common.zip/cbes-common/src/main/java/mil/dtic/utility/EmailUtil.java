/*
 * $Id$
 */
package mil.dtic.utility;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Environment;
import mil.dtic.cbes.constants.JBookRFREmailStatus;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.sso.siteminder.UserInfo;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndServiceAgencyLink;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserAndServiceAgencyLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.api.EmailService;
import mil.dtic.utility.attachment.RandomStringGenerator;
import mil.dtic.utility.samanage.model.json.ServiceAgencyEmail;
import mil.dtic.utility.samanage.model.json.ServiceAgencyEmailList;
import netscape.ldap.LDAPException;

@Component
public class EmailUtil implements EmailService{
    
    //@formatter:off
    private static final Logger log = CbesLogFactory.getLog(EmailUtil.class);
    private static final String COMPLETED_SUCCESS = "Completed successfully";    
    private static final String JBOOK_REVIEW_REQUEST = "%s JBook Review Request - %s";   
    private static final String JBOOK_REVIEW_REQUEST_SUBJECT = "The subject Justification Book is available for your review.";
    private static final String JBOOK_RFR_REST_ORIGINATOR = "\n\tOriginator: Web Service";
    private static final String JBOOK_RFR_REST_SVC_AGENCY = "\n\tService\\Agency: %s (%s)";
    private static final String JBOOK_RFR_ORIGINATOR = "\n\tOriginator:      \t";
    private static final String JBOOK_RFR_SVC_AGENCY = "\n\tService\\Agency: \t";
    private static final String JBOOK_RFR_APPN = "\n\tAppropriation:   \t";
    private static final String JBOOK_RFR_TITLE = "\n\tTitle(s):        \t";
    private static final String JBOOK_WORKFLOW_STATUS = "\n\tWork Flow Status:\t";
    private static final String JBOOK_EMAIL_RFR_FAIL = "Failed to send RFR email for job with id = ";
    private static final String JBOOK_RFR_COMPLETE_MSG = "\n\nTo access the Justification Book associated with this request, use the url below:\n\n\t%s//%s";
    private static final String JBOOK_RFR_REST_APPN_MSG = "\n\tAppropriation: %s";
    private static final String JBOOK_RFR_REST_TITLE_MSG = "\n\tTitle(s): %s";

    private static final String CR = "\r";
    private static final String NL = "\n";
    private static final String FORWARD_SLASH = "/";
    private static final String COMMA_DELIMTER = ",";
    
    private static final String PROFILE_UPDATE_EMAIL_SUBJ = "Your CXE Profile has been updated";
    private static final String PROFILE_UPDATE_EMAIL_MSG = ", your user profile in the CXE Budget Submission system has been updated.\n You can log in using the link below to see the changes.\n";
    private static final String SEND_USER_ADDED_EMAIL_SUBJ = "%s has been added to the CXE Budget Submission System";
    private static final String SEND_USER_ADDED_EMAIL_MSG_TEMPLATE = "%s , you have been added to the CXE Budget Submission System by %s,\nYou can now log in using the link below:\n %s\n";
    private static final String SEND_REG_EMAIL_SUBJ = "CXE Registration Request by %s %s ";
    private static final String SEND_REG_EMAIL_SUBJ_MSG_TEMPLATE = "%s is requesting access to CXE under organization %s.\n If needed, please log in with the link below and check whether you need to add this user.\n%s\n\n%s";
    private static final String SEND_JOB_COMPLETE_EMAIL_SUBJ = "CXE Status Notification - ";
    private static final String SEND_JOB_COMPLETE_EMAIL_MSG_1 = "The document you requested has been processed. The latest status is shown below. \n\n\tTracking Id: %s\n\tStatus:        %s\n\tOwner:         %s";
    private static final String SEND_JOB_COMPLETE_EMAIL_MSG_2 = "\n\nTo view the details of this request and download any associated file(s), please go to the link below:\n\n\t";
    private static final String SEND_JOB_COMPLETE_EMAIL_MSG_3 = "%s//%s\n\nTo view a history of all your requests, please go to the link below:\n\n\t%s";
    private static final String SEND_JOB_COMPLETE_EMAIL_MSG_4 = "\n\nNote: Document tracking information is periodically purged from the system. Therefore, the history may not show older requests.";
    
    private static final String SYSTEM_INFO_BLOCK_1 = "\n------------------------------- System Info ---------------------------------";
    private static final String SYSTEM_INFO_BLOCK_2 = "\nEnvironment: %s";
    private static final String SYSTEM_INFO_BLOCK_3 = "\nServer: %s";
    private static final String SYSTEM_INFO_BLOCK_4 = "\nContainer: %s\n";
    private static final String SYSTEM_INFO_BLOCK_5 = "\nJava: %s\n";
    private static final String SYSTEM_INFO_BLOCK_6 = "\nBuild: %s//%s\n";
    private static final String SYSTEM_INFO_BLOCK_7 = "\n-----------------------------------------------------------------------------\n";
    
    private static final String USER_INFO_BLOCK_1 = "\n--------------------------------- User Info ---------------------------------\n";
    private static final String USER_INFO_BLOCK_2 = "User Name: %s\nUser Id: %s\n";
    private static final String USER_INFO_BLOCK_3 = "LDAP User Id: %s\nLDAP User Group(s): %s";
    private static final String USER_INFO_BLOCK_4 = "LDAP User Email: %s\nLDAP User Phone: %s";
    private static final String USER_INFO_BLOCK_5 = "Service//Agency Associations: ";
    
    private static final String USER_LDAP_BLOCK_1 = "\n---------------------------- User LDAP Information -------------------------\n";
    private static final String USER_LDAP_BLOCK_2 = "User Id: %s\nName: %s\n";
    private static final String USER_LDAP_BLOCK_3 = "CXE Role: %s\nEmail: %s\nPhone: %s\n";

    private static final String DEFENSE_WIDE_SERVICE_AGENCY = "Defense-Wide";
    
    private Map<String, SimpleEmail> mailBox = new HashMap<>();
        
    @Autowired
    private ConfigService configService;
    
    @Autowired
    private AppDefaults appDefaults;
    
    @Autowired
    private LdapDAO ldapDao;
    
    @Autowired
    private BudgesUserDAO budgesUserDao;
    
    @Autowired
    private BudgesUserAndServiceAgencyLinkDAO budgesUserAndServiceAgencyLinkDao;
    //@formatter:on
    
    @Override
    public void sendEmail(String from, String[] to, String[] cc, String subject, String msg,
            boolean appendDevInfo) throws EmailException, IllegalArgumentException {
        
        log.debug("sendEmail: - start - subject: " + subject);
        if (!validate(from, to, cc, subject, msg)) {
            log.error("sendEmail: - parameters invalid");
            throw new IllegalArgumentException("sendEmail: invalid email parameters");
        }
        
        try {
            subject = stripLineBreaks(subject);
            Environment env = configService.getEnv();
            SimpleEmail email = new SimpleEmail();
            email.setHostName(configService.getEmailHost());
            email.setFrom(stripLineBreaks(from));
            
            for (String e : to) {  //an email is sent to every "to";
                log.debug("toEmail: " + e);
                email.addTo(stripLineBreaks(e));
            }
                
            if (cc != null && cc.length > 0) {
                for (String e2 : cc) {
                    log.debug("ccEmail: " + e2);
                    email.addCc(stripLineBreaks(e2));
                }
            }
            
            if (appendDevInfo) {
                subject = String.format("[%s]%s", env, subject);
            }
            
            email.setSubject(subject);
            String append = "\n\n" + Constants.EMAIL_SIGNATURE;
                
            if (appendDevInfo) {
                append += getSystemInfoBlock(env);
            }
                
            email.setMsg(msg + append);
            
            log.trace(String.format("Sending email from/to/cc/subject %s/%s/%s/%s", 
                    from, Arrays.toString(to), Arrays.toString(cc), email.getSubject()));
            
            email.send();
        } 
        catch (EmailException e) {
            log.error("Could not send email", e);
            throw e;
        }
    }
    
    @Override
    public void sendProfileUpdateEmail(UserCredentials srcUc, LdapUser destUser) throws EmailException {
        String from = resolveEmail(configService.getEmailFrom(), srcUc);
        String to = destUser.getEmailAddress();
        String fullName = destUser.getFullName();
        String subject = EmailUtil.PROFILE_UPDATE_EMAIL_SUBJ;
        String msg = fullName + PROFILE_UPDATE_EMAIL_MSG + configService.getLoginUrl();
        sendEmail(from, new String[] { to }, new String[0], subject, msg, !configService.isProd());
    }
    
    // called by NewAdminUsers.java
    @Override
    public void sendUserAddedEmail(UserCredentials srcUc, LdapUser destUser, Integer agencyId)
            throws EmailException, LDAPException {
        
        String from = resolveEmail(configService.getEmailFrom(), srcUc);
        String to = destUser.getEmailAddress();
        String fullName = destUser.getFullName();
        String subject = String.format(EmailUtil.SEND_USER_ADDED_EMAIL_SUBJ, destUser.getFullName());
        String msg = String.format(EmailUtil.SEND_USER_ADDED_EMAIL_MSG_TEMPLATE, fullName, 
                srcUc.getUserInfo().getBudgesUser().getFullName(),configService.getLoginUrl());
        
        String r2support = resolveEmail(configService.getEmailTo(), srcUc);
        String[] cc = new String[] { r2support };
        if (agencyId != null) {
            List<String> ccList = getAdminEmailsForAgency(agencyId);
            ccList.add(r2support);
            cc = ccList.toArray(new String[0]);
        }
        
        sendEmail(from, new String[] { to }, cc, subject, msg, !configService.isProd());
    }
    
    //called by P40AdminUser.java -- TODO: check to see if this is deprecated.
    @Override
    public void sendP40UserAddedEmail(String senderLDAPAddress, String recipientLDAPAddress,
            String senderFullName, String recipientFullName, Integer agencyId) throws EmailException, LDAPException {
        String from = senderLDAPAddress;
        String to = recipientLDAPAddress;
        
        String subject = String.format(EmailUtil.SEND_USER_ADDED_EMAIL_SUBJ, recipientFullName);
        String msg = String.format(SEND_USER_ADDED_EMAIL_MSG_TEMPLATE,recipientFullName, 
                senderFullName, configService.getLoginUrl());   
        String[] cc = new String[] { from };
        if (agencyId != null) {
            List<String> ccList = getAdminEmailsForAgency(agencyId);
            ccList.add(from);
            cc = ccList.toArray(new String[0]);
        }
        
        sendEmail(from, new String[] { to }, cc, subject, msg, !configService.isProd());
    }
    
    //called among PreviewDelegate, T5CRUDlayout, SendEmailOnInvalidXML(P40), ManageAppPropsBase, ManageValidationRules, SendEmailOnInvalidXML(R2)
    @Override
    public void sendSystemEmail(String subject, String msg) throws EmailException {
        String sender = configService.getEmailFrom();
        String recipient = configService.getEmailTo();
        sendSystemEmail(subject, msg, sender, recipient, null);
    }
    
    //@formatter:off
    //called among PreviewDelegate, T5CRUDlayout, SendEmailOnInvalidXML(P40), ManageAppPropsBase, ManageValidationRules, SendEmailOnInvalidXML(R2)
    //@formatter:on
    @Override
    public void sendSystemEmail(String subject, String msg, UserCredentials userCredentials) throws EmailException {
        String sender = resolveEmail(configService.getEmailFrom(), userCredentials);
        String recipient = resolveEmail(configService.getEmailTo(), userCredentials);
        String userInfo = getUserInfoBlock(userCredentials);
        
        sendSystemEmail(subject, msg, sender, recipient, userInfo);
    }
    
  //@formatter:off
    //called among PreviewDelegate, T5CRUDlayout, SendEmailOnInvalidXML(P40), ManageAppPropsBase, ManageValidationRules, SendEmailOnInvalidXML(R2)
  //@formatter:on
    @Override
    public void sendSystemEmail(String subject, String msg, P40User p40User) throws EmailException {
        String sender = resolveEmail(configService.getEmailFrom(), p40User.getEmail());
        String recipient = resolveEmail(configService.getEmailTo(), p40User.getEmail());
        String userInfo = getUserInfoBlock(p40User);
        
        sendSystemEmail(subject, msg, sender, recipient, userInfo);
    }
    
    
    // NotRegisteredPage email
    @Override
    public void sendRegEmail(UserCredentials senderCreds, ServiceAgency org, boolean hasAdmins,
            String adminUidsLine, String[] cc, String... to) throws EmailException {
        LdapUser sender = senderCreds.getUserInfo().getLdapUser();
        String from = resolveEmail(configService.getEmailFrom(), senderCreds);
        String subject = String.format(EmailUtil.SEND_REG_EMAIL_SUBJ, sender.getFullName(), hasAdmins ? "" : " -- Action Required by DTIC");
        String msg = String.format(EmailUtil.SEND_REG_EMAIL_SUBJ_MSG_TEMPLATE, sender.getFullName(), org.getName(), 
                configService.getAdminUsersUrl(), getUserLdapBlock(sender));
        //CXE-6764
        sendFromPostalCode(sendEmail(from, to, cc, subject, msg, !configService.isProd(),false));
        
    }
    
    @Override
    public boolean sendJobCompleteEmail(BudgesJob theJob, BudgesUser theUser) {
        log.trace("sendJobCompleteEmail: - start");        
        boolean retValue = false;
        boolean sendRfrEmail = false;
        Integer emailStatus = JBookRFREmailStatus.EMAIL_FAIL.getCode(); //set initial status to 0
        
        if (isRfr(theJob)) {
            sendRfrEmail = true;
            if (null == theUser) {
                return sendRfrJobCompletedREST(theJob);
            }
        }
        
        String from = configService.getJobManagerFrom();
        String to = resolveEmail(configService.getJobManagerEmailTo(), theUser.getEmail());
        String subject = EmailUtil.SEND_JOB_COMPLETE_EMAIL_SUBJ + theJob.getJobStatus().toString();
        String msg = String.format(EmailUtil.SEND_JOB_COMPLETE_EMAIL_MSG_1,theJob.getUuidStr(),
                theJob.getJobStatus().getDesc(),theUser.getUserLdapId());
        msg += EmailUtil.SEND_JOB_COMPLETE_EMAIL_MSG_2;
        msg += String.format(EmailUtil.SEND_JOB_COMPLETE_EMAIL_MSG_3,configService.getTrackingUrl(),
                theJob.getUuidStr(), configService.getTrackingUrl());
        msg += EmailUtil.SEND_JOB_COMPLETE_EMAIL_MSG_4;
        
        try {
            sendEmail(from, new String[] { to }, null, subject, msg, !configService.isProd());
            retValue = true;
            emailStatus = JBookRFREmailStatus.EMAIL_SUCCESS.getCode();
        } 
        catch (EmailException e) {
            log.error("sendJobCompleteEmail: Failed to send email for job with id = " + theJob.getUuidStr(), e);
        }
        
        if (sendRfrEmail && retValue && (theJob.getJobStatus().getDesc()).equals(EmailUtil.COMPLETED_SUCCESS)) {
            if (sendRfrJobCompleted(from, theUser, theJob, to)) {
                emailStatus = JBookRFREmailStatus.EMAIL_RFR_SUCCESS.getCode();
            } 
            else {
                emailStatus = JBookRFREmailStatus.EMAIL_RFR_FAIL.getCode();
            }
        }
        
        JBookRFREmailStatus jBookRFREmailStatus = JBookRFREmailStatus.valueOf(emailStatus);
        log.debug("sendJobCompleteEmail: rfr email status: " + jBookRFREmailStatus.getDisplayMessage());
        return retValue;
    }
    
    @Override
    public String getSystemInfoBlock(Environment env) {
        StringBuilder infoMsg = new StringBuilder();
        infoMsg.append(EmailUtil.SYSTEM_INFO_BLOCK_1);
        infoMsg.append(String.format(EmailUtil.SYSTEM_INFO_BLOCK_2, env.getDesc()));
        infoMsg.append(String.format(EmailUtil.SYSTEM_INFO_BLOCK_3,getLocalHostName()));
        infoMsg.append(String.format(EmailUtil.SYSTEM_INFO_BLOCK_4, 
                System.getProperty(Constants.SYSKEY_CONTAINER_NAME, "(Unknown)")));
        infoMsg.append(Util.getDatabaseInfo(configService.getDataSource())+ "\n");
        infoMsg.append(String.format(EmailUtil.SYSTEM_INFO_BLOCK_5,System.getProperty("java.version", "(Unknown)")));
        infoMsg.append(String.format(EmailUtil.SYSTEM_INFO_BLOCK_6,appDefaults.getFrontendVersion().getBuildnumber(),
                appDefaults.getCurrentRelease().getBuild()));
        infoMsg.append(EmailUtil.SYSTEM_INFO_BLOCK_7);
        return infoMsg.toString();
    }
    
    @Override
    public String getUserInfoBlock(UserCredentials userCredentials) {
        StringBuffer infoMsg = new StringBuffer();
        
        if (userCredentials != null) {
            UserInfo userInfo = userCredentials.getUserInfo();
            if (userInfo != null) {
                BudgesUser budgesUser = userInfo.getBudgesUser();
                infoMsg.append(EmailUtil.USER_INFO_BLOCK_1);
                infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_2, userInfo.getLdapUser().getFullName(),
                        (budgesUser == null ? "(none)" : budgesUser.getId().toString())));
                infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_3, userInfo.getLdapUser().getLdapUserId(), 
                        userInfo.getLdapUser().getGroupSet()));
                infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_4, userInfo.getLdapUser().getEmailAddress(), 
                        userInfo.getLdapUser().getPhoneNumber()));
                
                
                // User's associated services/agencies
                infoMsg.append(EmailUtil.USER_INFO_BLOCK_5);
                if (budgesUser == null) {
                    infoMsg.append("(none)\n");
                } else {
                    String agencyCodeList = BudgesUserAndServiceAgencyLink
                            .getBudgesServAgyCodesAsCsv(new ArrayList<BudgesUserAndServiceAgencyLink>
                            (budgesUser.getBudgesUserAndServiceAgencyLinks()));
                    if (StringUtils.isNotEmpty(agencyCodeList)) {
                        infoMsg.append(agencyCodeList);
                    }
                }
                infoMsg.append(EmailUtil.SYSTEM_INFO_BLOCK_7);
            }
        }
        return infoMsg.toString();
    }
    
    @Override
    public String getUserInfoBlock(P40User p40User) {
        StringBuffer infoMsg = new StringBuffer();
        
        if (p40User != null) {
            infoMsg.append(EmailUtil.USER_INFO_BLOCK_1);
            infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_2, p40User.getFullName(),p40User.getId().toString()));
            infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_3, p40User.getUserLdapId(), 
                    StringUtils.join(p40User.getRoles(), EmailUtil.COMMA_DELIMTER) ));
            infoMsg.append(String.format(EmailUtil.USER_INFO_BLOCK_4, p40User.getEmail(), p40User.getPhoneNum()));
            infoMsg.append(EmailUtil.USER_INFO_BLOCK_5);
            
            if (CollectionUtils.isEmpty(p40User.getActiveAgencies())) {
                infoMsg.append("(none)\n");
            } 
            else {
                List<String> codes = new ArrayList<String>();
                for (mil.dtic.cbes.p40.vo.ServiceAgency sa : p40User.getActiveAgencies()) {
                    codes.add(sa.getCode());
                }
                infoMsg.append(StringUtils.join(codes, EmailUtil.COMMA_DELIMTER));
            }
            infoMsg.append(EmailUtil.SYSTEM_INFO_BLOCK_7);
        }
        
        return infoMsg.toString();
    }
    
    @Override
    public String getUserLdapBlock(LdapUser luser) {
        if (luser == null) {
            return null;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(EmailUtil.USER_LDAP_BLOCK_1);
        sb.append(String.format(EmailUtil.USER_LDAP_BLOCK_2,luser.getLdapUserId() ,luser.getFullName()));
        sb.append(String.format(EmailUtil.USER_LDAP_BLOCK_3,luser.getR2Role(), 
                luser.getEmailAddress(), luser.getPhoneNumber()));
        sb.append(EmailUtil.SYSTEM_INFO_BLOCK_7);
        
        return sb.toString();
    }
    
    @Override
    public String resolveEmail(String email, UserCredentials userCredentials) {
        if (userCredentials != null && userCredentials.getUserInfo() != null) {
            return resolveEmail(email, userCredentials.getUserInfo().getLdapUser().getEmailAddress());
        }
        return email;
    }
    
    @Override
    public String resolveEmail(String email, String currentUserAddress) {
        if (Constants.EMAIL_CURRENT_USER_EMAIL_KEY.equals(email)){
            return currentUserAddress;
        }
        return email;
    }
    
    @Override
    public String getLocalHostName() {
        try {
            return InetAddress.getLocalHost().getCanonicalHostName();
        }
        catch (UnknownHostException e) {
            log.debug("getLocalHostName: - Could not get local host info", e);
        }
        return "";
    }
    
    @SuppressWarnings({"deprecation"})
    private List<String> getAdminEmailsForAgency(Integer agencyId) throws LDAPException, IllegalArgumentException {
        if (agencyId == null) {
            throw new IllegalArgumentException();
        }
        String[] allAdminIds = ldapDao.getAllAdminUserIds();
        List<BudgesUser> allAdmins = budgesUserDao.findByUserLdapIds(allAdminIds);
        List<BudgesUserAndServiceAgencyLink> links = 
                budgesUserAndServiceAgencyLinkDao.findByBudgesUsersAndAgency(allAdmins, agencyId);
        
        
        List<String> adminEmails = new ArrayList<String>(links.size() + 1);
        
        for (BudgesUserAndServiceAgencyLink link : links) {
            if (!link.getBudgesUser().getStatusFlag().isActive()) {
                continue;  // don't email inactive users
            }
            LdapUser luser = ldapDao.getLdapUser(link.getBudgesUser().getUserLdapId());
            adminEmails.add(luser.getEmailAddress());
        }
        return adminEmails;
    }

    @SuppressWarnings("deprecation")
	public List<LdapUser> getAdminUserForAgency(Integer agencyId) throws LDAPException, IllegalArgumentException {
        if (agencyId == null) {
            throw new IllegalArgumentException();
        }
        String[] allAdminIds = ldapDao.getAllAdminUserIds();
        List<BudgesUser> allAdmins = budgesUserDao.findByUserLdapIds(allAdminIds);
        List<BudgesUserAndServiceAgencyLink> links = budgesUserAndServiceAgencyLinkDao.findByBudgesUsersAndAgency(allAdmins, agencyId);
        
        if (links == null) {
        	return Collections.emptyList();
        }

        List<LdapUser> adminUserList = new ArrayList<LdapUser>(links.size() + 1);
        for (BudgesUserAndServiceAgencyLink link : links) {
            if (!link.getBudgesUser().getStatusFlag().isActive()) {
                continue;  // don't email inactive users
            }
            LdapUser user = ldapDao.getLdapUser(link.getBudgesUser().getUserLdapId());
            adminUserList.add(user);
        }
        return adminUserList;
    }

    private String stripLineBreaks(String headerString) {
        if (headerString != null) {
            return headerString.replace(EmailUtil.CR, " ").replace(EmailUtil.NL, " ");
        }
        return null;
    }

    private String getTitle(String jobTitle) {
        if (null == jobTitle || jobTitle.equals(Constants.TITLES_UNDEFINED)){
            return Constants.BLANK_TITLE;
        } else {
            return jobTitle;
        }
    }
    
    private void sendSystemEmail(String subject, String msg, String senderEmailAddress, String recipientEmailAddress, 
            String userInfo) throws EmailException {
        
        try {
            Environment env = configService.getEnv();
            SimpleEmail email = new SimpleEmail();
            email.setHostName(configService.getEmailHost());
            email.setFrom(senderEmailAddress);
            email.addTo(recipientEmailAddress);
            email.setSubject("[" + env.getDesc() + "] " + subject);
            email.setMsg(msg + userInfo + getSystemInfoBlock(env) + Constants.EMAIL_SIGNATURE);
            log.debug("sendSystemEmail: - Sending email [from/to/subject]:  " 
                    + senderEmailAddress + EmailUtil.FORWARD_SLASH 
                    + recipientEmailAddress + EmailUtil.FORWARD_SLASH  + email.getSubject());
            email.send();
        } catch (EmailException e) {
            log.error("sendSystemEmail: Could not send system email", e);
            throw e;
        }
    }
    
    private synchronized boolean sendRfrJobCompleted(String from, BudgesUser theUser, BudgesJob theJob, String cc) {
        log.trace("sendRfrJobCompleted - start: " + theJob.getUuid());
        boolean retValue = false;
        String[] copyTo = new String[] { cc };
        String rfrList = configService.getJbReviewers();
        String[] rfrArray = rfrList.split(EmailUtil.COMMA_DELIMTER);

        String subject = String.format(JBOOK_REVIEW_REQUEST, theJob.getAgency().getCode(), StringUtils.upperCase(JBookWorkFlowStatus.getByType(theJob.getReadyForReview()).getDisplayName()));
        
        String msg = EmailUtil.JBOOK_REVIEW_REQUEST_SUBJECT;
        msg += EmailUtil.JBOOK_RFR_ORIGINATOR + 
                StringUtils.trim(theUser.getFullName() + " (email: " + cc + " )");
        msg += EmailUtil.JBOOK_RFR_SVC_AGENCY + 
                StringUtils.trim(theJob.getAgency().getCode() + " (" + theJob.getAgency().getName() + ")");
        msg += EmailUtil.JBOOK_RFR_APPN + StringUtils.trim(theJob.getAppropriation().trim());
        msg += EmailUtil.JBOOK_RFR_TITLE + StringUtils.trim(getTitle(theJob.getVolumeTitleAggregation()).trim());
        
        JBookWorkFlowStatus jBookWorkFlowStatus = JBookWorkFlowStatus.getByType(theJob.getReadyForReview());
        msg += EmailUtil.JBOOK_WORKFLOW_STATUS +  jBookWorkFlowStatus.getDisplayName();
        msg += String.format(EmailUtil.JBOOK_RFR_COMPLETE_MSG,configService.getTrackingUrl(), theJob.getUuidStr());
        
        try {
            sendEmail(from, rfrArray, copyTo, subject, msg, false);
            retValue = true;
        } 
        catch (EmailException e) {
            log.error(EmailUtil.JBOOK_EMAIL_RFR_FAIL + theJob.getUuidStr(), e);
        }
        
        return retValue;
    }
    
    private synchronized boolean isRfr(BudgesJob theJob) {
        Integer rfr = theJob.getReadyForReview();
        if (null != rfr && rfr > 0 && !theJob.getAgency().getName().equals(DEFENSE_WIDE_SERVICE_AGENCY)) {
            return true;
        }
        
        return false;
    }

    //CXE-6709
    private String[] getWsCcRfrArray(String saCode) {  
        log.trace("getWsCcRfrArray: start - saCode: " + saCode);
        
        String[] defaultEmailArray = new String[] {};
        ServiceAgencyEmailList saEmailList = null;
        ServiceAgencyEmail saMail = null;
        String[] saEmailArray = null;
        
        String json = configService.getRestRfrServiceAgencyEmailList();
        log.trace("getWsCcRfrArray: json: " + json);
        
        try { 
            saEmailList = new Gson().fromJson(json, ServiceAgencyEmailList.class);
            
            List<ServiceAgencyEmail> saEmails = saEmailList.getServiceAgencyEmails();
            
            if (null == saEmails || saEmails.size() < 1) {
                return defaultEmailArray;
            }
            
            for (ServiceAgencyEmail sae : saEmails) {
                if (sae.getSaCode().equals(saCode)) {
                    saMail = sae;
                }
            }
            
            if (null == saMail) {
                log.trace("getWsCcRfrArray: no emails associated with service agency: " + saCode);
                return defaultEmailArray;
            }
            else {
                saEmailArray = saMail.getEmails().split(EmailUtil.COMMA_DELIMTER);
                boolean ok = false;
                
                for (int i = 0; i < saEmailArray.length; i++) {
                    // TODO: need emailValidation as new task.
                    ok = true;
                    log.trace("getWsCcRfrArray: - serviceAgency: " + saCode + " email: " + saEmailArray[i] 
                            + " status: " + ok);
                }
                if (ok) {
                    return saEmailArray;
                }
            }
        }
        catch(Exception e) {
            log.error("getWsCcRfrArray: - failed to unmarshall json emails for serviceAgency: " + saCode);
            return defaultEmailArray;
        }
        
        return defaultEmailArray;
    }
        

    @SuppressWarnings("unused")
    private String[] getWSCcRfrArray(String saCode) {
        return null;
    }
    
    private boolean sendRfrJobCompletedREST(BudgesJob theJob) {
        log.trace("sendRfrJobCompletedREST: - start");
        boolean retValue = false;
        String from = configService.getJobManagerFrom();
        
        String rfrList = configService.getJbReviewers(); 
        String[] rfrArray = rfrList.split(EmailUtil.COMMA_DELIMTER);
        String[] ccRfrArray = getWsCcRfrArray(theJob.getAgency().getCode());
        String rfrStatusText = JBookWorkFlowStatus.getByType(theJob.getReadyForReview()).getDisplayName();

        String subject = String.format(JBOOK_REVIEW_REQUEST, theJob.getAgency().getCode(), StringUtils.upperCase(JBookWorkFlowStatus.getByType(theJob.getReadyForReview()).getDisplayName()));        
        String msg = EmailUtil.JBOOK_REVIEW_REQUEST_SUBJECT;
        msg += EmailUtil.JBOOK_RFR_REST_ORIGINATOR;
        msg += String.format(EmailUtil.JBOOK_RFR_REST_SVC_AGENCY, 
                StringUtils.trim(theJob.getAgency().getCode()),theJob.getAgency().getName());
        msg += String.format(EmailUtil.JBOOK_RFR_REST_APPN_MSG, 
                StringUtils.trim(theJob.getAppropriation().trim()));
        msg += String.format(EmailUtil.JBOOK_RFR_REST_TITLE_MSG, StringUtils.trim(getTitle(theJob.getVolumeTitleAggregation()).trim()));
        msg += EmailUtil.JBOOK_WORKFLOW_STATUS +  rfrStatusText;
        msg += String.format(JBOOK_RFR_COMPLETE_MSG,StringUtils.trim(configService.getTrackingUrl()),theJob.getUuidStr());
        
        if (theJob.getReadyForReview() > 0){
            msg += "\n\n\t" +  theJob.getRfrFinalContent();
        }
        
        try {
            sendEmail(from, rfrArray, ccRfrArray, subject, msg, false);
            retValue = true;
        } 
        catch (EmailException e) {
            log.error("Failed to send RFR email for job with id = " + theJob.getUuidStr(), e);
        }
        
        return retValue;
    }
    
    private boolean validate(String from, String[] to, String[] cc, String subject, String msg) {
        if (from == null || ((to == null || to.length == 0) && cc == null) || subject == null || msg == null) {
            return false;
        }
        return true;
    }
    
    
    

    @Override
    public String sendEmail(String from, String[] to, String[] cc, String subject, String msg,
            boolean appendDevInfo, boolean b) throws EmailException, IllegalArgumentException {
        
        log.debug("sendEmail: - start mailBox size: " + mailBox.size());
        String postalCode = null;
        if (!validate(from, to, cc, subject, msg)) {
            log.error("sendEmail: - parameters invalid");
            throw new IllegalArgumentException("sendEmail: invalid email parameters");
        }
        
        try {
            subject = stripLineBreaks(subject);
            Environment env = configService.getEnv();
            SimpleEmail email = new SimpleEmail();
            email.setHostName(configService.getEmailHost());
            email.setFrom(stripLineBreaks(from));
            
            for (String e : to) {  //an email is sent to every "to";
                log.debug("toEmail: " + e);
                email.addTo(stripLineBreaks(e));
            }
                
            if (cc != null && cc.length > 0) {
                for (String e2 : cc) {
                    log.debug("ccEmail: " + e2);
                    email.addCc(stripLineBreaks(e2));
                }
            }
            
            if (appendDevInfo) {
                subject = String.format("[%s]%s", env, subject);
            }
            email.setSubject(subject);
            
                
            String append = "\n\n" + Constants.EMAIL_SIGNATURE;
                
            if (appendDevInfo) {
                append += getSystemInfoBlock(env);
            }
                
            email.setMsg(msg + append);
            email.buildMimeMessage();
            log.debug(String.format("Sending email from/to/cc/subject %s/%s/%s/%s", 
                    from, Arrays.toString(to), Arrays.toString(cc), email.getSubject()));
                //email.send();
            postalCode = RandomStringGenerator.getToken();
            mailBox.put(postalCode, email);
            log.debug("sendEmail: placed email email at postalCode: " + postalCode);
            
        } 
        catch (EmailException e) {
            log.error("Could not send email", e);
            throw e;
        }
        return postalCode;
    }

    @Override
    public void sendFromPostalCode(String postalCode) throws EmailException{
        log.debug("sendFromPostalCode: " + mailBox.size());
        
        try {
            SimpleEmail mail = mailBox.get(postalCode);
            if (null != mail) {
                mail.sendMimeMessage();
            }
            else {
                log.debug("postalCode: " + postalCode + " not found in mailbox");
                return;
            }
        }
        catch(Exception e) {
            if (e instanceof EmailException) {
                log.error("sendFromPostalCode email exception: " + e.getMessage(),e);
                throw e;
            }
            else {
                log.error("sendFromPostalCode general exception:" + e.getMessage(),e);
            }
        }
        mailBox.remove(postalCode);
        
    }
    
    
    
    
}
