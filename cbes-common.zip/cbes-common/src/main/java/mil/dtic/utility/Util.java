package mil.dtic.utility;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import javax.sql.DataSource;

import org.apache.cayenne.CayenneDataObject;
import org.apache.cayenne.CayenneRuntimeException;
import org.apache.cayenne.Fault;
import org.apache.cayenne.Persistent;
import org.apache.cayenne.reflect.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.TransformerUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.poi.util.MethodUtils;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.exceptions.MethodDispatchException;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.p40.vo.AuditableBase;
import mil.dtic.cbes.p40.vo.Base;
import mil.dtic.cbes.p40.vo.Costs;
import mil.dtic.cbes.p40.vo.HasTotalCosts;
import mil.dtic.cbes.p40.vo.HasTotalCostsAndQuantities;
import mil.dtic.cbes.p40.vo.HasTripletCosts;
import mil.dtic.cbes.p40.vo.HasUnitsAndBudgetYear;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.AuditableObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.ValueObjects.CongressionalAddDetail;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryItem;
import mil.dtic.cbes.submissions.ValueObjects.HasDisplayOrder;
import mil.dtic.cbes.submissions.ValueObjects.MajorPerformer;
import mil.dtic.cbes.submissions.ValueObjects.OtherAdjustmentDetail;
import mil.dtic.cbes.submissions.ValueObjects.OtherProgramFundingSummary;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.delegates.DelegateResultInfo;

public class Util
{ 
  private static final Logger log = CbesLogFactory.getLog(Util.class);
  
  
  private static final String[] fyMethodList = {"getPriorYears", "getPriorYear", "getCurrentYear", "getBy1Base", "getBy1Ooc", "getBy1", "getBy2", "getBy3", "getBy4", "getBy5", "getToComplete", "getTotal"};
  private static final String[] fySetMethodList = {"setPriorYears", "setPriorYear", "setCurrentYear", "setBy1Base", "setBy1Ooc", "setBy1", "setBy2", "setBy3", "setBy4", "setBy5", "setToComplete", "setTotal"};
  private static final String[] fyLabelList = {"Prior Years", "Prior Year", "Current Year", "Budget Year One Base", "Budget Year One OOC", "Budget Year One", "Budget Year Two", "Budget Year Three", "Budget Year Four", "Budget Year Five", "To Complete", "Total"};
  private static final String[] fyModsManufacturerList = {"Py", "Cy", "By1", "By2", "By3", "By4", "By5"};
  
  public static <T extends Throwable> void error(Logger log, String message, T exception) throws T
  {
      log.error(message, exception);
      throw exception;
  }

  public static <T extends Throwable> void fatal(Logger log, String message, T exception) throws T
  {
      log.fatal(message, exception);
      throw exception;
  }

  public static void throwRuntimeException(String msg)
  {
      log.error("An exception has occurred: " + msg);
      
      throw new RuntimeException(msg);
  }

  public static Object dispatch(Object object, String methodName) throws MethodDispatchException
  {
      return dispatch(object, methodName, null, null);
  }

  // IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
  public static Object dispatch(Object object, String methodName, Class<?>[] parameterTypes, Object[] args) throws MethodDispatchException
  {
      Object value = null;

      try
      {
          value = MethodUtils.invokeMethod(object, methodName, args, parameterTypes);
      }
      
      catch (IllegalArgumentException | InvocationTargetException e)
      {
          Util.error(log, "An exception was thrown while executing method " + methodName, new MethodDispatchException(e));
      }
       
      catch (IllegalAccessException | NoSuchMethodException | SecurityException e)
      {
          Util.fatal(log, "Error dispatching " + methodName, new MethodDispatchException(e));
      }

      return value;
    }

  public static boolean isEmpty(StringBuilder sb)
  {
    return(sb == null || sb.length() == 0);
  }

  public static String addDotLeader(String leftValue, String rightValue, int len)
  {
    return addLeader(leftValue, rightValue, len, '.');
  }

  public static String addLeader(String leftValue, String rightValue, int len, char leaderChar)
  {
    leftValue = StringUtils.defaultIfEmpty(leftValue, "");
    rightValue = StringUtils.defaultIfEmpty(rightValue, "");
    
    int dataLen = leftValue.length() + rightValue.length();
    
    if (dataLen > 0)
    {
      StringBuilder sb = new StringBuilder(leftValue);
      
      len = len - dataLen;
      
      for (int i = 0; i < len; ++i){
        sb.append(leaderChar);
      }  
      
      sb.append(rightValue);
      
      return sb.toString();
    }
    
    return StringUtils.EMPTY;
  }

  public static String splitCamelCase(String s) {
    return s.replaceAll(
       String.format("%s|%s|%s",
          "(?<=[A-Z])(?=[A-Z][a-z])",
          "(?<=[^A-Z])(?=[A-Z])",
          "(?<=[A-Za-z])(?=[^A-Za-z])"
       ),
       " "
    );
  }

  public static String formatIndex(int index)
  {
    int whatmatters = Math.abs(index);
    
    if (whatmatters > 99)
    {
      // get last two digits
      String s = whatmatters + "";
      whatmatters = Integer.parseInt(s.substring(s.length() - 2, s.length()));
    }

    // 11, 12, 13 are exceptions
    switch (whatmatters)
    {
      case 11:
        return index + "th";
      case 12:
        return index + "th";
      case 13:
        return index + "th";
    }
    
    // Everything else that ends with 1/2/3 have their special endings
    String s = whatmatters + "";
    
    int lastDigitIndex = s.length() == 2 ? 1 : 0;
    
    switch (s.charAt(lastDigitIndex))
    {
      case '1':
        return index + "st";
      case '2':
        return index + "nd";
      case '3':
        return index + "rd";
    }
    // everyone else
    return index + "th";
  }

  public static int getIntValue(Integer intObj)
  {
    if (intObj == null){
      return(0);
    } 
    
    return(intObj.intValue());
  }

  public static String getUnqualifiedClassName(Class clas)
  {
    String className = clas.getName();
    className = className.substring(className.lastIndexOf('.') + 1);
    
    return className;
  }

  public static void setAuditFieldsForNewObject(AuditableObject record, BudgesUser budgesUser)
  {
    Date now = new Date();
    record.setDateCreated(now);
    record.setDateModified(now);
    record.setCreatedByBudgesUser(budgesUser);
    record.setModifiedByBudgesUser(budgesUser);
  }

  public static void setAuditFieldsForUpdatedObject(AuditableObject record, BudgesUser budgesUser)
  {
    record.setModifiedByBudgesUser(budgesUser);
    record.setDateModified(new Date());
  }

  public static void setAuditFieldsForDeletedObject(AuditableObject record)
  {
    record.setDateCreated(null);
    record.setDateModified(null);
    record.setCreatedByBudgesUser(null);
    record.setModifiedByBudgesUser(null);
  }

  public static void setAuditFieldsForUser(BudgesUser buser, BudgesUser admin)
  {
    Date now = new Date();
    
    if (buser.getCreatedByBudgesUser() == null)
    {
      buser.setDateCreated(now);
      buser.setCreatedByBudgesUser(admin);
    }
    
    buser.setDateModified(now);
    buser.setModifiedByBudgesUser(admin);
  }

  public static void setAuditFields(AuditableBase record, P40User moduser)
  {
      moduser = CayenneUtils.copyToContext(moduser, record.getObjectContext());
//      moduser = moduser.getInOtherContext(record.getObjectContext());
    Date now = new Date();
    
    if (record.getCreatedBy() == null)
    {
      record.setDateCreated(now);
      record.setCreatedBy(moduser);
    }
    
    record.setDateModified(now);
    record.setModifiedBy(moduser);
  }


  public static InputStream getResourceFromClassPath(String name)
  {
    InputStream stream = Util.class.getClassLoader().getResourceAsStream(name);
    
    if (stream == null){
      return null;
    }
    
    else{
      return stream;
    }
  }

  public static InputStream getResourceFromClassPath(String path, String name)
  {
    InputStream stream = Util.class.getClassLoader().getResourceAsStream(path + name);
    if (stream == null){
      return null;
    }
    
    else{
      return stream;
    }
  }

  public static InputStream getResourceFromClassPath(List<String> pathList, String name)
  {
    InputStream inputStream = null;
    for (String path : pathList)
    {
      inputStream = getResourceFromClassPath(path, name);
      
      if (inputStream != null){
        break;
      }  
    }
    // If the resource was not found in the class path, look for it in the file
    // system
    if (inputStream == null){
      FileUtil.getFileInputStream(pathList, name);
    }

    return inputStream;
  }

  public static String createLiMapKey(String liNum, int index)
  {
    if (liNum == null)
    {
      throwRuntimeException("Cannot create map key because the LineItem number is null");
    }
    
    return liNum + "." + index;
  }

  public static String createPeMapKey(String peNum, int index)
  {
    if (peNum == null)
    {
      throwRuntimeException("Cannot create map key because the PE number is null");
    }
    
    return peNum + "." + index;
  }

  public static BigDecimal getBigDecimal(BigDecimal bd)
  {
    if (bd == null){
      bd = Constants.DEFAULT_FUNDING_VALUE;
    }
    
    return(bd);
  }

  public static String quoteValue(String colorValue)
  {
    return String.format("'%s'", colorValue);
  }

  public static String convertBooleanToYesNoString(boolean val)
  {
    return(val ? Constants.YES : Constants.NO);
  }

  public static String explicitTruncate(String s)
  {
    return explicitTruncate(s, Constants.DEFAULT_STRING_TRUNCATION_LENGTH);
  }

  public static String explicitTruncate(String s, int limit)
  {
    if (StringUtils.isNotEmpty(s) && s.length() > limit){
      s = s.substring(0, limit - 1) + "...";
    }  
    
    return s;
  }

  public static Integer getInitDisplayOrder(int index)
  {
    return((index + 1) * Constants.UI_DISPLAY_ORDER_INIT_VALUE);
  }

  public static Integer getNextDisplayOrderValue(Collection<? extends HasDisplayOrder> c)
  {
    int displayOrder = 0;
    
    if (CollectionUtils.isNotEmpty(c))
    {
      for (HasDisplayOrder item : c)
      {
        if (item.getDisplayOrder() != null && displayOrder < item.getDisplayOrder().intValue())
          displayOrder = item.getDisplayOrder().intValue();
      }
    }
    
    displayOrder += Constants.UI_DISPLAY_ORDER_INIT_VALUE;
    
    return displayOrder;
  }

  private static List<? extends BudgesBaseValueObject> sortBudgesObjects(Collection<? extends BudgesBaseValueObject> budgesObjectsCollection, String secondarySortMethodName)
  {
    List<? extends BudgesBaseValueObject> list = null;
    
    if (budgesObjectsCollection instanceof List){
      list = (List<? extends BudgesBaseValueObject>) budgesObjectsCollection;
    }
    
    else{
      list = toArrayList(budgesObjectsCollection);
    }
    
    BeanComparitor bc = new BeanComparitor("getDisplayOrder", secondarySortMethodName);
    
    Collections.sort(list, bc);
    
    return list;
  }

  public static <T extends HasDisplayOrder> List<T> getSortedByDisplayOrder(Collection<T> objects)
  {
    ArrayList<T> list = new ArrayList<T>(objects);
    
    @SuppressWarnings("unchecked")
    Comparator<T> displayorder = ComparatorUtils.transformedComparator(ComparatorUtils.NATURAL_COMPARATOR,
      TransformerUtils.invokerTransformer("getDisplayOrder"));
    
    Collections.sort(list, displayorder);
    
    return list;
  }

  /**
   * Generate display orders for a given list.
   *
   * @param list
   *          The list containing objects with a displayOrder attribute.
   * @return <tt>true</tt> if the list was modified, <tt>false</tt> if not.
   */
  public static boolean generateDisplayOrder(List<? extends HasDisplayOrder> list)
  {
    boolean modified = false;

    for (int i = 0; i < list.size(); i++)
    {
      Integer existing = list.get(i).getDisplayOrder();
      
      if (existing == null || existing != i + 1)
      {
        list.get(i).setDisplayOrder(i + 1);
        
        modified = true;
      }
    }
    
    return modified;
  }

  /**
   * Generate display orders for a given Set.
   *
   * @param s
   *          The Set containing objects with a displayOrder attribute.
   * @return <tt>true</tt> if the set was modified, <tt>false</tt> if not.
   */
  public static boolean generateDisplayOrder(Set<? extends HasDisplayOrder> s)
  {
    boolean modified = false;

    int displayOrder = 0;
    
    if (CollectionUtils.isNotEmpty(s))
    {
      for (HasDisplayOrder item : s)
      {
        Integer existing = item.getDisplayOrder();
        
        if (existing == null || existing != displayOrder + 1)
        {
          item.setDisplayOrder(displayOrder++ + 1);
          modified = true;
        }
      }
    }
    
    return modified;
  }

  public static String getCsvString(Collection<?> coll)
  {
    StringBuilder csv = new StringBuilder();
    
    if (CollectionUtils.isNotEmpty(coll))
    {
      int index = 0;
      
      for (Object o : coll)
      {
        csv.append(o.toString());
        
        if (index++ < coll.size() - 1)
          csv.append(", ");
      }
    }
    
    return csv.toString();
  }

  public static List<Project> sortProjects(Collection<Project> projectCollection)
  {
    return (List<Project>) sortBudgesObjects(projectCollection, "getNumber");
  }

  public static List<OtherAdjustmentDetail> sortBudgesPeOtherAdjustmentsSet(Collection<OtherAdjustmentDetail> budgesPeOtherAdjustmentsCollection)
  {
    return (List<OtherAdjustmentDetail>) sortBudgesObjects(budgesPeOtherAdjustmentsCollection, "getTitle");
  }

  public static List<CongressionalAddDetail> sortBudgesPeCongIncSet(Collection<CongressionalAddDetail> budgesPeCongIncCollection)
  {
    return (List<CongressionalAddDetail>) sortBudgesObjects(budgesPeCongIncCollection, "getTitle");
  }

  public static List<CongressionalAddDetail> sortBudgesPeCongAddSet(Collection<CongressionalAddDetail> budgesPeCongAddCollection)
  {
    return (List<CongressionalAddDetail>) sortBudgesObjects(budgesPeCongAddCollection, "getTitle");
  }

  public static List<OtherProgramFundingSummary> sortBudgesProjOtherPgmFundingsSet(Collection<OtherProgramFundingSummary> budgesProjOtherPgmFundingsCollection)
  {
    return (List<OtherProgramFundingSummary>) sortBudgesObjects(budgesProjOtherPgmFundingsCollection, "getLineItem");
  }

  public static List<AccomplishmentPlannedProgram> sortBudgesProjAccompPlannedPgmSet(Collection<AccomplishmentPlannedProgram> budgesProjAccompPlannedPgmCollection)
  {
    return (List<AccomplishmentPlannedProgram>) sortBudgesObjects(budgesProjAccompPlannedPgmCollection, "getTitle");
  }

  public static List<MajorPerformer> sortBudgesMajorPerformerSet(Collection<MajorPerformer> budgesMajorPerformerCollection)
  {
    return (List<MajorPerformer>) sortBudgesObjects(budgesMajorPerformerCollection, "getName");
  }

  public static List<CostCategoryItem> sortCostCategoryItemSet(Collection<CostCategoryItem> costCategoryItemCollection)
  {
    return (List<CostCategoryItem>) sortBudgesObjects(costCategoryItemCollection, null);
  }

  /**
   * Converts a collection to a HashSet. Duplicates are silently abandoned.
   */
  public static <T> HashSet<T> toHashSet(Collection<T> coll)
  {
    HashSet<T> set = new HashSet<T>(coll.size());
    
    for (T each : coll)
    {
      set.add(each);
    }
    
    return set;
  }

  /** Converts a collection to an ArrayList */
  public static <T> ArrayList<T> toArrayList(Collection<T> coll)
  {
    ArrayList<T> list = new ArrayList<T>(coll.size());
    
    for (T each : coll)
    {
      list.add(each);
    }
    
    return list;
  }

  /**
   * Format parts of a name into "lname, fname mi" format. Middle initial can be
   * null. Fall back to ldap if last name is null or blank.
   */
  public static String formatName(String lname, String fname, String mi, String ldap)
  {
    if (lname != null && lname.trim().length() > 0)
    {
      return lname + ", " + fname + (mi == null ? "" : " " + mi);
    }
    
    else
    {
      return ldap;
    }
  }

  /** See {@link #formatName(String, String, String, String)} */
  public static String formatName(BudgesUser b)
  {
    return formatName(b.getLastName(), b.getFirstName(), b.getMiddleInitial(), b.getUserLdapId());
  }

  public static String underscoreConcat(Object... names)
  {
    return concat("_", names);
  }

  public static String periodConcat(Object... names)
  {
    return concat(".", names);
  }

  public static String concat(String separator, Object... names)
  {
    String s = null;
    
    if (separator != null && names.length > 0)
    {
      StringBuilder sb = null;
      
      for (int i = 0; i < names.length; ++i)
      {
        if (names[i] != null)
        {
          if (sb == null){
            sb = new StringBuilder(names[i].toString());
          }
          
          else{
            sb.append(separator + names[i].toString());
          }
        }
      }
      
      if (sb != null){
        s = sb.toString();
      }
    }
    
    return s;
  }

  public static <T> boolean contains(T[] array, T obj)
  {
    if (array != null && obj != null){
      for (T i : array){
        if (obj.equals(i)){
          return true;
        }
      }  
    }
    
    return false;
  }

  public static <T> String dump(T[] array)
  {
    StringBuilder sb = new StringBuilder();
    
    if (array != null && array.length > 0)
    {
      for (int i = 0; i < array.length - 1; ++i){
        sb.append(array[i].toString() + ",");
      }
      
      sb.append(array[array.length - 1]);
    }
    
    return sb.toString();
  }

  public static class CloneFailedException extends Exception
  {
    private static final long serialVersionUID = 1L;

    public CloneFailedException()                                { super();               }
    public CloneFailedException(String message)                  { super(message);        }
    public CloneFailedException(String message, Throwable cause) { super(message, cause); }
    public CloneFailedException(Throwable cause)                 { super(cause);          }
  }

  /**
   * clone - Shallow copy of an object via serialization.
   *
   * @param obj
   *          Object to copy
   * @return new copy
   */
  @SuppressWarnings("unchecked")
  public static <T> T clone(T obj) throws CloneFailedException
  {
    try
    {
      // serialize
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      
      objectOutputStream.writeObject(obj);
      
      // deserialize
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
      
      ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
      
      Object copy = objectInputStream.readObject();

      return (T) copy;
    }
    
    catch (IOException e)
    {
      log.error("Failed to clone", e);
      throw new CloneFailedException(e);
    }
    
    catch (ClassNotFoundException e)
    {
      log.error("Failed to clone", e);
      throw new CloneFailedException(e);
    }
  }

  public static BudgetCycle getCurrentBudgetCycle()
  {
    return getCurrentBudgetCycle(null);
  }

  public static BudgetCycle getCurrentBudgetCycle(Calendar currDate)
  {
    // First see if there is a default budget cycle configured & use that if so
    BudgetCycle bc = BudgesContext.getConfigService().getDefaultBudgetCycle();
    
    if (bc != null)
    {
      log.debug("Found configured default budget cycle of: " + bc.getLabel());
      return bc;
    }

    log.debug("No configured default budget cycle, will compute it...");

    // Get September 1st for the current year
    Calendar initSubmissionDate = currDate;
    
    if (currDate == null)
    {
      initSubmissionDate = Calendar.getInstance();
      currDate = (Calendar) initSubmissionDate.clone();
    }
    
    else
    {
      initSubmissionDate = (Calendar) currDate.clone();
    }
    
    initSubmissionDate.clear();
    initSubmissionDate.set(currDate.get(Calendar.YEAR), Calendar.SEPTEMBER, 1);

    // Get start of window for BES
    Calendar initSubmissionWindowStart = (Calendar) initSubmissionDate.clone();
    initSubmissionWindowStart.add(Calendar.MONTH, -4);

    // Get end of window for BES
    Calendar initSubmissionWindowEnd = (Calendar) initSubmissionDate.clone();
    initSubmissionWindowEnd.add(Calendar.MONTH, 1);

    DateFormat dateTimeFormat = new SimpleDateFormat(Constants.DATETIME_FORMAT);
    
    log.debug(String.format("Computing current budget cycle based on current date %s, BES Date [%s], BES window = [%s - %s]",
            dateTimeFormat.format(currDate.getTime()),
            dateTimeFormat.format(initSubmissionDate.getTime()),
            dateTimeFormat.format(initSubmissionWindowStart.getTime()),
            dateTimeFormat.format(initSubmissionWindowEnd.getTime())));

    String cycle = null;
    
    int budgetYear = initSubmissionDate.get(Calendar.YEAR) + 1;
    
    if (currDate.after(initSubmissionWindowStart) && currDate.before(initSubmissionWindowEnd))
    {
      // BES cycle
      cycle = Constants.INITIAL_SUBMISSION_CYCLE;
      ++budgetYear;
    }
    else
    {
      // PB cycle
      cycle = Constants.FINAL_SUBMISSION_CYCLE;

      // Get start of window for BES
      Calendar finalSubmissionWindowStart = (Calendar) initSubmissionWindowEnd.clone();
      finalSubmissionWindowStart.add(Calendar.DAY_OF_MONTH, -1);

      // Get start of following year
      Calendar newYear = Calendar.getInstance();
      newYear.clear();
      newYear.set(currDate.get(Calendar.YEAR) + 1, Calendar.JANUARY, 1);
      
      log.debug(String.format("Computing PB cycle, end of BES to new year is [%s - %s]",
              dateTimeFormat.format(finalSubmissionWindowStart.getTime()),
              dateTimeFormat.format(newYear.getTime())));

      // PB's year is only + 2 just like BES unless current month is January or
      // later
      if (currDate.after(finalSubmissionWindowStart) && currDate.before(newYear))
      {
        ++budgetYear;
      }
    }

    log.debug("Looking up BudgetCycle object for computed default budget cycle of " + cycle + " " + budgetYear);
    bc = BudgesContext.getBudgetCycleDAO().findByCycleAndBudgetYear(cycle, budgetYear);

    //If BudgesContext.getBudgetCycleDAO().findByCycleAndBudgetYear(cycle, budgetYear); returns null then look for it using a reverse chronological order search.
    //return the first future budget cycle.
    if (bc == null)
    {
        log.debug("Could not find BudgetCycle object for computed default cycle, searching for cycle past current date");
        
        List<BudgetCycle> chronologicalBcList = BudgesContext.getBudgetCycleDAO().getBudgetCycles();
        
        Collections.reverse(chronologicalBcList);
        
        for (BudgetCycle chronCycle : chronologicalBcList)
        {
            SubmissionDate subdate = chronCycle.getSubmissionDates().iterator().next();
            
            Calendar calendarSubDate = Calendar.getInstance();
            calendarSubDate.setTime(subdate.getDate());
            
            if (currDate.before(calendarSubDate))
            {
                return chronCycle;
            }
        }
     }

    if (bc != null)
    {
      log.debug("Found BudgetCycle object for computed default budget cycle of: " + bc.getLabel());
      return bc;
    }

    log.error("Default BudgetCycle object not found! Falling back to hardcoded default BES 2010");

    bc = BudgesContext.getBudgetCycleDAO().findByCycleAndBudgetYear("BES", 2010);
    
    if (bc != null){
        return bc;
    }
    
    log.error("Uh-oh, could not find BudgetCycle object for BES 2010. You can probably guess what happens next after I return this null ;).");
    
    return null;
  }

  public static String addPrefixWithSpaceDelim(String prefix, String text)
  {
    return addPrefix(prefix, text, " ");
  }

  public static String addPrefix(String prefix, String text)
  {
    return addPrefix(prefix, text, " - ");
  }

  public static String addPrefix(String prefix, String text, String separator)
  {
    if (StringUtils.isEmpty(prefix)){
      return text;
    }
    
    return prefix + separator + text;
  }

  public static String formatJbPageNumber(int pageNumber)
  {
    return String.format("%1$4d", pageNumber);
  }

  public static String formatJbPageNumber(String pageNumber)
  {
    return String.format("%1$4s", pageNumber);
  }

  public static <T> int compare(Comparable<T> obj1, Comparable<T> obj2)
  {
    if (obj1 == null && obj2 == null){
      return 0;
    } 
    
    else if (obj1 == null){
      return -1;
    } 
    
    else if (obj2 == null){
      return 1;
    }
    
    else {
      return obj1.compareTo((T) obj2);
    }
  }

  public static int compare(String obj1, String obj2)
  {
    if (obj1 == null && obj2 == null){
      return 0;
    }
    
    if (obj1 == null && obj2 != null){
      return -1;
    }
    
    if (obj1 != null && obj2 == null){
      return 1;
    }
    
    return Strings.getNaturalComparator().compare(obj1, obj2);
  }

  public static void dumpKvpList(List<KeyValuePair> kvpList)
  {
    if (CollectionUtils.isNotEmpty(kvpList))
    {
      for (KeyValuePair kvp : kvpList){
        log.debug("The key, value pair is:  " + kvp);
      }
    }
  }

  public static String cleanupClasspathResourceRef(String href)
  {
    String nameOnly = null;
    
    if (href != null)
    {
      File f = new File(href);
      
      nameOnly = f.getName();
    }
    
    return nameOnly;
  }

  public static Object friendlyDescIfNull(Object o)
  {
    return(o == null ? "[none]" : o);
  }

  /** Get an array of funding years relevant to this budgetyear */
  public static int[] getBudgetYears(int budgetYear)
  {
    // Allowed years span 2 years before budget year (py)
    // and 5 or 4 years after budget years
    int startOffset = -2;
    
    int endOffset = 4; // isEvenBudgetYear() ? 5 : 4;
    
    int size = endOffset - startOffset + 1;
    
    int[] years = new int[size];
    
    for (int i = 0; i < size; i++)
    {
      years[i] = budgetYear + startOffset + i;
    }
    
    return years;
  }

  public static void setMaintenanceMode(Config config, boolean val, BudgesUser currentUser)
  {
    config.setValue(Boolean.toString(val));
    
    BudgesContext.getConfigDAO().saveByConfig(config);
  }

  public static boolean isMaintenanceMode()
  {
    return BudgesContext.getConfigService().getR2MaintenanceModeValue();
  }

  // FIXME: Ideally, this should go away.  The UI components which need to
  // know if on NIPR or SIPR should really just request the CSS to instruct
  // the UI to use.
  public static boolean isClassified()
  {
    return StringUtils.equalsIgnoreCase(BudgesContext.getConfigService().getClassificationSymbol(), "S");
  }

  public static String getClassificationLabel()
  {
      return BudgesContext.getConfigService().getClassificationLabel();
  }
  
  public static Map<String,String> getClassificationData(){
      Map<String, String> classificationData = BudgesContext.getConfigService().getClassificationData();
      
      return classificationData;
  }

  public static String getClassificationSymbol()
  {
      return BudgesContext.getConfigService().getClassificationSymbol();
  }

  /** for local use uuid, otherwise use svn revision/tag */
  public static String getT5AssetVersion()
  {
    if (BudgesContext.getConfigService().isLocal()){
      return UUID.randomUUID().toString();
    }
    
    return new VersionProperties().getBuildnumber() + StringUtils.EMPTY;
  }

  public static JobTypeFlag getJobType(DelegateResultInfo dri)
  {
    if (dri != null)
    {
      MasterJustificationBook mjb = dri.getMjb();

      if (mjb != null)
      {
        if (mjb.r2sExist() && !mjb.lineItemsExist()){
          return JobTypeFlag.R2MJBXMLTOPDF;
        }

        if (!mjb.r2sExist() && mjb.lineItemsExist()){
          return JobTypeFlag.P40MJBXMLTOPDF;
        }

        return JobTypeFlag.MJBXMLTOPDF;
      }

      JustificationBook jb = dri.getJb();

      if (jb != null)
      {
        if (jb.r2sExist() && !jb.lineItemsExist()){
          return JobTypeFlag.R2JBXMLTOPDF;
        }

        if (!jb.r2sExist() && jb.lineItemsExist()){
          return JobTypeFlag.P40JBXMLTOPDF;
        }

        return JobTypeFlag.JBXMLTOPDF;
      }
    }
    
    return JobTypeFlag.N;
  }

  public static String toJson(Object object, List<String> desiredProps)
  {
    JsonObject jsonObject = new JsonObject();

    for (String property : desiredProps)
    {
      Object value = object instanceof CayenneDataObject ? ((CayenneDataObject) object).readProperty(property) : null;

      // Try reflection for non-Cayenne getters.
      if (value == null)
      {
        try
        {
          value = PropertyUtils.getProperty(object, property);
        }
        catch (CayenneRuntimeException e)
        {
          log.error("toJson", e.getCause());
        }
      }

      String key = property.replace('.', '_');
      // Block things that are hard to whitelist in desiredProps
      if (value instanceof Persistent){
        log.error("i won't serialize entire objects");
      }
      
      else if (value instanceof Collection){
        log.error("i won't serialize entire collections");
      }
      
      else if (value instanceof Fault){
        log.error("i won't serialize faults");
      }
      
      else if (value == null){
        jsonObject.add(key, new JsonNull());
      }
      
      else if (value instanceof Boolean){
        jsonObject.add(key, new JsonPrimitive((Boolean) value));
      }
      
      else if (value instanceof Integer){
        jsonObject.add(key, new JsonPrimitive((Integer) value));
      }
      
      else{
        jsonObject.addProperty(key, value.toString());
      }
    }

    if (object instanceof Base){
      jsonObject.addProperty("id", ((Base) object).getId());
    }

    return new GsonBuilder().serializeNulls().create().toJson(jsonObject);
  }

  public static boolean isQuantityWithoutCost(HasTotalCostsAndQuantities ce, String methodName) throws MethodDispatchException
  {
    boolean qwc = false;

    // Method method = Costs.class.getMethod(methodName, (Class<?>[]) null);
    BigDecimal quantity = null;
    
    if(ce.getQuantities() != null){
        quantity = (BigDecimal) dispatch(ce.getQuantities(), methodName);
//      quantity = (BigDecimal) method.invoke(ce.getQuantities());
    }
    
    BigDecimal totalCost = null;
    
    if(ce.getTotalCosts() != null){
        totalCost = (BigDecimal) dispatch(ce.getTotalCosts(), methodName);
//    totalCost = (BigDecimal) method.invoke(ce.getTotalCosts());
    }
    
    if (quantity != null && totalCost == null)
    {
      qwc = true;
    }

    return qwc;
  }

  public static BigDecimal getDecimalCost(Costs costs, String methodName) throws MethodDispatchException
  {
    // Method method = Costs.class.getMethod(methodName, (Class<?>[]) null);
    BigDecimal totalCost = null;
    
    if (costs != null){
          totalCost = (BigDecimal) dispatch(costs, methodName);
//      totalCost = (BigDecimal) method.invoke(c);
    }
    
    return totalCost;
  }

  public static void setDecimalCost(Costs costs, String methodName, BigDecimal value) throws MethodDispatchException
  {
      if (costs != null){
          dispatch(costs, methodName, new Class<?>[] { BigDecimal.class }, new Object[] { value } );
      }

//    Class<?>[] cls = new Class<?>[1];
//    cls[0] = BigDecimal.class;
//    Method setMethod = Costs.class.getMethod(methodName, cls);
//    if (c != null)
//      setMethod.invoke(c, value);
  }

  public static boolean isToCompleteOrTotalCost(String method)
  {
    return "getToComplete".equals(method) || "getTotal".equals(method);
  }

  public static String[] getFyMethodList()
  {
    return fyMethodList;
  }

  public static String[] getFySetMethodList()
  {
    return fySetMethodList;
  }

  public static String[] getFyLabelList()
  {
    return fyLabelList;
  }

  public static String[] getFyModsManufacturerList()
  {
    return fyModsManufacturerList;
  }

  public static String getMethodNameFromBudgetYear(Short budgetYear, Integer currentBudgetYear)
  {
    int difference = 0;
    if (currentBudgetYear != null)
      difference = budgetYear.intValue() - currentBudgetYear;
    else
      difference = budgetYear.intValue() - getCurrentBudgetCycle().getBudgetYear();
    if(difference < -2)
      return fyMethodList[0];
    else if(difference == -2)
      return fyMethodList[1];
    else if(difference == -1)
      return fyMethodList[2];
    else if(difference == 0)
      return fyMethodList[5];
    else if(difference == 1)
      return fyMethodList[6];
    else if(difference == 2)
      return fyMethodList[7];
    else if(difference == 3)
      return fyMethodList[8];
    else if(difference == 4)
      return fyMethodList[9];
    else if (difference > 4)
      return fyMethodList[10];
    else
      return null;
  }

  public static String getFyLabelFromMethodName(String methodName)
  {
    String label = null;
    
    if (methodName != null)
    {
      for (int i = 0; i < fyMethodList.length; i++)
      {
        if (methodName.equals(fyMethodList[i]))
        {
          label = fyLabelList[i];
          break;
        }
      }
    }
    
    return label;
  }

  public static Integer getBudgetYearFromMethodName(HasUnitsAndBudgetYear unitsAndBudgetYear, String methodName)
  {
    if (unitsAndBudgetYear != null && methodName != null)
    {
      if (methodName.equalsIgnoreCase(getFyMethodList()[1]))
        return unitsAndBudgetYear.getBudgetYear() - 2;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[2]))
        return unitsAndBudgetYear.getBudgetYear() - 1;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[3]) || methodName.equalsIgnoreCase(getFyMethodList()[4]) || methodName.equalsIgnoreCase(getFyMethodList()[5]))
        return unitsAndBudgetYear.getBudgetYear();
      else if (methodName.equalsIgnoreCase(getFyMethodList()[6]))
        return unitsAndBudgetYear.getBudgetYear() + 1;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[7]))
        return unitsAndBudgetYear.getBudgetYear() + 2;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[8]))
        return unitsAndBudgetYear.getBudgetYear() + 3;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[9]))
        return unitsAndBudgetYear.getBudgetYear() + 4;
      else if (methodName.equalsIgnoreCase(getFyMethodList()[10]))
        return unitsAndBudgetYear.getBudgetYear() + 5;
      else
        return null;
    }
    return null;
  }

  public static String formatLocation(String location, int index, String childLoc)
  {
    return String.format("[%s %s \"%s\"]", Util.formatIndex(index), location, childLoc);
  }

  public static String getDatabaseInfo(DataSource dataSource)
  {
    StringBuilder sb = new StringBuilder();
    
    if (dataSource == null)
    {
      sb.append("<No DataSource>");
    }
    
    else
    {
      Connection c = null;
      
      try // FIXME: Try-with-resources this bad boy!
      {
        c = dataSource.getConnection();
        
        DatabaseMetaData metadata = c.getMetaData();
        
        sb.append("Database: " + metadata.getURL());
        sb.append(" (" + metadata.getDatabaseProductName());
        sb.append(" " + metadata.getDatabaseProductVersion());
        sb.append(", Driver: " + metadata.getDriverName());
        sb.append(" " + metadata.getDriverVersion());
        sb.append(")");
      }
      
      catch (SQLException e)
      {
        log.debug("Could not retrieve database info", e);
      }
      
      finally
      {
        if (c != null)
        {
          try
          {
            c.close();
          }
          catch (SQLException e)
          {
            log.debug(e);
          }
        }
      }
    }
    
    return sb.toString();
  }

  public static void cleanupContinuingTotal(HasTotalCosts hasTotalCosts)
  {
    if (hasTotalCosts != null && hasTotalCosts.isContinuing())
    {
      setToCompleteAndTotalToNull(hasTotalCosts.getTotalCosts());
    }

    if (hasTotalCosts != null && !hasTotalCosts.isContinuing())
    {
      if(hasTotalCosts.getTotalCosts() != null && !hasTotalCosts.getTotalCosts().isContinuing()){
        hasTotalCosts.getTotalCosts().setContinuingFootnote(StringUtils.EMPTY);
      }
    }
  }

  public static void cleanupContinuingTriplet(HasTripletCosts hasTripletCosts)
  {
    if (hasTripletCosts != null && hasTripletCosts.isContinuing())
    {
      setToCompleteAndTotalToNull(hasTripletCosts.getQuantities());
      setToCompleteAndTotalToNull(hasTripletCosts.getUnitCosts());
      setToCompleteAndTotalToNull(hasTripletCosts.getTotalCosts());
    }

    if (hasTripletCosts != null && !hasTripletCosts.isContinuing())
    {
    	if(hasTripletCosts.getTotalCosts() != null && !hasTripletCosts.getTotalCosts().isContinuing()){
    		hasTripletCosts.getTotalCosts().setContinuingFootnote(StringUtils.EMPTY);
    	}
    }
  }

  private static void setToCompleteAndTotalToNull(Costs costs)
  {
    if(costs != null)
    {
      costs.setToComplete(null);
      costs.setToCompleteFootnote(null);
      costs.setTotal(null);
      costs.setTotalCostFootnote(null);
    }
  }

  /**
   * Unzip the Comptroller XML Package file to the base directory for loading
   * XML resource from. The unzipped contents are used when the mode for
   * resolving XML schema/XSLT resources is the file system. It unzips to a temp
   * directory first, renames the old directory if it exists and moves the temp
   * directory to be the new location of the unzipped contents.
   *
   * @param xmlPackageFile
   *          - the Comptroller XML Package file to unzip
   * @throws IOException
   *           - if any problems populating the base directory for loading XML
   *           resource from with the contents of the Comptroller XML Package
   *           file
   */
  public static void unzipComptrollerXMLPackageToXmlResourceBaseDir(File xmlPackageFile) throws IOException
  {
    unzipComptrollerXMLPackageToXmlResourceBaseDir(xmlPackageFile, null);
  }

  /**
   * Unzip the Comptroller XML Package file to the base directory for loading
   * XML resource from. The unzipped contents are used when the mode for
   * resolving XML schema/XSLT resources is the file system. It unzips to a temp
   * directory first, renames the old directory if it exists and moves the temp
   * directory to be the new location of the unzipped contents.
   *
   * @param xmlPackageFile
   *          - the Comptroller XML Package file to unzip
   * @param userCredentials
   *          - the currently logged in user
   * @throws IOException
   *           - if any problems populating the base directory for loading XML
   *           resource from with the contents of the Comptroller XML Package
   *           file
   */
  public static void unzipComptrollerXMLPackageToXmlResourceBaseDir(File xmlPackageFile, UserCredentials userCredentials) throws IOException
  {
    String baseDirName = BudgesContext.getConfigService().getXmlResourceBaseDir();
    
    File baseDir = new File(baseDirName);
    
    AppDefaults appDefaults = BudgesContext.getAppDefaults();
//    try
//    {
      if (StringUtils.isBlank(baseDirName))
      {
        log.debug("Base directory for loading XML Resources from the file system is missing, will not unzip Comptroller XML Package to it.");
      }
      
      else
      {
        File baseDirParent = baseDir.getParentFile();
        
        if (!baseDirParent.exists())
        {
          throw new IOException("Base dir for unzipping Comptroller XML package file does not exist: " + baseDirParent);
        }

        // Unzip to a temporary location
        File unzipDest = new File(baseDirParent, "tmp");
        
        if (unzipDest.exists())
        {
          FileUtils.deleteDirectory(unzipDest);
        }
        
        unzipFile(xmlPackageFile, unzipDest);

        // Validate the unzipped contents
        String[] subDirs = unzipDest.list();
        
        if (subDirs == null || subDirs.length != 1 || !baseDir.getName().equals(subDirs[0]))
        {
          throw new IOException("Comptroller XML Exhibits package file needs to be self-contained when unzipped, in a directory named " + baseDir.getName());
        }

        // Validate the XML schema and XSLT directories exist
        File tmpBaseDir = new File(unzipDest, baseDir.getName());
        
        if (!FileUtil.allSubDirsExist(tmpBaseDir, appDefaults.getCurrentRelease().getXsdPathList()))
        {
          throw new IOException("Comptroller XML Exhibits package file does not contain one or more of the XML schema resources paths: " + appDefaults.getCurrentRelease().getXsdPathList());
        }

        // Validate the XSLT schema and XSLT directories exist
        if (!FileUtil.allSubDirsExist(tmpBaseDir, appDefaults.getCurrentRelease().getXslPathList()))
        {
          throw new IOException("Comptroller XML Exhibits package file does not contain one or more of the XSLT resources paths: " + appDefaults.getCurrentRelease().getXslPathList());
        }

        // Rename the old unzipped package by appending a unique id to it
        if (baseDir.exists())
        {
          File oldPackageDir = new File(FileUtil.createFileName(null, baseDir.getAbsolutePath(), "old"));
          
          if (oldPackageDir.exists())
          {
            FileUtils.deleteDirectory(oldPackageDir);
          }
          
          log.trace("Moving Comptroller XML package file from " + baseDir + " to " + oldPackageDir);
          
          FileUtils.moveDirectory(baseDir, oldPackageDir);
        }

        // Finally, "install" the newly unzipped contents
        File unzippedContents = new File(unzipDest, baseDir.getName());
        FileUtils.moveToDirectory(unzippedContents, baseDirParent, false);
        

        // Copy the package file itself to the install directory
        File destFile = new File(baseDir, Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME);
        
        log.debug("Copying " + xmlPackageFile + " to " + destFile);
        
        FileUtils.copyFile(xmlPackageFile, destFile);
      }
//    }
//    catch (IOException e)
//    {
//      StringBuilder msg = new StringBuilder("Base dir for unzipped package: " + baseDir);
//      msg.append("\n\nException Message: " + e.getMessage());
//      msg.append("\n\nSee system logs for details.");
//      msg.append("\n\nThings to check: ");
//      msg.append("\n-Make sure the Comptroller XML Package file is what is attmpted to be unzipped. It must have the XML & XSLT directories for the current cycle.");
//      msg.append("\n-Make sure the base directory for where the Comptroller XML Package file is supposed to be unzipped exists and the Tomcat user has read/write access to it.");
//      msg.append("\n\n");
//      BudgesContext.getEmailUtil().sendSystemEmail("Unzip of Comptroller XML Package Failed", msg.toString(), userCredentials);
//      throw e;
//    }
  }

  /**
   * Unzip a given zip file to a given destination directory.
   *
   * @param fileToUnzip
   *          - file to unzip
   * @param destDir
   *          - destination directory, will be created if it does not exist (but
   *          not only the first level)
 * @throws IOException
   */
  public static void unzipFile(File fileToUnzip, File destDir) throws IOException
  {
      if (!destDir.exists() && !destDir.mkdir()){
        throw new ZipException("Unzip destination directory does not exist and could not create it: " + destDir);
      }

      log.debug("Unzipping file: " + fileToUnzip);

    try (ZipFile zipFile = new ZipFile(fileToUnzip))
    {
      for (Enumeration<? extends ZipEntry> zipEntries = zipFile.entries(); zipEntries.hasMoreElements();)
      {
        ZipEntry zipEntry = zipEntries.nextElement();
        
        File zipEntryDestFile = new File(destDir, zipEntry.getName());
        
        log.trace("Unzipping zip entry " + zipEntry.getName() + " to " + zipEntryDestFile);
        
        if (zipEntry.isDirectory())
        {
          FileUtils.forceMkdir(zipEntryDestFile);
        }
        
        else
        {
          FileUtils.forceMkdir(zipEntryDestFile.getParentFile());
          
          InputStream is = zipFile.getInputStream(zipEntry);
          
          FileUtil.writeFileContents(is, zipEntryDestFile);
          
        }
        
        log.trace("Successfully unzipped " + zipEntry.getName());
      }
      
      log.debug("Successfully unzipped " + fileToUnzip + " to " + destDir);
    }
//    catch (ZipException e)
//    {
//      log.error("Failed to unzip file: " + fileToUnzip, e);
//      throw e;
//    }
//    finally
//    {
//      FileUtil.close(zipFile);
//    }
  }
  
  public static boolean isSCNExhibit(Object parentExhibit) {
    boolean isSCN = false;
    
    if(parentExhibit instanceof LineItem){
      LineItem lineItem = (LineItem)parentExhibit;
      
      if (lineItem.getServiceAgency() != null
          && StringUtils.equals(lineItem.getServiceAgency().getName(), "Navy")
          && lineItem.getBudgetSubActivity() != null
          && lineItem.getBudgetSubActivity().getBudgetActivity() != null
          && lineItem.getBudgetSubActivity().getBudgetActivity().getAppropriation() != null) {
        
        isSCN = StringUtils.equals(lineItem.getBudgetSubActivity().getBudgetActivity().getAppropriation().getName(), "Shipbuilding and Conversion, Navy");
      }
    }
    
    return isSCN;
  } 
}
