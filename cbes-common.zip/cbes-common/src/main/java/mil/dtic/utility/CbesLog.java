package mil.dtic.utility;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.logging.log4j.Logger;
public class CbesLog {

    private final Logger log;

    public CbesLog(Logger log) {
        this.log = log;
    }

    public void debug(Object arg0, Throwable arg1) {
        log.debug(sanitize(arg0), arg1);

    }

    public void debug(Object arg0) {
        log.debug(sanitize(arg0));

    }

    public void error(Object arg0, Throwable arg1) {
        log.error(sanitize(arg0), arg1);

    }

    public void error(Object arg0) {
        log.error(sanitize(arg0));

    }

    public void fatal(Object arg0, Throwable arg1) {
        log.fatal(sanitize(arg0), arg1);
        ;

    }

    public void fatal(Object arg0) {
        log.fatal(sanitize(arg0));
    }

    public void info(Object arg0, Throwable arg1) {
        log.info(sanitize(arg0), arg1);

    }

    public void info(Object arg0) {
        log.info(sanitize(arg0));

    }

    public boolean isDebugEnabled() {
        return log.isDebugEnabled();
    }

    public boolean isErrorEnabled() {
        return log.isErrorEnabled();
    }

    public boolean isFatalEnabled() {
        return log.isFatalEnabled();
    }

    public boolean isInfoEnabled() {
        return log.isInfoEnabled();
    }

    public boolean isTraceEnabled() {
        return log.isTraceEnabled();
    }

    public boolean isWarnEnabled() {
        return log.isWarnEnabled();
    }

    public void trace(Object arg0, Throwable arg1) {
        log.trace(sanitize(arg0), arg1);

    }

    public void trace(Object arg0) {
        log.trace(sanitize(arg0));

    }

    public void warn(Object arg0, Throwable arg1) {
        log.warn(sanitize(arg0), arg1);

    }

    public void warn(Object arg0) {
        log.warn(sanitize(arg0));
    }

    private String sanitize(Object arg0) {
        // ensure no CRLF injection into logs for forging records
        String clean = arg0.toString().replace('\n', '_').replace('\r', '_');
        clean = StringEscapeUtils.escapeHtml(arg0.toString());
        if (!arg0.toString().equals(clean)) {
            clean += " (Encoded)";
        }
        return clean;
    }
}
