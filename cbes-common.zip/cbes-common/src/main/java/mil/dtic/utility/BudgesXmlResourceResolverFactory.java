package mil.dtic.utility;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.constants.Constants.XML_RESOURCES_SOURCE;

@Component("BudgesXmlResourceResolverFactory")
public class BudgesXmlResourceResolverFactory
{
  private static final Logger log = CbesLogFactory.getLog(BudgesXmlResourceResolverFactory.class);

  @Autowired
  private AppDefaults appDefaults;
  private BudgesXsltResourceResolver xsltResourceResolver;
  private BudgesXmlSchemaResourceResolver schemaResourceResolver;
  private XML_RESOURCES_SOURCE xmlResourcesLoadFrom;

  private List<String> lastXsdPathList;
  private List<String> lastXslPathList;


  public BudgesXmlResourceResolverFactory()
  {
  }


  protected boolean switchResourceResolver()
  {
    return switchResourceResolver(lastXsdPathList, lastXslPathList);
  }


  protected boolean switchResourceResolver(List<String> xsdPathList, List<String> xslPathList)
  {
    XML_RESOURCES_SOURCE newXmlResourcesLoadFrom = BudgesContext.getConfigService().getXmlResourcesLoadFrom();
    return xmlResourcesLoadFrom == null || !xmlResourcesLoadFrom.equals(newXmlResourcesLoadFrom) || lastXslPathList != xslPathList || lastXsdPathList != xsdPathList;
  }


  public BudgesXsltResourceResolver getXsltResourceResolver()
  {
    changeResourceResolver();
    return xsltResourceResolver;
  }


  public BudgesXsltResourceResolver getXsltResourceResolver(List<String> xsdPathList, List<String> xslPathList)
  {
    changeResourceResolver(xsdPathList, xslPathList);
    return xsltResourceResolver;
  }


  public BudgesXmlSchemaResourceResolver getSchemaResourceResolver()
  {
    changeResourceResolver();
    return schemaResourceResolver;
  }


  public BudgesXmlSchemaResourceResolver getSchemaResourceResolver(List<String> xsdPathList, List<String> xslPathList)
  {
    changeResourceResolver(xsdPathList, xslPathList);
    return schemaResourceResolver;
  }


  public void changeResourceResolver()
  {
    changeResourceResolver(appDefaults.getCurrentRelease().getXsdPathList(), appDefaults.getCurrentRelease().getXslPathList());
  }


  public void changeResourceResolver(List<String> xsdPathList, List<String> xslPathList)
  {
    if (switchResourceResolver(xsdPathList, xslPathList))
    {
      lastXslPathList = xslPathList;
      lastXsdPathList = xsdPathList;
      xmlResourcesLoadFrom = BudgesContext.getConfigService().getXmlResourcesLoadFrom();
      log.debug("XML Resources (schema and xslts) will be loaded from " + xmlResourcesLoadFrom + " using paths " + xsdPathList + " " + xslPathList);
      switch (xmlResourcesLoadFrom)
      {
        case FILESYSTEM:
          xsltResourceResolver = new BudgesFileSystemXsltResourceResolver(xslPathList);
          schemaResourceResolver = new BudgesFileSystemXmlSchemaResourceResolver(xsdPathList);
          break;
        case DATABASE:
          xsltResourceResolver = new BudgesDatabaseXsltResourceResolver(xslPathList);
          schemaResourceResolver = new BudgesDatabaseXmlSchemaResourceResolver(xsdPathList);
          break;
        case CLASSPATH:
          xsltResourceResolver = new BudgesClasspathXsltResourceResolver(xslPathList);
          schemaResourceResolver = new BudgesClasspathXmlSchemaResourceResolver(xsdPathList);
          break;
        default:
          log.debug("use classpath");
          xsltResourceResolver = new BudgesClasspathXsltResourceResolver(xslPathList);
          schemaResourceResolver = new BudgesClasspathXmlSchemaResourceResolver(xsdPathList);
          break;
      }
    }
  }


  public XML_RESOURCES_SOURCE getXmlResourcesLoadFrom()
  {
    return xmlResourcesLoadFrom;
  }

}
