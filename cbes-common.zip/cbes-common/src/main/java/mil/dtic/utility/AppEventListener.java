package mil.dtic.utility;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Timer;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;

/**
 * Hook into the servlet lifecycle.
 */
public class AppEventListener implements ServletContextListener
{
  private static final Logger log = CbesLogFactory.getLog(AppEventListener.class);

  private Timer configPollTimer;


  @Override
  public void contextInitialized(ServletContextEvent sce)
  {
		dumpSystemProperties();
		ServletContext sc = sce.getServletContext();
		setAppInfo(sc);
		unzipComptrollerXmlPackageFile();
		notify(sc, "** STARTED **");
		startConfigPoller();
  }


  @Override
  public void contextDestroyed(ServletContextEvent sce)
  {
      notify(sce.getServletContext(), "STOPPED");
      stopConfigPoller();
  }


  private void setAppInfo(ServletContext sc)
  {
    setContainerNameSystemProperty(sc);
    setAppNameSystemProperty(sc);
    setAppNameListSystemProperty();
    setAppInstanceNameSystemProperty(sc);
    String appName = System.getProperty(Constants.SYSKEY_APP_NAME);
    String appInstanceName = System.getProperty(Constants.SYSKEY_APP_INSTANCE_NAME);
    String appNameList = System.getProperty(Constants.SYSKEY_APP_NAME_LIST);
    if (StringUtils.isBlank(appName) || StringUtils.isBlank(appInstanceName) || StringUtils.isBlank(appNameList))
    {
      log.error("At least one of these system properties is not set: " + Constants.SYSKEY_APP_NAME + ", " + Constants.SYSKEY_APP_NAME_LIST + ", " + Constants.SYSKEY_APP_INSTANCE_NAME);
    }
    if (!StringUtils.contains(appNameList, appName))
    {
      log.error("This app's name '" + appName + "' (system property " + Constants.SYSKEY_APP_NAME + ") is not in the app list '" + appNameList + "' (system property " + Constants.SYSKEY_APP_NAME_LIST + ")");
    }
  }


  private void notify(ServletContext sc, String action)
  {
    log.debug(sc);
    dumpServletContext(sc);
    ConfigService config = BudgesContext.getConfigService();
    String to = config.getEmailTo();
    boolean sendNotification = config.getSpamStartupEmails();
    if (sendNotification)
    {
      String contextPath = sc.getContextPath();
      // TODO make this a constant
      Properties props = getPropertiesFromClasspath("version.properties");
      // TODO make this a constant
      String scmBuildNumber = props.getProperty("scm-build");
      StringWriter stringWriter = new StringWriter();

      props.list(new PrintWriter(stringWriter));


      StringBuffer emailBody = new StringBuffer();
      emailBody.append("For all changes included in this build, please see details for the current SCM Build Number at this link:\n");
      emailBody.append(config.getScmBuildUrl());
      emailBody.append("\n\n");
      emailBody.append(stringWriter.getBuffer());
      emailBody.append("\n");
      String emailSubject = contextPath.substring(1) + " application " + action + " on " + getLocalHostInfo() + " [Build " + scmBuildNumber + "]";
      sendEmail(to, emailSubject, emailBody.toString());
    }
    else
    {
      log.info("not sending notification email");
    }
  }


  private void sendEmail(String to, String subject, String msg) {
    try {
        BudgesContext.getEmailUtil().sendSystemEmail(subject, msg);
    }
    catch (EmailException e) {
      log.error(e);
    }
  }


  private void startConfigPoller()
  {
    configPollTimer = new Timer(true);
    int freq = BudgesContext.getConfigService().getTouchfilePollFreq();
    configPollTimer.scheduleAtFixedRate(new ConfigPoller(), freq * 1000, freq * 1000);
  }


  private void stopConfigPoller()
  {
    if (configPollTimer != null)
      configPollTimer.cancel();
  }


  public void dumpServletContext(ServletContext sc)
  {
    ConfigService config = BudgesContext.getConfigService();
    StringBuilder sb = new StringBuilder("\nServletContext Info:");
    sb.append("\n Context: " + sc.getContext("/"));
    sb.append("\n Context Path:" + sc.getContextPath());
    sb.append("\n Servlet API Major Version:" + sc.getMajorVersion());
    sb.append("\n Servlet API Minor Version: " + sc.getMinorVersion());
    sb.append("\n Container: " + sc.getServerInfo());
    sb.append("\n " + Util.getDatabaseInfo(config.getDataSource()));

    @SuppressWarnings("unchecked")
    Enumeration<String> initParamsEnum = sc.getInitParameterNames();
    if (initParamsEnum != null)
    {
      sb.append("\n Init Parmeters:");
      while (initParamsEnum.hasMoreElements())
      {
        String paramName = initParamsEnum.nextElement();
        sb.append("\n\tparam " + paramName + "='" + sc.getInitParameter(paramName) + "'");
      }
    }
    sb.append("\n Servlet Context Name: " + sc.getServletContextName());
    sb.append("\n");
    log.debug(sb);
  }


  private void dumpSystemProperties()
  {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    printWriter.println("\n======================== System Properties ========================\n");
    System.getProperties().list(printWriter);
    printWriter.println("\n====================== End System Properties ======================\n");
    log.debug(stringWriter.getBuffer());
  }


  public String getLocalHostInfo()
  {
    try
    {
      return InetAddress.getLocalHost().toString();
    }
    catch (UnknownHostException e)
    {
      return "[UNKNOWN]";
    }
  }


  public String getLocalHostName()
  {
    try
    {
      return InetAddress.getLocalHost().getCanonicalHostName();
    }
    catch (UnknownHostException e)
    {
      return "[UNKNOWN]";
    }
  }


  private Properties getPropertiesFromClasspath(String propFileName)
  {
    Properties props = new Properties();
    InputStream inputStream = null;
    try
    {
      inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
      props.load(inputStream);
    }
    catch (IOException e)
    {
      log.error("property file '" + propFileName + "' not found in the classpath", e);
    }
    finally
    {
      if (inputStream != null)
        try
        {
          inputStream.close();
        }
        catch (IOException e)
        {
          log.error("IOException thrown closing properties file inputStream for '" + propFileName + "'");
        }
    }
    return props;
  }


  public void setAppNameSystemProperty(ServletContext sc)
  {
    String appName = System.getProperty(Constants.SYSKEY_APP_NAME);
    if (StringUtils.isBlank(appName))
    {
      appName = sc.getContextPath().replace("/", "");
      System.setProperty(Constants.SYSKEY_APP_NAME, appName);
      log.debug("App name not specified via JVM param, setting it based on servlet context path to : '" + appName + "'");
    }
    else
    {
      log.debug("App name set via JVM param to: '" + appName + "'");
    }
  }


  public void setAppInstanceNameSystemProperty(ServletContext sc)
  {
    String appInstanceName = System.getProperty(Constants.SYSKEY_APP_INSTANCE_NAME);
    if (StringUtils.isBlank(appInstanceName))
    {
      appInstanceName = getLocalHostName();
      System.setProperty(Constants.SYSKEY_APP_INSTANCE_NAME, appInstanceName);
      log.debug("App instance name not specified via JVM param, setting it based on local host name to: '" + appInstanceName + "'");
    }
    else
    {
      log.debug("App instance name set via JVM param to: '" + appInstanceName + "'");
    }
  }


  public void setAppNameListSystemProperty()
  {
    String appNameList = System.getProperty(Constants.SYSKEY_APP_NAME_LIST);
    if (StringUtils.isBlank(appNameList))
    {
      appNameList = Constants.DEFAULT_APP_NAME_LIST;
      System.setProperty(Constants.SYSKEY_APP_NAME_LIST, appNameList);
      log.debug("App name list not specified via JVM param, setting it based on default name list to: '" + appNameList + "'");
    }
    else
    {
      log.debug("App name list set via JVM param to: '" + appNameList + "'");
    }
  }


  public void setContainerNameSystemProperty(ServletContext sc)
  {
    System.setProperty(Constants.SYSKEY_CONTAINER_NAME, sc.getServerInfo());
  }


  /**
   * This method is called on startup to unzip the embedded Comptroller XML
   * Package file to the file system base directory from which to load all XML
   * schema and XSLT resources (when the load source for these is the file
   * system). An app property controls whether this should be done at startup or
   * not. If this property is set to false, this method does nothing.
   */
  public void unzipComptrollerXmlPackageFile()
  {
    ConfigService config = BudgesContext.getConfigService();

    // Don't attempt to unzip at startup unless we are configured to do so
    if (!config.getPopulateBaseDirForXmlResourcesAtStartup())
    {
      log.debug("Not configured to populate XML resources file system directory with Comptroller XML package file, so ain't doing it.");
      return;
    }

    // Randomly pick the first app listed in which to unzip the XML Package file
    // (we don't want all apps unzipping the file, it's unnecessary and would
    // also require coordination so that only first one to start does the
    // unzipping)
    String unzippingAppName = config.getAppNameList()[0];
    if (unzippingAppName.equalsIgnoreCase(config.getAppName()))
    {
      InputStream xmlPackageInputStream = null;
      try
      {
        xmlPackageInputStream = new BufferedInputStream(AppEventListener.class.getClassLoader().getResourceAsStream(Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME));
        File xmlPackageFile = new File(BudgesContext.getConfigService().getWorkingFolder(), Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME);
        FileUtil.writeFileContents(xmlPackageInputStream, xmlPackageFile);
        Util.unzipComptrollerXMLPackageToXmlResourceBaseDir(xmlPackageFile);
      }
      catch (IOException e)
      {
        log.error("Could not write or unzip the Comptroller XML Package file for placing into the XML resources file system directory", e);
      }
      finally
      {
        FileUtil.close(xmlPackageInputStream);
      }
    }
    else
    {
      log.debug("Not unzipping Comptroller XML Package file into the XML resources file system directory (only done in '" + unzippingAppName + "' app).");
    }
  }

}
