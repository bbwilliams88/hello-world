/*
 * $Id: BudgesFileSystemResourceResolver.java $
 */
package mil.dtic.utility;

import java.io.InputStream;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.ls.LSInput;

public class BudgesFileSystemXmlSchemaResourceResolver extends BudgesXmlSchemaResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesFileSystemXmlSchemaResourceResolver.class);


  public BudgesFileSystemXmlSchemaResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public LSInput resolveResource(final String type, final String namespaceURI, final String publicId, final String systemId, final String baseURI)
  {
    log.trace("Looking for file system XML schema resource, type: " + type +
      ", namespaceURI: " + namespaceURI +
      ", publicId: " + publicId +
      ", systemId: " + systemId +
      ", baseURI: " + baseURI);

    return new BudgesLSInput()
    {
      @Override
      public InputStream getByteStream()
      {
        String baseDir = BudgesContext.getConfigService().getXmlResourceBaseDir();
        return FileUtil.getFileInputStream(baseDir, getPathList(), systemId);
      }
    };
  }
}
