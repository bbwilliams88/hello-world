package mil.dtic.utility.api;

import org.apache.commons.mail.EmailException;

import mil.dtic.cbes.constants.Environment;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import netscape.ldap.LDAPException;


public interface EmailService {
   
    void sendEmail(String from, String[] to, String[] cc, String subject, String msg, boolean appendDevInfo) throws EmailException;
    String sendEmail(String from, String[] to, String[] cc, String subject, String msg, boolean appendDevInfo, boolean mailbox) throws EmailException;
    void sendFromPostalCode(String postalCode) throws EmailException;
    void sendProfileUpdateEmail(UserCredentials srcUc, LdapUser destUser) throws EmailException;
    void sendUserAddedEmail(UserCredentials srcUc, LdapUser destUser, Integer agencyId) throws EmailException, LDAPException;
    void sendP40UserAddedEmail(String senderLDAPAddress, String recipientLDAPAddress,String senderFullName, String recipientFullName, Integer agencyId) throws EmailException, LDAPException;
    void sendSystemEmail(String subject, String msg) throws EmailException;
    void sendSystemEmail(String subject, String msg, UserCredentials userCredentials) throws EmailException;
    void sendSystemEmail(String subject, String msg, P40User p40User) throws EmailException;
    String getLocalHostName();
    String resolveEmail(String email, String currentUserAddress);
    String resolveEmail(String email, UserCredentials userCredentials);
    String getUserLdapBlock(LdapUser luser);
    String getUserInfoBlock(P40User p40User);
    String getUserInfoBlock(UserCredentials userCredentials);
    String getSystemInfoBlock(Environment env);
    void sendRegEmail(UserCredentials senderCreds, ServiceAgency org, boolean hasAdmins, String adminUidsLine, String[] cc, String... to) throws EmailException;
    boolean sendJobCompleteEmail(BudgesJob theJob, BudgesUser theUser);
    
    
    
    
    
    
}
