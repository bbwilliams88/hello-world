package mil.dtic.utility;

import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.jibx.extras.DocumentComparator;
import org.jibx.runtime.Utility;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/**
 * Document comparator modifies the JiBX DocumentComparator to prevent equivalent numeric values (e.g., 04 vs 4) from failing the comparison.
 */
public class BudgesDocumentComparator extends DocumentComparator
{

  private static final Logger log = CbesLogFactory.getLog(DocumentComparator.class);


  public BudgesDocumentComparator(PrintStream print, boolean schema)
    throws XmlPullParserException
  {
    super(print, schema);
  }


  public BudgesDocumentComparator(PrintStream print)
    throws XmlPullParserException
  {
    this(print, false);
  }


  /**
   * Uses the base equalValues method. If it fails and the two values are numeric, then apply numeric equivalence check.
   */
  @Override
  protected boolean equalValues(String texta, String textb)
  {
    if (!super.equalValues(texta, textb) && !m_schemaCompare)
    {
      String trima = texta.trim();
      String trimb = textb.trim();
      if (Utility.ifDecimal(trima) && Utility.ifDecimal(trimb))
        return normalizeDecimal(trima).equals(normalizeDecimal(trimb));
    }
    return true;
  }


  protected String normalizeDecimal(String text)
  {

    // first skip past a leading sign character
    int length = text.length();
    int first = 0;
    boolean negate = false;
    char chr = text.charAt(0);
    if (chr == '-')
    {
      negate = true;
      first = 1;
    }
    else if (chr == '+')
    {
      first = 1;
    }

    // scan to find first and last non-zero characters
    int last = -1;
    int point = -1;
    for (int i = first; i < length; i++)
    {
      chr = text.charAt(i);
      if (chr == '0')
      {
        if (i == first)
        {
          first++;
        }
      }
      else if (chr == '.')
      {
        point = i;
      }
      else
      {
        last = i;
      }
    }

    // first check for case of no significant digits
    if (last < 0)
    {
      return negate ? "-0" : "0";
    }

    // return a normalized representation
    StringBuffer buff = new StringBuffer(length);
    if (negate)
    {
      buff.append('-');
    }
    if (point >= 0)
    {

      // decimal point seen, and at least one digit seen
      if (first < point)
      {

        // digit seen prior to decimal point
        if (last > point)
        {
          buff.append(text.substring(first, last + 1));
        }
        else
        {
          buff.append(text.substring(first, point));
        }

      }
      else
      {

        // no digits prior to decimal point, so must be after
        buff.append(text.substring(point, last + 1));

      }
    }
    else
    {

      // no decimal point, just go from first non-zero digit
      buff.append(text.substring(first));

    }
    return buff.toString();
  }


  /**
   * Verifies that the attributes on the current start tags match. Any mismatches are printed immediately.
   *
   * @return <code>true</code> if the attributes match, <code>false</code> if not
   */
  @Override
  protected boolean matchAttributes()
  {
    int counta = m_parserA.getAttributeCount();
    int countb = m_parserB.getAttributeCount();
    boolean[] flags = new boolean[countb];
    boolean match = true;
    for (int i = 0; i < counta; i++)
    {
      String name = m_parserA.getAttributeName(i);
      String ns = m_parserA.getAttributeNamespace(i);
      String value = m_parserA.getAttributeValue(i);
      boolean found = false;
      for (int j = 0; j < countb; j++)
      {
        if (name.equals(m_parserB.getAttributeName(j)) &&
          ns.equals(m_parserB.getAttributeNamespace(j)))
        {
          flags[j] = true;
          if (!equalValues(value, m_parserB.getAttributeValue(j)))
          {
            if (match)
            {
              printError("Attribute mismatch");
              match = false;
            }
            m_differencePrint.println("  attribute " +
              buildName(ns, name) + " value '" + value +
              "' != '" + m_parserB.getAttributeValue(j) + '\'');
          }
          found = true;
          break;
        }
      }
      if (!found && !isIgnore(name, ns) && !(m_schemaCompare && isSchemaLocation(name, ns)))
      {
        if (match)
        {
          printError("Attribute mismatch");
          match = false;
        }
        m_differencePrint.println("  attribute " +
          buildName(ns, name) + "=\"" + value +
          "\" is missing from second document");
      }
    }
    for (int i = 0; i < countb; i++)
    {
      if (!flags[i])
      {
        String ns = m_parserB.getAttributeNamespace(i);
        String name = m_parserB.getAttributeName(i);
        if (!isIgnore(name, ns) && !(m_schemaCompare && isSchemaLocation(name, ns)))
        {
          if (match)
          {
            printError("Attribute mismatch");
            match = false;
          }
          m_differencePrint.println("  attribute " +
            buildName(ns, name) +
            " is missing from first document");
        }
      }
    }
    return match;
  }


  /**
   * Check if an attribute should be ignored, the only one is targetSchemaVersion generated by the system for RDT&E.
   *
   * @param name
   * @param ns
   * @return <code>true</code> if the attribute should be ignored, <code>false</code> if not
   */
  protected boolean isIgnore(String name, String ns)
  {
      return("targetSchemaVersion".equals(name) || "schemaLocation".equals(name));
  }


  /**
   * Check if a name/namespace pair matches a schema namespace location attribute.
   *
   * @param name
   * @param ns
   * @return <code>true</code> if a schema namespace location, <code>false</code> if not
   */
  protected boolean isSchemaLocation(String name, String ns)
  {
    return("http://www.w3.org/2001/XMLSchema-instance".equals(ns) && ("schemaLocation".equals(name) || "noNamespaceSchemaLocation".equals(name)));
  }


  /**
   * Method which can skip an empty open/close tag pair that is not in degenerate form from the original xml and continue xml processing.
   *
   * @return true if the current, non-matching tag name is an empty tag not recreated by the jibx marshalling, false otherwise.
   */
  protected boolean isEmptyTagInImportFile()
  {
    String name = m_parserA.getName();
    try
    {
      m_parserA.next();
      if (m_parserA.getEventType() != XmlPullParser.END_TAG)
      {
        return false;
      }

      if (StringUtils.equals(name, m_parserA.getName()))
      {
        m_parserA.nextTag();
        return true;
      }

      return false;
    }
    catch (XmlPullParserException ex)
    {
      if (m_differencePrint != null)
      {
        log.error("Error comparing XML documents.");
        log.error(m_differencePrint, ex);
        m_differencePrint.flush();
      }

      return false;
    }
    catch (IOException ex)
    {
      if (m_differencePrint != null)
      {
        log.error("Error comparing XML documents.");
        log.error(m_differencePrint, ex);
        m_differencePrint.flush();
      }

      return false;
    }
  }


  /**
   * Compares a pair of documents by reading them in parallel from a pair of parsers. The comparison ignores differences in whitespace separating elements, but treats whitespace as significant within
   * elements with only character data content.
   *
   * @param rdra
   *          reader for first document to be compared
   * @param rdrb
   *          reader for second document to be compared
   * @return <code>true</code> if the documents are the same, <code>false</code> if they're different
   */
  @Override
  public boolean compare(Reader rdra, Reader rdrb)
  {
    try
    {

      // set the documents and initialize
      m_parserA.setInput(rdra);
      m_parserB.setInput(rdrb);
      boolean content = false;
      String texta = "";
      String textb = "";
      boolean same = true;
      while (true)
      {
        // start by collecting and moving past text content
        if (m_parserA.getEventType() == XmlPullParser.TEXT)
        {
          texta = m_parserA.getText();
          m_parserA.next();
        }

        if (m_parserB.getEventType() == XmlPullParser.TEXT)
        {
          textb = m_parserB.getText();
          m_parserB.next();
        }

        // now check actual tag state
        int typea = m_parserA.getEventType();
        int typeb = m_parserB.getEventType();
        if (typea != typeb)
        {
          if (m_parserB.getName() != null && StringUtils.equals(m_parserB.getName(), "DocumentAssemblyOptions") && m_parserB.isEmptyElementTag())
          {
            // ok to skip this tag if this tag in result xml is empty
            return true;
          }
          else if (StringUtils.equals(m_parserB.getName(), "DocumentAssemblyOptions") && StringUtils.equals(m_parserA.getName(), "LineItem"))
          {
            // ok to skip this tag if it is missing in input xml
            while (!StringUtils.equals("LineItem", m_parserB.getName()))
            {
              m_parserB.next();
            }
            return true;
          }
          printError("Different document structure");
          return false;
        }
        else if (typea == XmlPullParser.START_TAG)
        {

          // compare start tags, attributes, and prior text
          content = true;
          if (!matchNames())
          {
            // Don't advance the XmlPullParsers if the parserA is looking at an empty tag.
            if (!isEmptyTagInImportFile())
            {
                printError("Different start tags");
                return false;
            }
            else if (!m_parserB.isEmptyElementTag())
            {
              printError("Different start tags");
              return false;
            }
            else
            {
              m_parserB.nextTag();
              m_parserB.nextTag();
            }
          }
          else
          {
            if (!matchAttributes())
            {
              same = false;
            }
            if (!matchText(texta, textb,
              "Different text content between elements"))
            {
              same = false;
            }
          }
          texta = textb = "";

        }
        else if (typea == XmlPullParser.END_TAG)
        {

          // compare end tags and prior text
          if (!matchNames())
          {
            printError("Different end tags");
            return false;
          }
          if (content)
          {
            if (!matchText(texta, textb, "Different text content"))
            {
              same = false;
            }
            content = false;
          }
          else
          {
            if (!matchText(texta, textb,
              "Different text content between elements"))
            {
              same = false;
            }
          }
          texta = textb = "";

        }
        else if (typea == XmlPullParser.END_DOCUMENT)
        {
          if (!same && m_differencePrint != null)
          {
            m_differencePrint.flush();
          }
          return same;
        }

        // advance both parsers to next component
        m_parserA.next();
        m_parserB.next();

      }
    }
    catch (IOException ex)
    {
      if (m_differencePrint != null)
      {
       log.error(ex.getMessage());//NOSONAR
        m_differencePrint.flush();
      }
      return false;
    }
    catch (XmlPullParserException ex)
    {
      if (m_differencePrint != null)
      {
        log.error(ex.getMessage()); // NOSONAR
        m_differencePrint.flush();
      }
      return false;
    }
  }
}
