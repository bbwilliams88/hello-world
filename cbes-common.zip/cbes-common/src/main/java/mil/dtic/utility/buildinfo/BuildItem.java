package mil.dtic.utility.buildinfo;

public class BuildItem {
    
    private String buildType;
    private String typeValue;
    
    public BuildItem() {
    }
    
    public BuildItem(String buildType, String typeValue) {
        this.buildType = buildType;
        this.typeValue = typeValue;
    }

    public String getBuildType() {
        return buildType;
    }

    public void setBuildType(String buildType) {
        this.buildType = buildType;
    }

    public String getTypeValue() {
        return typeValue;
    }

    public void setTypeValue(String typeValue) {
        this.typeValue = typeValue;
    }

    @Override
    public String toString() {
        return "BuildItem [buildType=" + buildType + ", typeValue=" + typeValue + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((buildType == null) ? 0 : buildType.hashCode());
        result = prime * result + ((typeValue == null) ? 0 : typeValue.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BuildItem other = (BuildItem) obj;
        if (buildType == null) {
            if (other.buildType != null)
                return false;
        } else if (!buildType.equals(other.buildType))
            return false;
        if (typeValue == null) {
            if (other.typeValue != null)
                return false;
        } else if (!typeValue.equals(other.typeValue))
            return false;
        return true;
    }
    
    
    

}
