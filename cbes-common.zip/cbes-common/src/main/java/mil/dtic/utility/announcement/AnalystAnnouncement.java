package mil.dtic.utility.announcement;

import javax.annotation.concurrent.Immutable;

import mil.dtic.utility.announcement.options.Audience;

@Immutable
public class AnalystAnnouncement extends Announcement {

	private boolean addEnvToSubject;
	
	public AnalystAnnouncement(Audience audience, String emails, String subject, String content, String senderEmail, boolean addEnvToSubject) {
		super(audience, emails, subject, content, senderEmail);
		this.addEnvToSubject = addEnvToSubject;
	}
	
	public boolean getAddEnvToSubject() {
		return this.addEnvToSubject;
	}
}
