/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

/**
 * Sorts beans on the given method name.
 *
 * Note you need to specify the exact name of the method.
 *
 * if the field was name then the method would be getName
 *
 * <code>
 * BeanComparitor c = new BeanComparitor();
 * TreeSet s = new TreeSet(c);
 * c.setMethodName("getName");
 * c.setReverse(true);
 * s.add(object1);
 * s.add(object2);
 * System.out.println(s);
 * </code>
 */
public class BeanComparitor implements Comparator, Serializable
{
  private static final Logger log = CbesLogFactory.getLog(BeanComparitor.class);
  private static final long serialVersionUID = 3090580658857177112L;

  private static final boolean USE_PRIMARY_VALUES = true;
  private static final boolean USE_SECONDARY_VALUES = false;

  private final String primaryMethodName;
  private String secondaryMethodName;
  private boolean reverse = false;


  /**
   * Constructor for a new BeanComparitor
   *
   * @param methodName
   *          The method name to compare on
   */
  public BeanComparitor(String primaryMethodName)
  {
    this.primaryMethodName = primaryMethodName;
  }

  /**
   * Constructor for a new BeanComparitor
   *
   * @param methodName
   *          The method name to compare on
   * @param reverse
   *          Flag to reverse the collection
   */
  public BeanComparitor(String primaryMethodName, boolean reverse)
  {
    this(primaryMethodName);
    this.reverse = reverse;
  }

  /**
   * Constructor for a new BeanComparitor
   *
   * @param methodName
   *          The method name to compare on
   */
  public BeanComparitor(String primaryMethodName, String secondaryMethodName)
  {
    this(primaryMethodName);
    this.secondaryMethodName = secondaryMethodName;
  }

  /**
   * Constructor for a new BeanComparitor
   *
   * @param methodName
   *          The method name to compare on
   * @param reverse
   *          Flag to reverse the collection
   */
  public BeanComparitor(String primaryMethodName, String secondaryMethodName, boolean reverse)
  {
    this(primaryMethodName,secondaryMethodName);
    this.reverse = reverse;
  }

  /**
   * Compares two objects and returns the comparable value
   *
   * @param o1
   *          Object 1 to compare
   * @param o2
   *          Object 2 to compare
   * @return the comparable value
   */
  @Override
public int compare(Object o1, Object o2)
  {
    return compare(o1, o2, USE_PRIMARY_VALUES);
  }

  /**
   * Compares two objects and returns the comparable value
   *
   * @param o1
   *          Object 1 to compare
   * @param o2
   *          Object 2 to compare
   * @return the comparable value
   */
  public int compare(Object o1, Object o2, boolean valuesToUse)
  {
    int result = 0;

    Object v1 = null;
    Object v2 = null;

    if (valuesToUse == USE_PRIMARY_VALUES)
    {
        v1 = getPrimaryValue(o1);
        v2 = getPrimaryValue(o2);
    } else {
        v1 = getSecondaryValue(o1);
        v2 = getSecondaryValue(o2);
    }

    if (v1 == null && v2 == null)
    {
      result = 0;
    }
    else if (v1 == null)
    {
    	result = 1;
    }
    else if (v2 == null)
    {
      result = -1;
    }
    else if (v1 instanceof Comparable && v2 instanceof Comparable)
    {
    	result = ((Comparable) v1).compareTo(v2);
    }
    else
    {
    	throw new RuntimeException("Objects " + v1 + " and " + v2 + " cannot be compared becuase they don't both implement Comparable!");
    }

	// If the two objects are equal, campare them using their secondary values,
	// if it's available.
	if (result == 0 && valuesToUse == USE_PRIMARY_VALUES && hasSecondaryValue())
	{
		result = compare(o1, o2, USE_SECONDARY_VALUES);
	}

    if (reverse)
      result = -result;

    return result;
  }

  /**
   * Gets the primary value from the given object's getter method.
   *
   * @param ob1
   * @return Object
   */
  private Object getPrimaryValue(Object ob1)
  {
	  return getValue(primaryMethodName, ob1);
  }

  /**
   * Gets the secondary value from the given object's getter method.
   *
   * @param ob1
   * @return Object
   */
  private Object getSecondaryValue(Object ob1)
  {
	  return getValue(secondaryMethodName, ob1);
  }

  /**
   * Gets the value from the given object's getter method
   *
   * @param ob1
   * @return Object
   */
  private Object getValue(String methodName, Object ob1)
  {
    try
    {
      Method method = ob1.getClass().getMethod(methodName);
      return method.invoke(ob1);
    }
    catch (IllegalAccessException | NoSuchMethodException | IllegalArgumentException | InvocationTargetException e)
    {
      log.error("Failed to invoke comparator method " + methodName + " on object " + ob1, e);
      throw new RuntimeException(e);
    }
  }

  /**
   * Return true if this comparator has a method to return the secondary value.
   */
  private boolean hasSecondaryValue()
  {
      return StringUtils.isNotEmpty(secondaryMethodName);
  }
}
