package mil.dtic.utility.attachment;

import java.util.Random;

import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

public class RandomStringGenerator {
    private static final Logger log = CbesLogFactory.getLog(RandomStringGenerator.class);
    private static final String CHARS = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ234567890!@#$";
    private static final String SPEC_CHARS = "!@$%";
    private static final Random random = new Random();
    private static final int DEFAULT_SIZE = 5;
    
    public static String getToken(){
        return getToken(RandomStringGenerator.DEFAULT_SIZE);
    }
    
    public static String getToken(int size){
        
        if (size == 0){
            size = 1;
        }
        
        StringBuilder token = new StringBuilder(size);
        
        for (int i = 0; i < size; i++) {
            token.append(CHARS.charAt(random.nextInt(CHARS.length())));
        }
        
        log.debug("getToken: - value: " + token.toString());
        return token.toString();
    }
    
    public static String getSpecialToken(int size) {
        if (size == 0){
            size = 1;
        }
        
        StringBuilder token = new StringBuilder(size);
        
        for (int i = 0; i < size; i++) {
            token.append(SPEC_CHARS.charAt(random.nextInt(SPEC_CHARS.length())));
        }
        
        log.debug("getSpecialToken: - value: " + token.toString());
        return token.toString();
        
    }
    
}
