/*
 * $Id: BudgesFileSystemURIResolver.java 63662 2011-12-23 18:03:36Z aibrahim $
 */
package mil.dtic.utility;

import java.io.File;
import java.util.List;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.apache.logging.log4j.Logger;

public class BudgesFileSystemXsltResourceResolver extends BudgesXsltResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesFileSystemXsltResourceResolver.class);


  public BudgesFileSystemXsltResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public Source findResource(String href, String base)
  {
    // href = Util.cleanupClasspathResourceRef(href);
    File loc = new File(BudgesContext.getConfigService().getXmlResourceBaseDir());
    for (String path : getPathList())
    {
      File file = new File(loc, path + href);
      log.trace("Looking for file system resource '" + file);
      if (file.exists())
      {
        log.trace("Found file system resource '" + file);
        return new StreamSource(file);
      }
    }
    log.debug("Did not find file system resource (base:href) '" + base + ":" + href + "' within base dir " + loc);
    return null;
  }
}
