package mil.dtic.utility.announcement;

public interface AnnouncementService {
    
    String validate(Announcement announcement);
    String validate(Announcement announcement, String[] cc);
}
