/*
 * $Id: BudgesFileSystemURIResolver.java 63662 2011-12-23 18:03:36Z aibrahim $
 */
package mil.dtic.utility;

import java.util.List;

import javax.xml.transform.Source;

import org.apache.logging.log4j.Logger;

public class BudgesDatabaseXsltResourceResolver extends BudgesXsltResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesFileSystemXsltResourceResolver.class);


  public BudgesDatabaseXsltResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public Source findResource(String href, String base)
  {
    // TODO
    throw new RuntimeException("Database XSLT Resource Resolver is not implemented!");
  }
}
