/*
 * $Id$
 */
package mil.dtic.utility;

import java.util.List;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

public abstract class BudgesXmlSchemaResourceResolver implements LSResourceResolver
{
  private final List<String> pathList;


  public BudgesXmlSchemaResourceResolver(List<String> pathList)
  {
    this.pathList = pathList;
  }


  public List<String> getPathList()
  {
    return pathList;
  }


  public LSInput resolveResource(String systemId)
  {
    return resolveResource(null, null, null, systemId, null);
  }
}
