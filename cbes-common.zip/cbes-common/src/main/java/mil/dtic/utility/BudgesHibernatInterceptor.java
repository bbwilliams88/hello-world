/*
 * $Id$
 */
package mil.dtic.utility;

import org.apache.logging.log4j.Logger;

public class BudgesHibernatInterceptor extends org.hibernate.EmptyInterceptor

{
  private static final Logger log = CbesLogFactory.getLog(BudgesHibernatInterceptor.class);
  
  public BudgesHibernatInterceptor()
  {
    log.debug("Initialized BUDGES HIBERNATE INTERCEPTOR");
  }
  
}
