/*
 * $Id: BudgesHttpSessionListener.java 35866 2010-01-11 18:22:24Z aahmed $
 */
package mil.dtic.utility;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;

public class BudgesHttpSessionListener2 implements HttpSessionListener
{
  private static final Logger log = CbesLogFactory.getLog(BudgesHttpSessionListener2.class);

  Set<HttpSession> allHttpSessions = new HashSet<HttpSession>();

  public void sessionCreated(HttpSessionEvent event)
  {
    log.debug("Budges HTTP session created, id=" + event.getSession().getId() +", source=" + event.getSource());
    if (event.getSession().getServletContext().getAttribute(Constants.APPKEY_ALL_SESSIONS) == null)
      event.getSession().getServletContext().setAttribute(Constants.APPKEY_ALL_SESSIONS, allHttpSessions);
    synchronized (allHttpSessions)
    {
      allHttpSessions.add(event.getSession());
    }
  }

  public void sessionDestroyed(HttpSessionEvent event)
  {
    log.debug("Budges HTTP session about to be destroyed, id=" + event.getSession().getId() +", source=" + event.getSource());
    synchronized (allHttpSessions)
    {
      allHttpSessions.remove(event.getSession());
    }
  }
}
