/*
 * $Id$
 */
package mil.dtic.utility;

import mil.dtic.cbes.constants.Constants;

  //  Author : Fred Swartz - 2006-12-29 - Placed in public domain.
  // http://leepoint.net/notes-java/examples/components/romanNumerals/romanNumeral.html

public class RomanNumeralUtil
{
  final static RomanValue[] ROMAN_VALUE_TABLE = {
    new RomanValue(1000, "M"),
    new RomanValue( 900, "CM"),
    new RomanValue( 500, "D"),
    new RomanValue( 400, "CD"),
    new RomanValue( 100, "C"),
    new RomanValue(  90, "XC"),
    new RomanValue(  50, "L"),
    new RomanValue(  40, "XL"),
    new RomanValue(  10, "X"),
    new RomanValue(   9, "IX"),
    new RomanValue(   5, "V"),
    new RomanValue(   4, "IV"),
    new RomanValue(   1, "I")
};


  public static String int2RomanLowerCase(int n)
  {
    return int2RomanUpperCase(n).toLowerCase();
  }
  
  public static String int2RomanUpperCase(int n)
  {
    if (n >= Constants.MAX_ROMAN_NUMERAL_VALUE || n < 1)
    {
      throw new NumberFormatException("Numbers must be in range 1 - " + Constants.MAX_ROMAN_NUMERAL_VALUE);
    }
    StringBuffer result = new StringBuffer(10);

    for (RomanValue equiv : ROMAN_VALUE_TABLE)
    {
      while (n >= equiv.intVal)
      {
        n -= equiv.intVal;
        result.append(equiv.romVal);
      }
    }
    return result.toString();
  }

  private static class RomanValue
  {
    private int intVal;
    private String romVal;


    RomanValue(int dec, String rom)
    {
      this.intVal = dec;
      this.romVal = rom;
    }
  }
}
