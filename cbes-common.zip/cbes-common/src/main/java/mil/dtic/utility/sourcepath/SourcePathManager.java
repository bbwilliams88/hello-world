package mil.dtic.utility.sourcepath;

public interface SourcePathManager {
    void createSource(SourcePath sourcePath);
}
