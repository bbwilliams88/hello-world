/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.InputStream;
import java.io.Reader;

import org.w3c.dom.ls.LSInput;

public abstract class BudgesLSInput implements LSInput
{
  public BudgesLSInput()
  {
  }


  public String getBaseURI()
  {
    return null;
  }


  public boolean getCertifiedText()
  {
    return false;
  }


  public Reader getCharacterStream()
  {
    return null;
  }


  public String getEncoding()
  {
    return "UTF-8";
  }


  public String getPublicId()
  {
    return null;
  }


  public String getStringData()
  {
    return null;
  }


  public String getSystemId()
  {
    return null;
  }


  public void setBaseURI(String arg0)
  {
  }


  public void setByteStream(InputStream arg0)
  {
  }


  public void setCertifiedText(boolean arg0)
  {
  }


  public void setCharacterStream(Reader arg0)
  {
  }


  public void setEncoding(String arg0)
  {
  }


  public void setPublicId(String arg0)
  {
  }


  public void setStringData(String arg0)
  {
  }


  public void setSystemId(String arg0)
  {
  }

}
