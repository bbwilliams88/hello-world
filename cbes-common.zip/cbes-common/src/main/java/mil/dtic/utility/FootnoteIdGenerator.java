package mil.dtic.utility;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;

public class FootnoteIdGenerator
{
  private static final Logger log = CbesLogFactory.getLog(FootnoteIdGenerator.class);

  private Map<String, Integer> seqMap;
  private Map<String, Integer> nextSeqMap = new HashMap<String, Integer>();

  public synchronized int getId(String context, String key, boolean createIfAbsent)
  {
    if (createIfAbsent)
      return getId(context, key);
    else
      return findId(context, key);
  }
  
  private synchronized int getId(String context, String key)
  {    
    if (seqMap == null)
    {
      seqMap = new HashMap<String, Integer>();
      log.debug("Initialized Java map for footnote numbering...");
    }
    String contextKey = getContextKey(context, key);
    Integer nextVal = seqMap.get(contextKey);
    if (nextVal == null)
    {
      nextVal = nextSeqMap.get(context);
      if (nextVal == null)
        nextVal = 0;
      nextSeqMap.put(context, ++nextVal);
      seqMap.put(contextKey, nextVal);
      log.trace("*** Footnote created for context.key: " + contextKey + ", footnoteId = " + nextVal);
    } else {
      log.trace("*** Footnote retrieved for context.key: " + contextKey + ", footnoteId = " + nextVal);
    }
    return nextVal;
  }


  private synchronized int findId(String context, String key)
  {    
    Integer val = null;
    String contextKey = getContextKey(context, key);
    if (seqMap != null)
    {      
      val = seqMap.get(contextKey);
    }
    if (val == null)
      val = -1;
    log.trace("*** Footnote lookup result for context.key: " + contextKey + ", footnoteId = " + val);
    return val;
  }

  private String getContextKey(String context, String key)
  {
    String contextKey = "";
    if (context != null)
      contextKey = context; 
    if (key != null)
      contextKey += "." + key;
    return contextKey;
  }
  
}
