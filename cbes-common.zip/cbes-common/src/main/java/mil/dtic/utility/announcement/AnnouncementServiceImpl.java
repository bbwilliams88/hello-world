package mil.dtic.utility.announcement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.mail.SendFailedException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;
import mil.dtic.utility.announcement.exception.AnnouncementException;
import mil.dtic.utility.api.EmailService;

@Component
public class AnnouncementServiceImpl implements AnnouncementService{
    private static final Logger log = CbesLogFactory.getLog(AnnouncementServiceImpl.class);
    private static final boolean APPEND_DEV_INFO = true;
    private static final String EMAIL_NOTIFY = "Check R2Support incoming email for explanation of issues";
    
    @Autowired
    private BudgesUserDAO budgesUserDao;
    
    private String[] specialCC = null;    
    
    
    @Override
    public String validate(final Announcement announcement, final String[] cc) {
        specialCC = cc;
        String ok = validate(announcement);
        specialCC = null;
        return ok;
    }
    
    @Override
    public String validate(final Announcement announcement){
        log.debug("validate: - announcement: " + announcement.toString());
        
        AnnouncementValidator validator = new AnnouncementValidator(announcement);
        String validation = validator.validate();
        
        if (validation.equals(AnnouncementValidator.OK)){
            
            try {
                process(announcement, validator.getValidatedEmailList());
            }
            catch(EmailException me){
                validation += String.format(" : email execution failure: %s", me.getMessage());
            }
            catch(AnnouncementException e){
                
                validation += String.format(" : failure executing email: %s", e.getMessage());
            }
        }
        
        return validation;
    }

    /**
     * Process a validated announcement. This involves capturing non validated emails extracted from user table 
     * and sending the emails.
     * @param announcement - Announcement
     * @param validatedEmails - List<String>
     * @throws EmailException  - MailException
     * @throws AnnouncementException - EmailException
     */
    private void process(final Announcement announcement, final List<String> validatedEmails) throws EmailException, AnnouncementException{
        
        String[] ccRef = specialCC == null ? new String[] { BudgesContext.getConfigService().getEmailTo() }
                : new String[] { BudgesContext.getConfigService().getEmailTo(), specialCC[0] };
                
        List<String> finalEmails = new ArrayList<>();
        if (validatedEmails.size() > 0){
            finalEmails.addAll(validatedEmails);
        }
        
        List<String> unvalidatedEmails = getUnvalidatedEmails(announcement);
        validateEmails(unvalidatedEmails);
        if (unvalidatedEmails.size() > 0){
            finalEmails.addAll(unvalidatedEmails);
        }
        
        if(!finalEmails.isEmpty() && finalEmails.get(0).equalsIgnoreCase(ccRef[0])) {
            finalEmails.remove(0);
        }
        
        try {
            
            EmailService emailService = BudgesContext.getEmailUtil();
            
        	String postalCode = emailService.sendEmail(announcement.getSenderEmail(),finalEmails.toArray(new String[0]), ccRef, 
                  announcement.getSubject(),announcement.getContent(), (announcement instanceof AnalystAnnouncement ? false : AnnouncementServiceImpl.APPEND_DEV_INFO), true);
        	if (null != postalCode) {
        	    emailService.sendFromPostalCode(postalCode);
        	}
        	
        }
        catch(EmailException me){
            log.error("AnnouncmentService email process failure",me);
            boolean recover = false;
            
            if (me.getCause() instanceof javax.mail.SendFailedException){
                SendFailedException sfe = (SendFailedException) me.getCause();
                try {
                    sendEmailErrorFollowUpMessage(sfe, announcement.getSubject(), ccRef);
                    recover = true;
                    log.error("A followup email was sent to R2Support to detail specific issues");
                }
                catch (EmailException ee){
                    log.error("Followup email failure",ee);
                    throw ee;
                }
            }
            
            if (recover){
                throw new AnnouncementException(AnnouncementServiceImpl.EMAIL_NOTIFY);
            }
            
            throw me;
            
        }
        catch(Exception e){
            log.error(e);
            throw new AnnouncementException(e.getMessage());
        }
    }
    
    /**
     * CXE-6516
     * Created a validator for emails retrieved from the database.
     * This may only be an issue in Staging where there were several bad emails,
     * causing the application to fail but without giving much information as to why,
     * or as to which user was causing the problem.
    */
    private void validateEmails(List<String> unvalidatedEmails) {
    	Iterator<String> iter = unvalidatedEmails.iterator();
		InternetAddress emailAddr;
    	while(iter.hasNext()) {
    		emailAddr = null;
    		String emailAddress = iter.next();
			try {
				emailAddr = new InternetAddress(emailAddress);
	            emailAddr.validate();
	            log.debug("Emails from the DB validated.");
			} catch (AddressException e) {
				iter.remove();
				List<BudgesUser> users = budgesUserDao.findAllActive(true, BudgesUser.ID);
				log.debug("The following email address was removed for invalid format: " + emailAddress);
				for(BudgesUser user : users) {
					if(user.getEmail().equalsIgnoreCase(emailAddress)) {
						log.debug("UserID: " + user.getId() + " Name: " + user.getFullName());
					}
				}
				
			}
    	}
	}

	/**
     * Send email for follow up after email exceptions are thrown. 
     * These will generally be emails that are no longer used in the application, 
     * but still in the user table.
     * @param sfe - SendFailedException
     * @param emailSubject - String
     * @param ccRef - String[1]
     * @throws EmailException - EmailException
     */
    private void sendEmailErrorFollowUpMessage(final SendFailedException sfe, final String emailSubject, final String[] ccRef) throws EmailException{
        String title = String.format("Email Send Failed Exception: (%s) : Email Announcement Center", sfe.getMessage());
        StringBuilder content = new StringBuilder(String.format("Email send error failures wrt following subject line: %s",emailSubject));
        AnnouncmentExceptionContentManager.buildOutContent(sfe, content);
        BudgesContext.getEmailUtil().sendEmail(ccRef[0],ccRef, ccRef,title,content.toString(), AnnouncementServiceImpl.APPEND_DEV_INFO);
    }
    

    /**
     * get email addresses specific to audience from database.
     * @param announcement - Announcement
     * @return unvalidatedEmails - List<String>
     */
    private List<String> getUnvalidatedEmails(final Announcement announcement){
        
        List<String> unvalidatedEmails = new ArrayList<>();
        List<BudgesUser> activeUsers = budgesUserDao.findAllActive(true, BudgesUser.ID);
        
        switch (announcement.getAudience()){
            
            case NONE:
                break;
            case ALL_ADMIN:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_SITEADMIN) ||user.getRole().equals(LdapDAO.GROUP_R2_LOCALSITEADMIN)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case SITE_ADMIN:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_SITEADMIN)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case LOCAL_SITE_ADMIN:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_LOCALSITEADMIN)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case ANALYST:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_ANALYST)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case USER:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_USER)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case APP_MANAGER:
                for (BudgesUser user : activeUsers){
                    if (user.getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN)){
                        unvalidatedEmails.add(user.getEmail());
                    }
                }
                break;
            case ALL:
                for (BudgesUser user : activeUsers){
                    unvalidatedEmails.add(user.getEmail());
                }
                break;
            default:
                break;
        }
        
        return unvalidatedEmails;
     
    }    
}
    
