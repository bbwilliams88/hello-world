/*
 * $Id: BudgesHttpSessionListener.java 35866 2010-01-11 18:22:24Z aahmed $
 */
package mil.dtic.utility;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.logging.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import mil.dtic.cbes.service.HttpSessionService;

public class BudgesHttpSessionListener3 implements HttpSessionListener
{
  private static final Logger log = CbesLogFactory.getLog(BudgesHttpSessionListener3.class);


  private HttpSessionService getService(ServletContext sc)
  {
    WebApplicationContext spring =
      WebApplicationContextUtils.getWebApplicationContext(sc);
    return spring.getBean(HttpSessionService.class);
  }

  @Override
public void sessionCreated(HttpSessionEvent event)
  {
		log.debug("Budges HTTP session created, id=" + event.getSession().getId() + ", source=" + event.getSource());
		HttpSessionService service = getService(event.getSession().getServletContext());
		service.sessionCreated(event.getSession().getId());
  }

  @Override
public void sessionDestroyed(HttpSessionEvent event)
  {
    log.debug("Budges HTTP session about to be destroyed, id=" + event.getSession().getId() +", source=" + event.getSource());
  }

  /*
  public String getHttpSessionList()
  {
    //Get only the host specific version, creating if necessary
    Config c = findByName(HTTP_SESSION_LIST);
    if (c == null || UNASSIGNED_HOST.equals(c.getHostName()))
      throw new RuntimeException("Host-specific version not found - " + HTTP_SESSION_LIST);
    return c.getValue();
  }

  public void saveClearedHttpSessionList()
  {
    Config c = findByName(HTTP_SESSION_LIST);
    if (c == null || UNASSIGNED_HOST.equals(c.getHostName()))
      throw new RuntimeException("Host-specific version not found - " + HTTP_SESSION_LIST);
    c.setValue("");
    saveOrUpdate(c);
  }

  // don't call createHttpSessionList and addToHttpSessionList outside of a service, they don't start with the word "save"

  public void createHttpSessionList() throws UnknownHostException
  {
    //Create host-specific version if necessary
    Config c = findByName(HTTP_SESSION_LIST);
    if (c == null || UNASSIGNED_HOST.equals(c.getHostName())) {
      c = new Config();
      c.setName(HTTP_SESSION_LIST);
      c.setValue("");
      c.setValueType(ConfigTypeFlag.STRING);
      c.setDescription("List of active http sessions maintained by each server");
      c.setHostName(InetAddress.getLocalHost().getHostName());
      saveOrUpdate(c);
    }
  }

  private void lockAndReread(Config c)
  {
    //lock the row
    hqlUpdate("update Config set readOnly=? where name=? and hostName=?", !c.getReadOnly(), c.getName(), c.getHostName());
    //reread in case it changed in the past few ms
    getSession().refresh(c);
  }

  public void addToHttpSessionList(String sessionId)
  {
    Config c = findByName(HTTP_SESSION_LIST);
    if (c == null || UNASSIGNED_HOST.equals(c.getHostName()))
      throw new RuntimeException("Host-specific version not found - " + HTTP_SESSION_LIST);
    lockAndReread(c);
    //update it
    c.setValue(c.getValue() + " " + sessionId); //it's a space-delimited list
    saveOrUpdate(c); //save changes
  }

  public void removeFromHttpSessionList(String sessionId)
  {
    Config c = findByName(HTTP_SESSION_LIST);
    if (c == null || UNASSIGNED_HOST.equals(c.getHostName()))
      throw new RuntimeException("Host-specific version not found - " + HTTP_SESSION_LIST);
    lockAndReread(c);
    String value = c.getValue();
    //remove from list
    value = value.replace(" " + sessionId, sessionId); //this assumes there's always a space before it
    c.setValue(value);
    saveOrUpdate(c);
  }
   */

  /*
  <!-- http session service -->
  <bean id="HttpSessionService" class="org.springframework.transaction.interceptor.TransactionProxyFactoryBean">
    <property name="transactionManager" ref="transactionManager" />
    <property name="transactionAttributes" value="*=PROPAGATION_REQUIRES_NEW" />
    <property name="preInterceptors">
      <bean class="org.springframework.orm.hibernate3.HibernateInterceptor">
        <property name="sessionFactory" ref="sessionFactory" />
      </bean>
    </property>
    <property name="target">
      <bean class="mil.dtic.cbes.service.HttpSessionService">
        <property name="configDAO" ref="ConfigDAO" />
      </bean>
    </property>
  </bean>
   */
}
