package mil.dtic.utility.aop;

import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import mil.dtic.utility.CbesLogFactory;

@Aspect
public class CxeAspect {
    private static final Logger log = CbesLogFactory.getLog(CxeAspect.class);
    
    @Around("execution(* mil.dtic.utility.samanage.service.api.AdminService.*(..))")
    public Object onAroundAdminService(ProceedingJoinPoint joinPoint) throws Throwable {
        Object o = null;
        String execution = joinPoint.toShortString();
        long start = System.currentTimeMillis();
        
        try {
            o = joinPoint.proceed();
        }
        catch(Throwable t) {
            log.error("onAroundAdminService- execution:"+execution+" failure msg: "+t.getMessage());
        }
        
        log.info(String.format("### %s execution time: %s ms", execution, System.currentTimeMillis() - start));
        
        return o;
    }

    @Around("execution(* mil.dtic.cbes.submissions.dao.*.*(..))")
    public Object onAroundSubmissionDAO(ProceedingJoinPoint joinPoint) throws Throwable {
        Object o = null;
        String execution = joinPoint.toShortString();
        long start = System.currentTimeMillis();
        
        try {
            o = joinPoint.proceed();
        }
        catch(Throwable t) {
        	log.error("onAroundAdminService- execution:"+execution+" failure msg: "+t.getMessage());
        }
        
        log.info(String.format("### %s execution time: %s ms", execution, System.currentTimeMillis() - start));
        return o;
    }

    @Around("execution(* mil.dtic.cbes.submissions.service.*.*(..))")
    public Object onAroundSubmissionService(ProceedingJoinPoint joinPoint) throws Throwable {
        Object o = null; 
        String execution = joinPoint.toShortString();
        long start = System.currentTimeMillis();
        try {
            o = joinPoint.proceed();
        }
        catch(Throwable t) {
        	log.error("onAroundAdminService- execution:"+execution+" failure msg: "+t.getMessage());
        }
        log.info(String.format("### %s execution time: %s ms", execution, System.currentTimeMillis() - start));
        return o;
    }

}
