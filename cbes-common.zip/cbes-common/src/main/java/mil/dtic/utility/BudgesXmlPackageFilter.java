package mil.dtic.utility;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.ls.LSInput;

public class BudgesXmlPackageFilter implements Filter
{
  private static final Logger log = CbesLogFactory.getLog(BudgesXmlPackageFilter.class);


  @Override
  public void init(FilterConfig filterConfig) throws ServletException
  {
    log.debug("BudgesXmlPackageFilter initialized.");
  }


  @Override
  public void destroy()
  {
    log.debug("BudgesXmlPackageFilter destroyed.");
  }


  /**
   * Intercept requests for the Comptroller XML Package resources and serve them
   * directly from the base directory in which the package file was unzipped.
   */
  @Override
  public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException
  {
    HttpServletRequest httpReq = (HttpServletRequest) req;
    String path = httpReq.getServletPath();
    log.debug("About to stream Compgtroller XML Package resource " + path);
    String[] pathParts = path.split("/xmlpackage");
    if (pathParts.length == 2)
    {
      path = pathParts[1];
      // Remove all chars except alphas plus underscore. 
      path = FilenameUtils.normalize(path.replaceAll("[^a-zA-Z0-9_\\\\/\\.]", ""));
      BudgesXmlSchemaResourceResolver xmlResourceResolver = BudgesContext.getBudgesXmlResourceResolverFactory().getSchemaResourceResolver();
      LSInput lsInput = xmlResourceResolver.resolveResource(path);
      InputStream resourceInputStream = null;
      try 
      {
        if (lsInput != null && (resourceInputStream = lsInput.getByteStream()) != null)
        {
          HttpServletResponse httpResp = (HttpServletResponse) resp;
          IOUtils.copy(resourceInputStream, httpResp.getOutputStream());
        }
      } 
      finally
      {
        if (resourceInputStream!=null)
        {
          resourceInputStream.close();
        }
      }     
    }
  }

}
