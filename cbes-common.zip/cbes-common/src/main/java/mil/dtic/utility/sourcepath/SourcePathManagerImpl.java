package mil.dtic.utility.sourcepath;

import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import mil.dtic.utility.CbesLogFactory;

// SourcePathManager is a helper utility that lets R2 know if a method call came from P40 and if so from where.
@Component
public class SourcePathManagerImpl implements SourcePathManager{
    private static final Logger LOG = CbesLogFactory.getLog(SourcePathManagerImpl.class);
    public static final String P40_ADMINTOOLS = "admintools";
    public static final String P40_ADMINTOOLS_PATH = "/p40/admintools";
    public static final String P40_ADMINTOOLS_LABEL = "Return P40 Admin Tools";
    public static final String P40_HOME = "p40";
    public static final String P40_HOME_PATH = "/p40/";
    public static final String P40_HOME_LABEL = "Return to Procurement Home Page";
    public static final String R2_HOME_PATH = "/r2/";
    public static final String R2_HOME_LABEL = "Return to RDT&E Home Page";
    

    @Override
    public void createSource(SourcePath sourcePath) {
        String path = sourcePath.getSourcePath();
        LOG.debug("createSource: path=" + path);
        if (path.equals(SourcePathManagerImpl.P40_ADMINTOOLS)) {
            sourcePath.setSourceUrl(SourcePathManagerImpl.P40_ADMINTOOLS_PATH);
            sourcePath.setReturnLabel(SourcePathManagerImpl.P40_ADMINTOOLS_LABEL);
        } else if (path.equals(SourcePathManagerImpl.P40_HOME)) {
            sourcePath.setSourceUrl(SourcePathManagerImpl.P40_HOME_PATH);
            sourcePath.setReturnLabel(SourcePathManagerImpl.P40_HOME_LABEL);
        } else {
            sourcePath.setSourceUrl(SourcePathManagerImpl.R2_HOME_PATH);
            sourcePath.setReturnLabel(SourcePathManagerImpl.R2_HOME_LABEL);
        }

        if (sourcePath.getSourceUrl() != null) {
            sourcePath.setHasPath(true);
        }

        LOG.debug("createSource: sourceUrl: " + sourcePath.getSourceUrl());
    }


}
