package mil.dtic.utility;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.constants.FileType;

/**
 * Used to construct sanitized filenames of known types.
 */
public class FileName
{
    private final String   fileName;
    private final FileType fileType;

    /**
     * Constructs a sanitized file name composed of the base file name and the
     * extension (type).
     *
     * @param baseFileName The base (no extension) file name.
     * @param fileType The type of file.
     */
    public FileName(String baseFileName, FileType fileType)
    {
        this(new String[]{ baseFileName }, fileType);
    }

    /**
     * Constructs a sanitized file name composed of the components, separated by
     * underscores ("_") and the extension (type).
     *
     * @param baseFileNames
     *            List of String file name components.
     * @param fileType
     *            The type of file.
     */
    public FileName(List<String> baseFileNames, FileType fileType)
    {
        this(baseFileNames.toArray(new String[baseFileNames.size()]), fileType);
    }

    /**
     * Constructs a sanitized file name composed of the components, separated by
     * underscores ("_") and the extension (type).
     *
     * @param baseFileNames
     *            Array of String file name components.
     * @param fileType
     *            The type of file.
     */
    public FileName(String baseFileNames[], FileType fileType)
    {
        StringBuilder fileName = new StringBuilder();

        for (int i = 0; i < baseFileNames.length; i++)
        {
            if (i != 0)
                fileName.append("_");

            fileName.append(CBESFilenameUtils.sanitizeFileName(baseFileNames[i]));
        }

        if (StringUtils.isNotBlank(fileType.getExtension()))
            fileName.append(".").append(fileType.getExtension());

        this.fileName = fileName.toString();
        this.fileType = fileType;
    }

    /**
     * @return The sanitized filename with appropriate extension.
     */
    public String getFileName()
    {
        return fileName;
    }

    /**
     * @return The file's type (from which extension and MIME type can be
     *         obtained).
     */
    public FileType getFileType()
    {
        return fileType;
    }
}
