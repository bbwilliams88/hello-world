/*
 * $Id: BudgesFileSystemResourceResolver.java $
 */
package mil.dtic.utility;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.ls.LSInput;

public class BudgesDatabaseXmlSchemaResourceResolver extends BudgesXmlSchemaResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesDatabaseXmlSchemaResourceResolver.class);


  public BudgesDatabaseXmlSchemaResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public LSInput resolveResource(String type, String namespaceURI, String publicId, String systemId, String baseURI)
  {
    log.trace("Looking for database LSResource, type: " + type +
      ", namespaceURI: " + namespaceURI +
      ", publicId: " + publicId +
      ", systemId: " + systemId +
      ", baseURI: " + baseURI);
    // TODO
    throw new RuntimeException("Database XML Schema Resource Resolver not implemented!");
  }


}
