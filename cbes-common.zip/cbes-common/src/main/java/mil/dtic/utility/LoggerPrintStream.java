package mil.dtic.utility;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.apache.logging.log4j.Logger;

/*
 * PrintStream which forwards log messages to the logger.  Class
 * is needed to maintain backwards compatibility with
 * RemoteServer.{set|get}Log().
 */
public class LoggerPrintStream extends PrintStream {

  /** logger where output of this log is sent */
  private static final Logger log = CbesLogFactory.getLog(LoggerPrintStream.class);

  /** record the last character written to this stream */
  private int last = -1;

  /** stream used for buffering lines */
  private final ByteArrayOutputStream bufOut;

  public LoggerPrintStream()
  {
    super(new ByteArrayOutputStream());
    bufOut = (ByteArrayOutputStream) super.out;
  }

  public void write(int b) {
    if ((last == '\r') && (b == '\n')) {
      last = -1;
      return;
    } else if ((b == '\n') || (b == '\r')) {
      try {
        /* write the converted bytes of the log message */
        String message =
          Thread.currentThread().getName() + ": " +
          bufOut.toString();
        log.debug(message);
      } finally {
        bufOut.reset();
      }
    } else {
      super.write(b);
    }
    last = b;
  }

  public void write(byte b[], int off, int len) {
    if (len < 0) {
      throw new ArrayIndexOutOfBoundsException(len);
    }
    for (int i = 0; i < len; i++) {
      write(b[off + i]);
    }
  }

  public String toString() {
    return "RMI";
  }
}