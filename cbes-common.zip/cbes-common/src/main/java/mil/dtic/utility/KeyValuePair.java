/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.p40.vo.IBase;

public class KeyValuePair implements IBase, Serializable
{
  private static final long serialVersionUID = 1L;

  private String key;
  private String value;
  private String t5Id;


  public KeyValuePair()
  {
    super();
  }


  public boolean isEmpty()
  {
    return StringUtils.isEmpty(key) && StringUtils.isEmpty(value);
  }

  public KeyValuePair(String key, String value)
  {
    super();
    this.key = key;
    this.value = value;
  }


  public String getKey()
  {
    return key;
  }


  public void setKey(String key)
  {
    this.key = key;
  }


  public String getValue()
  {
    return value;
  }


  public void setValue(String value)
  {
    this.value = value;
  }

  public String getT5Id()
  {
    return t5Id;
  }


  public void setT5Id(String t5Id)
  {
    this.t5Id = t5Id;
  }


  @Override
public String toString()
  {
    return "(" + key + ":" + value + ")";
  }


  @Override
  public Integer getId()
  {
    return null;
  }
}
