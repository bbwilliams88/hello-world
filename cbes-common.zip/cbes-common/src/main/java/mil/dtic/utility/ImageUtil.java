/*
 * $Id$
 */
package mil.dtic.utility;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.PNGEncodeParam;
import com.sun.media.jai.codec.TIFFDecodeParam;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Constants.JBLogoImageFileType;

public class ImageUtil
{
  private static final Logger log = CbesLogFactory.getLog(ImageUtil.class);


  public static boolean validateFileExtension(String fileName)
  {
    if (fileName==null) throw new IllegalArgumentException("ImageUtil");
    String fileExt = CBESFilenameUtils.getExtension(fileName);
    JBLogoImageFileType ext = JBLogoImageFileType.valueOf(fileExt.toUpperCase());
    return (ext != null);
  }
  
  

  public static boolean validateImageFile(File imageFile)
  {
    boolean success = true;

    Iterator<ImageReader> imageReaders = null;
    ImageReader imageReader = null;
    BufferedInputStream bis = null;
    ImageInputStream iis = null;
    try
    {

      // check the extension-- if fails, an IllegalArgumentException exception
      // is thrown
      String fileExt = CBESFilenameUtils.getExtension(imageFile.getAbsolutePath());
      Constants.JBLogoImageFileType.valueOf(fileExt.toUpperCase());

      // extension was good, now check contents of image file-- JDK supports
      // most of the basic ones except tif
      imageReaders = ImageIO.getImageReadersByFormatName(fileExt);
      imageReader = imageReaders.hasNext() ? (ImageReader) imageReaders.next() : null;
      if (imageReader != null)
      {
        bis = new BufferedInputStream(new FileInputStream(imageFile.getAbsolutePath()));
        iis = ImageIO.createImageInputStream(bis);
        imageReader.setInput(iis, true);
        int h = imageReader.getHeight(0);
        int w = imageReader.getWidth(0);
        int n = imageReader.getNumImages(false);
        log.debug("Image is valid, file info (file/num images/height/width): " + imageFile.getAbsolutePath() + "/" + n + "/" + h + "/" + w);
      } else {
        log.debug("No image reader to validate with found. Probably a tiff.");
      }
    }
    catch (IOException e)
    {
      log.debug("Failed to access image file " + imageFile.getAbsolutePath(), e);
      success = false;
    }
    catch (IllegalArgumentException e)
    {
      log.debug("This is not a valid image file because it does not have the correct extension: " + imageFile.getAbsolutePath());
      success = false;
    }
    finally
    {
      if (imageReader != null)
        imageReader.dispose();
      FileUtil.close(iis);
      FileUtil.close(bis);
    }

    return success;
  }


  /**
   * Convenience method that returns a scaled instance of the provided {@code
   * BufferedImage}.
   * 
   * @param img
   *          the original image to be scaled
   * @param targetWidth
   *          the desired width of the scaled instance, in pixels
   * @param targetHeight
   *          the desired height of the scaled instance, in pixels
   * @param hint
   *          one of the rendering hints that corresponds to {@code
   *          RenderingHints.KEY_INTERPOLATION} (e.g. {@code
   *          RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR}, {@code
   *          RenderingHints.VALUE_INTERPOLATION_BILINEAR}, {@code
   *          RenderingHints.VALUE_INTERPOLATION_BICUBIC})
   * @param higherQuality
   *          if true, this method will use a multi-step scaling technique that
   *          provides higher quality than the usual one-step technique (only
   *          useful in downscaling cases, where {@code targetWidth} or {@code
   *          targetHeight} is smaller than the original dimensions, and
   *          generally only when the {@code BILINEAR} hint is specified)
   * @return a scaled version of the original {@code BufferedImage} Credit:
   *         http://today.java.net/pub/a/today/2007/04/03/perils-of-image-
   *         getscaledinstance.html
   */
  public static BufferedImage getScaledInstance(BufferedImage img, int targetWidth, int targetHeight, Object hint, boolean higherQuality)
  {
    int type = (img.getTransparency() == Transparency.OPAQUE) ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
    BufferedImage ret = (BufferedImage) img;
    int w, h;
    if (higherQuality)
    {
      // Use multi-step technique: start with original size, then
      // scale down in multiple passes with drawImage()
      // until the target size is reached
      w = Math.max(img.getWidth(), targetWidth);
      h = Math.max(img.getHeight(), targetHeight);
    }
    else
    {
      // Use one-step technique: scale directly from original
      // size to target size with a single drawImage() call
      w = targetWidth;
      h = targetHeight;
    }

    do
    {

      if (higherQuality && w > targetWidth)
      {
        w /= 2;
        if (w < targetWidth)
        {
          w = targetWidth;
        }
      }

      if (higherQuality && h > targetHeight)
      {
        h /= 2;
        if (h < targetHeight)
        {
          h = targetHeight;
        }
      }

      BufferedImage tmp = new BufferedImage(w, h, type);
      Graphics2D g2 = tmp.createGraphics();
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
      g2.drawImage(ret, 0, 0, w, h, null);
      g2.dispose();

      ret = tmp;
    } while (w != targetWidth || h != targetHeight);

    return ret;
  }
  
  /** scale to width while preserving aspect ratio */
  public static BufferedImage scaleToWidth(BufferedImage img, int width)
  {
    if (img.getWidth() <= width) return img;
    int x = width;
    int y = (int)(img.getHeight() / (img.getWidth()/(float)x));
    return ImageUtil.getScaledInstance(img, x, y, RenderingHints.VALUE_INTERPOLATION_BICUBIC, true);
  }
  
  
  /** Convert tiff to png using JAI */
  public static byte[] getPngFromTiff(InputStream tis) throws IOException
  {
    try
    {
      log.debug("getPngFromTiff start");
      ImageDecoder id = ImageCodec.createImageDecoder("tiff", tis, new TIFFDecodeParam());
      RenderedImage ri = id.decodeAsRenderedImage();
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ImageEncoder ie = ImageCodec.createImageEncoder("png", baos, PNGEncodeParam.getDefaultEncodeParam(ri));
      ie.encode(ri);
      baos.flush();
      log.debug("getPngFromTiff copying");
      byte[] result = baos.toByteArray();
      log.debug("getPngFromTiff end");
      FileUtil.close(baos);
      return result;
    }
    finally
    {
      FileUtil.close(tis);
    }
  }
  
  public static boolean isTiff(String filename)
  {
    return StringUtils.endsWith(filename.toLowerCase(), "tif");
  }
  

  public static byte[] getPngThumbnail(InputStream is, String filename) throws IOException
  {
    ByteArrayOutputStream baos = null;
    try
    {
      if (isTiff(filename))
      { // overwrite inputstream with png version
        byte[] png = getPngFromTiff(is);
        is = new ByteArrayInputStream(png);
      }
      BufferedImage big = ImageIO.read(is);
      BufferedImage thumb = ImageUtil.scaleToWidth(big, 200);
      baos = new ByteArrayOutputStream(32768);
      ImageIO.write(thumb, "png", baos);
      byte[] thumbnail = baos.toByteArray();
      return thumbnail;
    }
    finally
    {
      FileUtil.close(is);
      FileUtil.close(baos);
    }
  }
}
