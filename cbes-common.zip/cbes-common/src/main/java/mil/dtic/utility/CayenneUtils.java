package mil.dtic.utility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.cayenne.Cayenne;
import org.apache.cayenne.CayenneDataObject;
import org.apache.cayenne.DataRow;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.PersistenceState;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.ObjectStore;
import org.apache.cayenne.configuration.Constants;
import org.apache.cayenne.configuration.server.ServerRuntime;
import org.apache.cayenne.di.Binder;
import org.apache.cayenne.di.Module;
import org.apache.cayenne.map.ObjAttribute;
import org.apache.cayenne.util.Util;

/**
 * Cayenne utility methods.
 */
public class CayenneUtils
{
    private static ServerRuntime runtime     = null;
    private static Lock          runtimeLock = new ReentrantLock();

    /**
     * Custom Cayenne Module to add to the ServerRuntime.
     */
    private static class CayenneModule implements Module
    {
        @Override
        public void configure(Binder binder)
        {
            // Turn off DataContext synchronization.
            binder.bindMap(Constants.PROPERTIES_MAP).put(Constants.SERVER_CONTEXTS_SYNC_PROPERTY, "false");
        }
    }

    /**
     * @return The current Cayenne ServerRuntime. If this hasn't been created
     *         yet, will automatically create one.
     */
    public static ServerRuntime getRuntime()
    {
        try
        {
            runtimeLock.lock();

            // FIXME: When Spring goes away, remove this auto-creation feature
            // and allow the creation to be done externally and rely on that
            // external creation to call setRuntime(), such as from Tapestry's
            // AppModule @Startup.
            if (runtime == null)
                runtime = new ServerRuntime("cayenne-procurement.xml", new CayenneModule());

            return runtime;
        }
        finally
        {
            runtimeLock.unlock();
        }
    }

    /**
     * Sets the Cayenne ServerRuntime to the supplied value. This allows for a
     * non-default runtime to be created and used (such as for unit testing).
     *
     * @param serverRuntime The ServerRuntime instance to use.
     */
    public static void setRuntime(ServerRuntime serverRuntime)
    {
        try
        {
            runtimeLock.lock();

            runtime = serverRuntime;
        }
        finally
        {
            runtimeLock.unlock();
        }
    }

    /**
     * Shuts down the current Cayenne ServerRuntime.
     */
    public static void shutdownRuntime()
    {
        try
        {
            runtimeLock.lock();

            if (runtime != null)
            {
                runtime.shutdown();
                runtime = null;
            }
        }
        finally
        {
            runtimeLock.unlock();
        }
    }

    /**
     * Cayenne 3.0 -> 3.1 changes the way a DataContext is created.  This
     * method acts as a bridge between the two versions.  All code should
     * use this method to ease upgrading to 3.1 in the future.
     *
     * @return A new DataContext.
     */
    public static DataContext createDataContext()
    {
        return (DataContext) getRuntime().getContext();
    }

    public static DataContext createChildDataContext(DataContext dataContext)
    {
        return (DataContext) getRuntime().getContext(dataContext);
    }

//    public static ObjectContext createChildObjectContext(ObjectContext objectContext)
//    {
//        return (DataContext) getRuntime().getContext(objectContext);
//    }

    /**
     * Copies a Cayenne object into a data context.
     *
     * @param cayenneObject
     *            The Cayenne object to copy.
     * @param objectContext
     *            The object context to copy cayenneObject into.
     * @return A copy of the object associated with the supplied data context.
     */
    public static <T extends CayenneDataObject> T copyToContext(T cayenneObject, ObjectContext objectContext)
    {
        // FIXME: This use of localObject() is deprecated and will vanish.
        // Unfortunately, it is used by the validation system to create copies
        // of objects (and their values) in micro-contexts for some reason. The
        // new Cayenne localObject() does not work with NEW objects and does not
        // copy values, which breaks validation. One possible validation
        // alternative is to create child contexts instead of peer contexts.
        // Cayenne will correctly handle NEW objects and copy values in this
        // scenario. Unsure about memory issues with that approach currently
        // (eg, will the child contexts pile up instead of be GC'ed). An
        // even better solution is to FIX the validation system to not create
        // new micro-contexts and use the original objects for validation
        // instead of copying objects.
//        T copiedObject = (T) objectContext.localObject(cayenneObject.getObjectId(), cayenneObject);
        T copiedObject = null;

        // The returned copy is HOLLOW.  Make the copy NEW if the original is NEW.
        if (cayenneObject.getPersistenceState() == PersistenceState.NEW)
            copiedObject.setPersistenceState(PersistenceState.NEW);

        return copiedObject;
    }

    /**
     * Determine if there are in relevant changes in the data context. Does a
     * deep introspection instead of the shallow introspection of Cayenne's
     * hasChanges() method.  Phantom changes are ignored.
     *
     * @param dataContext
     *            The data context to check for changes.
     * @return True if there are changes (the context is dirty), false if the
     *         context is clean.
     */
    public static boolean isDirty(DataContext dataContext)
    {
        // If there are any new objects, the context is dirty.
        if (newObjects(dataContext).size() > 0)
            return true;

        // If there are any deleted objects, the context is dirty.
        if (deletedObjects(dataContext).size() > 0)
            return true;

        // Need the object store to access the snapshot data.
        ObjectStore objectStore = dataContext.getObjectStore();

        // Loop over all 'modified' objects and compare snapshot data to current data.
        for (CayenneDataObject modifiedObject : modifiedObjects(dataContext))
        {
            // Get the snapshot data.
            DataRow dataRow = objectStore.getSnapshot(modifiedObject.getObjectId());

            // Loop over all the attributes to compare data.
            for (ObjAttribute attribute : Cayenne.getObjEntity(modifiedObject).getAttributes())
            {
                // If the snapshot data matches the current data, continue.
                if (Util.nullSafeEquals(dataRow.get(attribute.getDbAttributeName()), modifiedObject.readPropertyDirectly(attribute.getName())))
                    continue;

                // Object is dirty, abort all other comparisons.
                return true;
            }
        }

        // The context is clean.
        return false;
    }

    /**
     * Prints (to standard output) all relevant changes in a data context.
     * Useful for debugging.
     *
     * @param dataContext
     *            The data context examine to print changes.
     */
    public static void printDirty(DataContext dataContext)
    {
        // Print all new objects.
        for (CayenneDataObject newObject : newObjects(dataContext))
            System.out.printf("Persistent Object [%s]: New Object\n", newObject.getObjectId());

        // Print all deleted objects.
        for (CayenneDataObject newObject : deletedObjects(dataContext))
            System.out.printf("Persistent Object [%s]: Deleted Object\n", newObject.getObjectId());

        // Need the object store to access the snapshot data.
        ObjectStore objectStore = dataContext.getObjectStore();

        // Loop over all modified objects and print snapshot data versus current data.
        for (CayenneDataObject modifiedObject : modifiedObjects(dataContext))
        {
            // Get the snapshot data.
            DataRow dataRow = objectStore.getSnapshot(modifiedObject.getObjectId());

            // Loop over all the attributes to compare data.
            for (ObjAttribute attribute : Cayenne.getObjEntity(modifiedObject).getAttributes())
            {
                String dbAttributeName  = attribute.getDbAttributeName();
                String objAttributeName = attribute.getName();

                // If the snapshot data matches the current data, continue.
                if (Util.nullSafeEquals(dataRow.get(dbAttributeName), modifiedObject.readPropertyDirectly(objAttributeName)))
                    continue;

                // Print the change.
                System.out.printf("Persistent Object [%s]: Attribute [%s] changed from [%s] to [%s]\n",
                                  modifiedObject.getObjectId(),
                                  dbAttributeName,
                                  dataRow.get(dbAttributeName),
                                  modifiedObject.readPropertyDirectly(objAttributeName));
            }
        }
    }

    /**
     * Helper method to return the collection of deleted objects as
     * CayenneDataObject instead of Object, which is what the standard Cayenne
     * API returns.
     *
     * @param dataContext
     *            The data context to locate deleted objects.
     * @return A collection of CayenneDataObjects to be deleted.
     */
    public static Collection<? extends CayenneDataObject> deletedObjects(DataContext dataContext)
    {
        return objectsInState(dataContext, PersistenceState.DELETED);
    }

    /**
     * Helper method to return the collection of modified objects as
     * CayenneDataObject instead of Object, which is what the standard Cayenne
     * API returns.
     *
     * @param dataContext
     *            The data context to locate modified objects.
     * @return A collection of CayenneDataObjects which are modified (includes phantom modifications).
     */
    public static Collection<? extends CayenneDataObject> modifiedObjects(DataContext dataContext)
    {
        return modifiedObjects(dataContext, true);
    }

    /**
     * Helper method to return the collection of modified objects as
     * CayenneDataObject instead of Object, which is what the standard Cayenne
     * API returns.
     *
     * @param dataContext
     *            The data context to locate modified objects.
     * @param includePhantomModifications
     *            Flag to control if phantom modifications should be included.
     * @return A collection of CayenneDataObjects which are modified.
     */
    public static Collection<? extends CayenneDataObject> modifiedObjects(DataContext dataContext, boolean includePhantomModifications)
    {
        // If including phantom modifications, life is simpler.
        if (includePhantomModifications)
            return objectsInState(dataContext, PersistenceState.MODIFIED);

        // Otherwise, evaluate all the 'modified' objects and inspect them for actual changes,
        // collecting those that are actually modified.
        List<CayenneDataObject> modifiedObjects = new ArrayList<CayenneDataObject>();

        // Need the object store to access the snapshot data.
        ObjectStore objectStore = dataContext.getObjectStore();

        // Loop over all modified objects and print snapshot data versus current data.
        for (CayenneDataObject modifiedObject : objectsInState(dataContext, PersistenceState.MODIFIED))
        {
            // Get the snapshot data.
            DataRow dataRow = objectStore.getSnapshot(modifiedObject.getObjectId());

            // Loop over all the attributes to compare data.
            for (ObjAttribute attribute : Cayenne.getObjEntity(modifiedObject).getAttributes())
            {
                String dbAttributeName  = attribute.getDbAttributeName();
                String objAttributeName = attribute.getName();

                // If the snapshot data matches the current data, continue the search.
                if (Util.nullSafeEquals(dataRow.get(dbAttributeName), modifiedObject.readPropertyDirectly(objAttributeName)))
                    continue;

                // Object is modified, collect it.
                modifiedObjects.add(modifiedObject);

                // Break out of this loop since we know the object is modified.
                break;
            }
        }

        return modifiedObjects;
    }

    /**
     * Helper method to return the collection of new objects as
     * CayenneDataObject instead of Object, which is what the standard Cayenne
     * API returns.
     *
     * @param dataContext
     *            The data context to locate new objects.
     * @return A collection of CayenneDataObjects to be inserted.
     */
    public static Collection<? extends CayenneDataObject> newObjects(DataContext dataContext)
    {
        return objectsInState(dataContext, PersistenceState.NEW);
    }

    /**
     * Helper method to return a collection of CayenneDataObjects instead of
     * Persistent, which is what the standard Cayenne API returns.
     *
     * @param dataContext
     *            The data context to locate new objects.
     * @param persistenceState
     *            The state of the objects in question (from PersistenceState).
     * @return A collection of CayenneDataObjects matching the given state.
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static Collection<? extends CayenneDataObject> objectsInState(DataContext dataContext, int persistenceState)
    {
        return new ArrayList(dataContext.getObjectStore().objectsInState(persistenceState));
    }

    /**
     * @param objects
     *            List of Cayenne objects.
     * @return A list of integers that are the primary keys of the Cayenne
     *         objects. Only works for collections of Cayenne objects with a
     *         single integer primary key.
     */
    public static List<Integer> pksForObjects(List<? extends CayenneDataObject> objects)
    {
        List<Integer> results = new ArrayList<Integer>();

        if (objects != null)
            for (CayenneDataObject object : objects)
                results.add(Integer.valueOf(Cayenne.intPKForObject(object)));

        return results;
    }
}
