/*
 * $Id: UserPeUtils.java 34111 2009-11-23 12:44:31Z aahmed $
 */
package mil.dtic.utility;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;

public class UserPeUtils
{
  private static final Logger log = CbesLogFactory.getLog(UserPeUtils.class);
  
	private UserPeUtils() {}
  
  public static void grantPermsForNewPe(BudgesUser b, ProgramElement pe) {
    grantEditPerm(b, pe);
  }
  
  public static void grantPermsForNewPe(UserCredentials creatorCreds, ProgramElement pe) {
    if (creatorCreds.checkPrivilege(Privilege.DISABLE_SET_PERM_ON_CREATEPE)) return;
    //grant for creating user
    grantEditPerm(creatorCreds.getUserInfo().getBudgesUser(), pe);
  }
  
  private static void grantEditPerm(BudgesUser user, ProgramElement pe) {
    BudgesUserAndProgramElementLink perm =
      BudgesUserAndProgramElementLink.createTransient(user, pe);
    perm.setView(true);
    perm.setEdit(true);
    BudgesContext.getBudgesUserAndProgramElementLinkDAO().saveOrUpdate(perm);
  }
}