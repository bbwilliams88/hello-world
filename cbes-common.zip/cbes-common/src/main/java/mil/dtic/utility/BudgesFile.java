/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.File;

public class BudgesFile implements Comparable<BudgesFile>
{
  protected String title;
  protected String originalName;
  protected File virusScanFile;
  protected File file;
  protected BudgesFile zipSource; //if this file was unzipped this will store the zip file which was it's source. this is a renamed version of the parent

  public BudgesFile()
  {
    this(null, null);
  } 
  
  public BudgesFile(String originalName, File file)
  {
    this.setOriginalName(originalName);
    this.setFile(file);
  }
  public BudgesFile(String originalName, File file, BudgesFile zipSource)
  {
    this(originalName, file);
    this.setZipSource(zipSource);
  }

  public BudgesFile(String originalName, File file, File virusScanFile, BudgesFile zipSource)
  {
    this(originalName, file, zipSource);
    this.setVirusScanFile(virusScanFile);
  }

  public BudgesFile(String originalName, File file, File virusScanFile, BudgesFile zipSource, String title)
  {
    this(originalName, file, virusScanFile, zipSource);
    this.setTitle(title);
  }
  
  /**
   * Implementation of compareTo.  Uses the values of the file names to do the comparison.
   * 
   * @param budgesFile The other file to compare to THIS one.
   * @return Compares the value of the file name, returning the same as the compared strings.
   */
  @Override
  public int compareTo(BudgesFile budgesFile)
  {
    if (budgesFile == null || budgesFile.getOriginalName() == null)
      return 1;
    if (getOriginalName() == null)
      return -1;
    return getOriginalName().compareTo(budgesFile.getOriginalName());
  }
  
  /**
   * Override of default equals.  Compares the Budges Files by their file name.
   * 
   * @param otherBudgesFile The second BudgesFile to compare to THIS BudgesFile.
   * @return True if they have the same file, false otherwise.
   */
  @Override
  public boolean equals(Object otherBudgesFile)
  {
    if (otherBudgesFile == null || getClass() != otherBudgesFile.getClass())
    {
      return false;
    }
    else
    {
      BudgesFile otherFile = (BudgesFile) otherBudgesFile;
      if (getOriginalName() != null && otherFile.getOriginalName() != null)
        return getOriginalName().equals(otherFile.getOriginalName());
      else
        return false;
    }
  }
  
  /**
   * Implementation of hashCode() mirroring equals().
   * 
   * return The computed hash off the relevant fields.
   */
  @Override
  public int hashCode()
  {
    return getOriginalName().hashCode();
  }
  
  public String toString()
  {
    return "[" + getOriginalName() + "]" + (getParent() == null ? "" : " in " + getParent().toString());
  }

  public String toStringFull()
  {
    return "[" + getFile().getAbsolutePath() + "] (original: " + getOriginalName() + ")" + (getParent() == null ? "" : " in " + getParent().toStringFull());
  }
  
  public String getTitle()
  {
    return title;
  }


  public void setTitle(String title)
  {
    this.title = title;
  }


  public String getOriginalName()
  {
    return originalName;
  }


  public void setOriginalName(String originalName)
  {
    this.originalName = originalName;
  }


  private BudgesFile getParent()
  {
    return (this.file == null || this.file.getParentFile() == null) ? null: 
      new BudgesFile(file.getParentFile().getName(), file.getParentFile());
  }
  public BudgesFile getZipSource()
  {
    return this.zipSource;
  }
  public void setZipSource(BudgesFile zipFile)
  {
    this.zipSource = zipFile;
  }

  public File getVirusScanFile()
  {
    return virusScanFile;
  }


  public void setVirusScanFile(File virusScanFile)
  {
    this.virusScanFile = virusScanFile;
  }


  public File getFile()
  {
    return file;
  }


  public void setFile(File file)
  {
    this.file = file;
  }

}
