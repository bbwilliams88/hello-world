package mil.dtic.utility;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Level;


public class LogChanger {
	private static final Logger log = LogManager.getLogger(LogChanger.class);
	private String testedNames = ""; 
	private final String name = "RestLogLevelChanger";

  public void setLogLevel(String loggerName, String level) {
    
    if ((loggerName != null) && (level != null)) {
      Logger theLogger;
      if ("root".equalsIgnoreCase(loggerName)) {
        theLogger = LogManager.getRootLogger();
      }
      else {
        theLogger = LogManager.getLogger(loggerName); 
      } 
      
      if ("debug".equalsIgnoreCase(level)) {
        //theLogger.setLevel(Level.DEBUG);
    	  log.warn("WARNING: LogChanger is currently not functional");
      } 
      else if ("info".equalsIgnoreCase(level)) {
        //theLogger.setLevel(Level.INFO);
    	  log.warn("WARNING: LogChanger is currently not functional");
      } 
      else if ("error".equalsIgnoreCase(level)) {
        //theLogger.setLevel(Level.ERROR);
    	  log.warn("WARNING: LogChanger is currently not functional");
      } 
      else if ("fatal".equalsIgnoreCase(level)) {
        //theLogger.setLevel(Level.FATAL);
    	  log.warn("WARNING: LogChanger is currently not functional");
      } 
      else if ("warn".equalsIgnoreCase(level)) {
        //theLogger.setLevel(Level.WARN);
    	  log.warn("WARNING: LogChanger is currently not functional");
      }
    }
  }

  public String getLogLevel(String loggerName) {
	  
    String retValue  = null;
    Level level = null;
    
    if ("root".equalsIgnoreCase(loggerName)){
    	
      level = LogManager.getRootLogger().getLevel();
    }
    else{
      level = LogManager.getLogger(loggerName).getLevel();
    }
    
    if (level == null) {
      Logger aLogger = this.getLoggerDisplay(loggerName);
      if (aLogger != null){
        Level aLevel = aLogger.getLevel();
        String aName = "";
        if (aLevel != null){
          aName = aLevel.toString();
          retValue = aName;
        }
        else {
          retValue = "level is unset";
        } 
      }
      else {
        retValue = "On second pass logger is null" + testedNames;
        testedNames = "";
      }
    } 
    else {
      retValue = loggerName +" is set to: "+ level.toString();
    }
    return (retValue);
  }

  public String getName() {
    return name;
  }

  public void setName(String newName)  {

  }
  
  public String getLoggerDisplay() {
	  log.warn("WARNING: LogChanger is currently not functional");
//    StringBuilder retValue = new StringBuilder();
//    //Level  root = Logger.getRootLogger().getLevel();
//    //String rootlvl = (root == null) ? "unset " : " "+root.toString()+" ";
//    retValue.append("root logger  = "+rootlvl+" </br>");
//    LoggerRepository repo = Logger.getRootLogger().getLoggerRepository();
//    for (Enumeration e = repo.getCurrentCategories(); e.hasMoreElements();)
//    {
//      Object logObj = e.nextElement();
//      if (logObj instanceof Logger)
//      {
//        Logger aLogger = (Logger) logObj;
//        Level logLevel = aLogger.getLevel();
//        String level =" unset ";
//        if(logLevel != null)
//        {
//          level = logLevel.toString();
//        }
//        retValue.append("-> "+aLogger.getName()+" level = "+level+" <br/>");   
//      }
//    }
//        return retValue.toString();
	  return null;
  }

  
  public Logger getLoggerDisplay(String name) {
	  log.warn("WARNING: LogChanger is currently not functional");
	  return null;
//    Logger retValue = null;;
//    LoggerRepository repo = Logger.getRootLogger().getLoggerRepository();
//    if ((name != null)&& (name.length() > 0))
//    {
//      for (Enumeration e = repo.getCurrentCategories(); e.hasMoreElements();)
//      {
//        Object logObj = e.nextElement();
//        if (logObj instanceof Logger)
//        {
//          Logger aLogger = (Logger) logObj;
//          String loggerName = aLogger.getName() ;
//          Level logLevel = aLogger.getLevel();
//          testedNames += ("-> "+loggerName+" level = "+logLevel.toString()+" <br/>");
//          
//          if (name.equals(loggerName))
//          {
//            retValue = aLogger;
//          }
//        }
//      }
//    }
//    return (retValue);
  }

  
}
