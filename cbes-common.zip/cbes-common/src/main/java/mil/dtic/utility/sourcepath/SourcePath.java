package mil.dtic.utility.sourcepath;

public interface SourcePath {
    String getSourcePath();
    void setSourcePath(String sourcePath);
    String getSourceUrl();
    void setSourceUrl(String sourceUrl);
    String getReturnLabel();
    void setReturnLabel(String returnLabel);
    void setHasPath(boolean hasPath);
    boolean isHasPath();
}
