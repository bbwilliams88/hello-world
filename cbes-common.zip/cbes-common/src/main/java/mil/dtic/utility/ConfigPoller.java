package mil.dtic.utility;

import java.util.TimerTask;

import org.apache.logging.log4j.Logger;

/**
 * Poll triggerfiles and reload app configuration beans from db based on
 * triggerfiles being modified
 */
public class ConfigPoller extends TimerTask {
    private static final Logger log = CbesLogFactory.getLog(ConfigPoller.class);

    @Override
    public void run() {

        log.trace("Checking and reloading config and business rules caches if necessary...");
        BudgesContext.getConfigService().reloadConfigCacheIfModified();
        BudgesContext.getValidationService().reloadRulesCacheIfModified();
    }
}
