/*
 * $Id: VersionProperties.java 42094 2010-06-07 12:32:35Z aibrahim $
 */
package mil.dtic.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.Logger;

public class VersionProperties
{
  private static final Logger log = CbesLogFactory.getLog(VersionProperties.class);

  private final Properties properties = new Properties();


  public VersionProperties()
  {
    InputStream is = null;
    try {
      is = getClass().getResourceAsStream("/version.properties");
      properties.load(is);
    } catch (IOException e) {
      //nullpointer on file not found, IOException, etc
      log.error("version.properties not loaded", e);
    } finally {
      FileUtil.close(is);
    }
  }


  private String get(String key)
  {
    String v = properties.getProperty(key);
    return v==null ? "null" : v;
  }


  public String getVersion()
  {
    return get("version");
  }

  /*
  * If you are here because 'buildnumber' is blank in the application and
  * causing invalid URLs on non-local builds, make sure Jenkins build the
  * WAR with the -PincludeGitProperties profile active.
  */
  public String getBuildnumber()
  {
    return get("buildnumber");
  }

  public String getTag()
  {
    return get("tag");
  }

  public String getTimestamp()
  {
    return get("timestamp");
  }
}
