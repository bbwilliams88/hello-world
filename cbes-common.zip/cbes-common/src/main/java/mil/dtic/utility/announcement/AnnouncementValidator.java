package mil.dtic.utility.announcement;

import java.util.ArrayList;
import java.util.List;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
//import mil.dtic.cbes.submissions.t5.pages.EmailAnnouncement;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.announcement.exception.AnnouncementException;
import mil.dtic.utility.announcement.options.Audience;

public class AnnouncementValidator {
    private static final Logger log = CbesLogFactory.getLog(AnnouncementValidator.class);
    
    // validation responses.
    static String OK = "OK"; //package private constant, also useed by AnnouncementServiceImpl
    static String FAIL = "FAIL"; 
    private static String NULL_REQUIRED_FIELD = "A required field(s) is empty!";
    private static String NO_AUDIENCE_NO_EMAILS ="Additional recipient email addresses cannot be empty if target audience is NONE";
    private static String SENDER_EMAIL_INVALID = "Sender email address is invalid";
    private static String ADDITIONAL_RECIPIENT_EMAIL_INVALID = "Additional recipient email address is invalid";
    private static String NO_ANNOUNCEMENT =  "No announcement provided to validator";
    private static String NULL_AUDIENCE = " Target Audience";
    private static String NULL_SUBJECT = " Subject";
    private static String NULL_CONTENT = " Content";
    private static String NULL_SENDER =  " Sender Email Address";
    

    private final Announcement announcement;
    //validationStatus should always be modified during validation, this insures it will not be involved in NPE
    private String validationStatus = AnnouncementValidator.FAIL;  
    private final List<String> validatedEmailList = new ArrayList<>();
    
    public AnnouncementValidator(final Announcement announcement){
        this.announcement = announcement;
    }
    
    /**
     * Provides list of emails available to the creator of this class.
     * @return List<String> validatedEmailList
     */
    public final List<String> getValidatedEmailList() {
        return validatedEmailList;
    }

    /**
     * Validates values embedded in an Announcement.
     * @return String - represents success or validation failure point.
     * @throws AnnouncementException
     */
    public String validate() throws AnnouncementException{
        
        if (null == announcement){
            throw new AnnouncementException(AnnouncementValidator.NO_ANNOUNCEMENT);
        }
        
        return processValidation(announcement);
    }
    
    private String processValidation(final Announcement announcement){
        
        if (validateNotNull(announcement)){
            if (validateNoAudienceNoEmails(announcement)){
                if (validateEmailAddresses(announcement)){
                    validationStatus = AnnouncementValidator.OK; 
                }
            }
        }
        
        return validationStatus;
    }
    
    private boolean validateEmailAddresses(final Announcement announcement){
        if (validateEmailAddress(announcement.getSenderEmail())){
            if (null != announcement.getEmails()){
                String emails = announcement.getEmails();
                String[] aEmails = emails.split("\\s");
                aEmails = emails.trim().split("\\s+");
                
                for (String s : aEmails){
                    boolean valid = validateEmailAddress(s);
                    if (!valid){
                        validationStatus = AnnouncementValidator.ADDITIONAL_RECIPIENT_EMAIL_INVALID + ": " + s;
                        return false;
                    }
                }
            }
            return true;
        }
        else {
            validationStatus = AnnouncementValidator.SENDER_EMAIL_INVALID;
            return false;
        }
    }
    
    private boolean validateEmailAddress(final String emailAddress){
        try {
            InternetAddress emailAddr = new InternetAddress(emailAddress);
            emailAddr.validate();
            validatedEmailList.add(emailAddress);
         } 
        catch (AddressException ex) {
            log.info("email address failed validation: " + ex.getMessage());
            return false;
         }
        
        return true;
        
    }
    
    
    private boolean validateNoAudienceNoEmails(Announcement announcement){
        
        if (announcement.getAudience() == Audience.NONE){
            if (null == announcement.getEmails()){
                validationStatus = AnnouncementValidator.NO_AUDIENCE_NO_EMAILS;
                return false;
            }
        }
        return true;
        
    }

    
    private boolean validateNotNull(Announcement announcement){
      
        List<String> nullValues = getNullValues(announcement);
        
        if (nullValues.size() == 0){
            return true;   
        }
        else{
        
            StringBuilder sb = new StringBuilder(" (");
            String prefix = "" ;
            for (String requiredField : nullValues){
                sb.append(prefix);
                sb.append(requiredField);
                prefix = ", ";
            }
            sb.append(" )");
            validationStatus = AnnouncementValidator.NULL_REQUIRED_FIELD + sb.toString();
            return false;
        }
    }
    
    public Announcement getAnnouncement() {
        return announcement;
    }

    public String getValidationStatus() {
        return validationStatus;
    }

    public void setValidationStatus(String validationStatus) {
        this.validationStatus = validationStatus;
    }
    
    private List<String> getNullValues(Announcement announcement){
        
        List<String> nullValues = new ArrayList<>();
        
        if (null == announcement.getAudience()){
            nullValues.add(AnnouncementValidator.NULL_AUDIENCE);
        }
        
        if (null == announcement.getSubject()){
            nullValues.add(AnnouncementValidator.NULL_SUBJECT);
        }
        
        if (null == announcement.getContent()){
            nullValues.add(AnnouncementValidator.NULL_CONTENT);
        }
        
        if (null == announcement.getSenderEmail()){
            nullValues.add(AnnouncementValidator.NULL_SENDER);
        }
        
        return nullValues;

    }

    
    
}
