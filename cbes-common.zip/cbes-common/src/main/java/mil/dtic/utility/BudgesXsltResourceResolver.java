/*
 * $Id$
 */
package mil.dtic.utility;

import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;

import org.apache.logging.log4j.Logger;

public abstract class BudgesXsltResourceResolver implements URIResolver {

	private static final Logger log = CbesLogFactory.getLog(BudgesXsltResourceResolver.class);

	private List<String> pathList = new ArrayList<String>();

	public BudgesXsltResourceResolver(String path) {
		pathList.add(path);
	}

	public BudgesXsltResourceResolver(List<String> pathList) {
		this.pathList.addAll(pathList);
	}

	public List<String> getPathList() {
		return pathList;
	}

	public Source resolve(String href, String base) throws TransformerException {

		log.trace("Resolving uri (base:href) '" + base + ":" + href + "'");
		Source result = findResource(href, base);

		if (result == null)
			log.trace("Did not find uri: '" + base + href + "'");
		else
			log.trace("Found uri: '" + base + href + "'");
		return (result);
	}

	protected abstract Source findResource(String href, String base);

}
