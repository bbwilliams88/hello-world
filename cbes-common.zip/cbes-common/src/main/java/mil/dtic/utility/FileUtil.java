/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.List;
import java.util.zip.ZipFile;

import javax.imageio.stream.ImageInputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants;

/**
 * A static class that contains commonly used helper methods for file
 * processing.
 *
 * @author aprabhu
 */
public class FileUtil
{
  private static final Logger log = CbesLogFactory.getLog(FileUtil.class);


  public static InputStream getFileInputStream(List<String> pathList, String name)
  {
    return getFileInputStream(null, pathList, name);
  }

  public static InputStream getFileInputStream(String base, List<String> pathList, String name)
  {
    if (StringUtils.isEmpty(base))
      base = "";
    else
      base = base + "/";

    FileInputStream fis = null;
    for (String path : pathList)
    {
      try
      {
        File file = new File(base + path + "/" + name);
        if (file.exists()) {
          return new FileInputStream(file);
        }
      }
      catch (IOException e)
      {
        log.error("Error while trying to get file as input stream", e);
      }
    }
    return fis;
  }


  public static byte[] getByteArrayFromFilePath(String filePath)
  {
    return getByteArrayFromFile(new File(filePath));
  }

  public static byte[] getByteArrayFromFile(File file)
  {
    try (BufferedInputStream is = new BufferedInputStream(new BufferedInputStream(new FileInputStream(file))) ){
    	  byte[] bytes = getByteArrayFromInputStream(is);
    	  return bytes;
    } catch (IOException e) {
		log.error("Error while trying to convert File object to byte array", e);
    }
	return null;
  }

  public static byte[] getByteArrayFromInputStream(InputStream is){
	  byte [] data = null;
	  if (is != null){
		  byte[] tmpBuffer = new byte[Constants.TMP_BUFFER_SIZE];
		  try(ByteArrayOutputStream baos = new ByteArrayOutputStream()){
			  int numBytesRead = 0;
			  while ((numBytesRead = is.read(tmpBuffer, 0, tmpBuffer.length)) > 0){
				  baos.write(tmpBuffer, 0, numBytesRead);
				  data = baos.toByteArray();
			  }
		  } catch (IOException e) {
			  log.error("Error while trying to convert InputStream to byte array", e);
		}
	  }
	  return data;
  }


  public static String readFileContents(File inputFile)
  {
    String s = null;
    byte[] data = getByteArrayFromFile(inputFile);
    if (data != null)
      s = new String(data);
    return s;
  }

  public static void writeFileContents(File file, OutputStream os, boolean closeOutputStream) throws IOException
  {
	  try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(file))){
		  writeFileContents(is, os, true, closeOutputStream);
	  }

  }

  public static void writeFileContents(File file, OutputStream os) throws IOException
  {
    try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(file))){
		  writeFileContents(is, os);
	  }
  }

  public static void writeFileContents(String file, OutputStream os, boolean closeOutputStream) throws IOException
  {
	  try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(file))){
		  writeFileContents(is, os, true, closeOutputStream);
	  }
  }

  public static void writeFileContents(String file, OutputStream os) throws IOException
  {
	  try (BufferedInputStream is = new BufferedInputStream(new FileInputStream(file))){
		  writeFileContents(is, os);
	  }
  }


  public static void writeFileContents(byte[] byteArray, OutputStream os) throws IOException
  {
    writeFileContents(new ByteArrayInputStream(byteArray), os);
  }

  public static void writeFileContents(String stringData, File outputFile) throws IOException
  {
	  try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))){
		  bw.write(stringData);
	  }
  }

  public static void writeFileContents(InputStream is, OutputStream os) throws IOException
  {
    writeFileContents(is, os, true, true);
  }

  public static void writeFileContents(InputStream is, OutputStream os, boolean closeInputStream, boolean closeOutputStream) throws IOException
  {
    byte[] buffer = new byte[Constants.TMP_BUFFER_SIZE];
    int len = 0;

    try
    {
      while ((len = is.read(buffer)) > 0)
        os.write(buffer, 0, len);
    }
    finally
    {
      if (closeInputStream)
        close(is);
      if (closeOutputStream)
        close(os);
    }
  }

  public static void writeFileContents(InputStream is, File outputFile) throws IOException
  {
	  try(BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outputFile))){
		  writeFileContents(is, bos);
	  }
  }

  // handle directories in zip filename (don't get confused when the directory
  // has a dot)
  // '/' is the standard zip path separator
//  public static String getFileExtensionForZipEntry(String fileName)
//  {
//    String ext = "";
//    if (StringUtils.isNotEmpty(fileName))
//    {
//      int index = fileName.lastIndexOf('.');
//      int pathSepIndex = fileName.lastIndexOf(System.getProperty("file.separator"));
//      if (pathSepIndex > index) return ext;
//      if (index >= 0 && index < (fileName.length() - 1))
//        ext = fileName.substring(index + 1);
//    }
//    return ext;
//  }


  public static boolean isZipFile(String fileName)
  {
    return BudgesContentType.ZIP.getFileExtension().equalsIgnoreCase(CBESFilenameUtils.getExtension(fileName));
  }


  public static boolean isZzzFile(String fileName)
  {
    return BudgesContentType.ZZZ.getFileExtension().equalsIgnoreCase(CBESFilenameUtils.getExtension(fileName));
  }


  public static boolean isXmlFile(String fileName)
  {
    return BudgesContentType.XML.getFileExtension().equalsIgnoreCase(CBESFilenameUtils.getExtension(fileName));
  }

  public static boolean isPdfFile(String fileName)
  {
    return BudgesContentType.PDF.getFileExtension().equalsIgnoreCase(CBESFilenameUtils.getExtension(fileName));
  }


  public static String getFileNameWithoutPath(String fileName)
  {    String localFileName = fileName;
    if (StringUtils.isNotEmpty(fileName))
    {
      int index = fileName.lastIndexOf(System.getProperty("file.separator"));
      if (index >= 0 && index < (fileName.length() - 1))
        localFileName = fileName.substring(index + 1);
    }
    return localFileName;
  }


  public static boolean close(InputStream is)
  {
    boolean success = true;
    try
    {
      if (is != null)
        is.close();
    }
    catch (IOException ex)
    {
      log.error(ex);
      success = false;
    }

    return success;
  }


  public static boolean close(ImageInputStream is)
  {
    boolean success = true;
    try
    {
      if (is != null)
        is.close();
    }
    catch (IOException ex)
    {
      log.error(ex);
      success = false;
    }

    return success;
  }


  public static boolean close(OutputStream os)
  {
    boolean success = true;
    try
    {
      if (os != null)
        os.close();
    }
    catch (IOException ex)
    {
      log.error(ex);
      success = false;
    }
    return success;
  }


  public static boolean close(Reader r)
  {
    boolean success = true;
    try
    {
      if (r != null)
        r.close();
    }
    catch (IOException ex)
    {
      log.error(ex);
      success = false;
    }
    return success;
  }


  public static boolean close(Writer w)
  {
    boolean success = true;
    try
    {
      if (w != null)
        w.close();
    }
    catch (IOException ex)
    {
      log.error(ex);
      success = false;
    }
    return success;
  }


  public static void close(ZipFile zipFile)
  {
    if (zipFile != null)
    {
      try
      {
        zipFile.close();
      }
      catch (IOException e)
      {
        log.error(e);
      }
    }
  }


  public static void deleteFile(File file)
  {
    try
    {
      if (file != null && file.isFile() && file.exists())
        file.delete();
    }
    catch (SecurityException ex)
    {
      log.error(ex);
    }
  }

  public static String createTextFileName(Object... names)
  {
    return createFileName("txt", names);
  }


  public static String createExcelFileName(Object... names)
  {
    return createFileName("xls.xml", names);
  }


  public static String createWordFileName(Object... names)
  {
    return createFileName("doc", names);
  }


  public static String createPdfFileName(Object... names)
  {
    return createFileName("pdf", names);
  }


  public static String createZipFileName(Object... names)
  {
    return createFileName("zip", names);
  }


  public static String createZzzFileName(Object... names)
  {
    return createFileName("zzz", names);
  }


  public static String createXmlFileName(Object... names)
  {
    return createFileName("xml", names);
  }


  public static String createFileNameOfSameType(String fileName, Object... names)
  {
    return createFileName(CBESFilenameUtils.getExtension(fileName), names);
  }


  public static String createFileName(String ext, Object... names)
  {
    StringBuffer sb = new StringBuffer(CBESFilenameUtils.sanitizeFileName(names[0].toString()));
    for (int i = 1; i < names.length && names[i] != null; ++i)
      sb.append("_" + CBESFilenameUtils.sanitizeFileName(names[i].toString()));
    if (ext != null)
      sb.append("." + ext);
    return sb.toString();//(Util.isClassified() ? "S" : "U") + "_" + sb.toString();
  }


  public static int getQuotientCeil(double numerator, double denominator)
  {
    return (int) Math.ceil(numerator / denominator);
  }


  public static String convertFileSizeToHumanReadable(long sizeInBytes)
  {
    String value = null;
    String sizeInBytesStr = "";

    if (sizeInBytes < Constants.KILOBYTE)
      value = String.valueOf(sizeInBytes) + " B";
    else if (sizeInBytes < Constants.MEGABYTE)
      value = sizeInBytesStr + getQuotientCeil(sizeInBytes, Constants.KILOBYTE) + " KB";
    else if (sizeInBytes < Constants.GIGABYTE)
      value = sizeInBytesStr + getQuotientCeil(sizeInBytes, Constants.MEGABYTE) + " MB";
    else
      value = sizeInBytesStr + getQuotientCeil(sizeInBytes, Constants.GIGABYTE) + " GB";
    return value;
  }


  /**
   * Checks to see if a list of subdirectories in a given parent directory ALL
   * exist or not. If they all exist, returns true; false otherwise.
   *
   * @param parentDir
   *          - the parent directory
   * @param subDirs
   *          - An list of subdirectories whose existence to check
   * @return
   */
  public static boolean allSubDirsExist(File parentDir, List<String> subDirs)
  {
    if (parentDir == null || subDirs == null)
    {
      return false;
    }
    else
    {
      for (String subDir : subDirs)
      {
        if (!new File(parentDir, subDir).exists())
        {
          return false;
        }
      }
    }
    return true;
  }


  /**
   * Checks to see if a file exists in a list of subdirectories in a given
   * parent directory and returns the File for the first one that exists.
   *
   * @param parent
   *          - the parent directory
   * @param subDirs
   *          - An list of subdirectories whose existence to check
   * @return
   */
  public static File getFirstExistingPath(File parent, List<String> subDirs, String fileName)
  {
    if (parent != null && subDirs != null)
    {
      for (String subDir : subDirs)
      {
        File file = new File(new File(parent, subDir), fileName);
        log.debug("Looking for xmlpackage: " + file);
        if (file.exists())
        {
          return file;
        }
      }
    }
    return null;
  }

    /**
     * Tests if a file's extension is NOT whitelisted using the default
     * whitelist.
     *
     * @param file
     *            The file to test.
     * @return {@code true} if the file's extension does NOT match one of the
     *         default whitelist options, {@code false} otherwise.
     */
    public static boolean isNotWhitelisted(File file)
    {
        return isNotWhitelisted(file, null);
    }

    /**
     * Tests if a file's extension is whitelisted using the default whitelist.
     *
     * @param file
     *            The file to test.
     * @return {@code true} if the filename's extension matches one of the
     *         default whitelist options, {@code false} otherwise.
     */
    public static boolean isWhitelisted(File file)
    {
        return isWhitelisted(file, null);
    }

    /**
     * Tests if a file's extension is whitelisted using the supplied whitelist.
     *
     * @param file
     *            The file to test.
     * @param whitelist
     *            A comma-or-whitespace separated list of filename extensions.
     * @return {@code true} if the file's extension matches one of the
     *         supplied whitelist options, {@code false} otherwise.
     */
    public static boolean isWhitelisted(File file, String whitelist)
    {
        if (file.isDirectory())
            return true;

        if (whitelist == null)
            return CBESFilenameUtils.isWhitelisted(file.getName());
        else
            return CBESFilenameUtils.isWhitelisted(file.getName(), whitelist);
    }

    /**
     * Tests if a file's extension is NOT whitelisted using the supplied whitelist.
     *
     * @param file
     *            The file to test.
     * @param whitelist
     *            A comma-or-whitespace separated list of filename extensions.
     * @return {@code true} if the file's extension does NOT match one of the
     *         supplied whitelist options, {@code false} otherwise.
     */
    public static boolean isNotWhitelisted(File file, String whitelist)
    {
        return isWhitelisted(file, whitelist) == false;
    }
}
