package mil.dtic.utility;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentNameDictionary;
import org.apache.pdfbox.pdmodel.PDEmbeddedFilesNameTreeNode;
import org.apache.pdfbox.pdmodel.common.COSObjectable;
import org.apache.pdfbox.pdmodel.common.filespecification.PDComplexFileSpecification;
import org.apache.pdfbox.pdmodel.common.filespecification.PDEmbeddedFile;
import org.apache.pdfbox.pdmodel.encryption.BadSecurityHandlerException;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;

import mil.dtic.cbes.service.UnzipService;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.XmlValidationDelegate;


public class UploadPdfUtils
{

  private static final Logger log = CbesLogFactory.getLog(UploadPdfUtils.class);

  /**
   * This will parse the pdf file and pulls out the zip (.zzz) attachment if it is there.
   *
   * @param pdfFile
   * @return
   * @throws IOException
   * @throws BadSecurityHandlerException
   * @throws CryptographyException
   * @throws VirusScanException
   */
  public static List<File> unwrapPdfFile(File pdfFile) throws IOException, BadSecurityHandlerException, CryptographyException, VirusScanException
  {
    List<File> ans = new ArrayList<File>();
    if ((pdfFile == null) ||(pdfFile.getName() == null)){
      return ans;
    }
    log.debug("Unwrapping PDF file " + pdfFile.getName());

    // if file isn't a pdf, but is a zip/zzz, we can return it without further processing
    if (StringUtils.endsWith(pdfFile.getName().toLowerCase(), ".zip") || StringUtils.endsWith(pdfFile.getName().toLowerCase(), ".zzz"))
      {
        ans.add(pdfFile);
      }
    else
    {
      // extract all attachments to the folder where the pdf lives, and return a list of the ones with a zzz extension
      for(File f: UploadPdfUtils.extractPdfAttachments(pdfFile)) {
        if(StringUtils.endsWith(f.getName().toLowerCase(),".zzz")) {
          ans.add(f);
        }
      }
    }
    return ans;
  }

  /* the document-handling heavy lifting to extract attachments from a pdf (does not unzip or filter for zzz's) */
  public static List<File> extractPdfAttachments(File pdfFile) throws IOException, BadSecurityHandlerException, CryptographyException, VirusScanException
  {
    ArrayList<File> ans = new ArrayList<File>();
    PDDocument document = null;
    try {
      document = PDDocument.load(pdfFile);
      if (document.isEncrypted())
      {
        StandardDecryptionMaterial sdm = new StandardDecryptionMaterial("");
        document.openProtection(sdm);
      }


      //Store the embedded files in a sub directory named after the pdf filename.
      String embeddedFilePath = pdfFile.getParent() + System.getProperty("file.separator") + CBESFilenameUtils.getBaseName(pdfFile.getName()) + "_dir";
      File embeddedFileExtractDir = new File(embeddedFilePath);
      if(embeddedFileExtractDir.mkdirs() == false) {
        log.error("could not create directory " + embeddedFilePath);
      } else {
        log.debug("created extract directory at " + embeddedFilePath);
      }

      PDDocumentNameDictionary namesDictionary = new PDDocumentNameDictionary(document.getDocumentCatalog());
      PDEmbeddedFilesNameTreeNode efTree = namesDictionary.getEmbeddedFiles();

      if (efTree != null)
      {
        for (Entry<String, COSObjectable> fileEntry : efTree.getNames().entrySet())
        {
          // extract files to same folder as original PDF file
          FileOutputStream fos = null;
          String embeddedFilename = "";


          File extractedFile = null;
          try
          {
            PDComplexFileSpecification fileSpec = (PDComplexFileSpecification) fileEntry.getValue();
            PDEmbeddedFile embeddedFile = fileSpec.getEmbeddedFile();
            // the key from names didn't have the file extension
            embeddedFilename = embeddedFileExtractDir + System.getProperty("file.separator") + CBESFilenameUtils.sanitizeFileName(fileSpec.getFilename());
            extractedFile = new File(embeddedFilename);
            fos = new FileOutputStream(extractedFile);
            fos.write(embeddedFile.getByteArray());
          }
          finally
          {
            if (fos != null)
            {
              fos.close();
            }
          }
          log.debug("Extracted PDF attachment " + embeddedFilename);
          ans.add(extractedFile);
        }
      }
    } catch (IOException ex) {
      log.error(ex.getMessage());
    } finally {
      if (document != null) {
        document.close();
      }
    }
    if (CollectionUtils.isEmpty(ans))
    {
      throw new IOException ("Could not find any attachments for PDF file.");
    }
    return ans;
  }

  /* processZzz, processXmlFile:
   * Old-UI methods to extract XML from zzz attachments as PreviewResultInfo */

  public static PreviewResultInfo processZzz(File zzzFile,File workingDirectory, List<String> errorMessages,BudgesUser user, boolean runOnlyVerifiedRules) throws VirusScanException, IOException
  {
    UnzipService xmlService = null;
    PreviewResultInfo processedXml = null;
    UnzipService us = new UnzipService(zzzFile.getParentFile());
    us.unzipOriginalNames(new BudgesFile("theZip.zzz", zzzFile, null));
    xmlService = us;

    processedXml = processXmlFile(xmlService, errorMessages, workingDirectory, user, runOnlyVerifiedRules);
    if (processedXml==null){
      return null;
    }
    if (!processedXml.getErrorList().isEmpty())
    {
      errorMessages.addAll(processedXml.getErrorList());
    }
    if (processedXml.fatalErrorsExist())
    {
      errorMessages.add("Fatal errors found parsing uploaded XML.");
    }
    return processedXml;
  }

  public static PreviewResultInfo processXmlFile(UnzipService us, List<String> errorList, File workingDirectory, BudgesUser user, boolean runOnlyVerifiedRules) throws VirusScanException, IOException
  {
    BudgesFile f = null;
    if (us != null && us.getUnzippedXmlFileList() != null && us.getUnzippedXmlFileList().isEmpty() == false)
    {
      if (us.getUnzippedXmlFileList().size() >= 2)
      {
        errorList.add("Found more than one attached XML file.");
      }
      f= us.getUnzippedXmlFileList().get(0);
    }
    if (f == null) {
      errorList.add("Uploaded file corrupt: cannot find zipped XML file.");
      return null;
    }
    XmlValidationDelegate xvd = new XmlValidationDelegate(user, workingDirectory, new SendEmailOnInvalidXML2(), runOnlyVerifiedRules, us);
    xvd.setScanEnabled(false);
    return xvd.doValidateXml(f);
  }

  /* extractXmlFromPdfFile, extractXmlFromZZZ, highestOrderFile utils:
   * New-UI methods to extract XML from zzz attachments as InputStream */

   public static List<InputStream> extractXmlFromPdfFile(File pdfFile) throws IOException, BadSecurityHandlerException, CryptographyException, VirusScanException {
     List<File> pdfAttachments = unwrapPdfFile(pdfFile);
     List<InputStream> xmlFiles = new LinkedList<InputStream>();

     xmlFiles.addAll(extractXmlFromZZZ(pdfAttachments, pdfFile.getParent() + System.getProperty("file.separator")));

     return xmlFiles;
  }

   public static List<InputStream> extractHighestOrderXmlFromPdfFile(File pdfFile) throws IOException, BadSecurityHandlerException, CryptographyException, VirusScanException {
     List<File> pdfAttachments = extractHighestOrderZzz(pdfFile);
     List<InputStream> xmlFiles = new LinkedList<InputStream>();

     xmlFiles.addAll(extractXmlFromZZZ(pdfAttachments, pdfFile.getParent() + System.getProperty("file.separator")));

     return xmlFiles;
   }

   public static List<String> extractHighestOrderXmlFileNameFromPdfFile(File pdfFile) throws IOException, BadSecurityHandlerException, CryptographyException, VirusScanException {
     List<File> pdfAttachments = extractHighestOrderZzz(pdfFile);
     List<String> fNames = new LinkedList<String>();
     for (File f: pdfAttachments){
       fNames.add(f.getName());
     }
     return fNames;
   }

   public static List<File> extractHighestOrderZzz(File pdfFile) throws IOException, CryptographyException, BadSecurityHandlerException, VirusScanException {
     File mjbFile = null;
     File jbFile = null;
     File exhibitFile = null;
     String fname = null;
     List<File> resultList = new ArrayList<File>();

     List<File> zzzFiles = unwrapPdfFile(pdfFile);

     for(File f: zzzFiles) {
       fname = f.getName();
       log.debug("Found zzz name:"+fname);
       if (fname.toLowerCase().contains("_masterjustificationbook_")) {
         mjbFile = f;
       }
       else if (fname.toLowerCase().contains("_justificationbook_")) {
         jbFile = f;
       }
       else {
         exhibitFile = f;
       }
     }


     if (mjbFile!=null) {
       resultList.add(mjbFile);
       return resultList;
     }
     else if (jbFile!=null){
       resultList.add(jbFile);
       return resultList;
     }
     else if (exhibitFile !=null){
       resultList.add(exhibitFile);
       return resultList;
     }
     if (CollectionUtils.isEmpty(resultList))
     {
       throw new IOException ("No MJB, JB, or exhibit .zzz files attached to PDF.");
     }
     return resultList;
   }

   private static List<InputStream> extractXmlFromZZZ(List<File> files, String filePath) throws IOException {
     List<InputStream> attachments = new ArrayList<InputStream>();
     for (File f : files) {
       log.debug("unzipping file: " + f.getAbsolutePath());
       try (ZipFile zp = new ZipFile(f)) {
         log.debug("begin looping through zip");
         for (ZipEntry zipEntry : Collections.list(zp.entries())) {
           log.debug("zip content: " + zipEntry.getName());
           if (CBESFilenameUtils.isExtension(zipEntry.getName(), "xml")) {

             log.debug(" &&&&&&&&&&&&&& found an XML file, copying: "
                 + zipEntry.getName());
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
             IOUtils.copyLarge(zp.getInputStream(zipEntry), outputStream);
             attachments.add(new ByteArrayInputStream(outputStream
                 .toByteArray()));
             IOUtils.closeQuietly(outputStream);
           }
         }
       }
       catch (IOException e)
       {
         log.error("Error in UploadPDFUtils extractXmlFromZZZ method: " + e.getMessage());
         throw e;
       }
     }
     return attachments;
   }
}
