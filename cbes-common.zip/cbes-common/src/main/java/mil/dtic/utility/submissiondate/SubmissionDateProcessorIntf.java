package mil.dtic.utility.submissiondate;

import java.util.Date;

import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.utility.submissiondate.exception.SubmissionDateProcessorException;

public interface SubmissionDateProcessorIntf {
    Date getDate(String budgetCyle, Integer submissionDate) throws SubmissionDateProcessorException;
    Date getDate(String budgetCycleAndYear);
    SubmissionDate getSubmissionDate(String budgetCyle, Integer submissionDate) throws SubmissionDateProcessorException;
    SubmissionDate getSubmissionDate(String budgetCycleAndYear);
    
    
}
