/*
 * $Id: BudgesJbFile.java$
 */
package mil.dtic.utility;

import mil.dtic.cbes.p40.vo.JbVolume;

public class BudgesJbFile
{
  private String bookGroup;
  private String bookLabel;
  private String bookNumber;
  private String bookDescription;
  private String agencyCode;
  private boolean overrideDocumentAssemblyOptionsInXml;
  private boolean generateR1;
  private boolean generateR1Summary;
  private boolean generateR1c;
  private boolean generateR1d;
  private boolean generateProgramElementTocByTitle;
  private boolean generateProgramElementTocByBA;
  private boolean generateP1;
  private boolean generateLineItemTocByTitle;
  private boolean generateLineItemTocByBA;
  private BudgesFile budgesFile;
  private Integer sequenceNumber;

  public BudgesJbFile() {
    
  }
  
  public BudgesJbFile(JbVolume jbVolume) {
    
    setAgencyCode(jbVolume.getAgencyCode());
    setBookGroup(jbVolume.getBookGroup());
    setBookLabel(jbVolume.getBookLabel());
    setBookDescription(jbVolume.getBookDescription());
    setBookNumber(jbVolume.getBookNumber());
    setOverrideDocumentAssemblyOptionsInXml(jbVolume.isOverrideDocumentAssemblyOptionsInXml());
    setGenerateR1(jbVolume.isGenerateR1());
    setGenerateR1Summary(jbVolume.isGenerateR1Summary());
    setGenerateR1c(jbVolume.isGenerateR1c());
    setGenerateR1d(jbVolume.isGenerateR1d());
    setGenerateProgramElementTocByTitle(jbVolume.isGenerateProgramElementTocByTitle());
    setGenerateProgramElementTocByBA(jbVolume.isGenerateProgramElementTocByBA());    
    setGenerateP1(jbVolume.isGenerateP1());
    setGenerateLineItemTocByTitle(jbVolume.isGenerateLineItemTocByTitle());
    setGenerateLineItemTocByBA(jbVolume.isGenerateLineItemTocByBA());
   
  }

  public static BudgesJbFile copy(BudgesJbFile src)
  {
    BudgesJbFile jbVolume = new BudgesJbFile();
    jbVolume.setAgencyCode(src.getAgencyCode());
    jbVolume.setBookGroup(src.getBookGroup());
    jbVolume.setBookLabel(src.getBookLabel());
    jbVolume.setBookDescription(src.getBookDescription());
    jbVolume.setBookNumber(src.getBookNumber());
    jbVolume.setOverrideDocumentAssemblyOptionsInXml(src.isOverrideDocumentAssemblyOptionsInXml());
    jbVolume.setGenerateR1(src.isGenerateR1());
    jbVolume.setGenerateR1Summary(src.isGenerateR1Summary());
    jbVolume.setGenerateR1c(src.isGenerateR1c());
    jbVolume.setGenerateR1d(src.isGenerateR1d());
    jbVolume.setGenerateProgramElementTocByTitle(src.isGenerateProgramElementTocByTitle());
    jbVolume.setGenerateProgramElementTocByBA(src.isGenerateProgramElementTocByBA());    
    jbVolume.setGenerateP1(src.isGenerateP1());
    jbVolume.setGenerateLineItemTocByTitle(src.isGenerateLineItemTocByTitle());
    jbVolume.setGenerateLineItemTocByBA(src.isGenerateLineItemTocByBA());        
    jbVolume.setBudgesFile(src.getBudgesFile());
    
    return jbVolume;
  }

  public String getBookLabelAndNumber()
  {
    return Util.concat(" ", getBookLabel(), getBookNumber());
  }

  public String getBookGroup()
  {
    return bookGroup;
  }


  public void setBookGroup(String bookGroup)
  {
    this.bookGroup = bookGroup;
  }


  public String getBookLabel()
  {
    return bookLabel;
  }


  public void setBookLabel(String bookLabel)
  {
    this.bookLabel = bookLabel;
  }


  public String getBookNumber()
  {
    return bookNumber;
  }


  public void setBookNumber(String bookNumber)
  {
    this.bookNumber = bookNumber;
  }


  public String getBookDescription()
  {
    return bookDescription;
  }


  public void setBookDescription(String bookDescription)
  {
    this.bookDescription = bookDescription;
  }


  public String getAgencyCode()
  {
    return agencyCode;
  }

  public void setAgencyCode(String agencyCode)
  {
    this.agencyCode = agencyCode;
  }

  public boolean isOverrideDocumentAssemblyOptionsInXml()
  {
    return overrideDocumentAssemblyOptionsInXml;
  }


  public void setOverrideDocumentAssemblyOptionsInXml(boolean overrideDocumentAssemblyOptionsInXml)
  {
    this.overrideDocumentAssemblyOptionsInXml = overrideDocumentAssemblyOptionsInXml;
  }


  public boolean isGenerateR1()
  {
    return generateR1;
  }


  public void setGenerateR1(boolean generateR1)
  {
    this.generateR1 = generateR1;
  }


  public boolean isGenerateR1Summary()
  {
    return generateR1Summary;
  }


  public void setGenerateR1Summary(boolean generateR1Summary)
  {
    this.generateR1Summary = generateR1Summary;
  }


  public boolean isGenerateR1c()
  {
    return generateR1c;
  }


  public void setGenerateR1c(boolean generateR1c)
  {
    this.generateR1c = generateR1c;
  }


  public boolean isGenerateR1d()
  {
    return generateR1d;
  }


  public void setGenerateR1d(boolean generateR1d)
  {
    this.generateR1d = generateR1d;
  }


  public boolean isGenerateProgramElementTocByTitle()
  {
    return generateProgramElementTocByTitle;
  }


  public void setGenerateProgramElementTocByTitle(boolean generateProgramElementTocByTitle)
  {
    this.generateProgramElementTocByTitle = generateProgramElementTocByTitle;
  }


  public boolean isGenerateProgramElementTocByBA()
  {
    return generateProgramElementTocByBA;
  }


  public void setGenerateProgramElementTocByBA(boolean generateProgramElementTocByBA)
  {
    this.generateProgramElementTocByBA = generateProgramElementTocByBA;
  }

  
  public boolean isGenerateP1()
  {
    return generateP1;
  }

  public void setGenerateP1(boolean generateP1)
  {
    this.generateP1 = generateP1;
  }

  public boolean isGenerateLineItemTocByTitle()
  {
    return generateLineItemTocByTitle;
  }

  public void setGenerateLineItemTocByTitle(boolean generateLineItemTocByTitle)
  {
    this.generateLineItemTocByTitle = generateLineItemTocByTitle;
  }

  public boolean isGenerateLineItemTocByBA()
  {
    return generateLineItemTocByBA;
  }

  public void setGenerateLineItemTocByBA(boolean generateLineItemTocByBA)
  {
    this.generateLineItemTocByBA = generateLineItemTocByBA;
  }

  public BudgesFile getBudgesFile()
  {
    return budgesFile;
  }


  public void setBudgesFile(BudgesFile budgesFile)
  {
    this.budgesFile = budgesFile;
  }

  public Integer getSequenceNumber() {
      return sequenceNumber;
  }

  public void setSequenceNumber(Integer seqNumber) {
      this.sequenceNumber = seqNumber;
  }


}
