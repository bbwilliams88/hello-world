package mil.dtic.utility;

import org.apache.commons.lang3.StringUtils;

import mil.dtic.cbes.exceptions.InvalidFileTypeException;


/**
 *A utility class to help with testing file names uploaded by users
 *
 */
public class CBESFilenameUtils extends org.apache.commons.io.FilenameUtils {

	private static String[] defaultWhitelist;

	public static String[] getDefaultWhitelist() {
		return defaultWhitelist;
	}

	public static void setDefaultWhitelist(String[] defaultWhitelist) {
	    CBESFilenameUtils.defaultWhitelist = defaultWhitelist;
	}

    /**
     * Converts a string of whitelist filename extensions into an array.
     *
     * @param whitelistString
     *            A comma-or-whitespace separated list of filename extensions to
     *            extract into an array.
     * @return A {@code String[]} of filename extensions.
     */
    public static String[] stringToWhitelistArray(String whitelistString)
    {
        return StringUtils.split(BudgesContext.getConfigService().getWhitelist(), " ,\n\r");
    }

    /**
     * Checks the filename's extension against a whitelist and, if it is a valid
     * filename extension, sanitizes the filename.
     *
     * @param filename
     *            The original filename to check and sanitize.
     * @param whitelist
     *            A comma-or-whitespace separated list of filename extensions.
     * @return A new filename that has been sanitized if the original name
     *         passes the whitelist check.
     * @throws InvalidFileTypeException
     *             If the filename is an invalid file type (based upon the
     *             filename's extension).
     */
    public static String checkAndSanitizeFileName(String filename, String whitelist) throws InvalidFileTypeException
    {
        return checkAndSanitizeFileName(filename, stringToWhitelistArray(whitelist));
    }

	/**
	 * checks and sanitizes a file against a provided whitelist.
	 *
	 * @param filename - The filename to sanitize
	 * @return The original file name with non-letters, non-numbers, and - and . replaced with _
	 * @throws InvalidFileTypeException - if the filename extension does not match the whitelist.
	 */
public static String checkAndSanitizeFileName(String filename, String [] whitelist) throws InvalidFileTypeException {
		String name = getName(filename);
		if (isNotWhitelisted(filename, whitelist)) {
			throw new InvalidFileTypeException("File type is not supported.");
		}
		name = name.replaceAll("[^a-zA-Z0-9.-]", "_");
		return name;
	}

	/**
	 * checks and sanitizes a file against our default whitelist.
	 *
	 * @param filename - the file name to test against the default whitelist
	 * @return
	 * @throws InvalidFileTypeException - if the whitelist is null.
	 */
	public static String checkAndSanitizeFileName(String filename) throws InvalidFileTypeException {
		return checkAndSanitizeFileName(filename, defaultWhitelist);
	}

	/**
	 * removed all characters that not letters, numbers, "." , or "-" from the file name and replaces them with "_"
	 * NOTE: see docs for getName(). It removes path stuff (i.e. // , ..)
	 *
	 * @param filename - file name to be cleaned
	 * @return
	 */
	public static String sanitizeFileName(String filename) {
		return getName(filename).replaceAll("[^a-zA-Z0-9.-]", "_");
	}

    /**
     * Tests if a filename's extension is whitelisted.
     *
     * @param filename
     *            The filename to test.
     * @param whitelist
     *            A comma-or-whitespace separated list of filename extensions.
     * @return {@code true} if the filename's extension matches one of the
     *         whitelisted options, {@code false} otherwise.
     */
    public static boolean isWhitelisted(String filename, String whitelist)
    {
        return isWhitelisted(filename, stringToWhitelistArray(whitelist));
    }

	/**
	 * Tests a filename's extension to see if it is whitelisted.
	 *
	 * @param filename - the name of the file's extension we are testing against the whitelist
	 * @param whitelist - a custom provided whitelist.
	 * @return true if the file's extension IS whitelisted.
	 * @throws IllegalArgumentException - if the whitelist provided is null.
	 */
	public static boolean isWhitelisted(String filename, String [] whitelist) throws IllegalArgumentException {
		if(whitelist == null){
			throw new IllegalArgumentException("No whitelist specified.");
		}
		for (String extension : whitelist)
			if (StringUtils.equalsIgnoreCase(CBESFilenameUtils.getExtension(filename), extension))
				return true;
		return false;
	}

	/**
	 * Tests a filename's extension to see if it is whitelisted.
	 *
	 * @param filename
	 * @return true if the file's extension IS whitelisted.
	 * @throws IllegalArgumentException - if the whitelist is null.
	 */
	public static boolean isWhitelisted(String filename) throws IllegalArgumentException {
		return isWhitelisted(filename, defaultWhitelist);
	};


	/**
	 * Tests a filename's extension to see if it is NOT whitelisted.
	 * @param filename - file name to test if the extension is NOT whitelisted.
	 * @return returns true if filename is NOT whitelisted.
	 */
	public static boolean isNotWhitelisted(String filename) {
		return !isWhitelisted(filename);
	}



	/**
	 * Tests a filename's extension to see if it is NOT whitelisted using a provided whitelist.
	 * @param whitelist - the whitelist to test against.
	 * @param filename - file name to test if the extension is NOT whitelisted.
	 * @return returns true if filename is NOT whitelisted.
	 */
	public static boolean isNotWhitelisted(String filename, String [] whitelist) {
		return !isWhitelisted(filename, whitelist);
	}

    public static boolean isNotWhitelisted(String filename, String whitelist)
    {
        return isNotWhitelisted(filename, stringToWhitelistArray(whitelist));
    }
}

