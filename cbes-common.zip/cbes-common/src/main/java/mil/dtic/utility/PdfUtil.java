/*
 * $Id$
 */
package mil.dtic.utility;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;

import com.Ostermiller.util.CircularByteBuffer;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.exceptions.InvalidPdfException;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopyFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfGState;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.jb.EmbedableFile;

public class PdfUtil {
    private static final Logger log = CbesLogFactory.getLog(PdfUtil.class);
    private static final String _B4_WATER_MARK = "_b4watermark";
    
    public static final float MAXIMUM_PDF_Y_DIMENSION = 11.01f;
    public static final float MAXIMUM_PDF_X_DIMENSION = 8.51f;

    public static boolean isPdf(File pdfFile) {
        PdfReader pdfReader = null;
        
        try {
            pdfReader = new PdfReader(pdfFile.getAbsolutePath());
            pdfReader.getNumberOfPages();
            return true;
        }
        catch (IOException e) {
            log.error("Bad PDF file", e);
            return false;
        }
    }

    public static boolean isSecured(File pdfFile) {
        PdfReader pdfReader = null;
        try {
            pdfReader = new PdfReader(pdfFile.getAbsolutePath());
            return !pdfReader.isOpenedWithFullPermissions();
        }
        catch (IOException e) {
            log.error("Bad PDF file", e);
            return false;
        }
    }

    public static int getNumberOfPagesInPdf(File pdfFile) throws IOException {
        PdfReader pdfReader = new PdfReader(pdfFile.getAbsolutePath());
        int numberOfPages = pdfReader.getNumberOfPages();
        return numberOfPages;
    }

    public static int getNumberOfPagesInPdf(String pdfFilePath) throws IOException {
        PdfReader pdfReader = new PdfReader(pdfFilePath);
        int numberOfPages = pdfReader.getNumberOfPages();
        return numberOfPages;
    }

    public static boolean attachFileToPdf(InputStream srcPdfInputStream, OutputStream destPdfOutputStream, List<EmbedableFile> fileToEmbedList, List<HashMap<String, Object>> bookmarkList) {
        boolean success = false;
        PdfReader pdfReader = null;
        PdfStamper pdfStamper = null;

        try {
            srcPdfInputStream = getCleanPdf(srcPdfInputStream);
            pdfReader = new PdfReader(srcPdfInputStream);
            pdfStamper = new PdfStamper(pdfReader, destPdfOutputStream);
            if (fileToEmbedList != null) {
                for (EmbedableFile fileToEmbed : fileToEmbedList) {
                    if (fileToEmbed.getObjectToEmbed() != null) {
                        log.debug("Embedding into PDF the byte array from " + fileToEmbed);
                        pdfStamper.addFileAttachment(fileToEmbed.getDisplayDescription(), fileToEmbed.getObjectToEmbed(), null, fileToEmbed.getDisplayFileName());
                    }
                    else{
                        log.debug("Embedding into PDF the file from " + fileToEmbed);
                        pdfStamper.addFileAttachment(fileToEmbed.getDisplayDescription(), null, fileToEmbed.getFileLocation(), fileToEmbed.getDisplayFileName());
                    }
                }
            }
          
            if (bookmarkList != null){
                pdfStamper.setOutlines(bookmarkList);
                pdfStamper.setViewerPreferences(PdfWriter.PageModeUseOutlines);
            }
      
            pdfStamper.setViewerPreferences(PdfWriter.PageModeUseAttachments);
            pdfStamper.setXmpMetadata(null);
            success = true;
        }
        catch (IOException | DocumentException e){
            log.error("Failed to attach embedable file list " + fileToEmbedList + " to pdf file input stream.", e);
        }
        finally {
            success &= closePdfStamper(pdfStamper);
            closePdfReader(pdfReader);
            success &= FileUtil.close(destPdfOutputStream);
        }
      
        return success;
    }


    public static boolean attachFileToPdf(File pdfFile, List<EmbedableFile> fileToEmbedList) {
        return attachFileToPdf(pdfFile, fileToEmbedList, null);
    }

    public static boolean attachFileAndBookmarksToPdf(File pdfFile, List<EmbedableFile> fileToEmbedList, List<HashMap<String, Object>> bookmarkList) {
        return attachFileToPdf(pdfFile, fileToEmbedList, bookmarkList);
    }

    private static boolean attachFileToPdf(File pdfFile, List<EmbedableFile> fileToEmbedList, List<HashMap<String, Object>> bookmarkList) {
        boolean success = false; 
        InputStream srcPdfInputStream = null;
        OutputStream destPdfOutputStream = null;
        try {
            srcPdfInputStream = new BufferedInputStream(new FileInputStream(pdfFile));
            File tmpFile = new File(pdfFile.getAbsolutePath() + "_attach");
            destPdfOutputStream = new BufferedOutputStream(new FileOutputStream(tmpFile));
            success = attachFileToPdf(srcPdfInputStream, destPdfOutputStream, fileToEmbedList, bookmarkList);

            if (success){
                boolean renamed = tmpFile.renameTo(pdfFile);
                if (!renamed) {
                    Path target = Paths.get(pdfFile.getAbsolutePath());
                    Path source = Paths.get(tmpFile.getAbsolutePath());
                    try {
                        Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
                        log.debug("successfully copied " + source.toString() + " to: " + target.toString());
                    }
                    catch(IOException e) {
                        log.error("failed to copy " + source.toString() + " to: " + target.toString());
                        success = false;
                    }
                }
            }
        }
        catch (FileNotFoundException e) {
            log.error("Failed to attach file as " + fileToEmbedList + " to pdf file.", e);
        }
        finally {
            success &= FileUtil.close(srcPdfInputStream);
            success &= FileUtil.close(destPdfOutputStream);
        }
      
        return success;
    }

    public static boolean applyPdfProperties(File pdfFile, HashMap<String, String> docProps, int securityProps, String budgetCycle, int budgetYear) {
        boolean success = false;
        InputStream srcPdfInputStream = null;
        OutputStream destPdfOutputStream = null;
        PdfReader pdfReader = null;
        PdfStamper pdfStamper = null;
        File tmpFile = null;

        try {
            log.debug("Applying document properties & security to " + pdfFile);
            srcPdfInputStream = new BufferedInputStream(new FileInputStream(pdfFile));
            tmpFile = new File(pdfFile.getAbsolutePath() + "_props");
            destPdfOutputStream = new BufferedOutputStream(new FileOutputStream(tmpFile));

            pdfReader = new PdfReader(srcPdfInputStream);
            pdfStamper = new PdfStamper(pdfReader, destPdfOutputStream);

            Map<String, String> props = pdfStamper.getMoreInfo();
            if (props == null){
                props = docProps;
            }
            else if (docProps != null){
                props.putAll(docProps);
            }
            
  
            
            log.debug("Applying document properties to " + pdfFile + " : " + docProps);
            pdfStamper.setMoreInfo(props);

            if (securityProps != Constants.PDF_ALL_PERMISSIONS) {
                log.debug("Applying security properties to " + pdfFile + " : " + securityProps);
                
                // Apply security constraints: 1) disallow changes, 2) use random string for password
                boolean passwordEnabled = BudgesContext.getConfigService().getJbPdfPasswordEnable(budgetCycle, budgetYear);
                if (passwordEnabled) {
                    log.debug("#### apply password to PDF for cycle/year: " + budgetCycle + "/" + budgetYear);
                    pdfStamper.setEncryption(PdfWriter.STANDARD_ENCRYPTION_40, null, BudgesContext.getConfigService().
                    getJbPdfPassword(budgetCycle, budgetYear), Constants.PDF_READ_ONLY_PERMISSIONS);
                }
                else
                    log.debug("#### password NOT applied to PDF");
                }

                success = true;
        }
        catch (IOException | DocumentException e) {
            log.error("Failed to apply document & security properties to " + pdfFile, e);
        }
        finally {
            success &= closePdfStamper(pdfStamper);
            if (success && tmpFile != null) {
                tmpFile.renameTo(pdfFile);
            }
            
            closePdfReader(pdfReader);
            success &= FileUtil.close(srcPdfInputStream);
            success &= FileUtil.close(destPdfOutputStream);
        }
        
        return success;
    }


    public static InputStream getCleanPdf(InputStream is) throws DocumentException, IOException {
        CircularByteBuffer cbb = new CircularByteBuffer(CircularByteBuffer.INFINITE_SIZE);
        PdfCopyFields pdfCopyFields = null;
        PdfReader pdfReader = null;
        OutputStream os = null;
        try {
            os = cbb.getOutputStream();
            pdfCopyFields = new PdfCopyFields(os);
            pdfCopyFields.open();
            pdfReader = new PdfReader(is);
            pdfCopyFields.addDocument(pdfReader);
        }
        finally {
            closePdfCopyFields(pdfCopyFields);
            FileUtil.close(os);
            FileUtil.close(is);
        }

        return cbb.getInputStream();
    }

    public static void addWatermarkToPdf(String watermark, String pdfFileName, boolean cleanPdfFirst, boolean isTrackingHeader) throws DocumentException, IOException {
        addWatermarkToPdf(watermark, new File(pdfFileName), cleanPdfFirst, isTrackingHeader);
    }

    public static void addWatermarkToPdf(String watermark, File pdfFile, boolean cleanPdfFirst, boolean isTrackingHeader) throws DocumentException, IOException {
        File outputFile = new File(pdfFile.getAbsolutePath() + PdfUtil._B4_WATER_MARK);
        InputStream pdfInputStream = null;
        FileInputStream fis = null;
        BufferedInputStream bis = null;

        try {
            if (cleanPdfFirst) {
                fis = new FileInputStream(pdfFile);
                bis = new BufferedInputStream(fis);
                pdfInputStream = getCleanPdf(bis);  
            }
            else {
                pdfInputStream = new FileInputStream(pdfFile);
            }
            
            addWatermarkToPdf(watermark, pdfInputStream, new BufferedOutputStream(new FileOutputStream(outputFile)), isTrackingHeader);

            // Sun #4017593 - you have to explicitly delete on windows
            if (!pdfFile.delete()){
                log.debug("Could not delete unwatermarked pdf " + pdfFile);
            }

            if (!outputFile.renameTo(pdfFile)) {
                throw new RuntimeException("Could not rename file after adding watermark, watermark/file: " + watermark + " / " + pdfFile.getAbsolutePath());
            }
        }
        finally {
            //TODO: need to implement a Closeable so we don't need to embed finally inside finallys
            try {
                if (fis != null) {
                    fis.close();
                }
            }
            finally {
                try {
                    if (bis != null) {
                        bis.close();
                    }
                }
                finally {
                    if (pdfInputStream != null) {
                         pdfInputStream.close();
                    }
                }
            }
        }
    }

    public static void addWatermarkToPdf(String watermark, InputStream pdfInputStream, OutputStream os, boolean isTrackingHeader) throws IOException, DocumentException {
        PdfReader pdfReader = null;
        PdfStamper pdfStamper = null;
        try {
            pdfReader = new PdfReader(pdfInputStream);
            pdfStamper = new PdfStamper(pdfReader, os);
            for (int currPageIndex = 1; currPageIndex <= pdfReader.getNumberOfPages(); ++currPageIndex) {
                PdfContentByte pdfOverContentByte = pdfStamper.getOverContent(currPageIndex);
            
                if(isTrackingHeader) {
                    addTrackingHeaderToPdfPage(watermark, pdfReader.getPageSizeWithRotation(currPageIndex), pdfOverContentByte);
                }
                else {
                    addWatermarkToPdfPage(watermark, pdfReader.getPageSizeWithRotation(currPageIndex), pdfOverContentByte);
                }
            }
        }
        finally {
            closePdfStamper(pdfStamper);
            FileUtil.close(os);
            FileUtil.close(pdfInputStream);
        }
    }

    public static void addWatermarkToPdfPage(String watermark, Rectangle pageSizeRectangle, PdfContentByte pdfOverContentByte) {
        float watermarkWidth = XmlUtil.getBaseFont().getWidthPoint(watermark, 80f);
        float watermarkHeight = XmlUtil.getBaseFont().getAscentPoint(watermark, 80f);

        pdfOverContentByte.saveState();
        
        PdfGState gState = new PdfGState();
        gState.setFillOpacity(0.1f);
        
        pdfOverContentByte.beginText();
        pdfOverContentByte.setGState(gState);
        pdfOverContentByte.setFontAndSize(XmlUtil.getBaseFont(), 80);
        pageSizeRectangle.setBackgroundColor(new BaseColor(0xDD, 0xDD, 0xDD));
        pdfOverContentByte.showTextAligned(Element.ALIGN_LEFT, watermark, pageSizeRectangle.getWidth() - pageSizeRectangle.getWidth() / 2 - watermarkWidth / 2, pageSizeRectangle.getHeight() / 2 - watermarkHeight / 2, 0);
        pdfOverContentByte.endText();
        pdfOverContentByte.restoreState();
    }
    
    public static void addWorkFlowStatusToPdfPage(String workFlowStatus, Rectangle pageSizeRectangle, PdfContentByte pdfUnderContentByte) {
        if (!JBookWorkFlowStatus.valueOf(workFlowStatus).getProcess()) {
            return;
        }
        
        String displayValue =JBookWorkFlowStatus.valueOf(workFlowStatus).getDisplayName();
        float workFlowStatusWidth = XmlUtil.getBaseFont().getWidthPoint(displayValue, 15f); //34 - 125
        float workFlowStatusHeight = XmlUtil.getBaseFont().getAscentPoint(displayValue, 15f); //11
            
        pdfUnderContentByte.beginText();
        pdfUnderContentByte.setFontAndSize(XmlUtil.getBaseFont(), 10);
        pageSizeRectangle.setBackgroundColor(BaseColor.BLACK);
            
        if (workFlowStatusWidth < pageSizeRectangle.getWidth()) {  //792.0
            float showWidth = pageSizeRectangle.getWidth() - pageSizeRectangle.getWidth() / 2 - workFlowStatusWidth / 2; //366.4125
            float showHeight = pageSizeRectangle.getHeight() - pageSizeRectangle.getHeight() / 16 - workFlowStatusHeight / 2; //568.365
            pdfUnderContentByte.showTextAligned(Element.ALIGN_LEFT, displayValue, showWidth/10, showHeight, 0);
        }
        else{
            // this can't happen since we control the size of the text in the UI.
            // but just in case it does happen, we won't execute the stamp and log an exception indicating the issue.
            log.error("PdfUtil.addWorkFlowStatusToPdfPage aborted as workFlowStatusWidth: " + workFlowStatusWidth + " is equal or greater than pageWidth: " +  pageSizeRectangle.getWidth());
        }
        
        pdfUnderContentByte.endText();
    }
    
    public static void addTrackingHeaderToPdfPage(String trackingHeader, Rectangle pageSizeRectangle, PdfContentByte pdfUnderContentByte) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
        String headerLabel = "Generated: " + dateFormat.format(new Date()) + ", Editor's Note: ";
        String fullTrackingHeader = headerLabel + trackingHeader;
        float watermarkWidth = XmlUtil.getBaseFont().getWidthPoint(fullTrackingHeader, 10f);
        float watermarkHeight = XmlUtil.getBaseFont().getAscentPoint(fullTrackingHeader, 10f);
        float labelWidth = XmlUtil.getBaseFont().getWidthPoint(headerLabel, 10f);
        float headerWidth = XmlUtil.getBaseFont().getWidthPoint(trackingHeader, 10f);
        pdfUnderContentByte.beginText();
        pdfUnderContentByte.setFontAndSize(XmlUtil.getBaseFont(), 10);
        pageSizeRectangle.setBackgroundColor(new BaseColor(0xDD, 0xDD, 0xDD));
        if (watermarkWidth < pageSizeRectangle.getWidth()) {
            pdfUnderContentByte.showTextAligned(Element.ALIGN_LEFT, fullTrackingHeader, pageSizeRectangle.getWidth() - pageSizeRectangle.getWidth() / 2 - watermarkWidth / 2, pageSizeRectangle.getHeight() - pageSizeRectangle.getHeight() / 16 - watermarkHeight / 2, 0);
        }
        else {
            int breakIndex = trackingHeader.length()/2;
            int spaceBeforeBreak = trackingHeader.substring(0,breakIndex).lastIndexOf(" ");
            int spaceAfterBreak = trackingHeader.substring(breakIndex).indexOf(" ");
            if (spaceAfterBreak == -1) {
                spaceAfterBreak = 101; //set to 101 because of the math to determine the line break in the if clauses below. 101 is basically the equivalent to an indexOf being -1 in the second half of the tracking header in this case.
            }
            else {
                spaceAfterBreak = spaceAfterBreak + breakIndex;
            }
        
            String firstLine, secondLine;
        
            if (((spaceAfterBreak - breakIndex) < (breakIndex - spaceBeforeBreak)) && ((spaceAfterBreak - breakIndex) < 8 )) {
                firstLine = headerLabel + trackingHeader.substring(0, spaceAfterBreak);
                secondLine = trackingHeader.substring(spaceAfterBreak+1);
            }
            else if (((breakIndex - spaceBeforeBreak) < (spaceAfterBreak - breakIndex)) && ((breakIndex - spaceBeforeBreak) < 8))  {
                firstLine = headerLabel + trackingHeader.substring(0, spaceBeforeBreak);
                secondLine = trackingHeader.substring(spaceBeforeBreak+1);
            }
            else {
                firstLine = headerLabel + trackingHeader.substring(0, breakIndex) + "-";
                secondLine = trackingHeader.substring(breakIndex);
            }
            pdfUnderContentByte.showTextAligned(Element.ALIGN_LEFT, firstLine, pageSizeRectangle.getWidth() - pageSizeRectangle.getWidth() / 2 - headerWidth / 6 - labelWidth, pageSizeRectangle.getHeight() - pageSizeRectangle.getHeight() / 16 - watermarkHeight / 8, 0);
            pdfUnderContentByte.showTextAligned(Element.ALIGN_LEFT, secondLine, pageSizeRectangle.getWidth() - pageSizeRectangle.getWidth() / 2 - headerWidth / 6, pageSizeRectangle.getHeight() - pageSizeRectangle.getHeight() / 16 - ((5*watermarkHeight)/4), 0);
        }
        pdfUnderContentByte.endText();
    }

    public static void concatPdfs(File outputFile, List<String> concatFileNameList) throws DocumentException, IOException {
        for (String fileName : concatFileNameList) {
            log.trace(" - " + fileName);
        }

        OutputStream pdfOutputStream = null;
        PdfCopyFields pdfCopyFields = null;
        try {
            log.debug("About to concatenate PDF documents...");
            pdfOutputStream = new BufferedOutputStream(new FileOutputStream(outputFile));
            pdfCopyFields = new PdfCopyFields(pdfOutputStream);
            pdfCopyFields.open();

            for (String concatFileName : concatFileNameList) {
                log.debug("Concatenating file " + concatFileName + " to " + outputFile.getAbsolutePath());
                PdfReader pdfReader = new PdfReader(concatFileName);
                pdfCopyFields.addDocument(pdfReader);
            }
        }
        catch(InvalidPdfException ipe){
            log.error("XML contains errors.", ipe);
        }
        finally{
            PdfUtil.closePdfCopyFields(pdfCopyFields);
            FileUtil.close(pdfOutputStream);
        }
        log.debug("Finished concatenating PDF into " + outputFile.getAbsolutePath());
    }

    public static void closePdfCopyFields(PdfCopyFields pdfCopyFields) {
        if (pdfCopyFields != null){
            pdfCopyFields.close();
        }
    }

    public static void closePdfReader(PdfReader pdfReader) {
        if (pdfReader != null){
            pdfReader.close();
        } 
    }


    public static boolean closePdfStamper(PdfStamper pdfStamper) {
        boolean success = true;
        try {
            if (pdfStamper != null) {
                pdfStamper.close();
            }
        }
        catch (IOException | DocumentException e) {
            log.error("Failed to close PdfStamper.", e);
            success = false;
        }
        return success;
    }

    /**
     * Helper method for the page sizes. It will take width/height
     * of a page in inches as a float and determine if the page is the correct dimensions.
     * @param width
     * @param height
     * @return
     */
    public static boolean pageCorrectDimensions(float width, float height){
        if (width <= MAXIMUM_PDF_X_DIMENSION && height <= MAXIMUM_PDF_Y_DIMENSION){
            return true;
        }
        else if (height <= MAXIMUM_PDF_X_DIMENSION && width <= MAXIMUM_PDF_Y_DIMENSION){
            return true;
        }

        return false;
    }
}
