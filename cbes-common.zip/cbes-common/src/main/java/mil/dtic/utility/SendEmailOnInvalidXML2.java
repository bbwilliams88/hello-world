/*
 * $Id: XmlUtil.java 32173 2009-08-24 16:40:16Z aibrahim $
 */
package mil.dtic.utility;

import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;


/** Dumber version of R2 class that does not log user name/phone/etc */
public class SendEmailOnInvalidXML2 implements InvalidXMLListener
{
  private static final Logger log = CbesLogFactory.getLog(SendEmailOnInvalidXML2.class);

  public void onInvalidXML(String root, String msg, String xmlFileName)
  {
    try
    {
        BudgesContext.getEmailUtil().sendSystemEmail("*** XML Validation Failure Notice [" + root + "] ***", msg.toString());
      log.info("Invalid XML file written to: " + xmlFileName);
    }
    catch (EmailException e)
    {
      log.error("Could not send failed XML validation email", e);
    }
  }
}
