/*
 * $Id: BudgesResourceResolver.java 41458 2010-05-21 21:45:06Z aibrahim $
 */
package mil.dtic.utility;

import java.io.InputStream;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.w3c.dom.ls.LSInput;

public class BudgesClasspathXmlSchemaResourceResolver extends BudgesXmlSchemaResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesClasspathXmlSchemaResourceResolver.class);


  public BudgesClasspathXmlSchemaResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public LSInput resolveResource(String type, String namespaceURI, String publicId, final String systemId, String baseURI)
  {
    log.trace("Looking for classpath XSLT resource, type: " + type +
      ", namespaceURI: " + namespaceURI +
      ", publicId: " + publicId +
      ", systemId: " + systemId +
      ", baseURI: " + baseURI);

    return new BudgesLSInput()
    {

      @Override
      public InputStream getByteStream()
      {
        // Remove all references to "../" from systemId.
        // THIS IS A HACK TO GET AROUND THE CLASSLOADER NOT LIKING "../".
        // BUT SHOULD WORK SINCE WE HAVE ALL PATHS IN PathList AND WE'LL SEARCH
        // EACH FOR THE RESOURCE.
        String cleanSystemId = Util.cleanupClasspathResourceRef(systemId);
        return Util.getResourceFromClassPath(getPathList(), cleanSystemId);
      }
    };
  }


}
