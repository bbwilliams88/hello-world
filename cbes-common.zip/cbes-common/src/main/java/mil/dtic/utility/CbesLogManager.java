package mil.dtic.utility;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

public class CbesLogManager {
  // Map to hold all loggers
  private HashMap<String, Logger> loggerMap;

  // List of possible log levels
  private final Level[] levels = {Level.ALL, Level.TRACE, Level.DEBUG, Level.INFO,  Level.WARN, Level.ERROR, Level.FATAL, Level.OFF};

  /**
   * @brief Constructor. Initialize the logger map.
   */
  public CbesLogManager()
  {
    this.loggerMap = new HashMap<>();  
  }

  /**
   * @brief Set the log level of the given logger using the Configurator
   * 
   * @param loggerName Name of logger to set log level
   * @param logLevel new log level
   */
  public void setLogLevel(String loggerName, Level logLevel) {
	  Configurator.setLevel(loggerName, logLevel);
  }

  /**
   * @brief Get the log level of the given logger
   * 
   * @param loggerName Name of logger to get log level of
   * 
   * @return Level of given logger, null if given logger does not exist
   */
  public Level getLogLevel(String loggerName) {
	  return loggerMap.get(loggerName).getLevel();
  }

  /**
   * @brief Put given logger in loggerMap 
   * 
   * @param logger Logger to put into loggerMap
   */
  public void addLogger(Logger logger) {
    loggerMap.put(logger.getName(), logger);
  }

  /**
   * @brief Get the logger with the provided name
   * 
   * @param loggerName name of logger to get
   * 
   * @return Logger object with provided name, else null if logger does not exist
   */
  public Logger getLoggerByName(String loggerName) {
	  return loggerMap.get(loggerName);
  }

  /**
   * @brief Get all loggers in loggerMap
   * 
   * @return list of loggers
   */
  public List<Logger> getCurrentLoggers() {
	  return new ArrayList<Logger>(loggerMap.values());
  }

  /**
   * @brief Set all loggers to provided level
   * 
   * @param level Level to set all loggers to
   */
  public void setAllLogLevels(Level level)  {
    for (String loggerName : loggerMap.keySet())
    {
      Configurator.setLevel(loggerName, level);
    }
  }

  /**
   * @brief Get list of possible log levels
   * 
   * @return levels, list of log levels
   */
  public Level[] getAvailableLogLevels() {
	  return this.levels;
  }
  
}
