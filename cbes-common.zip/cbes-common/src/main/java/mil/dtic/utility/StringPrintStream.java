package mil.dtic.utility;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * PrintStream which forwards messages to an internal StringBuffer.
 */
public class StringPrintStream extends PrintStream
{
  /** record the last character written to this stream */
  private int last = -1;

  /** stream used for buffering lines */
  private final ByteArrayOutputStream bufOut;

  private final StringBuffer stringBuffer = new StringBuffer(1024);
  
  public StringPrintStream()
  {
    super(new ByteArrayOutputStream());
    bufOut = (ByteArrayOutputStream) super.out;
  }

  public void write(int b) {
    if ((last == '\r') && (b == '\n')) {
      last = -1;
      return;
    } else if ((b == '\n') || (b == '\r')) {
      try {
        /* write the converted bytes of the log message */
        String message =
          Thread.currentThread().getName() + ": " +
          bufOut.toString();
        stringBuffer.append(message);
        stringBuffer.append("\n");
      } finally {
        bufOut.reset();
      }
    } else {
      super.write(b);
    }
    last = b;
  }

  public void write(byte b[], int off, int len) {
    if (len < 0) {
      throw new ArrayIndexOutOfBoundsException(len);
    }
    for (int i = 0; i < len; i++) {
      write(b[off + i]);
    }
  }

  public String toString() {
    return stringBuffer.toString();
  }
}