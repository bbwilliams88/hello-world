/*
 * $Id$
 */
package mil.dtic.utility;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.BoundedInputStream;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.commandline.CommandLineService;
import mil.dtic.utility.commandline.CommandLineServiceFactory;

public class CmdLineUtil
{
  private static final Logger log = CbesLogFactory.getLog(CmdLineUtil.class);
  private static final int CXE_PROCESS_TIMEOUT_IN_MINUTES = 15;
  private static final long MAX_IO_BYTES = 5*1024*1024;

  public static boolean runCmd(String command, String... arguments)
  {
    if (BudgesContext.getConfigService().getDisableRmi())
      return runCmdRuntime(command, arguments);
    else
      return runCmdRmi(command);
  }

    /**
     * @param command
     *            Command to execute. If there are spaces, the assumption is the
     *            value came from the DB and includes command-line arguments and
     *            these arguments will be automatically be split on spaces. If
     *            the arguments are complex (in double/single quotes with spaces
     *            between), this will fail and you will have a bad day. Those
     *            need to be passed in via the arguments parameter.
     * @param arguments
     * @return
     */
    public static boolean runCmdRuntime(String command, String... arguments)
    {
        boolean success = false;

        if (StringUtils.isNotEmpty(command))
        {
            String[]      commandAndArguments = ArrayUtils.addAll(StringUtils.split(command), arguments);
            StringBuilder commandLine         = new StringBuilder("[").append(StringUtils.join(commandAndArguments, " ")).append("]");
            StringBuilder stringBuilder       = new StringBuilder("Command Executed: ").append(commandLine);

            try
            {
                log.info("Executing:");
                for (String commandLineComponent : commandAndArguments)
                    log.debug("    [" + commandLineComponent + "]");

                Process process  = Runtime.getRuntime().exec(commandAndArguments);
                boolean finished = process.waitFor(CXE_PROCESS_TIMEOUT_IN_MINUTES, TimeUnit.MINUTES);

                if (finished == false)
                    log.error("Process terminated after timed out.");

                if (stringBuilder.length() > 0)
                    stringBuilder.append("\n");

                stringBuilder.append("\nstderr: \n");

                try (BoundedInputStream boundedInput = new BoundedInputStream(process.getErrorStream(), MAX_IO_BYTES))
                {
                    String stderr = IOUtils.toString(boundedInput);
                    stringBuilder.append(stderr);
                    stringBuilder.append("\n");
                }
                catch (IOException e)
                {
                    log.error("Could not read stderr", e);
                }

                stringBuilder.append("\nstdout: \n");

                try (BoundedInputStream boundedInput = new BoundedInputStream(process.getInputStream(), MAX_IO_BYTES))
                {
                    String stdout = IOUtils.toString(boundedInput);
                    stringBuilder.append(stdout);
                    stringBuilder.append("\n");
                }
                catch (IOException e)
                {
                    log.error("Could not read stdout", e);
                }

                stringBuilder.append("exit code = ").append(process.exitValue()).append(" for ").append(commandLine);
                success = (process.exitValue() == 0 && finished);
            }
            catch (IOException  | InterruptedException e)
            {
                log.error("Failed to execute command: " + commandLine, e);
                throw new RuntimeException(e);
            }
            finally
            {
                log.info("Commmand Execution Results:\n" + stringBuilder);
            }
        }

        return success;
    }

  private static boolean runCmdRmi(String command)
  {
    boolean success = false;

    if (StringUtils.isNotEmpty(command))
    {
      CommandLineService service = null;

      try
      {
        log.info("Executing command line:" + command);
        service = CommandLineServiceFactory.newCommandLineService();
        success = service.executeCommand(command);
      }

      // FIXME: Mike Gentry: " there is a cbes-misc/rmi/dist/javadoc/mil/dtic/utility/commandline/CommandLineService.html  .. we shouldn't be using this i don't think"
      // see:  https://commons.apache.org/proper/commons-exec/apidocs/org/apache/commons/exec/CommandLine.html
      catch (Exception e) // Catching the raw Exception thrown from executeCommand() until we replace it.
      {
        log.error("Failed to execute command line: " + command, e);
        throw new RuntimeException(e);
      }
      finally
      {
        if (service != null)
        {
          StringBuilder sb = new StringBuilder();
          sb.append("Command line execution results for: " + command);
          sb.append("\nExit Code: " + service.getExitValue());
          sb.append("\nStdout:\n" + service.getStdout());
          sb.append("\nStderr:\n" + service.getStderr());
          log.error(sb);
        }
      }

    }
    return success;
  }
}
