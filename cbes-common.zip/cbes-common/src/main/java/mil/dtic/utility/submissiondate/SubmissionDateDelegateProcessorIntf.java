package mil.dtic.utility.submissiondate;

import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;

public interface SubmissionDateDelegateProcessorIntf {
    
    void processForDelegate(PreviewResultInfo previewResultInfo);
    
}
