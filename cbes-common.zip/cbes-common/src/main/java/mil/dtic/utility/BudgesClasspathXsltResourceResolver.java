/*
 * $Id: BudgesURIResolver.java 63662 2011-12-23 18:03:36Z aibrahim $
 */
package mil.dtic.utility;

import java.io.InputStream;
import java.util.List;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.apache.logging.log4j.Logger;

public class BudgesClasspathXsltResourceResolver extends BudgesXsltResourceResolver
{
  private static final Logger log = CbesLogFactory.getLog(BudgesClasspathXsltResourceResolver.class);


  public BudgesClasspathXsltResourceResolver(List<String> pathList)
  {
    super(pathList);
  }


  @Override
  public Source findResource(String href, String base)
  {
    href = Util.cleanupClasspathResourceRef(href);
    InputStream is = null;
    ClassLoader cl = BudgesClasspathXsltResourceResolver.class.getClassLoader();
    for (String path : getPathList())
    {
      log.trace("Looking for classpath resource (base:href) '" + base + ":" + href + "' at " + path);
      if ((is = cl.getResourceAsStream(path + href)) != null)
      {
        log.trace("Found classpath resource (base:href) '" + base + ":" + href + "' at " + path);
        //the input stream will be closed in BudgesXslCache
        return new StreamSource(is);
      }
    }
    log.debug("Did not find classpath resource (base:href) '" + base + ":" + href + "'");
    return null;
  }
}
