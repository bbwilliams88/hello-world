/*
 * $Id: BudgesJbUploadFile.java $
 */
package mil.dtic.utility;

import mil.dtic.cbes.p40.vo.JbVolume;

public class BudgesJbUploadFile extends BudgesJbFile
{
  private Object uploadFile;

  public BudgesJbUploadFile()
  {
    super();
  }

  public BudgesJbUploadFile(JbVolume jbVolume)
  {
    super(jbVolume);
  }


  public Object getUploadFile()
  {
    return uploadFile;
  }


  public void setUploadFile(Object uploadFile)
  {
    this.uploadFile = uploadFile;
  }

}
