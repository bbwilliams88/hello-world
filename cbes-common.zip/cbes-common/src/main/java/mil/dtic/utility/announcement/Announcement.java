package mil.dtic.utility.announcement;

import javax.annotation.concurrent.Immutable;

import mil.dtic.utility.announcement.options.Audience;

@Immutable
public class Announcement {
    
    private final Audience audience;
    private final String emails;
    private final String subject;
    private final String content;
    private final String senderEmail;
    
    public Announcement(Audience audience, String emails, String subject, String content, String senderEmail){
        this.audience = audience;
        this.emails = emails;
        this.subject = subject;
        this.content = content;
        this.senderEmail = senderEmail;
    }
    
    public Audience getAudience() {
        return audience;
    }
    
    public String getEmails() {
        return emails;
    }
    
    public String getSubject() {
        return subject;
    }
    
    public String getContent() {
        return content;
    }
    
    public String getSenderEmail() {
        return senderEmail;
    }
    
    @Override
    public String toString() {
        return "Announcement [audience=" + audience + ", emails=" + emails + ", subject=" + subject + ", content="
                + content + ", senderEmail=" + senderEmail + "]";
    }
    
    
    
}
