/*
 * $Id: XmlUtil.java 32173 2009-08-24 16:40:16Z aibrahim $
 */
package mil.dtic.utility;


public interface InvalidXMLListener
{
  public static InvalidXMLListener DO_NOTHING = new InvalidXMLListener(){ public void onInvalidXML(String root, String msg, String xmlFileName){} };
  
  public void onInvalidXML(String root, String msg, String xmlFileName);
}
