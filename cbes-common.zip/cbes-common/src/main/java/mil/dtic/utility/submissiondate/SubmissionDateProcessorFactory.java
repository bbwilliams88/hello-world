package mil.dtic.utility.submissiondate;

import mil.dtic.utility.submissiondate.synch.SubmissionDateDelegateProcessor;
import mil.dtic.utility.submissiondate.synch.SubmissionDateProcessor;

public class SubmissionDateProcessorFactory {
    
    public static SubmissionDateProcessorIntf getSubmissionDateProcessor(){
        return new SubmissionDateProcessor();
    }
    
    public static SubmissionDateDelegateProcessorIntf getSubmissionDateDelegateProcessor(){
        return new SubmissionDateDelegateProcessor();
    }
    
    
}
