package mil.dtic.utility;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.fop.FopFactoryWrapper;
import mil.dtic.cbes.p40.validation.LineItemListValidator;
import mil.dtic.cbes.p40.vo.JbVolume;
import mil.dtic.cbes.service.CacheService;
import mil.dtic.cbes.submissions.ValueObjects.BaseValueObject;
import mil.dtic.cbes.submissions.dao.AccomplishmentPlannedProgramDAO;
import mil.dtic.cbes.submissions.dao.AppropriationDAO;
import mil.dtic.cbes.submissions.dao.BudgesBaseDAO;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserAndProgramElementLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserAndServiceAgencyLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.BudgetActivityDAO;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.dao.CongressionalAddDetailDAO;
import mil.dtic.cbes.submissions.dao.ContractMethodDAO;
import mil.dtic.cbes.submissions.dao.ContractTypeDAO;
import mil.dtic.cbes.submissions.dao.CostCategoryGroupDAO;
import mil.dtic.cbes.submissions.dao.CostCategoryGroupNameDAO;
import mil.dtic.cbes.submissions.dao.CostCategoryItemDAO;
import mil.dtic.cbes.submissions.dao.FundingVehicleDAO;
import mil.dtic.cbes.submissions.dao.HealthCheckDAO;
import mil.dtic.cbes.submissions.dao.JointFundingDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.MajorPerformerDAO;
import mil.dtic.cbes.submissions.dao.OtherAdjustmentDetailDAO;
import mil.dtic.cbes.submissions.dao.OtherProgramFundingSummaryDAO;
import mil.dtic.cbes.submissions.dao.P1DataDAO;
import mil.dtic.cbes.submissions.dao.P1R1ServiceDao;
import mil.dtic.cbes.submissions.dao.PELockDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementBaseDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementListDAO;
import mil.dtic.cbes.submissions.dao.ProjectDAO;
import mil.dtic.cbes.submissions.dao.ProjectListDAO;
import mil.dtic.cbes.submissions.dao.R1DataDAO;
import mil.dtic.cbes.submissions.dao.R2ContractMethodTypeFundingVehicleDAO;
import mil.dtic.cbes.submissions.dao.RDTERuleStatusDAO;
import mil.dtic.cbes.submissions.dao.ScheduleDetailDAO;
import mil.dtic.cbes.submissions.dao.ScheduleProfileDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.dao.SubProjectScheduleDAO;
import mil.dtic.cbes.submissions.dao.SubmissionDateDAO;
import mil.dtic.cbes.submissions.dao.TerminationLiabilityDAO;
import mil.dtic.cbes.submissions.dao.UserProgramElementListDAO;
import mil.dtic.cbes.submissions.dao.ValidationExemptionDAO;
import mil.dtic.cbes.submissions.service.P1R1Service;
import mil.dtic.cbes.submissions.service.R2SelectionService;
import mil.dtic.cbes.submissions.service.SaveService;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.validation.backend.ValidationService;
import mil.dtic.cbes.xml.BudgesXslCache;
import mil.dtic.utility.samanage.service.api.AdminService;
import mil.dtic.utility.sourcepath.SourcePathManager;

public class BudgesContext
{

  public static BudgesXslCache getBudgesXslCache()
  {
    return SpringApplicationContext.getBean(BudgesXslCache.class);
  }


  public static FopFactoryWrapper getFopFactoryWrapper()
  {
    return (FopFactoryWrapper) SpringApplicationContext.getBean("fopFactoryWrapper");
  }

  public static AppDefaults getAppDefaults()
  {
    return (AppDefaults) SpringApplicationContext.getBean("appDefaults");
  }
  
  public static AdminService getAdminService(){
      return SpringApplicationContext.getBean(AdminService.class);
  }

  public static P1R1ServiceDao getP1R1ServiceDao()
  {
    return SpringApplicationContext.getBean(P1R1ServiceDao.class);
  } 
  
  public static P1R1Service getP1R1Service()
  {
    return SpringApplicationContext.getBean(P1R1Service.class);
  }

  public static ProgramElementListDAO getProgramElementListDAO()
  {
    return SpringApplicationContext.getBean(ProgramElementListDAO.class);
  }

  public static ProgramElementBaseDAO getProgramElementBaseDAO()
  {
    return SpringApplicationContext.getBean(ProgramElementBaseDAO.class);
  }

  public static ProgramElementDAO getProgramElementDAO()
  {
    return SpringApplicationContext.getBean(ProgramElementDAO.class);
  }

  public static SubmissionDateDAO getSubmissionDateDAO()
  {
    return SpringApplicationContext.getBean(SubmissionDateDAO.class);
  }

  public static ServiceAgencyDAO getServiceAgencyDAO()
  {
    return SpringApplicationContext.getBean(ServiceAgencyDAO.class);
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  public static AppropriationDAO getAppropriationDAO()
  {
    return createSimpleDAO(AppropriationDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("AppropriationDAO"));
  }

  public static ProjectListDAO getProjectListDAO()
  {
    return SpringApplicationContext.getBean(ProjectListDAO.class);
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static ProjectDAO getProjectDAO()
  {
    return createSimpleDAO(ProjectDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("ProjectDAO"));
  }


  public static BudgetActivityDAO getBudgetActivityDAO()
  {
    return SpringApplicationContext.getBean(BudgetActivityDAO.class);
  }


  @SuppressWarnings({"rawtypes", "unchecked"})
  public static OtherAdjustmentDetailDAO getOtherAdjustmentDetailDAO()
  {
    return createSimpleDAO(OtherAdjustmentDetailDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("OtherAdjustmentDetailDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static CongressionalAddDetailDAO getCongressionalAddDetailDAO()
  {
    return createSimpleDAO(CongressionalAddDetailDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("CongressionalAddDetailDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static AccomplishmentPlannedProgramDAO getAccomplishmentPlannedProgramDAO()
  {
    return createSimpleDAO(AccomplishmentPlannedProgramDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("AccomplishmentPlannedProgramDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static JointFundingDAO getJointFundingDAO()
  {
    return createSimpleDAO(JointFundingDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("JointFundingDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static OtherProgramFundingSummaryDAO getOtherProgramFundingSummaryDAO()
  {
    return createSimpleDAO(OtherProgramFundingSummaryDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("OtherProgramFundingSummaryDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static HealthCheckDAO getHealthCheckDAO()
  {
    return createSimpleDAO(HealthCheckDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("HealthCheckDAO"));
  }

  public static BudgesUserDAO getBudgesUserDAO()
  {
    return SpringApplicationContext.getBean(BudgesUserDAO.class);
  }

  public static BudgesUserAndProgramElementLinkDAO getBudgesUserAndProgramElementLinkDAO()
  {
    return SpringApplicationContext.getBean(BudgesUserAndProgramElementLinkDAO.class);
  }

  public static BudgesUserAndServiceAgencyLinkDAO getBudgesUserAndServiceAgencyLinkDAO()
  {
    return SpringApplicationContext.getBean(BudgesUserAndServiceAgencyLinkDAO.class);
  }

  public static CostCategoryGroupDAO getCostCategoryGroupDAO()
  {
    return SpringApplicationContext.getBean(CostCategoryGroupDAO.class);
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static CostCategoryGroupNameDAO getCostCategoryGroupNameDAO()
  {
    return createSimpleDAO(CostCategoryGroupNameDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("CostCategoryGroupNameDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static ContractMethodDAO getContractMethodDAO()
  {
    return createSimpleDAO(ContractMethodDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("ContractMethodDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static ContractTypeDAO getContractTypeDAO()
  {
    return createSimpleDAO(ContractTypeDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("ContractTypeDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static FundingVehicleDAO getFundingVehicleDAO()
  {
    return createSimpleDAO(FundingVehicleDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("FundingVehicleDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static CostCategoryItemDAO getCostCategoryItemDAO()
  {
    return createSimpleDAO(CostCategoryItemDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("CostCategoryItemDAO"));
  }


  public static BudgetCycleDAO getBudgetCycleDAO()
  {
    return SpringApplicationContext.getBean(BudgetCycleDAO.class);
  }


  public static LdapDAO getLdapDAO()
  {
    return SpringApplicationContext.getBean(LdapDAO.class);
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static MajorPerformerDAO getMajorPerformerDAO()
  {
    return createSimpleDAO(MajorPerformerDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("MajorPerformerDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static ScheduleProfileDAO getScheduleProfileDAO()
  {
    return createSimpleDAO(ScheduleProfileDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("ScheduleProfileDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static SubProjectScheduleDAO getSubProjectScheduleDAO()
  {
    return createSimpleDAO(SubProjectScheduleDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("SubProjectScheduleDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static ScheduleDetailDAO getScheduleDetailDAO()
  {
    return createSimpleDAO(ScheduleDetailDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("ScheduleDetailDAO"));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static TerminationLiabilityDAO getTerminationLiabilityDAO()
  {
    return createSimpleDAO(TerminationLiabilityDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("TerminationLiabilityDAO"));
  }

  public static PELockDAO getPELockDAO()
  {
    return SpringApplicationContext.getBean(PELockDAO.class);
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  public static RDTERuleStatusDAO getRDTERuleStatusDAO() {
    return createSimpleDAO(RDTERuleStatusDAO.class, (BudgesBaseDAO) SpringApplicationContext.getBean("RDTERuleStatusDAO"));
  }

  @SuppressWarnings({ "rawtypes", "unchecked" })
  public static ValidationExemptionDAO getValidationExemptionDAO()
  {
      return createSimpleDAO(ValidationExemptionDAO.class,
              (BudgesBaseDAO) SpringApplicationContext.getBean("ValidationExemptionDAO"));
  }

  public static BudgesJobDAO getBudgesJobDAO()
  {
    return SpringApplicationContext.getBean(BudgesJobDAO.class);
  }

  public static R2ContractMethodTypeFundingVehicleDAO getR2ContractMethodTypeFundingVehicleDAO()
  {
    return SpringApplicationContext.getBean(R2ContractMethodTypeFundingVehicleDAO.class);
  }
  
  public static R1DataDAO getR1DataDAO()
  {
    return SpringApplicationContext.getBean(R1DataDAO.class);
  }
  
  public static P1DataDAO getP1DataDAO()
  {
    return SpringApplicationContext.getBean(P1DataDAO.class);
  }

  public static ConfigDAO getConfigDAO()
  {
    return SpringApplicationContext.getBean(ConfigDAO.class);
  }

  public static ConfigService getConfigService()
  {
    return SpringApplicationContext.getBean(ConfigService.class);
  }

  public static SaveService getSaveService()
  {
    return SpringApplicationContext.getBean(SaveService.class);
  }

  public static R2SelectionService getR2SelectionService()
  {
    return SpringApplicationContext.getBean(R2SelectionService.class);
  }

  public static List<BudgesJbUploadFile> getJbUploadFileListForServices()
  {
    List<BudgesJbUploadFile> agencyTov = new ArrayList<BudgesJbUploadFile>();
    List<JbVolume> aList = JbVolume.fetchR2ServiceVolumes(CayenneUtils.createDataContext());

    for(JbVolume JbVolume : aList) {
      BudgesJbUploadFile bjuf = new BudgesJbUploadFile(JbVolume);
      agencyTov.add(bjuf);
    }

    return agencyTov;
  }

  public static List<BudgesJbUploadFile> getJbUploadFileListForAgencies() {
    List<BudgesJbUploadFile> agencyTov = new ArrayList<BudgesJbUploadFile>();
    List<JbVolume> aList = JbVolume.fetchR2AgencyVolumes(CayenneUtils.createDataContext());

    for(JbVolume JbVolume : aList) {
      BudgesJbUploadFile bjuf = new BudgesJbUploadFile(JbVolume);
      agencyTov.add(bjuf);
    }
    //CXE-6408
    return getAdminService().processTovList(agencyTov, true, null);
  }

  public static List<BudgesJbUploadFile> getJbUploadFileListForP40Services(){
    List<BudgesJbUploadFile> agencyTov = new ArrayList<BudgesJbUploadFile>();
    List<JbVolume> aList = JbVolume.fetchP40ServiceVolumes(CayenneUtils.createDataContext());

    for(JbVolume JbVolume : aList) {
      BudgesJbUploadFile bjuf = new BudgesJbUploadFile(JbVolume);
      agencyTov.add(bjuf);
    }
    
    return agencyTov;
  }

  public static List<BudgesJbUploadFile> getJbUploadFileListForP40Agencies() {
    List<BudgesJbUploadFile> agencyTov = new ArrayList<BudgesJbUploadFile>();
    List<JbVolume> aList = JbVolume.fetchP40AgencyVolumes(CayenneUtils.createDataContext());

    for(JbVolume JbVolume : aList) {
      BudgesJbUploadFile bjuf = new BudgesJbUploadFile(JbVolume);
      agencyTov.add(bjuf);
    }
    //CXE-6408
    return getAdminService().processTovList(agencyTov, false, null);
  }

  public static CbesLogManager getCbesLogManager()
  {
    return CbesLogFactory.getCbesLogManagerInstance();
  }

  public static CacheService getCacheService()
  {
    return SpringApplicationContext.getBean(CacheService.class);
  }

  public static LineItemListValidator getLineItemListValidator()
  {
    return SpringApplicationContext.getBean(LineItemListValidator.class);
  }

  public static ValidationService getValidationService()
  {
    return SpringApplicationContext.getBean(ValidationService.class);
  }

  public static BudgesXmlResourceResolverFactory getBudgesXmlResourceResolverFactory()
  {
    return SpringApplicationContext.getBean(BudgesXmlResourceResolverFactory.class);
  }

  /** Create a quick impl of a certain interface that simply extends BudgesBaseDAO and adds nothing else */
  public static <V extends BaseValueObject,P extends BudgesBaseDAO<V>> P createSimpleDAO(Class<P> iface, final BudgesBaseDAO<V> dao) {
    InvocationHandler handler = new InvocationHandler() {
      @Override
    public Object invoke(Object object, Method method, Object[] objects) throws Throwable {
        return method.invoke(dao, objects);
      }
    };
    return (P) Proxy.newProxyInstance(iface.getClassLoader(), new Class[]{iface}, handler);
  }

  public static UserProgramElementListDAO getUserProgramElementListDAO()
  {
    return SpringApplicationContext.getBean(UserProgramElementListDAO.class);
  }
  
  public static EmailUtil getEmailUtil() {
      return SpringApplicationContext.getBean(EmailUtil.class);
  }
  
  public static SourcePathManager getSourcePathManager(){
      return SpringApplicationContext.getBean(SourcePathManager.class);
  }



}
