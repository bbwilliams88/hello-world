#!/bin/sh

# Generates Cayenne classes (superclass and subclass, as necessary) via the Maven Plugin.
mvn cayenne:cgen
