#!/bin/sh

# Runs Cayenne Modeler via the Maven Plugin.
mvn cayenne-modeler:run
