#!/bin/sh

http_proxy=""
HOST=http://sys7588.dtic.mil:8080
SERVLET=restapp


#curl "$HOST/$SERVLET/xmlv/validateXml?agency=DTIC" -F 'file=@invalidschema.xml'
#curl "$HOST/$SERVLET/xmlv/validateXml?agency=DTIC" -F 'file=@ruleerror.xml'


curl "$HOST/$SERVLET/pdfgen/buildR2Pdf?agency=DTIC" -F 'file=@validr2.xml'
#curl "$HOST/$SERVLET/pdfgen/buildR2Pdf?agency=DTIC" -F 'file=@ruleerror.xml'

#curl "$HOST/$SERVLET/pdfgen/buildR2Pdfs?agency=DTIC&singlePdf=false" -F 'file=@validjb.zip'

#curl "$HOST/$SERVLET/pdfgen/buildJbPdf?agency=DTIC" -F 'file=@validjb.zip'

#curl "$HOST/$SERVLETt/pdfgen/buildMjbPdf?agency=DTIC" -F 'file=@warningmjb.zip'




UUID="c88aff26-6350-4987-94c8-5edc68ce5ca1"
#UUID="838957e6-61b6-44bc-8c7e-91bf01651dfd"
UUID=e2878956-fff3-43b5-bb0c-4c473491a613
#curl "$HOST/$SERVLET/job/$UUID" -o file.zip
#wget -S "$HOST/$SERVLET/job/$UUID"
#wget $HOST/$SERVLET/job/550e8400-e29b-41d4-a716-446655440000 -S