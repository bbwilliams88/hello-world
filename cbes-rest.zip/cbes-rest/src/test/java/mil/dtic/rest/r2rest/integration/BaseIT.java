package mil.dtic.rest.r2rest.integration;

public abstract class BaseIT
{
  protected static final String restUrl = "http://127.0.0.1:8084/restapp";
}
