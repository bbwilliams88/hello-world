package mil.dtic.rest.r2rest.xmlbean;

import java.net.URL;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlObject;
import org.junit.Assert;
import org.junit.Test;


public class TestXmlBeanCompile
{

  @Test
  public void testCompileCbesWsResponse(){
    
    try{
      
      URL url = TestXmlBeanCompile.class.getResource("/cbes-ws-response.xsd");
      
      XmlObject[] schemaObj = new XmlObject[] {XmlObject.Factory.parse(url)};
      
      SchemaTypeSystem schemaTypeObject = XmlBeans.compileXsd(schemaObj, null, null);
    
      SchemaType[] types = schemaTypeObject.globalTypes();
    
      Assert.assertTrue(types != null && types.length > 0);
      
    }catch(Throwable t){
      t.printStackTrace();
      Assert.fail("Its so sad when things go wrong: " + t.getMessage());
    }
    
  }
  
}
