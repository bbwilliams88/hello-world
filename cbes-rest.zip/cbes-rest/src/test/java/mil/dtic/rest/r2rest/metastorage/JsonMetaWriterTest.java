package mil.dtic.rest.r2rest.metastorage;


import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mil.dtic.rest.r2rest.metastorage.JsonMetaWriter;

import org.junit.* ;

import static org.junit.Assert.*;


public class JsonMetaWriterTest {

	
	@SuppressWarnings("unchecked")
	@Test
	public void test_uninitialized()
	{
		JsonMetaWriter metaTest = new JsonMetaWriter();
		Map testData = new HashMap();
		testData.put("a", "apple");
		testData.put("b", "Bananna");
		testData.put("c", "coconut");
		List arr = new ArrayList();
		arr.add("one");
		arr.add("two");
		arr.add("three");
		testData.put("arr", arr);
		Integer nine = new Integer(9);
		
		testData.put("nine", nine);
		System.out.println("testMap before json ->"+testData.toString());
		
		StringWriter foo = new StringWriter();
		
		metaTest.writeMetaData(foo, testData);
		String result = foo.getBuffer().toString();
		System.out.println(" result -> "+result);
		StringReader strReader = new StringReader(result);
		Map mapResult = metaTest.readMetaData(strReader);
		System.out.println("mapResult ->"+mapResult.toString());
		
	}

}
