package mil.dtic.rest.r2rest;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RepoTest {

	private static final String fileComponent = "/files";
	private static final String defaultRepo = "/tmp";
	private static int fileNameSize = 10;

	@Test
	public void test_uninitialized()
	{
		DocumentStore docStore = new DocumentStore();
		assertFalse(docStore.isRepositoryValid());

	}

	@Test
	public void test_defaultinitialize()
	{
		DocumentStore docStore = new DocumentStore();
		docStore.initializeDefaultFileContainer();
		assertTrue(docStore.isRepositoryValid());
	}

	@Test
	public void test_initialize()
	{
		DocumentStore docStore = new DocumentStore();
		docStore.initializeFileContainer();
		assertFalse(docStore.isRepositoryValid());

	}

	@Test
	public void test_DocStoreWithFileInit()
	{
		DocumentStore docStore = new DocumentStore();
		docStore.setStorageContainer(defaultRepo);
		docStore.initializeFileContainer();
		assertTrue(docStore.isRepositoryValid());

	}

// This doesn't actually test creating a DocumentStore with a file.  Instead,
// it just creates a file in the project root directory and litters up your
// version control by making you delete these unwanted files, so I commented
// it out for now.  - mrg
//	@Test
//	public void test_DocStoreWithFile()
//	{
//		DocumentStore docStore = new DocumentStore();
//		docStore.setStorageContainer(defaultRepo);
//		docStore.initializeFileContainer();
//		assertTrue(docStore.isRepositoryValid());
//		String fileName =  docStore.getFileNameForRepo(fileNameSize);
//		assertTrue(fileName.length() == fileNameSize);
//		File myFile = new File(fileName);
//		try {
//			myFile.createNewFile();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}




}
