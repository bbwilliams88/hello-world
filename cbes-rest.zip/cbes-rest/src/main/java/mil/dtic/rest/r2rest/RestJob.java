package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.TEXT;
import static mil.dtic.rest.r2rest.RestConstants.XML;
import static mil.dtic.rest.r2rest.RestConstants.ZIP;

import java.io.File;
import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.delegates.errorformat.R2XMLResponseFactory;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

@Resource
@Path(value = "/job")
public class RestJob extends RestUtils
{
  private static final Logger log = CbesLogFactory.getLog(RestJob.class);
  
  
   
  @GET
  @Path("/{uuid}")
  @Produces({ZIP,XML,TEXT})
  public Response fetchJob(@PathParam("uuid") String uuidstr, @Context HttpServletRequest req)
  {
    log.debug("fetchJob " + uuidstr);
    BudgesJob job;
    try {
      job = BudgesContext.getBudgesJobDAO().findByUUID(uuidstr);
    } catch (IllegalArgumentException e) {
      log.debug("fetchJob - invalid uuid");
      return Response.status(Status.BAD_REQUEST).entity("Invalid UUID " + uuidstr).type(TEXT).build();
    }
    if (job==null) {
      log.debug("fetchJob - not found");
      return Response.status(Status.NOT_FOUND).entity("Job with UUID " + uuidstr + " not found").type(TEXT).build();
    }
    log.debug("Agency " + job.getAgency());
    if (job.getJobStatus() == null) {
      log.error("fetchJob - null status");
      return Response.serverError().build();
    }
    if (job.getJobStatus().isStillProcessing()) {
      log.debug("fetchJob - processing not complete");
      return Response.status(Status.ACCEPTED).entity("Still processing...").type(TEXT).build();
    }
    if (job.getResultFilename()==null) {
      try {
        log.error("fetchJob - result filename null");
        String xmlresponse = R2XMLResponseFactory.buildXMLResponse("An error occurred, and no pdf was generated.");
        return Response.ok(xmlresponse, XML).header("Content-Disposition", "attachment; filename=xmlresponse.xml").build();
      } catch (IOException e) { //I'm not sure why xmlbeans throws ioexceptions for in-memory operations...
        log.error("", e);
        return Response.serverError().build();
      }
    }
    File result = R2Storage.getResultFile(job);
    if (!result.exists()) {
      log.error("fetchJob - result file not found");
      return Response.serverError().build();
    }
    String contentType = getMimeType(result);
    log.debug("fetchJob - sending " + result + " type " + contentType);
    return Response.ok(result, contentType).header("Content-Disposition", "attachment; filename="+result.getName()).build();
  }
}
