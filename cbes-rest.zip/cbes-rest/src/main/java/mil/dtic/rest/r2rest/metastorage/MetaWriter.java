package mil.dtic.rest.r2rest.metastorage;

import java.io.Reader;
import java.io.Writer;
import java.util.Map;

public interface MetaWriter
{
    public void writeMetaData(Writer myStream, Map<String, String> dataMap);
    public Map<String, String> readMetaData(Reader myStream); 
}
