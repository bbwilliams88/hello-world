package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.ZIP;

import java.io.InputStream;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.utility.CbesLogFactory;

@Resource
@Path(value = "/xmlpkg")
public class XmlPackage
{
  private final Logger log = CbesLogFactory.getLog(XmlPackage.class);
  
  @GET 
  @Path("/getlatest")
  @Produces(ZIP)
  public Response getSchemaPackage(@QueryParam("agency") String agencyCode)
  {
    log.debug("getSchemaPackage " + agencyCode);
    String file = Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME;
    InputStream is = getClass().getResourceAsStream(file);
    if (is==null) {
      log.error("File not found internally. Probably a bug.");
      return Response.serverError().entity("File not found internally. Probably a bug.").build();
    }
    return Response.ok(is,ZIP).header("Content-Disposition", "attachment; filename=" + file).build();
  }
}
