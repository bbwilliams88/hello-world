package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.TEXT;
import static mil.dtic.rest.r2rest.RestConstants.XML;
import static mil.dtic.rest.r2rest.RestConstants.ZIP;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.transform.TransformerException;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.delegates.P40XMLTools;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2XMLTools;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsError;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsException;
import mil.dtic.utility.CayenneUtils;

@Resource
@Path(value = "/pdfgen")
public class PdfGenerator extends RestUtils
{
  //private static final Logger log = CbesLogFactory.getLog(PdfGenerator.class);
 
  @POST
  @Path("/buildP40Pdf")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({ZIP,XML,TEXT})
  public Response buildP40Pdf(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode)
  {
    R2XMLToolsMethod rtm = new R2XMLToolsMethod() {
      @Override
    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException, R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
        PreviewResultInfo result = P40XMLTools.buildP40Pdfs(job, false, onlyRunVerifiedRules);
        Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, job.getAgency().getCode());
        SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
        List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
        mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);

        return result;

      }
    };
    if (forceAsync) return processAsync("Build P40 PDF", agencyCode, JobTypeFlag.P40XMLTOSINGLEPDF);
    else return process("Build P40 PDF", agencyCode, rtm, false);
  }

  @POST
  @Path("/buildP40Pdfs")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({TEXT})
  public Response buildP40Pdfs(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode,
    @QueryParam("singlePdf") @DefaultValue("true") final boolean singlePdf)
  {
    JobTypeFlag jobType = singlePdf ? JobTypeFlag.P40XMLTOSINGLEPDF : JobTypeFlag.P40XMLTOMULTIPDF;
    return processAsync("Build P40 PDF(s)", agencyCode, jobType);
  }

  @POST
  @Path("/buildR2Pdf")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({ZIP,XML,TEXT})
  public Response buildR2Pdf(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode)
  {
    R2XMLToolsMethod rtm = new R2XMLToolsMethod() {
      @Override
    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException, R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {

        PreviewResultInfo result = R2XMLTools.buildR2Pdfs(job, false, onlyRunVerifiedRules);
        Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, job.getAgency().getCode());
        SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
        List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
        mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);
   
        return result;

      }
    };
    if (forceAsync) return processAsync("Build R2 PDF", agencyCode, JobTypeFlag.R2XMLTOSINGLEPDF);
    else return process("Build R2 PDF(s)", agencyCode, rtm, false);
  }

  @POST
  @Path("/buildR2Pdfs")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({TEXT})
  public Response buildR2Pdfs(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode,
    @QueryParam("singlePdf") @DefaultValue("true") final boolean singlePdf)
  {
    JobTypeFlag jobType = singlePdf ? JobTypeFlag.R2XMLTOSINGLEPDF : JobTypeFlag.R2XMLTOMULTIPDF;
    return processAsync("Build R2 PDF(s)", agencyCode, jobType);
  }

  @POST
  @Path("/buildJbPdf")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({TEXT})
  public Response buildJbPdf(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode)
  {
    return processAsync("Build J-Book PDF", agencyCode, JobTypeFlag.JBXMLTOPDF);
  }

  @POST
  @Path("/buildMjbPdf")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces({TEXT})
  public Response buildMjbPdf(
    @QueryParam("forceAsync") @DefaultValue("false") boolean forceAsync,
    @QueryParam("agency") String agencyCode)
  {
    return processAsync("Build MJB PDF", agencyCode, JobTypeFlag.MJBXMLTOPDF);
  }
}
