package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.TEXT;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Resource
@Path(value = "/httpcode")
public class HttpCodeTester
{
  @GET
  @Path("/test")
  public Response buildR2Pdf(@QueryParam("code") int httpCode)
  {
    return Response.status(httpCode).entity(httpCode).type(TEXT).build();
  }
} 
