package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.XML;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import mil.dtic.cbes.p40.vo.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2XMLTools;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsError;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsException;

@Resource
@Path(value = "/xmlv")
public class XmlValidator extends RestUtils
{
  //private final Logger log = CbesLogFactory.getLog(XmlValidator.class);

  /**
   * Helper method to look up ServiceAgency by code.
   * @param context
   * @param code
   * @return
   */ 
  private ServiceAgency getServiceAgency(ObjectContext context, String code){
    Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, code);
    SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
    List<mil.dtic.cbes.p40.vo.ServiceAgency> results = context.performQuery(query);
    mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);
    return agency;
  }

  @POST
  @Path("/validateXml")
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(XML)
  public Response validateXml(@QueryParam("agency") String agencyCode)
  {
    R2XMLToolsMethod rtm = new R2XMLToolsMethod() {
      @Override
    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException, R2XMLToolsException, R2XMLToolsError {

        PreviewResultInfo result = R2XMLTools.validateXML(job, onlyRunVerifiedRules);

        return result;

      }
    };
    return process( "validateXml", agencyCode, rtm, true);
  }
}
