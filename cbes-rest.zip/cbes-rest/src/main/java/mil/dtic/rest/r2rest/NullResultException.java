package mil.dtic.rest.r2rest;

/**
 * Thrown when the delegate fails to create a PDF for unknown reasons (>_>)
 */
public class NullResultException extends Exception
{
  private static final long serialVersionUID = 1L;
  public NullResultException()
  {
    super();
  }
  public NullResultException(String message)
  {
    super(message);
  } 
  
  public NullResultException(String message, Object entity)
  {
    super(message);
  }
}
