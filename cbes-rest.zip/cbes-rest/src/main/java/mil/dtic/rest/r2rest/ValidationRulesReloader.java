package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.TEXT;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Logger;

import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

@Resource
@Path(value = "/rules")
public class ValidationRulesReloader
{
  private static final Logger log = CbesLogFactory.getLog(ValidationRulesReloader.class);

  @GET 
  @Path("/refresh")
  public Response refreshValidatorRules()
  {
    log.info("refreshValidatorRules");
      BudgesContext.getValidationService().markRulesCacheForReload();
      return Response.ok().entity("Done " +  new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()) + ".").type(TEXT).build();
  }
}
