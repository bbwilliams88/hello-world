package mil.dtic.rest.r2rest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap; 
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.rest.r2rest.metastorage.JsonMetaWriter;
import mil.dtic.rest.r2rest.metastorage.MetaWriter;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.CBESFilenameUtils;


public class DocumentStore {
    private static final Logger log = CbesLogFactory.getLog(DocumentStore.class);

    // FIXME: Change these to be normative for Java constants, such as FILE_COMPONENT.
	private static final String fileComponent = "/files";
	private static final String metaComponent = "/meta";
	private static final String defaultRepo = "/tmp";
	private static final int maxCount = 10;

	public static final String fileNameKey = "fileName";
	public static final String filePathKey = "filePath";
	public static final String metaExtention = ".jsn";
	public static final String metaFileKey = "metaKey";
	public static final String fileNameKeyToken = "fileRepositoryKey";
	public static final String fileDateSubmission = "uploadDate";
	public static final String fileSize = "fileSize";

	private String storageContainer = null;
	private boolean repositoryIsValid = false;
	private Map<String,Map<String,String>> repositoryProxy = new HashMap<>();


	public void setRepositoryValid(boolean repositoryIsValid)
	{
		this.repositoryIsValid = repositoryIsValid;
	}



	public boolean isRepositoryValid()
	{
		return repositoryIsValid;
	}



	public Map<String,Map<String,String>> getRepositoryProxy()
	{
		return repositoryProxy;
	}

	public void setRepositoryProxy(Map<String,Map<String,String>> repositoryProxy) {
		this.repositoryProxy = repositoryProxy;
	}



	public void setStorageContainer(String storageContainer) {
		this.storageContainer = storageContainer;
	}

	public String getStorageContainer() {
		return storageContainer;
	}

	public String getFileStorageContainerFilePath()
	{
		return storageContainer+fileComponent;
	}

	public String getMetaStorageContainerFilePath()
	{
		return storageContainer+metaComponent;
	}

	public void initializeFileContainer()
	{
		setRepositoryValid(false);

		if (StringUtils.isNotBlank(this.getStorageContainer()))
		{
			File repository = new File (getStorageContainer());
			if (repository.canRead() && repository.canWrite() && repository.isDirectory())
			{
				File fileRepo = new File(getFileStorageContainerFilePath());
				if (!fileRepo.exists())
				{
					fileRepo.mkdir();
				}
				if (fileRepo.isDirectory() && fileRepo.canRead() && fileRepo.canWrite())
				{
					setRepositoryValid(true);
				}
			}
			if (StringUtils.isNotBlank(getMetaStorageContainerFilePath()))
			{
				initializeMetaFileProxy();
			}
		}
	}


	public void initializeMetaFileProxy()
	{
		MetaWriter metaReader = new JsonMetaWriter();
		File metaStorage = new File(getMetaStorageContainerFilePath());
		if (metaStorage.isDirectory())
		{
			String[] filelist = metaStorage.list(new FilenameFilter() {
				@Override
                public boolean accept(File f, String s) { return s.endsWith(".jsn"); }
			});
			if (filelist.length > 0)
			{
				int i;
				for (i = 0; i < filelist.length; i++)
				{
					String fileName = filelist[i];
					File curFile = new File(getMetaStorageContainerFilePath()
							+ "/" + fileName);
					if (curFile.exists())
					{
						try {
							FileReader freader = new FileReader(curFile);
							Map<String,String> fileData = metaReader.readMetaData(freader);
							String fileId = fileName.substring(0, fileName
									.indexOf(".jsn"));
							repositoryProxy.put(fileId, fileData);
							freader.close();

						} catch (FileNotFoundException e) {
							log.error("Error reading file with name : " + fileName,e);
						} catch (IOException e) {
						  log.error("Error closeing file with name : " + fileName,e);
						}
					}
				}
				log.debug("Read in "+i+" files into repository proxy");
			}
		}

	}


	public void initializeDefaultFileContainer()
	{
		setStorageContainer(defaultRepo);
		initializeFileContainer();

	}

	public String getFileNameForRepo(int length)
	{
		String retValue = RandomStringUtils.randomAlphabetic(length);
		while (this.fileWithNameExists(retValue))
		{
			retValue = RandomStringUtils.randomAlphabetic(length);
		}
		return ( retValue);
	}


	private boolean fileWithNameExists(String proposedName) {
		boolean retValue = false;
		String filePath = getFileStorageContainerFilePath() + "/" + proposedName;
		File possibleFile = new File(filePath);
		if (possibleFile.exists())
		{
			retValue = true;
		}
		return retValue;
	}

	private boolean metaFileWithNameExists(String proposedName) {
		boolean retValue = false;
		String filePath = getMetaStorageContainerFilePath() + "/" + proposedName;
		File possibleFile = new File(filePath);
		if ((possibleFile.exists()) && (possibleFile.canWrite()))
		{
			retValue = true;
		}
		return retValue;
	}


	public String addDocumentToStorage(Map<String,String> fileMetaData)
	{
		int attempts = 0;
		String fileKey = null;
		String fileName = null;
		do
		{
			fileKey = RandomStringUtils.randomAlphabetic(10);
			fileName = fileKey + DocumentStore.metaExtention;
		} while ((metaFileWithNameExists(fileName)) && (attempts < maxCount));
		if (attempts != maxCount)
		{
			fileMetaData.put(metaFileKey, fileKey);
			getRepositoryProxy().put(fileKey, fileMetaData);
			putMetaDataInRepository(fileName, fileMetaData);

		}
		else
		{
			fileKey = null;
		}
		return (fileKey);
	}


	private void putMetaDataInRepository(String fileKey, Map<String,String> fileMetaData)
	{
		String metaFilePath = getMetaStorageContainerFilePath() + "/" + fileKey;
		if (!metaFilePath.endsWith(DocumentStore.metaExtention))
		{
			metaFilePath += DocumentStore.metaExtention;
		}
		File metaFile = new File(metaFilePath);
		try {
			metaFile.createNewFile();
			Writer output = new BufferedWriter(new FileWriter(metaFile));
			JsonMetaWriter converter = new JsonMetaWriter();
			converter.writeMetaData(output, fileMetaData);
			output.close();

		} catch (IOException e) {
		  log.error("Failed to put metadata into repository: " + e.getMessage(),e);
		}
	}

	public String getMetaDataFromRepository(String fileKey)
	{
		StringBuilder retValue = new StringBuilder();
		String metaFilePath = getMetaStorageContainerFilePath() + "/" + CBESFilenameUtils.sanitizeFileName(fileKey);
		if (!metaFilePath.endsWith(DocumentStore.metaExtention))
		{
			metaFilePath += DocumentStore.metaExtention;
		}
		File metaFile = new File(metaFilePath);
		Reader input = null;
		if (metaFile.exists())
		{
		    // FIXME: Change to try/resources
			try {
				input = new BufferedReader(new FileReader(metaFile));
				int size;
				do
				{
					char[] buffer = new char[100];
					size = input.read(buffer);
					retValue.append(buffer);
				} while (size > 0);
			} catch (FileNotFoundException e) {
			  log.error("Failed to get metadate from repository: " + e.getMessage(),e);
			} catch (IOException e) {
			  log.error("Error reading metadata: " + e.getMessage(),e);
			}finally{
			  if(input != null)
			  {
			    try
          {
			      input.close();
          }
          catch (IOException e)
          {
            log.warn("Failed to close input stream: " + e.getMessage(),e);
          }
			  }
			}

		}
		return retValue.toString();
	}

	public int repositoryCount()
	{
		int count = 0;
		if (StringUtils.isNotBlank(getFileStorageContainerFilePath()))
		{
			String[] fileList = (new File(getFileStorageContainerFilePath())).list();
			count = fileList.length;
		}
		return (count);
	}

	public String getFileAtPos(int i) {
		String filePath = null;
		if (StringUtils.isNotBlank(getFileStorageContainerFilePath()))
		{
			String[] fileList = (new File(getFileStorageContainerFilePath())).list();
			int count = fileList.length;
			if (count >= i)
			{
				String fileName = fileList[i];
				filePath = getFileStorageContainerFilePath()+ "/"+fileName;
			}
		}
		return filePath;
	}

	public String getDocWithId(String fileId) {
		String filePathStr = "";
		Map<String,String> metaData = getRepositoryProxy().get(fileId);
		if (metaData != null)
		{
			filePathStr = metaData.get(DocumentStore.filePathKey);
		}
		return filePathStr;
	}

}
