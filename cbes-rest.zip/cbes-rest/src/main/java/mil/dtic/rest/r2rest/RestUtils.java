package mil.dtic.rest.r2rest;

import static mil.dtic.rest.r2rest.RestConstants.FILE_FORM_PARAM;
import static mil.dtic.rest.r2rest.RestConstants.REST_TMP_FILE_PFX;
import static mil.dtic.rest.r2rest.RestConstants.TEXT;
import static mil.dtic.rest.r2rest.RestConstants.XML;
import static mil.dtic.rest.r2rest.RestConstants.XML_RESP_FILENAME;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URLConnection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import javax.xml.transform.TransformerException;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.data.config.JobSourceFlag;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.delegates.R2XMLTools;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsError;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsException;
import mil.dtic.cbes.submissions.delegates.errorformat.R2XMLResponseFactory;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;

public abstract class RestUtils
{
  private static final Logger log = CbesLogFactory.getLog(RestUtils.class);
  private static final String nullmessage = "An error occurred, and no pdf was generated.";

  @Context
  private HttpServletRequest req;
  @Context
  private UriInfo uriinfo;

  /** Wraps a particular method from R2XMLTools in a generic method signature */
  protected interface R2XMLToolsMethod
  {
    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException, R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException;
  }
 
  private URI getPathToJob(UriInfo uriinfo, BudgesJob job)
  {
    if (job.getId()==null) throw new IllegalArgumentException("job should be persisted first");
    String uuid = job.getUuid().toString();
    return uriinfo.getBaseUriBuilder().path(RestJob.class).path(uuid).build();
  }

  /** Convert "r" to XML and save it to xmlresponse.xml in "parentFolder" */
  private File saveXmlResponseToFile(File parentFolder, String xml) throws IOException
  {
    if (!parentFolder.exists()) throw new IOException("saveXmlResponseToFile: destinination folder does not exist - "+parentFolder);
    File dest = new File(parentFolder, XML_RESP_FILENAME);
    if (!dest.createNewFile()) throw new IOException("saveXmlResponseToFile: Could not create file - "+dest);
    FileUtils.writeStringToFile(dest, xml);
    return dest;
  }

  /**
   * Parse a multipart file upload from the request and pick out one file.
   * Prefer the form field named "file", or pick a random file.
   */
  private FileItem getOneFile(HttpServletRequest req) throws FileUploadException, BadRequestException
  {
    log.debug("parsing request ");

    FileItemFactory factory = new DiskFileItemFactory(10*1024, R2Storage.getSandboxTmp());
    ServletFileUpload upload = new ServletFileUpload(factory);

    @SuppressWarnings("unchecked")
    List<FileItem> items = upload.parseRequest(req);
    FileItem theChosenOne = null;

    for (FileItem item : items) {
      if (item.isFormField()) {
        log.debug("form field " + item.getFieldName() + "=" + item.getString());
      }
      // form field "file" is preferred
      if (FILE_FORM_PARAM.equals(item.getFieldName())) {
        if (item.getName()==null) throw new BadRequestException("No filename header found in form part for \"file\"");
        theChosenOne = item;
        break; //
      }
      // else grab a random field with "filename" in the Content-Disposition
      if (theChosenOne==null && item.getName()!=null) {
        theChosenOne = item;
      }
    }

    if (theChosenOne == null) {
      throw new BadRequestException("No upload file found in form fields");
    }

    return theChosenOne;
  }


  // pick file from form data, process it using "method",
  // return result (zip or xml-formatted error or w/e), or barf and throw exception (500 error)
  // BadRequestException is a 400 error
  private File process0(JobTypeFlag jobType, String agencyCode, HttpServletRequest req, R2XMLToolsMethod method, boolean returnXmlrspOnly) throws BadRequestException, FileUploadException, IOException
  {
      File result;

      FileItem fileItem = getOneFile(req); // throw if it's not in the formfields
      R2Storage r2stor = new R2Storage(REST_TMP_FILE_PFX + "_" + agencyCode);
      File sandboxFile = r2stor.createTempFileInSandbox(FilenameUtils.getExtension(fileItem.getName()));

      // create sandbox file from upload
    try {
        String originalName = "shouldnotappear";
      fileItem.write(sandboxFile);
      originalName = fileItem.getName();

      // Remove path from filename (IE6 puts it in)
      originalName = FilenameUtils.getName(originalName);

      ServiceAgency agency = parseAgency(agencyCode);
      boolean onlyRunVerifiedRules = !BudgesContext.getConfigService().getUnverifiedRulesAgencies().contains(agency.getCode());
      BudgesJob job = r2stor.scanAndPutInUpload(sandboxFile, originalName, agency, jobType, JobSourceFlag.WebService);

      File dirInUpl = R2Storage.getWorkingDirectory(job);
      try {
        PreviewResultInfo pri;

			pri = method.execute(job, onlyRunVerifiedRules);

        String xmlresponse = R2XMLResponseFactory.buildXMLResponse(pri);
        if (returnXmlrspOnly) {
          result = saveXmlResponseToFile(dirInUpl, xmlresponse);
        } else {
          result = R2XMLTools.getResultFile(pri);
          if (result==null) throw new NullResultException();
          File xml = saveXmlResponseToFile(dirInUpl, xmlresponse);
          // add xml response to zip
          result = R2Storage.repackageResult(dirInUpl, result, xml);
        }
      } catch (R2XMLToolsException e) { // bad input (bad xml, violated rule, etc)
        String xmlresponse = R2XMLResponseFactory.buildXMLResponse(e.getPreviewResultInfo());
        result = saveXmlResponseToFile(dirInUpl, xmlresponse);
      }
      catch (NullResultException e)
      {
        log.error(nullmessage, e);
        String xmlresponse = R2XMLResponseFactory.buildXMLResponse(nullmessage);
        result = saveXmlResponseToFile(dirInUpl, xmlresponse);
      }
    } catch (VirusScanException e) { // virus scan error
      // no upload dir made, so make one
      File newDirInUpl = r2stor.createEmptyFolderInUpload();
      String xmlresponse = R2XMLResponseFactory.buildXMLResponse(e);
      result = saveXmlResponseToFile(newDirInUpl, xmlresponse);
    }
        catch (Exception e) // Wrap raw Exception from Apache Commons FileItem.write().
        {
            throw new IOException("Error writing item to file " + sandboxFile, e);
        }
        finally
        {
            if (sandboxFile != null)
                sandboxFile.delete();
        }
        String Test = URLConnection.guessContentTypeFromName(result.getName());
    return result;
  }

  private BudgesJob process0Async(JobTypeFlag jobType, String agencyCode, HttpServletRequest req) throws BadRequestException, FileUploadException, IOException, VirusScanException
  {
      FileItem fileItem = getOneFile(req); // throw if it's not in the form fields
    R2Storage r2stor = new R2Storage(REST_TMP_FILE_PFX + "_" + agencyCode);
    File sandboxFile = null;

    try {
      // create sandbox file from upload
      sandboxFile = r2stor.createTempFileInSandbox(FilenameUtils.getExtension(fileItem.getName()));
      fileItem.write(sandboxFile);
      String originalName = fileItem.getName();

      // Remove path from filename (IE6 puts it in)
      originalName = FilenameUtils.getName(originalName);

      ServiceAgency agency = parseAgency(agencyCode);
      BudgesJob job = r2stor.scanAndPutInUpload(sandboxFile, originalName, agency, jobType, JobSourceFlag.WebService);

      BudgesContext.getBudgesJobDAO().saveOrUpdate(job);
      return job;
    }
    catch (Exception e) // Wrap raw Exception from Apache Commons FileItem.write().
    {
        throw new IOException("Error writing item to file " + sandboxFile, e);
    }
        finally
        {
            if (sandboxFile != null)
                sandboxFile.delete();
        }
    }

  protected Response process(String functionName, String agencyCode, R2XMLToolsMethod method, boolean returnXmlrspOnly)
  {
    log.info("Parsing " + functionName + " " + agencyCode);
    try {
      JobTypeFlag jobType = JobTypeFlag.N;
      File result = process0(jobType, agencyCode, req, method, returnXmlrspOnly);


      String contentType = getMimeType(result);
      return Response
        .ok(result, contentType)
        .header("Content-Disposition", "attachment; filename=" + result.getName())
        .build();
    } catch (BadRequestException e) { // malformed request
      log.error(functionName + ": Malformed request", e);
      return Response
        .status(Status.BAD_REQUEST)
        .entity(e.getMessage())
        .type(TEXT)
        .build();
    } catch (Exception e) { // unknown error, die
      log.error(functionName + ": failed", e);
       return Response.serverError().build();
    }
  }


  protected Response processAsync(String functionName, String agencyCode, JobTypeFlag jobType)
  {
    log.info("Parsing " + functionName + " " + agencyCode);

    try {
      try {
        BudgesJob job = process0Async(jobType, agencyCode, req);
        URI jobpath = getPathToJob(uriinfo, job);
        log.info("Created job " + job.getUuidStr());

        Response result = Response
          .created(jobpath)
          .entity(job.getUuidStr())
          .type(TEXT)
          //.header("Content-Disposition", "attachment; filename=uuid.txt")
          .build();
        Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, job.getAgency().getCode());
        SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
        List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
        mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);

        return result;

      } catch (BadRequestException e) { // malformed request
        log.error(functionName + ": Malformed request", e);
        Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, agencyCode);
        SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
        List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
        mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);

        return Response
          .status(Status.BAD_REQUEST)
          .entity(e.getMessage())
          .type(TEXT)
          .build();
      } catch (VirusScanException e) { // virus scan error
        String xmlresponse = R2XMLResponseFactory.buildXMLResponse(e);
        log.error("Virus scan error, returning xmlresponse " + xmlresponse);
        Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, agencyCode);
        SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
        List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
        mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);
    
        return Response
          .status(Status.OK)
          .entity(xmlresponse)
          .type(XML)
          .header("Content-Disposition", "attachment; filename=" + XML_RESP_FILENAME)
          .build();
      }
    }
    catch (Exception e) { // unknown error, die
      log.error(functionName + ": failed", e);
      Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, agencyCode);
      SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
      List<mil.dtic.cbes.p40.vo.ServiceAgency> results = CayenneUtils.createDataContext().performQuery(query);
      mil.dtic.cbes.p40.vo.ServiceAgency agency = results.get(0);
   
      return Response.serverError().build();
    }
  }

  protected String getMimeType(File f)
  {
    BudgesContentType bct = BudgesContentType.getContentType(f.getName().toUpperCase());
    if (bct == BudgesContentType.XML) {
      return XML; // instead of text/xml
    }
    return bct.getMimeType();
  }

  private ServiceAgency parseAgency(String agencyCode) throws BadRequestException
  {
    ServiceAgency anAgency = BudgesContext.getServiceAgencyDAO().findByCode(agencyCode);
    log.trace("Searching for agency with code: " + agencyCode);
    if (anAgency == null){
      log.error("found NO agency for " + agencyCode );
      throw new BadRequestException("Searching for agency with code: "+agencyCode+" found no agency with that code");
    }
    else
    {
      log.trace("Found agency with Id = " + anAgency.getId());
    }
    return anAgency;
  }

}
