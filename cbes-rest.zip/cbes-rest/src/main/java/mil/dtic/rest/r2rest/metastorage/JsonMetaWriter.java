package mil.dtic.rest.r2rest.metastorage;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;

import mil.dtic.utility.CbesLogFactory;

public class JsonMetaWriter implements MetaWriter  {

  private static final Logger log = CbesLogFactory.getLog(JsonMetaWriter.class);

	private String getJsonString(Reader myStream)
	{
		String jsonString = null;
		try {
			int count = 0; 
			while ((myStream.ready()) && (count != -1))
			{
				char[] buffer = new char[1024];
				count = myStream.read(buffer);
				if (count > 0)
				{
					if(StringUtils.isNotBlank(jsonString))
					{
						jsonString += new String(buffer);
					}
					else
					{
						jsonString = new String(buffer);
					}
				}
			}
		} catch (IOException e) {
			log.error("Error while getting json string: " + e.getMessage(),e);
		}
		return (jsonString);
	}


	@Override
    @SuppressWarnings("unchecked")
	public Map<String, String> readMetaData(Reader myStream) {

		String json = getJsonString(myStream);
		XStream xstream = new XStream(new JettisonMappedXmlDriver());
		xstream.alias("map", HashMap.class);
		Map<String, String> fileData = (Map<String,String>) xstream.fromXML(json);
		log.debug(fileData.toString());

		return fileData;
	}



	@Override
	public void writeMetaData(Writer myStream, Map<String, String> dataMap) {

    XStream xstream = new XStream(new JettisonMappedXmlDriver());
    xstream.setMode(XStream.NO_REFERENCES);
    xstream.alias("map", HashMap.class);
    try {
			myStream.write(xstream.toXML(dataMap));
		} catch (IOException e) {
			log.error("Error while writing metadate: " + e.getMessage(),e);
		}
	}

}
