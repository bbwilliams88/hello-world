package mil.dtic.rest.r2rest;

/**
 * Thrown when a multipart http request is malformed
 */
public class BadRequestException extends Exception
{
  private Object entity;
  public BadRequestException()
  {
    super(); 
    entity = "";
  }


  public BadRequestException(String message)
  {
    super(message);
    entity = message;
  }


  /** @param entity entity to pass to RESTEasy ResponseBuilder, to then end up being sent to the client */
  public BadRequestException(String message, Object entity)
  {
    super(message);
    this.entity = entity;
  }


  public Object getEntity()
  {
    return entity;
  }
}
