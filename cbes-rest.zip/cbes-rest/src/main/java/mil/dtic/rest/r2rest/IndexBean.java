package mil.dtic.rest.r2rest;

import java.io.Serializable;
import java.util.List;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.Util;

public class IndexBean implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  public IndexBean()
  {
 
  }

  public boolean getIsClassified()
  {
    return Util.isClassified();
  }

  public List<ServiceAgency> getServiceAgency()
  {
    return BudgesContext.getServiceAgencyDAO().findAllRDTE();
  }
}
