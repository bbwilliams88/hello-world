package mil.dtic.rest.r2rest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;
import org.apache.commons.lang.StringEscapeUtils;

@Resource
@Path(value = "/putfile")
public class FormFileWriter
{
    private static final Logger log = CbesLogFactory.getLog(FormFileWriter.class);

    private static DocumentStore docStore;

    @GET 
    @Path("/upload/result")
    @Produces("application/pdf")
    public File downloadFile(@QueryParam("fileId") String fileId)
    {
        return new File(docStore.getDocWithId(fileId));
    }

    @GET
    @Path("/download/{id}")
    @Produces("text/plain")
    public String downloadFileId(@PathParam("id") String repoId)
    {
        if (StringUtils.isNotBlank(repoId))
            return docStore.getMetaDataFromRepository(repoId);
        else
            return "";
    }

    // I pulled the plug on /sumarize because:
    //     a) Narf security review findings correctly state it can be used as part of an XSS attack,
    //     b) It exposes too much internal document state,
    //     c) It should only be a debug API (if re-enabled, disable in production-mode),
    //     d) Doesn't appear to be used,
    //     e) Embarrassingly, It is misspelled.
    // -mrg

//    @GET
//    @Path("/sumarize")
//    @Produces("text/html")
//    @SuppressWarnings("unchecked")
//    public String displaySummary()
//    {
//        String result = "";
//        StringWriter stringData = new StringWriter();
//
//        if (docStore != null)
//        {
//            Map docMap = docStore.getRepositoryProxy();
//            Iterator<Map.Entry> entrys = docMap.entrySet().iterator();
//            while (entrys.hasNext())
//            {
//                Map.Entry entry = entrys.next();
//                String keyStr = (String) entry.getKey();
//                Map fileData = (Map) entry.getValue();
//                String filePath = (String) fileData.get(DocumentStore.fileNameKey);
//                String size = (String) fileData.get(DocumentStore.fileSize);
//                String date = (String) fileData.get(DocumentStore.fileDateSubmission);
//                String anchor = "<a ";
//                if ((size != null) && (size.length() < 15))
//                    size = String.format(" %1$#15s", size);
//                else
//                    size = "unknown";
//
//                if ((date != null) && (date.length() < 25))
//                    date = String.format(" %1$#25s  ", date);
//                else
//                    date = "unknown";
//                String fp = (String) fileData.get(DocumentStore.metaFileKey);
//                if (StringUtils.isNotBlank(fp))
//                {
//                    anchor += " href=\"/RestApp/services/putfile/upload/result?fileId=" + fp + "\" >" + filePath + "</a>";
//                }
//                else
//                {
//                    anchor = filePath;
//                }
//                stringData.write(date + size + "   " + anchor + "</br>\n");
//            }
//        }
//        if (stringData != null)
//        {
//            result = "<HTML>\n";
//            result += "<HEAD>\n";
//            result += "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=ISO-8859-1\"\n";
//            result += "<TITLE>Document Storage Summary</TITLE>\n";
//            result += "</HEAD>\n";
//            result += "<BODY>\n";
//            result += stringData.toString();
//            result += "</BODY>\n";
//            result += "</HTML>\n";
//        }
//        return (result);
//    }

    @GET
    @Path("/echo")
    @Produces("text/plain")
    public String echo(@QueryParam("input") String input)
    {
    	String escapedInput = StringEscapeUtils.escapeHtml(input);
    	log.debug(String.format("escaped input: %s to: %s", input, escapedInput));
        return "[" + getDateTime() + "] Your input was: " + escapedInput;
    }

    private String getDateTime()
    {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date());
    }

    static
    {
        docStore = new DocumentStore();
        docStore.initializeDefaultFileContainer();

        log.debug("base path = " + docStore.getFileStorageContainerFilePath());
        log.debug("meta path = " + docStore.getMetaStorageContainerFilePath());

        if (!docStore.isRepositoryValid())
        {
            docStore.initializeFileContainer();

            log.debug("base2 path = " + docStore.getFileStorageContainerFilePath());
            log.debug("meta2 path = " + docStore.getMetaStorageContainerFilePath());
        }
    }
}
