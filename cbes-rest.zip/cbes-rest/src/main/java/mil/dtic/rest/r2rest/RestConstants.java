package mil.dtic.rest.r2rest;


public class RestConstants
{
  public static final String PDF = "application/pdf";
  public static final String XML = "application/xml";
  public static final String ZIP = "application/zip";
  public static final String TEXT = "text/plain";
  public static final String RESULTXML = "application/vnd.dtic.r2.result+xml";
  
  // look for this in the multipart form data. Otherwise we're picking a random one.
  public static final String FILE_FORM_PARAM = "file";
  // tmp folders start with these letters
  public static final String REST_TMP_FILE_PFX = "rst";
  // final XML response will always be stored in this file.
  public static final String XML_RESP_FILENAME = "xmlresponse.xml"; 
} 
