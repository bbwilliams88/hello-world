function addSorNot(intVal) {
  if (intVal === 1) {
    return '';
  } else {
    return 's';
  }
}
$(document).ready(function() {
  /* Alerts the user to select an agency if they haven't already */
  $('.checkForAgency').click(function(event) {
    var agency = $('#agency').val();
    if (agency == '') {
      event.preventDefault();
      alert ('You must select an agency.');
      return;
    }
  });

  /* Alerts the user to select a file if they haven't already */
  $('.checkForFile').click(function(event) {
    var filename = $(this).parent().parent().find('.testerFileInput').first().val();
    if (filename == '') {
      event.preventDefault();
      alert ('You must select a file.');
      return;
    }
  });

  /* changes the action url for every form based on the user's agency selection */
  $('#agency').change(function(event) {
    var agency = $(this).val();
    $('form').each(function(index) {
      var baseUrl = $(this).attr('data-action');
      $(this).attr('action', baseUrl + '?agency=' + agency);
    });
  });

  /* Handle the Echo Request */
  $('#echoSubmit').click(function(event) {
    event.preventDefault();
    $.get('putfile/echo', {input: $('#echoInput').val()}, function(data) {
      $('#echoOutput').html(data);
      });
  });

  /* Handle the Async Check Request */
  $('#checkAsyncJobSubmit').click(function(event) {
    event.preventDefault();
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    if ($('#uuid').val() !== $('#uuid').val().trim()) {
      var trimmedVal = $('#uuid').val().trim();
      $('#uuid').val(trimmedVal);
    }
    if ($('#uuid').val().length !== 36) {
      alert ('You must enter a valid Async job ID.');
      return;
    }
    $('#checkAsyncJobOutput').html(spinner);
    $.ajax({
      url: 'job/' + $('#uuid').val(),
      processData: false,
      contentType: false,
      type: 'GET',
      success: function(data, status, jqXHR) {
        var respMime = jqXHR.getResponseHeader('content-type');
        if (respMime.indexOf('plain') > -1) {
          document.getElementById('checkAsyncJobOutput').innerHTML = jqXHR.responseText;
        } else {
          var link = document.createElement('a');
          link.href = 'job/' + $('#uuid').val();
          if (respMime.indexOf('xml') > -1) {
            link.download = 'async_result.xml';
            link.innerHTML = 'download XML Response';
          } else {
            link.download = 'async_result.zip';
            link.innerHTML = 'download ZIP created';
          }
          document.getElementById('checkAsyncJobOutput').innerHTML = '';
          document.getElementById('checkAsyncJobOutput').appendChild(link);
        }
      },
      error: function(data, status, jqXHR) {
        document.getElementById('checkAsyncJobOutput').innerHTML = 'The async id you entered was not found in our system.';
      }
    });
  });

  /* Handle the Validate XML Request */
  $('#validateXmlSubmit').click(function(event) {
    event.preventDefault();
    var agency = $('#agency').val();
    if (agency == '')
    {
      alert ('You must select an agency.');
      return;
    }
    if ($('#validateXmlFile').val() == '') {
      alert ('You must select a file.');
      return;
    }
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    $('#validateXmlOutput').html(spinner);
    var fd = new FormData(document.getElementById('xmlvalidateform'));
    $.ajax({
      url: 'xmlv/validateXml?agency=' + agency,
      dataType: 'xml',
      data: fd,
      processData: false,
      contentType: false,
      type: 'POST',
      success: function(data, status, jqXHR) {
          if($('#validateXmlOutput').hasClass('text-error')){
        	  $('#validateXmlOutput').removeClass('text-error');
          }
          var errorCount = data.getElementsByTagNameNS("*", "Error").length;
          var warningCount = data.getElementsByTagNameNS("*", "Warning").length;
          var link = document.createElement('a');
          link.innerHTML = "(more info)";
          validationSummary = 'XML has ' + errorCount + ' error' + addSorNot(errorCount) + ' and ' + warningCount + ' warning' + addSorNot(warningCount) + ". ";
          link.addEventListener('click', function() {
          document.getElementById('xmlvalidateform').submit();
        });
        document.getElementById('validateXmlOutput').innerHTML = validationSummary;
        document.getElementById('validateXmlOutput').appendChild(link);
      },
      error: function (xhr, ajaxOptions, thrownError) {
          $('#validateXmlOutput').html(xhr.responseText).addClass('text-error');
        }
    });
  });

  /* Handle the Build Many R2s into PDFs Request */
  $('#multiR2PdfSubmit').click(function(event) {
    event.preventDefault();
    var agency = $('#agency').val();
    if (agency == '')
    {
      alert ('You must select an agency.');
      return;
    }
    if ($('#multiR2PdfFile').val() == '') {
      alert ('You must select a file.');
      return;
    }
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    $('#multiR2PdfOutput').html(spinner);
    var fd = new FormData(document.getElementById('buildr2pdfsform'));
    pdfGenUrl = 'pdfgen/buildR2Pdfs?agency=' + agency;
    if ($('#manyToMany').prop('checked')) {
      pdfGenUrl += '&singlePdf=false';
    }
    $.ajax({
      url: pdfGenUrl,
      data: fd,
      processData: false,
      contentType: false,
      type: 'POST',
      success: function(data) {
        $('#multiR2PdfOutput').html(data);
      }
    });
  });

  /* Handle the Jbook PDF Request */
  $('#jBookPdfSubmit').click(function(event) {
    event.preventDefault();
    var agency = $('#agency').val();
    if (agency == '')
    {
      alert ('You must select an agency.');
      return;
    }
    if ($('#jBookPdfFile').val() == '') {
      alert ('You must select a file.');
      return;
    }
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    $('#jBookPdfOutput').html(spinner);
    var fd = new FormData(document.getElementById('buildjbpdfform'));
    $.ajax({
      url: 'pdfgen/buildJbPdf?agency=' + agency,
      data: fd,
      processData: false,
      contentType: false,
      dataType: 'text',
      type: 'POST',
      success: function(data) {
        $('#jBookPdfOutput').html(data);
      }
    });
  });

  /* Handle the Master Jbook PDF Request */
  $('#masterJBookPdfSubmit').click(function(event) {
    event.preventDefault();
    var agency = $('#agency').val();
    if (agency == '') {
      alert ('You must select an agency.');
      return;
    }
    if ($('#masterJBookPdfFile').val() == '') {
      alert ('You must select a file.');
      return;
    }
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    $('#masterJBookPdfOutput').html(spinner);
    var fd = new FormData(document.getElementById('buildmjbpdfform'));
    $.ajax({
      url: 'pdfgen/buildMjbPdf?agency=' + agency,
      data: fd,
      processData: false,
      contentType: false,
      type: 'POST',
      success: function(data) {
        $('#masterJBookPdfOutput').html(data);
      }
    });
  });

  /* Handle the Build Many P40s into PDFs Request */
  $('#multiP40PdfSubmit').click(function(event) {
    event.preventDefault();
    var agency = $('#agency').val();
    if (agency == '')
    {
      alert ('You must select an agency.');
      return;
    }
    if ($('#multiP40PdfFile').val() == '') {
      alert ('You must select a file.');
      return;
    }
    var spinner = '<img alt="loading..." src="img/Ajax-loader.gif" height="32" width="32" />';
    $('#multiP40PdfOutput').html(spinner);
    var fd = new FormData(document.getElementById('buildp40pdfsform'));
    pdfGenUrl = 'pdfgen/buildP40Pdfs?agency=' + agency;
    if ($('#manyToMany').prop('checked')) {
      pdfGenUrl += '&singlePdf=false';
    }
    $.ajax({
      url: pdfGenUrl,
      data: fd,
      processData: false,
      contentType: false,
      type: 'POST',
      success: function(data) {
        $('#multiP40PdfOutput').html(data);
      }
    });
  });
});
