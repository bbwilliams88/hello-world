package mil.dtic.utility;

import static java.lang.String.format;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotNull;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


/**
 * Utility class that generates sql scrips and xsd updates for adding a new P40/R2 agency.
 * @author 1509934521@mil
 *
 */
public class AgencyUpdateGenerator {
	private static final Log log = LogFactory.getLog(AgencyUpdateGenerator.class);
	private static String AA_INSERT = "INSERT INTO APPROP_ACCOUNT (BUDGES_APPROP_ACCT_CODE, BUDGES_APPROP_ACCT_NAME, aa_status_flag) VALUES ('%s', '%s', 'A');";
	private static String BA_INSERT = "INSERT INTO proc_budget_activity (aa_ID, ba_num, ba_title, ba_status_flag, ba_RDTE_flag, ba_PROC_flag)  "
			+ "VALUES ((SELECT BUDGES_APPROP_ACCT_ID FROM APPROP_ACCOUNT a "
			+ "WHERE a.BUDGES_APPROP_ACCT_CODE = '%s' AND a.BUDGES_APPROP_ACCT_NAME = '%s'), "
			+ "%s ,'%s', 'A', 0, 1);";
	private static String BSA_INSERT = "INSERT INTO proc_budget_sub_activity (ba_id, bsa_num, bsa_title, bsa_status_flag) "
			+ "VALUES((SELECT ba_id FROM proc_budget_activity ba WHERE ba.aa_id = ("
			+ "SELECT BUDGES_APPROP_ACCT_ID FROM APPROP_ACCOUNT a WHERE a.BUDGES_APPROP_ACCT_CODE = '%s' AND a.BUDGES_APPROP_ACCT_NAME = '%s') AND ba.ba_title = '%s'), "
			+ "%s, '%s', 'A');";
	private static String SA_INSERT = "INSERT INTO SERVICE_AGENCY (BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME) "
			+ "VALUES ('%s','%s',(SELECT BUDGES_APPROP_ACCT_ID FROM APPROP_ACCOUNT a "
			+ "WHERE a.BUDGES_APPROP_ACCT_CODE = '%s' " + "AND a.BUDGES_APPROP_ACCT_NAME = '%s')," + "'A', '0', '%s');";
	private static String SUFFIX_INSERT = "INSERT INTO PE_SUFFIX (PS_SERV_AGY_ID, PS_SUFFIX) "
			+ "VALUES ((SELECT BUDGES_SERV_AGY_ID FROM SERVICE_AGENCY a " + "WHERE a.BUDGES_SERV_AGY_CODE = '%s'"
			+ " AND a.SERV_AGY_NAME = '%s'), '%s');";
	private static String SA_ACCT_INSERT = "INSERT INTO service_agency_acct (aa_ID, sa_ID, saa_budget_tag, saa_status_flag) "
			+ "VALUES ((SELECT BUDGES_APPROP_ACCT_ID FROM APPROP_ACCOUNT a "
			+ "WHERE a.BUDGES_APPROP_ACCT_CODE = '%s' AND a.BUDGES_APPROP_ACCT_NAME = '%s'), "
			+ "(SELECT BUDGES_SERV_AGY_ID FROM SERVICE_AGENCY a WHERE a.BUDGES_SERV_AGY_CODE = '%s' AND a.SERV_AGY_NAME = '%s'), "
			+ "'%s', 'A');";

	private static final ImmutableMap<String, String> xsdCommentMap = ImmutableMap.<String, String>builder()
			.put("R2AA_CODE", "<!--AppropriationCodeType-->")
			.put("R2AA_NAME", "<!--AppropriationNameType-->")
			.put("P40AA_TYPE", "<!--AppropriationNumberType-->")
			.put("P40AA_TITLE", "<!--AppropriationTitleType-->")
			.put("P40BA_TITLE", "<!--BudgetActivityTitleType-->")
			.put("P40BSA_TITLE", "<!--BudgetSubActivityTitleType-->")
			.build();

	private static String xsdEnum = "<xs:enumeration value=\"%s\"/>";

	private static final ObjectMapper om = new ObjectMapper();
	private static final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

	private static final Map<String, String> results = new HashMap<>();
	private static File outputFolder;

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class AgencyUpdateList {
		@JsonProperty
		@Valid
		List<Agency> newAgencies = new ArrayList<>();

	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class Agency {
		@JsonProperty
		@Valid
		List<P40AppropAccount> p40AppropAccountList = new ArrayList<>();

		@JsonProperty
		@Valid
		AppropAccount r2AppropAccount;

		@JsonProperty
		@Valid
		List<BudgetActivity> r2BaList = new ArrayList<>();

		@NotNull
		@JsonProperty
		String suffix;
		@NotNull
		@JsonProperty
		String code;
		@NotNull
		@JsonProperty
		String name;
		@JsonProperty
		String logo;

	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class AppropAccount {
		@NotNull
		@JsonProperty
		String code;

		@NotNull
		@JsonProperty
		String name;

		@JsonProperty
		boolean skip = false;

	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class P40AppropAccount extends AppropAccount {

		@JsonProperty
		@Valid
		List<P40BudgetActivity> p40BaList = new ArrayList<>();

	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class BudgetActivity {
		@NotNull
		@JsonProperty
		String baTitle;
	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class P40BudgetActivity extends BudgetActivity {

		@JsonProperty
		@NotEmpty
		@Valid
		List<BudgetSubActivity> bsas = new ArrayList<>();
	}

	@Getter
	@Setter
	@Accessors(fluent = true)
	public static class BudgetSubActivity {
		@NotNull
		@JsonProperty
		String bsaTitle;

	}

	public static void usage() {
		log.error(
				"Usage: java -jar agency-updater.jar <agencyconfig.jsonfile> <outputDir (default=<curentDir\newAgencies>)>");
		System.exit(0);
	}

	public static void main(String args[]) {
		try {
			if (args.length < 1) {
				usage();
			}

			outputFolder = new File(args.length == 2 ? args[1] : "./newAgencies");
			outputFolder.mkdirs();

			AgencyUpdateList newAgencyList = om.readValue(FileUtils.getFile(args[0]), AgencyUpdateList.class);
			Set<ConstraintViolation<AgencyUpdateList>> constraintViolations = validator.validate(newAgencyList);
			if (constraintViolations.isEmpty()) {
				buildResults(newAgencyList);
			} else {
				logValidationErrors(constraintViolations);
			}
		} catch (IOException e) {
			log.error("Error running util", e);
		}
	}

	private static void logValidationErrors(Set<ConstraintViolation<AgencyUpdateList>> violations) {
		for (ConstraintViolation<?> violation : violations) {
			log.error(violation.getPropertyPath() + " " + violation.getMessage());
		}
	}

	private static void buildResults(AgencyUpdateList agencyList) throws IOException {
		Map<String, List<String>> p40Xsd = new HashMap<>();
		Map<String, List<String>> r2Xsd = new HashMap<>();

		for (Agency agency : agencyList.newAgencies()) {
			List<String> agencySql = new ArrayList<>();

			if (!agency.r2AppropAccount().skip()) {
				agencySql.add(format(AA_INSERT, agency.r2AppropAccount().code(), agency.r2AppropAccount().name()));
				grabListFromMap(r2Xsd, "R2AA_CODE").add(String.format(xsdEnum, agency.r2AppropAccount().code()));
				grabListFromMap(r2Xsd, "R2AA_NAME").add(String.format(xsdEnum, agency.r2AppropAccount().name()));
			}
			if (null != agency.r2AppropAccount()) {
				agencySql.add(format(SA_INSERT, agency.code(), agency.name(), agency.r2AppropAccount().code(),
						agency.r2AppropAccount().name(), agency.logo()));
			} else if (null != agency.p40AppropAccountList().get(0)) {
				agencySql.add(format(SA_INSERT, agency.code(), agency.name(), agency.p40AppropAccountList().get(0).code(),
						agency.p40AppropAccountList().get(0).name(), agency.logo()));
			}
			agencySql.add(format(SUFFIX_INSERT, agency.code(), agency.name, agency.suffix()));

			for (P40AppropAccount p40Account : agency.p40AppropAccountList()) {
				if (!p40Account.skip()) {
					agencySql.add(format(AA_INSERT, p40Account.code(), p40Account.name()));
					grabListFromMap(p40Xsd, "P40AA_CODE").add(String.format(xsdEnum, p40Account.code()));
					grabListFromMap(p40Xsd, "P40AA_TITLE").add(String.format(xsdEnum, p40Account.name()));
				}
				agencySql.add(format(SA_ACCT_INSERT, p40Account.code(), p40Account.name(), agency.code(), agency.name(),
						"P40"));
				for (int baIter = 0; baIter < p40Account.p40BaList().size(); baIter++) {
					agencySql.add(format(BA_INSERT, p40Account.code(), p40Account.name(), (baIter + 1),
							p40Account.p40BaList().get(baIter).baTitle()));
					grabListFromMap(p40Xsd, "P40BA_TITLE")
							.add(String.format(xsdEnum, p40Account.p40BaList().get(baIter).baTitle()));
					for (int bsaIter = 0; bsaIter < p40Account.p40BaList().get(baIter).bsas().size(); bsaIter++) {
						agencySql.add(format(BSA_INSERT, p40Account.code(), p40Account.name(),
								p40Account.p40BaList().get(baIter).baTitle(), (bsaIter + 1),
								p40Account.p40BaList().get(baIter).bsas().get(bsaIter).bsaTitle()));
						grabListFromMap(p40Xsd, "P40BSA_TITLE").add(String.format(xsdEnum,
								p40Account.p40BaList().get(baIter).bsas().get(bsaIter).bsaTitle()));
					}
				}
			}
			if (null != agency.r2AppropAccount()) {
				agencySql.add(format(SA_ACCT_INSERT, agency.r2AppropAccount().code(), agency.r2AppropAccount().name(),
						agency.code(), agency.name(), "R2"));
			}
			results.put(agency.code(), StringUtils.join(agencySql, "\n"));
		}

		for (Map.Entry<String, String> entry : results.entrySet()) {
			File outputFile = new File(outputFolder, entry.getKey() + ".sql");
			FileUtils.write(outputFile, entry.getValue());
		}

		for (Map.Entry<String, List<String>> entry : p40Xsd.entrySet()){
			File outputFile = new File(outputFolder, entry.getKey() + ".xsd");
			FileUtils.writeStringToFile(outputFile, xsdCommentMap.get(entry.getValue()) + "\n");
			FileUtils.write(outputFile, StringUtils.join(entry.getValue(),"\n"));
		}
	}

	private static List<String> grabListFromMap(Map<String, List<String>> originalMap, String key) {
		List<String> returnVal = originalMap.get(key);
		if (returnVal != null) {
			return returnVal;
		} else {
			returnVal = new ArrayList<>();
			originalMap.put(key, returnVal);
		}

		return returnVal;
	}
}
