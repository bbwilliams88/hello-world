Dropzone.autoDiscover = false;

$(document).ready(function() {
  $(".cxeButton.cancel").hide();
//  if($("#r1PrcpTimestamp").html().length || $("#p1PrcpTimestamp").html().length) {
//    $("#cxePrcpNoData").hide();
//  }
  
  var prcpUploadFileListNode = document.querySelector("#prcpUpdate");
  
  if(prcpUploadFileListNode !== null) {
    //
    // prcp r-1/p-1 upload dropzone
    //
    //
    $("#prcpUpdateActions").remove(); // we are using custom file inputs, so remove the ones from the component template
    var prcpUpdateConfig = {
      maxFiles: 1,
      parallelUploads: 1,
      acceptedFiles: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel",
      autoQueue: true
    };
    var prcpUpdateDropzone = cxeCustomDropzone("prcpUpdate", "/r2/ViewNGRMS.PrcpUpdate:prcpupdate", prcpUpdateConfig);

    $("#prcpUpdatePreviews").hide();
    $("#prcpUpdateMessageContainer").hide();
    
    prcpUpdateDropzone.on("addedfile", function(file) {
      $("#prcpUpdatePreviews").show();
    });

    prcpUpdateDropzone.on("success", function (file, response) {
      var responsestr = JSON.stringify(response);
      console.log(response);

      // show the appropriate response alert box
      $("#prcpUpdateMessageContainer").show();
      $("#prcpUpdateServerMsg").removeClass("alert-success alert-danger");
      if (response.error) {
        console.log("update error");
        $("#prcpUpdateServerMsg").addClass("alert-danger");
        $("#prcpUpdateServerMsg").text("Error: " + response.error);
        $(".prcp-update-complete").text("NGRMS upload complete. Errors.");
      }
      else {
        console.log("update accepted");
        // update displayed timestamp
        if (response.r1PrcpTimestamp) {
          $("#r1PrcpTimestamp").text(response.r1PrcpTimestamp);
          $("#r1PrcpFilename").text(response.r1PrcpFilename);
          $("#prcpR1download").show();
        }
        if (response.p1PrcpTimestamp) {
          $("#p1PrcpTimestamp").text(response.p1PrcpTimestamp);
          $("#p1PrcpFilename").text(response.p1PrcpFilename);
          $("#prcpP1download").show();
        }

        $("#prcpUpdateServerMsg").addClass("alert-success");
        $("#prcpUpdateServerMsg").text("NGRMS data updated in CXE");
        $(".prcp-update-complete").text("NGRMS upload complete. Success.");
      }

      if (response.p1Uploaded[0])
      {
        p1Table.ajax.reload();
      }
      else
      {
        r1Table.ajax.reload();
      }
    });
    
    prcpUpdateDropzone.on("maxfilesexceeded", function(file){
      prcpUpdateDropzone.removeAllFiles();
      prcpUpdateDropzone.addFile(file);
    });

    prcpUpdateDropzone.on("removedfile", function(file) {
        $("#prcpUpdatePreviews").hide();
        $("#prcpUpdateMessageContainer").hide();
    });
  }
});