var buildPdfLinks;

// customizations for the default Dropzone

function configureDropzone(dz, toggleName, trueClass, falseClass) {
  // buttons with trueClass or falseClass control a hidden true/false input 
  // 'build single PDF'/'build zip of PDFs', 'build JB'/'build MJB'
  dz.on('addedfile', function(file) {
    var container = $(file.previewElement);
    var toggle = container.find('input[name="' + toggleName + '"]');
    container.find('.' + trueClass).click(function() {
      toggle.val('true');
    });
    container.find('.' + falseClass).click(function() {
      toggle.val('false');
    });
  });

  dz.on('sending', function(file, xhr, formData) {
    var container = $(file.previewElement);
    var toggle = container.find('input[name="' + toggleName + '"]').val();
    formData.append(toggleName, toggle);
  });
  
  // handle response
  dz.on('success', function(file, response) {
    var container = $(file.previewElement);
    if(response.success) {
      if(typeof response.downloadUrl != 'undefined' && response.downloadUrl.length) {
        var downloadButton = '<a href="' + buildPdfLinks.downloadFile + '/' + response.downloadUrl + '">';
        downloadButton += '<button class="cxeButton">';
        downloadButton += '<span>Download File</span>';
        downloadButton += '</button></a>';
      }
      container.find('.start').hide();
      container.find('.fileActionColumn').prepend(downloadButton);
    }
    else {
      var errStr = 'Error processing uploaded file';
      if(response.errorMessage) {
        errStr += ': ' + response.errorMessage;
      }
      container.find('[data-dz-errormessage]').text(errStr);
    }
  });
}

function buildPDFToolTabInit(urlJson){
	buildPdfLinks = urlJson;
  var xtpDropzone = cxeDefaultDropzone("xmlToPdf", buildPdfLinks.uploadR2);
  var xtjbDropzone = cxeDefaultDropzone("xmlToJb", buildPdfLinks.uploadJb);
  
  configureDropzone(xtpDropzone, 'asZip', 'zipOfPdfs', 'singlePdf');
  configureDropzone(xtjbDropzone, 'isMjb', 'mjb', 'jb');
  
  // form data for jb document assembly options
  xtjbDropzone.on('sending', function(file, xhr, formData) {
    var jbOptions = $("#jbOptions");
    jbOptions.find("input:checkbox").each(function(idx, checkbox) {
      formData.append($(this).attr('name'), $(this).prop('checked'));
    });
    jbOptions.find("input:text").each(function(idx, textfield) {
      formData.append($(this).attr('name'), $(this).val());
    });
  });
  
};