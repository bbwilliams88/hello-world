var jbInfo; // holds budget cycles, agencies/appropriations, and JB volumes inserted by Tapestry's JS support

function setInfo(infoJson) {
  console.log(JSON.stringify(infoJson));
  jbInfo = infoJson;
}

var jbApp = angular.module('angularJB', ['ngResource', 'datatables']);

jbApp.value('show', {                                                                     // INITIALIZE SHOW/HIDE CONTROLS
  basicInfo: true, exhibits: false, volumes: false, attachments: false,           // top-level sections
  selectExhibits: true, uploadExhibits: true, summary: true,  // exhibits subsections
  vol: [true],                                                                    // initialize subsection for first volume
  assemblyOptions: true, toc: true, docs: true,                                   // attachments subsections
  
  cols: { r1: true, number: true, exhibits: false, title: true, ba: true,  // columns in exhibit selection table
    bsa: false, projects: false, sa: true, bc: true, creator: false,
    createDate: false, modifier: false, modifyDate: true }
});

jbApp.value('labels', {
  r2: { budgetAreaShort: 'R-2', budgetAreaLong: 'RDT&E', exhibitLong: 'Program Element', exhibitShort: 'PE', r1p1: 'R-1' },
  p40: { budgetAreaShort: 'P-40', budgetAreaLong: 'Procurement', exhibitLong: 'Line Item', exhibitShort: 'LI', r1p1: 'P-1' }
});

jbApp.directive('dropzone', function() {
  return function(scope, element, attrs) {
    var config, dropzone;
    
    config = scope[attrs.dropzone];
    
    dropzone = new Dropzone(element[0], config.options);
    
    angular.forEach(config.eventHandlers, function(handler, event) {
      dropzone.on(event, handler);
    });
    

    element.find("button.reset").click(function(e) {
      dropzone.removeAllFiles();
    });
  }
});

var exhibitListFactory = function($resource) {
  
  var exhibitIcons = {
      'test': { 'cssClass':'badge-test', 'title':'Test Exhibit', 'letter':'T' },
      'r2Long': { 'cssClass':'badge-r2Long', 'title':'R2 Long Format', 'letter':'L' },
      'imported': { 'cssClass':'badge-import', 'title':'Imported Exhibit', 'letter':'I' },
      'valid': { 'cssClass':'badge-valid', 'title':'Valid Exhibit', 'letter':'V' },
      'warning': { 'cssClass':'badge-warning', 'title':'Warnings Exist', 'letter':'W' },
      'errorExists': { 'cssClass':'badge-error', 'title':'Errors Exist', 'letter':'E' },
      'allLocked': { 'img':'images/icon_padlock_blue.png', 'title':'Exhibit Frozen' },
      'anyLocked': { 'img':'images/icon_padlock.png', 'title':'Exhibit Locked' }
      };

  var exhibitTypeBadges = ['R2', 'R3', 'R4', 'R4a', 'R5', 'P40a', 'P3a', 'P18', 'P10', 'P5a', 'P21', 'P17', 'P23', 'P26'];
  
  var el = { 'exhibits': [] };

  el.fetchExhibits = function(budgetArea, budgetCycle) {
    console.log("fetching exhibit list data for " + budgetArea + "/" + budgetCycle);
    if(budgetArea.length && budgetCycle.length) {
      var bcParts = budgetCycle.split(" ");
      var url = '/r2/newExhibitList/' + [budgetArea, bcParts[0], bcParts[1]].join('/');
      var res = $resource(url);
      return res.get(function(data) {
        for(var i=0; i<data.aaData.length; i++) {
          ex = data.aaData[i];
          ex.source="Webapp";
          ex.filename="";
          if(budgetArea.toLowerCase() === 'p40') {
            //table compatibility
            ex.lineNum = ex.p1LineItemNumber;
            ex.exhibitNumber = ex.lineItemNumber;
            ex.title = ex.lineItemTitle;
            ex.serviceAgencyCode = ex.agencyCode;
            ex.serviceAgencyName = ex.agencyName;
            ex.errorExists = ex.error;
            ex.allLocked = ex.frozen;
          } else if(budgetArea.toLowerCase() === 'r2') {
            ex.budgetActivityNumber = ex.baNum;
            ex.exhibitNumber = ex.number;
          }
        }
        el.exhibits = data.aaData;
      });
    }
  };
  
  el.getBusinessRuleWarnings = function(exhibit) {
    var businessRuleValidator;
    var warnings = [];
    if (angular.isDefined(exhibit.id)) {
      businessRuleValidator = $resource('/r2/BusinessRuleWarningsJson/' + exhibit.id);
    } else {
      // R2ValidateXml endpoint for uploaded files
    }
    return businessRuleValidator.get(function(warningsData) {
      exhibit.valid = !angular.isDefined(warningsData.warningMessages) || warningsData.warningMessages.length === 0;
      if(!exhibit.valid) {
        exhibit.warningMessages = warningsData.warningMessages;
      }
    });
  };
  
  el.getExhibitIcons = function(exhibit) {
    var icons = [];
    angular.forEach(exhibitIcons, function(iconData, iconKey) {
      if((angular.isDefined(exhibit[iconKey]) && exhibit[iconKey] === true)
          || (iconKey === 'warning' && !exhibit.valid)) {
        icons.push(iconData);
      }
    });
    return icons;
  };
  
  el.getExhibitTypeBadges = function(exhibit) {
    var badges = [];
    var tempKey;
    exhibitTypeBadges.forEach(function(badge) {
      tempKey = badge.toLowerCase() + "Exists";
      if(angular.isDefined(exhibit[tempKey]) && exhibit[tempKey] === true) {
        badges.push(badge);
      }
    });
    return badges;
  };
  
  return el;
};

var selectedExhibitListFactory = function(VolumeList) {
  var sel = { 'exhibits': [] };
  
  sel.getList = function() {
    return sel.exhibits;
  }
  
  sel.reset = function() {
    sel.exhibits = [];
  }
  
  sel.addExhibit = function(exhibit, isP40, isService) {
    exhibit = sel.assignVolume(exhibit, isP40, isService);
    exhibit.isSelected = true;
    sel.exhibits.push(exhibit);
  }
  
  sel.assignVolume = function(exhibit, isP40, isService) {
    exhibit.volume = 0;
    if(!isP40 && isService && exhibit.budgetActivityNumber.length) {
      angular.forEach(VolumeList.getStandardVolumes().services, function(vol, index) {
        if(vol.description.indexOf(exhibit.budgetActivityNumber) != -1 && index < VolumeList.getVolumes().length) {
          exhibit.volume = index;
        }
      });
    }
    return exhibit;
  };
  
  sel.removeExhibit = function(exhibit) {
    var i = sel.exhibits.indexOf(exhibit);
    if(i > -1) {
      sel.exhibits.splice(i, 1);
      exhibit.isSelected = false;
    }
  };
  
  sel.removeFromSource = function(srcFilename) {
    console.log("removing all exhibits that come from " + srcFilename);
    for(var i=sel.exhibits.length - 1; i>= 0; i--) {
      if(sel.exhibits[i].selectionType === 'Upload' && sel.exhibits[i].uploadSource === srcFilename) {
        sel.exhibits.splice(i, 1);
      }
    }
  };
  
  return sel;
}

var volumeListFactory = function($filter) {
  var volDefaults = {
      'services': {
        'description': { 'disabled': false },
        'num':         { 'disabled': false },
        'numVolumes':     { 'val': 3,     'disabled': false }
      },
      'bigAgencies': {
        'description': { 'disabled': true },
        'num':         { 'disabled': true },
        'numVolumes':     { 'val': 1,     'disabled': false }
      },
      'smallAgencies': {
        'description': { 'disabled': true },
        'num':         { 'disabled': true },
        'numVolumes':     { 'val': 1,     'disabled': true }
      },
      'procurement' : {
        'description': { 'disabled': false },
        'num':         { 'disabled': false },
        'numVolumes':     { 'val': 1,          'disabled': false }
      }
  };
  var currentDefaults = volDefaults.services;
  
  var standardVolumes = jbInfo.volumes;
  var currentStandardVolumes = standardVolumes['r2'];
  
  var vl = { 'vols':[] };
  
  vl.getVolumes = function() {
    return vl.vols;
  }
  
  vl.getDefaults = function() {
    return currentDefaults;
  }
  
  vl.setDefaults = function(budgetArea, serviceAgency) {
    console.log("setting defaults for budgetarea=" + budgetArea + "sa=" + serviceAgency.code + "(isService=" + serviceAgency.isService + " isBigAgency=" + serviceAgency.isBigAgency);
    if(budgetArea === 'p40') {
      currentDefaults = volDefaults.procurement;
    } else {
      if(serviceAgency.isService) {
        currentDefaults = volDefaults.services;
      } else if(serviceAgency.isBigAgency) {
        currentDefaults = volDefaults.bigAgencies;
      } else {
        currentDefaults = volDefaults.smallAgencies;
      }
    }
  }
  
  vl.getStandardVolumes = function() {
    return currentStandardVolumes;
  }
  
  vl.setStandardVolumes = function(budgetArea) {
    if(budgetArea === 'r2' || budgetArea === 'p40') {
      currentStandardVolumes = standardVolumes[budgetArea];
    }
  }
  
  vl.addVolume = function(title, description, num, tovEntry) {
    vl.vols.push({
      'title': title,
      'description': description,
      'num': num,
      'tovEntry': tovEntry
    });
  };
  
  vl.addVolumeFromDefaults = function(budgetArea, serviceAgency) {
    var newIndex = vl.vols.length;
    var title, description, num, tovEntry = '';
    
    num = (newIndex + 1).toString();
    
    if(serviceAgency.isService) {
      if(currentStandardVolumes.services.length > newIndex) {
        description = currentStandardVolumes.services[newIndex].description;
        tovEntry = currentStandardVolumes.services[newIndex].tovEntry;
      }
    } else {
      var matchingAgency = $filter('filter')(currentStandardVolumes.agencies, {'code':serviceAgency.code})[0];
      console.log("matching agency: " + JSON.stringify(matchingAgency));
      description = matchingAgency.description;
      num = matchingAgency.num;
   // R2 multi-volume agencies keep their MJB volume # and add suffixes
      if(newIndex > 0 && newIndex < 25) {
        num = matchingAgency.num + String.fromCharCode(97 + newIndex); // 97 = ascii lowercase a
      }
    }
    if(!tovEntry.length) {
      tovEntry = "Volume " + num;
    }
    vl.addVolume(title, description, num, tovEntry);
  }
  
  vl.defaultVolumeList = function(budgetArea, agency) {
    console.log("in defaultVolumeList()");
    vl.vols = [];
    for(var i=0; i<currentDefaults.numVolumes.val; i++) {
      console.log("adding volume with area=" + budgetArea + ", agency=" + agency);
      vl.addVolumeFromDefaults(budgetArea, agency);
    }
    return vl.vols;
  }
  
  vl.toMjbVols = function() {
    vl.vols = [];
    angular.forEach(currentStandardVols.agencies, function(vol, index) {
      vl.addVolume('', vol.description, vol.num, vol.tovEntry);
    });
    return vl.vols;
  }
  
  vl.deleteVolume = function(volIndex, selectedExhibitList) {
    var len = vl.vols.length;
    // Check that there are multiple volumes and that the volume to delete is in-range
    if(len < 2 || volIndex >= len) {
      return;
    }
    // Reassign any exhibits from deleted volume to vol 1
    angular.forEach(selectedExhibitList, function(exhibit, index) {
      if(exhibit.volume === volIndex) {
        exhibit.volume = 0;
      } else if(exhibit.volume > volIndex) {
        exhibit.volume = exhibit.volume - 1;
      }
    });
    vl.vols.splice(volIndex, 1);
  }
  
  // Test to differentiate the "(see NIP and MIP justification books)" entries
  vl.mjbVolumeHasAgency = function(vol) {
    return vol.code.length > 0;
  }
  return vl;
};

var attachmentListFactory = function() {
  var al = {
      'attachments': [ { 'title':'Introduction', 'filename':'', 'includeInAll':true, 'allowTitleEdit':false, 'supplemental':false },
                       { 'title':'Summary', 'filename':'', 'includeInAll':true, 'allowTitleEdit':true, 'supplemental':false },
                       { 'title':'Comptroller R-1', 'filename':'', 'includeInAll':true, 'allowTitleEdit':false, 'supplemental':false },
                       { 'title':'Acronyms', 'filename':'', 'includeInAll':true, 'allowTitleEdit':false, 'supplemental':false },
                       { 'title':'', 'filename':'', 'includeInAll':true, 'allowTitleEdit':true, 'supplemental':true }
                       ]
  };
  return al;
};

var topLevelController = function(show, labels, $scope, $log) {

  $scope.show = show;
  $scope.labels = labels['r2'];
  $scope.links = { uploadExhibit: ':onuploadexhibit' };
  
  // CONTROLLER FUNCTION DEFINITIONS
  
  $scope.logJb = function() {
    $log.debug(JSON.stringify($scope.jb));
  }
  
  // Getters/setters for basic information
  
  $scope.getBudgetArea = function() {
    if(angular.isDefined($scope.jb.basicInfo.budgetArea)) {
      return $scope.jb.basicInfo.budgetArea;
    } else {
      return null;
    }
  }
  
  $scope.isP40 = function() {
    // so we don't have to keep explicitly testing the value of budgetArea in the templates
    return (angular.isDefined($scope.jb.basicInfo.budgetArea) && $scope.jb.basicInfo.budgetArea.toLowerCase() === 'p40');
  }
  
  $scope.getBudgetCycle = function() {
    if(angular.isDefined($scope.jb.basicInfo.budgetCycle)) {
      return $scope.jb.basicInfo.budgetCycle;
    } else {
      return null;
    }
  }
  
  $scope.isBES = function() {
    return !$scope.jb.basicInfo.budgetCycle.$isEmpty && $scope.jb.basicInfo.budgetCycle.cycle.toUpperCase() === 'BES';
  }
  
  $scope.getServiceAgency = function() {
    if(angular.isDefined($scope.jb.basicInfo.serviceAgency)) {
      return $scope.jb.basicInfo.serviceAgency;
    } else {
      return null;
    }
  }
  
  $scope.isSmallAgency = function() {
    return !$scope.isP40()
      && $scope.getServiceAgency() !== null
      && !$scope.getServiceAgency().isService
      && !$scope.getServiceAgency().isBigAgency;
  }
  
  $scope.isMultiVol = function () {
    return(angular.isDefined($scope.jb.volumes) && $scope.jb.volumes.length > 1);
  }
  
  $scope.hasWarnings = function() {
    var hasWarnings = false;
    angular.forEach($scope.jb.selectedExhibits, function(exhibit, index) {
      if(!exhibit.valid) {
        hasWarnings = true;
      }
    });
    return hasWarnings;
  }
  
  $scope.validationModal = function() {
    $('#validationModal').modal();
  }
  
  // END CONTROLLER FUNCTION DEFINITIONS
  
  // jbInfo holds budget cycles, agencies/appropriations, and JB volumes
  // It is set by by Tapestry's JS support after the page is rendered and before it's sent to the client
  var agencies = jbInfo.agencies;
  $scope.agencies = jbInfo.agencies['r2'];
  $scope.cycles = jbInfo.cycles;
  $scope.links = jbInfo.links;
  
  $scope.jb = { 'basicInfo': {} };
  
  $scope.$watch('jb.basicInfo.budgetArea', function(newArea, oldArea) {
    // update anything that needs to be switched when changing between r2 and p40
    $log.debug("watcher function for budget area, new=" + newArea + " old=" + oldArea);
    if(angular.isDefined(newArea)) {
      newArea = newArea.toLowerCase();
    }
    if('r2' === newArea || 'p40' === newArea) {
      $scope.agencies = agencies[newArea];
      $scope.labels = labels[newArea];
      // keep agency if possible by finding the equivalent agency on the P40 (or R2) side
      var oldAgency = $scope.getServiceAgency();
      var correspondingAgencyIndex = 0;
      if(oldAgency != null) {
        for(var i=0; i<$scope.agencies.length; i++) {
          if($scope.agencies[i].code === oldAgency.code) {
            correspondingAgencyIndex = i;
            break;
          }
        }
      } 
      $scope.jb.basicInfo.serviceAgency = $scope.agencies[correspondingAgencyIndex];
      $log.debug("about to broadcast budget area change");
      $scope.$broadcast("budgetAreaChange", newArea, oldArea);
    }
  });
  
  
  $scope.$watch('jb.basicInfo.budgetCycle', function(newBc, oldBc) {
    if(newBc!== oldBc) {
      $scope.$broadcast("budgetCycleChange", newBc, oldBc);
    }
  });
  
  $scope.$watch('jb.basicInfo.serviceAgency', function(newSa, oldSa) {
    if(newSa != null) {
      if(newSa.code!= 'DW' && newSa.code != 'DEFW') {
        $scope.jb.basicInfo.isMjb = false;
      } else {
        $scope.jb.basicInfo.isMjb = true;
      }
      $scope.jb.basicInfo.appropriation = $scope.jb.basicInfo.serviceAgency.appropriations[0];
    }
    $log.debug("about to broadcast sa change");
    $scope.$broadcast("serviceAgencyChange", newSa, oldSa);
  });
  
  $scope.$watch('jb.basicInfo.isMjb', function(newValue, oldValue) {
    $scope.$broadcast("mjbChange", newValue, oldValue);
  });
  
  $scope.jb.basicInfo.budgetCycle = $scope.cycles[0];
  $scope.jb.basicInfo.budgetArea = 'r2';
  $scope.jb.basicInfo.serviceAgency = $scope.agencies[0];
  
};

var exhibitUploadController = function($scope, SelectedExhibitList) {
  $scope.hasFilesAdded = false;
  $scope.exhibitUploadConfig = {
      'options': {
        'url': $scope.links.uploadExhibit,
        'parallelUploads': 10,
        'autoQueue': true,
        'acceptedFiles': 'application/pdf,application/zip,application/x-zip-compressed,text/xml',
        'previewsContainer': '#jbExhibitFileRows',
        'previewTemplate': document.querySelector('#jbExhibitFileRows').innerHTML,
        'clickable': '#jbUploadExhibitInput-button'
      },
      'eventHandlers': {
        'addedfile': function(file) {
          console.log("added file");
          $scope.hasFilesAdded = true;
          $scope.$apply();
        },
        'removedfile': function(file) {
          SelectedExhibitList.removeFromSource(file.name);
          $scope.$apply();
        },
        'reset': function(file) {
          $scope.hasFilesAdded = false;
          $scope.$apply();
        },
        'uploadprogress': function(file, progress) {
          file.previewElement.querySelector(".progress-bar").textContent = progress + "%";
          if(progress > 99) {
            angular.element(file.previewElement.querySelector(".upload-active")).show();
          }
        },
        'success': function(file, response) {
          console.log(JSON.stringify(response));
          angular.element(file.previewElement.querySelector(".upload-active")).hide();
          angular.element(file.previewElement.querySelector(".upload-complete")).show();
          if(typeof response.exhibits != 'undefined') {
            $scope.show.summary = true;
            for(var i=0; i<response.exhibits.length; i++) {
              if(response.exhibits[i].exhibitType.toLowerCase() === $scope.getBudgetArea()) {
                response.exhibits[i].uploadSource = file.name;
                SelectedExhibitList.addExhibit(response.exhibits[i], $scope.isP40(), $scope.getServiceAgency().isService);
                $scope.$apply();
              }
            }
          } else if(typeof response.errorMessages != 'undefined' && response.errorMessages.length > 0) {
            var progressBar = angular.element(file.previewElement.querySelector(".progress-bar"));
            progressBar.text("Error.");
            progressBar.addClass("progress-bar-danger");
            progressBar.removeClass("progress-bar-success");
            var errorElm = angular.element(file.previewElement.querySelector(".error"));
            errorElm.append("<ul />");
            var errorList = errorElm.find("ul");
            for(var i=0; i<response.errorMessages.length; i++) {
              errorList.append("<li>" + response.errorMessages[i] + "</li>");
            }
          }
        },
        'error': function(file, message) {
          file.previewElement.querySelectorAll("[data-dz-errormessage]")[0].textContent = "An error occurred while uploading file "+file.name+".  Please try again.";
          angular.element(file.previewElement.querySelector(".upload-active")).hide();
          angular.element(file.previewElement.querySelector(".upload-complete")).hide();
          var progressBar = angular.element(file.previewElement.querySelector(".progress-bar"));
          progressBar.text("Error.");
          progressBar.addClass("progress-bar-danger");
          progressBar.removeClass("progress-bar-success");
        }
      }
  };
  // remove empty template div now that Dropzone has grabbed it
  angular.element(document.querySelector('#jbExhibitFileRows')).empty();
};

var exhibitsController = function(DTOptionsBuilder, ExhibitList, SelectedExhibitList, $scope) {
  var self = this;
  self.dtOptions = DTOptionsBuilder.newOptions()
                                  .withOption("autoWidth", false)
                                  .withOption("stateSave", true)
                                  .withOption("order", [[ 12, 'desc']])
                                  .withLanguage({
                                    'emptyTable': 'No results found.'
                                  });
  console.log(JSON.stringify($scope.show.cols));
  var createColumnDefs = function(cols) {
    console.log("creating column defs for " + JSON.stringify(cols));
    return [
     { "targets":0, "sortable":false, "searchable":false }, //selection checkbox
     { "targets":1, "visible":cols.r1 },               //R1/P1 num
     { "targets":2, "visible":cols.number },               //exhibit num + badges
     { "targets":3, "visible":cols.exhibits, "sortable":false, "defaultContent":"<span>Exhibit Types</span>" },
     { "targets":4, "visible":cols.title },               //title
     { "targets":5, "visible":cols.ba },               //BA num
     { "targets":6, "visible":($scope.isP40() && cols.bsa) || (!$scope.isP40() && cols.projects) },  //number of projects (R2) or BSA (P40)
     { "targets":7, "visible":cols.sa },               //agency
     { "targets":8, "visible":cols.bc },               //budget cycle
     { "targets":9, "visible":cols.creator },  //created by
     { "targets":10, "visible":cols.createDate }, //create date
     { "targets":11, "visible":cols.modifier }, //modified by
     { "targets":12, "visible":cols.modifyDate }               //modify date
    ];
  };
  self.dtColumnDefs = createColumnDefs($scope.show.cols);
  self.dtInstance={};

  $scope.tableControls = { 'bcFilter': $scope.getBudgetCycle() };
  ExhibitList.fetchExhibits($scope.getBudgetArea(), $scope.tableControls.bcFilter.value).$promise.then(function() {
    self.exhibitTable = ExhibitList.exhibits;
  });
  $scope.jb.selectedExhibits = SelectedExhibitList.getList();
  
  $scope.$on("budgetAreaChange", function(e, newArea, oldArea) {
    // reset selected exhibit list so we aren't mixing R2 and P40
    $scope.jb.selectedExhibits = [];
    // refresh exhibit selection table with new data from server
    ExhibitList.fetchExhibits(newArea, $scope.getBudgetCycle().value).$promise.then(function() {
      self.exhibitTable = ExhibitList.exhibits;
      self.dtInstance.DataTable.draw();
    });
  });
  
  $scope.$on("budgetCycleChange", function(e, newBc, oldBc) {
    $scope.tableControls.bcFilter = newBc;
    $scope.updateExhibitTableBcFilter();
  });
  
  $scope.updateColumnVisibility = function(cols) {
    self.dtColumnDefs = createColumnDefs(cols);
    self.dtInstance.DataTable.draw();
  }
  
  $scope.updateExhibitTableBcFilter = function() {
    ExhibitList.fetchExhibits($scope.getBudgetArea(), $scope.tableControls.bcFilter.value).$promise.then(function() {
      self.exhibitTable = ExhibitList.exhibits;
      self.dtInstance.DataTable.draw();
    });
  };
  
  $scope.updateExhibitTableSaFilter = function() {
    var searchString;
    if(!angular.isDefined($scope.tableControls.saFilter) || $scope.tableControls.saFilter == null) {
      searchString = '';
    } else {
      searchString = $scope.tableControls.saFilter.code;
    }
    self.dtInstance.DataTable.column(".r2List_agency").search(searchString).draw();
  }
  
  $scope.toggleExhibitSelect = function(exhibit) {
    var i = SelectedExhibitList.getList().indexOf(exhibit);
    if(i > -1 && !exhibit.isSelected) {
      SelectedExhibitList.removeExhibit(exhibit);
    }
    if(i < 0 && exhibit.isSelected) {
      $scope.show.summary = true;
      ExhibitList.getBusinessRuleWarnings(exhibit).$promise.then(function(responseData) {
        SelectedExhibitList.addExhibit(exhibit, $scope.isP40(), $scope.getServiceAgency().isService);
      });
    }
  };
  
  $scope.deselectExhibit = function(exhibit) {
    exhibit.isSelected = false;
    $scope.toggleExhibitSelect(exhibit);
  };
  
  $scope.getExhibitIcons = function(exhibit) {
    return ExhibitList.getExhibitIcons(exhibit);
  };
  
  $scope.constrainLength = function(str, maxLength) {
    if(str && str.length > maxLength) {
      str = str.substr(0,maxLength-2) + "...";
    }
    return str;
  };
  
  $scope.logExhibits = function() {
    console.log(JSON.stringify(self.exhibitTable));
  };
  

  
};

var volumesController = function(VolumeList, SelectedExhibitList, $scope) {
  $scope.jb.volumes = VolumeList.defaultVolumeList($scope.getBudgetArea(), $scope.getServiceAgency(), $scope.isBES());
  $scope.jb.selectedExhibits = SelectedExhibitList.exhibits;
  
  $scope.$on("budgetAreaChange", function(e, newArea, oldArea) {
    console.log("volumesController budget area change...");
    VolumeList.setStandardVolumes(newArea);
  });
  
  $scope.$on("serviceAgencyChange", function(e, newAgency, oldAgency) {
    console.log("volumesController sa change...");
    VolumeList.setDefaults($scope.getBudgetArea(), newAgency);
    $scope.jb.volumes = VolumeList.defaultVolumeList($scope.getBudgetArea(), newAgency, $scope.isBES());
    angular.forEach(SelectedExhibitList.getList(), function(exhibit, index) {
        exhibit.volume = 0;
    });
  });
  
  $scope.$on("mjbChange", function(e, newValue, oldValue) {
    if(newValue) {
      angular.forEach($scope.jb.selectedExhibits, function(exhibit, index) {
        exhibit.isSelected = false;
      });
      SelectedExhibitList.reset();
      $scope.jb.volumes = VolumeList.toMjbVols();
    } else {
      $scope.jb.volumes = VolumeList.defaultVolumeList($scope.getBudgetArea(), $scope.getServiceAgency(), $scope.isBES());
    }
  });
  
  $scope.deleteVolume = function(index) {
    VolumeList.deleteVolume(index, $scope.jb.selectedExhibits);
  };
  
  $scope.addVolume = function() {
    VolumeList.addVolumeFromDefaults($scope.getBudgetArea(), $scope.getServiceAgency());
  };
  
  $scope.addRemoveDisabled = function() {
    return VolumeList.getDefaults().numVolumes.disabled;
  }
  
  $scope.descriptionDisabled = function() {
    return VolumeList.getDefaults().description.disabled;
  }
  
  $scope.volNumDisabled = function() {
    return VolumeList.getDefaults().num.disabled;
  }
};

var attachmentsController = function(AttachmentList, $scope) {
  $scope.jb.attachmentList = AttachmentList.attachments;
  $scope.jb.assemblyOptions = { forceEven: true };
};

var tocController = function($scope) {
  var getTocDefaults = function() {
    return {
      tov: { val:true, disabled: $scope.isSmallAgency() }, //agencies in MJB vol.5 must include table of volumes
      perVolByBA: { val:true, disabled:false },
      perVolByTitle: { val:true, disabled:false },
      perVolGenR1P1: { val:$scope.isBES(), disabled:!$scope.isBES() }, //disable generating own R1/P1 in PB, enable as default but optional in BES
      crossVolByBA: { val: $scope.isMultiVol() || $scope.isSmallAgency(), disabled: $scope.isMultiVol() }, //require for multi-vol, set as optional default for single-vol small agencies
      crossVolByTitle: { val: $scope.isMultiVol() || $scope.isSmallAgency(), disabled: $scope.isMultiVol() },
      crossVolR1P1: { val: $scope.isBES && $scope.isMultiVol(), disabled: !$scope.isBES() } //disabled in PB, optional in BES and only default if multi-vol
      //note: in attachments section, Comptroller-provided R1/P1 is required in PB, disabled in BES
    }
  };
  var forceDefaultsForDisabledOptions = function(toc) {
    angular.forEach($scope.tocDefaults, function(option, key, toc) {
      if(option.disabled) {
        console.log("option " + key + " is disabled, setting to " + option.val);
        this[key] = option.val;
      }
    });
  };
  var updateDefaults = function() {
    $scope.tocDefaults = getTocDefaults();
    console.log("forcing defaults for top-level TOC");
    forceDefaultsForDisabledOptions($scope.jb.toc);
    angular.forEach($scope.jb.volumes, function(vol, index) {
      console.log("forcing defaults for TOC volume " + (index+1));
      forceDefaultsForDisabledOptions(vol.toc);
    });
  };
  var initializeDefaults = function() {
    var newToc = {};
    angular.forEach($scope.tocDefaults, function(option, key) {
      newToc[key] = option.val;
    });
    return newToc;
  }
  $scope.tocDefaults = getTocDefaults();
  $scope.jb.toc = initializeDefaults();
  $scope.$on("budgetCycleChange", function(e, newBc, oldBc) {
    updateDefaults();
  });
  $scope.$on("serviceAgencyChange", function(e, newSa, oldSa) {
    updateDefaults();
  });
  
  console.log("in TOC controller, defaults = " + JSON.stringify($scope.tocDefaults));

}

jbApp.factory("ExhibitList", exhibitListFactory);
jbApp.factory("SelectedExhibitList", selectedExhibitListFactory);
jbApp.factory("VolumeList", volumeListFactory);
jbApp.factory("AttachmentList", attachmentListFactory);
jbApp.controller("jbCtrl", topLevelController);
jbApp.controller("exhibitUploadCtrl", exhibitUploadController);
jbApp.controller("exhibitsCtrl", exhibitsController);
jbApp.controller("exhibitUploadCtrl", exhibitUploadController);
jbApp.controller("volumesCtrl", volumesController);
jbApp.controller("attachmentsCtrl", attachmentsController);
jbApp.controller("tocCtrl", tocController);