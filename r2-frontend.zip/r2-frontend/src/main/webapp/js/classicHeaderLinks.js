$(document).ready(function () {
	if ($("#manageR2Link").length){
		$("#manageR2Link").children("a").attr("href", "/r2/newr2manage");
	}
	if (("#createR2Link").length){
		$("#createR2Link").children("a").attr("href", "/r2/r2add");
	}
	if ($("#helpPageLink").length){
		$("#helpPageLink").children("a").attr("href", "/r2/HelpPage.html");
		$("#helpPageLink").children("a").attr("target", "_blank");
	}
	if ($("#contactUsLink").length){
		$("#contactUsLink").children("a").attr("href", "/r2/ContactUsPage.html");
	}
	if ($("#userProfileLink").length){
		$("#userProfileLink").children("a").attr("href", "/r2/UserProfile.html");
	}
	if ($("#copyR2Link").length){
		$("#copyR2Link").show();
	}
	if ($("#freezeR2Link").length){
		$("#freezeR2Link").show();
	}
	if ($("#controlNumbersLink").length){
		$("#controlNumbersLink").show();
	}
	});	