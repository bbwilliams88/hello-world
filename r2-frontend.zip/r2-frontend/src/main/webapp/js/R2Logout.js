$(document).ready(function () {
  $.ajax({ 
	dataType: "json",
	url: "/r2/endpoints/R2Logout",
	cache: false,
    success: function(data, status) {
     var success = ("success" in data && status === "success");
     if (success) {
       $('#r2LogoutMessage').html('<div class="alert alert-success"><p>You are logged out of the system.  To log back in:</p></div>')
     }
     else {
       $('#r2LogoutMessage').html('<div class="alert alert-danger"><p>System error, user may still be logged in.</p></div>')
     }
    }
  }).fail(function(jqXHR, textStatus, errorThrown) {
    $('#r2LogoutMessage').html('<div class="alert alert-danger"><p>System error, user still logged in.</p></div>')
    console.log(textStatus + ": " + errorThrown);
  })
})