//confirmation utilities peppered across the t4 pages

function getConfirmation() {
  var str = 'Please make sure to save your changes. Are you sure you want to proceed?';
  var result = confirm(str);

  return result;
}

function getLoseFormDataConfirmation() {
  var str = 'If you proceed, you will lose the selections/entries you made and you will have to re-enter them if/when you come back to this page. Are you sure you want to move away from this page?';
  var result = confirm(str);

  return result;
}

function getLogoutConfirmation() {
  var str = 'Are you sure you want to logout?';
  var result = confirm(str);  
  return result;
}

function getWarningForDeletion() {
  var str = 'Are you sure you want to delete?';
  var result = confirm(str);

  return result;
}

function checkMaxLength(obj)
{
  var maxLength = obj.getAttribute ? parseInt(obj.getAttribute("maxlength")) : "";  
  if (obj.getAttribute && obj.value.length > maxLength)
    obj.value = obj.value.substring(0, maxLength);
  var charsLeft = maxLength - obj.value.length;
  window.status = "Max characters: " + maxLength + ". You have " + charsLeft + " characters left.";  
}

function clearStatusMessage()
{
  window.status = "";
}
