// TAPESTRY 5.4.1 UPGRADE

var idList = ["#peNum", "#baNum", "#peTag", "#modifiedUser", "#budgetCycleFilter", "#serviceAgencyFilter"];

idList.forEach(removeClass)

function removeClass(id)
{
	$(id).removeClass("form-control");
}


function openHelpWindow()
{
	var baseUrl = window.location.href;
	var newUrl = baseUrl + "Help";
	window.open(newUrl, "newPeSelectionPageHelp", "popup");
}

function showProgressBar()
{
	var overlay = document.getElementById("overlay");
	overlay.style.display = "flex";
	var progressContainer = document.getElementById("progressBarContainer");
	progressContainer.style.display = "flex";
}

window.onload = function()
{
	var overlay = document.getElementById("overlay");
	overlay.style.display = "none";
	var progressContainer = document.getElementById("progressBarContainer");
	progressContainer.style.display = "none";
}

function collapseFilters()
{
	var expandButton = document.getElementById("expandButton");
	expandButton.style.display = "inline-block";

	var collapseButton = document.getElementById("collapseButton");
	collapseButton.style.display = "none";
	
	var filterMenu = document.getElementById("filterMenu"); 
	filterMenu.classList.toggle("active");
}

function expandFilters()
{
	var expandButton = document.getElementById("expandButton");
	expandButton.style.display = "none";

	var collapseButton = document.getElementById("collapseButton");
	collapseButton.style.display = "inline-block";

	var filterMenu = document.getElementById("filterMenu");
	filterMenu.classList.toggle("active");
}