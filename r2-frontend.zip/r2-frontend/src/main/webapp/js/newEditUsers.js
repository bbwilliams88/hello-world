var userTableUrl = "";
var userTableLIUrl = "";
var SaveUpdatesURL = "";
var newAdminUsersLinks;

//
function setResponseModalMessages(headerText, messages) {
	$("#r2modalHeader").text(headerText);
	var msgList = $("#alertMessagesList");
	msgList.empty();
	for (var i = 0; i < messages.length; i++) {
		msgList.append("<li>" + messages[i] + "</li>");
	}
	$("#alertMessagesModal").modal();
}

//
function newEditUserPageInit(urlJson) {
	var liChange = false;
	var p40Change = false;
	var agencyChange = false;
	var peCheckboxChange = false;
	var liCheckboxChange = false;

	userTablePeUrl = urlJson.getUserTablePeUrl;
	userTableLiUrl = urlJson.getUserTableLiUrl;
	SaveUpdatesURL = urlJson.onSaveUpdatesURL;
	getRole(); // ?

	var r2BudgetCycleSelect = $("#r2BudgetCycleFilter").val();
	var r2BudgetCycleSet = new Set();

	var p40BudgetCycleSelect = $("#p40BudgetCycleFilter").val();
	var p40BudgetCycleSet = new Set();

	// start newEditUserTable for PE
	var newEditUserTable = $("#editUserTable")
			.DataTable(
					{
						// "order": [[ 12, 'desc' ]],
						"autoWidth" : false,
						"serverSide" : false,
						"stateSave" : true,
						"info" : false,
						"language" : {
							"emptyTable" : "No results found."
						},
						"deferRender" : true,
						"ajax" : {
							"url" : userTablePeUrl,
							"type" : "POST",
							"data" : function(data) {
								data.budgetCycle = $("#r2BudgetCycleFilter")
										.val();
							}
						},
						"columns" : [
								{
									"data" : "PeNumber",
									"searchable" : true,
									"sortable" : true,
									"title" : "PE Number",
									"render" : function(data, type, full, meta) {
										return data
												+ getExhibitIcons(data, type,
														full, meta);
									}
								},
								{
									"data" : "agency",
									"searchable" : true,
									"sortable" : true,
									"title" : "Service/Agency",
									"sClass" : "userListAgencies"
								},
								{
									"data" : "BudgetCycle",
									"searchable" : true,
									"sortable" : false,
									"render" : function(data, type, full, meta) {
										var budgetCyle = full.BudgetCycle
										r2BudgetCycleSet.add(budgetCyle);
										return budgetCyle;
									}
								},
								{
									"data" : "viewEdit",
									"searchable" : false,
									"sortable" : false,
									"title" : "View / Edit",
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.agency
												+ "' value='viewEdit' name='"
												+ full.PeID
												+ "' checked/>"
												+ "<span style='display: none;'>_viewEdit</span>";
										var uncheckedRadio = "<input type='radio' class='radio' id='"
												+ full.agency
												+ "' value='viewEdit' name='"
												+ full.PeID + "'/>";
										if (full.priv == "VIEWEDIT") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								},
								{
									"data" : "view",
									"searchable" : false,
									"sortable" : false,
									"title" : "View",
									"sClass" : "view",
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.agency
												+ "' value='view' name='"
												+ full.PeID
												+ "' checked/>"
												+ "<span style='display: none;'>_view</span>";
										var uncheckedRadio = "<input  type='radio'class='radio' id='"
												+ full.agency
												+ "' value='view' name='"
												+ full.PeID + "'/>";
										if (full.priv == "VIEW") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								},
								{
									"title" : "None",
									"searchable" : false,
									"sortable" : false,
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.agency
												+ "' value='none' name='"
												+ full.PeID
												+ "' checked/>"
												+ "<span style='display: none;'>_none</span>";
										var uncheckedRadio = "<input type='radio' class='radio' id='"
												+ full.agency
												+ "' value='none' name='"
												+ full.PeID + "'/>";
										if (full.priv == "NONE") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								} ]

					});
	// end newEditUserTable for PE

	// start - newEditUserTable for LineItem
	var newEditUserLITable = $("#editUserLineItemTable")
			.DataTable(
					{
						// "order": [[ 12, 'desc' ]],
						"autoWidth" : false,
						"serverSide" : false,
						"stateSave" : true,
						"info" : false,
						"language" : {
							"emptyTable" : "No results found."
						},
						"deferRender" : true,
						"ajax" : {
							"url" : userTableLiUrl,
							"type" : "POST",
							"data" : function(data) {
								data.budgetCycle = $("#p40BudgetCycleFilter")
										.val();
							}
						},
						"columns" : [
								{
									"data" : "LineItemNumber",
									"searchable" : true,
									"sortable" : true,
									"title" : "Line Item Number",
									"render" : function(data, type, full, meta) {
										return data
												+ getExhibitIcons(data, type,
														full, meta);
									}
								},
								{
									"data" : "agency",
									"searchable" : true,
									"sortable" : true,
									"title" : "Service/Agency",
									"sClass" : "userListAgencies"
								},
								{
									"data" : "BudgetCycle",
									"searchable" : true,
									"sortable" : false,
									"render" : function(data, type, full, meta) {
										var budgetCyle = full.BudgetCycle
										p40BudgetCycleSet.add(budgetCyle);
										return budgetCyle;
									}
								},
								{
									"data" : "viewEdit",
									"searchable" : false,
									"sortable" : false,
									"title" : "View / Edit",
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.lineItemId
												+ "' value='viewEdit' name='"
												+ full.lineItemId
												+ "' checked/>"
												+ "<span style='display: none;'>_viewEdit</span>";
										var uncheckedRadio = "<input type='radio' class='radio' id='"
												+ full.lineItemId
												+ "' value='viewEdit' name='"
												+ full.lineItemId + "'/>";
										if (full.priv == "VIEWEDIT") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								},
								{
									"data" : "view",
									"searchable" : false,
									"sortable" : false,
									"title" : "View",
									"sClass" : "view",
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.lineItemId
												+ "' value='view' name='"
												+ full.lineItemId
												+ "' checked/>"
												+ "<span style='display: none;'>_view</span>";
										var uncheckedRadio = "<input  type='radio'class='radio' id='"
												+ full.lineItemId
												+ "' value='view' name='"
												+ full.lineItemId + "'/>";
										if (full.priv == "VIEW") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								},
								{
									"title" : "None",
									"searchable" : false,
									"sortable" : false,
									"render" : function(data, type, full, meta) {
										var checkedRadio = "<input type='radio' class='radio' id='"
												+ full.lineItemId
												+ "' value='none' name='"
												+ full.lineItemId
												+ "' checked/>"
												+ "<span style='display: none;'>_none</span>";
										var uncheckedRadio = "<input type='radio' class='radio' id='"
												+ full.lineItemId
												+ "' value='none' name='"
												+ full.lineItemId + "'/>";
										if (full.priv == "NONE") {
											return checkedRadio;
										} else {
											return uncheckedRadio;
										}
									}
								} ]

					});
	// end - newEditUserTable for LineItem

	var initialPrivs = [];
	var initialP40Privs = []; // CXE-6577
	var initialAgencies = [];
	var initialCreationRights;
	var initialLiCreationRights;
	var disabledAgencies = [];
	var role;

	function getRole() {
		role = $("#role").text();
	}

	function getDisabledAgencies() { // Site Admins can only edit pe privs on
		// pes for agencies they adminster
		disabledAgencies = [];
		var allCheckboxes = $('[type=checkbox]');
		allCheckboxes.each(function() {
			if (this.disabled) {
				disabledAgencies.push(this.value);
			}
		})
	}

	function disableRadios() {
		getDisabledAgencies();
		var allRadios = $('[class=radio]');
		allRadios.each(function() {
			if (disabledAgencies.indexOf(this.id) > -1) {
				this.disabled = true; // disable agencies privs that you don't
				// administer for
				// i.e. NAVY web admin cannot change privs on AIR FORCE PEs
			}
		})
	}

	function setInitialAgencies() {
		initialAgencies = [];
		var agencies = $(".agencyTr").find("input");
		for (var i = 0; i < agencies.length; i++) {
			if (agencies[i].checked) {
				initialAgencies.push(agencies[i].name);
			}
		}
	}

	function setInitialCreation() {
		if (peCheckbox.prop("checked")) {
			initialCreationRights = true; // creation allowed
		} else {
			initialCreationRights = false; // creation not allowed
		}

		if (liCheckbox.prop("checked")) {
			initialLiCreationRights = true;
		} else {
			initialLiCreationRights = false;
		}

	}

	function setInitialPrivs() {
		console.log("start setInitialPrivs");
		c = 0;
		initialPrivs = [];

		$.each(newEditUserTable.rows().data(), function(row) {
			initialPrivs.push({
				peID : this.PeID,
				priv : this.priv
			});
		})
		console.log("end setInitialPrivs : " + initialPrivs + " count: " + c);
	}

	function setInitialP40Privs() {
		console.log("start setInitialP40Privs");
		c = 0;
		initialP40Privs = [];
		$.each(newEditUserLITable.rows().data(), function(row) {
			c++;
			initialP40Privs.push({
				lineItemId : this.lineItemId,
				priv : this.priv
			});
		})
		console.log("end setInitialP40Privs : " + initialP40Privs + " count: "
				+ c);
	}

	function setInitialState() {
		console.log("start setInitialState")
		setInitialAgencies();
		setInitialPrivs();
		setInitialP40Privs();
		setInitialCreation();
		console.log("end setIntialState")
	}

	function cannotEditAdminRights() {

		if (role == "R2AppMgr" || role == "R2SiteAdmin") {
			$('#buttonGroupOne').show();
			peCheckbox.attr('disabled', true);
			liCheckbox.attr('disabled', true);
			$('.serviceAgencyInputs').show();
			$('#buttonGroupTwo').show();
			$('.managePEOptions').hide();
			$('#buttonGroupThree').hide();
			$('.manageLiOptions').hide();
			$('#buttonGroupFour').hide();
		}
		if (role == "R2LocalSiteAdmin") {
			$('#buttonGroupOne').show();
			peCheckbox.attr('disabled', false);
			liCheckbox.attr('disabled', false);
			$('.serviceAgencyInputs').show();
			$('#buttonGroupTwo').show();
			$('.managePEOptions').show();
			$('#buttonGroupThree').show();
			$('.manageLiOptions').show();
			$('#buttonGroupFour').show();
		}
	}

	newEditUserLITable.on('draw.dt', function() {
		console.log("start newEditUserLITable onDraw.dt");
		setInitialP40Privs();

		$(".radio").on("click", function() {
			var radio = this;
			var radioId = this.name;
			var radioValue = this.value;

			var radioViewEditValue = false;
			var radioViewValue = false;
			var radioNoneValue = false;
			// issue: name is a primary key, it is possible to have dups
			// when
			// multiple datatables used in same js file.
			// that is why the id on LineItems have an underscore.
			console.log("button clicked = " + this.name);
			// radios should only be one record, but because of the
			// issue above,
			// it can have more than one
			// in which the check will go to the other record.
			radios = document.getElementsByName(this.name);

			$.each(radios, function(radio) {
				if (this.name === radioId) {
					switch (radioValue) {
					case "viewEdit":
						radioViewEditValue = true;
						break;
					case "view":
						radioViewValue = true;
						break;
					case "none":
						radioNoneValue = true;
					}
				}
			});

			data = [];
			$.each(newEditUserLITable.rows().data(), function(row) {
				if (this.lineItemId == radioId) {
					if (radioViewEditValue) {
						this.priv = "VIEWEDIT";
					}
					if (radioViewValue) {
						this.priv = "VIEW";
					}
					if (radioNoneValue) {
						this.priv = "NONE";
					}
				}
			});

			checkLiTablePriv();
			updateModifiedBanner();

		});

	});

	newEditUserTable.on('draw.dt', function() {
		console.log("start newEditUserTable onDraw.dt")
		setInitialState();
		cannotEditAdminRights();
		disableRadios();

		$(".radio").on("click", function() {
			var radio = this;
			var radioId = this.name;
			var radioValue = this.value;

			var radioViewEditValue = false;
			var radioViewValue = false;
			var radioNoneValue = false;
			// issue: name is a primary key, it is possible to have dups
			// when
			// multiple datatables used in same js file.
			// that is why the id on LineItems have an underscore.
			console.log("button clicked = " + this.name);
			// radios should only be one record, but because of the
			// issue above,
			// it can have more than one
			// in which the check will go to the other record.
			radios = document.getElementsByName(this.name);

			$.each(radios, function(radio) {
				if (this.name === radioId) {
					switch (radioValue) {
					case "viewEdit":
						radioViewEditValue = true;
						break;
					case "view":
						radioViewValue = true;
						break;
					case "none":
						radioNoneValue = true;
					}
				}
			});

			data = [];
			$.each(newEditUserTable.rows().data(), function(row) {
				if (this.PeID == radioId) {
					if (radioViewEditValue) {
						this.priv = "VIEWEDIT";
					}
					if (radioViewValue) {
						this.priv = "VIEW";
					}
					if (radioNoneValue) {
						this.priv = "NONE";
					}
				}
			});

			checkPeTablePriv();
			updateModifiedBanner();
		});

	});

	var peCheckbox = $("#peCheckBox");
	var liCheckbox = $("#liCheckBox");

	$("#r2BudgetCycleFilter").on("change", function() {
		newEditUserTable.ajax.reload();
	})

	$("#p40BudgetCycleFilter").on("change", function() {
		newEditUserLITable.ajax.reload();
	})

	$("#reset").on("click", function() {
		newEditUserTable.ajax.reload();
		newEditUserLITable.ajax.reload();
	});

	function saveAgencies() {
		var agencyNames = [];
		var agencies = $(".agencyTr").find("input");
		for (var i = 0; i < agencies.length; i++) {
			if (agencies[i].checked) {
				agencyNames.push(agencies[i].name);
			}
		}
		return agencyNames;
	}

	function canCreatePE() {
		var canCreatePE;
		if (peCheckbox.prop("checked") == true) {
			canCreatePE = true
		} else {
			canCreatePE = false;
		}
		return canCreatePE;
	}

	function canCreateLI() {
		var canCreateLi;
		if (liCheckbox.prop("checked") == true) {
			canCreateLi = true
		} else {
			canCreateLi = false;
		}
		return canCreateLi;
	}

	$(document).on(
			'click',
			'.newEditUserSave',
			function() {

				var request = {};
				var data = [];
				var userRights = [];
				var userP40Rights = [];

				$.each(initialPrivs, function(row) {
					var id = this.peID;
					var intialpriv = this.priv;

					$.each(newEditUserTable.rows().data(), function(row) {
						if (id == this.PeID && intialpriv !== this.priv) {// check
							// for
							// changes
							// in
							// privs
							userRights.push({
								peID : this.PeID,
								access : this.priv
							});
						}
					})
				})

				// process LineItem Table for specific privileges on a LineItem
				// Number
				$.each(initialP40Privs, function(row) {
					var id = this.lineItemId;
					var intialLIpriv = this.priv;
					console.log("initial P40 id: " + id + " intitialLIPriv: "
							+ intialLIpriv);

					$.each(newEditUserLITable.rows().data(),
							function(row) {
								console.log("lineItemId: " + this.lineItemId
										+ " priv: " + this.priv);
								if (id == this.lineItemId
										&& intialLIpriv !== this.priv) {// check
									// for
									// changes
									// in
									// privs
									userP40Rights.push({
										lineItemId : this.lineItemId,
										access : this.priv
									});
								}
							})
				})

				if (userRights.length > 0) { // must be at least 1 change in
					// privs to save
					request.ProgamElementsPrivs = userRights;
				}

				if (userP40Rights.length > 0) { // must be at least 1 change in
					// privs to save
					request.LineItemPrivs = userP40Rights;
				}

				if (JSON.stringify(saveAgencies()) !== JSON
						.stringify(initialAgencies)) { // check for changes in
					// agencies
					request.agencies = saveAgencies();
				}
				if (canCreatePE() != initialCreationRights) { // check for
					// changes in PE
					// Creation
					// rights
					request.canCreatePE = canCreatePE();
				}

				if (canCreateLI() != initialLiCreationRights) { // check for
					// changes in LI
					// Creation
					// rights
					request.canCreateLI = canCreateLI();
				}

				if (request.ProgamElementsPrivs == null
						&& request.LineItemPrivs == null
						&& request.agencies == null
						&& request.canCreatePE == null
						&& request.canCreateLI == null) {
					return; // if there are no changes, don't save
				} else {
					setResponseModalMessages("Saving Changes",
							[ "Updating..." ]); // else save
					data = {
						"json" : JSON.stringify(request)
					}
					$.ajax({
						url : SaveUpdatesURL,
						type : "POST",
						data : data,
						success : function(response) {
							if (response.reload) { // change in agency
								location.reload();
							}
							if (response.successMessages) {
								setResponseModalMessages("Update Saved",
										response.successMessages);
								setInitialState(); // reset state checker to
								// check for future changes
								checkPeCheckboxPriv();
								checkLiCheckboxPriv();
								checkLiTablePriv();
								checkPeTablePriv();
								updateModifiedBanner();
							}
							if (response.errorMessages) {
								setResponseModalMessages("Error",
										[ response.errorMessages ]);
							}
						},
						error : function() {
							setResponseModalMessages("error",
									[ "A failure occured while saving" ]);
						}
					});
				}
				;

			})

	$(".agencyTr > .checkbox").on(
			"click",
			function() {
				var change = false;
				var checkedAgencies = [];
				var allAgencies = $(".agencyTr").find("input");
				$.each(allAgencies, function(i) {
					var agency = $(this)[0];
					if (agency.checked) {
						checkedAgencies.push(agency.name);
					}
				})
				var found = 0;
				$.each(initialAgencies,
						function(index) {
							if ($.inArray(initialAgencies[index],
									checkedAgencies) > -1) {
								found++;
							}
						})
				if (found != initialAgencies.length
						|| found === initialAgencies.length
						&& checkedAgencies.length != initialAgencies.length) {
					change = true;
				}
				agencyChange = change;
				updateModifiedBanner();
			})

	peCheckbox.on("click", function() {
		checkPeCheckboxPriv();
		updateModifiedBanner();
	})

	liCheckbox.on("click", function() {
		checkLiCheckboxPriv();
		updateModifiedBanner();
	})

	function checkPeCheckboxPriv() {
		if (peCheckbox.prop("checked") != initialCreationRights) {
			peCheckboxChange = true;
		} else {
			peCheckboxChange = false;
		}
	}

	function checkLiCheckboxPriv() {
		if (liCheckbox.prop("checked") != initialLiCreationRights) {
			liCheckboxChange = true;
		} else {
			liCheckboxChange = false;
		}
	}

	function checkPeTablePriv() {
		var change = false;
		$.each(initialPrivs, function(index) {
			$.each(newEditUserTable.rows().data(), function(row) {
				var initPriv = initialPrivs[index];
				var newPriv = $(this)[0];
				if (initPriv.peID == newPriv.PeID
						&& initPriv.priv != newPriv.priv) {
					change = true;
				}
			})
		})
		p40Change = change;
	}

	function checkLiTablePriv() {
		var change = false;
		$.each(initialP40Privs, function(index) {
			$.each(newEditUserLITable.rows().data(), function(row) {
				var initP40Priv = initialP40Privs[index];
				var newP40Priv = $(this)[0];
				if (initP40Priv.lineItemId == newP40Priv.lineItemId
						&& initP40Priv.priv != newP40Priv.priv) {
					change = true;
				}
			})
		})
		liChange = change;
	}

	function updateModifiedBanner() {
		if (!liChange && !p40Change && !agencyChange && !peCheckboxChange
				&& !liCheckboxChange) {
			$(".cxe-warning-banner").hide();
		} else {
			$(".cxe-warning-banner").show();
		}
	}

};