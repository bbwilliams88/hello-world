
var isRfr;
var isOSDAnalyst;
var isOMBAnalyst;
var budgetCycleText;

/**
 * Called by Tapestry to save the index of each column before the DataTable
 * re-arranges the columns.  Enables getIndex() to function later in life.
 */
function beforeDatatable() {
	isRfr = jQuery('#rfrStatus').val();
	isOSDAnalyst = jQuery('#osdAnalystStatus').val();
	isOMBAnalyst = jQuery('#ombAnalystStatus').val();
	jQuery('#datatable th').each(function(index) {
		jQuery('#datatable').data(this.id, index);
	});
}

/**
 * Returns the saved column index value for the given header ID.
 * 
 * @param headerId The column name key to find the saved index.
 * @returns The index for the column name.
 */
function getIndex(headerId) {
	return jQuery('#datatable').data(headerId);
}


/**
 * Called by Tapestry to set up and configure the DataTable.
 */
function setupDatatable(eventLink, dateRangeChanged) {
	$.fn.dataTable.moment('MMM DD, YYYY HH:mm');

	var trackingPageTable = $('#datatable').DataTable({
		"ajax" : eventLink,
		"language" : {
			"search" : "Filter:"
		},
		"order" : [ getIndex('datesubmitted'), 'desc' ],
		"orderCellsTop" : true,
		"stateDuration" : 1800, // 30 minutes
		"autoWidth" : false,
		// Custom number of entries to show in the dropdown.
		aLengthMenu: [
			[10, 25, 50, 100, -1],
			[10, 25, 50, 100, "All"]
		],
		"buttons" : getButtonConfig(),
		"sDom" : 'B<"H"lfr>t<"F"ip>',
		"stateSave" : true,
		"stateLoaded" : function(settings, data) {
			if (dateRangeChanged) {
				data.start = 0;
			}
		},
		"stateLoadParams" : function(settings, data) {
			if (dateRangeChanged) {
				data.start = 0;
			}
		},
		"columnDefs": [{
			"targets": '_all',
			"defaultContent": ""
		}],
		"columns" : (isRfr == null ? buildNonRFRColumns() : buildRFRColumns())
	});

	$.fn.dataTable.ext.errMode = function(settings, helpPage, message) {
		console.log("Datatable error during loading of data: " + message);
		renderServerError("Datatable error during loading of data: " + message,
				"Server Error");
	}

	var r2SelectAllCheckbox = $("#r2SelectAllCheckbox");

	trackingPageTable.on('draw.dt', function() {
		var trackingListData = trackingPageTable.data();

		var trackingPageSelectionBoxes = $('.r2TrackingPageSelectionCheckbox'); 
		
		trackingPageSelectionBoxes.unbind("click");
		trackingPageSelectionBoxes.click(function(e) {
			var selectedRowIndex = $(this).val();
			var selectedRow = trackingListData[selectedRowIndex];
			var checked = $(this).is(":checked");
			selectedRow.selected = checked;

			updateSelectAllCheckbox(trackingPageSelectionBoxes,
					r2SelectAllCheckbox, trackingListData);
		});

		r2SelectAllCheckbox.unbind("click");
		r2SelectAllCheckbox.click(function(e) {
			var checked = $(this).is(":checked");
			var displayedRows = $(".r2TrackingPageSelectionCheckbox");
			displayedRows.prop("checked", checked);
			//now update the data
			displayedRows.each(function() {
				var index = $(this).val();
				trackingListData[index].selected = checked;
			});

		});

		updateSelectAllCheckbox(trackingPageSelectionBoxes,
				r2SelectAllCheckbox, trackingListData);

	});

	$("#r2modalDeleteConfirmation").on("show.bs.modal", function(e) {
		deleteButtonHandler(trackingPageTable);
	});
}

function getButtonConfig(){
	let result = [];
	
	if(!isOSDAnalyst){
	
	result.push({
		"extend" : "csv",
		"text" : "Download CSV",
		"fieldSeparator" : ",",
		"extension" : ".csv",
		"exportOptions" : {
			"columns" : [1,2,3,4,6,7,8,9,10],
			"orthogonal" : "export"
		}
	});
	
	}
	
	else{
		result.push({
			text: 'Status Tracker',
			action : function (e, dt, node, config){
				$.ajax({
					url : statusTrackerLink,
					type: 'GET',
					success : function(){
						window.location = statusTrackerLink;
					}
				});
			}	
		});
	}
	
	return result;
}

var submittedDateFilterLink;
var serviceOrAgencyFilterLink;
var jobFilterLink;
var sourceFilterLink;
var isRfr;
var workFlowFilterLink;
var budgetCycleFilterLink;

var analystdSelectChangeLink;

var statusTrackerLink;

function initializeStatusTrackerLink(aLink){
	statusTrackerLink = aLink;
}

function initializeOSDSelectChangeLink(aLink){
	analystdSelectChangeLink = aLink;
}

function initializeBudgetCycleFilter(aLink) {
	budgetCycleFilterLink = aLink;
	jQuery('#filterByBudgetCycle').change(handleBudgetCycleFilterChange);
}

function initializeWorkFlowFilter(aLink) {
	workFlowFilterLink = aLink;
	jQuery('#filterByWorkFlowStatus').change(handleWorkFlowFilterChange);
}

function initializeDateFilter(aLink) {
	submittedDateFilterLink = aLink;
	jQuery('#filterBySubmittedDate').change(handleSubmittedDateFilterChange);
}

function initializeServiceAgencyFilter(aLink) {
	serviceOrAgencyFilterLink = aLink;
	jQuery('#service-agency-filter').change(handleServiceOrAgencyFilterChange);
}

function initializeJobFilter(aLink) {
	jobFilterLink = aLink;
	jQuery('#jobTypeFilter').change(handleJobFilterChange);
}

function initializeSourceFilter(aLink) {
	sourceFilterLink = aLink;
	jQuery('#sourceTypeFilter').change(handleSourceFilterChange);
}

/**
 * Handles the Submitted Date range pulldown changing by issuing an AJAX call to Tapestry
 */

function handleSubmittedDateFilterChange() {
	var dateRange = jQuery('#filterBySubmittedDate :selected').val();
	jQuery.post(submittedDateFilterLink, {
		"filterText" : dateRange
	}, function() {
		window.location.reload();
	});
}

function handleWorkFlowFilterChange() {
	var workFlow = jQuery('#filterByWorkFlowStatus :selected').val();
	jQuery.post(workFlowFilterLink, {
		"filterText" : workFlow
	}, function() {
		window.location.reload();
	});
}

function handleBudgetCycleFilterChange() {
	var budgetCycle = jQuery('#filterByBudgetCycle :selected').val();
	jQuery.post(budgetCycleFilterLink, {
		"filterText" : budgetCycle
	}, function() {
		window.location.reload();
	});
}
/**
 * Handles the Service/Agency pulldown changing by issuing an AJAX call to Tapestry
 */
function handleServiceOrAgencyFilterChange() {
	var agencyId = jQuery('#service-agency-filter :selected').val();
	jQuery.post(serviceOrAgencyFilterLink, {
		"filterText" : agencyId
	}, function() {
		window.location.reload();
	});
}
/**
 * Handles the Job Type Filter pulldown changing by issuing an AJAX call to Tapestry
 */
function handleJobFilterChange() {
	jQuery.post(jobFilterLink, {
		"filterText" : this.value
	}, function() {
		window.location.reload();
	});
}
/**
 * Handles the Job Source Filter pulldown changing by issuing an AJAX call to Tapestry
 */
function handleSourceFilterChange() {
	jQuery.post(sourceFilterLink, {
		"filterText" : this.value
	}, function() {
		window.location.reload();
	});
}

function setValueForDateFilter(aRange) {
	jQuery("#filterBySubmittedDate").val(aRange);
}

function setValueForSAFilter(id) {
	jQuery("#service-agency-filter").val(id);
}

function setValueForWorkFlowFilter(id) {
	jQuery("#filterByWorkFlowStatus").val(id);
}

function setValueForBudgetCycleFilter(id) {
	jQuery("#filterByBudgetCycle").val(id);
}

function setValueForJobTypeFilter(id) {
	jQuery("#jobTypeFilter").val(id);
}

function setValueForJobSourceFilter(id) {
	jQuery("#sourceTypeFilter").val(id);
}

/**
 * Refresh the page every 2 seconds until the build is complete 
 */
function refreshUntilComplete(timeoutPeriod) {
	setTimeout("window.location.reload(true);", timeoutPeriod);
}

function initializeColumnSelectionModal(columnsState) {
	// read the table's state to set the checkboxes if it is null set the default values;
	var counter = 0;
	$("[id^='r2ColumnCheckbox_']").each(function() {
		var colVisible = columnsState[counter].bVisible;
		if (colVisible) {
			$(this).prop("checked", "checked");
		}
		counter++;
	});
}

function getColumns() {
	let array = [];
	
	if(isRfr == null){
		array.push({
			"data" : "selected",
			"searchable" : false,
			"orderable" : false,
			"sClass" : "r2List_checkbox",
			"visible" : true,
			"render" : function(data, type, full, meta) {
				var selectedText = '';

				if (full.selected) {
					selectedText = ' checked="checked"';
				}

				return '<input type = "checkbox" class="r2TrackingPageSelectionCheckbox" value = "'
						+ meta.row + '"' + selectedText + '/>'

			},
			"defaultContent" : ""
		});
		
		array.push({
			"data" : "trackingNumber",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push({
			"data" : "budgetCycle",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "appropriation",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "title",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "source",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "status",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "user",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "agency",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "dateCreated",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "workflowStatus",
			"searchable" : true,
			"orderable" : true,
		});
	}
	
	if(isRfr != null){		
		if(isOSDAnalyst){
			array.push(		{
				"data" : "selected",
				"searchable" : false,
				"orderable" : false,
				"sClass" : "r2List_checkbox",
				"visible" : true,
				"render" : function(data, type, full, meta) {
					var selectedText = '';

					if (full.selected) {
						selectedText = ' checked="checked"';
					}

					return '<input type = "checkbox" class="r2TrackingPageSelectionCheckbox" value = "'
							+ meta.row + '"' + selectedText + '/>'

				},
				"defaultContent" : "",
			});
		}
		
		array.push({
			"data" : "budgetCycle",
			"searchable" : true,
			"orderable" : true,
			"width" : "7%"
		});
		
		array.push(		{
			"data" : "agency",
			"searchable" : true,
			"orderable" : true,
			"width" : "5%"
		});
		
		array.push(		{
			"data" : "appropriation",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "title",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push(		{
			"data" : "user",
			"searchable" : true,
			"orderable" : true,
			"width" : "4%"
		});
		
		array.push(		{
			"data" : "dateCreated",
			"searchable" : true,
			"orderable" : true,
			"width" : "9%"
		});
		
		array.push(		{
			"data" : "workflowStatus",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push({
			"data" : "trackingNumber",
			"searchable" : true,
			"orderable" : true,
			"width" : "7%"
		});
		
		array.push(		{
			"data" : "osdAnalystSelected",
			"searchable" : true,
			"orderable" : true,
			"sClass" : "r2List_checkbox",
			"visible" : true,
			"render" : function(data, type, full, meta) {
				var selectedText = '';
								
				if (full.selected) {
					selectedText = ' checked="checked"';
				}
				
				if(data){
					selectedText = ' checked="checked"';
				}
				
				var returnString = '<input type = "checkbox" id="osdSelect" class="" value = "'
					+ meta.row + '"' + selectedText + '/>';
				
				budgetCycleText=jQuery('#filterByBudgetCycle :selected').text();
				if(isOMBAnalyst || !full.ombAnalystSelected && !budgetCycleText.includes("BES") && !isRfr){
					returnString = '<input type = "checkbox" id="osdSelect" class="" disabled="true" value = "' 
						+ meta.row + '"' + selectedText + '/>';
				}
				
				return returnString

			},
			"defaultContent" : ""
		});
		
		array.push({
			"data" : "osdAnalystName",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push({
			"data" : "osdClearedDate",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push({
			"data" : "ombAnalystSelected",
			"searchable" : true,
			"orderable" : true,
			"visible" : true,
			"render" : function(data, type, full, meta) {
				var selectedText = '';

				if (full.selected) {
					selectedText = ' checked="checked"';
				}
				
				if(data){
					selectedText = ' checked="checked"';
					isOMBAnalystChecked = true;
				}
				
				
				var returnString = '<input type = "checkbox" id="ombSelect" class="" value = "'
					+ meta.row + '"' + selectedText + '/>';
				
				if(isOSDAnalyst){
					returnString = '<input type = "checkbox" id="ombSelect" class="" disabled="true" value = "' 
						+ meta.row + '"' + selectedText + '/>';
				}
				
				return returnString

			},
			"defaultContent" : ""
		});
		
		array.push({
			"data" : "ombAnalystName",
			"searchable" : true,
			"orderable" : true,
		});
		
		array.push({
			"data" : "ombClearedDate",
			"searchable" : true,
			"orderable" : true,
		});
	}

	return array;
}

function deleteButtonHandler(trackingPageTable) {
	var trackingListData = trackingPageTable.data();
	var rowStr = "";

	var dataVals = {
		action : "deleteTrackingJobs",
		trackingJobs : []
	};
	var selectedRows = [];
	var rows = [];
	var count = 0;
	for (var i = 0; i < trackingListData.length; i++) {
		if (trackingListData[i].selected) {
			var selectedRow = {
				"trackingNumber" : null,
				"title" : null,
				"agency" : null
			};
			selectedRow.trackingNumber = trackingListData[i].trackingNumber;
			selectedRow.title = trackingListData[i].title;
			selectedRow.agency = trackingListData[i].agency;
			selectedRows[count] = selectedRow;
			rows[count] = {
				id : trackingListData[i].trackingNumber
			};
			count++;
		}
	}
	dataVals.trackingJobs = rows;

	var deleteFormContainer = $("#r2DeleteFormContainer");
	var deleteConfirmationBtn = $("#confirmDeleteBtn");
	var deleteErrorMessage = $("#deleteErrorMessage");

	deleteErrorMessage.empty();
	if (count == 0) {
		deleteFormContainer.children().hide();
		deleteConfirmationBtn.prop("disabled", true);
		deleteErrorMessage
				.append("<h4>Error:</h4><p>No jobs were selected.</p>");
		deleteErrorMessage.show();
	} else {
		deleteErrorMessage.hide();
		var deleteTable = $("#r2DeleteTrackingJobs").dataTable({
			"autoWidth" : false,
			"data" : selectedRows,
			"pageLength" : 5,
			"paging" : true,
			"searching" : false,
			"lengthChange" : false,
			"columns" : [ {
				"data" : "trackingNumber",
				"bSearchable" : false,
				"bSortable" : false
			}, {
				"data" : "title",
				"bSearchable" : false,
				"bSortable" : false
			}, {
				"data" : "agency",
				"bSearchable" : false,
				"bSortable" : false
			}

			],
			"destroy" : true
		});

		deleteFormContainer.children().show();
		deleteConfirmationBtn.prop("disabled", false);

		deleteConfirmationBtn.unbind("click");
		deleteConfirmationBtn.click(function(e) {
			e.preventDefault();
			// add progress bar
			var jsonObj = {
				"json" : JSON.stringify(dataVals)
			};
			$("#r2modalProgress").modal('show');
			$
					.ajax({
						url : "/r2/endpoints/trackingpagejobdelete",
						dataType : "json",
						type : "POST",
						data : jsonObj,
						success : function(response) {
							$("#r2modalProgress").modal('hide');
							renderServerResponse(response,
									"Delete Tracking Page Jobs");
							clearSelections(trackingListData);

							trackingPageTable.ajax.reload();
						},
						error : function(response) {
							console.log("failed");
							var responseStr = JSON.stringify(response);
							console.log(responseStr);
							$("#r2modalProgress").modal('hide');
							renderServerError(response,
									"Delete Tracking Page Jobs");
							$("#r2modalEndpointResponse").modal();
						}
					});
		});
	}
}

function renderServerError(response, responseHeader) {
	var successMessage = $("#successMessage");
	var errorMessage = $("#errorMessage");
	var header = $("#r2modalEndpointResponseHeader");

	header.empty();
	header.append(responseHeader);
	successMessage.empty();
	errorMessage.empty();
	errorMessage.hide();
	successMessage.hide();

	var errorMessage = $("#errorMessage");
	var errHtml = "<h4>Failed</h4><textarea style='height: 200px; width: 100%;>"
			+ response + "</textarea>";
	errorMessage.append(errHtml);
	errorMessage.show();
	$("#r2modalEndpointResponse").modal();
}

function updateSelectAllCheckbox(trackingPageSelectionBoxes, r2SelectAllCheckbox,
		trackingListData) {
	var allchecked = true;
	//now update the data
	trackingPageSelectionBoxes.each(function() {
		var index = $(this).val();
		if (!trackingListData[index].selected) {
			allchecked = false;
			return false;
		}
	});
	r2SelectAllCheckbox.prop("checked", allchecked);
}

function renderServerResponse(response, responseHeader) {
	var header = $("#r2modalEndpointResponseHeader");
	header.empty();
	header.append(responseHeader);
	var successMessage = $("#successMessage");
	var errorMessage = $("#errorMessage");
	successMessage.empty();
	errorMessage.empty();
	errorMessage.hide();
	successMessage.hide();

	if (typeof response.successMessages != 'undefined'
			&& response.successMessages.length > 0) {
		var successStr = "<h4>Success</h4><ul style=\"height:100px;overflow-y:auto\">";
		for (var j = 0; j < response.successMessages.length; j++) {
			successStr += "<li>" + response.successMessages[j].message
					+ "</li>";
		}
		successStr += "</ul>";
		successMessage.append(successStr);
		successMessage.show();
	}
	if (typeof response.errorMessages != 'undefined'
			&& response.errorMessages.length > 0) {
		var errHtml = "<h4>Failed</h4><ul style=\"height:100px;overflow-y:auto\">";
		for (var i = 0; i < response.errorMessages.length; i++) {
			errHtml += "<li>" + response.errorMessages[i].message + "</li>";
		}
		errHtml += "</ul>";
		errorMessage.append(errHtml);
		errorMessage.show();
	}
	$("#r2modalEndpointResponse").modal();
}

function clearSelections(trackingListData) {
	for (var i = 0; i < trackingListData.length; i++) {
		if (trackingListData.selected) {
			trackingListData.selected = false;
		}
	}
	$(".r2TrackingPageSelectionCheckbox").prop("checked", false);
}

function hideFluidRules(){
	$('#fluidUserInput').hide();
}

function handleAnalystSelectChange(event, datatable){
	let eventTarget = $(event.target);

	var data = datatable.rows().data();

	var userType = eventTarget.attr('id');

	if(userType === "osdSelect" || userType === "ombSelect"){		
		var checked = eventTarget.prop('checked');

		var val = eventTarget.val();

		var uuid = extractUUIDFromString(data[val].trackingNumber);
		
		jQuery.post(analystdSelectChangeLink, {
			"uuid" : uuid,
			"checked" : checked,
			"userType" : userType
		}, function(){
			window.location.reload();
		})
		window.location.reload();
	}
}

function extractUUIDFromString(uuid){
	let regex = new RegExp("([a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12})");
	
	return uuid.match(regex)[1];
}

function buildNonRFRColumns(){
	let array = [];
	
	array.push({
		"data" : "selected",
		"searchable" : false,
		"orderable" : false,
		"sClass" : "r2List_checkbox",
		"visible" : true,
		"render" : function(data, type, full, meta) {
			var selectedText = '';

			if (full.selected) {
				selectedText = ' checked="checked"';
			}

			return '<input type = "checkbox" class="r2TrackingPageSelectionCheckbox" value = "'
					+ meta.row + '"' + selectedText + '/>'

		},
		"defaultContent" : ""
	});
	
	array.push({
		"data" : "trackingNumber",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push({
		"data" : "budgetCycle",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "appropriation",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "title",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "source",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "status",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "user",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "agency",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "dateCreated",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "workflowStatus",
		"searchable" : true,
		"orderable" : true,
	});
	
	return array;
}

function buildRFRColumns(){
	let array = [];
	
	if(isOSDAnalyst){
		array.push(		{
			"data" : "selected",
			"searchable" : false,
			"orderable" : false,
			"sClass" : "r2List_checkbox",
			"visible" : true,
			"render" : function(data, type, full, meta) {
				var selectedText = '';

				if (full.selected) {
					selectedText = ' checked="checked"';
				}

				return '<input type = "checkbox" class="r2TrackingPageSelectionCheckbox" value = "'
						+ meta.row + '"' + selectedText + '/>'

			},
			"defaultContent" : "",
		});
	}
	
	array.push({
		"data" : "budgetCycle",
		"searchable" : true,
		"orderable" : true,
		"width" : "7%"
	});
	
	array.push(		{
		"data" : "agency",
		"searchable" : true,
		"orderable" : true,
		"width" : "5%"
	});
	
	array.push(		{
		"data" : "appropriation",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "title",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push(		{
		"data" : "user",
		"searchable" : true,
		"orderable" : true,
		"width" : "4%"
	});
	
	array.push(		{
		"data" : "dateCreated",
		"searchable" : true,
		"orderable" : true,
		"width" : "9%"
	});
	
	array.push(		{
		"data" : "workflowStatus",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push({
		"data" : "trackingNumber",
		"searchable" : false,
		"orderable" : false,
		"width" : "7%"
	});
	
	array.push(		{
		"data" : "osdAnalystSelected",
		"searchable" : false,
		"orderable" : false,
		"sClass" : "r2List_checkbox",
		"visible" : true,
		"render" : function(data, type, full, meta) {
			var selectedText = '';
							
			if (full.selected) {
				selectedText = ' checked="checked"';
			}
			
			if(data){
				selectedText = ' checked="checked"';
			}
			
			var returnString = '<input type = "checkbox" id="osdSelect" class="" value = "'
				+ meta.row + '"' + selectedText + '/>';
			
			budgetCycleText=jQuery('#filterByBudgetCycle :selected').text();
			
			if(isOMBAnalyst || !full.ombAnalystSelected && !budgetCycleText.includes("BES") && !isRfr){
				returnString = '<input type = "checkbox" id="osdSelect" class="" disabled="true" value = "' 
					+ meta.row + '"' + selectedText + '/>';
			}
			
			return returnString

		},
		"defaultContent" : ""
	});
	
	array.push({
		"data" : "osdAnalystName",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push({
		"data" : "osdClearedDate",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push({
		"data" : "ombAnalystSelected",
		"searchable" : false,
		"orderable" : false,
		"visible" : true,
		"render" : function(data, type, full, meta) {
			var selectedText = '';

			if (full.selected) {
				selectedText = ' checked="checked"';
			}
			
			if(data){
				selectedText = ' checked="checked"';
				isOMBAnalystChecked = true;
			}
			
			
			var returnString = '<input type = "checkbox" id="ombSelect" class="" value = "'
				+ meta.row + '"' + selectedText + '/>';
			
			if(isOSDAnalyst){
				returnString = '<input type = "checkbox" id="ombSelect" class="" disabled="true" value = "' 
					+ meta.row + '"' + selectedText + '/>';
			}
			
			return returnString

		},
		"defaultContent" : ""
	});
	
	array.push({
		"data" : "ombAnalystName",
		"searchable" : true,
		"orderable" : true,
	});
	
	array.push({
		"data" : "ombClearedDate",
		"searchable" : true,
		"orderable" : true,
	});
	
	return array;
}

$(document).ready(function(){
	$('#datatable').on('click', 'input[type="checkbox"]', function(event) {
		handleAnalystSelectChange(event, $('#datatable').DataTable())
	});
});