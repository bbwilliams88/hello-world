var importLinks;


 function xmlImportToolTabPageInit(links){
	  importLinks = links;
  var previewTemplate = $("#importTemplate").parent().html();
  $("#importTemplate").hide();
  var importDropzone = cxeDefaultDropzone("import", importLinks.uploadFile);
  
  importDropzone.on("addedfile", function(file) {
    file.previewElement.querySelector(".import-check").onclick = function() {
      $(file.previewElement).find("input[name='checkImportability']").val("true");
      $(file.previewElement).find(".start-import").hide();
    }
    file.previewElement.querySelector(".start-import").onclick = function() {
      $(file.previewElement).find(".import-check").hide();
    }
  });
  
  importDropzone.on("sending", function(file, xhr, formData) {
    var elm = $(file.previewElement);
    var tag = elm.find("input[name='exhibitTag']").val();
    var isTest = (elm.find("input[name='importAsTest']:checked").length > 0);
    var isCheck = elm.find("input[name='checkImportability']").val();
    console.log("tag: " + tag + ", test: " + isTest + ", check: " + isCheck);
    formData.append("exhibitTag", tag);
    formData.append("isTest", isTest);
    formData.append("isCheck", isCheck);
    // TODO if(checkImportability) leave start button enabled and change event handler to send an ajax request to do the actual import
  });
  
  importDropzone.on("success", function(file, response) {
    renderImportResponse(file.name, response);
  });
  
  var importResponseTemplate = $("#importResponseTemplate").html();
  $("#importResponseTemplate").hide();
  
  function renderImportResponse(filename, response) {
    console.log(JSON.stringify(response));
    var filenameId = getIdFilename(filename);
    var newResult = $("<div class='importResponse' id='import_" + filenameId + "'>" + importResponseTemplate + "</div>");
    
    var header = newResult.find(".resultsHeader");
    var successCount = newResult.find("li.importSuccessCount");
    var successWithWarningsCount = newResult.find("li.importSuccessWithWarningsCount");
    var failureCount = newResult.find("li.importFailureCount");
    var summaryWrapper = newResult.find("ul.importSummaryList");
    var importItemsTable = newResult.find("table.importItemsTable");
    var importMessagesTable = newResult.find("table.importMessagesTable");
    
    if(response.importCheckOnly) {
      header.text("Importability Check Results");
      successCount.text("Can be imported: ");
      successWithWarningsCount.text("Can be imported with warnings: ");
      failureCount.text("Cannot be imported: ");
    }
    
    header.text(header.text() + ": " + filename);
    
    setResultStatus(newResult, response.status);
    
    if(response.status == 'error' && typeof response.errorMessage != 'undefined') {
      newResult.find(".modal-body").text(response.errorMessage);
    }
    
    if(typeof response.summary != 'undefined') {
      appendTextIfExists(response.summary.successCount, successCount);
      appendTextIfExists(response.summary.successWithWarningsCount, successWithWarningsCount);
      appendTextIfExists(response.summary.failureCount, failureCount);
    } else {
      newResult.find("li.importExhibitCount").remove();
    }
    
    
    if(typeof response.rejectedFiles != 'undefined' && response.rejectedFiles.length) {
      for(var i=0; i<response.rejectedFiles.length; i++) {
        var fileListItem = $("<li class='rejectedFile validationErrorsList' />");
        var text = "Rejected: " + response.rejectedFiles[i].filename;
        if(response.rejectedFiles[i].message) {
          text += ": " + response.rejectedFiles[i].message;
        }
        fileListItem.text(text);
        if(response.rejectedFiles[i].schemaErrors) {
          var schemaErrors = $("<ol />");
          $.each(response.rejectedFiles[i].schemaErrors, function(err) {
            schemaErrors.append("<li>" + err + "</li>");
          });
          schemaErrors.appendTo(fileListItem);
        }
        fileListItem.appendTo(summaryWrapper);
      }
    }
    
    importItemsTable.attr("id", "import_" + filenameId + "_exhibits");
    importMessagesTable.attr("id", "import_" + filenameId + "_messages");
    
    newResult.appendTo("#importResults");
    
    console.log(JSON.stringify(response.exhibits));
    
    var itemsDataTable = $("#import_" + filenameId + "_exhibits").DataTable({
      data: response.exhibits,
      paging: false,
      searching: false,
      info: false,
      columns: [
                { data: "sourceFile", sortable: true },
                { data: "xmlIndex", sortable: true },
                { data: "exhibitNumber", sortable: true, width: "5%", render: function(data, type, full, meta) {
                  if(typeof full.exhibitId != 'undefined' && full.exhibitId.length)
                    return "<a href='/r2/peeditangular/" + full.exhibitId + "'>" + data + "</a>";
                  else
                    return data;
                } },
                { data: "title", sortable: false },
                { data: "budgetCycle", sortable: false, width: "5%" },
                { data: "serviceAgency", sortable: false, width: "7%" },
                { data: "status", sortable: true, render: function(data, type, full, meta) {
                  if(data.indexOf("error") >= 0)
                    return "<span class='text-danger'>" + data + "</span>";
                  else if(data.indexOf("warning") >= 0)
                    return "<span class='text-warning'>" + data + "</span>";
                  else
                    return "<span class='text-success'>" + data + "</span>";
                } }
                ]
    });
    var messagesDataTable = $("#import_" + filenameId + "_messages").DataTable({
      data: response.messages,
      paging: false,
      searching: false,
      info: false,
      columns: [
                { data: "type", sortable: true, width: "5%", render: function(data, type, full, meta) {
                  if(data.indexOf("Error") >= 0)
                    return "<span class='text-danger'>" + data + "</span>";
                  else
                    return "<span class='text-warning'>" + data + "</span>";
                } },
                { data: "location", sortable: true, width: "5%" },
                { data: "message", sortable: false }
                ]
    });
    
    if(typeof response.exhibits == 'undefined' || !response.exhibits.length) {
      importItemsTable.hide();
      importItemsTable.parent().prev("h3").hide();
    }
    if(typeof response.messages == 'undefined' || !response.messages.length) {
      importMessagesTable.hide();
      importMessagesTable.parent().prev("h3").hide();
    }
    
  }
  
  function setResultStatus(result, status) {
    var summaryDiv = result.find(".importItemsSummary");
    var heading = result.find("h3.modal-title");
    var failureHeading = result.find("h3.importFailure");
    if(typeof status != 'undefined' && status == 'success') {
      summaryDiv.addClass("alert-success");
      heading.text("Success");
    }
    else if(typeof status != 'undefined' && status == 'partial') {
      summaryDiv.addClass("alert-warning");
      heading.text("Partial success");
    }
    else if(typeof status != 'undefined' && status == 'failure'){
      summaryDiv.addClass("alert-danger");
      heading.text("Failure");
    }
    else {
      summaryDiv.addClass("alert-danger");
      heading.text("Error");
    }
  }
  
  function appendTextIfExists(src, element) {
    if(typeof src != 'undefined') {
      element.text(element.text() + src);
    } else {
      element.remove();
    }
  }
  
};