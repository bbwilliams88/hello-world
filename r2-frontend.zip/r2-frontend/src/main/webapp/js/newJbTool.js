/**
 * 
 */

var $, _, app;

if (!window.R2) {
  window.R2 = {};
}

$ = jQuery;

_ = T5._;

app = angular.module('app', ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider.when("/", {
    templateUrl: "angular/jbTool.html",
    controller: "jbTool"
  });
});
function getGenericDefaultJB(){
   return {
     budgetyear: 2017,
     budgetCucle: "BES",
     serviceAgency: "dummy agency",
     coverpage: { title: "JBCover", file:null },
     tocItemList : [{title:"AirForce", location:"Volume 1" } ],
     assemblyOptions: {
       generateR1: true,
       generateR1c: false,
       generater1d: false,
       generater1summary:true,
       generatePeTocByTitle:true,
       generatePeTocByBa:false,
       CostDoc: "costdoc.pdf",
       IntroductionDoc: "introdoc.pdf",
       SummaryDoc: "summary.pdf",
       AcronymDoc: "ad.pdf",
       UserR1Doc: "userR1.pdf",
       UserP1Doc: "userP1.pdf",
       supplementalDocList: [{title:"supplementalDoc 1", fileName:"supplements1.pdf"}]
     }
   };
}
app.controller("jbTool", function($scope, $routeParams) {
  console.log("jbtool controller starting");
  var jb =  getGenericDefaultJB();
  jb.programElements = [{id:"4", other:"fields will go in here"}];
  $scope.mjb = getGenericDefaultJB();
  $scope.mjb.justificationBooks = [jb];
});
app.directive("jbform",function(){
  return {
    restrict: 'E',
    scope: {jb:'='},
    templateUrl: 'angular/jbForm.html'
  };
});
