
$(document).ready(function(){  
  var validationDropzone = cxeDefaultDropzone("validate", "/r2/newr2xmltools.xmlvalidatetooltab:validatexml");
  
  validationDropzone.on("success", function (file, response){
        console.log("Success?");
        var responsestr = JSON.stringify(response);
        console.log(responsestr);
        renderValidationResponse(file.name, response);
  });
});

function renderValidationResponse(fileName,response){
  var validateForm = $('#validateForm');
  var newId = "validate_" + getIdFilename(fileName);
  console.log(newId);
  var validationResponseTemplate =  $('#validationResponseTemplate').clone().prop({id:newId}).appendTo(validateForm);
  $(this).find(".validationResponseContent").hide();
  
  var expanderHeader = validationResponseTemplate.find(".expanderHeader");
  expanderHeader.click(function(e){
    $(this).next(".validationResponseContent").slideToggle("fast");
  });
  validationResponseTemplate.find("h2").text("Summary Results: "+fileName);
  
  var itemsTBody = validationResponseTemplate.find("tbody");
  var validationSuccessDiv = validationResponseTemplate.find(".validationSuccess");
  var validationErrorsDiv = validationResponseTemplate.find(".validationErrors");
  var validationWarningsDiv = validationResponseTemplate.find(".validationWarnings");
  var validationInfoDiv = validationResponseTemplate.find(".validationInfo");
  
  var validationSuccessList = validationResponseTemplate.find(".validationSuccessList");
  var validationErrorsList = validationResponseTemplate.find(".validationErrorsList");
  var validationWarningsList = validationResponseTemplate.find(".validationWarningsList");
  var validationInfoList = validationResponseTemplate.find(".validationInfoList");
  
  if (typeof response.files!='undefined' && response.files.length>0) {
    var itemsStr = "";
    var k=0;
    for (var i=0; i<response.files.length;i++){
      var file = response.files[i];
      console.log(file.fileName);
      for (var j=0; j<file.items.length; j++){
        k=j+1;
        var item = file.items[j];
        if (typeof item !='undefined'){
//        console.log(item);
          if (j==0){
            itemsStr+="<tr><td rowspan='"+file.items.length+"'>"+file.fileName+"</td><td>"+k+"</td><td>"+item.number+"</td><td>"+item.title+"</td><td>"+item.budgetCycleAndYear+"</td><td>"+item.serviceAgency+"</td></tr>";
          }
          else {
            itemsStr+="<tr><td>"+k+"</td><td>"+item.number+"</td><td>"+item.title+"</td><td>"+item.budgetCycleAndYear+"</td><td>"+item.serviceAgency+"</td></tr>";
          }
        }
      }
    }
  }
  else {
    itemsStr+="<tr><td colspan='6'>No items found.</td></tr>";
  }
  itemsTBody.append(itemsStr);  
  
  var successStr = formatMessages(response.successMessages);
  if (successStr.length>0){
    validationSuccessList.append(successStr);
    var header =validationSuccessDiv.find(".modal-header");
    header.unbind("click");
    header.click(function(){
      validationSuccessDiv.find(".modal-body").slideToggle();
    });
    validationSuccessDiv.show();
  }
 
  var errorStr = formatMessages(response.errorMessages);
  if (errorStr.length>0){
    validationErrorsList.append(errorStr);
    var header =validationErrorsDiv.find(".modal-header");
    header.unbind("click");
    header.click(function(){
      validationErrorsDiv.find(".modal-body").slideToggle();
    });
    validationErrorsDiv.show();
  }
  
  var warningStr = formatMessages(response.warningMessages);
  if (warningStr.length>0){
    validationWarningsList.append(warningStr);
    var header =validationWarningsDiv.find(".modal-header");
    header.unbind("click");
    header.click(function(){
      validationWarningsDiv.find(".modal-body").slideToggle();
    });
    validationWarningsDiv.show();
  }
 
  if (typeof response.infoMessages!='undefined' && typeof response.infoMessages.files!='undefined' && response.infoMessages.files.length>0){
    for (var i=0; i<response.infoMessages.files.length;i++){
      var fileObj = response.infoMessages.files[i];
      if (typeof fileObj.messages != 'undefined'){
        var fileN = fileObj.fileName;
        var infoStr = "<li>File "+fileN+" is from a previous budget cycle. To validate against the current business rules, it has been migrated to the current budget cycle schema.  <a href='/r2/newr2xmltools.xmlvalidatetooltab:downloadfile/"+ fileObj.messages[0].message+"'>Click here to download.</a></li>";
        validationInfoList.append(infoStr);
        validationInfoDiv.show();
      }
    }

  }
  console.log("added response");
  validationResponseTemplate.show();
}
  
  function formatMessages(messageNode) {
    var generalBuf = [];
    if (typeof messageNode !='undefined' && typeof messageNode.general != 'undefined' && messageNode.general.length>0){
      for (var i=0; i<messageNode.general.length; i++){
        if (typeof messageNode.general[i].message !='undefined'){
          var generalStr ="";
          generalStr+="<li>";
          generalStr+=messageNode.general[i].message;
          generalStr+="</li>";
          generalBuf.push(generalStr);
        }
      }
    }
    
    
    var fileMsgBuf = [];
    if (typeof messageNode!='undefined' && typeof messageNode.files != 'undefined' && messageNode.files.length>0)
    {     
      for (var i=0; i<messageNode.files.length;i++){
        var fileStr = "";
        if (typeof messageNode.files[i] != 'undefined'){
          var fileObj = messageNode.files[i];
          var fileName = fileObj.fileName;
          if (typeof fileObj.messages != 'undefined' && fileObj.messages.length>0){
            fileStr+="<li>"+fileName;
            fileStr+="<ol>";
            var tmpBuf = [];
            for(var j=0; j<fileObj.messages.length; j++){
              var msg = fileObj.messages[j].message;
              tmpBuf.push("<li>"+msg+"</li>");
            }
            fileStr+=tmpBuf.join("");
            fileStr+="</ol>";
          
        fileStr+="</li>";
        fileMsgBuf.push(fileStr);
          }
      }
    }
    }
    return generalBuf.join("")+fileMsgBuf.join("");
    
  }