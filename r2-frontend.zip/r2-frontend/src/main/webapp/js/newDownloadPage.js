var downloadTableUrl = "";
var nameLinkURL = "";
var uploadFileURL = "";
var deleteFileURL = "";
var userRoleURL = "";
var newDownloadPageLinks;

var budgetCycleJson;

function downloadPageInit(urlJson) {

  downloadTableUrl = urlJson.getDownloadTableUrl;
  uploadFileURL = urlJson.uploadFileURL;
  nameLinkURL = urlJson.namelinkURL;
  deleteFileURL = urlJson.deleteFileUrl;
  userRoleURL = urlJson.userRoleUrl;

  var uploadPreviewNode = document.querySelector("#uploadTemplate");
  var jqUploadPreviewNode = $("#" + uploadPreviewNode.id);
  var bcSelect = jqUploadPreviewNode.find("select[name='budgetCycleToMigrate']")[0];

  uploadPreviewNode.id = "";

  var previewTemplate = $(uploadPreviewNode).parent().html();
  uploadPreviewNode.parentNode.removeChild(uploadPreviewNode);

  var instructionsTemplate = $("#uploadPreviews").find(".instruction").parent().html();
  var uploadDropzone = new Dropzone("#uploadForm", {
    url : uploadFileURL, // Set the url
    thumbnailWidth : 80,
    thumbnailHeight : 80,
    parallelUploads : 20,
    previewTemplate : previewTemplate,
    // acceptedFiles: "application/pdf,.zip,.xml", accept all file types
    autoQueue : false, // Make sure the files aren't queued until manually added
    previewsContainer : "#uploadPreviews", // Define the container to display the previews
    clickable : "#uploadFileInput-button" // Define the element that should be
                                          // used as click trigger to select files.
  });
  hideUploadsFromLowerUsers();

  uploadDropzone.on("addedfile", function(file) {
    var uploadPreviews = $("#uploadPreviews");
    var uploadProgress = $(file.previewElement).find(".upload-progress");
    uploadProgress.hide();

    console.log("upload added file");
    $("#uploadForm").find(".instruction").remove();
 
	file.previewElement.querySelector(".start").onclick = function() {
      uploadDropzone.enqueueFile(file);
      $(file.previewElement).find(".description").hide();
    };
    file.previewElement.querySelector(".delete").onclick = function() {
      var resultsId = "[id^=" + getIdFilename(file.name) + "]";
      $(resultsId).remove();
    };
    var fileDescription = $(file.previewElement).find(".description");
    fileDescription.val("Optional Description");
    fileDescription.addClass('placeholder');
    fileDescription.focus(function() {
      if (fileDescription.val() == "Optional Description") {
        fileDescription.val('');
        fileDescription.removeClass('placeholder');
      }
    }).blur(function() {
      if (fileDescription.val() === '') {
        fileDescription.addClass('placeholder');
        fileDescription.val('Optional Description');
      }
    }).blur();
    
	fileDescription.keyup(function() {
	  var descPattern = /^[0-9A-Za-z\(\)\[\]\-\_\#\@\:\.\s]*$/;
      var startBtn = $(file.previewElement).find(".start");
      var fileDescription = $(file.previewElement).find(".description");
      if (fileDescription.val().match(descPattern) || fileDescription.val() == "" || fileDescription.val() =="Optional Description") {
   		startBtn.prop("disabled", false);
   		fileDescription.css({"border-color": "#ddd"});
      } else {
   		startBtn.prop("disabled", true);
   		fileDescription.css({"border-color": "red"});
      }
    });
  });

  uploadDropzone.on("uploadprogress", function(file, progress) {
    var progressBar = file.previewElement.querySelector('.progress-bar');
    $(file.previewElement).find(".upload-progress").show();

    progressBar.style.width = progress + "%";
    if (progress > 99) {
      progressBar.textContent = "Upload complete.";
    }
  });

  uploadDropzone.on("processing", function(file) {
    console.log("processing");
  });

  uploadDropzone.on("sending", function(file, xhr, formData) {
    var fileDescription = $(file.previewElement).find(".description");
    console.log("sending file desc: " + fileDescription.val());
    if (fileDescription.val() != "Optional Description") {
      formData.append('description', fileDescription.val());
    } else {
      formData.append('description', "");
    }

    // Show the total progress bar when upload starts
    file.previewElement.querySelector(".progress").style.opacity = "1";
    // And disable the start button
    file.previewElement.querySelector(".start").setAttribute("disabled", "disabled");
  });

  uploadDropzone.on("reset", function() {
    if ($("#uploadPreviews div:first-child").find(".instruction").length === 0) {
      $("#uploadPreviews div:first-child").append(instructionsTemplate);
    }
  });

  document.querySelector("#uploadActions .cancel").onclick = function() {
    uploadDropzone.removeAllFiles(true);
    var uploadResponseTemplate = $('#uploadResponseTemplate');
    uploadResponseTemplate.find("tbody").empty();
  };
  
  uploadDropzone.on("success", function(file, response) {
    var uploadProgress = file.previewElement.querySelector(".upload-active");
    var uploadComplete = file.previewElement.querySelector(".upload-complete");
    uploadProgress.style.display = "none";
    uploadComplete.style.display = "block";
    renderUploadResponse(file.name, response);
  });

  uploadDropzone.on("complete", function(file) {
    console.log("complete");

  });

  uploadDropzone.on("error", function(file, message) {
    console.log("error");
    console.log(file.previewElement);
    
    var errorMsg = "An error occurred while uploading file " + file.name + ".  Please try again.";
    if (file.name.length > 100) {
      errorMsg += "  Shorten the file name, it is too long.  Please keep file names under 100 characters (character count includes the .pdf/.xml/.zip ending).";
    }
    file.previewElement.querySelectorAll("[data-dz-errormessage]")[0].textContent = errorMsg;
    file.previewElement.querySelector(".upload-active").style.display = "none";
    file.previewElement.querySelector(".upload-complete").style.display = "none";
    file.previewElement.querySelector(".progress-bar").style.display = "none";
  });

  var newDownloadsPageDataTable = $("#downloadsDataTable")
      .DataTable(
          {
            // "order": [[ 12, 'desc' ]],
            "autoWidth" : true,
            "serverSide" : false,
            "stateSave" : true,
            "language" : {
              "emptyTable" : "No results found."
            },
            "deferRender" : true,
            "ajax" : {
              "url" : downloadTableUrl,
              "type" : "POST"
            },
            "columns" : [
                {
                  "data" : "name",
                  "visible" : true,
                  "searchable" : true,
                  "sortable" : true,
                  "title" : "File Name",
                  "render" : function(data, type, full, meta) {
                    if (full.name) {
                      return "<a href='" + nameLinkURL + "/" + full.id
                          + "' download='download'>" + full.name + "</a>";
                    }
                  }
                },
                {
                  "data" : "description",
                  "searchable" : true,
                  "sortable" : true,
                  "title" : "Description"
                },
                {
                  "data" : "dateCreated",
                  "searchable" : true,
                  "sortable" : true,
                  "title" : "Date Created"
                },
                {
                  "data" : "createdBy",
                  "searchable" : true,
                  "sortable" : true,
                  "title" : "Created By"
                },
                {
                  "data" : "size",
                  "searchable" : true,
                  "sortable" : true,
                  "title" : "Size",
                  "render" : function(data, type, full, meta) {
                    if (data) {
                      return Math.round(data / 1000) + " KB";
                    } else {
                      return "No data";
                    }
                  }
                },
                {
                  "data" : "deleteEnabled",
                  "searchable" : true,
                  "sortable" : false,
                  "title" : "Actions", // looks like only delete
                  "render" : function(data, type, full, meta) {
                    if (data) {
                      return "<span><button class ='cxeButton actionsDeleteButton'id='delete"
                          + full.id + "' value='" + meta.row + "'><span>Delete</span></button></span>";
                    } else {
                      return "<span></span>";
                    }
                  }
                } ]
          });

  function hideUploadsFromLowerUsers() {
    $.ajax({
      url : userRoleURL,
      data : null,
      type : "POST",
      success : function(response) {
        if (response.role == 'R2AppMgr') {
        	$('#uploadForm').show();
        }	
        else if (response.role == 'R2Analyst' || response.role == 'R2OmbAnalyst'){
        	$('#uploadForm').show();
        }
        else {
          $('#uploadForm').hide(); // only app managers are allowed to upload documents CXE-5506
        }
      },
      error : function() {
        console.log("error reciving data from backend");
        $("#r2modalHeader").text("Failure");
        $("#errorMessagesList").find("li").text("An error occurred while getting user role");
        $("#errorMessagesModal").modal();
      }
    });
  }

  function deleteButtonClicked(deleteButton) {
    var jsonObj = {
      "json" : JSON.stringify(newDownloadsPageDataTable.data()[deleteButton.value].id)
    };
    $.ajax({
      url : deleteFileURL,
      data : jsonObj,
      type : "POST",
      success : function(response) {
        if (response.SuccessMessages) {
          newDownloadsPageDataTable.ajax.reload();
          $("#r2modalHeader").text("Success");
          $("#errorMessagesList").find("li").text(response.SuccessMessages);
          $("#errorMessagesModal").modal();
        } else if (response.errorMessages) {
          $("#r2modalHeader").text("Error");
          $("#errorMessagesList").find("li").text(response.errorMessages);
          $("#errorMessagesModal").modal();
        }
      },
      error : function() {
        console.log("error reciving data from backend");
        $("#r2modalHeader").text("Failure");
        $("#errorMessagesList").find("li").text("An error occurred while deleting the file");
        $("#errorMessagesModal").modal();
      }
    });
  }
  function countFiles() {
    var fileCount = newDownloadsPageDataTable.data().length;
    if (fileCount == 50) {
      $("#uploadFileInput-button").hide();
      $("#r2modalHeader").text("Alert");
      $("#errorMessagesList").find("li").text(
              "You have reached the limit of 50 files please delete a file before uploading another");
      $("#errorMessagesModal").modal();
      var text = $(".instructionHeader").text(
              "You have reached the limit of 50 files please delete a file before uploading another");
    } else {
      var text = $(".instructionHeader").text("Click 'Add Files' or drop files here.");
      $("#uploadFileInput-button").show();
    }
  }
  newDownloadsPageDataTable.on('draw.dt', function() {
    countFiles();
    $(".actionsDeleteButton").unbind();
    $(".actionsDeleteButton").on("click", function() {
      var deleteButton = this;
      $("#deleteMessagesList").find("li").text(
          "Are you sure you want to delete the file: "
              + newDownloadsPageDataTable.data()[this.value].name + "?");
      $("#deleteModal").modal();
      $(".modalDeleteButton").unbind();
      $(".modalDeleteButton").on("click", function() {
        deleteButtonClicked(deleteButton);
      });
    });
  });

  function renderUploadResponse(fileName, response) {
    newDownloadsPageDataTable.ajax.reload();
    var uploadForm = $('#uploadForm');
    var newId = getIdFilename(fileName);

    var uploadResponseTemplate = $('#uploadResponseTemplate');
    var itemsTBody = uploadResponseTemplate.find("tbody");

  }
  function getIdFilename(fileNameStr) {
    return fileNameStr.replace(/[\\.]/g, '_');
  }
  
}
