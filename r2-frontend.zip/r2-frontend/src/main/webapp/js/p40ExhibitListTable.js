var p40ExhibitsTableLinks;

function p40ExhibitListTablePageInit(urlJson){
	p40ExhibitsTableLinks = urlJson;
  var p40ExhibitTable = $("#p40ExhibitTable").DataTable({
    "order": [[ 12, 'desc' ]],
    "autoWidth": false,
    "serverSide": false,
    "stateSave": true,
    "language": {
      "emptyTable": "No results found."
    },
    "deferRender": true,
    "ajax": {
      "url": p40ExhibitsTableLinks.p40ExhibitTableDataUrl,
      "type": "POST"
    },
    "createdRow": function(row, data, index){
      var checkbox = $(row).find(".liSelectionCheckbox");
      var api = this.api();
      checkbox.unbind("click");
      checkbox.click(function(e){
        p40ExhibitSelected($(this),api.data());
      });
    },
    "sDom": 'B<"H"lfr>t<"F"ip>',
	"buttons" : [{
		"extend" :'colvis',
		"text" : "Columns",
		"columns" : ":gt(0)",    // This is hiding the selection column on the left from the column visibility options
		"columnText" : function(dt, idx, title){
			if(title.indexOf('Agency') != -1){
				return "Agency";
			}
			
			if(title.indexOf('Budget Cycle') != -1){
				return "Budget Cycle";
			}
			
			return title;
		}
	}],
    "columns": [
       {
        "data": "selected",
        "searchable":false,
        "orderable":false,
        "sClass": "r2List_checkbox",
        "visible":true,
        "render": function(data, type, full, meta){
          var selectedText = '';
          if (full.selected)
          {
            selectedText = ' checked="checked"';
          }
          return '<input type="checkbox" class="liSelectionCheckbox" value="'+meta.row+'"'+selectedText+'/>';
        },
        "defaultContent":""   
      },
      
      { "data": "p1LineItemNumber",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_r1num",
          "visible":true
        },
        { "data": "lineItemNumber",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_number",
          "visible":true,
          "render": function(data, type, full, meta){
            var numberCellStr = full.lineItemNumber;
            return numberCellStr.concat(getP40Icons(data, type, full, meta));
          },
          "defaultContent":""
        },
        { "data": null,
          "bSearchable":false,
          "bSortable":false,
          "sClass": "r2List_exhibitBadges",
          "visible":false,
          "render": function(data, type, full, meta){
            return getP40ExhibitTypeBadges(data, type, full, meta);
          },
          "defaultContent": "<span>Exhibit Types</span>"
        },
        { 
          "data": "lineItemTitle",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_title",
          "visible":true,
          "render": function(data,type,full, meta){
            var titleStr = "";
            if (typeof full.lineItemTitle != 'undefined' && full.lineItemTitle != null) {
              titleStr = full.lineItemTitle.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    	.replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/-/g, "&ndash;").replace(/,/g, "&sbquo;");
            }
            if (titleStr.length > 40) {
              return '<span data-toggle="tooltip" title="'+titleStr+'">'+(titleStr).substr(0,38)+'...</span>';
            }
            else
            {
              return '<span data-toggle="tooltip" title="'+titleStr+'">'+titleStr+'</span>';
            }
          },
          "defaultContent":""
          
        },
        { 
          "data": "budgetActivityNumber",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_budgetactivity",
          "visible":false
        },
        { 
          "data": "bsaNum",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_budgetactivity",
          "visible":false
        },
        { "data": "agencyCode",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_agency",
          "visible":true,
          "render": function(data, type, full, meta)
          {
            return "<span data-toggle='tooltip' title='"+full.agencyName+"'>"+full.agencyCode+"</span>";
          },
          "defaultContent":""
        }, 
        { "data": "budgetCycleAndYear",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_budgetcycle",
          "visible":true
        },
        {
          "data": "creatorDisplayName",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_createdby",
          "visible":false
        },
        {
          "data": "formattedDateCreated",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_datecreated",
          "visible":false,
          "defaultContent":""
        },
        {
          "data": "modifierDisplayName",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_modifiedby",
          "visible":false
        },
        {
          "data": "formattedDateModified",
          "bSearchable":true,
          "bSortable":true,
          "sClass": "r2List_datemodified",
          "visible":true,
          "defaultContent":""
        }
]
  });
  
  $("#p40ServiceAgencyFilter").change(function (e){
    var filterText = $("#p40ServiceAgencyFilter :selected").attr('value');
    console.log("filterText:"+filterText);
    if (filterText==null || filterText =='undefined'){
      filterText = "";
    }
    p40ExhibitTable.column(".r2List_agency").search(filterText).draw();
  });
  
  $("#p40BudgetCycleFilter").change(function (e){
    var filterText = $("#p40BudgetCycleFilter :selected").attr('value');
    filterText = URLEncoder.encode(filterText);
    $.ajax({
      url: p40ExhibitsTableLinks.budgetCycleChangedUrl+"/"+filterText,
      type: "GET",
      success: function(response){
        p40ExhibitTable.ajax.reload();
      },
      error : function(data){
        console.log(data);
        var errorStr = "An unexpected error occurred: "+data;
        $("#errorMessage").append(errorStr);
        $("#errorMessage").show();
      }
    });
  });
};