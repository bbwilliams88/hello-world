if (!window.R2) window.R2 = {};
if (window._ && !window._.extend) {
	T5._.extend(T5._, window._); // pull in any underscore addons before replacing _
	window._ = T5._; //Expose underscore globally
}

function redirect(anchorid)
{
	showProgressManual();
	jQuery(function(e) {
		window.location = jQuery(anchorid).attr("href");
	});
}

function download(anchorid)
{
	showProgressManual();
	jQuery(function(e) {
		hideProgressManual();
		window.location = jQuery(anchorid).attr("href");
	});
}

//Bind for custom events. Custom Prototype events don't work in jQuery,
//so if Prototype is present use its bind instead
R2.custombind = function(eventsource,event,func) {
	if (window.Event && Event.observe) {
		if (eventsource.length === 0) return; //ignore empty jQuery object
		if (eventsource.length) { //unwrap a jQuery object
			eventsource = eventsource[0];
		}
		// do it the Prototype way
		Event.observe(eventsource,event,func);
	} else {
		// Jquery
		jQuery(eventsource).bind(event,func);
	}
};


// Progress Window code
var transparentOpacity = 0;
var progressOpacity = 0;
var links;
function getNumberFromStyleString(styleString) {
	if (Number(styleString))
		return (Number(styleString));
	else if ((rightIndex = styleString.indexOf("px")) != -1)
		return (Number(styleString.slice(0, rightIndex)));
	return (0);
}
function getScrollTop() {
	if (document.documentElement && document.documentElement.scrollTop)
		return document.documentElement.scrollTop;
	else if (document.body)
		return document.body.scrollTop;
}
function getScrollLeft() {
	if (document.documentElement && document.documentElement.scrollLeft)
		return document.documentElement.scrollLeft;
	else if (document.body)
		return document.body.scrollLeft;
}
function getScrollWidth() {
	if (navigator.appName == "Microsoft Internet Explorer")
		return document.body.scrollWidth;
	else {
		if (document.documentElement && document.documentElement.scrollWidth)
			return document.documentElement.scrollWidth;
		else if (document.body)
			return document.body.scrollWidth;
	}
}
function getScrollHeight() {
	if (navigator.appName == "Microsoft Internet Explorer")
		return document.body.scrollHeight;
	else {
		if (document.documentElement && document.documentElement.scrollHeight)
			return document.documentElement.scrollHeight;
		else if (document.body)
			return document.body.scrollHeight;
	}
}
function getBodyMarginWidth() {
	// The margin from the style is accurate
	if (document.body.style.marginLeft)
		return getNumberFromStyleString(document.body.style.marginLeft)
				+ getNumberFromStyleString(document.body.style.marginRight);
	else if (document.body.leftMargin)
		return Number(document.body.leftMargin)
				+ Number(document.body.rightMargin);
	else
		return (0);
}
function getBodyMarginHeight() {
	// The margin from the style is accurate
	if (document.body.style.marginTop)
		return getNumberFromStyleString(document.body.style.marginTop)
				+ getNumberFromStyleString(document.body.style.marginBottom);
	else if (document.body.topMargin != null)
		return Number(document.body.topMargin)
				+ Number(document.body.bottomMargin);
	else
		return (0);
}
function getWindowWidth() {
	if (document.documentElement && document.documentElement.clientWidth)
		return document.documentElement.clientWidth;
	else if (document.body)
		return document.body.clientWidth;
}
function getWindowHeight() {
	if (document.documentElement && document.documentElement.clientHeight)
		return document.documentElement.clientHeight;
	else if (document.body)
		return document.body.clientHeight;
}
function getContentWidth() {
	// The width of "contentDiv" is inaccurate in Firefox
	// So, use the top-level table to get the right width
	return (document.getElementById("contentTable").offsetWidth + getBodyMarginWidth());
}
function getContentHeight() {
	// The height of "contentDiv" and "mainDiv" is accurate across browsers
	// So, just use the div to get the right height
	return (document.getElementById("contentDiv").offsetHeight + getBodyMarginHeight());
}
function getFullContentHeight() {
	// Returns the greater of window height and content height
	if (getContentHeight() > getWindowHeight())
		return (getContentHeight());
	return (getWindowHeight());
}
function getProgressWidth() {
	return (document.getElementById("progressWindow").offsetWidth);
}
function getProgressHeight() {
	return (document.getElementById("progressWindow").offsetHeight);
}
function setDisplayTransparentWindow(displayVal) {
	document.getElementById("transparentWindow").style.display = displayVal;
}
function showTransparentWindow() {
	setDisplayTransparentWindow("");
}
function hideTransparentWindow() {
	setDisplayTransparentWindow("none");
}
function resizeTransparentWindow() {
	document.getElementById("transparentWindow").style.width = getContentWidth()
			+ "px";
	document.getElementById("transparentWindow").style.height = getFullContentHeight()
			+ "px";
}
function setDisplayProgressWindow(displayVal) {
	document.getElementById("progressWindow").style.display = displayVal;
}
function showProgressWindow() {
	setDisplayProgressWindow("");
	// Re-set the image source to start the image animation.
	// Sometimes in IE, the animation will not work if this is not done.
	document.getElementById("progressImage").src = document.getElementById("progressImage").src;
}
function showEmailProgressWindow() {
	setDisplayProgressWindow("");
	// Re-set the image source to start the image animation.
	// Sometimes in IE, the animation will not work if this is not done.
	document.getElementById("progressImage").src = document.getElementById("progressImage").src;
	setTimeout(() => {
		hideProgressWindow();
		hideTransparentWindow();
	}, 100);
}
function hideProgressWindow() {
	setDisplayProgressWindow("none");
}
function moveProgressWindow() {
	pWinLeft = getScrollLeft() + (getWindowWidth() - getProgressWidth()) / 2;
	pWinRight = pWinLeft + getProgressWidth();
	if (pWinRight > getScrollWidth())
		pWinLeft = getScrollWidth() - getProgressWidth();

	pWinTop = getScrollTop() + (getWindowHeight() - getProgressHeight()) / 3;
	pWinBottom = pWinTop + getProgressHeight();
	if (pWinBottom > getScrollHeight())
		pWinTop = getScrollHeight() - getProgressHeight();

	document.getElementById("progressWindow").style.left = pWinLeft + "px";
	document.getElementById("progressWindow").style.top = pWinTop + "px";
}
function onWindowScroll() {
	moveProgressWindow();
}
function onWindowResize() {
	resizeTransparentWindow();
	resizeTransparentWindow();
	moveProgressWindow();
}
function setDisplaySelectControlsforIE(displayVal) {
	if (navigator.appName == "Microsoft Internet Explorer") {
		selectControls = document.getElementsByTagName("select");
		for ( var i = 0; i < selectControls.length; i++)
			selectControls[i].style.display = displayVal;
	}
}
function showSelectControlsforIE() {
	setDisplaySelectControlsforIE("");
}
function hideSelectControlsforIE() {
	setDisplaySelectControlsforIE("none");
}
function disableLinks() {
	linkControls = document.getElementsByTagName("a");
	if (linkControls.length == 0)
		linkControls = document.getElementsByTagName("A");
	links = new Array(linkControls.length);
	for ( var i = 0; i < linkControls.length; i++) {
		links[i] = {
			control : linkControls[i],
			onclick : linkControls[i].onclick
		};
		linkControls[i].onclick = function() {
			return false;
		};
	}

}
function enableLinks() {
	for ( var i = 0; links != null && i < links.length; i++)
		links[i].control.onclick = links[i].onclick;
	links = null;
}
function setDisabledFormElements(form, disabled) {
	for ( var i = 0; i < form.elements.length; i++)
		form.elements[i].disabled = disabled;
	document.getElementById("contentDiv").disabled = disabled;
}
function disableFormElements(form) {
	setDisabledFormElements(form, true);
}
function enableFormElements(form) {
	setDisabledFormElements(form, false);
}
function addEventListeners() {
	if (window.addEventListener) {
		window.addEventListener("scroll", onWindowScroll, false);
		window.addEventListener("resize", onWindowResize, false);
	} else if (window.attachEvent) {
		window.attachEvent("onscroll", onWindowScroll);
		window.attachEvent("onresize", onWindowResize);
	} else {
		window.onscroll += onWindowScroll;
		window.onresize += onWindowResize;
	}
}
function removeEventListeners() {
	if (window.removeEventListener) {
		window.removeEventListener("scroll", onWindowScroll, false);
		window.removeEventListener("resize", onWindowResize, false);
	} else if (window.detachEvent) {
		window.detachEvent("onscroll", onWindowScroll);
		window.detachEvent("onresize", onWindowResize);
	} else {
		window.onscroll -= onWindowScroll;
		window.onresize -= onWindowResize;
	}
}

function showProgressManual() {
	hideSelectControlsforIE();
	showTransparentWindow();
	resizeTransparentWindow();
	showProgressWindow();
	moveProgressWindow();
	addEventListeners();
}

function showEmailProgressManual() {
	hideSelectControlsforIE();
	showTransparentWindow();
	resizeTransparentWindow();
	showEmailProgressWindow();
	moveProgressWindow();
	addEventListeners();
}

function hideProgressManual() {
	removeEventListeners();
	hideProgressWindow();
	hideTransparentWindow();
	showSelectControlsforIE();
}
