function showProgressBar()
{
	var overlay = document.getElementById("overlay");
	overlay.style.display = "flex";
	var progressContainer = document.getElementById("progressBarContainer");
	progressContainer.style.display = "flex";
}

function openHelpWindow()
{
	var baseUrl = window.location.origin;
	var newUrl = baseUrl + "/r2/newR2ImportHelp";
	window.open(newUrl, "newR2ImportHelp", "popup");
}

window.onload = function()
{
	var overlay = document.getElementById("overlay");
	overlay.style.display = "none";
	var progressContainer = document.getElementById("progressBarContainer");
	progressContainer.style.display = "none";
}