function reset(){

	$('#peSuffix').val('');
}