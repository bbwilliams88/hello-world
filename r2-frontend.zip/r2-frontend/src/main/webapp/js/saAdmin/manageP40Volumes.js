const COLVIS_BUTTON = 'colvis';

/**
 * Modal confirmation dialog to require the user to confirm a deletion.

 * @param message The message to display n the dialog box.
 * @returns True if the user confirms the delete, false otherwise.
 */
function confirmDelete(message)
{
	return confirm("Are you sure you want to delete this " + message + "?");
}

/**
 * Function that creates the configuration object for use by the datatables buttons extension
 * 
 * @param buttonTypes
 * @returnsrD
 */
function getButtonConfig(buttonTypes){
	let defaultConfig = [];
	
	// Iterate over the array of button types that are passed in and call the appropriate configuration function
	buttonTypes.forEach(function(buttonType){
		switch(buttonType){
		case COLVIS_BUTTON:
			defaultConfig.push(getColvisButtonConfig());
			break;
		default:
			break;
		}
	})
	
	return defaultConfig;
}

/**
 * Function that configures the colvis button for the Datatables Buttons extension
 * 
 * @returns
 */
function getColvisButtonConfig(){
		return {				
			  "extend" :'colvis',     
			  "text" : "Columns",
			  "columnText" : function(dt, idx, title){
				  if(title.indexOf('Host') != -1){
					  return "Host";
				  }
					
				  return title;
				}
		}
}

/**
 * Called by Tapestry to set up and configure the DataTable.
 */
function setupDatatable()
{
	$.fn.dataTable.moment('MMM DD, YYYY HH:mm', 'en');	
	
	// Create and initialize the DataTable.
		var datatable = $('#p40JBVolumeTable').DataTable( {
			"pageLength" : 20,
			"lengthMenu": [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
			"language" : {
				"search" : "Search:"
			},
			"order" : [[6, 'desc']],
			"orderCellsTop" : true,
			"columnDefs" : [
				{"targets" : 6, "searchable" : false, "sortable" : true},
				{"targets" : "_all", "searchable" : true, "sortable" : true, "visible" : true},
				{"targets" : [1,6], "render" : function(data, type, row, meta){
                	var dataStr = data;
                    if (data.length>40){
                      return '<span data-toggle="tooltip" title="'+dataStr+'">'+(data).substr(0,38)+'...</span>';
                    }
                    else {
                      return '<span data-toggle="tooltip" title="'+data+'">'+data+'</span>';
                    }
				  }
				},
              {"width" : "30%", "targets" : [0]},  
              {"width" : "20%", "targets" : [1]},
              {"width" : "10", "targets" : [2]},
              {"width" : "10%", "targets" : [3]},
              {"width" : "10%", "targets" : [4,5,6]}
			],
            "dom": 'B<"H"lfr>t<"F"ip>',
			"buttons" : getButtonConfig([COLVIS_BUTTON]),	
			"stateDuration" : 30 * 60, // 30 minutes.
			"stateSave": true,
			"autoWidth" : false
		});
}

// TODO: Find out what these two methods are doing
//Hide the selectbox and put a loading icon there instead
function loadingize(selectbox) {

}

//show a previously hidden selectbox and remove the loading icon
function unloadingize(selectbox) {
	
}
