const COLVIS_BUTTON = 'colvis';

function confirmDelete(message)
{
	return confirm("Are you sure you want to delete this " + message + "?");
}

function getButtonConfig(buttonTypes){
	let defaultConfig = [];
	
	// Iterate over the array of button types that are passed in and call the appropriate configuration function
	buttonTypes.forEach(function(buttonType){
		switch(buttonType){
		case COLVIS_BUTTON:
			defaultConfig.push(getColvisButtonConfig());
			break;
		default:
			break;
		}
	})
	
	return defaultConfig;
}

function getColvisButtonConfig(){
		return {				
			  "extend" :'colvis',     
			  "text" : "Columns",
			  "columnText" : function(dt, idx, title){
				  if(title.indexOf('Host') != -1){
					  return "Host";
				  }
					
				  return title;
				}
		}
}

function loadingize(selectbox) {

}

function unloadingize(selectbox) {
	
}


function setupDatatable(){
	$.fn.dataTable.moment('MMM DD, YYYY HH:mm', 'en');	
	
	// Create and initialize the DataTable.
		var datatable = $('#manageAppropriationTable').DataTable( {
			"pageLength" : 20,
			"lengthMenu": [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
			"language" : {
				"search" : "Search:"
			},
			"order" : [[5, 'desc']],
			"orderCellsTop" : true,
			"columnDefs" : [
				{"targets" : 5, "searchable" : false, "sortable" : true},
				{"targets" : "_all", "searchable" : true, "sortable" : true, "visible" : true},
				{"targets" : [1,5], "render" : function(data, type, row, meta){
                	var dataStr = data;
                    if (data.length>200){
                      return '<span data-toggle="tooltip" title="'+dataStr+'">'+(data).substr(0,198)+'...</span>';
                    }
                    else
                    {
                      return '<span data-toggle="tooltip" title="'+data+'">'+data+'</span>';
                    }
				  }
				},
              {"width" : "45%", "targets" : [0]},  
              {"width" : "11%", "targets" : [1,2,3,4,5]},
			],
            "dom": 'B<"H"lfr>t<"F"ip>',
			"buttons" : getButtonConfig([COLVIS_BUTTON]),	
			"stateDuration" : 30 * 60, // 30 minutes.
			"stateSave": true,
			"autoWidth" : false
		});
}





