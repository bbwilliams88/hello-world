const COLVIS_BUTTON = 'colvis';

/**
 * Modal confirmation dialog to require the user to confirm a deletion.

 * @param message The message to display n the dialog box.
 * @returns True if the user confirms the delete, false otherwise.
 */
function confirmDelete(message)
{
	return confirm("Are you sure you want to delete this " + message + "?");
}

/**
 * Function that creates the configuration object for use by the datatables buttons extension
 * 
 * @param buttonTypes
 * @returnsrD
 */
function getButtonConfig(buttonTypes){
	let defaultConfig = [];
	
	// Iterate over the array of button types that are passed in and call the appropriate configuration function
	buttonTypes.forEach(function(buttonType){
		switch(buttonType){
		case COLVIS_BUTTON:
			defaultConfig.push(getColvisButtonConfig());
			break;
		default:
			break;
		}
	})
	
	return defaultConfig;
}

/**
 * Function that configures the colvis button for the Datatables Buttons extension
 * 
 * @returns
 */
function getColvisButtonConfig(){
		return {				
			  "extend" :'colvis',     
			  "text" : "Columns",
			  "columnText" : function(dt, idx, title){
				  if(title.indexOf('Host') != -1){
					  return "Host";
				  }
					
				  return title;
				}
		}
}

/**
 * Called by Tapestry to set up and configure the DataTable.
 */
function setupDatatable()
{
	$.fn.dataTable.moment('MMM DD, YYYY HH:mm', 'en');	
	
	// Create and initialize the DataTable.
		var datatable = $('#manageBudgetSubActivityTable').DataTable( {
			"pageLength" : 10,
			"lengthMenu": [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
			"language" : {
				"search" : "Search:"
			},
			"order" : [[3, 'desc']],
			"orderCellsTop" : true,
			"columnDefs" : [
				{"targets" : 2, "searchable" : false, "sortable" : true},
				{"targets" : "_all", "searchable" : true, "sortable" : true, "visible" : true},
				{"targets" : [1,2], "render" : function(data, type, row, meta){
				/*{"targets" : [8], "render" : function(data, type, row, meta){*/
                	var dataStr = data;
                    if (data.length>40){
                      return '<span data-toggle="tooltip" title="'+dataStr+'">'+(data).substr(0,38)+'...</span>';
                    }
                    else
                    {
                      return '<span data-toggle="tooltip" title="'+data+'">'+data+'</span>';
                    }
				  }
				},
			  {"width" : "60%", "targets" : [0]},
			  {"width" : "20%", "targets" : [1,2]},
			],
            "dom": 'B<"H"lfr>t<"F"ip>',
			"buttons" : getButtonConfig([COLVIS_BUTTON]),	
			"stateDuration" : 30 * 60, // 30 minutes.
			"stateSave": true,
			"autoWidth" : false
		});
}

// TODO: Find out what these two methods are doing
//Hide the selectbox and put a loading icon there instead
function loadingize(selectbox) {

}

//show a previously hidden selectbox and remove the loading icon
function unloadingize(selectbox) {
	
}

//function displayAppList(){
//	alert("hello");
//}

//function setup(){
//	$('#processStatusId').hide();
//	$('#resultMsgId').show();
//	
//	var test = $('#statusMsg').val();
//	if (test.length > 0){
//		
//		if (test == "Successfully updated Appropriation"){
//			$('#resultMsgId').css({'font-size':'14px','color':'green'});
//		}
//		else{
//			$('#resultMsgId').css({'font-weight':'bold','font-size':'14px','color':'red'});
//		}
//		
//		$('#resultMsgId').show();
//		$('#resultMsgId').fadeOut(15000);
//	}
//}
//
//function execute(){
//	$('#processStatusId').show();
//	$('#processMsg').css({'font-weight':'bold','font-size':'small','color':'blue'});
//	$('#resultMsgId').hide();
//}

//function reset(){
//	$('#reset').click();
//}

