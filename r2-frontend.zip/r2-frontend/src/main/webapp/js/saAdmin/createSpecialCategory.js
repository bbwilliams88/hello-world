function setup(){
	$('#saId').hide();
	$('#aaId').hide();
	document.getElementById('categories').selectedIndex = 0;
	
}

function doChange(){
	var e = document.getElementById('categories');
	var x = e.options[e.selectedIndex].value;
	
	if (x == 'DW'){
		$('#aaId').show();
		$('#saId').hide();
	}
	else if (x == 'DOD_SERVICE'){
		$('#aaId').hide();
		$('#saId').show();
	}
	else if (x == 'DOD_BIG_AGENCY'){
		$('#aaId').hide();
		$('#saId').show();
	}
	else {
		$('#saId').hide();
		$('#aaId').hide();
	}
	
}