function setup(){
	$('#processStatusId').hide();
	$('#resultMsgId').hide();
	
	var test = $('#statusMsg').val();
	
	if (test.length > 0){
		
		if (test == "Successfully created new Appropriation"){
			$('#resultMsgId').css({'font-size':'14px','color':'green'});
		}
		else{
			$('#resultMsgId').css({'font-weight':'bold','font-size':'14px','color':'red'});
		}
		
		$('#resultMsgId').show();
		$('#resultMsgId').fadeOut(5000);
	}
}

function execute(){
	$('#processStatusId').show();
	$('#processMsg').css({'font-weight':'bold','font-size':'small','color':'blue'});
	$('#resultMsgId').hide();
}
