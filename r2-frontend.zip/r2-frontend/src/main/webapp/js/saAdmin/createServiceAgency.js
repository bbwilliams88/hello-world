function setup(){
	$('#processStatusId').hide();
	$('#resultMsgId').show();
	
	var test = $('#statusMsg').val();
	if (test.length > 0){
		
		
		if (test == "Successfully created new Service Agency."){
			$('#resultMsgId').css({'font-size':'14px','color':'green'});
		}
		else{
			$('#resultMsgId').css({'font-weight':'bold','font-size':'14px','color':'red'});
		}
		
		$('#resultMsgId').show();
		$('#resultMsgId').fadeOut(15000);
	}
}

function execute(){
	$('#processStatusId').show();
	$('#processMsg').css({'font-weight':'bold','font-size':'small','color':'blue'});
	//$('#resultMsgId').show();
}

