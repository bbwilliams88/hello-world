console.log("angular-dropzone.js running");
angular.module('angularDropzone', []).directive('dropzone', function() {
  console.log("ngDz module directive function");
  return  {
    restrict: 'E',
    scope: { 
      prefix: '@prefix',
      url: '@url',
      customConfig: '=?config'
    },
    templateUrl: '/r2/angular/angularDropzone.html',
    link: function(scope, element, attrs) { 
      var previewsContainer, previewTemplate, clickable, config, dropzone;
      
      previewsContainer = element.find(".previews").get(0);
      previewTemplate = element.find(".file-row:first").parent().html();
      clickable = element.find(".fileinput-button").get();
      
      config = {
          'options': {
            'url': scope.url,
            'parallelUploads': 10,
            'autoQueue': true,
            'acceptedFiles': 'application/pdf,application/zip,text/xml',
            'previewsContainer': previewsContainer,
            'previewTemplate': previewTemplate,
            'clickable': clickable
          },
          'instructions': {
            'header': 'Click Add Files or drop files here.',
            'content': [ 'Accepted file types: XML, PDF, ZIP (of XMLs or PDFs)',
                        'Accepted formats: Exhibit, Justification Book, Master Justification Book' ]
          },
          'eventHandlers': {
            'addedfile': function(file) {
              console.log("added file");
              scope.hasFilesAdded = true;
              scope.$apply();
            },
            'uploadprogress': function(file, progress) {
              file.previewElement.querySelector(".progress-bar").textContent = progress + "%;"
              if(progress > 99) {
                angular.element(file.previewElement.querySelector(".upload-active")).show();
              }
            },
            'success': function(file, response) {
              console.log(JSON.stringify(response));
              console.log("hasFilesAdded = " + scope.hasFilesAdded);
              angular.element(file.previewElement.querySelector(".upload-active")).hide();
              angular.element(file.previewElement.querySelector(".upload-complete")).show();
            },
            'error': function(file, message) {
              file.previewElement.querySelectorAll("[data-dz-errormessage]")[0].textContent = "An error occurred while uploading file "+file.name+".  Please try again.";
              angular.element(file.previewElement.querySelector(".upload-active")).hide();
              angular.element(file.previewElement.querySelector(".upload-complete")).hide();
              var progressBar = angular.element(file.previewElement.querySelector(".progress-bar"));
              progressBar.text("Error.");
              progressBar.addClass("progress-bar-danger");
              progressBar.removeClass("progress-bar-success");
            },
            'reset': function() {
              scope.hasFilesAdded = false;
              scope.$apply();
            }
          }
      };
      
      angular.extend(config.options, scope.customConfig.options);
      angular.extend(config.instructions, scope.customConfig.instructions);
      angular.extend(config.eventHandlers, scope.customConfig.eventHandlers);
      
      scope.instructions = config.instructions;
      
      dropzone = new Dropzone(element[0], config.options);
      
      angular.forEach(config.eventHandlers, function(handler, event) {
        dropzone.on(event, handler);
      });
    }
  };
});