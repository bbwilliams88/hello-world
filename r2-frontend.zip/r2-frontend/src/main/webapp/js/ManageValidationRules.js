function setupValidationRuleDatatable(businessRule_updateActiveURL) {
	console.log("businessRule_updateActiveURL");
	console.log(businessRule_updateActiveURL);
	var r2RulesTable = $('#rulesTable').dataTable({
		"stateSave": true,
		"stateDuration": -1,
		"pageLength": 10,
		"buttons": [
			{
				"extend": "csv",
				"text": "Download CSV",
				"fieldSeparator": ",",
				"extension": ".csv",
				"exportOptions": {
					"columns": [0, 1, 2, 3, 4, 5],
					"orthogonal": "export"
				}
			},
			{
				"extend": "colvis",
				"text": "Columns"
			}
		],
		"sDom": 'B<"H"lfr>t<"F"ip>',
		"columnDefs": [
			{ "width": "50%", "targets": 1 },
			{ "width": "8%", "targets": [0, 3, 4] },
			{
				"width": "15%",
				"render":
					function (data, type, row) {
						if (type === "display") {
							var dataStr = data;

							if (data.length > 40) {
								return '<span data-toggle="tooltip" title="' + dataStr + '">' + (data).substr(0, 38) + '...</span>';
							}

							else {
								return '<span data-toggle="tooltip" title="' + data + '">' + data + '</span>';
							}
						}

						else {
							return data;
						}
					},
				"targets": 5
			},
			{
				"width": "5%",
				"render": function (data, type, row) {
					console.log("type" + type);
					if (type === "export") {
						var $input = $(data).find('input[type="checkbox"]').addBack();
						data = ($input.prop('checked')) ? "Enabled" : "Disabled";
						console.log("data" + data);
					}

					return data;
				},
				"targets": 2
			}
		],
	});

	r2RulesTable.show();
	jQuery('.ruleEnabled', r2RulesTable.fnGetNodes()).change(function () {
		var parentDiv = this;
		$.post(businessRule_updateActiveURL,
			{
				"index": parentDiv.parentNode.getAttribute('id'),
				"value": (($(parentDiv).children("input").prop("checked")) ? 0 : 1),
				"csrfToken": $("#csrfToken").val()
			},
			function (response) {
				var aPos = r2RulesTable.fnGetPosition(parentDiv);

				// Update the rule status cell only if it needs to be adjusted to avoid extra change 
				if ($(parentDiv).children("input").prop("checked") != (response[0] == "true")) {
					$(parentDiv).children("input").prop("checked", response[0] == "true");
				}
				// Update the audit cell
				r2RulesTable.fnUpdate(response[1], aPos[0], aPos[1] + 2, false);

				// Update the admin message
				document.getElementById("adminMessage").textContent = response[2];

			});
	});
}