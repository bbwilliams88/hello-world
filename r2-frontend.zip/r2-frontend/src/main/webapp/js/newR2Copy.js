
function intializeCopyModal()
{
	$(".r2ModalCopyButton").click(function(e)
	{
		e.preventDefault();
		var copyUsers = false;
		if ($("#r2CopyUsersCheckbox").length)
		{
			copyUsers = $("#r2CopyUsersCheckbox").is(":checked");
		}
		var testPe = false;
		if ($("#r2CopyTestCheckbox").length)
		{
			testPe = $("#r2CopyTestCheckbox").is(":checked");
		}
		var formVals = {"r2-number": $("#r2ProgramElementNumberInput").val(),
						"r2-budgetCycle": $("#r2BudgetYearCycleSelect").val(),
						"r2-budgetActivity": $("#r2ActivitySelect").val(),
						"r2-copyUsers": copyUsers,
						"r2-test": testPe
		};
		validateCopyForm();
		submitCopyForm();
	});
}

function validateCopyForm(formVals)
{
	
}

function submitCopyForm()
{

}

function validatePeNumber(formVals)
{
	var validationObject;
	if (formVals.r2-Number==null)
	{
		$("#r2ProgramElementNumberInput").css('border', '1px solid #f00');
		validationObject = {"valid":false, "message": "You enter a Program Element."};
	}
	else
	{
		$("#r2ProgramElementNumberInput").css('border', '1px solid #ccc');
		validationObject = {"valid": true, "message": "This is a valid Program Element."};
	}
	return validationObject;
}