var r2ExhibitsTableLinks;
var p40ExhibitsTableLinks;
var budgetCycleJson;
var activityJson;

var volumeList = [
                  {num: "", description: "", title: ""}
                  ];

var jbDefaults = {
  services: {       vol: {
                      title:       { defaultVal: ["", "", ""], disabled: false },
                      description: { defaultVal: ["BAs 1, 2, and 3", "BAs 4 and 5", "BAs 6 and 7"], disabled: false },
                      num:         { defaultVal: ["1", "2", "3"], disabled: false }
                    },
                    numVolumes:     { defaultVal: 3, disabled: false },
                    includeTOV:     { defaultVal: true, disabled: false },
                    xVolTOCsSingle: { defaultVal: false, disabled: false } //generate cross-volume TOC by BA/by title when JB is single-volume
  },
  bigAgencies: {    vol: {
                      title:       { defaultVal: ["", "", ""], disabled: false },
                      description: { defaultVal: ["Agency Name", "Agency Name", "Agency Name"], disabled: true },
                      num:         { defaultVal: ["4", "4a", "4b"], disabled: true }
                    },
                    numVolumes:     { defaultVal: 1, disabled: false },
                    includeTOV:     { defaultVal: true, disabled: false },
                    xVolTOCsSingle: { defaultVal: false, disabled: false } //generate cross-volume TOC by BA/by title when JB is single-volume
    },
  smallAgencies: {  vol: {
                      title:       { defaultVal: ["", "", ""], disabled: false },
                      description: { defaultVal: ["Agency Name", "Agency Name", "Agency Name"], disabled: true },
                      num:         { defaultVal: ["5", "", ""], disabled: true }
                    },
                    numVolumes:     { defaultVal: 1, disabled: true },
                    includeTOV:     { defaultVal: true, disabled: true },
                    xVolTOCsSingle: { defaultVal: true, disabled: false } //generate cross-volume TOC by BA/by title when JB is single-volume
    },
  global: {
      perVolTOCs:     { defaultVal: true, disabled: false },  //generate per-volume TOC by BA/by title
      xVolTOCsMulti:  { defaultVal: true, disabled: true },   //generate cross-volume TOC by BA/by title when JB is multi-volume
      R1P1bes:        { defaultVal: true, disabled: false },  //generate per-volume R1/P1 (BES cycle)
      xR1P1besSingle: { defaultVal: false, disabled: false }, //generate cross-volume R1/P1 when JB is single-volume (BES cycle)
      xR1P1besMulti:  { defaultVal: true, disabled: false },  //generate cross-volume R1/P1 when JB is multi-volume (BES cycle)
      R1P1pb:         { defaultVal: false, disabled: true },  //generate per-volume R1/P1 (PB cycle)
      xR1P1pb:        { defaultVal: false, disabled: true },  //generate cross-volume R1/P1 (PB cycle)
      compR1P1bes:    { defaultVal: false, disabled: false }, //attach R1/P1 document from comptroller (BES cycle)
      compR1P1pb:     { defaultVal: true, disabled: true }    //attach R1/P1 document from comptroller (PB cycle)
  }
};

var currentDefaults = jbDefaults.services;

$(document).ready(function() {
  
  var jbExpanderHeader = $(".docsExpanderHeader");
  jbExpanderHeader.click(function(e) {
    //allow individual expand/collapse of subheaders
    if($(this).hasClass("docsExpanderSubHeader")) {
      $(this).next("div").slideToggle("fast");
      $(this).toggleClass("docsExpanderHidden");
    }
    //only one top-level header open at a time
    else {
      accordionExpand($(this))
    }
  });
  
  
  $("#volumes section").each(function() {
    infoForm = $(this).find(".volumeInfoForm");
    updateVolumeHeader(infoForm);
    $(infoForm).find("input").change(function() {
      updateVolumeHeader(infoForm);
    });
  });
  
  $.getJSON('/r2/newBudgetCycleJson', function(data) {
    budgetCycleJson = data;
    console.log(JSON.stringify(data));
  });
  $("#budgetCycle").change(function() {
    var selectedCycle = $(this).val();
    for(var i=0; i < budgetCycleJson.cycles.length; i++) {
      var cycle = budgetCycleJson.cycles[i];
      if(selectedCycle === cycle.label) {
        $("#submissionDate").text(cycle.SubmissionDates[cycle.SubmissionDates.length - 1]);
      }
    }
  });
  
  $.getJSON('/r2/newActivityJson', function(data) {
    activityJson = data;
    console.log(JSON.stringify(data));
  });
  var isDefenseWide = updateDefenseWide();
  $("#serviceAgency").change(function() {
    
    var currentSA = $("#serviceAgency").val();
    
    // update defaults based on agency
    if(currentSA === "ARMY" || currentSA === "NAVY" || currentSA === "AF") {
      currentDefaults = jbDefaults.services;
    }
    else if(currentSA === "DARPA"
         || currentSA === "MDA"
         || currentSA === "OSD"
         || currentSA === "CBDP") {
      currentDefaults = jbDefaults.bigAgencies;
    } else {
      currentDefaults = jbDefaults.smallAgencies;
    }
    
    if(currentDefaults === jbDefaults.smallAgencies) {
      $("#jbWizardContainer").addClass("smallAgency");
    } else {
      $("#jbWizardContainer").removeClass("smallAgency");
    }
    updateDefenseWide();
    
    // populate appropriations dropdown
    for (var a = 0; a < activityJson.agencies.length; a++) {
      var agency = activityJson.agencies[a];
      var option;
      if (currentSA === agency.code) {
        var appropriation;
        if (agency.appropriations.length === 1) {
          appropriation = agency.appropriations[0];
          option = '<option value="' + appropriation.id + '">';
          option += appropriation.code + ': ' + appropriation.name + '</option>';
          $('#appropriation').html(option);
        } else {
          var nullOption = '<option value="null">Please select an ';
          nullOption += 'appropriation...</option>';
          $('#appropriation').html(nullOption);
          for (var b = 0; b < agency.appropriations.length; b++) {
            appropriation = agency.appropriations[b];
            option = '<option value="' + appropriation.id + '">';
            option += appropriation.code + ': ' + appropriation.name;
            option += '</option>';
            $('#appropriation').append(option);
          }
        }
      }
    }
  });
  
  var isP40 = updateR2P40();
  $("input:radio[name=r2p40toggle]").change(function(e) {
    updateR2P40();
  });
  var isMjb = updateJbMjb();
  $("#buildMJB").click(function(e) {
    updateJbMjb();
  });
  
  $("#jbWizardSubmitBtn").click(function(e) {
    var docOptions = JSON.stringify(getDocOptions());
    console.log(docOptions);
  });
  
  
  var selectedExhibits = [];
  
  var selectedExhibitsTable = $("#selectedExhibitsTable").DataTable({
    "autoWidth": false,
    "serverSide": false,
    "language": {
      "emptyTable": "No results found."
    },
    "createdRow": function(row, data, index){
        var deleteBtns = $(row).find(".deleteSelectedBtn");
        var api = this.api();
        deleteBtns.unbind("click");
        deleteBtns.click(function(e){
          deleteSelected(data, api, index);
        });
    },
    "data": selectedExhibits,
    "columns": [
          { "data": "selectionType",
            "bSearchable":false,
            "bSortable":false,
            "sClass": "r2List_selectiontype",
            "visible":true
          },
          { "data": "number",
            "bSearchable":true,
            "bSortable":true,                 
            "sClass": "r2List_r1num",
            "visible":true,
            "defaultContent":""
          },
          { "data": "exhibitNumber",
            "bSearchable":true,
            "bSortable":true,
            "sClass": "r2List_number",
            "visible":true
          },
          { 
            "data": "title",
            "bSearchable":true,
            "bSortable":true,
            "sClass": "r2List_title",
            "visible":true,
            "render": function(data,type,full, meta){
              var titleStr = full.title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    	.replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/-/g, "&ndash;").replace(/,/g, "&sbquo;");
              if ((full.title).length>40){
                return '<span data-toggle="tooltip" title="'+titleStr+'">'+(titleStr).substr(0,38)+'...</span>';
              }
              else
              {
                return '<span data-toggle="tooltip" title="'+titleStr+'">'+titleStr+'</span>';
              }
            },
            "defaultContent":""
          },
          {
            "data": "volumeNumber",
            "bSearchable":false,
            "bSortable":true,
            "sClass":"r2List_volume",
            "visible":true,
            "defaultContent":""
          },
          { 
            "data": "filename",
            "bSearchable":true,
            "bSortable":true,
            "sClass": "r2List_filename",
            "visible":true,
            "render": function(data,type,full, meta){
              var filenameStr = full.filename;
              if ((full.filename).length>40){
                return '<span data-toggle="tooltip" title="'+filenameStr+'">'+(full.filename).substr(0,38)+'...</span>';
              }
              else
              {
                return '<span data-toggle="tooltip" title="'+full.filename+'">'+full.filename+'</span>';
              }
            },
            "defaultContent":""
          },
          {
            "data": null,
            "bSearchable":false,
            "bSortable":false,
            "sClass": "r2List_action",
            "visible":true,
            "render": function(data, type, full, meta)
            {
              return "<button class='cxeButton deleteExhibitBtn'>Delete</button>";
            },
            "defaultContent": "<span></span>"
          }
      ]
    
  });
  
});

function accordionExpand(header) {
  if($(header).hasClass("docsExpanderHidden")) {
    $(header).next("div").slideDown("fast");
    $(header).removeClass("docsExpanderHidden");
    
    $(header).parent().siblings().each(function(i, element) {
      
      var siblingHeader=$(element).children(".docsExpanderHeader");
      if(!$(siblingHeader).hasClass("docsExpanderHidden")) {
        $(siblingHeader).next("div").slideUp("fast");
        $(siblingHeader).addClass("docsExpanderHidden");
      }
    });
  }
}

function updateR2P40() {
  var isP40 = ($("input[name=r2p40toggle]:checked").val() === "p40");
  $("#jbWizardContainer").toggleClass("p40", isP40);
  $("#jbWizardContainer").toggleClass("r2", !isP40);
  return isP40;
}

function updateDefenseWide() {
  var isDW = ($("#serviceAgency").val() === "DEFW" || $("#serviceAgency").val() === "DW");
  if(isDW) {
    $("#buildMJB").closest(".form-group").slideDown("fast");
    $("#buildMJB").prop("checked", true);
  } else {
    $("#buildMJB").closest(".form-group").slideUp("fast");
    $("#buildMJB").prop("checked", false);
  }
  updateJbMjb();
  return isDW;
}

function updateJbMjb() {
  var isMjb = $("#buildMJB").is(":checked");
  $("#jbWizardContainer").toggleClass("mjb", isMjb);
  $("#jbWizardContainer").toggleClass("jb", !isMjb);
  
  // adjust default show/hide for MJB mode's subsections
  $("#jbUploadExhibits").addClass("docsExpanderContentShowAtStart");
  $("#jbUploadExhibits").removeClass("docsExpanderContent");
  
  return isMjb;
}

function updateVolumeHeader(infoForm) {
  var sec = $(infoForm).closest("section");
  var headerStr = "Volume " + $(infoForm).find("input[placeholder='Num']").val();
  if($(infoForm).find("input[placeholder='Title']").val() != '') {
    headerStr += " - " + $(infoForm).find("input[placeholder='Title']").val();
  }
  if($(infoForm).find("input[placeholder='Description']").val() != '') {
    headerStr += " - " + $(infoForm).find("input[placeholder='Description']").val();
  }
  console.log(headerStr);
  $(sec).find("h4").text(headerStr);
}

function updateDefaults(former, current) {
  // if current form value has been changed from previous default settings (and field is not disabled), keep the change
  // todo: set volume defaults
  
  updateIfDefault(former.includeTOV, current.includeTOV, $("#tov"));
  updateIfDefault(former.volTOCs, current.volTOCs, $("#tocByBA"));
  updateIfDefault(former.volTOCs, current.volTOCs, $("#xTocByTitle"));
  updateIfDefault(former.xVolTOCs, current.xVolTOCs, $("#xTocByBA"));
  updateIfDefault(former.xVolTOCs, current.xVolTOCs, $("#xTocByTitle"));
  if($("#budgetCycle").val().includes("PB")) {
    updateIfDefault(former.R1P1pb, current.R1P1pb, $("#r1p1"));
    updateIfDefault(former.xR1P1pb, current.xR1P1pb, $("#xR1P1"));
    // todo: set required on Comptroller R1/P1 attachment
  }
  else {
    updateIfDefault(former.R1P1bes, current.R1P1bes, $("#r1p1"));
    updateIfDefault(former.xR1P1besMulti, current.xR1P1besMulti, $("#xR1P1")); //todo: check number of volumes 1 or >1
    // todo: set optional on Comptroller R1/P1 attachment
  }
}

function updateIfDefault(former, current, elm) {
  if($(elm).val() === former.defaultVal || current.disabled === true) {
    $(elm).val(current.defaultVal);
  }
  $(elm).prop("disabled", current.disabled);
}

function getDocOptions() {
  var selectedBudgetCycle = $("#budgetCycle :selected").attr('value');
  var selectedCycleName = selectedBudgetCycle.split(" ")[0];
  var selectedYear = selectedBudgetCycle.split(" ")[1];
  
  return {
    jbMjb: $("#buildMJB").prop("checked") ? "mjb" : "jb",
    budgetArea: $("input[name=r2p40toggle]:checked").val(),
    budgetCycle: selectedCycleName,
    budgetYear: selectedYear,
    submissionDate: $("#submissionDate").text(),
    serviceAgency:  $("#serviceAgency :selected").attr('value'),
    appropriation:  $("#appropriation :selected").attr('value'),
    forceEven: $("#forceEven").prop("checked"),
    topLevel: $("#topLevel").prop("checked"),
    watermark: $("#watermark").val(),
    trackingHeader: $("#trackingHeader").val(),
    coverPageTitle: $("#coverTitle").val(),
    logoFilename: "DoD-seal.jpg"
  };
}