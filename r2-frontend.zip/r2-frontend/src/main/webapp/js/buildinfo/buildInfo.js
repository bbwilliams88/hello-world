function setupDatatable() {
	$.fn.dataTable.moment('MMM DD, YYYY HH:mm', 'en');	
		var datatable = $('#buildInfoTable').DataTable( {
			"pageLength" : 10,
			"lengthMenu": [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
			"language" : {
				"search" : "Search:"
			},
			"order" : [[2, 'desc']],
			"orderCellsTop" : true,
            "dom": 'B<"H"lfr>t<"F"ip>',
			"stateDuration" : 30 * 60, // 30 minutes.
			"stateSave": true,
			"autoWidth" : false
		});
}
