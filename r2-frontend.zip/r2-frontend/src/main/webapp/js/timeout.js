function startTimeoutCounter() {
  var str = 'In two minutes, you will be logged out due to inactivity. Any unsaved work will be lost. Saving or clicking OK will reset the 15 minute inactivity timer.';
  window.setTimeout( function() {
    if(confirm(str)) {
      pingToResetCounter();
    }
  }, 13*60*1000 );
}

function pingToResetCounter() {
  $.get('/r2/endpoints/R2Ping', function(data) {
    if (data.pinged === 'true') {
      startTimeoutCounter();
    }
  });
}

startTimeoutCounter();