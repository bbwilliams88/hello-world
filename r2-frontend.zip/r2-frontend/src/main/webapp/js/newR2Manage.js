

var activityJson;
var budgetCycleJson;
var originalPENumberForSingleCopy;
var originalBAForSingleCopy;
var originalBAIdForSingleCopy=0;


$.getJSON("/r2/newActivityJson", function(data) {
    activityJson = data;
  });

$.getJSON("/r2/newBudgetCycleJson", function(data) {
    budgetCycleJson = data;
  });


function r2ManagePageInit( url ){	
  $.fn.dataTable.moment('MMM DD, YYYY HH:mm', 'en');	
  
  var r2ManageDataTable = $('#r2ProgramElementsManage').DataTable({
    "order": [[ 12, 'desc' ]],
    "autoWidth": false,
    "serverSide": false,
    "stateSave": true,
    "language": {
      "emptyTable": "No results found."
    },
    "ajax": {
      "url": url,
      "type": "POST"
    },
    "sDom": 'B<"H"lfr>t<"F"ip>',
	"buttons" : [{
		"extend" :'colvis',
		"text" : "Columns",
		"columns" : ":gt(0)",    // This is hiding the selection column on the left from the column visibility options
		"columnText" : function(dt, idx, title){
			if(title.indexOf('Agency') != -1){
				return "Agency";
			}
			
			if(title.indexOf('Budget Cycle') != -1){
				return "Budget Cycle";
			}
			
			return title;
		}
	}],
    "columns": [
          { "data": "selected",
            "bSearchable":false,
            "bSortable":false,
            "sClass": "r2List_checkbox",
            "visible":true,
            "render": function(data, type, full, meta){
              var selectedText = '';
              if (full.selected)
              {
                selectedText = ' checked="checked"';
              }
              return '<input type="checkbox" class="r2PESelectionCheckbox" value="'+meta.row+'"'+selectedText+'/>';
            },
            "defaultContent":""
          },
                { "data": "r1LineNumber",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_r1num",
                  "visible":true
                },
                { "data": "number",
                  "bSearchable":true,
                  "bSortable":true,                  
                  "sClass": "r2List_number",
                  "visible":true,
                  "render": function(data, type, full, meta){
                    var numberCellStr = "<a href='/r2/peeditangular/"+full.id+"'>"+full.number+"</a>";
                    return numberCellStr.concat(getExhibitIcons(data, type, full, meta));
                  },
                  "defaultContent":""
                },
                { "data": null,
                  "bSearchable":false,
                  "bSortable":false,
                  "sClass": "r2List_exhibitBadges",
                  "visible":false,
                  "render": function(data, type, full, meta){
                    return getExhibitTypeBadges(data, type, full, meta);
                  },
                  "defaultContent": "<span>Exhibit Types</span>"
                },
                { 
                  "data": "title",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_title",
                  "visible":true,
                  "render": function(data,type,full, meta){
                    var titleStr = full.title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    	.replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/-/g, "&ndash;").replace(/,/g, "&sbquo;");
                    if ((full.title).length>40){
                      return '<span data-toggle="tooltip" title="'+titleStr+'">'+(titleStr).substr(0,38)+'...</span>';
                    }
                    else
                    {
                      return '<span data-toggle="tooltip" title="'+titleStr+'">'+titleStr+'</span>';
                    }
                  },
                  "defaultContent":""
                  
                },
                { 
                  "data": "baNum",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_budgetactivity",
                  "visible":true
                },
                { 
                  "data": "numProjects",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_numprojects",
                  "visible":false
                },
                { "data": "serviceAgencyCode",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_agency",
                  "visible":true,
                  "render": function(data, type, full, meta)
                  {
                    return "<span data-toggle='tooltip' title='"+full.serviceAgencyName+"'>"+full.serviceAgencyCode+"</span>";
                  },
                  "defaultContent":""
                }, 
                { "data": "budgetCycle",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_budgetcycle",
                  "visible":true,
                  "render": function(data, type, full, meta)
                  {
                    return full.budgetCycle+" "+full.budgetYear;
                  },
                  "defaultContent":""
                },
                {
                  "data": "creatorDisplayName",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_createdby",
                  "visible":false
                },
                {
                  "data": "formattedDateCreated",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_datecreated",
                  "visible":false
                },
                {
                  "data": "modifierDisplayName",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_modifiedby",
                  "visible":false
                },
                {
                  "data": "formattedDateModified",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_datemodified",
                  "visible":true,
                  "type" : "date"
                },
                {
                  "data": null,
                  "bSearchable":false,
                  "bSortable":false,
                  "sClass": "r2List_download",
                  "visible":true,
                  "render": function(data, type, full, meta)
                  {
                    if (full.submissionStatus!="E")
                    {
                      return "<div style='display:block'> <a href='/r2/newR2Pdf/"+full.id+"' download='download' class='r2DataTableButton'>PDF</a>"+
                      "<a href='/r2/newR2Word/"+full.id+"' download='download' class='r2DataTableButton'>Word</a>"+
                      "<a href='/r2/newR2Xml/"+full.id+"' download='download' class='r2DataTableButton'>XML</a></div>";
                    }
                  },
                  "defaultContent": "<span></span>"
                }
                ]
  });
  
  $.fn.dataTable.ext.errMode = function (settings, helpPage, message){
    console.log("Datatable error during loading of data: "+message);
    renderServerError("Datatable error during loading of data: "+message,"Server Error");
  }

  var r2SelectAllCheckbox =$("#r2SelectAllCheckbox");

  r2ManageDataTable.on('draw.dt', function(){
    $(".notImplementedYet").click(function(event) {
      event.preventDefault();
      $('#r2modalNotImplemented').modal();
    });
 
    var peListData = r2ManageDataTable.data();
    // render Action button group
    if (peListData[0]!=undefined)
    {
      renderActionButtonGroup(peListData[0].copyEnabled, peListData[0].freezeEnabled, peListData[0].deleteEnabled);
    }
    else
    {
      renderActionButtonGroup(false, false, false);
    }
    
    // if the controls link exists, move the it to the correct position before table search box
    var controlsLink = $("#r2ControlNumbersLink");
    if (controlsLink.length)
    {
      controlsLink.insertAfter("#r2ProgramElementsManage_filter");
    }
    
    // bind event handlers
    
    // Checkboxes
    
    var peSelectionBoxes = $('.r2PESelectionCheckbox');
    peSelectionBoxes.unbind("click");
    peSelectionBoxes.click(function (e)
    {
      var selectedElementIndex = $(this).val();
      var selectedElement = peListData[selectedElementIndex];
      var checked = $(this).is(":checked");
      selectedElement.selected = checked;
//      if (!checked && r2SelectAllCheckbox.is(":checked"))
//      {
//        r2SelectAllCheckbox.prop("checked", false);
//      }
      updateSelectAllCheckbox(peSelectionBoxes,r2SelectAllCheckbox, peListData);
    });
    
    r2SelectAllCheckbox.unbind("click");
    r2SelectAllCheckbox.click(function (e)
    {
      var checked = $(this).is(":checked");
      var displayedRows = $(".r2PESelectionCheckbox");
      displayedRows.prop("checked",checked);
      //now update the data
      displayedRows.each(function()
      {
        var index = $(this).val();
        peListData[index].selected = checked;
      });
      
    });
    
    if($('#service-agency-filter').children('option').length == 2){ // "" agency is search 'all' 2 children means the user has 1 agency 
		  $("#service-agency-filter").hide();
	  };
    
    updateSelectAllCheckbox(peSelectionBoxes,r2SelectAllCheckbox, peListData);
    
    $('[data-toggle="tooltip"]').tooltip();
  });  

  var filter;
  $("#service-agency-filter").change(function (e){
    var filterText = $("#service-agency-filter :selected").attr('value');
    filter = filterText;
    console.log("filter text: " + filterText);
    if (filterText==null || filterText =='undefined'){
      filterText = "";
    }
    r2ManageDataTable.column(".r2List_agency").search(filterText).draw();
  });
 
  //this makes the filter reset correctly after navigating off the page after filtering by agency. 
  var reset = false;
  r2ManageDataTable.on('draw.dt', function(){
	  if( filter == undefined && reset === false){
		  reset = true
		  r2ManageDataTable.column(".r2List_agency").search("").draw();	
	  }
	});
  
  // Prevent click/keypress on the dropdown filters from bubbling up to the header sorting
  $("#service-agency-filter").keypress(function (e) {
    e.stopPropagation();
  });
  $("#service-agency-filter").click(function (e) {
    e.stopPropagation();
  });
  
  $("#budget-cycle-filter").keypress(function (e){
    e.stopPropagation();
  });
  $("#budget-cycle-filter").click(function (e){
    e.stopPropagation();
  });

  // Modals
  var tableState = r2ManageDataTable.state();
  var columnsState;
//  var cookie = JSON.parse($.cookie("r2Manage.datatable"));
//  if (cookie!=undefined || cookie!=null)
//  {      
//    columnsState = cookie.columns;    
//  }
//  else
//  {
    columnsState = tableState.columns;
//  }
  initializeColumnSelectionModal(columnsState);
  
  var modalCopy = $("#r2modalMultiCopy");
  modalCopy.on("show.bs.modal", function(e)
  {
    displayCopyForm(r2ManageDataTable);
  });
  
  modalCopy.on("hide.bs.modal",function(e)
  {
    originalPENumberForSingleCopy = "";
    originalBAForSingleCopy = "";
    originalBAIdForSingleCopy=0;
  });
  
  $("#r2modalDeleteConfirmation").on("show.bs.modal", function(e)
  {
    deleteButtonHandler(r2ManageDataTable);  
  });
  
  $("#r2modalFreezeConfirmation").on("show.bs.modal", function(e)
  {
    var button = $(e.relatedTarget);
    var action = button.data("action");
    if(action=='freeze')
    {
      freezeButtonHandler(r2ManageDataTable);
    }
    else if (action=='unfreeze')
    {
      unfreezeButtonHandler(r2ManageDataTable);
    }
  });
  
  var modalCopyButton =$("#r2ModalMultiCopyButton");
  modalCopyButton.unbind("click");
  modalCopyButton.click(function(e) {
    e.preventDefault();
    var validationObject = validateCopyForm();
    
    if (validationObject.allGood)
    {
      submitCopyForm(r2ManageDataTable);
    }
    else
    {
      console.log(validationObject.errors);
        var alertText = '<h4>Error:</h4><ul>';
        for (var i = 0; i < validationObject.errors.length; i++) {
          alertText = alertText + '<li>' + validationObject.errors[i] + '</li>';
        }
        alertText += '</ul>';
        var errorMessage =$('#copyErrorMessage'); 
        errorMessage.html(alertText);
        errorMessage.show();
       return false;
    }
  });
}


function initializeColumnSelectionModal(columnsState)
{
  // read the table's state to set the checkboxes if it is null set the default values;
  var counter=1;
  $("[id^='r2ColumnCheckbox_']").each(function(){
    var colVisible = columnsState[counter].visible;
    if (colVisible)
    {  
      $(this).prop("checked", "checked");
    }
    counter++;
  });
}

function setupBudgetCycleReload(reloadUrl)
{
  try
  {
    $("#budget-cycle-filter").change(function (e){
      var filterText = $("#budget-cycle-filter :selected").attr('value');
      filterText = URLEncoder.encode(filterText);
      window.location.href = reloadUrl+"/"+filterText;
    });
  } 
  catch (ex)
  {
    console.log(ex)
  }
}

function getPEBase(peNumber, selectedPE)
{  var peBase={};
  $.ajax({
    url:"/r2/endpoints/R2PEBase/"+peNumber,
    type:"POST",
    contentType: "application/json",
    dataType: "json",
    data:
      {peNumber: peNumber},
      success: function(response) {
        if(typeof response.PEBase != 'undefined') {
          displaySingleCopyForm(response.PEBase, selectedPE);
        } else if(typeof response.errorMessages!='undefined' && response.errorMessages.length) {
          $("#r2modalMultiCopy").modal('hide');
          renderServerResponse(response, "Error fetching PE information for copy");
        } else {
          $("#r2modalMultiCopy").modal('hide');
          var errorResponseObj = {"errorMessages":[{"message":"Unable to get PE information from server."}]};
          renderServerResponse(errorResponseObj, "Error fetching PE information for copy");
        }
        return false;
      }
  });
  
}

function clearCopyForm()
{
  var programElementNumberInput = $("#r2CopyProgramElementNumberInput");
  var budgetCycleSelect = $("#r2CopyBudgetYearCycleSelect");
  
  $("#copyPeRows").empty();
  budgetCycleSelect.val("");
  $("#r2BudgetYearCycle").val("");
  programElementNumberInput.val("");
  $("#r2CopyAgencySelect").val("");
  
  $("#r2CopyAppropriation").empty();
  $("#r2CopyActivitySelect").empty();  
  $("#r2isR2LongCheckbox").prop("checked",false);
  $("#r2CopyUsersCheckbox").prop("checked",false);
  $("#r2CopyTestCheckbox").prop("checked",false);
  $("#r2CopyTag").val("");
  
  
  programElementNumberInput.unbind("change");
  budgetCycleSelect.unbind("change");
  
  clearValidationDiv(programElementNumberInput.next(),programElementNumberInput);
  clearValidationDiv(budgetCycleSelect.next(),budgetCycleSelect);
  
  var errorMessage = $("#copyErrorMessage");
  var successMessage = $("#copySuccessMessage");
  errorMessage.empty();
  successMessage.empty();
  errorMessage.hide();
  successMessage.hide();
  
}

function getFundingYearStr(currentYear, delta)
{
  var yr = currentYear + delta;
  return yr.toString();
}

function slashIfNullOrZero(val)
{
  if (val==null)
  {
    return "-";
  }
  else if (val===0)
  {
    return "-";
  }
  return val.toString();
}


function submitCopyForm(r2ManageDataTable)
{
$("#r2modalProgress").modal('show');  
  var copyUsers = false;
  var copyUsersCheckbox = $("#r2CopyUsersCheckbox");
  if (copyUsersCheckbox.length)
  {
    copyUsers = copyUsersCheckbox.is(":checked");
  }
  var testPe = false;
  var testCheckbox = $("#r2CopyTestCheckbox");
  if (testCheckbox.length)
  {
    testPe = testCheckbox.is(":checked");
  }

  var budgetCycleSelect = $("#r2CopyBudgetYearCycleSelect");
  var oldBudgetCycle = $("#r2BudgetYearCycle");
  var formVals = {
          action: "copyProgramElements",
          programElements:[],
          budgetCycle: budgetCycleSelect.val().split(" ")[0],
          budgetYear: budgetCycleSelect.val().split(" ")[1],
          budgetActivity: $("#r2CopyActivitySelect").val(),
          copyUsers: copyUsers,
          test: testPe,
          tags:$("#r2CopyTag").val()
  };

  var peListData = r2ManageDataTable.data();
  var count = 0 ;
  var pes = [];
  for (var i=0; i<peListData.length;i++)
  {
    if (peListData[i].selected)
    {
      pes[count]={id:peListData[i].id};
      count++;
    }
  }
  formVals.programElements = pes;
  // if only one, add the program element number
  if (count==1)
  {
    formVals.programElements[0].programElementNumber=$("#r2CopyProgramElementNumberInput").val();
  }
  
  
  var jsonObj = {"json":JSON.stringify(formVals)};
   $.ajax({
            url:"/r2/endpoints/r2Copy",
            type: "POST",
            data: jsonObj,
            dataType: "json",
            success:   function(data) {
          $("#r2modalProgress").modal('hide');
          renderServerResponse(data, "Copy Program Elements");
          clearSelections(peListData);
          r2ManageDataTable.ajax.reload();
            },
         error : function(data)
         {
           $("#r2modalProgress").modal('hide');
          renderServerError(data, "Copy Program Elements");  
         }
       
   });
}

function validateCopyForm()
{
   var validationObjects = [];
   var programElementNumberField = $("#r2CopyProgramElementNumberInput");
   if (programElementNumberField.length && programElementNumberField.is(":visible"))
   {
    validationObjects.push(checkPeNumberValidation());
   }

   validationObjects.push(checkBudgetCycleValidation());
    var activitySelectField =$("#r2CopyActivitySelect"); 
    if (activitySelectField.length)
  {
      validationObjects.push(validateBudgetActivity(activitySelectField));
  }
    var errors = [];
    for (var i = 0; i < validationObjects.length; i++) {
      if (!validationObjects[i].valid) {
        errors.push(validationObjects[i].message);
      }
    }
    
    var userTagField = $("#r2CopyTag");
    if (userTagField.val().length>12)
    {
    validationObjects.push({'valid': false, 'message': 'User defined tags cannot be greater than 12 characters.'});  
    }
    
    if (errors.length === 0) {
      return {'allGood': true};
    } else {
      return {'allGood': false, 'errors': errors};
    }
}

function clearValidationDiv(validationDivObject, field)
{
  validationDivObject.removeClass('r2ValidatorInfo');
  validationDivObject.removeClass('r2ValidatorError');
  validationDivObject.removeClass('r2ValidatorGood');
  validationDivObject.empty();
  field.css('border', '1px solid #ccc');
}

function updateValidationDiv(validationDivObject, validationObject, field)
{
  validationDivObject.removeClass('r2ValidatorInfo');
  validationDivObject.removeClass('r2ValidatorError');
  validationDivObject.removeClass('r2ValidatorGood');
  validationDivObject.text(validationObject.message);
    if (validationObject.valid) {
      validationDivObject.addClass('r2ValidatorGood');
      field.css('border', '1px solid #ccc');
    } else {
      validationDivObject.addClass('r2ValidatorError');
      field.css('border', '1px solid #f00');
    }
}

function checkPeNumberValidation() {
    var programElementNumberField = $("#r2CopyProgramElementNumberInput");
    var validationObject = validatePeNumber(programElementNumberField);
    var validationDiv = programElementNumberField.next();
    updateValidationDiv(validationDiv,validationObject, programElementNumberField);
    return validationObject;
}

function checkBudgetCycleValidation()
{
  var budgetCycleSelect = $("#r2CopyBudgetYearCycleSelect");
  var validationObject = validateBudgetCycle(budgetCycleSelect);
  
  var validationDiv = budgetCycleSelect.next();
  updateValidationDiv(validationDiv,validationObject, budgetCycleSelect);
  return validationObject;
}

function validatePeNumber(field) {
    var inputVal = field.val();
    if (inputVal.length === 0) {
      return {'valid': false, 'message': 'The program element number must not be empty.'};
    }
    if (inputVal.length > 40) {
	  return {'valid': false, 'message': 'The program element number length can not be greater than 40.'};
    }
    if (!/^[0-9A-Za-z\(\)\[\]\-\_\#\@\:\.\s]*$/.test(inputVal)) {
	  return {'valid': false, 'message': 'The program element number contains invalid characters.'};
  	}
//    var numberPortion = inputVal.substring(0, 7);
//    var suffixPortion = inputVal.substring(7);
//    if (numberPortion.length !== 7) {
//      return {'valid': false, 'message': 'The program element number must begin with seven digits.'};
//    }
//    if (! /^[0-9]+$/.test(numberPortion)) {
//      return {'valid': false, 'message': 'The program element number must begin with seven digits.'};
//    }
//    var selectedAgency = $("#r2CopyServiceAgencyInput").val();
//    if (selectedAgency === "null" || selectedAgency===undefined) {
//      return {'valid': false, 'message': "The program element number's suffix depends on the agency selected. The agency has not been set."};
//    } else {
//      var matchFound = false;  
//      for (var a = 0; a < activityJson.agencies.length; a++) {
//        var agency = activityJson.agencies[a];
//        if (selectedAgency == agency.code) {
//        matchFound = true;
//        
//          if ($.inArray(suffixPortion, agency.suffixes) < 0) {
//            var helpStr = agency.name + " program element numbers must end with ";
//            helpStr  = helpStr + agency.suffixes.join(' or ');
//            return {'valid': false, 'message': helpStr + "."};
//          }
//        }
//      }
//      if (!matchFound)
//        {
//        return {'valid': false, 'message': 'Selected Agency is invalid.'};
//        }
//    }
    return {'valid': true, 'message': 'Valid program element number.'};
}

function validateBudgetCycle(budgetCycleSelect)
{
  var oldBudgetCycle = $("#r2BudgetYearCycle").val();
  var ba = $("#r2CopyActivitySelect").val();
  //validate for multi select - can't multi select within same year
  var programElementNumberField = $("#r2CopyProgramElementNumberInput");
  var newBudgetCycle = budgetCycleSelect.val();
  if (!programElementNumberField.length || !programElementNumberField.is(":visible")) {
    if (oldBudgetCycle==newBudgetCycle)
    {
      return {'valid': false, 'message': 'Cannot perform copy to same budget cycle.'};
    }
  }
  else {
    if ((oldBudgetCycle==newBudgetCycle)&&(originalPENumberForSingleCopy==programElementNumberField.val()) && (originalBAIdForSingleCopy==ba))
    {
      return {'valid': false, 'message': 'Same PE Number for Budget Cylce \"'+newBudgetCycle+'\" and Budget Activity \"'+originalBAForSingleCopy+'\" already exists.' };
    }
  }
  
  var oldBudgetYear = oldBudgetCycle.split(" ")[1];
  var budgetYear = budgetCycleSelect.val().split(" ")[1];
  if(budgetYear < oldBudgetYear)
  {
    return {'valid': false, 'message': 'Cannot copy to previous year.'};
  }
  else if ((budgetYear - oldBudgetYear) > 3)
  {
    return {"valid": false, 'message': 'Cannot copy more than three years ahead.'};
  }
  
  
  return {'valid': true, 'message': 'Valid budget cycle.'};
  
}

function validateBudgetActivity(activitySelectField)
{
  if (activitySelectField.val()=="")
  {
    return {'valid': false, 'message': 'Please select a Budget Activity.'};
  }
  return {'valid': true, 'message': 'Valid budget activity.'};
}

function deleteButtonHandler(r2ManageDataTable)
{
  var peListData = r2ManageDataTable.data();
  var rowStr = "";
  
  var dataVals = {
      action: "deleteProgramElements",
      programElements:[]
  };
  var selectedPEs = [];
  var pes= [];
  var count=0;
  for (var i=0;i<peListData.length;i++)
  {
    if (peListData[i].selected)
    {
      var selectedPE = {"number":null,"title":null,"agencyCode":null};
      selectedPE.number = peListData[i].number;
      selectedPE.title = peListData[i].title;
      selectedPE.agencyCode = peListData[i].serviceAgencyCode;
      selectedPEs[count] = selectedPE;
      pes[count]={id:peListData[i].id};
      count++;
    }
  }
  dataVals.programElements = pes;
  
  var deleteFormContainer = $("#r2DeleteFormContainer");
  var deleteConfirmationBtn =$("#confirmDeleteBtn");
  var deleteErrorMessage =$("#deleteErrorMessage");
  
  deleteErrorMessage.empty();
  if (count==0)
  {
    deleteFormContainer.children().hide();
    deleteConfirmationBtn.prop("disabled",true);
    deleteErrorMessage.append("<h4>Error:</h4><p>No program elements were selected.</p>");
    deleteErrorMessage.show();
  }
  else
  {
    deleteErrorMessage.hide();
    var deleteTable = $("#r2DeleteProgramElementNumbers").dataTable({
      "autoWidth" : false,
    	"data":selectedPEs,
      "pageLength":5,
      "paging":true,
      "searching":false,
      "lengthChange": false,
      "columns": [
        {"data":"number",
          "bSearchable":false,
              "bSortable":false,
              "className": "r2PeNumCol"
        },
        {"data":"title",
          "bSearchable":false,
              "bSortable":false
        },
        {"data":"agencyCode",
          "bSearchable":false,
              "bSortable":false
        }
        
      ],
      "destroy":true
    });
    
    deleteFormContainer.children().show();
    deleteConfirmationBtn.prop("disabled",false);  
    
    deleteConfirmationBtn.unbind("click");
    deleteConfirmationBtn.click(function (e){
      e.preventDefault();
      // add progress bar
      var jsonObj = {"json":JSON.stringify(dataVals)};
      $("#r2modalProgress").modal('show');
      $.ajax({
        url:"/r2/endpoints/r2delete",
        dataType: "json",
        type: "POST",
        data: jsonObj,
        success: function(response)
        {
          $("#r2modalProgress").modal('hide');
          renderServerResponse(response, "Delete Program Elements");
          clearSelections(peListData);
          
          r2ManageDataTable.ajax.reload();
        },
        error: function(response)
        {
          console.log("failed");
          var responseStr = JSON.stringify(response);
          console.log(responseStr);
          $("#r2modalProgress").modal('hide');
          renderServerError(response, "Delete Program Elements");
          $("#r2modalEndpointResponse").modal();
        }
      });
    });
  }
}

function displayCopyForm(r2ManageDataTable)
{
  clearCopyForm();
  var peListData = r2ManageDataTable.data();
  var count = 0;
  var programElementNumbersTable = $("#copyPeRows");
  var rowStr = "";
  var selectedPEs = [];
  
  for (var i=0; i<peListData.length;i++)
  {
    if (peListData[i].selected)
    {
      var selectedPE = {"number":null,"title":null,"agencyCode":null};
      selectedPE.number = peListData[i].number;
      selectedPE.title = peListData[i].title;
      selectedPE.agencyCode = peListData[i].serviceAgencyCode;
      selectedPEs[count] = selectedPE;
      count++;
    }
  }
  

  var copyForm = $("#copyFormContainer");
  var copyErrorMessage =$("#copyErrorMessage");
  if (count==0)
  {
    copyForm.children().hide();
    $("#r2ModalMultiCopyButton").prop("disabled",true); 
    copyErrorMessage.append("<h4>Error:</h4><p>No program elements were selected.</p>");
    copyErrorMessage.show();
  }  
  else 
  {
    var copyTable = $("#r2CopyProgramElementNumbers").dataTable({
    	"autoWidth" : false,
    	"data":selectedPEs,
      "pageLength":5,
      "paging":true,
      "searching":false,
      "lengthChange": false,
      "columns": [
        {"data":"number",
          "bSearchable":false,
              "bSortable":false,
              "className": "r2PeNumCol"
        },
        {"data":"title",
          "bSearchable":false,
              "bSortable":false
        },
        {"data":"agencyCode",
          "bSearchable":false,
              "bSortable":false
        }
        
      ],
      "destroy":true
    });
    copyForm.children().show();

    $("#r2ModalMultiCopyButton").prop("disabled",false);
    
    var currentBudgetCycle = $("#r2CopyBudgetYearCycleSelect option").last().val();
    var oldBudgetYearCycle =$("#r2BudgetYearCycle"); 
    var newBudgetYearCycle = $("#r2CopyBudgetYearCycleSelect");
    oldBudgetYearCycle.val(peListData[0].budgetCycle+" "+peListData[0].budgetYear);
    newBudgetYearCycle.val(currentBudgetCycle);
    
    newBudgetYearCycle.change(function() {
      copyErrorMessage.empty();
      copyErrorMessage.hide();
      checkBudgetCycleValidation();
    });
  }
  if (count>1)
  {
    $("#r2ControlGroup_ProgramElementNumber").hide();
    $('#r2CopyActivity').hide();
  }
  if (count==1)
  {
    for (i=0; i<peListData.length;i++)
    {
      if (peListData[i].selected)
      {  
        getPEBase(peListData[i].id, peListData[i]);
        break;
      }
    }  
  }
  
}

function displaySingleCopyForm(peBase,selectedPE)
{
  var programElementNumberInput = $("#r2CopyProgramElementNumberInput");
  var agencySelect = $("#r2CopyServiceAgencyInput");
  var activityControlGroup = $('#r2CopyActivity');
  var activitySelect = $("#r2CopyActivitySelect");
  programElementNumberInput.val(selectedPE.number);
  originalPENumberForSingleCopy = selectedPE.number; 
  originalBAForSingleCopy = peBase.budgetActivity;
  var budgetCycleSelect = $("#r2CopyBudgetYearCycleSelect");
  agencySelect.val(selectedPE.serviceAgencyCode);
  var errorMessage = $("#copyErrorMessage");
  programElementNumberInput.unbind("change");
  programElementNumberInput.change(function() {
      errorMessage.empty();
      errorMessage.hide();
      checkPeNumberValidation();
      checkBudgetCycleValidation();
  });
  $("#r2ControlGroup_ProgramElementNumber").show();
  activityControlGroup.show();
//  $agencySelect.val(selectedPE.serviceAgencyCode);
//  $agencySelect.prop("disabled",true);
  $("#r2CopyAppropriation").append(peBase.appropriation.code+": "+peBase.appropriation.name+" /");
  for (var i=0; i<activityJson.agencies.length; i++)
  {
    var agency = activityJson.agencies[i];
    if (agency.id==peBase.serviceAgency.id)
    {
      for (var j=0; j<agency.appropriations.length; j++)
      {
        var approp = agency.appropriations[j];
        if (approp.id == peBase.appropriation.id)
        {
          var budgetActivities = approp.budgetactivities;
          var activityOptions = "";
          for (var ba = 0; ba < budgetActivities.length; ba++) {
            var selected = '';
            
            var tmpVal = 'BA '+budgetActivities[ba].number + ' - ' + budgetActivities[ba].title;
            if (peBase.budgetActivity==tmpVal)
            {
              selected = ' selected="selected"';
              originalBAIdForSingleCopy = budgetActivities[ba].id;
            }
            activityOptions += '<option value="' + budgetActivities[ba].id + '"'+selected+'>BA ' + budgetActivities[ba].number + ': ' + budgetActivities[ba].title + '</option>';
            
          }
          activitySelect.append(activityOptions);
          break;
        }
      }
      break;
    }
  }
  activitySelect.unbind("change");
  activitySelect.change(function() {
    errorMessage.empty();
    errorMessage.hide();
    checkBudgetCycleValidation();
  });
  $("#r2CopyTestCheckbox").prop("checked", peBase.test);
}

function renderActionButtonGroup(copyEnabled, freezeEnabled, deleteEnabled)
{
  if(!copyEnabled && !freezeEnabled && !deleteEnabled)
  {
    return;
  }
  if ($(".r2ManageActionButtonGroup").length)
  {
    return;
  }
    
  var actionCopyButton = "<button class='cxeButton r2CopyButton' data-toggle='modal' data-target='#r2modalMultiCopy'>Copy</button>";
  var actionFreezeButton = "<button class='cxeButton r2FreezeButton' data-toggle='modal' data-target='#r2modalFreezeConfirmation' data-action='freeze'>Freeze</button><button class='cxeButton r2FreezeButton' data-toggle='modal' data-target='#r2modalFreezeConfirmation' data-action='unfreeze'>Unfreeze</button> ";
  var actionDeleteButton = "<button class='cxeButton r2DeleteButton' data-toggle='modal' data-target='#r2modalDeleteConfirmation'>Delete</button>";
  var r2ActionButtons = "<div class='r2ManageActionButtonGroup'>";
  
  if (copyEnabled)
  {
    r2ActionButtons +=actionCopyButton;
  }
  if (freezeEnabled)
  {
    r2ActionButtons +=actionFreezeButton;
  }
  
  if (deleteEnabled)
  {
    r2ActionButtons +=actionDeleteButton;
  }
  r2ActionButtons +="</div>";
  
  $("#r2ProgramElementsManage_length").after(r2ActionButtons);
//  $(".r2DeleteButton").hide();
//  $(".r2FreezeButton").hide();
}

function clearSelections(peListData)
{
  for (var i=0; i<peListData.length;i++)
  {
    if (peListData[i].selected)
    {
      peListData[i].selected = false;
    }
  }
  $(".r2PESelectionCheckbox").prop("checked",false);
}

function renderServerResponse(response, responseHeader)
{
  var header = $("#r2modalEndpointResponseHeader");
  header.empty();
  header.append(responseHeader);
  var successMessage = $("#successMessage");
  var errorMessage = $("#errorMessage");
  successMessage.empty();
  errorMessage.empty();
  errorMessage.hide();
  successMessage.hide();
  
  if (typeof response.successMessages!='undefined' && response.successMessages.length>0)
  {
    
    var successStr = "<h4>Success</h4><ul style=\"height:100px;overflow-y:auto\">";
    for (var j=0;j<response.successMessages.length;j++)
    {
      successStr+="<li>"+response.successMessages[j].message+"</li>";
    }
    successStr+="</ul>";
    successMessage.append(successStr);
    successMessage.show();
  }
  if (typeof response.errorMessages!='undefined' && response.errorMessages.length>0)
  {
    var errHtml = "<h4>Failed</h4><ul style=\"height:100px;overflow-y:auto\">";
    for (var i=0; i<response.errorMessages.length; i++)
    {
      errHtml+="<li>"+response.errorMessages[i].message+"</li>";
    }
    errHtml+="</ul>";
    errorMessage.append(errHtml);
    errorMessage.show();
  }
  $("#r2modalEndpointResponse").modal();
}

function renderServerError(response, responseHeader)
{
  var successMessage = $("#successMessage");
  var errorMessage = $("#errorMessage");
  var header = $("#r2modalEndpointResponseHeader");
  
  header.empty();
  header.append(responseHeader);
  successMessage.empty();
  errorMessage.empty();
  errorMessage.hide();
  successMessage.hide();
  
  var errorMessage = $("#errorMessage");
  var errHtml = "<h4>Failed</h4><textarea style='height: 200px; width: 100%;>"+response+"</textarea>";
  errorMessage.append(errHtml);
  errorMessage.show();
  $("#r2modalEndpointResponse").modal();
}  

function freezeButtonHandler(r2ManageDataTable)
{  
  var peListData = r2ManageDataTable.data();
  var dataVals = {
      action: "freezeProgramElements",
      programElements:[]
  };
  displayFreezeModal(dataVals, peListData, r2ManageDataTable);
}

function unfreezeButtonHandler(r2ManageDataTable)
{
  var peListData = r2ManageDataTable.data();
  var dataVals = {
      action: "unfreezeProgramElements",
      programElements:[]
  };
  displayFreezeModal(dataVals, peListData, r2ManageDataTable);
}

function displayFreezeModal(dataVals, peListData, r2ManageDataTable)
{
  var confirmationHeader = $("#r2modalFreezeConfirmationHeader");
  var confirmationQuestion = $("#r2modalFreezeQuestion");
  var button = $("#confirmFreezeBtn");
  var unfreezeForceCheckbox = $("#r2UnFreezeForceCheckbox");
  confirmationHeader.empty();
  confirmationQuestion.empty();
  button.empty();
  var freeze = dataVals.action =="freezeProgramElements" ? true:false;
  if (freeze)
  {
    confirmationHeader.append("Freeze Confirmation");
    button.append("Freeze");
    if (unfreezeForceCheckbox.length)
    {
      $(".r2UnfreezeForceControl").children().hide();
    }
  }
  else
  {
    confirmationHeader.append("Unfreeze Confirmation");
    button.append("Unfreeze");
    if (unfreezeForceCheckbox.length)
    {
      $(".r2UnfreezeForceControl").children().show();
    }
  }
    
  var pes = [];
  var selectedPEs = [];
  var invalidStatePEs = [];
  var count=0;
  var onlyFrozenSelected = true;
  for (var i=0;i<peListData.length;i++)
  {
    if (peListData[i].selected)
    { 
      if ( (freeze && (!peListData[i].allLocked || !peListData[i].lockedByOtherUser)) ||
         (!freeze && peListData[i].allLocked)  
         )
      {
        pes[count]={id:peListData[i].id};
        var selectedPE = {"number":null,"title":null,"agencyCode":null};
        selectedPE.number = peListData[i].number;
        selectedPE.title = peListData[i].title;
        selectedPE.agencyCode = peListData[i].serviceAgencyCode;
        selectedPEs[count] = selectedPE;
        if(!peListData[i].allLocked){
        	onlyFrozenSelected = false
        }
        count++;
      }
      else 
      {
        var invalidPE = peListData[i].number+" - "+peListData[i].title;
        invalidStatePEs.push(invalidPE);
      }
    }
  }
  
  dataVals.programElements = pes;
    
  
  var freezeFormContainer = $("#r2FreezeFormContainer");
  var freezeConfirmationBtn =$("#confirmFreezeBtn");
  var freezeErrorMessage = $("#freezeErrorMessage");
  freezeErrorMessage.empty();
  
  if (count==0)
    {
		freezeFormContainer.children().hide();
		freezeConfirmationBtn.prop("disabled", true);
		if (invalidStatePEs.length == 0) 
		{
			freezeErrorMessage
					.append("<h4>Error:</h4><p>Please select a program element.</p>");
			freezeErrorMessage.show();
		}
	}
    
  else if (onlyFrozenSelected && freeze) 
    {
		freezeFormContainer.children().hide();
		freezeConfirmationBtn.prop("disabled", true);
		if (invalidStatePEs.length == 0) 
		{
			freezeErrorMessage
					.append("<h4>Error:</h4><p>Please select an unfrozen program element to freeze.</p>");
			freezeErrorMessage.show();
		}
    }
  
  else if (count>0)
  {
    if (freeze)
    {
      confirmationQuestion.append("Are you sure you want to freeze the following Program Elements?");
    }
    else
    {
      confirmationQuestion.append("Are you sure you want to unfreeze the following Program Elements?");
    }
    
    freezeFormContainer.children().show();
    freezeErrorMessage.hide();
    var freezeTable = $("#r2FreezeProgramElementNumbers").dataTable({
    	"autoWidth" : false,
    	"data":selectedPEs,
      "pageLength":5,
      "paging":true,
      "searching":false,
      "lengthChange": false,
      "columns": [
        {"data":"number",
          "bSearchable":false,
              "bSortable":false,
              "className": "r2PeNumCol"
        },
        {"data":"title",
          "bSearchable":false,
              "bSortable":false
        },
        {"data":"agencyCode",
          "bSearchable":false,
              "bSortable":false
        }
        
      ],
      "destroy":true
    });
    
    
    freezeConfirmationBtn.prop("disabled",false);  
    
    freezeConfirmationBtn.unbind("click");
    freezeConfirmationBtn.click(function (e){
      // add progress bar
      e.preventDefault();
      if (dataVals.action=='unfreezeProgramElements' && unfreezeForceCheckbox.length)
      {
          dataVals.force =unfreezeForceCheckbox.is(":checked");
      }
      else
      {
          dataVals.force =false;
      }
      var jsonObject= {"json": JSON.stringify(dataVals)};
      $("#r2modalProgress").modal('show');
      $.ajax({
        url:"/r2/endpoints/r2freeze",
        dataType: "json",
        type: "POST",
        data: jsonObject,
        success: function(response)
        {
          $("#r2modalProgress").modal('hide');
          if (dataVals.action=='freezeProgramElements')
          {
            renderServerResponse(response, "Freeze Program Elements");
          }
          else
          {
            renderServerResponse(response, "Unfreeze Program Elements");
          }  
          clearSelections(peListData);
          
          r2ManageDataTable.ajax.reload();
        },
        error: function(response)
        {
          console.log("failed");
          var responseStr = JSON.stringify(response);
          console.log(responseStr);
          $("#r2modalProgress").modal('hide');
          if (dataVals.action=='freezeProgramElements')
          {
            renderServerResponse(response, "Freeze Program Elements");
          }
          else
          {
            renderServerResponse(response, "Unfreeze Program Elements");
          }
          $("#r2modalEndpointResponse").modal();
        }
      });
    });
  }
  
  if (invalidStatePEs.length>0)
  {
    var errStr = "<h4>Warning:</h4><p>The following Program Elements are already";
    if (freeze)
    {
      errStr += " frozen and no action will be taken:"
    }
    else
    {
      errStr += " not frozen and no action will be taken:"
    }
    errStr+="</p><ul class='r2ManageErrorList'>";
    
    for (var i=0;i<invalidStatePEs.length; i++)
    {
      errStr+="<li>"+invalidStatePEs[i]+"</li>";
    }
    errStr+="</ul>";
    freezeErrorMessage.append(errStr);
    freezeErrorMessage.show();
  }
}

function updateSelectAllCheckbox(peSelectionBoxes,r2SelectAllCheckbox, peListData)
{
  var allchecked = true;
  //now update the data
  peSelectionBoxes.each(function()
  {
    var index = $(this).val();
    if (!peListData[index].selected)
    {
      allchecked = false;
      return false;
    }
  });
  r2SelectAllCheckbox.prop("checked",allchecked);
}
	
