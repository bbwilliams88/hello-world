function setResponseModalMessages(headerText, messages) {
	  console.log(JSON.stringify(messages));
	  $("#r2modalHeader").text(headerText);
	  var msgList = $("#errorMessagesList");
	  msgList.empty();
	  for(var i=0; i<messages.length; i++) {
	    msgList.append("<li>" + messages[i] + "</li>");
	  }
	  $("#errorMessagesModal").modal();
	}
