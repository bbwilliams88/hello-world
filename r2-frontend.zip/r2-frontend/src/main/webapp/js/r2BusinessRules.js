

//=======================
//Program Element Business Rules
//=======================
function validateRDTEPE420(jqSelection) {
//  console.log("Rule RDTE#PE-420");
  var valid = {'allGood': true, 'errors': []};
  var input = $("#r2R1LineNumberInput");
  var errorContainer = input.siblings('.r2TopLevelOtherHeader')[0];
  
  var ruleStr = "RDTE#PE-420 - The R-1 Line Number must be numeric.";
  var regex = /^\d{0,10}$/;
  
  if (input.val().length<=0 || input.val()=='') {
    valid.allGood = false;
    valid.errors.push(ruleStr);
    setInputError(input, ruleStr);
  }
    
  else if (!regex.test(input.val())){
    valid.allGood = false;
    valid.errors.push(ruleStr);
    setInputError(input, ruleStr);
  }
  else {
    clearInputError(jqSelection);
  }
  
  return valid;
}


//======================================
//R2a Business Rules
//=======================================

// RDTE#R2a-230 - Project Mission Description not null
function validateRuleR2a230(jqSelection) {
  var valid = {'allGood': true, 'errors': []};
  var inputField = jqSelection.siblings('.r2aProjectMissionDescriptionInput');
  return validateRequiredField(jqSelection, inputField, 'RDTE#R2a-230 - Project Mission Description and Budget Item Justification is required.');
}

// RDTE#R2a-251 - Congressional Add Details Title not null
function validateRule2a251(jqSelection){
  var valid = {'allGood': true, 'errors': []};
  var inputField = jqSelection.find('.r2aCongressionalAddDetailTitle');
  return validateRequiredField(jqSelection, inputField, 'RDTE#R2a-251 - Congressional Add Detail title is required.');
  
}

// RDTE#R2a-311 - Other Program Funding Item Number not null
function validateRule2a311(jqSelection) {
  var valid = {'allGood': true, 'errors': []};
  
  var lineItemField = jqSelection.find('.r2aOtherProgramFundingLineItem');
  if (lineItemField.length>0){
    if (lineItemField.val().length<=0 || lineItemField.val()=='') {
      jqSelection.addClass('r2FormInputError');
      valid.allGood = false;
      valid.errors.push('RDTE#R2a-311 - Other Program Funding Summary line item number is required.');
      setInputError(jqSelection, 'RDTE#R2a-311 - Other Program Funding Summary line item number is required.');
    }
    
  }
  return valid;
}

// RDTE#R2a-312 - Other Program Funding Item Title not null
function validateRule2a312(jqSelection) {
  var valid = {'allGood': true, 'errors': []};
  var titleField = jqSelection.find('.r2aOtherProgramFundingTitle');
  if (titleField.length>0){
    if ( titleField.val().length<=0 || titleField.val()==''){
      jqSelection.addClass('r2FormInputError');
      valid.allGood = false;
      valid.errors.push('RDTE#R2a-312 - Other Program Funding Summary line item title is required.');
      setInputError(jqSelection, 'RDTE#R2a-312 - Other Program Funding Summary line item title is required.');
    }
    

  }
  return valid;
}

// RDTE#2a-219 - Accomplishment Plan Title not null
function validateRuleR2a219(jqSelection) {
  var inputField = jqSelection.find('.r2aAccomplishmentPlannedProgramTitle');
  return validateRequiredField(jqSelection, inputField, 'RDTE#2a-219 - Accomplishment/Planned Program Title is required.');
}

// =======================================
// R4a Business Rules
// =======================================

// R4a Schedule Detail SubProject Title blank as N/A
function validateRuleR4aBlankSubProject(jqSelection) {
  var inputField = jqSelection.find('.r4aScheduleTitleInput');
  if (inputField.val().length<=0 || inputField.val()==''){
    inputField.val("N/A");
  }
  //revalidate the subproject titles again
  $('.r4aScheduleTitleRow').find('.validation-container').remove();
  validateR4aRule130($('.exhibitR4a'));
}

// RDTE#R4a-105 - R4a Schedule Detail Event Title not null
function validateRuleR4a105(jqSelection) {
  var inputField = jqSelection.find('.r4aScheduleEventTitleInput');
  return validateRequiredField(jqSelection, inputField,  'RDTE#R4a-105 - Schedule Detail Event Title is required.')
}


//================================
// Generic required field validation
//================================
function validateRequiredField(jqSelection, inputField, ruleMessage) {
//  console.log("Validating Rule: "+ruleMessage);
  var valid = {'allGood': true, 'errors': []};
  var regex = /^\s*$/;
  if (inputField.length>0) {
	var tmpVal = inputField.val();
    if (tmpVal.length<=0 || tmpVal==''){
      valid.allGood=false;
      valid.errors.push(ruleMessage);
      setInputError(inputField, ruleMessage);
    }
    else if (regex.test(tmpVal)){
    	valid.allGood=false;
        valid.errors.push(ruleMessage);
        setInputError(inputField, ruleMessage);	
    }
  }
  return valid;
}