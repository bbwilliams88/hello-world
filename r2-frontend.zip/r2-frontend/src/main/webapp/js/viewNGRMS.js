var r1Table, p1Table;

function r1TableInit(sourceUrl) {
  r1Table = $("#r1DataTable").DataTable({
    "order":[
             [0, 'asc'], // organization
             [1, 'asc'], // account
             [2, 'asc'], // BA
             [4, 'asc'], // PE num
             [5, 'asc'] // project num
             ],
    "buttons" : [
    	{
    		"extend" : "csv",
    		"text" : "Download CSV",
    		"fieldSeparator" : ",",
            "filename" : "R1 Data",
    		"extension" : ".csv",
    	}
    ],
    "sDom" : 'B<"H"lfr>t<"F"ip>',
    "autoWidth": true,
    "serverSide": false,
    "language": { "emptyTable": "No results found." },
    "deferRender": true,
    "ajax": { "url": sourceUrl, "type": "POST" },
    "initComplete": function(settings, json) {
      if(typeof json.aaData !== "undefined") {
        console.log("rows retrieved: " + json.aaData.length);
        if (json.aaData.length) console.log(json.aaData[0]);
      }
      else {
        console.log("no aaData returned");
      }
    },
    "columns": [
                { "data": "organization" },
                { "data": "account" },
                { "data": "budgetActivity" },
                { "data": "lineNumber" },
                { "data": "peNumber", className: "r2ViewNGRMS_peNumber" },
                { "data": "projectNumber" },
                { "data": "py", "searchable": "false" },
                { "data": "cy", "searchable": "false" },
                { "data": "by1Base", "searchable": "false" },
                { "data": "by1OOC", "searchable": "false" },
                { "data": "by1", "searchable": "false" },
                { "data": "by2", "searchable": "false" },
                { "data": "by3", "searchable": "false" },
                { "data": "by4", "searchable": "false" },
                { "data": "by5", "searchable": "false" }
                ]
  });
}

function p1TableInit(sourceUrl) {
  p1Table = $("#p1DataTable").DataTable({
    "order":[
             [0, 'asc'], // organization
             [1, 'asc'], // account
             [2, 'asc'], // BA
             [3, 'asc'], // BSA
             [5, 'asc'], // LI num
             [6, 'asc'] // cost type
             ],
   "buttons" : [
	   {
		   "extend" : "csv",
           "text" : "Download CSV",
           "fieldSeparator" : ",",
           "filename" : "P1 Data",
           "extension" : ".csv",
       }
    ],
    "sDom" : 'B<"H"lfr>t<"F"ip>',
    "autoWidth": true,
    "serverSide": false,
    "language": { "emptyTable": "No results found." },
    "deferRender": true,
    "ajax": { "url": sourceUrl, "type": "POST" },
    "initComplete": function(settings, json) {
      if(typeof json.aaData !== "undefined") {
        console.log("rows retrieved: " + json.aaData.length);
        if (json.aaData.length) console.log(json.aaData[0]);
      }
      else {
        console.log("no aaData returned");
      }
    },
    "columns": [
                { "data": "organization" },
                { "data": "account" },
                { "data": "budgetActivity" },
                { "data": "budgetSubActivity" },
                { "data": "lineNumber" },
                { "data": "liNumber" },
                { "data": "costType" },
                { "data": "py", "searchable": "false" },
                { "data": "cy", "searchable": "false" },
                { "data": "by1Base", "searchable": "false" },
                { "data": "by1OOC", "searchable": "false" },
                { "data": "by1", "searchable": "false" },
                { "data": "by2", "searchable": "false" },
                { "data": "by3", "searchable": "false" },
                { "data": "by4", "searchable": "false" },
                { "data": "by5", "searchable": "false" }
                ]
  });
}