function getExhibitIcons(data, type, full, meta)
{
  var str = "<span style='padding-right:0.5em; padding-left:0.5em'>";
  var testStr=""; 
  var r2LongStr=""; 
  var importedStr=""; 
  var validStr="";
  var errorsStr=""; 
  var allLockedStr=""; 
  var anyLockedStr ="";

  if (full.test)
  {
    testStr =  "<span class='badge-test' title='Test Exhibit' data-toggle='tooltip'>T</span>";
    testStr += "<span style=\"display: none;\">_test</span>";
  } else {
    testStr = "<span style=\"display: none;\">_nottest</span>";
  }
  if (full.r2Long)
  {
    r2LongStr =  "<span class='badge-r2Long' title='R2 Long Format' data-toggle='tooltip'>L</span>";
    r2LongStr += "<span style=\"display: none;\">_r2long</span>";
  } else {
    r2LongStr = "<span style=\"display: none;\">_notr2long</span>";
  }
  if (full.imported)
  {
    importedStr =  "<span class='badge-import' title='Imported Exhibit' data-toggle='tooltip'>I</span>";
    importedStr += "<span style=\"display: none;\">_imported</span>";
  } else {
    importedStr = "<span style=\"display: none;\">_notimported</span>";
  }
  if (full.valid)
  {
    validStr =  "<span class='badge-valid' title='Valid Exhibit' data-toggle='tooltip'>V</span>";
    validStr += "<span style=\"display: none;\">_valid</span>";
  }
  if (full.warningExists)
  {
    validStr =  "<span class='badge-warning' title='Warnings Exist' data-toggle='tooltip'>W</span>";
    validStr += "<span style=\"display: none;\">_warnings</span>";
  }
  if (full.errorExists)
  {
    errorsStr =  "<span class='badge-error' title='Errors Exist' data-toggle='tooltip'>E</span>";
    errorsStr += "<span style=\"display: none;\">_errors</span>";
  }
  if (full.allLocked)
  {
    allLockedStr =  "<img src='images/icon_padlock_blue.png' title='PE Frozen' data-toggle='tooltip'/>";
    allLockedStr +=  "<span style=\"display: none;\">_frozen</span>";
  } else {
    allLockedStr =  "<span style=\"display: none;\">_notfrozen</span>";
  }
  if (full.anyLocked || full.peLocked)
  {
    anyLockedStr =  "<img src='images/icon_padlock.gif' title='Locked' data-toggle='tooltip'/>";
    anyLockedStr +=  "<span style=\"display: none;\">_locked</span>";
  }
  
  return str.concat(testStr, r2LongStr, importedStr,validStr, errorsStr,
      allLockedStr, anyLockedStr,"</span>" );
}

function getExhibitTypeBadges(data, type, full, meta)
{
  var str="";
  var r3ExistsStr="";
  var r4ExistsStr="";
  var r4aExistsStr=""; 
  var r5ExistsStr=""; 
  
  if (full.r3Exists)
  {
    r3ExistsStr = "<span class='badge-exhibit' title='R3 Exists' data-toggle='tooltip'>R3</span>";
    r3ExistsStr += "<span style=\"display: none;\">_r3</span>";
  } else {
    r3ExistsStr = "<span style=\"display: none;\">_notr3</span>";
  }
  if (full.r4Exists)
  {
    r4ExistsStr =  "<span class='badge-exhibit' title='R4 Exists' data-toggle='tooltip'>R4</span>";
    r4ExistsStr += "<span style=\"display: none;\">_r4</span>";
  } else {
    r4ExistsStr = "<span style=\"display: none;\">_notr4</span>";
  }
  if (full.r4aExists)
  {
    r4aExistsStr =  "<span class='badge-exhibit' title='R4A Exists' data-toggle='tooltip'>R4A</span>";
    r4aExistsStr += "<span style=\"display: none;\">_r4a</span>";
  } else {
    r4aExistsStr = "<span style=\"display: none;\">_notr4a</span>";
  }
  if (full.r5Exists)
  {
    r5ExistsStr =  "<span class='badge-exhibit' title='R5 Exists' data-toggle='tooltip'>R5</span>";
    r5ExistsStr += "<span style=\"display: none;\">_r5</span>";
  } else {
    r5ExistsStr = "<span style=\"display: none;\">_notr5</span>";
  }

  return str.concat(r3ExistsStr, r4ExistsStr, r4aExistsStr, 
      r5ExistsStr);
}