var budgetCycleJson;
var controlLinks={};
var originalData;
var r2ControlsErrorList={};
var r2ControlsErrorKey = function(cell){
	return cell.index().row+"|"+cell.index().column;
};

var r2ControlsColumnSizes = {};
var continueRevert = true;

var currentBudgetYear;

const CONTINUING = 'Continuing';

function setCurrentBudgetYear(year){
	currentBudgetYear = year;
}

$.getJSON("/r2/newBudgetCycleJson", function(data) {
	  budgetCycleJson = data;
	});

function setup(links)
{
	controlLinks = links;
}
function pageInit(){
	console.log("Version:"+$.fn.dataTable.version);
	
	var test = 0;
	var budgetYear;
	var editableCellClass;

	var r2ControlsTable = $("#r2ControlsTable").DataTable({
		"order":[[0,'asc']],
		"serverSide": false,
		"stateSave": true,
		"language": {
			"emptyTable": "No results found."
		},
		"ajax":{
			"url":controlLinks.getPeJsonUrl,
			"type": "POST"
		},
		"fnRowCallback": function(row, data, index){
			if (data.edit )
			{
				$(row).addClass("editableRow");
			}
			else if (!data.edit)
			{
				$(row).addClass("viewableRow");
			}
			if (data.locked)
			{
				$(row).addClass("lockedRow");
			}
			if (data.edit && !data.locked)
			{
				editableCellClass = "userEditableCell";
			}
			else
			{
				editableCellClass = "editableCell";
			}
			
			$(row).children(".r2Controls_fundingYears input[type=text]").addClass(editableCellClass);
			$(row).children(".r2Controls_r1num input[type=text]").addClass(editableCellClass);
		},
	    "headerCallback": function(thead, data, start, end, display) {
	    	for (var i=0;i<data.length;i++) {
	    		if(budgetYear==null) {
	    			budgetYear = data[i].budgetYear;
	    		}
	    	}
	    	renderHeaderCells(budgetYear);	    	
	    },
	    "autowidth": false,
	    "sDom": 'B<"H"lfr>t<"F"ip>',
		"buttons" : [{
			"extend" :'colvis',
			"text" : "Columns",
			"columnText" : function(dt, idx, title){
				if(title.indexOf('Agency') != -1){
					return "Agency";
				}
				
				if(title.indexOf('Budget Cycle') != -1){
					return "Budget Cycle";
				}
				
				return title;
			}
		}],
	    "columnDefs": [
	                   {"type":"natural", "targets":[5,6]},
	                  ],
		"columns": [
		            {
		            	"data":"r1LineNumber",
		            	"bSearchable":false,
		            	"orderable":true,
		            	"order": "asc",
		            	"sClass": "r2Controls_r1num",
		            	"visible": true,
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.r1LineNumber, full.locked, full.edit, full,meta.row,0,"r1LineNumber");
		            	},
		            	"defaultContent":""
		            },
		            {
		            	"data":"number",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"sClass": "r2Controls_number",
		            	"visible": true,
	            		"render": function(data, type, full, meta){
		            		var numberCellStr = "<a href='/r2/peeditangular/"+full.id+"'>"+full.number+"</a>";
		            		return numberCellStr.concat(getExhibitIcons(data, type, full, meta));
	            		},
		            	"defaultContent":""
		            },
		            {
		            	"data":null,
		            	"bSearchable":false,
		            	"orderable":false,
		            	"sClass": "r2Controls_exhibitBadges",
		            	"visible": false,
	            		"render": function(data, type, full, meta){
		            		return getExhibitTypeBadges(data, type, full, meta);
		            	},
		            	"defaultContent": "<span>Exhibit Types</span>"
		            },
		            { 
		            	"data": "title",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_title",
		            	"render": function(data,type,full, meta){
		            		var titleStr = full.title;
		            		if ((full.title).length>40){
		            			return '<div data-toggle="tooltip" title="'+titleStr+'">'+(full.title).substr(0,38)+'...</div>';
		            		}
		            		else
		            		{
		            			return '<div data-toggle="tooltip" title="'+full.title+'">'+full.title+'</div>';
		            		}
		            	},
		            	"defaultContent":""
		            },
		            { 
		            	"data": "baNum",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": true,
		            	"sClass": "r2Controls_budgetactivity"
		            },
		            { 
		            	"data": "serviceAgencyCode",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": true,
		            	"sClass": "r2Controls_agency",
		            	"render": function(data, type, full, meta)
		            	{
		            		return "<span data-toggle='tooltip' title='"+full.serviceAgencyName+"'>"+full.serviceAgencyCode+"</span>";
		            	},
		            	"defaultContent":""
		            },
		            { 
		            	"data": "budgetCycle",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_budgetcycle",
		            	"render": function(data, type, full, meta)
		            	{
		            		return full.budgetCycle+" "+full.budgetYear;
		            	},
		            	"defaultContent":""
		            },
		            {
		            	"data": "creatorDisplayName",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_createdby"
		            },
		            {
		            	"data": "formattedDateCreated",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_datecreated"
		            },
		            {
		            	"data": "modifierDisplayName",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_modifiedby"	
		            },
		            {
		            	"data": "formattedDateModified",
		            	"bSearchable":true,
		            	"orderable":true,
		            	"visible": false,
		            	"sClass": "r2Controls_datemodified"
		            },
		            {
		            	"data": "fundingAllPys",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingAllPys, full.locked, full.edit, full,meta.row,11,"fundingAllPys");
		            	},
		            	"defaultContent":""
		            },
		            {
		            	"data": "fundingPy",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingPy, full.locked, full.edit, full, meta.row,12,"fundingPy");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, -2)
		            },
		            {
		            	"data": "fundingCy",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingCy, full.locked, full.edit, full,meta.row,13,"fundingCy");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, -1)
		            },
		            {
		            	"data": "fundingBy1Base",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy1Base, full.locked, full.edit, full, meta.row,14,"fundingBy1Base");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 0) + " Base"
		            },
		            {
		            	"data": "fundingBy1Ooc",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy1Ooc, full.locked, full.edit, full,meta.row,15,"fundingBy1Ooc");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 0) + " OOC"
		            },
		            {
		            	"data": "fundingBy1",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy1, full.locked, full.edit, full, meta.row,16,"fundingBy1");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 0)
		            },
		            {
		            	"data": "fundingBy2",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy2, full.locked, full.edit, full, meta.row,17,"fundingBy2");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 1)
		            },
		            {
		            	"data": "fundingBy3",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy3, full.locked, full.edit, full, meta.row,18,"fundingBy3");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 2)
		            },
		            {
		            	"data": "fundingBy4",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy4, full.locked, full.edit, full,meta.row,19,"fundingBy4");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 3)
		            },
		            {
		            	"data": "fundingBy5",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": true,
		            	"sClass": "r2Controls_fundingYears",
		            	"render": function(data, type, full, meta){
		            		return renderEditableCell(full.fundingBy5, full.locked, full.edit, full, meta.row,20,"fundingBy5");
		            	},
		            	"defaultContent":"",
		            	"title" : getFundingYearStr(currentBudgetYear, 4)
		            },
		            {
		            	"data": "fundingCompCost",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": false,
		            	"sClass": "r2Controls_fundingYears r2Continuing",
		            	"render": function(data, type, full, meta){
		            		return renderContinuingCell(full.fundingCompCost, full.locked, full.edit, true, meta.row,21,"fundingCompCost");
		            	},
		            	"defaultContent":""
		            },
		            {
		            	"data": "fundingTotalCost",
		            	"bSearchable":true,
		            	"orderable":false,
		            	"visible": false,
		            	"sClass": "r2Controls_fundingYears r2Continuing",
		            	"render": function(data, type, full, meta){
		            		return renderContinuingCell(full.fundingTotalCost, full.locked, full.edit, true, meta.row, 22, "fundingTotalCost");
		            	},
		            	"defaultContent":""
		            },
		            {
		            	"data": null,
		            	"bSearchable":false,
		            	"orderable":false,
		            	"visible": false,
		            	"sClass": "r2Controls_fundingYears r2Continuing r2ContinuingCheckbox",
		            	"render": function(data, type, full, meta){
		            		return renderContinuingCell(full.fundingTotalCost, full.locked, full.edit, false, meta.row, "");
		            	},
		            	"defaultContent":""
		            }
		           ]
	});

	$.fn.dataTable.ext.errMode = function (settings, helpPage, message){
		console.log("Datatable error during loading of data: "+message);
		renderServerError("Datatable error during loading of data: "+message,"Server Error");
	}
	
	// render Columns button
	$("#r2ControlsTable_length").after("<button class='cxeButton r2ControlsSave' id='r2ControlsSaveBtn'>Save</button><button class='cxeButton r2ControlsRevert' id='r2ControlsRevertBtn' >Revert</button>");

	//resetting values on auto-renumber modal closing
//	$("#r2modalControlsAutoRenumber").unbind("hide.bs.modal");
//	$("#r2modalControlsAutoRenumber").on("hide.bs.modal", function (e){
//		continueRevert = true;
//	});
//	
	$('#r2ControlsRevertBtn').unbind("click");
	$('#r2ControlsRevertBtn').click(function (e)
	{
		e.preventDefault();
		setTimeout(function(){
			if (continueRevert){
				originalData = null;
				r2ControlsErrorList = {};

				r2ControlsTable.ajax.reload();
				}	
		}, 400);
		
	});
	
	$('#r2ControlsSaveBtn').unbind("click");
	$('#r2ControlsSaveBtn').click(function (e)
	{
		e.preventDefault();
		// This gives the onblur event on the r1 fields a chance to run first
		setTimeout(function(){
				saveButtonHandler(r2ControlsTable);
		} , 400);
	});
	
	$("#service-agency-filter").keypress(function (e) {
		e.stopPropagation();
	});
	$("#service-agency-filter").click(function (e) {
		e.stopPropagation();
	});
	
	$("#service-agency-filter").change(function (e){
		var filterText = $("#service-agency-filter :selected").attr('value');
//		console.log("filterText:"+filterText);
		if (filterText==null || filterText =='undefined'){
			filterText = "";
		}
		e.stopPropagation();
		r2ControlsTable.column(".r2Controls_agency").search(filterText).draw();
	});
	
	r2ControlsTable.on("init.dt", function(e, settings){
		for (var key in r2ControlsColumnSizes)
		{
			if (r2ControlsColumnSizes.hasOwnProperty(key))
			{
				if (r2ControlsColumnSizes[key]!=undefined)
				{
					var columnHeader = r2ControlsTable.column(key).header();
					var columnHeaderId = columnHeader.getAttribute("id");
					$("#"+columnHeaderId).css("width", r2ControlsColumnSizes[key]+"px");
				}
			}
		}

	});

	//post-rendering of data table
	r2ControlsTable.on("draw.dt", function(){
		console.log("@@@@@ done redrawing table");
		
		var displayAutoNumber = true;
		var peListData = r2ControlsTable.data();
		
		if (originalData==null)
		{
			originalData = peListData;
		}
		
		$("#budget-cycle-filter").keypress(function (e){
			e.stopPropagation();
		});
		
		$("#budget-cycle-filter").click(function (e){
			e.stopPropagation();
		});
		
		$("#budget-cycle-filter").change(function (e){
			var filterText = $("#budget-cycle-filter :selected").attr('value');
			filterText = URLEncoder.encode(filterText);
			e.stopPropagation();
			window.location.href = controlLinks.budgetCycleReloadUrl+"/"+filterText;
		});
		
		// add eventhandlers
		addUserEditableCheckboxEventHandler(r2ControlsTable);
		
		addR1NumberEventHandler(r2ControlsTable);
		
		addUserEditableCellEventHandler(r2ControlsTable);
		
		
		var tableState = r2ControlsTable.state();
		var columnsState = tableState.columns;

		// read the table's state to set the checkboxes if it is null set the default values;
		var counter=0;

		$("[id^='r2ColumnCheckbox_']").each(function(){
			var colVisible = columnsState[counter].visible;
			if (colVisible)
			{	
				$(this).prop("checked", "checked");
			}
			counter++;
		});
		
		$('[data-toggle="tooltip"]').tooltip();
	});
};


//---------------
//
//---------------

function addUserEditableCheckboxEventHandler(r2ControlsTable){
	r2ControlsTable.$(".userEditableCell").unbind("blur");
	r2ControlsTable.$(".userEditableCell").on("blur", function(e){
		var field = $(e.target);
		cellUpdateEventHandler(r2ControlsTable,field);
	});
}

function addUserEditableCellEventHandler(r2ControlsTable){
	r2ControlsTable.$(".userEditableCell").unbind("blur");
	r2ControlsTable.$(".userEditableCell").on("blur", function(e){
		var field = $(e.target);
		cellUpdateEventHandler(r2ControlsTable,field);
	});
}


function addR1NumberEventHandler(r2ControlsTable){
	$('#r2ControlsTable').unbind('blur');
	$('#r2ControlsTable').on('blur','.r2Controls_r1num',
			function(e) {
				console.log('r1LineNumber event handler');
				displaySave = false;

				var field = $(e.target);

				var td = field.closest("td");

				var newVal = field.val();
				
				var cell = r2ControlsTable.cell(td);
				
				var rowIndx = cell.index().row;
				
				var colIndx = cell.index().column;
				
				var columnHeader = r2ControlsTable.column(cell.index().column)
						.header();
				
				var columnHeaderId = columnHeader.getAttribute("id");
				
				var peListData = r2ControlsTable.data()

				var oldVal = getEditablePEListDataCell(peListData, rowIndx,
						columnHeaderId);
				
				if (oldVal == null && newVal != null) {
					updateCellData(oldVal, newVal, peListData, rowIndx,
							columnHeaderId, field, cell);
					displaySave = true;
				} 
				
				else {
					if (newVal == oldVal) {
						displaySave = true;
						return false;
					}
					
					field.removeClass("r2FormInputError");
					field.removeClass("r2FormInputModified");
					
					updateCellData(oldVal, newVal, peListData, rowIndx,
							columnHeaderId, field, cell);

					if (newVal == null || newVal == "") {
						displaySave = true;
						return false;
					}
				}

			});
}


function getFundingYearStr(currentYear, delta)
{
	var yr = currentYear + delta;

	return yr.toString();
}


function cellUpdateEventHandler(r2ControlsTable,field)
{
	var peListData = r2ControlsTable.data();
	var td = field.closest("td");
	var cell = r2ControlsTable.cell(td);
	var rowIndx = cell.index().row;
	var colIndx = cell.index().column;
	var visibleColIndx  = td.closest("tr").children().index(td);
	
	var columnHeader = r2ControlsTable.column(cell.index().column).header();
	
	var columnHeaderId = columnHeader.getAttribute("id");
	var newVal = field.val();
	var oldVal = getEditablePEListDataCell(peListData, rowIndx, columnHeaderId);
	
	updateCellData(oldVal, newVal, peListData, rowIndx, columnHeaderId, field, cell);
}

function renderHeaderCells(budgetYear)
{	
	if (budgetYear!=null){
		$("[id^='r2Controls_fundingYear']").not("[id='r2Controls_fundingYearPriors'],[id='r2Controls_fundingYearTC'],[id='r2Controls_fundingYearTotal'],[id='r2Controls_fundingYearContinuing']").each(function(){
			$(this).empty();
		});
		
    	$("#r2Controls_fundingYearMinus2").append(getFundingYearStr(budgetYear, -2));
		$("#r2Controls_fundingYearMinus1").append(getFundingYearStr(budgetYear, -1));
		$("#r2Controls_fundingYearBase").append(budgetYear+" Base");
		$("#r2Controls_fundingYearOOC").append(budgetYear+" OOC");
		$("#r2Controls_fundingYearPlus1").append(budgetYear);
		$("#r2Controls_fundingYearPlus2").append(getFundingYearStr(budgetYear, 1));
		$("#r2Controls_fundingYearPlus3").append(getFundingYearStr(budgetYear, 2));
		$("#r2Controls_fundingYearPlus4").append(getFundingYearStr(budgetYear, 3));
		$("#r2Controls_fundingYearPlus5").append(getFundingYearStr(budgetYear, 4));
		
		$("[id^='r2ColumnCheckbox_']").each(function(){
			$(this).parent().children("span").remove();
		});
		
		$("#r2ColumnCheckbox_fundingYearMinus2").parent().append('<span>'+getFundingYearStr(budgetYear, -2)+'</span>');
		$("#r2ColumnCheckbox_fundingYearMinus1").parent().append('<span>'+getFundingYearStr(budgetYear, -1)+'</span>');
		$("#r2ColumnCheckbox_fundingYearBase").parent().append('<span>'+budgetYear+" Base"+'</span>');
		$("#r2ColumnCheckbox_fundingYearOOC").parent().append('<span>'+budgetYear+" OOC"+'</span>');
		$("#r2ColumnCheckbox_fundingYearPlus1").parent().append('<span>'+budgetYear+'</span>');
		$("#r2ColumnCheckbox_fundingYearPlus2").parent().append('<span>'+getFundingYearStr(budgetYear, 1)+'</span>');
		$("#r2ColumnCheckbox_fundingYearPlus3").parent().append('<span>'+getFundingYearStr(budgetYear, 2)+'</span>');
		$("#r2ColumnCheckbox_fundingYearPlus4").parent().append('<span>'+getFundingYearStr(budgetYear, 3)+'</span>');
		$("#r2ColumnCheckbox_fundingYearPlus5").parent().append('<span>'+getFundingYearStr(budgetYear, 4)+'</span>');
	}
}


function renderEditableCell(val, locked, edit, rowData, rowIndex, colIndx,dataAttributeName)
{
	
	if (!locked && edit)
	{
		var width = 64;
		if (val!=null){
			width=( (val.length+3) *8);
		}

		var cssClassStr = "";
		
		if (originalData!=null)
		{
			var orgVal = originalData[rowIndex][dataAttributeName];
			
			if (orgVal!=val)
			{

				cssClassStr +=" r2FormInputModified";
			}
			
		}
		if (val==null)
		{
			val = "";
		}
		if (dataAttributeName=='r1LineNumber')
		{
			return "<input type='text' class='"+cssClassStr+" r1LineNumber' value='"+val+"' maxlength='10' /><span style='display:none'>"+val+"</span>";
		}
		else
		{
			return "<input type='text' class='"+cssClassStr+" userEditableCell' value='"+val+"' />";
		}
	}
	else
	{
		
		return val;
	}
}

function renderContinuingCell(val, locked, edit, isTextfield, rowIndex, colIndex, dataAttributeName )
{
	
	if (!locked && edit)
	{
		if (isTextfield )
		{
			var width = 90;
			var str =  "<input type='text' ";
			var cssClassStr = "userEditableCell";
			var styleStr = "";
			
			// check against original to style
			if (originalData!=null)
			{
				var orgVal = originalData[rowIndex][dataAttributeName];
				
				if (orgVal!=val)
				{	
					cssClassStr +=" r2FormInputModified"; 
				}
				
			}
			
			if (val=="Continuing" && isTextfield)
			{
				str+= " disabled='true'";
				
			}
			
			if (val==null)
			{
				val = "";
			}
			return str+= " class='"+cssClassStr+"' value='"+val+"' />";
			
		}
		else if (val=="Continuing"  && !isTextfield)
		{
			return "<input type='checkbox' class='userEditableCheckbox' value='Continuing' checked='checked' />";
		}
		else if ($.isNumeric(val) && !isTextfield)
		{
			return "<input type='checkbox' class='userEditableCheckbox' value='Continuing' />";
		}
	}
	else
	{
		if (isTextfield)
		{
			return val;	
		}
		else if (!isTextfield && val=="Continuing")
		{
			return "<input type='checkbox' class='userEditableCheckbox' value='Continuing' checked='checked' disabled='true'/>";
		}
		else if (!isTextfield)
		{
			return "<input type='checkbox' class='userEditableCheckbox' value='Continuing' disabled='true'/>";
		}
	}
}

function getEditablePEListDataCell(peListData, rowIndx, columnHeaderId)
{
	if (columnHeaderId=="r2Controls_fundingYearPriors")
	{
		return peListData[rowIndx].fundingAllPys;
	}
	else if(columnHeaderId=="r2Controls_fundingYearMinus2")
	{
		return peListData[rowIndx].fundingPy
	}
	else if (columnHeaderId=="r2Controls_fundingYearMinus1")
	{
		return peListData[rowIndx].fundingCy
	}
	else if (columnHeaderId=="r2Controls_fundingYearBase")
	{
		return peListData[rowIndx].fundingBy1Base;
	}
	else if (columnHeaderId=="r2Controls_fundingYearOOC")
	{
		return peListData[rowIndx].fundingBy1Ooc;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus1")
	{
		return peListData[rowIndx].fundingBy1;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus2")
	{
		return peListData[rowIndx].fundingBy2;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus3")
	{
		return peListData[rowIndx].fundingBy3;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus4")
	{
		return peListData[rowIndx].fundingBy4;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus5")
	{
		return peListData[rowIndx].fundingBy5;
	}
	else if (columnHeaderId=="r2Controls_fundingYearTC")
	{
		return peListData[rowIndx].fundingCompCost;
	}
	else if (columnHeaderId=="r2Controls_fundingYearTotal")
	{
		return peListData[rowIndx].fundingTotalCost;
	}
	else if (columnHeaderId=="r2Controls_r1num")
	{
		return peListData[rowIndx].r1LineNumber;
	}
}

function setEditablePEListDataCell(peListData, rowIndx, columnHeaderId, val)
{
	if (columnHeaderId=="r2Controls_fundingYearPriors")
	{
		peListData[rowIndx].fundingAllPys = val;
	}
	else if(columnHeaderId=="r2Controls_fundingYearMinus2")
	{
		 peListData[rowIndx].fundingPy = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearMinus1")
	{
		 peListData[rowIndx].fundingCy = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearBase")
	{
		 peListData[rowIndx].fundingBy1Base = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearOOC")
	{
		 peListData[rowIndx].fundingBy1Ooc = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus1")
	{
		 peListData[rowIndx].fundingBy1 = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus2")
	{
		 peListData[rowIndx].fundingBy2 = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus3")
	{
		 peListData[rowIndx].fundingBy3 = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus4")
	{
		 peListData[rowIndx].fundingBy4 = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearPlus5")
	{
		 peListData[rowIndx].fundingBy5 = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearTC")
	{
		 peListData[rowIndx].fundingCompCost = val;
	}
	else if (columnHeaderId=="r2Controls_fundingYearTotal")
	{
		 peListData[rowIndx].fundingTotalCost = val;
	}
	else if (columnHeaderId=="r2Controls_r1num")
	{
		 peListData[rowIndx].r1LineNumber = val;
	}
}

function continuingCheckboxHandler(r2ControlsTable, field)
{
	var peListData = r2ControlsTable.data();
	var td = field.closest("td");
	var cell = r2ControlsTable.cell(td);
	var rowIndx = cell.index().row;
	var colIndx = cell.index().column;
	var visibleColIndx = r2ControlsTable.column.index('toVisible', colIndx);

	var columnHeader = r2ControlsTable.column(cell.index().column).header();
	var columnHeaderId = columnHeader.getAttribute("id");	
	var checked = field.is(":checked");
	
	// Total Column
	if (r2ControlsTable.column(colIndx-1).visible())
	{
		var totalCellVisibleIndx = r2ControlsTable.column.index('toVisible', colIndx-1);
		updateVisibleTotalOrTCCell(r2ControlsTable, td, checked, rowIndx, columnHeaderId, 'fundingTotalCost', totalCellVisibleIndx, peListData)
		
	}
	else
	{ 
		updateHiddenTotalOrTCCell(r2ControlsTable, checked, rowIndx, colIndx-1, 'fundingTotalCost',  peListData);
	}
	
	// TC column
	if (r2ControlsTable.column(colIndx-2).visible())
	{
		var tcCellVisibleIndx = r2ControlsTable.column.index('toVisible', colIndx-2);
		updateVisibleTotalOrTCCell(r2ControlsTable,td, checked, rowIndx, columnHeaderId, 'fundingCompCost', tcCellVisibleIndx, peListData)
	}
	else		
	{
		updateHiddenTotalOrTCCell(r2ControlsTable, checked, rowIndx, colIndx-2, 'fundingCompCost',  peListData);
	}
	
}

function updateVisibleTotalOrTCCell(r2ControlsTable, checkboxTd,checked, rowIndx,columnHeaderId, jsonAttributeName, visibleColIndx, peListData)
{
	var td = checkboxTd.closest("tr").children().eq(visibleColIndx);
	var newVal = "";
//	var borderStyle = "dashed";
	var newWidth = "48";
	
	td.children("input").removeClass("r2FormInputModified");
	td.children("input").removeClass("r2FormInputError");
	
	if (checked)
	{
		newVal = CONTINUING;
		td.children('input').val(newVal);
		td.children("input").prop("disabled", true);
		peListData[rowIndx].continuing = true;
		var orgVal = originalData[rowIndx][jsonAttributeName];
		var peData = peListData[rowIndx][jsonAttributeName];
		
		if (orgVal!=CONTINUING)
		{
			td.children("input").addClass("r2FormInputModified");
		}
		
	}
	else
	{
		var orgVal = originalData[rowIndx][jsonAttributeName];
		var peData = peListData[rowIndx][jsonAttributeName];
		var peDataCont = peListData[rowIndx].continuing;
		peListData[rowIndx].continuing = false;
		td.children("input").addClass("r2FormInputModified");
		
		if ( (orgVal==CONTINUING && peData==CONTINUING) )
		{
			newVal = "";
		}
		else if (orgVal==CONTINUING && peData!=CONTINUING)
		{
			newVal = peData;
		}
		else if (orgVal==peData)
		{
			newVal = peData;
			td.children("input").addClass("r2FormInputModified");
		}
		else if (orgVal!=peData && peData==CONTINUING)
		{
			newVal = "";		
		}
		else if (orgVal!=peData && peData!=CONTINUING )
		{
			newVal = peData;
		}
		
		td.children("input").prop("disabled", false);
		td.children('input').val(newVal);
		//ugh got to validate on view too...
		
		if( !$.isNumeric(newVal) &&  newVal!="")
		{
			td.children("input").addClass("r2FormInputError");
			td.children("input").removeClass("r2FormInputModified");
			
		}
		td.children("input").on("blur", function(e){
			var field = $(e.target);
			cellUpdateEventHandler(r2ControlsTable,field);
		});
	}
	
}

function updateHiddenTotalOrTCCell(r2ControlsTable, checked, rowIndx, colIndx, jsonAttributeName,  peListData)
{
	
	var newVal = "";
	var newWidth = "48";
	
	if (checked)
	{
		newVal = CONTINUING;
		peListData[rowIndx].continuing = true;
		var orgVal = originalData[rowIndx][jsonAttributeName];
		var peData = peListData[rowIndx][jsonAttributeName];
		
		r2ControlsTable.cell(rowIndx,colIndx ).data(newVal);
		removeFromErrors(r2ControlsTable.cell(rowIndx,colIndx));
	}
	else
	{
		var orgVal = originalData[rowIndx][jsonAttributeName];
		var peData = peListData[rowIndx][jsonAttributeName];
		var peDataCont = peListData[rowIndx].continuing;
		peListData[rowIndx].continuing = false;
		
		if ( (orgVal==CONTINUING && peData==CONTINUING) )
		{
			newVal = "";
			
		}
		else if (orgVal==CONTINUING && peData!=CONTINUING)
		{
			newVal = peData;
			
		}
		else if (orgVal==peData)
		{
			newVal = peData;	
		}
		else if (orgVal!=peData && peData==CONTINUING)
		{
			newVal = "";
		}
		else if (orgVal!=peData && peData!=CONTINUING )
		{
			newVal = peData;
		}
		r2ControlsTable.cell(rowIndx,colIndx ).data(newVal);
	}
	
}


function updateCellData(oldVal, newVal, peListData, rowIndx, columnHeaderId, field, cell)
{ 
	if (newVal!==oldVal)
	{
//		$('#r2ControlsSaveBtn').prop('disabled', false);	
//		$('#r2ControlsRevertBtn').prop('disabled', false);
		console.log('update cell data');
		var width = 32;
		field.removeClass("r2FormInputModified");
		field.removeClass("r2FormInputError");
		if (newVal==null || newVal=="")
		{
			if (oldVal!=null)
			{
				setEditablePEListDataCell(peListData, rowIndx, columnHeaderId, "");
				field.addClass("r2FormInputModified");
			}
			removeFromErrors(cell);
		}
		else if( $.isNumeric(newVal))
		{
			// set value in json object
			if (columnHeaderId=="r2Controls_r1num")
			{
				field.val(newVal);
				setEditablePEListDataCell(peListData, rowIndx, columnHeaderId, newVal);
				width=((newVal.length+3) *8);
				// add to the span
				field.siblings("span").empty();
				field.siblings("span").append(newVal);
			}
			else
			{
				var formattedVal = parseFloat(newVal).toFixed(3);
				field.val(formattedVal);
//				console.log(formattedVal+" length:"+formattedVal.length);
				setEditablePEListDataCell(peListData, rowIndx, columnHeaderId, formattedVal);
				width=((formattedVal.length+3) *8);
			}
			removeFromErrors(cell);
			field.addClass("r2FormInputModified");
		}
		else
		{
//			console.log("invalid input");
			width=( (newVal.length+3) *8);
			addToErrors(cell);
			setEditablePEListDataCell(peListData, rowIndx, columnHeaderId, newVal);
			field.addClass("r2FormInputError");
		}
		var column = $("#"+columnHeaderId);
		var oldColWidthStr = column.css("width");
		if (oldColWidthStr!='undefined')
		{
			var oldColWidth = oldColWidthStr.substr(0, oldColWidthStr.length-2);
			var newWidth = width-10;
//			console.log("new width:"+newWidth+" , oldwidth:"+oldColWidth);
			if (newWidth>oldColWidth){
				column.css({"width":newWidth+"px"});
//				console.log("resize col: "+newWidth);
			}
			field.css({'width':width+"px"});
		}
		
	}
}

function saveButtonHandler(r2ControlsTable)
{
	console.log("saving....");
	if (validationErrorsExist())
	{
		console.log("Errors found.");
		$("#r2modalControlsSaveErrors").modal();
		return;
	}
	
	$("#r2modalProgress").modal('show');
	
	var peListData = r2ControlsTable.data();
	var rows = [];
	peListData.each(function (row)
	{
		if (row.continuing)
		{
			row.fundingCompCost = CONTINUING;
			row.fundingTotalCost = CONTINUING;
		}
		rows.push(row);
	});
//	console.log(JSON.stringify(rows));
	var formVals = {"tabledata":JSON.stringify(rows)};
//	console.log(JSON.stringify(peListData));
	
//	console.log("posting...."+controlLinks.saveUrl);
	 $.ajax({
	        url:controlLinks.saveUrl,
	        type: "POST",
	        data: formVals,
	        dataType: "json",
	        success:   function(response) {
	        	var responseStr = JSON.stringify(response);
//	        	console.log(responseStr);
	        	$("#r2modalProgress").modal('hide');
	        	renderServerResponse(response,"Saved Control Numbers");
//	        	$('#r2ControlsSaveBtn').prop('disabled', true);	
//	        	$('#r2ControlsRevertBtn').prop('disabled', true);
	        	originalData=null;
	        	r2ControlsErrorList = {};
	        	r2ControlsTable.ajax.reload();

	        },
	        error:   function(response) {
	        	var responseStr = JSON.stringify(response);
//	        	console.log(responseStr);
	        	$("#r2modalProgress").modal('hide');
	        	renderServerResponse(response,"Save Control Numbers");
	        	originalData=null;
	        	r2ControlsErrorList = {};
	        	r2ControlsTable.ajax.reload();
	        }
	});
}

function renderServerResponse(response, responseHeader)
{
	var $header = $("#r2modalEndpointResponseHeader");
	$header.empty();
	$header.append(responseHeader);
	var $successMessage = $("#successMessage");
	var $errorMessage = $("#errorMessage");
	$successMessage.empty();
	$errorMessage.empty();
	$errorMessage.hide();
	$successMessage.hide();
	
	if (typeof response.successMessages!='undefined' && response.successMessages.length>0)
	{
		
		var successStr = "<h4>Success</h4><ul>";
		for (var j=0;j<response.successMessages.length;j++)
		{
			successStr+="<li>"+response.successMessages[j].message+"</li>";
		}
		successStr+="</ul>";
		$successMessage.append(successStr);
		$successMessage.show();
//		console.log(successStr);
	}
	if (typeof response.errorMessages!='undefined' && response.errorMessages.length>0)
	{
		var errHtml = "<h4>Failed</h4><ul>";
		for (var i=0; i<response.errorMessages.length; i++)
		{
			errHtml+="<li>"+response.errorMessages[i].message+"</li>";
		}
		errHtml+="</ul>";
		$errorMessage.append(errHtml);
		$errorMessage.show();
	}
	$("#r2modalEndpointResponse").modal();
}

function autorenumberHandler(peId, newVal, r2ControlsTable)
{
//	console.log("peId:"+ peId+", newVal:"+newVal);
	$("#r2modalProgress").modal('show');
	var peListData = r2ControlsTable.data();
	var rows = [];
	peListData.each(function (row)
	{
		if (row.continuing)
		{
			row.fundingCompCost = CONTINUING;
			row.fundingTotalCost = CONTINUING;
		}
		rows.push(row);
	});
	
	
//	console.log(JSON.stringify(rows));
	var formVals = {
			"tabledata":JSON.stringify(rows),
			"updateid": peId,
			"updateval":newVal};
	
//	console.log("posting...."+controlLinks.updateUrl);
	
	 $.ajax({
	        url:controlLinks.updateUrl,
	        type: "POST",
	        data: formVals,
	        dataType: "json",
	        success:   function(response) {
	        	var responseStr = JSON.stringify(response);
//	        	console.log(responseStr);
	        	$("#r2modalProgress").modal('hide');
	        	renderServerResponse(response,"Updated Control Numbers");
	        	r2ControlsTable.ajax.url(controlLinks.getRenumberedPeJsonUrl).load();
	        	//reset to original url
	        	r2ControlsTable.ajax.url(controlLinks.getPeJsonUrl);
	        },
	        error: function (response) {
	        	$("#r2modalProgress").modal('hide');
	        	renderServerResponse(response,"Update Control Numbers");
	        }
	});
	
}

function addToErrors(cell)
{
	if (r2ControlsErrorList[r2ControlsErrorKey(cell)]==undefined)
	{
		r2ControlsErrorList[r2ControlsErrorKey(cell)] = cell;
	}
}

function removeFromErrors(cell)
{
	if (r2ControlsErrorList[r2ControlsErrorKey(cell)]!=undefined)
	{
		r2ControlsErrorList[r2ControlsErrorKey(cell)] = undefined;
	}
}

function validationErrorsExist()
{
	for (var key in r2ControlsErrorList)
	{
		if (r2ControlsErrorList.hasOwnProperty(key))
		{
			if (r2ControlsErrorList[key]!=undefined)
			{
				return true;
			}
		}
	}
	return false;
}
