var userTableUrl = "";
var updateLdapURL = "";
var PeEditURL = "";
var addUserURL = "";
var deleteUserURL = "";
var newAdminUsersLinks;
var currentUserRole = "";
var controller = "";
var inModifyMode = false;
var initialDataStateList = [];

const CSV_BUTTON = "csv";

//called byNewAdminUsers.java afterRender()
function setLinkUrls(urlJson) {
  userTableUrl = urlJson.getUserTableUrl;
  updateLdapURL = urlJson.updateFromLdapURL;
  PeEditURL = urlJson.editPePrivUrl;
  addUserURL = urlJson.addUserURL;
  deleteUserURL = urlJson.deleteUserUrl;
  controller = urlJson.controller;
}

function setViewMode() {
  inModifyMode = false;
  $(".modifyModeOnly").hide();
  $(".viewModeOnly").show();
}

function setModifyMode() {
	  inModifyMode = true;
	  $(".modifyModeOnly").show();
	  $(".viewModeOnly").hide();
}

function setResponseModalMessages(headerText, messages) {
	  console.log(JSON.stringify(messages));
	  $("#r2modalHeader").text(headerText);
	  var msgList = $("#errorMessagesList");
	  msgList.empty();

	  for (var i=0; i<messages.length; i++) {
	    msgList.append("<li>" + messages[i] + "</li>");
	  }

	  $("#errorMessagesModal").modal();
}
	
// Function that creates the configuration object for use by the datatables buttons extension
function getButtonConfig(buttonTypes) {
	let defaultConfig = [];
	
  // Iterate over the array of button types that are passed in and call the appropriate configuration function
	buttonTypes.forEach(function(buttonType){
	switch (buttonType) {
		case CSV_BUTTON:
			defaultConfig.push(getCsvButtonConfig());
			break;
		default:
			break;
		}
	})
	
	return defaultConfig;
}

function getCsvButtonConfig() {
	if (controller === "R2AppMgr") {
		return {				
			"extend" :'csv',     
			"text" : "Download CSV",
			"fieldSeparator" : ",",
			"extension" : ".csv",
			"exportOptions" : {"columns" : [0,1,2,3,4,5,6]}
		}
	}
}

//called byNewAdminUsers.java afterRender()
function pageInit(){
  var newAdminUserTable = $("#manageUsersTable").DataTable({
    "autoWidth" : true,
    "serverSide" : false,
    "stateSave" : true,
    "language" : {"emptyTable" : "No results found."},
    "deferRender" : true,
    "ajax" : {
      "url" : userTableUrl,
      "type" : "POST"
    },
    "sDom": 'B<"H"lfr>t<"F"ip>',
		"buttons" : getButtonConfig([CSV_BUTTON]),
    "columns" : [{
      "data" : "userLdapId",
      "visible" : true,
      "searchable" : true,
      "sortable" : true,
      "title" : "User LDAP ID",
      "render" : function(data, type, full, meta) { // TODO add link to user profile page once it's implemented
        return data;
      }
    }, {
      "data" : "firstName",
      "searchable" : true,
      "sortable" : true,
      "title" : "First Name"
    }, {
      "data" : "lastName",
      "searchable" : true,
      "sortable" : true,
      "title" : "Last Name"
    }, {
      "data" : "email",
      "searchable" : true,
      "sortable" : true,
      "title" : "Email",
      "sClass" : "user_email",
      "width" : "15%",
      "render" : function(data, type, full, meta) {
        var emailAddress = full.email;
                	  
        return '<span data-toggle="tooltip" title="'+emailAddress+'">'+emailAddress+'</span>';
      },
      "defaultContent":""
    }, {
      "data" : "agencies",
      "searchable" : true,
      "sortable" : true,
      "title" : "Agencies",
      "sClass" : "userListAgencies",
      "render" : function(data, type, full, meta) {
        if (full.role == "R2AppMgr" || full.role == "R2Analyst" ||full.role == "R2OmbAnalyst") {
          return "<span align='center'>N/A</span>";
        }
        else {
          return data.join(",");	  
        }
      },
      "defaultContent" : ""
    }, {
      "data" : "role",
      "searchable" : true,
      "sortable" : true,
      "title" : "Role",
      "render" : function(data, type, full, meta) {
        if (data === "R2AppMgr") {
          return "<span>App Manager</span>";
        }
        else if (data === "R2SiteAdmin") {
          return "<span>Site Admin</span>";
        }
        else if (data === "R2LocalSiteAdmin") {
          return "<span>Local Site Admin</span>";
        }
        else if (data === "R2User") {
          return "<span>User</span>";
        }
        else if (data === "R2Analyst") {
          return "<span>OSD Analyst</span>";
        }
        else if (data === "R2OmbAnalyst") {
          return "<span>OMB Examiner</span>";
        }
        else {
          return "<span>No R2 group in LDAP</span>";
        }
      }
    }, {
      "data" : "createPeAllowed",
      "width" : "7%",
      "searchable" : true,
      "sortable" : true,
      "title" : "PE Creator",
      "render" : function(data, type, full, meta) {
        if (data) {
          if (full.role == "R2AppMgr" || full.role == "R2SiteAdmin" || full.role == "R2Analyst" || full.role == "R2OmbAnalyst") {
            return "<span align='center'>N/A</span>";
          }

          return "<span align='center'>Yes</span>";
        } 
        else {
          if (full.role == "R2AppMgr" || full.role == "R2SiteAdmin" || full.role == "R2Analyst" || full.role == "R2OmbAnalyst") {
            return "<span align='center'>N/A</span>";
          }

          return "<span align='center'>No</span>";
        }
      }
    }, {
      "data" : "createLiAllowed",
      "searchable" : true,
      "sortable" : true,
      "width" : "7%",
      "title" : "LI Creator",
      "render" : function(data, type, full, meta) {
        if (data) {
          if (full.role == "R2AppMgr" || full.role == "R2SiteAdmin" || full.role == "R2Analyst" || full.role == "R2OmbAnalyst") {
            return "<span align='center'>N/A</span>";
          }
          
          return "<span align='center'>Yes</span>";
        } 
        else {
          if (full.role == "R2AppMgr" || full.role == "R2SiteAdmin" || full.role == "R2Analyst" || full.role == "R2OmbAnalyst") {
            return "<span align='center'>N/A</span>";
          }
          
          return "<span align='center'>No</span>";
        }
      }
    }, {
      "title" : "Actions",
      "name"  : "actions",
      "width" : "13%",
      "searchable" : false,
      "sortable" : false,
      "render" : function(data, type, full, meta) {
        if (full.role == "R2User") {
          return "<span><button class ='cxeButton deleteButton'id='delete"+full.userLdapId+"' value='"+meta.row+"'><span>Delete</span></button></span" +
            "<span><button class ='cxeButton editButton' id='edit"+full.userLdapId+"'value='"+meta.row+"'><span>Edit</span></button></span>" +
            "<span><button class ='cxeButton roleButton' id='role"+full.userLdapId+"'value='"+meta.row+"'><span>Role</span></button></span>"
        }
        else if (full.role == "R2SiteAdmin" || full.role == "R2LocalSiteAdmin") {
          return "<span><button class ='cxeButton editButton'id='edit"+full.userLdapId+"'value='"+meta.row+"'><span>Edit</span></button></span>";
        }
        else if (full.role == "R2AppMgr" || full.role == "R2Analyst"|| full.role == "R2OmbAnalyst") {
          return "<span><button class ='cxeButton deleteButton'id='delete"+full.userLdapId+"' value='"+meta.row+"'><span>Delete</span></button></span" +
            "<span><button class ='cxeButton roleButton' id='role"+full.userLdapId+"'value='"+meta.row+"'><span>Role</span></button></span>"
        }
        else {
          return "<span>&nbsp;</span>";
        }
      }
    }]
  });
  
  function setCheckBoxState(checkbox) {
    var rowIndex = checkbox.val();
    var row = newAdminUserTable.data()[rowIndex];
    row.createPeAllowed = checkbox.prop("checked");
    console.log(JSON.stringify(row));
                
    if (row.createPeAllowed) {
      checkbox.closest("td").find(".newAdminUserText").addClass("text-success");
      checkbox.closest("td").find(".newAdminUserText").removeClass("text-danger");
      checkbox.closest("td").find(".newAdminUserText").text("Yes");
    } 
    else {
      checkbox.closest("td").find(".newAdminUserText").removeClass("text-success");
      checkbox.closest("td").find(".newAdminUserText").addClass("text-danger");
      checkbox.closest("td").find(".newAdminUserText").text("No");
    }
  }
  
  function roleButtonClicked(roleButton) {
	  var rowValue = roleButton.value;
	  var row = newAdminUserTable.data()[roleButton.value];
	  window.location.href='/r2/userRole/userRoleEditor/'+row.userLdapId+'';
  }

  function editButtonClicked(editButton) {
    var rowValue = editButton.value;
    var row = newAdminUserTable.data()[editButton.value];
    window.location.href='/r2/newEditUsers/manageUsers/'+row.userLdapId+'';
  }
  
  function deleteButtonClicked(deleteButton) {
    console.log("delete this user: ");
    var userId = newAdminUserTable.data()[deleteButton.value].userLdapId;
    console.log(userId);

    $.ajax({
      url: deleteUserURL + "/" + userId,
      data:userId,
      type:"GET",
      success:function(response){
        console.log(response);

        if (response.successMessages) {
          newAdminUserTable.ajax.reload();
          setResponseModalMessages("Success", response.successMessages);
        } 
        else if(response.errorMessages) {
          setResponseModalMessages("Error", response.errorMessages);
        }
      },
      error:function() {
        console.log("error reciving data from backend"); 
        setResponseModalMessages("Failure", ["An error occured while deleting the user"]);
      }
    })
  }
  
  function resetButtonClicked() {
    $.each(initialDataStateList, function(entry) {
      var initialCanCreate = this.canCreate;
      var LdapId = this.LdapId;
      var checkbox = $("#" + LdapId + "canCreate");

      if (checkbox.length) {
        checkbox.prop("checked", initialCanCreate);
        setCheckBoxState(checkbox); 
      }
    });
  }
  
  newAdminUserTable.on('draw.dt', function() {
    if (inModifyMode) {
      setModifyMode();
    } 
    else {
    	setViewMode();
    }
    
    $(".canCreatePeCheckbox").on("click",function() {
      setCheckBoxState($(this));
    });
    
    $(".deleteButton").on("click",function() {
		  $("#r2DeleteModalHeader").text("Warning");
		  $("#deleteMessagesList").find("li").text("Are you sure you want to delete this user?");
		  $("#deleteModal").modal();
		  var deleteButton = this;
		  $("#modalDelete").unbind('click');
		  $("#modalDelete").on("click",function() {
			deleteButtonClicked(deleteButton);
			console.log("modal delete clicked");
		  });
    });
    
    $(".editButton").on("click",function() {
      editButtonClicked(this);
    });
    
    $(".roleButton").on("click",function() {
        roleButtonClicked(this);
      });
  });

  $("#resetPeButton").on("click",function() {
    resetButtonClicked();
  });
  
  $("#cancelPeBtn").on("click",function() {
    console.log("cancel clicked");
    resetButtonClicked();
    setViewMode();
  });
  
  $("#savePeBtn").on("click", function() {
    console.log("save button clicked");
    var tableRows = newAdminUserTable.rows().data();
    initialDataStateList = [];
    $.each(tableRows, function(row) {
      initialDataStateList.push({"LdapId":this.userLdapId, "canCreate":this.createPeAllowed});
    });
    var jsonObj = {"json":JSON.stringify(initialDataStateList)};
    
    $.ajax({
      url: PeEditURL, 
      type:"POST",
      data:jsonObj,
      success: function(response) {
        console.log(JSON.stringify(response));
      },
      error: function() {
        console.log("error hitting backend")
      }
    });

    setViewMode();
  });
  
  function setInitialDataState() {
    var tableRows = newAdminUserTable.rows().data();
    initialDataStateList = [];
    $.each(tableRows, function(row){
      initialDataStateList.push({"LdapId":this.userLdapId, "canCreate":this.createPeAllowed});
    });
    console.log("initial state: "+JSON.stringify(initialDataStateList));
  }
  
  $("#editPeButton").on("click", function() {
    setModifyMode();
    setInitialDataState();
  });
  
  $("#updateUserLdapIDBtn").on("click", function() {
	  $.ajax({
	    url: updateLdapURL, 
	    type:"GET",
	    success: function(response){
	    	newAdminUserTable.ajax.reload();

	      if (response.successMessages) {
	       	setResponseModalMessages("Success", response.successMessages);
	      }

	      if (response.errorMessages){
	    	  setResponseModalMessages("Failure", response.errorMessages); 
	      }
	    },
	    error: function() {
	    	console.log("error hitting backend")
	    }
	  })
	});

  $("#addUserLdapIdBtn").on("click", function() {
    var input = $("#UserLdapIdToAdd").val();
    console.log("add User button clicked: " + input);

    if (input.length != 0) {
      var jsonObj = {"json":input};

      $.ajax({
        url: addUserURL + "/" + input, 
        type:"GET",
        success: function(response) {
          console.log(JSON.stringify(response));
          // The response messages must be in an  ["text"] to display correctly
          if (response.successMessages) {
            newAdminUserTable.ajax.reload();
            setResponseModalMessages("Success", response.successMessages);
            $("#UserLdapIdToAdd").val("");
          }
          
          if(response.errorMessages) {
            console.log(response.errorMessages);
            setResponseModalMessages("Failure", response.errorMessages);
          }
        },
        error: function() {
          console.log("error hitting backend")
        }
      });
    }
    else {
      console.log("enter a valid ldap id");
    }
  });
  
  setViewMode();
};