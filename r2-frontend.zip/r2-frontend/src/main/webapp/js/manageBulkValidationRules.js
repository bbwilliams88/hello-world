function setup(){
	$('#processStatusId').hide();
	$('select').val(0);
}

function execute(){
	$('#processStatusId').show();
	$('#processMsg').css({'font-weight':'bold','font-size':'small','color':'blue'});
	$('#textarea').val("Processing underway, please wait.....");
}
