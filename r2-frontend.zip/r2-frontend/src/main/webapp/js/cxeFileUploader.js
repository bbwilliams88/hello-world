(function(){
  
  
  var previewTemplate= "<div class='cxeFileUploadPreview'>Success</div>";
  var fileZoneTemplate = "<div class='filezone'></div>"
  
  var CxeFileUploader;
  CxeFileUploader = (function(uploadZone){
    
    var uploadAddFile = uploadZone.find(".cxeFileUploadAddFile");
    var uploadInput = uploadZone.find(".cxeFileUploadInput");
    var uploadSubmit = uploadZone.find(".cxeFileUploadSubmit");
    var fileZone;
    var _this = this;
    
    CxeFileUploader.prototype.init = function() {
      uploadAddFile.unbind("click");
      uploadAddFile.on("click", function() {
        console.log("show file chooser 2");
        console.log(uploadInput);
        uploadInput.click();
      });
      
      uploadInput.unbind("change");
      uploadInput.on("change", function(){
        var file = $(this)[0].files[0];
        _this.addFile($(this)[0].files);
        uploadSubmit.click();
        return;
      });  
      uploadZone.append(fileZoneTemplate);
      fileZone = uploadZone.find(".filezone");
    }
   
    CxeFileUploader.prototype.addFile = function(files) {
      console.log(fileZone);
      
      for (var i=0; i<files.length; i++){
        fileZone.append('<span>'+files[i].name+" "+files[i].size+'</span>');
      }
    }
    
    
    this.init();
  });
  
  $(".cxeFileUploadZone").each(function() {
    new CxeFileUploader($(this));
  });
  
}).call(this);




