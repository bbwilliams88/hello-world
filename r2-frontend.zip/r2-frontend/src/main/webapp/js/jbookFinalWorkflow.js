function setup(){
	if ($('#final').prop("checked")){
		showFinal();
	}
	else{
		hideFinal();
	}
}

function showFinal(){
	$('#finalJBook').show();
}

function hideFinal(){
	$('#finalJBook').hide();
}
