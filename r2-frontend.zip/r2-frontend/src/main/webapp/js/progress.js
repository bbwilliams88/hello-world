if (!window.R2) window.R2 = {};

R2.progressWindow = function(element) {
	try {
		jQuery(element).click(showProgressManual);
	} catch (ex) {
		log(ex);
	}
};

R2.emailProgressWindow = function(element) {
	try {
		jQuery(element).click(showEmailProgressManual);
	} catch (ex) {
		log(ex);
	}
};

R2.progressForm = function(element) {
	try {
		element = jQuery(element);
		R2.custombind(element, Tapestry.FORM_PREPARE_FOR_SUBMIT_EVENT, showProgressManual);
		R2.custombind(element, Tapestry.FORM_PROCESS_SUBMIT_EVENT, hideProgressManual);
	} catch (ex) {
		log(ex);
	}
};