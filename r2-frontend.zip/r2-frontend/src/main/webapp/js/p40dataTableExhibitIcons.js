function getP40Icons(data, type, full, meta)
{
  var str = "<span style='padding-right:0.5em; padding-left:0.5em'>";
  var testStr="";  
  var validStr="";
  var errorsStr="";
  var importedStr ="";
  var allLockedStr=""; 
  var anyLockedStr ="";

  if (full.test)
  {
    testStr =  "<span class='badge-test' title='Test Exhibit' data-toggle='tooltip'>T</span>";
  }
  
  if (full.imported)
  {
    importedStr =  "<span class='badge-import' title='Imported Exhibit' data-toggle='tooltip'>I</span>";
  }
  if (full.valid)
  {
    validStr =  "<span class='badge-valid' title='Valid Exhibit' data-toggle='tooltip'>V</span>";
  }
  else
  {
    validStr =  "<span class='badge-warning' title='Warnings Exist' data-toggle='tooltip'>W</span>";
  }
  if (full.errors)
  {
    errorsStr =  "<span class='badge-error' title='Valid Exhibit' data-toggle='tooltip'>E</span>";
  }
  if (full.frozen)
  {
    allLockedStr =  "<img src='images/icon_padlock_blue.png' title='PE Frozen' data-toggle='tooltip'/>";
  }
//  if (full.anyLocked || full.peLocked)
//  {
//    anyLockedStr =  "<img src='images/icon_padlock.gif' title='Locked' data-toggle='tooltip'/>";
//  }
  
  return str.concat(testStr, importedStr,validStr, errorsStr,
      allLockedStr, anyLockedStr,"</span>" );
}

var P40ExhibitTypes =[
    {name: "p40aExists", label:"P40a", toolTip: "P40a Exists"},
    {name: "p3aExists", label:"P3a", toolTip: "P3a Exists"},
    {name: "p18Exists", label:"P18", toolTip: "P18 Exists"},
    {name: "p10Exists", label:"P10", toolTip: "P10 Exists"},
    {name: "p5aExists", label:"P5a", toolTip: "P5 Exists"},
    {name: "p21Exists", label:"P21", toolTip: "P21 Exists"},
    {name: "p20Exists", label:"P20", toolTip: "P20 Exists"},
    {name: "p17Exists", label:"P17", toolTip: "P17 Exists"},
    {name: "p23Exists", label:"P23", toolTip: "P23 Exists"},
    {name: "p25Exists", label:"P25", toolTip: "P25 Exists"},
    {name: "p26Exists", label:"P26", toolTip: "P26 Exists"}
    ];
    

function getP40ExhibitTypeBadges(data, type, full, meta)
{
  var str="";
  
  for (var i=0; i<P40ExhibitTypes.length; i++){
    if (full[P40ExhibitTypes[i].name]){
      str+="<span class='badge-exhibit' title='"+P40ExhibitTypes[i].toolTip+"' data-toggle='tooltip'>"+P40ExhibitTypes[i].label+"</span>"; 
    }
  }
  return str;

}
