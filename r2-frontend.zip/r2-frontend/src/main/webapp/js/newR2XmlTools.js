$(document).ready(function() {
  $('.accordion-tabs').unbind("click");
    $('.tab-link').unbind('click');
    $('.tab-link').on('click', function(event) {
    if (!$(this).hasClass('is-active')) {
      event.preventDefault();
      var accordionTabs = $(this).closest('.accordion-tabs');
      accordionTabs.find('.is-open').removeClass('is-open').hide();
      $(this).next().toggleClass('is-open').toggle();
      accordionTabs.find('.is-active').removeClass('is-active');
      $(this).addClass('is-active');
    } else {
      event.preventDefault();
    }
    event.preventDefault();
  });
  
    $('.tab-link').first().addClass('is-active').next().addClass('is-open').show();
  
});

  
 

  
