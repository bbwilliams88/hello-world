var buildOtherDocsLinks;

var CXEDocTypes = [
    {type: "r1", format:  [{name: "PDF", checkboxId: "#r1_pdf"},{name: "EXCEL", checkboxId: "#r1_excel"}]},
    {type: "r1summary",format:  [{name: "PDF", checkboxId: "#r1summary_pdf"},{name: "EXCEL", checkboxId: "#r1summary_excel"}]},
    {type: "r1c",format:  [{name: "PDF", checkboxId: "#r1c_pdf"},{name: "EXCEL", checkboxId: "#r1c_excel"}]},
    {type: "r1d",format:  [{name: "PDF", checkboxId: "#r1d_pdf"},{name: "EXCEL", checkboxId: "#r1d_excel"}]},
    {type: "r2",format:  [{name: "PDF", checkboxId: "#r2_pdf"},{name: "EXCEL", checkboxId: "#r2_excel"}]},
    {type: "p1",format:  [{name: "PDF", checkboxId: "#p1_pdf"},{name: "EXCEL", checkboxId: "#p1_excel"}]},
    {type: "p1m",format:  [{name: "PDF", checkboxId: "#p1m_pdf"}]},
    {type: "p40",format:  [{name: "PDF", checkboxId: "#p40_pdf"}]}
    ];


function buildOtherDocumentsPageInit(urlJson){
	  buildOtherDocsLinks = urlJson;
	$(".three-quarters-loader").hide();
	$("#errorMessage").hide();
	var expanderHeader = $("#otherDocumentsTab").find(".expanderHeader");
	expanderHeader.click(function(e) {
		$(this).next("div").slideToggle("fast");
	});
  
  //FILE UPLOAD SECTION

  var otherDropzone = cxeDefaultDropzone("buildOtherUpload", buildOtherDocsLinks.uploadFile);

  otherDropzone.on("success", function(file, response){
    var responseStr = JSON.stringify(response);
    console.log(responseStr);
    
    // add successfully returned exhibits (if any) to the selected exhibits table
    if (typeof response.exhibits != 'undefined' && response.exhibits.length > 0) {
      var selectedExhibitsTable = $("#selectedExhibitsTable").DataTable();
      selectedExhibitsTable.rows.add(response.exhibits).draw();
    }
    
    // add error messages (if any) to this file's row in the upload list
    if (typeof response.errorMessages!='undefined' && typeof response.errorMessages.general !='undefined' && response.errorMessages.general.length>0){
        
        var errors = [];
        for (var i=0; i<response.errorMessages.general.length; i++){
          errors.push("<li>"+response.errorMessages.general[i].message+"</li>");
        }
        var errorStr = "<ul>"+errors.join("")+"</ul>";
        file.previewElement.querySelector(".error").innerHTML = errorStr;
      }
  });
   
   var selectedExhibits = [];
   
   var selectedExhibitsTable = $("#selectedExhibitsTable").DataTable({
     "autoWidth": false,
     "serverSide": false,
     "language": {
       "emptyTable": "No results found."
     },
     "createdRow": function(row, data, index){
         var deleteBtns = $(row).find(".deleteExhibitBtn");
         var api = this.api();
         deleteBtns.unbind("click");
         deleteBtns.click(function(e){
           deleteSelected(data, api, index);
         });
     },
     "data": selectedExhibits,
     "columns": [
           { "data": "exhibitType",
             "bSearchable":false,
             "sortable":true,
             "sClass": "r2List_exhibittype",
             "visible":true
           },
           { "data": "selectionType",
             "bSearchable":false,
             "bSortable":false,
             "sClass": "r2List_selectiontype",
             "visible":true
           },
                 { "data": "number",
                   "bSearchable":true,
                   "bSortable":true,                 
                   "sClass": "r2List_r1num",
                   "visible":true,
                   "defaultContent":""
                 },
                 { "data": "exhibitNumber",
                   "bSearchable":true,
                   "bSortable":true,
                   "sClass": "r2List_number",
                   "visible":true
                 },
                 { 
                   "data": "title",
                   "bSearchable":true,
                   "bSortable":true,
                   "sClass": "r2List_title",
                   "visible":true,
                   "render": function(data,type,full, meta) {
                     var titleStr = full.title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    	.replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/-/g, "&ndash;").replace(/,/g, "&sbquo;");
                     if (typeof full.title == 'undefined' || full.title == null) {
                       titleStr = "";
                     }
                     if (titleStr.length > 40) {
                       return '<span data-toggle="tooltip" title="'+titleStr+'">'+(titleStr).substr(0,38)+'...</span>';
                     }
                     else
                     {
                       return '<span data-toggle="tooltip" title="'+titleStr+'">'+titleStr+'</span>';
                     }
                   },
                   "defaultContent":""
                 },
                 {
                   "data": null,
                   "bSearchable":true,
                   "bSortable": true,
                   "sClass": "r2List_budgetcycle",
                   "visible": true,
                   "render": function (data,type, full, meta){
                     return full.budgetCycle+" "+full.budgetYear;
                   },
                   "defaultContent": ""
                 },
                 {
                   "data": null,
                   "bSearchable":false,
                   "bSortable":false,
                   "sClass": "r2List_action",
                   "visible":true,
                   "render": function(data, type, full, meta)
                   {
                     return "<button class='cxeButton deleteExhibitBtn'>Delete</button>";
                   },
                   "defaultContent": "<span></span>"
                 }
                 ]
     
   });
   
   var r2ExhibitTable = $("#r2ExhibitTable").DataTable();
   
   // Check server for stored uploads
   $.ajax({
     url: buildOtherDocsLinks.getUploadedExhibits,
     type: "GET",
     success: function(response){
       var responseStr = JSON.stringify(response);
       console.log(responseStr);
       
       // add successfully returned exhibits (if any) to the selected exhibits table
       if (typeof response.exhibits != 'undefined' && response.exhibits.length > 0) {
         for(var i=0; i<response.exhibits.length; i++) {
           selectedExhibitsTable.rows.add([response.exhibits[i]]).draw();
         }
       }
     },
     error : function(data){
       console.log(data);
       var errorStr = "Error fetching stored uploads: "+data;
       $("#errorMessage").append(errorStr);
       $("#errorMessage").show();
     }
   });
   
   r2ExhibitTable.on('draw.dt', function(){
     // after draw, sync with selected table (if exhibit is in the selected table, check the checkbox)
     var peListData = r2ExhibitTable.data();
     var selectedListData = selectedExhibitsTable.data();
     var selectedBudgetCycle = $("#r2BudgetCycleFilter :selected").attr('value');
     var budgetCycle = selectedBudgetCycle.split(" ")[0];
     var budgetYear = selectedBudgetCycle.split(" ")[1];
     
     for (var i=0; i<selectedListData.length; i++){
       if (selectedListData[i].selectionType=="List" && selectedListData[i].exhibitType=="R2" 
         && selectedListData[i].budgetCycle==budgetCycle && selectedListData[i].budgetYear==budgetYear ){
         for (var j=0; j<peListData.length; j++){
           if (peListData[j].id==selectedListData[i].id){
             peListData[j].selected=true;
             var checkbox = $(r2ExhibitTable.row(j).node()).find(".r2PESelectionCheckbox");
             checkbox.prop("disabled", true);
             checkbox.prop("checked", true);
           }
         }
       }
     }
     
     var peListBoxes = $(".r2PESelectionCheckbox");
     var selectAllCheckbox = $("#r2SelectAllCheckbox");
     updateSelectAllCheckbox(peListBoxes, selectAllCheckbox, peListData);
   }); 
   
   var p40ExhibitTable = $("#p40ExhibitTable").DataTable();
   p40ExhibitTable.on('draw.dt', function(){
     // after draw, sync with selected table (if exhibit is in the selected table, check the checkbox)
     var liListData = p40ExhibitTable.data();
     var selectedListData = selectedExhibitsTable.data();
     var selectedBudgetCycle = $("#p40BudgetCycleFilter :selected").attr('value');
     var budgetCycle = selectedBudgetCycle.split(" ")[0];
     var budgetYear = selectedBudgetCycle.split(" ")[1];
     
     for (var i=0; i<selectedListData.length; i++){
       if (selectedListData[i].selectionType=="List" && selectedListData[i].exhibitType=="P40" 
         && selectedListData[i].budgetCycle==budgetCycle && selectedListData[i].budgetYear==budgetYear ){
         for (var j=0; j<liListData.length; j++){
           if (liListData[j].id==selectedListData[i].id){
             liListData[j].selected=true;
             var checkbox = $(p40ExhibitTable.row(j).node()).find(".liSelectionCheckbox");
             checkbox.prop("disabled", true);
             checkbox.prop("checked", true);
           }
         }
       }
     }
     
     var liListBoxes = $(".liSelectionCheckbox");
     var selectAllCheckbox = $("#p40SelectAllCheckbox");
     updateSelectAllCheckbox(liListBoxes, selectAllCheckbox, liListData);
   });
   
   $("#r2SelectAllCheckbox").click(function(e) {
     selectAllCheckboxChecked("R2");
   });
   
   $("#p40SelectAllCheckbox").click(function(e) {
     selectAllCheckboxChecked("P40");
   });
   
   $('[data-toggle="tooltip"]').tooltip();
   
   // Prevent click/keypress on the dropdown filters from bubbling up to the header sorting
   $(".service-agency-filter").keypress(function (e) {
     e.stopPropagation();
   });
   $(".service-agency-filter").click(function (e) {
     e.stopPropagation();
   });
   
   $(".budget-cycle-filter").keypress(function (e){
     e.stopPropagation();
   });
   $(".budget-cycle-filter").click(function (e){
     e.stopPropagation();
   });

   // Modals
   
   // submit button
   $("#otherDocsSubmitBtn").click(function (e) {
     var selectedData = selectedExhibitsTable.data();
     // get list of exhibits that were selections
     submitForm(selectedData);
   });
   
   $(".large-checkbox").click(function(e){
     if (!$(this).prop("checked")){
       $(this).parent().parent().find(".results").remove();
     }
   });
   
   
   // reset form and selections
   $("#otherDocsResetBtn").click(function (e){
	 var resetUploadsButton = $('#buildOtherUploadActions').find(".cancel");
	 resetUploadsButton.click();
     var selectedLargeCheckboxes =$(".large-checkbox:checked");
     $.each(selectedLargeCheckboxes, function (i, checkbox ){
       resetLargeCheckbox(checkbox);  
     });
     $(".large-checkbox:checked").prop("checked", false);
     
     $(".r2PESelectionCheckbox:checked").prop("disabled", false);
     $(".liSelectionCheckbox:checked").prop("disabled", false);
     $(".r2PESelectionCheckbox:checked").prop("checked",false);
     $(".liSelectionCheckbox:checked").prop("checked",false);
    
     
     var peListData = r2ExhibitTable.data();
     for (var i=0; i<peListData.length;i++)
     {
       if (peListData[i].selected)
       {
         peListData[i].selected = false;
       }
     }
     
     $(".liSelectionCheckbox:checked").prop("checked",false);
     var liListData = p40ExhibitTable.data();
     for (var i=0; i<liListData.length;i++)
     {
       if (liListData[i].selected)
       {
         liListData[i].selected = false;
       }
     }
     
     
     $("#forceEvenPages").prop("checked", true);
     $("#watermark").val("");
     $("#trackingHeader").val("");
     $(".results").remove();
     selectedExhibitsTable.clear().draw();
     r2ExhibitTable.draw();
     p40ExhibitTable.draw();
     $("#errorMessage").empty();
     $("#errorMessage").hide();
     //delete uploaded exhibits from server
     $.ajax({
       url: buildOtherDocsLinks.reset,
       type: "GET",
       success: function(response){
       },
       error : function(data){
         console.log(data);
         var errorStr = "An unexpected error occurred: "+data;
         $("#errorMessage").append(errorStr);
         $("#errorMessage").show();
       }
     });

   });
  
};

function selectAllCheckboxChecked(type) {
  var exhibitSelectionBoxes;
  var selectAllCheckbox;
  var peListData;
  
  if(type == "R2") {
    exhibitSelectionBoxes = $(".r2PESelectionCheckbox");
    selectAllCheckbox = $("#r2SelectAllCheckbox");
    peListData = $("#r2ExhibitTable").DataTable().data();
  }
  if(type == "P40") {
    exhibitSelectionBoxes = $(".liSelectionCheckbox");
    selectAllCheckbox = $("#p40SelectAllCheckbox");
    peListData = $("#p40ExhibitTable").DataTable().data();
  }
  var checked = selectAllCheckbox.prop("checked");
  exhibitSelectionBoxes.prop("checked", checked);
  // now update the data and add to selected exhibit table
  exhibitSelectionBoxes.each(function() {
    var index = $(this).val();
    var alreadySelected = peListData[index].selected;
    peListData[index].selected = checked;
    if(type == "R2" && !alreadySelected)
      r2ExhibitSelected($(this), peListData);
    if(type == "P40" && !alreadySelected)
      p40ExhibitSelected($(this), peListData);
    
  });
  
  selectAllCheckbox.prop("disabled", true)
}

function updateSelectAllCheckbox(exhibitSelectionBoxes, selectAllCheckbox, peListData) {
  var allchecked = true;
  exhibitSelectionBoxes.each(function() {
    var index = $(this).val();
    if (!peListData[index].selected) {
      allchecked = false;
      return false;
    }
  });

  selectAllCheckbox.prop("checked", allchecked);
  selectAllCheckbox.prop("disabled", allchecked);
}

function r2ExhibitSelected(checkbox, peListData) {
  var selectedElementIndex = checkbox.val();
  var selectedElement = peListData[selectedElementIndex];
  var checked = checkbox.prop("checked");
  selectedElement.selected = checked;
  updateSelectAllCheckbox($(".r2PESelectionCheckbox"), $("#r2SelectAllCheckbox"), peListData);
  
// add selected row to selected table
  var newSelection = [{ "exhibitType": "R2",
                       "selectionType": "List",
                       "originIndex": selectedElementIndex,
                       "exhibitNumber": selectedElement.number,
                       "number": selectedElement.lineNum,
                       "title": selectedElement.title,
                       "budgetCycle": selectedElement.budgetCycle,
                       "budgetYear": selectedElement.budgetYear,
                       "serviceAgencyCode": selectedElement.serviceAgencyCode,
                       "budgetActivityNumber": selectedElement.baNum,
                       "budgetActivityTitle": "",
                       "id": selectedElement.id}];
  var selectedExhibitsTable = $("#selectedExhibitsTable").DataTable();
  selectedExhibitsTable.rows.add(newSelection).draw();
  checkbox.prop("disabled", true);

}

function p40ExhibitSelected(checkbox, peListData) {
  
  var selectedElementIndex = checkbox.val();
  var selectedElement = peListData[selectedElementIndex];
  var checked = checkbox.prop("checked");
  selectedElement.selected = checked;
  updateSelectAllCheckbox($(".liSelectionCheckbox"), $("#p40SelectAllCheckbox"), peListData);
  
  var budgetCycleYear = selectedElement.budgetCycleAndYear;
  var bc = budgetCycleYear.split(" ")[0];
  var year = budgetCycleYear.split(" ")[1];
  
// add selected row to selected table
  var newSelection = [{ "exhibitType": "P40",
                       "selectionType": "List",
                       "originIndex": selectedElementIndex,
                       "exhibitNumber": selectedElement.lineItemNumber,
                       "number": selectedElement.p1LineItemNumber,
                       "title": selectedElement.lineItemTitle,
                       "budgetCycle": bc,
                       "budgetYear": year,
                       "serviceAgencyCode": selectedElement.agencyCode,
                       "budgetActivityNumber": selectedElement.bsaNum,
                       "budgetActivityTitle": selectedElement.budgetActivityTitle,
                       "id": selectedElement.id}];
  
  var selectedExhibitsTable = $("#selectedExhibitsTable").DataTable();
  selectedExhibitsTable.rows.add(newSelection).draw();
  checkbox.prop("disabled", true);

}

function deleteSelected(data, selectedExhibitTable, index) {
  var exhibitTable;
  var checkboxClass;
  var selectAllCheckboxId
  var selectedExhibitTableData = selectedExhibitTable.data();
  
  if (data.selectionType=="List"){
    
    // set exhibit table selectors to r2 or p40
    if (data.exhibitType=="R2"){
      exhibitTable = $("#r2ExhibitTable").DataTable();
      checkboxClass =".r2PESelectionCheckbox";
      selectAllCheckboxId = "#r2SelectAllCheckbox";
    }
    else if (data.exhibitType=="P40"){
      exhibitTable = $("#p40ExhibitTable").DataTable();
      checkboxClass =".liSelectionCheckbox";
      selectAllCheckboxId = "#p40SelectAllCheckbox";
    }
    // find in r2 or p40 exhibit table and uncheck
    var exhibitTableData = exhibitTable.data();
    for (var i=0; i<exhibitTableData.length;i++)
    {
      if (exhibitTableData[i].budgetCycle==data.budgetCycle && exhibitTableData[i].budgetYear==data.budgetYear && exhibitTableData[i].id==data.id){
        exhibitTableData[i].selected = false;
        var checkbox = $(exhibitTable.row(i).node()).find(checkboxClass);
        checkbox.prop("disabled", false);
        checkbox.prop("checked", false);
        updateSelectAllCheckbox($(checkboxClass), $(selectAllCheckboxId), exhibitTableData);
        break;
      }
    }
    
    // find in selected exhibit table and remove
    for (var i = 0; i < selectedExhibitTableData.length; i++) {
        if (selectedExhibitTableData[i].budgetCycle === data.budgetCycle 
            && selectedExhibitTableData[i].budgetYear === data.budgetYear
            && selectedExhibitTableData[i].exhibitType === data.exhibitType
            && selectedExhibitTableData[i].id === data.id) {
          selectedExhibitTable.row(i).remove().draw();
          break;
        }
      }
  }
  else {
    // uploaded exhibit
    
    // find in selected exhibit table and remove (search by PE/LI # b/c no database id)
    for (var i = 0; i < selectedExhibitTableData.length; i++) {
        if (selectedExhibitTableData[i].exhibitType === data.exhibitType
            && selectedExhibitTableData[i].selectionType === data.selectionType
            && selectedExhibitTableData[i].budgetCycle === data.budgetCycle
            && selectedExhibitTableData[i].budgetYear === data.budgetYear
            && selectedExhibitTableData[i].exhibitNumber === data.exhibitNumber) {
          selectedExhibitTable.row(i).remove().draw();
          break;
        }
      }
    
    // request deletion from server-side upload data
    var deleteSelection = { "exhibitType": data.exhibitType,
      "selectionType": "Upload",
      "originIndex": data.originIndex,
      "exhibitNumber": data.exhibitNumber,
      "number": data.number,
      "title": data.title,
      "budgetCycle": data.budgetCycle,
      "budgetYear": data.budgetYear,
      "serviceAgencyCode": data.serviceAgencyCode,
      "budgetActivityNumber": data.budgetActivityNumber,
      "budgetActivityTitle": data.budgetActivityTitle,
      "id": data.id};
    
    var jsonObj = {"json": JSON.stringify(deleteSelection)};
    $.ajax({
      url: buildOtherDocsLinks.deleteUploadedExhibit,
      type: "POST",
      data: jsonObj,
      success: function(response){
        
      },
      error : function(data){
        console.log(data);
      }
    });
  }
}

function submitForm(selectedData){
  $("#errorMessage").empty();
  $("#errorMessage").hide();
  // get all r2's and p40's that were selected from the database
  var peSelection =  [];
  var liSelection = [];
  var peUploadSelection = [];
  var liUploadSelection = [];
  for (var i=0; i<selectedData.length;i++){
    if (selectedData[i].selectionType=="List" && selectedData[i].exhibitType=="R2"){
      peSelection.push(selectedData[i].id);
    }
    else if (selectedData[i].selectionType=="List" && selectedData[i].exhibitType=="P40"){
      liSelection.push(selectedData[i].id);
    }
    else if (selectedData[i].selectionType=="Upload" && selectedData[i].exhibitType=="R2"){
      peUploadSelection.push(selectedData[i].exhibitNumber);
    }
    else if (selectedData[i].selectionType=="Upload" && selectedData[i].exhibitType=="P40"){
      liUploadSelection.push(selectedData[i].exhibitNumber);
    }
  }
  
  // get document formats
  var selectedBudgetCycleStr = $("#budgetCycle").val();
  var selectedBudgetCycle = selectedBudgetCycleStr.split(" ")[0];
  var selectedBudgetYear = selectedBudgetCycleStr.split(" ")[1];
  var serviceAgencyName = $("#serviceAgency").val();
  var forceEvenPages = $("#forceEvenPages").prop("checked");
  var watermark = $("#watermark").val();
  var trackingHeader = $("#trackingHeader").val();

  var formdataTemplate = {
	      budgetCycle: selectedBudgetCycle,
	      budgetYear: selectedBudgetYear,
	      serviceAgencyName: serviceAgencyName,
	      forceEvenPages: forceEvenPages,
	      watermark: watermark,
	      trackingHeader: trackingHeader,
	      r2SelectedExhibits: peSelection,
	      p40SelectedExhibits: liSelection,
	      r2UploadedExhibits: peUploadSelection,
	      p40UploadedExhibits: liUploadSelection,
	      documentType:"",
	      formatType:""
	  };
  console.log("template: "+formdataTemplate.p40UploadedExhibits.length);
  
  var count = 0;
  for (var i=0; i<CXEDocTypes.length; i++){
    for (var j=0; j<CXEDocTypes[i].format.length; j++){
      var checked = $(CXEDocTypes[i].format[j].checkboxId).is (":checked");
      if (checked){
        var formdata = JSON.parse(JSON.stringify(formdataTemplate));
        formdata.documentType=CXEDocTypes[i].type;
        formdata.formatType=CXEDocTypes[i].format[j].name;
        requestDoc(formdata);
        count++;
      }
    }
  }
  
  // validate data
  var errors = [];
  if (selectedBudgetCycleStr==''){
    errors.push("Please select a budget cycle.");
  }
  if (serviceAgencyName==''){
    errors.push("Please select an Agency.");
  }
  if (selectedData.length==0 ){
    errors.push("No exhibits were selected.");
  }
  if (count == 0){
    errors.push("No document type or format type was selected.");
  }
  
  if (errors.length>0){
    var errorStr = "<ul>";
    for (var i=0; i< errors.length; i++){
      errorStr +="<li>"+errors[i]+"</li>";
    }
    errorStr+="</ul>";
    $("#errorMessage").append(errorStr);
    $("#errorMessage").show();
    return;
  }

}

function createFormData(budgetCycle, budgetYear, serviceAgencyName, forceEvenPages, watermark, trackingHeader, peSelection, liSelection){
  return  {
      budgetCycle: budgetCycle,
      budgetYear: budgetYear,
      serviceAgencyName: serviceAgencyName,
      forceEvenPages: forceEvenPages,
      watermark: watermark,
      trackingHeader: trackingHeader,
      r2SelectedExhibits: peSelection,
      p40SelectedExhibits: liSelection,
      documentType:"",
      formatType:""
  };
}

function requestDoc(formdata){
  //console.log(JSON.stringify(formdata)); //uncomment to check that the right data is getting sent to the server
  var jsonObj = {"json": JSON.stringify(formdata)};
  var cellLocation = formdata.documentType+"_"+formdata.formatType+"_cell";
  var cell = $("#"+cellLocation); 
  cell.find(".results").remove();
  var statusInfoContainer = cell.find(".statusInfoContainer");
  var svg = cell.find("svg");
  svg[0].removeAttributeNS(null, "class", "large-checkbox-svg")
  svg[0].setAttributeNS( null, "class", "large-checkbox-with-status");
 
  // stupid ie
  if (formdata.documentType.indexOf("r")==0 && formdata.r2SelectedExhibits.length==0 && formdata.r2UploadedExhibits.length==0){
//  if (formdata.documentType.startsWith("r") && formdata.r2SelectedExhibits.length==0 && formdata.r2UploadedExhibits.length==0){
    statusInfoContainer.append("<div class='results'>No RDT&E exhibit was selected.</div>");
    return;
  }
  
  if (formdata.documentType.indexOf("p")==0 && formdata.p40SelectedExhibits.length==0 && formdata.p40UploadedExhibits.length==0 ){
//  if (formdata.documentType.startsWith("p") && formdata.p40SelectedExhibits.length==0 && formdata.p40UploadedExhibits.length==0 ){
    statusInfoContainer.append("<div class='results'>No Procurement exhibit was selected.</div>");
    return;
  }
  
  // put up spinner
  
  var spinner =cell.find(".three-quarters-loader"); 
  spinner.show();
  
  $.ajax({
    url: buildOtherDocsLinks.buildDoc,
    type: "POST",
    data: jsonObj,
    success: function(response){
      var responseStr = JSON.stringify(response);
      console.log(responseStr);
      spinner.hide();
      renderResponse(formdata, response);
    },
    error : function(data){
      console.log(data);
      var errorStr = "An unexpected error occurred: "+data;
      $("#errorMessage").append(errorStr);
      $("#errorMessage").show();
      spinner.hide();
    }
  });
}

function renderResponse(formdata, response){
  var cellLocation = formdata.documentType+"_"+formdata.formatType+"_cell";
  var cell = $("#"+cellLocation).find(".statusInfoContainer");
  
  if (typeof response.errorMessages!='undefined' && typeof response.errorMessages.general !='undefined' && response.errorMessages.general.length>0){
    
    var errors = [];
    for (var i=0; i<response.errorMessages.general.length; i++){
      errors.push("<li>"+response.errorMessages.general[i].message+"</li>");
    }
    var errorStr = "<div class='results'><ul>"+errors.join("")+"</ul></div>";
    cell.append(errorStr);
  }
  else if (typeof response.successMessages!='undefined' && typeof response.successMessages.general !='undefined' && response.successMessages.general.length>0){
    var fileKey = response.successMessages.general[0].message;
    var resultStr = "<div class='results'><a href='"+buildOtherDocsLinks.downloadFile+"/"+fileKey+"'>Download</a></div>";
    cell.append(resultStr);
  }
}