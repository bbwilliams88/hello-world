$(document)
		.ready(
				function() {
					// customize the file-row template before initializing the
					// dropzone
					var filenameContainer = $("#mergeForm").find("p.name")
							.parent();
					filenameContainer
							.append("<div class='merge-upload-labels'></div>");

					var mergeDropzone = cxeCustomDropzone("merge",
							"/r2/newr2xmltools.xmlmergetooltab:mergexmlfileupload");

					mergeDropzone
							.on(
									"success",
									function(file, response) {
										var responsestr = JSON
												.stringify(response);
										console.log(responsestr);

										var mergeComplete = file.previewElement
												.querySelector(".complete");
										var mergeExhibitCount = file.previewElement
												.querySelector(".merge-exhibit-count");
										var mergeFileCount = file.previewElement
												.querySelector(".merge-file-count");
										var mergeUploadLabels = file.previewElement
												.querySelector(".merge-upload-labels");

										mergeExhibitCount.style.display = "none";
										mergeFileCount.style.display = "none";

										if (response.added
												&& (response.added > 0)) {
											var userMessage = (response.added > 1) ? "Ready to Merge ("
													+ response.added
													+ ") Files"
													: "Ready to Merge";
											$(mergeComplete).text(userMessage);
											$(mergeComplete).attr(
													"title",
													response.count
															+ " Exhibit(s)");
											$(mergeComplete).addClass(
													"text-success");
											$(mergeExhibitCount).text(
													response.count);
											$(mergeFileCount).text(
													response.added);
											$("#mergeXml-button").show();

											// Add badges
											// See MergeCandidate.java for _
											// string origins
											var hasArmy = false;
											var hasNavy = false;
											var hasAirForce = false;
											var hasDefenseWide = false;
											var hasR2 = false;
											var hasP40 = false;

											for (var i = 0; i < response.added; i++) {
												var description = response['description'
														+ i];
												if (description
														.indexOf("_Army") >= 0) {
													hasArmy = true;
												}
												if (description
														.indexOf("_Navy") >= 0) {
													hasNavy = true;
												}
												if (description
														.indexOf("_Air_Force") >= 0) {
													hasAirForce = true;
												}
												if (description.indexOf("_DW") >= 0) {
													hasDefenseWide = true;
												}
												if (description.indexOf("_LI") >= 0) {
													hasP40 = true;
												}
												if (description
														.indexOf("_RDTE") >= 0) {
													hasR2 = true;
												}
											}

											if (hasArmy) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-success\">Army</span> ");
											}
											if (hasNavy) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-primary\">Navy</span> ");
											}
											if (hasAirForce) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-info\">Air Force</span> ");
											}
											if (hasDefenseWide) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-warning\">Defense Wide</span> ");
											}
											if (hasR2) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-default\">R2</span> ");
											}
											if (hasP40) {
												$(mergeUploadLabels)
														.append(
																"<span class=\"label label-default\">P40</span> ");
											}
										} else {
											var userMessage = (response.duplicate) ? "Duplicate"
													: "Invalid";
											$(mergeComplete).text(userMessage);
											$(mergeComplete).addClass(
													"text-danger");
											$(mergeUploadLabels)
													.append(
															"<span class=\"label label-danger\">Rejected</span> ");
											$(mergeExhibitCount).text(0);
											$(mergeFileCount).text(0);
										}
										$("#mergeXmlDownloadLink").hide();
									});

					mergeDropzone.on("complete", function(file) {
						updateStatsCount(mergeDropzone);
					});

					mergeDropzone
							.on(
									"removedfile",
									function(file) {
										var mergeComplete = file.previewElement
												.querySelector(".complete");
										if ($(mergeComplete).hasClass(
												"text-success")) {
											$
													.post(
															"/r2/newr2xmltools.xmlmergetooltab:removeFile",
															{
																name : file.name
															}, function(resp) {
															});
										}
										$("#mergeXmlDownloadLink").hide();
										updateStatsCount(mergeDropzone);
									});

					mergeDropzone.on("reset", function() {
						$.ajax({
							url : "/r2/newr2xmltools.xmlmergetooltab:reset",
							type : "POST"
						}).done(function(data) {

						});
						$("#mergeXmlDownloadLink").hide();
						$("#mergeXml-button").hide();
					});

					$("#mergeXml-button").click(function() {
						$("#mergeProgressBar").show();
						$.ajax({
							url : "/r2/newr2xmltools.xmlmergetooltab:mergexml",
							type : "POST"
						}).done(function(data) {
							$("#mergeXmlDownloadLink").show();
							$("#mergeProgressBar").hide();
							console.log("merge complete");
						});
					});

					$("#mergeXmlDownloadLink").hide();
					$("#mergeProgressBar").hide();
					$("#mergeXml-button").hide();

					$.post("/r2/newr2xmltools.xmlmergetooltab:reset", function(
							resp) {
						// reset on new page loads
					});
				});

function updateStatsCount(mergeDropzone) {
	var exhibitCount = 0;
	var fileCount = 0;

	var arrayLength = mergeDropzone.files.length;
	for (var i = 0; i < arrayLength; i++) {
		var mfc = mergeDropzone.files[i].previewElement
				.querySelector(".merge-file-count");
		fileCount += parseInt($(mfc).text());

		var mec = mergeDropzone.files[i].previewElement
				.querySelector(".merge-exhibit-count");
		exhibitCount += parseInt($(mec).text());
	}

	var mergeButtonText = (fileCount > 1) ? "Merge (" + fileCount + ") Files"
			: "Merge";
	$("#mergeXml-button").text(mergeButtonText);
}