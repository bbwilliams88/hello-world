$(document).ready(function() {
  
  var splitDropzone = cxeDefaultDropzone("split", "/r2/newr2xmltools.xmlsplittooltab:splitxml");
  
  splitDropzone.on("success", function (file, response){
        console.log("Success?");
        var responsestr = JSON.stringify(response);
        console.log(responsestr);
        renderSplitResponse(file.name, response);
  });
  
});

function renderSplitResponse(fileName,response){
  var migrateForm = $('#splitXmlForm');
  var newId = "split_" + getIdFilename(fileName);
  console.log(newId);
  
  var splitResponseTemplate =  $('#splitResponseTemplate');
  var itemsTBody = splitResponseTemplate.find("tbody");
  
  var columns = [];
  
  // FILE NAME Column
  columns.push("<td>"+fileName+"</td>");
  
  // ITEMS Column
  
  //RESULTS column
  var results= [];
  if (typeof response.errorMessages!='undefined' && typeof response.errorMessages.general !='undefined' && response.errorMessages.general.length>0){
    
    for (var i=0;i<response.errorMessages.general.length;i++){
      results.push("<li>"+response.errorMessages.general[i].message+"</li>");
    }
  }
  if (typeof response.errorMessages!='undefined' && typeof response.errorMessages.files !='undefined' && response.errorMessages.files.length>0){
    for (var i=0;i<response.errorMessages.files.length;i++){
      
      var fileNode = response.errorMessages.files[i];
      if (typeof fileNode.messages!='undefined' && fileNode.messages.length>0){
        var str = "<li>"+fileNode.fileName+"<ol>";
        var buf = [];
        for (var j=0; j<fileNode.messages.length; j++){
          buf.push("<li>"+fileNode.messages[j].message+"</li>");
        }
        str+=buf.join("")+"</ol></li>";
      }
      results.push(str);
    }
  }
  if(typeof response.errorMessages == 'undefined' || response.errorMessages.length == 0) {
    results.push("No errors.");
  }
  
  
  columns.push("<td>"+results.join("")+"</td>");
  
  //Download column
  var downloads = [];
  if (typeof response.successMessages!='undefined' && typeof response.successMessages.general !='undefined' && response.successMessages.general.length>0){
    downloads.push("<td><a href='/r2/newr2xmltools.xmlsplittooltab:downloadfile/"+response.successMessages.general[0].message+"'>Download</a></td>");
  }
  else {
    downloads.push("<td></td>");
  }
  columns.push(downloads.join(""));
  itemsTBody.append("<tr id='"+newId+"'>"+columns.join("")+"</tr>");  

}