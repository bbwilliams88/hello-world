var migrateUrl = "/r2/newr2xmltools.xmlmigratetooltab:migrate/";
var downloadMigratedFileUrl = "/r2/newr2xmltools.xmlmigratetooltab:downloadfile/";

$(document).ready(function() {
  
  var migrationDropzone = cxeDefaultDropzone("migrate", migrateUrl);
  
  migrationDropzone.on("processing", function(file){
    var bc = file.previewElement.querySelector("select[name='budgetCycleToMigrate']");
    migrationDropzone.options.url = migrateUrl+bc.value; // update url with the selected budgetcycle
    console.log(migrationDropzone.options.url);
  });
  
  migrationDropzone.on("success", function (file, response){
        console.log("Success?");
        var responsestr = JSON.stringify(response);
        console.log(responsestr);
        renderMigrationResponse(file.name, response);
  });
  
});

function renderMigrationResponse(fileName,response){
  var migrateForm = $('#migrateXmlForm');
  var newId = "migrate_" + getIdFilename(fileName);
  console.log(newId);
  
  var migrationResponseTemplate =  $('#migrationResponseTemplate');
  var itemsTBody = migrationResponseTemplate.find("tbody");
  var itemsStr = "";
  var itemsBuff = [];
  if (typeof response.items!='undefined' && response.items.length>0) {
    for (var i=0; i<response.items.length;i++){
      var item = response.items[i];
      var k=i+1;
      var results = "";
      if (typeof item.results.error!='undefined' && item.results.error.length>0){
        results = item.results.error;
      }
      else if (typeof item.results.success!='undefined' && item.results.success.length>0){
        results = item.results.success;
      }
      
      if (i==0){
        itemsBuff.push("<tr id='"+newId+"_"+i+"'>");

        itemsBuff.push("<td rowspan='"+response.items.length+"' class='uploadedFileNameColumn'>");
        if ((response.uploadedfilename).length>30){
          itemsBuff.push("<span data-toggle='tooltip' title='"+response.uploadedfilename+"'>"+(response.uploadedfilename).substr(0,30)+"...</span>");
        }
        else {
          itemsBuff.push(fileName);
        }
        itemsBuff.push("</td>");
      
        itemsBuff.push("<td class='fileNameColumn'>");  
        if ((item.filename).length>40){
          itemsBuff.push("<span data-toggle='tooltip' title='"+item.filename+"'>"+(item.filename).substr(0,40)+"...</span>");
        }
        else {
          itemsBuff.push(item.filename);
        }
        itemsBuff.push("</td>");
        itemsBuff.push("<td class='budgetCycleColumn'>"+item.budgetCycle+"</td>");
        itemsBuff.push("<td class='migratedBudgetCycleColumn'>"+item.migratedCycle+"</td>");
        itemsBuff.push("<td class='migrationResultsColumn'>");
        itemsBuff.push(results);
        
        if (typeof response.errorMessages!='undefined' && response.errorMessages.length>0){
          var errBuff = [];
          errBuff.push("Error:<ul>");
          for (var i=0;i<response.errorMessages.length; i++){
            errBuff.push("<li>"+response.errorMessages[i].message+"</li>");
          }
          errBuff.push("</ul>");
          itemsBuff.push(errBuff.join(""));
        }
        itemsBuff.push("</td>");
        
        itemsBuff.push("<td rowspan='"+response.items.length+"'>");
        
        if (typeof response.successMessages!='undefined' && response.successMessages.length>0){
//          itemsStr+="<td rowspan='"+response.items.length+"'><a href='"+downloadMigratedFileUrl+response.successMessages[0].message+"'>Download Migrated File</a></td>";
          itemsBuff.push("<a href='"+downloadMigratedFileUrl+response.successMessages[0].message+"'>Download Migrated File</a>");
        }
        itemsBuff.push("</td>");
        
//        if (typeof response.errorMessages!='undefined' && response.errorMessages.length>0){
//          var errStr = "Error:<ul>";
//          for (var i=0;i<response.errorMessages.length; i++){
//            errStr +="<li>"+response.errorMessages[i].message+"</li>";
//          }
//          itemsStr+="</ul><td rowspan='"+response.items.length+"' class='migrationResultsColumn'>"+errStr+"</td>";
//        }
//        if (typeof response.successMessages!='undefined' && response.successMessages.length>0){
//          itemsStr+="<td rowspan='"+response.items.length+"'><a href='"+downloadMigratedFileUrl+response.successMessages[0].message+"'>Download Migrated File</a></td>";
//        }
//        itemsStr+="</tr>";
        itemsBuff.push("</tr>");
      }
      else {
//        itemsStr+="<tr id='"+newId+"_"+i+"'><td>"+item.filename+"</td><td>"+item.budgetCycle+"</td><td>"+item.migratedCycle+"</td><td>"+results+"</td></tr>";
        itemsBuff.push("<tr id='"+newId+"_"+i+"'>");
        itemsBuff.push("<td>"+item.filename+"</td>");
        itemsBuff.push("<td>"+item.budgetCycle+"</td>");
        itemsBuff.push("<td>"+item.migratedCycle+"</td>");
        itemsBuff.push("<td>"+results+"</td>");
        itemsBuff.push("</tr>");
      }
    }
  }
  else if(typeof response.uploadedfilename != 'undefined') {
    if(typeof response.errorMessages != 'undefined' && response.errorMessages.length > 0) {
      var errList = "<td>Error:<ul>"
      for(var i=0; i<response.errorMessages.length; i++) {
        errList += "<li>" + response.errorMessages[i].message + "</li>";
      }
      errList += "</ul></td>";
      itemsBuff.push("<tr id='" + newId+ "_" + i + "'>");
      itemsBuff.push("<td>"+response.uploadedfilename+"</td>");
      itemsBuff.push("<td></td>"); //item filename
      itemsBuff.push("<td></td>"); //budget cycle
      itemsBuff.push("<td></td>"); //migrated budget cycle
      itemsBuff.push(errList);
      itemsBuff.push("<td></td>"); //download link
      itemsBuff.push("</tr>");
    }
  }
  
  itemsTBody.append(itemsBuff.join(""));
  $('[data-toggle="tooltip"]').tooltip();
}
