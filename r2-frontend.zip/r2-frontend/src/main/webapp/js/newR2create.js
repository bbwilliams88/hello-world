var activityJson;
var budgetCycleJson;
var r2SupportEmailAddress;

/*
  This newActivityJson endpoint takes a long time (2 minutes) to send a response on local, 
  which causes problems in this create R2 page. This issue along with details and fixes 
  has been documented on the CXE TroubleShooting Issues wiki page, and the Jira ticket CXE-8031. 
  Please refer to those for more information.
*/
$.getJSON('/r2/newActivityJson', function (data) {
  activityJson = data;
});
$.getJSON('/r2/newBudgetCycleJson', function (data) {
  budgetCycleJson = data;
});

function validateCreateForm() {
  var validationObjects = [];
  validationObjects.push(checkAgencyValidation());
  validationObjects.push(checkAppropriationValidation());
  validationObjects.push(checkActivityValidation());
  validationObjects.push(checkPeNumberValidation());
  validationObjects.push(checkPeTitleValidation());
  validationObjects.push(checkR1NumberValidation());
  validationObjects.push(checkUserTagValidation());
  var errors = [];
  for (var i = 0; i < validationObjects.length; i++) {
    if (!validationObjects[i].valid) {
      errors.push(validationObjects[i]);
    }
  }
  if (errors.length === 0) {
    return { 'allGood': true };
  } else {
    return { 'allGood': false, 'errors': errors };
  }
}
function validateAgency() {
  var inputVal = $('#r2CreateAgencySelect').val();
  if (inputVal === 'null') {
    return { 'valid': false, 'message': 'You must select an agency.' };
  }
  return { 'valid': true, 'message': 'This is a valid agency.' };
}
function checkAgencyValidation() {
  var validationObject = validateAgency();
  if (!validationObject.valid) {
    $('#r2CreateAgencySelect').addClass('r2FormInputError');
  } else {
    $('#r2CreateAgencySelect').removeClass('r2FormInputError');
  }
  return validationObject;
}
function validateAppropriation() {
  var inputVal = $('#r2CreateAppropriationSelect').val();
  if (inputVal === 'null') {
    return { 'valid': false, 'message': 'You must select an appropriation.' };
  }
  return { 'valid': true, 'message': 'This is a valid appropriation.' };
}
function checkAppropriationValidation() {
  var validationObject = validateAppropriation();
  if (!validationObject.valid) {
    $('#r2CreateAppropriationSelect').addClass('r2FormInputError');
  } else {
    $('#r2CreateAppropriationSelect').removeClass('r2FormInputError');
  }
  return validationObject;
}
function validateActivity() {
  var inputVal = $('#r2CreateActivitySelect').val();
  if (inputVal === 'null') {
    return { 'valid': false, 'message': 'You must select a budget activity.' };
  }
  return { 'valid': true, 'message': 'This is a valid budget activity.' };
}
function checkActivityValidation() {
  var validationObject = validateActivity();
  if (!validationObject.valid) {
    $('#r2CreateActivitySelect').addClass('r2FormInputError');
  } else {
    $('#r2CreateActivitySelect').removeClass('r2FormInputError');
  }
  return validationObject;
}
function validatePeNumber() {
  var inputVal = $('#r2CreateNumberInput').val();
  var vMessage;
  if (inputVal.length === 0) {
    vMessage = 'The program element number must not be empty.';
    return { 'valid': false, 'message': vMessage };
  }
  if (inputVal.length > 40) {
    vMessage = 'The program element number length can not be greater than 40.';
    return { 'valid': false, 'message': vMessage };
  }
  if (!/^[0-9A-Za-z\(\)\[\]\-\_\#\@\:\.\s]*$/.test(inputVal)) {
    vMessage = 'The program element number contains invalid characters.';
    return { 'valid': false, 'message': vMessage };
  }
  //  var numberPortion = inputVal.substring(0, 7);
  //  var suffixPortion = inputVal.substring(7).toUpperCase();
  //  if (!/^[0-9]{7}$/.test(numberPortion)) {
  //    vMessage = 'The program element number must have the format: 7 digits followed by at least 1 letter.';
  //    return {'valid': false, 'message': vMessage};
  //  }
  //  if (!/^[A-Za-z]\w*/.test(suffixPortion)) {
  //    vMessage = 'The program element number must have the format: 7 digits followed by at least 1 letter.';
  //    return {'valid': false, 'message': vMessage};
  //  }
  //  var selectedAgency = $('#r2CreateAgencySelect').val();
  //  $('#r2CreateNumberInput').val(numberPortion + suffixPortion);
  //  if (selectedAgency === 'null') {
  //    vMessage = 'The program element number\'s suffix depends on the ';
  //    vMessage += 'agency selected. You must select an agency.';
  //    return {'valid': false, 'message': vMessage};
  //  } else {
  //    for (var a = 0; a < activityJson.agencies.length; a++) {
  //      var agency = activityJson.agencies[a];
  //      if (selectedAgency === agency.code) {
  //    	if (agency.suffixes.length<=0){
  //    		return {'valid': true, 'message': 'Valid program element number.'};	
  //    	}
  //    	else {
  //          if ($.inArray(suffixPortion, agency.suffixes) < 0) {
  //            var helpStr = agency.name + ' program element numbers must end with ';
  //            helpStr += agency.suffixes.join(' or ');
  //            return {'valid': false, 'message': helpStr + '.'};
  //          }
  //    	}
  //      }
  //    }
  //  }
  return { 'valid': true, 'message': 'Valid program element number.' };
}
function checkPeNumberValidation() {
  var validationObject = validatePeNumber();
  var vaildationDiv = $('#r2CreateNumberInput').next();
  vaildationDiv.removeClass('r2ValidatorInfo');
  vaildationDiv.removeClass('r2ValidatorError');
  vaildationDiv.removeClass('r2ValidatorGood');
  vaildationDiv.text(validationObject.message);
  if (validationObject.valid) {
    vaildationDiv.addClass('r2ValidatorGood');
    $('#r2CreateNumberInput').removeClass('r2FormInputError');
  } else {
    vaildationDiv.addClass('r2ValidatorError');
    $('#r2CreateNumberInput').addClass('r2FormInputError');
  }
  return validationObject;
}
function validatePeTitle() {
  var inputVal = $('#r2CreateTitleInput').val();
  if (inputVal.length === 0) {
    var vMessage = 'The program element name must not be empty.';
    return { 'valid': false, 'message': vMessage };
  }
  return { 'valid': true, 'message': 'This is a valid program element name.' };
}
function checkPeTitleValidation() {
  var validationObject = validatePeTitle();
  var vaildationDiv = $('#r2CreateTitleInput').next();
  vaildationDiv.removeClass('r2ValidatorInfo');
  vaildationDiv.removeClass('r2ValidatorError');
  vaildationDiv.removeClass('r2ValidatorGood');
  vaildationDiv.text(validationObject.message);
  if (validationObject.valid) {
    vaildationDiv.addClass('r2ValidatorGood');
    $('#r2CreateTitleInput').removeClass('r2FormInputError');
  } else {
    vaildationDiv.addClass('r2ValidatorError');
    $('#r2CreateTitleInput').addClass('r2FormInputError');
  }
  return validationObject;
}

function validateR1Number() {
  var inputVal = $('#r2CreateR1NumInput').val();
  var vMessage;

  if (inputVal.length == 0) {
    vMessage = 'The R-1 Line Number must not be empty.';

    return { 'valid': false, 'message': vMessage };
  }

  if (!/^\d+$/.test(inputVal)) {
    vMessage = 'The R-1 Line Number can only contain numeric values.';

    return { 'valid': false, 'message': vMessage };
  }

  if (inputVal.length > 10) {
    vMessage = 'The R-1 Line Number length can not be greater than 10.';

    return { 'valid': false, 'message': vMessage };

  }

  return { 'valid': true, 'message': 'This is a valid R-1 Line Number.' };
}

function checkR1NumberValidation() {
  var validationObject = validateR1Number();
  var vaildationDiv = $('#r2CreateR1NumInput').next();
  vaildationDiv.removeClass('r2ValidatorInfo');
  vaildationDiv.removeClass('r2ValidatorError');
  vaildationDiv.removeClass('r2ValidatorGood');
  vaildationDiv.text(validationObject.message);
  if (validationObject.valid) {
    vaildationDiv.addClass('r2ValidatorGood');
    $('#r2CreateR1NumInput').removeClass('r2FormInputError');
  } else {
    vaildationDiv.addClass('r2ValidatorError');
    $('#r2CreateR1NumInput').addClass('r2FormInputError');
  }
  return validationObject;
}

function validateUserTag() {
  var inputVal = $('#r2CreateTagInput').val();
  if (inputVal.length !== 0) {
    if (inputVal.length <= 12) {
      return { 'valid': true, 'message': 'Valid User-Defined Tag' };
    } else {
      var vMessage = 'User-defined tag must be fewer than twelve characters.';
      return { 'valid': false, 'message': vMessage };
    }
  }
  return { 'valid': true, 'message': 'optional' };
}

function checkUserTagValidation() {
  var validationObject = validateUserTag();
  var vaildationDiv = $('#r2CreateTagInput').next();
  vaildationDiv.removeClass('r2ValidatorInfo');
  vaildationDiv.removeClass('r2ValidatorError');
  vaildationDiv.removeClass('r2ValidatorGood');
  vaildationDiv.text(validationObject.message);
  if (validationObject.valid) {
    vaildationDiv.addClass('r2ValidatorGood');
    $('#r2CreateTagInput').removeClass('r2FormInputError');
  } else {
    vaildationDiv.addClass('r2ValidatorError');
    $('#r2CreateTagInput').addClass('r2FormInputError');
  }
  return validationObject;
}

function showErrors(errors) {
  var alertText = '<ul>';
  for (var i = 0; i < errors.length; i++) {
    alertText = alertText + '<li>' + errors[i].message + '</li>';
  }
  alertText = alertText + '</ul>';
  $('#r2modalNotValidBody').html(alertText);
  $('#r2modalNotValid').modal();
}

function populateActivitiesSelect(agencyIndex, appIndex) {
  $('#r2CreateActivitySelect')
    .html('<option value="null">Please select a budget activity...</option>');
  var activities = activityJson.agencies[agencyIndex]
    .appropriations[appIndex].budgetactivities;
  var option;
  if (activities.length === 1) {
    option = '<option value="' + activities[0].id + '">';
    option += activities[0].number + ': ' + activities[0].title + '</option>';
    $('#r2CreateActivitySelect').html(option);
  } else {
    for (var i = 0; i < activities.length; i++) {
      option = '<option value="' + activities[i].id + '">';
      option += activities[i].number + ': ' + activities[i].title + '</option>';
      $('#r2CreateActivitySelect').append(option);
    }
  }
}

function initialize() {
  $('#importFromXml').click(function (event) {
    event.preventDefault();
    $('#r2modalImportXml').modal();
  });

  $('#importFromPdf').click(function (event) {
    event.preventDefault();
    $('#r2modalNotImplemented').modal();
  });

  $('#copyExisting').click(function (event) {
    event.preventDefault();
    $('#r2modalNotImplemented').modal();
  });

  $('#r2CreateFormSubmit').click(function (event) {
    event.preventDefault();
    var formVals = {
      'r2-csrf': $('#csrfToken').val(),
      'r2-cycle': $('#r2CreateBudgetCycleSelect').val(),
      'r2-agency': $('#r2CreateAgencySelect').val(),
      'r2-appropriation': $('#r2CreateAppropriationSelect').val(),
      'r2-activity': $('#r2CreateActivitySelect').val(),
      'r2-number': $('#r2CreateNumberInput').val(),
      'r2-title': $('#r2CreateTitleInput').val(),
      'r2-r1num': $('#r2CreateR1NumInput').val(),
      'r2-mdap': $('#r2CreateMdapInput').val(),
      'r2-pydelta': $('#r2CreatePyDeltaInput').val(),
      'r2-r2long': $('#r2CreateR2Long').is(':checked'),
      'r2-tag': $('#r2CreateTagInput').val(),
      'r2-testpe': $('#r2CreateTestPE').is(':checked')
    };
    var validateObject = validateCreateForm();
    if (validateObject.allGood) {
      $.post(
        '/r2/newR2CreateJson', formVals,
        function (data) {
          if (data.id != undefined) {
            window.location = '/r2/peeditangular/' + data.id;
          } else if (typeof data.errorMessages != 'undefined') {
            showErrors(data.errorMessages);
          } else {
            showErrors([{ "message": "Unknown server error has occured, Please contact R2 Support at " + r2SupportEmailAddress }]);
          }
        }
      );
    } else {
      console.log(validateObject.errors);
      showErrors(validateObject.errors);
    }
  });
}

function changeInit() {
  $('#r2CreateBudgetCycleSelect').change(function () {
    var selectedCycle = $(this).val();
    for (var i = 0; i < budgetCycleJson.cycles.length; i++) {
      var cycle = budgetCycleJson.cycles[i];
      if (selectedCycle === cycle.label) {
        $('#r2submissionDateValue')
          .text(cycle.SubmissionDates[cycle.SubmissionDates.length - 1]);
      }
    }
  });
  $('#r2CreateAgencySelect').change(function () {
    $('#r2CreateAppropriationSelect').css('border', '1px solid #ccc');
    $('#r2CreateActivitySelect').css('border', '1px solid #ccc');
    var selectedAgency = $(this).val();
    $('#r2CreateAppropriationSelect').html('<option value="null"></option>');
    $('#r2CreateActivitySelect').html('<option value="null"></option>');
    for (var a = 0; a < activityJson.agencies.length; a++) {
      var agency = activityJson.agencies[a];
      var option;
      if (selectedAgency === agency.code) {
        var appropriation;
        if (agency.appropriations.length === 1) {
          appropriation = agency.appropriations[0];
          option = '<option value="' + appropriation.id + '">';
          option += appropriation.code + ': ' + appropriation.name + '</option>';
          $('#r2CreateAppropriationSelect').html(option);
          populateActivitiesSelect(a, 0);
        } else {
          var nullOption = '<option value="null">Please select an ';
          nullOption += 'appropriation...</option>';
          $('#r2CreateAppropriationSelect').html(nullOption);
          for (var b = 0; b < agency.appropriations.length; b++) {
            appropriation = agency.appropriations[b];
            option = '<option value="' + appropriation.id + '">';
            option += appropriation.code + ': ' + appropriation.name;
            option += '</option>';
            $('#r2CreateAppropriationSelect').append(option);
          }
        }
      }
    }
    checkAgencyValidation();
  });

  $('#r2CreateAppropriationSelect').change(function () {
    var selectedAgency = $('#r2CreateAgencySelect').val();
    var selectedAppropriation = $(this).val();
    for (var a = 0; a < activityJson.agencies.length; a++) {
      var agency = activityJson.agencies[a];
      if (selectedAgency === agency.code) {
        for (var b = 0; b < agency.appropriations.length; b++) {
          var appropriation = agency.appropriations[b];
          if (parseInt(selectedAppropriation) === appropriation.id) {
            populateActivitiesSelect(a, b);
          }
        }
      }
    }
    checkAgencyValidation();
    checkAppropriationValidation();
  });

  $('#r2CreateActivitySelect').change(function () {
    checkAgencyValidation();
    checkAppropriationValidation();
    checkActivityValidation();
  });

  $('#r2CreateNumberInput').change(function () {
    checkPeNumberValidation();
  });

  $('#r2CreateTitleInput').change(function () {
    checkPeTitleValidation();
  });

  $('#r2CreateR1NumInput').change(function () {
    checkR1NumberValidation();
  });

  $('#r2CreateTagInput').change(function () {
    checkUserTagValidation();
  });
} // changeInit() end

function setR2SupportEmailAddress(s) {
  r2SupportEmailAddress = s;
}