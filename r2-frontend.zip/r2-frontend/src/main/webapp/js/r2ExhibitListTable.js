var r2ExhibitsTableLinks;

function r2ExhibitTablePageInit(urlJson){
  //R2Exhibit List Table
	r2ExhibitsTableLinks = urlJson;
  var r2ExhibitTable = $("#r2ExhibitTable").DataTable({
    "order": [[ 12, 'desc' ]],
    "autoWidth": false,
    "serverSide": false,
    "stateSave": true,
    "language": {
      "emptyTable": "No results found."
    },
    "deferRender": true,
    "ajax": {
      "url": r2ExhibitsTableLinks.r2ExhibitTableDataUrl,
      "type": "POST"
    },
    "createdRow": function(row, data, index){
      var checkbox = $(row).find(".r2PESelectionCheckbox");
      var api = this.api();
      checkbox.unbind("click");
      checkbox.click(function(e){
        r2ExhibitSelected($(this),api.data());
      });
    },
	"sDom": 'B<"H"lfr>t<"F"ip>',
	"buttons" : [{
		"extend" :'colvis',
		"text" : "Columns",
		"columns" : ":gt(0)",    // This is hiding the selection column on the left from the column visibility options
		"columnText" : function(dt, idx, title){
			if(title.indexOf('Agency') != -1){
				return "Agency";
			}
			
			if(title.indexOf('Budget Cycle') != -1){
				return "Budget Cycle";
			}
			
			return title;
		}
	}],
    "columns": [
          { "data": "selected",
            "bSearchable":false,
            "bSortable":false,
            "sClass": "r2List_checkbox",
            "visible":true,
            "render": function(data, type, full, meta){
              var selectedText = '';
              if (full.selected)
              {
                selectedText = ' checked="checked"';
              }
              return '<input type="checkbox" class="r2PESelectionCheckbox" value="'+meta.row+'"'+selectedText+'/>';
            },
            "defaultContent":""
          },
                { "data": "lineNum",
                  "searchable":true,
                  "orderable":true,
                  "sClass": "r2List_r1num",
                  "visible":true
                },
                { "data": "number",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_number",
                  "visible":true,
                  "render": function(data, type, full, meta){
                    var numberCellStr = full.number;
                    return numberCellStr.concat(getExhibitIcons(data, type, full, meta));
                  },
                  "defaultContent":""
                },
                { "data": null,
                  "bSearchable":false,
                  "bSortable":false,
                  "sClass": "r2List_exhibitBadges",
                  "visible":false,
                  "render": function(data, type, full, meta){
                    return getExhibitTypeBadges(data, type, full, meta);
                  },
                  "defaultContent": "<span>Exhibit Types</span>"
                },
                { 
                  "data": "title",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_title",
                  "visible":true,
                  "render": function(data,type,full, meta){
                    var titleStr = full.title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                    	.replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/-/g, "&ndash;").replace(/,/g, "&sbquo;");
                    if (typeof full.title == 'undefined' || full.title == null) {
                      titleStr = "";
                    }
                    if (titleStr.length > 40) {
                      return '<span data-toggle="tooltip" title="'+titleStr+'">'+(titleStr).substr(0,38)+'...</span>';
                    }
                    else
                    {
                      return '<span data-toggle="tooltip" title="'+titleStr+'">'+titleStr+'</span>';
                    }
                  },
                  "defaultContent":""
                  
                },
                { 
                  "data": "baNum",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_budgetactivity",
                  "visible":true
                },
                { 
                  "data": "numProjects",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_numprojects",
                  "visible":false
                },
                { "data": "serviceAgencyCode",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_agency",
                  "visible":true,
                  "render": function(data, type, full, meta)
                  {
                    return "<span data-toggle='tooltip' title='"+full.serviceAgencyName+"'>"+full.serviceAgencyCode+"</span>";
                  },
                  "defaultContent":""
                }, 
                { "data": "budgetCycle",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_budgetcycle",
                  "visible":true,
                  "render": function(data, type, full, meta)
                  {
                    return full.budgetCycle+" "+full.budgetYear;
                  },
                  "defaultContent":""
                },
                {
                  "data": "creatorDisplayName",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_createdby",
                  "visible":false
                },
                {
                  "data": "formattedDateCreated",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_datecreated",
                  "visible":false
                },
                {
                  "data": "modifierDisplayName",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_modifiedby",
                  "visible":false
                },
                {
                  "data": "formattedDateModified",
                  "bSearchable":true,
                  "bSortable":true,
                  "sClass": "r2List_datemodified",
                  "visible":true
                }
                ]
    
  });
  
  $("#r2ServiceAgencyFilter").change(function (e){
    var filterText = $("#r2ServiceAgencyFilter :selected").attr('value');
    console.log("filterText:"+filterText);
    if (filterText==null || filterText =='undefined'){
      filterText = "";
    }
    r2ExhibitTable.column(".r2List_agency").search(filterText).draw();
  });
  
  $("#r2BudgetCycleFilter").change(function (e){
    var filterText = $("#r2BudgetCycleFilter :selected").attr('value');
    filterText = URLEncoder.encode(filterText);
    $.ajax({
      url: r2ExhibitsTableLinks.budgetCycleChangedUrl+"/"+filterText,
      type: "GET",
      success: function(response){
        r2ExhibitTable.ajax.reload();
      },
      error : function(data){
        console.log(data);
        var errorStr = "An unexpected error occurred: "+data;
        $("#errorMessage").append(errorStr);
        $("#errorMessage").show();
      }
    });
  });
};