/*
 * $Id: Util.java 32381 2009-10-07 14:21:54Z aahmed $
 */
package mil.dtic.utility.tapestry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.cayenne.util.HashCodeBuilder;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import ognl.Ognl;
import ognl.OgnlException;

public class TapestryUtil {
  private static final Logger log = CbesLogFactory.getLog(TapestryUtil.class);

  /**
   * Sort a list using ognl to get toString versions of some property of the
   * member objects.<br/> <br/> Example, a House object with an owner and
   * houseAge property, sort by age of owner, then age of house:<br/> <tt>
   * List&lt;House&gt; houses = whatever;<br/>
   * ognlsort(houses, true, "owner.age","houseAge");<br/>
   * </tt>
   * 
   * @param properties
   *          ognl specifications of properties to sort by, in order of priority
   * @throws OgnlException
   *           wrapped in a RuntimeException, if you messed up the ognl property
   */
  public static void ognlsort(List<? extends Object> list, final boolean asc, final String ... properties)
  {
    if (list == null || properties == null || properties.length < 1)
      throw new IllegalArgumentException();

    Comparator<Object> c = new Comparator<Object>()
    {
      public int compare(Object o1, Object o2)
      {
        try
        {
          int result = 0;
          for (String property : properties)
          {
            String v1 = Ognl.getValue(property, o1).toString();
            String v2 = Ognl.getValue(property, o2).toString();
            if (asc)
              result = v1.compareToIgnoreCase(v2);
            else
              result = v2.compareToIgnoreCase(v1);
            // loop back to next sort property if the first were equal
            if (result != 0)
              return result;
          }
          // been trying to avoid returning 0 but oh well
          return result;
        }
        catch (OgnlException e)
        {
          log.error("Ognl sorting error", e);
          throw new RuntimeException(e);
        }
      }

      @Override
      public int hashCode()
      {
          return new HashCodeBuilder(17, 37).append(this).toHashCode();
      }

      @Override
      public boolean equals(Object obj)
      {
        return compare(this, obj) == 0;
      }
    };

    Collections.sort(list, c);
  }


  /**
   * Similar to {@link #ognlsort(List, boolean, String)}, but assumes the
   * property is a Comparable object.
   * 
   * @throws OgnlException
   *           wrapped in a RuntimeException, if you messed up the ognl property
   * @throws ClassCastException
   *           if the property you specified is not Comparable
   */
  public static void ognlsortcomparable(List<? extends Object> list, final String property, final boolean asc)
  {

    Comparator<Object> c = new Comparator<Object>()
    {
      public int compare(Object o1, Object o2)
      {
        try
        {
          Comparable v1 = (Comparable) Ognl.getValue(property, o1);
          Comparable v2 = (Comparable) Ognl.getValue(property, o2);
          if (asc)
            return v1.compareTo(v2);
          else
            return v2.compareTo(v1);
        }
        catch (OgnlException e)
        {
          log.error("Ognl sorting error", e);
          throw new RuntimeException(e);
        }
      }

      @Override
      public int hashCode()
      {
        return new HashCodeBuilder(17, 37).append(this).toHashCode();
      }

      @Override
      public boolean equals(Object obj)
      {
        return compare(this, obj) == 0;
      }
    };

    Collections.sort(list, c);
  }


  /**
   * Takes a collection of parent objects, and extracts a subobject of each and
   * places them in a Set.
   * 
   * @param <T>
   *          the type of the subobject
   * @param coll
   *          the collection of parent objects
   * @param property
   *          ognl specification of subobject
   * @return Set containing subjects
   * @throws OgnlException
   *           wrapped in a RuntimeException, if you messed up the ognl property
   * @throws ClassCastException
   *           if you mess up the subobject type
   */
  public static <T> Set<T> ognlsettransform(Collection<?> coll, String property)
  {
    try
    {
      Set<T> set = new HashSet<T>(coll.size());
      for (Object each : coll)
      {
        set.add((T) Ognl.getValue(property, each));
      }
      return set;
    }
    catch (OgnlException e)
    {
      log.error("Ognl set transform error", e);
      throw new RuntimeException("Ognl set transform error", e);
    }
  }


  /**
   * Takes a collection of parent objects, and extracts a subobject of each and
   * places them in a List.
   * 
   * @param <T>
   *          the type of the subobject
   * @param coll
   *          the collection of parent objects
   * @param property
   *          ognl specification of subobject
   * @return List containing subjects
   * @throws OgnlException
   *           wrapped in a RuntimeException, if you messed up the ognl property
   * @throws ClassCastException
   *           if you mess up the subobject type
   */
  public static <T> List<T> ognllisttransform(Collection<?> coll, String property)
  {
    try
    {
      List<T> list = new ArrayList<T>(coll.size());
      for (Object each : coll)
      {
        list.add((T) Ognl.getValue(property, each));
      }
      return list;
    }
    catch (OgnlException e)
    {
      log.error("Ognl list transform error", e);
      throw new RuntimeException("Ognl list transform error", e);
    }
  }


  /**
   * Takes a collection of parent objects, and extracts a subobject of each and
   * places them in another collection.
   * 
   * @param <T>
   *          the type of the subobject
   * @param src
   *          the collection of parent objects
   * @param dest
   *          the collection to add the subobjects to
   * @param property
   *          ognl specification of subobject
   * @return the collection passed in as dest
   * @throws OgnlException
   *           wrapped in a RuntimeException, if you messed up the ognl property
   * @throws ClassCastException
   *           if you mess up the subobject type
   */
  public static <T> Collection<T> ognlcolltransform(Collection<?> src, Collection<T> dest, String property)
  {
    try
    {
      for (Object each : src)
      {
        dest.add((T) Ognl.getValue(property, each));
      }
      return dest;
    }
    catch (OgnlException e)
    {
      log.error("Ognl collection transform error", e);
      throw new RuntimeException("Ognl collection transform error", e);
    }
  }
  
  /**
   * Sorts a set by copying to list, sorting, then addAlling back to the set.
   * The set is assumed to have the ability to preserve order.
   */
  public static <T> void sortSet(Set<T> set, String ognlproperty, boolean asc)
  {
    List<T> list = Util.toArrayList(set);
    ognlsortcomparable(list, ognlproperty, asc);
    set.clear();
    set.addAll(list);
  }

  /**
   * Sorts a list by copying to list, sorting, then addAlling back to the set.
   * The set is assumed to have the ability to preserve order.
   */
  public static <T> void sortList(List<T> list, String ognlproperty, boolean asc)
  {
    ognlsortcomparable(list, ognlproperty, asc);
  }
  
  /**
   * returns request session attribute.
   * @param request - HttpServletRequest
   * @param key - String
   * @return Object - session attribute variable
   */
  public static Object getSessionVar(HttpServletRequest request, String key){
      String ctx = request.getContextPath().substring(1);  //path less the leading "/"
      return request.getSession(false).getAttribute(String.format("state:%s:%s",ctx,key));
  }

  /**
   * sets a session attribute 
   * @param request - HttpServletRequest
   * @param key - String
   * @param`value - Object
   * @return void
   */
  public static void setSessionVar(HttpServletRequest request, String key, Object value)  {
    String ctx = request.getContextPath().substring(1); //path less the leading "/"
    request.getSession(false).setAttribute(String.format("state:%s:%s",ctx,key), value);
  }
  
}
