/*
 * $Id$
 */
package mil.dtic.utility;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.Logger;

public class BudgesFilter implements Filter
{

  private static final Logger log = CbesLogFactory.getLog(BudgesFilter.class);


  public void init(FilterConfig filterConfig) throws ServletException
  {
    log.debug("BudgesFilter started.");
  }


  public void destroy()
  {
    log.debug("BudgesFilter stopped.");

  }


  public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException
  {
    if (log.isTraceEnabled())
      dumpRequest((HttpServletRequest)req);
    
    filterChain.doFilter(req, resp);
    
      if (log.isTraceEnabled())
    dumpResponse((HttpServletResponse)resp);
  }


  public void dumpRequest(HttpServletRequest req)
  {
    StringBuilder sb = new StringBuilder("\n===================================================\n*** Request ***\n===================================================\n");
    String query = req.getQueryString();
    query = (query == null) ? "" : query;
    sb.append(req.getMethod() + " " + req.getRequestURL() + query);
    sb.append("\n");
    sb.append("Auth Type: " + req.getAuthType());
    sb.append("\n");
    sb.append("Context Path: " + req.getContextPath());
    sb.append("\n");
    sb.append("Path Info: " + req.getPathInfo());
    sb.append("\n");
    sb.append("Translated Path: " + req.getPathTranslated());
    sb.append("\n");
    sb.append("Servlet Path: " + req.getServletPath());
    sb.append("\n");
    sb.append("Remote User: " + req.getRemoteUser());
    sb.append("\n");
    sb.append("Requested session id: " + req.getRequestedSessionId());
    sb.append("\n");
    sb.append("Is requested session id valid: " + req.isRequestedSessionIdValid());
    sb.append("\n");
    sb.append("Is requested session id from cookie: " + req.isRequestedSessionIdFromCookie());
    sb.append("\n");
    sb.append("User Principal (should be null): " + req.getUserPrincipal());
    sb.append("\n*** Cookies:\n");
    Cookie[] cookies = req.getCookies();
    if (cookies != null)
    {
      for (Cookie cookie : cookies)
      {
        sb.append(cookie.getName() + "=" + cookie.getValue());
        sb.append(" [max age=" + cookie.getMaxAge());
        sb.append(", path=" + cookie.getPath());
        sb.append(", secure=" + cookie.getSecure());
        sb.append(", domain=" + cookie.getDomain());
        sb.append(", version=" + cookie.getVersion());
        sb.append(", comment=" + cookie.getComment() + "]");
      }
    }
    sb.append("\n*** Headers:\n");
    @SuppressWarnings("rawtypes")
    Enumeration headerNames = req.getHeaderNames();
    if (headerNames != null)
    {
      while (headerNames.hasMoreElements())
      {

        String headerName = (String) headerNames.nextElement();
        @SuppressWarnings("rawtypes")
        Enumeration headerValues = req.getHeaders(headerName);
        while (headerValues.hasMoreElements())
        {
          sb.append(headerName + "=" + headerValues.nextElement() + "\n");
        }
      }
    }
    log.trace(sb.toString());
  }
  
  public void dumpResponse(HttpServletResponse resp)
  {
    StringBuilder sb = new StringBuilder("\n===================================================\n*** Response ***\n===================================================\n");
    sb.append("Sent...");
    log.trace(sb.toString());
  }  
}
