/*
 * $Id$
 */
package mil.dtic.utility;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;

public class BudgesHttpSessionListener implements HttpSessionListener
{
  private static final Logger log = CbesLogFactory.getLog(BudgesHttpSessionListener.class);

  Set<HttpSession> allHttpSessions = new HashSet<HttpSession>();

  @Override
public void sessionCreated(HttpSessionEvent event) {
    log.debug("Budges HTTP session created, id=" + event.getSession().getId() +", source=" + event.getSource());
    if (event.getSession().getServletContext().getAttribute(Constants.APPKEY_ALL_SESSIONS) == null)
      event.getSession().getServletContext().setAttribute(Constants.APPKEY_ALL_SESSIONS, allHttpSessions);
    synchronized (allHttpSessions)
    {
      allHttpSessions.add(event.getSession());
    }
  }

  @Override
public void sessionDestroyed(HttpSessionEvent event)
  {
    log.debug("Budges HTTP session about to be destroyed, id=" + event.getSession().getId() +", source=" + event.getSource());
    synchronized (allHttpSessions)
    {
      allHttpSessions.remove(event.getSession());
      UserCredentials uc = (UserCredentials)event.getSession().getAttribute("state:r2:user.credentials");
      if (uc==null || uc.getUserInfo()==null || uc.getUserInfo().getBudgesUser()==null)
      {
        log.error("Could not clear locks, maybe user credentials not found");
        if (uc!=null)
        {
          log.error("UserInfo: " + uc.getUserInfo());
        }
        return;
      }
      clearLocksIfNoDuplicateSessions(uc.getUserInfo().getBudgesUser());
    }

  }

  private void clearLocksIfNoDuplicateSessions(BudgesUser current)
  {
    log.debug("clearLocksIfNoDuplicateSessions");
    for (HttpSession hs : allHttpSessions)
    {
      UserCredentials uc = (UserCredentials)hs.getAttribute("state:r2:user.credentials");
      if (uc==null || uc.getUserInfo()==null)
      {
        log.error("Skipping session with no user credentials or user info id=" + hs.getId());
        log.error(printHS(hs));
        continue;
      }
      BudgesUser b = uc.getUserInfo().getBudgesUser();
      if (b!=null && current!=null && b.getId().equals(current.getId()))
      {
        log.debug("Not clearing locks, user still logged in");
        return;
      }
    }
    log.debug("Clearing locks for user " + current);
    clearLocks(current);
  }

  private void clearLocks(BudgesUser current)
  {
      BudgesContext.getPELockDAO().lockClearAllForUser(current);
  }

  private String printHS(HttpSession hs)
  {
      if (hs!=null)
      {
        StringBuilder sb = new StringBuilder();
        sb.append("HttpSession{");
        Enumeration<String> e = hs.getAttributeNames();
        while (e.hasMoreElements())
        {
          Object o = hs.getAttribute(e.nextElement());
          sb.append(o);
          sb.append(",");
        }
        sb.append("}");
        return sb.toString();
      }
    return "null";
  }
}
