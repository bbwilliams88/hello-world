/* 
 * $Id$
 */
package mil.dtic.utility;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;

public class FirstFilter implements Filter
{

  private static final Logger log = CbesLogFactory.getLog(FirstFilter.class);


  public void init(FilterConfig filterConfig) throws ServletException
  {
    log.error("FirstFilter started...");
  }


  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
  {
    StringBuffer sb = new StringBuffer("\n\n--Request Headers--\n");
    HttpServletRequest hr = (HttpServletRequest)servletRequest;
    Enumeration headerNames = hr.getHeaderNames();
    while (headerNames != null && headerNames.hasMoreElements())
    {
      String header = (String)headerNames.nextElement();
      Enumeration headerValues = hr.getHeaders(header);
      while (headerValues != null && headerValues.hasMoreElements())
      {
        sb.append(header + ":" + headerValues.nextElement() + "\n");
      }
    }
    log.error(sb);
    filterChain.doFilter(servletRequest, servletResponse);
  }


  public void destroy()
  {
    log.debug("FirstFilter ended.");

  }
}