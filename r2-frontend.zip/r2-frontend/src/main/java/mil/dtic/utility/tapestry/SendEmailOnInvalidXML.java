/*
 * $Id: XmlUtil.java 32173 2009-08-24 16:40:16Z aibrahim $
 */
package mil.dtic.utility.tapestry;

import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;

import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;
import mil.dtic.utility.InvalidXMLListener;


public class SendEmailOnInvalidXML implements InvalidXMLListener
{
  private static final Logger log = CbesLogFactory.getLog(SendEmailOnInvalidXML.class);
  
  private final UserCredentials creds;
  
  public SendEmailOnInvalidXML(UserCredentials creds)
  {
    if (creds==null) throw new IllegalArgumentException();
    this.creds = creds;
  }
  
  public void onInvalidXML(String root, String msg, String xmlFileName)
  {
    try
    {
        BudgesContext.getEmailUtil().sendSystemEmail("*** XML Validation Failure Notice [" + root + "] ***", msg.toString(), creds);
      log.error("Invalid XML file written to: " + xmlFileName);
    }
    catch (EmailException e)
    {
      log.error("Could not send failed R2 XML validation email", e);
    }
  }
}
