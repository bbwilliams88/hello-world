package mil.dtic.cbes.submissions.t5.encoders;

import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.p40.vo.IBase;
import mil.dtic.utility.CbesLogFactory;

//Instead of map that also needs to be stored in session, do an O(n) search on the list of objects
//presumably that's also stored in session, otherwise this class won't work
//that way this encoder itself won't need to be stored in session

public class ListUUIDEncoder<T extends IBase> implements ValueEncoder<T>
{
  private static final Logger log = CbesLogFactory.getLog(ListUUIDEncoder.class);
  private final List<T> list;
  
  public ListUUIDEncoder(List<T> list)
  {
    this.list = list;
  }

  public String toClient(T value)
  {
    log.trace("toClient " + value);
    if (value.getT5Id()==null) {
      value.setT5Id(UUID.randomUUID().toString());
    }
    return value.getT5Id();
  }

  public T toValue(String key)
  {
    log.trace("toValue " + key);
    for (T obj : list)
    {
      if (key.equals(obj.getT5Id())) return obj;
    }
    throw new IllegalArgumentException(key + " not found in list");
  }
}