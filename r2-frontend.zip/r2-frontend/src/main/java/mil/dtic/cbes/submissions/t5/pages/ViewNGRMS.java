package mil.dtic.cbes.submissions.t5.pages;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.P1Data;
import mil.dtic.cbes.submissions.ValueObjects.R1Data;
import mil.dtic.cbes.submissions.dao.P1DataDAO;
import mil.dtic.cbes.submissions.dao.R1DataDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BigDecimalUtil;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * View PRCP data in the database for a given year.
 */
@Import( stack   = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DATATABLESBUTTONS },
library = { "context:/js/viewNGRMS.js" })
public class ViewNGRMS extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(ViewNGRMS.class);

  @Inject
  private R1DataDAO r1DAO;
  @Inject
  private P1DataDAO p1DAO; 
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private ComponentResources resources;

  @Property
  @Persist
  private Integer budgetYear;
  
  @Property
  @Persist
  private String budgetCycleAndYear;
  
  @Property
  @Persist
  private List<R1Data> r1Rows;
  @Property
  @Persist
  private List<P1Data> p1Rows;

  void onDeleteR1Data() {
	  if (getUserCredentials().getPrivs().showAdminTools()) {
		int bYear = Util.getCurrentBudgetCycle().getBudgetYear();
        r1DAO.deleteData(bYear);
	  }   
  }
  
  void onDeleteP1Data() {
	  if (getUserCredentials().getPrivs().showAdminTools()) {
         p1DAO.deleteData();
	  }    
  }
  
  void onActivate() { 
	budgetYear = Util.getCurrentBudgetCycle().getBudgetYear();
    budgetCycleAndYear = Util.getCurrentBudgetCycle().getValue();
    
    if(getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES)) {
      r1Rows = r1DAO.findByProperty(R1Data.BUDGET_YEAR, budgetYear);
      p1Rows = p1DAO.findByProperty(P1Data.BUDGET_YEAR, budgetYear);
    }
    else {
      if(!CollectionUtils.isEmpty(getUserCredentials().getUserInfo().getAvailableRdteAgencies())) {
        r1Rows = r1DAO.findAllForYearAndOrganizations(budgetYear, getUserCredentials().getUserInfo().getAvailableRdteAgencies());
      }
      else {
        r1Rows = new ArrayList<R1Data>();
      }
      if(!CollectionUtils.isEmpty(getUserCredentials().getUserInfo().getAvailableProcurementAgencies())) {
        p1Rows = p1DAO.findAllForYearAndOrganizations(budgetYear, getUserCredentials().getUserInfo().getAvailableProcurementAgencies());
      }
      else {
        p1Rows = new ArrayList<P1Data>();
      }
    }
  }

  void afterRender() {
    jsSupport.addScript("r1TableInit('%s')", resources.createEventLink("R1Ajax").toString());
    jsSupport.addScript("p1TableInit('%s');", resources.createEventLink("P1Ajax").toString());
  }

  JSONObject onR1Ajax(){
    JSONObject resp = new JSONObject();
    JSONArray rows = new JSONArray();

    if (CollectionUtils.isNotEmpty(r1Rows)) {
      R1Data currentR1Data = r1Rows.get(0);
      JSONObject totalRow = null;

      for (R1Data row : r1Rows) {
        if (!currentR1Data.getPeNumber().equals(row.getPeNumber())) {
          rows.put(totalRow);
          totalRow = null;
        }
   
        JSONObject dtRow = new JSONObject();

        if (totalRow == null) {
          totalRow = new JSONObject();

          totalRow.put("organization", row.getOrganization());
          totalRow.put("account", row.getAccount());
          totalRow.put("budgetActivity", row.getBudgetActivity());
          totalRow.put("lineNumber", row.getLineNumber());
          totalRow.put("peNumber", row.getPeNumber());
          totalRow.put("projectNumber", "PETotal");
          totalRow.put("py", "0.00");
          totalRow.put("cy", "0.00");
          totalRow.put("by1Base", "0.00");
          totalRow.put("by1OOC", "0.00");
          totalRow.put("by1", "0.00");
          totalRow.put("by2", "0.00");
          totalRow.put("by3", "0.00");
          totalRow.put("by4", "0.00");
          totalRow.put("by5", "0.00");
        }

        dtRow.put("organization", row.getOrganization());
        dtRow.put("account", row.getAccount());
        dtRow.put("budgetActivity", row.getBudgetActivity());
        dtRow.put("lineNumber", row.getLineNumber());
        dtRow.put("peNumber", row.getPeNumber());
        dtRow.put("projectNumber", row.getProjectNumber());

        dtRow.put("py", bdToString(row.getPyAmount()));
        totalRow.put("py", bdToString(
            BigDecimalUtil.add(row.getPyAmount(), new BigDecimal(totalRow.get("py").toString()))));

        dtRow.put("cy", bdToString(row.getCyAmount()));
        totalRow.put("cy", bdToString(
            BigDecimalUtil.add(row.getCyAmount(), new BigDecimal(totalRow.get("cy").toString()))));

        dtRow.put("by1Base", bdToString(row.getBy1BaseAmount()));
        totalRow.put("by1Base", bdToString(BigDecimalUtil.add(row.getBy1BaseAmount(),
            new BigDecimal(totalRow.get("by1Base").toString()))));

        dtRow.put("by1OOC", bdToString(row.getBy1OOCAmount()));
        totalRow.put("by1OOC", bdToString(BigDecimalUtil.add(row.getBy1OOCAmount(),
            new BigDecimal(totalRow.get("by1OOC").toString()))));

        dtRow.put("by1", bdToString(row.getBy1Amount()));
        totalRow.put("by1", bdToString(BigDecimalUtil.add(row.getBy1Amount(),
            new BigDecimal(totalRow.get("by1").toString()))));

        dtRow.put("by2", bdToString(row.getBy2Amount()));
        totalRow.put("by2", bdToString(BigDecimalUtil.add(row.getBy2Amount(),
            new BigDecimal(totalRow.get("by2").toString()))));

        dtRow.put("by3", bdToString(row.getBy3Amount()));
        totalRow.put("by3", bdToString(BigDecimalUtil.add(row.getBy3Amount(),
            new BigDecimal(totalRow.get("by3").toString()))));

        dtRow.put("by4", bdToString(row.getBy4Amount()));
        totalRow.put("by4", bdToString(BigDecimalUtil.add(row.getBy4Amount(),
            new BigDecimal(totalRow.get("by4").toString()))));

        dtRow.put("by5", bdToString(row.getBy5Amount()));
        totalRow.put("by5", bdToString(BigDecimalUtil.add(row.getBy5Amount(),
            new BigDecimal(totalRow.get("by5").toString()))));

        rows.put(dtRow);

        currentR1Data = row;
      }
    }
    resp.put("aaData", rows);
    
    return resp;
  }

  JSONObject onP1Ajax() {
    JSONObject resp = new JSONObject();
    JSONArray rows = new JSONArray();
    if(CollectionUtils.isNotEmpty(p1Rows)) {
      for(P1Data row : p1Rows) {
        JSONObject dtRow = new JSONObject();
        dtRow.put("organization", row.getOrganization());
        dtRow.put("account", row.getAccount());
        dtRow.put("budgetActivity", row.getBudgetActivity());
        dtRow.put("budgetSubActivity", row.getBudgetSubActivity());
        dtRow.put("lineNumber", row.getLineNumber());
        dtRow.put("liNumber", row.getLiNumber());
        dtRow.put("costType", row.getCostType());
        dtRow.put("py", bdToString(row.getPyAmount()));
        dtRow.put("cy", bdToString(row.getCyAmount()));
        dtRow.put("by1Base", bdToString(row.getBy1BaseAmount()));
        dtRow.put("by1OOC", bdToString(row.getBy1OOCAmount()));
        dtRow.put("by1", bdToString(row.getBy1Amount()));
        dtRow.put("by2", bdToString(row.getBy2Amount()));
        dtRow.put("by3", bdToString(row.getBy3Amount()));
        dtRow.put("by4", bdToString(row.getBy4Amount()));
        dtRow.put("by5", bdToString(row.getBy5Amount()));
        rows.put(dtRow);
      }
    }
    resp.put("aaData", rows);
    return resp;
  }
  
  private String bdToString(BigDecimal bd) {
    String s = "";
    if(bd != null) {
 //     s = bd.movePointLeft(3).setScale(3).toString();
      s = bd.toString();
    }
    return s;
  }
}