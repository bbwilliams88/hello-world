package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.mail.EmailException;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Cached;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndServiceAgencyLink;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.AgencyEncoder;
import mil.dtic.cbes.submissions.t5.models.ServiceAgencySelectModel;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.tapestry.TapestryUtil;
import netscape.ldap.LDAPException;

@Import(stylesheet={"context:/css/NewNotRegisteredPage.css"}, library = { "context:js/newR2Import.js"})
public class NewNotRegisteredPage extends T5Base {
    // TODO Update Logger when NewAdminLogLevel page is merged
    private static final Logger log = CbesLogFactory.getLog(NewNotRegisteredPage.class);

    // List of Service Agency options
    @Property
    private List<ServiceAgency> organizations;

    // Store the user's selection
    @Property @Persist
    private ServiceAgency selectedOrganization;

    // Status of registration request
    @Property @Persist
    private String statusMsg;
    @Property @Persist
    private boolean evilStatusMsg;

    // Requesting user's email address
    @Property @Persist
    private String userEmail;

    // Requesting user's ldap id
    @Property @Persist
    private String ldapId;
    
    /**
     * @brief When the page is loaded
     */
    public void onActivate()
    {
        log.debug("Activating NewNotRegisteredPage");
        
        //populate organizations
        this.organizations = BudgesContext.getServiceAgencyDAO().findAllRDTEAndProcurement();// findAllRDTE();

        // Initialize userEmail
        if(this.userEmail == null) this.userEmail = getUserCredentials().getUserInfo().getLdapUser().getEmailAddress();

        // Initialize ldapId
        if(this.ldapId == null) this.ldapId = getUserCredentials().getUserInfo().getLdapUser().getLdapUserId();
    }

    /**
     * @brief When the AgencyAuthorizationForm is submitted, try to send the email
     */
    public void onSuccessFromAgencyAuthorizationForm()
    {
        log.debug("onSuccess");

        try {
            createOrUpdateUser();
            List<LdapUser> adminLdapUsers = gatherAdminLdaps();
            sendRegEmail(adminLdapUsers);
            
            this.statusMsg = "Your request has been submitted, and an email has been sent to an administrator.";
            this.evilStatusMsg = false;
            return;
        } catch (LDAPException e) {
            log.error("LDAP error fetching admins for unregistered user", e);
        } catch (EmailException e) {
            log.error("Error sending emails to admins", e);
        }
        this.statusMsg = "An error occurred. Your request was not submitted";
        this.evilStatusMsg = true;
    }
    
    /**
     * @brief If the user isn't in the CXE DB, add them, otherwise update their status to `New`
     */
    private void createOrUpdateUser()
    {
        log.debug("createOrUpdateUser function");
        BudgesUser b = BudgesContext.getBudgesUserDAO().findByUserLdapId(this.ldapId);
        if (b==null)
        {
            log.debug("createOrUpdateUser --> create");
            b = BudgesUser.createTransient(getUserCredentials().getUserInfo().getLdapUser());
            b.setLastVisitDate(new Date());
            b.setStatusFlag(StatusFlag.NEW);
            b.getAgencies().add(this.selectedOrganization);
        }
        else
        {
            log.debug("createOrUpdateUser --> update");
            b.setStatusFlag(StatusFlag.NEW); //overwrite D flag
            //switch agency
            b.getAgencies().clear();
            b.getAgencies().add(this.selectedOrganization);
        }
        BudgesContext.getBudgesUserDAO().saveOrUpdate(b);
        BudgesContext.getBudgesUserDAO().evict(b);
    }
    
    /**
     * @brief Gather LdapUser objects of admins so they can be emailed
     * 
     * @throws LDAPException Error retrieving LdapUser objects
     */
    private List<LdapUser> gatherAdminLdaps() throws LDAPException
    {
        log.debug("gatherAdminLdaps function");
        String[] allAdminIds = BudgesContext.getLdapDAO().getAllAdminUserIds();
        List<BudgesUser> allAdmins =
        BudgesContext.getBudgesUserDAO().findByUserLdapIds(allAdminIds);
        List<BudgesUserAndServiceAgencyLink> links = BudgesContext.getBudgesUserAndServiceAgencyLinkDAO().findByBudgesUsersAndAgency(allAdmins, this.selectedOrganization.getId());
        //now links only has the admins we want
        //get their emails
        List<LdapUser>  adminLdaps = new ArrayList<LdapUser>(links.size());
        for (BudgesUserAndServiceAgencyLink link : links) {
            if (!link.getBudgesUser().getStatusFlag().isActive()) {
                //don't email inactive users
                continue;
            }
            LdapUser luser = BudgesContext.getLdapDAO().getLdapUser(
                link.getBudgesUser().getUserLdapId());
            adminLdaps.add(luser);
        }
        
        return adminLdaps;
    }
    
    /**
     * @brief Decides whether to email admins or just r2support, then does so
     * 
     * @param adminLdaps List of LdapUser objects
     * @throws EmailException If failed to send email(s)
     */
    private void sendRegEmail(List<LdapUser> adminLdaps) throws EmailException
    {
        log.debug("Sending registration email for service agency: " + this.selectedOrganization.getName());
        
        String r2support = BudgesContext.getEmailUtil().resolveEmail(BudgesContext.getConfigService().getEmailTo(), getUserCredentials());
        boolean sendToAdmins = BudgesContext.getConfigService().getRegistrationEmailToAdmins();
        boolean sendToUser = BudgesContext.getConfigService().getRegistrationEmailToUser();
        
        String adminUidsLine = "";
        if (!BudgesContext.getConfigService().isProd()) {
            //list receiving admins in dev/local
            adminUidsLine = "Recipients: " +
            TapestryUtil.ognllisttransform(adminLdaps, LdapUser.LDAP_USER_ID).toString() + "\n";
        }
        
        if (sendToAdmins) {
            log.debug("Send email to admins and r2 support...");
            
            List<String> adminEmails = TapestryUtil.ognllisttransform(adminLdaps, LdapUser.EMAIL_ADDRESS);
            adminEmails.add(r2support);
            
            BudgesContext.getEmailUtil().sendRegEmail(getUserCredentials(), this.selectedOrganization, adminEmails.size()>1, adminUidsLine, sendToUser ? new String[]{this.userEmail} : new String[0], adminEmails.toArray(new String[0]));
        }

        else {
            log.debug("Send email to r2support...");
            BudgesContext.getEmailUtil().sendRegEmail(getUserCredentials(), this.selectedOrganization, false, adminUidsLine, sendToUser ? new String[]{this.userEmail} : new String[0], r2support);
        }
    }

    /**
     * @brief Create T5 SelectModel --> ServiceAgencySelectModel
     * 
     * @return new ServiceAgencySelectModel object
     */
    public SelectModel getServiceAgencySelectModel()
    {
        return new ServiceAgencySelectModel(getAvailableRdteAgencies());
    }

    /**
     * @brief Create T5 ValueEncoder --> AgencyEncoder
     * 
     * @return new AgencyEncoder object
     */
    @Cached
    public ValueEncoder<ServiceAgency> getAgencyEncoder()
    {
        log.debug("getAgencyEncoder");
        return new AgencyEncoder(getAvailableRdteAgencies());
    }

    /**
     * @brief Used by tapestry for if statements
     * 
     * @return true if User status is NOT `New` or `Active`, else false
     */
    public boolean isNotNewOrActive()
    {
        BudgesUser b = BudgesContext.getBudgesUserDAO().findByUserLdapId(this.ldapId);
        return b!=null && !b.getStatusFlag().isNew() && !b.getStatusFlag().isActive();
    }

    /**
     * @brief Used by tapestry for if statements
     * 
     * @return true if User status is `New`, else false
     */
    public boolean isNewUser()
    {
        BudgesUser b = BudgesContext.getBudgesUserDAO().findByUserLdapId(this.ldapId);
        return b!=null && b.getStatusFlag().isNew() ;
    }

    /**
     * @brief Used by tapestry for if statements
     * 
     * @return true if User status is `Active`, else false
     */
    public boolean isActiveUser()
    {
        BudgesUser b = BudgesContext.getBudgesUserDAO().findByUserLdapId(this.ldapId);
        return b!=null && b.getStatusFlag().isActive();
    }

    /**
     * @brief Used by tapestry for if statements
     * 
     * @return true if statusMsg is not null or empty, else false
     */ 
    public boolean isStatusMsgSet()
    {
        return this.statusMsg != null && !statusMsg.isEmpty();
    }

    /**
     * @brief 
     * 
     * @return
     */
    public boolean isStatusMsgEvil()
    {
        return this.evilStatusMsg;
    }
}
