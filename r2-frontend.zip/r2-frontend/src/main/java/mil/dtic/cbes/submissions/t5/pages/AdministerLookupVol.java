package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgencyApp;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

@Import( stack   = { CbesT5SharedModule.DATATABLESUPDATED },
library = { "context:/js/administerLookupVol.js" })
public class AdministerLookupVol extends ManageAppPropsBase{

	  @Inject
	  private ServiceAgencyDAO serviceAgencyDAO;	
	  
	  @Property(read = true)
	  private ServiceAgency serviceAgencyEntry;
	  
	  @Property(read = true)
	  private ServiceAgencyApp serviceAgencyAppEntry;
	  
	  @Property
	  private int rowIndex;
	  
	  @Property
	  private List<ServiceAgency> serviceAgencyList;
	  
	  @Property
	  private List<ServiceAgencyApp> serviceAgencyAppList;
	  
	  @Property
	  private Set<ServiceAgency> serviceAgencySet;
	  
	  @Property
	  private ServiceAgency serviceAgency;
	  
	  @Property
	  private ServiceAgencyApp serviceAgencyApp;
	  
	  @Inject
	  private JavaScriptSupport jsSupport;
	  
	  @Inject
	  private ComponentResources resources;
	  
	  @Property
	  @Persist
	  private List<ServiceAgency> orgRows;
	  
	  List<String> vals;
	  
	  public void onActivate() {
		  
		  if (serviceAgencyList == null){
			  serviceAgencyList = serviceAgencyDAO.findAllRDTEAllStatus();
			  
			  String recType="";

			  serviceAgencyAppList = new ArrayList<ServiceAgencyApp>();

			    if(CollectionUtils.isNotEmpty(serviceAgencyList)) 
			    {
			      for(int x = 0; x < serviceAgencyList.size(); x = x + 1) {
			    	  
			    	for(int y = 0; y < serviceAgencyList.get(x).getAppropriations().size(); y = y + 1) {
			    		
			    	  if(serviceAgencyList.get(x).getAppropriations().get(y).isRdte()){
			    		recType="RDTE"; 
			    	  }else{
			    		recType="Procurement"; 
			    	  }
			    	  
		    	      serviceAgencyApp = new ServiceAgencyApp(); 
				      serviceAgencyApp.setAgencyCode(serviceAgencyList.get(x).getCode().toString()); 
				      serviceAgencyApp.setAgencyName(serviceAgencyList.get(x).getName().toString()); 
				      serviceAgencyApp.setBudgetType(recType);
				      serviceAgencyApp.setStatus(serviceAgencyList.get(x).getStatusFlag().toString());
				      serviceAgencyApp.setAppnCode(serviceAgencyList.get(x).getAppropriations().get(y).getCode().toString());
				      serviceAgencyApp.setAppnName(serviceAgencyList.get(x).getAppropriations().get(y).getName().toString());
				      
				      serviceAgencyAppList.add(x, serviceAgencyApp);
			    	}  
		          }	
			   	}
			    
		  }  
	  }
	  
	  void afterRender()
	  {
		  jsSupport.addScript("setupDatatable();");
	  }
}