/*
 * I don't know what goes here. ~Evan Sonderegger
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.tapestry.SendEmailOnInvalidXML;

public class NewR2Copy extends NewR2Endpoint
{
  private static final Logger log = CbesLogFactory.getLog(NewR2Copy.class);

  @Property
  private ProgramElement PEBase;


  public StreamResponse onActivate(String peNumber)
  {
    InputStream is = null;
    try {
      ProgramElement pe = getRequestedPe(peNumber);

      File workingFolder = createFileInUpload();
      String filePath = pe.toZip(workingFolder, new SendEmailOnInvalidXML(getUserCredentials()));
      String fileName = FileUtil.createZipFileName("R2", pe.getBusinessId());
      is = new FileInputStream(filePath);
      return getStreamResponse(is, BudgesContentType.ZIP.getMimeType(), fileName);
    } catch(ApiRequestException e) {
      return new TextStreamResponse("application/json", createErrorResponse(e.getMessage()).toString());
    }
    catch (IOException  | SQLException ex)
    {
      try
      {
        if (is != null) {
          is.close();
        }
      }
      catch (IOException ex2) {
        log.error("Error closing input stream", ex2);
      }
      finally
      {
        log.error("Error during download of R2 Xml file.", ex);
      }
    }
    return new TextStreamResponse("application/json", createErrorResponse("Error during download of R2 XML file.").toString());
//    return getStreamResponse(is, BudgesContentType.ZIP.getMimeType(), FileUtil.createPdfFileName("R2", pe.getBusinessId()));
  }
}
