/*
 * $Id: R2EventButton.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.LinkSubmit;

public class R2SubmitButton
{
  //private static final Logger log = CbesLogFactory.getLog(R2SubmitButton.class);

  @SuppressWarnings("unused")
  @Parameter(defaultPrefix = BindingConstants.LITERAL)
  @Property
  private String text;
  
  @SuppressWarnings("unused")
  @Component(publishParameters="defer,disabled,event", inheritInformalParameters=true)
  private LinkSubmit linkSubmit;
}
