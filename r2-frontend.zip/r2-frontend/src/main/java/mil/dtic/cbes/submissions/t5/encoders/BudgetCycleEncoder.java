package mil.dtic.cbes.submissions.t5.encoders;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;


public class BudgetCycleEncoder implements ValueEncoder<BudgetCycle>
{
  private static final Logger log = CbesLogFactory.getLog(BudgetCycleEncoder.class);
  
  public BudgetCycleEncoder()
  {
    log.debug("constructed");
  }
  
  public String toClient(BudgetCycle value)
  {
    return value.getCycle() + " " + value.getBudgetYear();
  }
  
  public BudgetCycle toValue(String clientValue)
  {
    String[] split = clientValue.split(" ");
    return BudgesContext.getBudgetCycleDAO().findByCycleAndBudgetYear(split[0], new Integer(split[1]));
  }
}