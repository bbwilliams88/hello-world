package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.rule.RuleGroup;
import mil.dtic.cbes.rule.RuleGroupVisitor;
import mil.dtic.cbes.rule.RuleGroupVisitorFactory;
import mil.dtic.cbes.rule.RuleViolationList;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.validation.backend.ProgramElementValidator;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.submissiondate.SubmissionDateProcessorFactory;

/**
 * Base class for pages with endpoint functionality in the new R2 UI.
 * New UI currently has two different implementations of endpoints. This
 * class provides standardized convenience methods for the ones in the
 * Pages package, and should be merged with the BaseEndpoint class in
 * the Endpoints sub-package once compatibility issues have been fixed.
 *
 * @author Jennifer Trow
 */
public class NewR2Endpoint extends T5Base {

  private static final Logger log = CbesLogFactory.getLog(NewR2Endpoint.class);
  @Inject
  private ProgramElementDAO peDao;
  @Inject
  private HttpServletRequest request;

  /**
   * Fetches a program element from the database based on its database ID number, with checks on
   * the validity of the ID string, the existence of the PE, and the user's view permissions for
   * the PE.
   *
   * @param peNumber              the PE's database ID number (not the 7-digit PE Number property)
   * @return                      the specified program element as a Java object
   * @throws ApiRequestException  If the PE cannot be returned due to malformed ID parameter, non-
   *                              existent PE, or lack of view permissions.
   */
  protected ProgramElement getRequestedPe(String peNumber) throws ApiRequestException {
    Integer peID = null;
    try
    {
      peID = Integer.parseInt(peNumber);
    }
    catch (NumberFormatException e)
    {
      log.debug("Bad pe ID value submitted.");
      throw new ApiRequestException("Invalid program element ID number.");
    }
    ProgramElement pe = peDao.findById(peID);
    if(pe == null) {
      throw new ApiRequestException("Program element not found.");
    }
    if(!getUserCredentials().viewPeAllowed(pe)) {
      throw new ApiRequestException("User does not have permission to view this PE.");
    }
    
    pe.setSubmissionDate(SubmissionDateProcessorFactory.getSubmissionDateProcessor().getDate(pe.getBudgetCycleAndYear()));
    
    return pe;
  }

  /*
   * The following methods create standardized JSON responses from the message(s) passed to them
   * as input. The response format is:
   *
   * success (boolean): false for error response, true for success or success + warnings
   * errorMessages (array, optional)
   * warningMessages (array, optional)
   * successMessages (array, optional)
   *
   * Array rows contain key-value pairs with 'message' as the key and the message text as the value.
   *
   * The endpoints in this package generally do not return multiple success or error messages, but
   * single messages are still put in an array. This is to maintain a standard JSON response format
   * that is compatible with, for example, XML Tools endpoints that process multi-exhibit uploads.
   */

  protected static JSONObject createErrorResponse(String msg) {
    ArrayList<String> msgs = new ArrayList<String>();
    msgs.add(msg);
    return createErrorResponse(msgs);
  }

  protected static JSONObject createErrorResponse(List<String> msgs) {
    JSONObject responseObj = new JSONObject();
    if(!CollectionUtils.isEmpty(msgs)) {
      responseObj.put("errorMessages", messageList(msgs));
    }
    responseObj.put("success", false);
    return responseObj;
  }

  /*
   * Success messages, unlike errors, might not be the only data in the endpoint's final response.
   * Therefore, the createSuccessResponse methods append their messages and success flag to an
   * existing JSON response that is passed as a parameter.
   */

  protected static JSONObject createSuccessResponse(JSONObject responseObject, String successMsg) {
    return createSuccessResponse(responseObject, successMsg, null);
  }

  protected static JSONObject createSuccessResponse(JSONObject responseObject, String successMsg, List<String> warningMsgs) {
    ArrayList<String> successMsgs = new ArrayList<String>();
    successMsgs.add(successMsg);
    return createSuccessResponse(responseObject, successMsgs, warningMsgs);
  }

  protected static JSONObject createSuccessResponse(JSONObject responseObject, List<String> successMsgs, List<String> warningMsgs) {
    if(!CollectionUtils.isEmpty(successMsgs)) {
      responseObject.put("successMessages", messageList(successMsgs));
    }
    if(!CollectionUtils.isEmpty(warningMsgs)) {
      responseObject.put("warningMessages", messageList(warningMsgs));
    }
    responseObject.put("success", true);
    return responseObject;
  }

  /**
   * Performs business-rules validation and appends the appropriate success message to an existing
   * JSON response, as well as a list of warning messages if applicable.
   *
   * @param responseObject    a JSON response with any other data this endpoint is going to return
   * @param pe                the program element to validate
   * @param isValidMsg        the success message to use if the PE is valid
   * @param hasWarningsMsg    the success message to use if the PE has business rule warnings
   * @return                  the original JSON response, plus an array with a single success
   *                          message, an array of warning messages if applicable, and a success
   *                          flag (set to true)
   */
  protected JSONObject validateAndCreateResponse(JSONObject responseObject, ProgramElement pe, String isValidMsg, String hasWarningsMsg) {
    RuleGroup pev = new ProgramElementValidator(pe);
    RuleGroupVisitor visitor = RuleGroupVisitorFactory.makeVisitor();
    visitor.visit(pev, pe.getServiceAgency().getCode());
    RuleViolationList violations = visitor.getRuleViolations();

    if (visitor.hasViolations()) {
      peDao.updateValidity(pe.getId(), PeSubmissionFlag.INVALID);
    } else {
      peDao.updateValidity(pe.getId(), PeSubmissionFlag.VALID);
    }

    if (!violations.isEmpty()) {
      responseObject = createSuccessResponse(responseObject, hasWarningsMsg, violations.asParseFriendlyList());
    } else {
      responseObject = createSuccessResponse(responseObject, isValidMsg);
    }

    return responseObject;
  }

  /**
   * Converts a list of message strings into standardized JSON response format. The array returned
   * by this method can then be added to the response object under one of the standard keys
   * 'successMessages,' 'warningMessages,' or 'errorMessages.'
   *
   * @param   a list of message strings of any type (success, warning, or error)
   * @return  an array of JSON key-value pairs with 'message' as the key and one of the provided
   *          strings as the value
   */
  protected static JSONArray messageList(List<String> msgs) {
    JSONArray msgsJson = new JSONArray();
    for(String s : msgs) {
      msgsJson.put(new JSONObject("message", s));
    }
    return msgsJson;
  }

  /**
   * For now, file-download endpoints where Tapestry expects a StreamResponse deal with failed
   * downloads by landing on an ugly raw text response, which might as well be a plain text error
   * message rather than JSON.
   *
   * For a possible alternative approach, see the onDownloadFile method in BusinessRuleWarningsCsv
   * and the downloadFrom handler in the Angular UI.
   */
  protected TextStreamResponse plainErrorResponse(String msg) {
    return new TextStreamResponse("text/plain", msg);
  }
}