package mil.dtic.cbes.submissions.t5.etc;

import java.io.IOException;
import java.io.InputStream;

import org.apache.tapestry5.StreamResponse;

import mil.dtic.cbes.submissions.ValueObjects.UploadedBudgetFile;

public abstract class UploadedBudgetFileStreamResponse<F extends UploadedBudgetFile> implements StreamResponse {
	
	protected F uploadedBudgetFile;
	
	public UploadedBudgetFileStreamResponse(F uploadedBudgetFile) {
		this.uploadedBudgetFile = uploadedBudgetFile;
	}

	@Override
	public String getContentType() {
		return "application/" + uploadedBudgetFile.getType();
	}

	@Override
	public InputStream getStream() throws IOException {
		return uploadedBudgetFile.getFileURI().toURL().openStream();
	}

}
