/*
 * $Id: AlreadyLockedPage.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.pages;

/**
 * Presents a "Locked by someone else" message, and
 * a link to a page that would restart the operation.
 * Make sure the page you pass in does not need any
 * special parameters because this page won't pass them
 * in.
 */
import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.PageRenderLinkSource;

import mil.dtic.utility.CbesLogFactory;

public class AlreadyLockedPage
{
  private static final Logger log = CbesLogFactory.getLog(AlreadyLockedPage.class);
  
  @Inject
  private PageRenderLinkSource linkSource;
  
  private String returnTo;
  
  void onActivate(String page) throws URISyntaxException
  {
    this.returnTo = page;
  }
  
  Object[] onPassivate()
  {
    return new String[] { returnTo };
  }
  
  Object onEventLink() throws MalformedURLException
  {
    log.debug("onEventLink " + returnTo);
    return returnTo;
  }
  
  public void setPage(Class<?> t5PageClass)
  {
//    try {
//      returnTo = new URL("http://www.google.com");
      this.returnTo = linkSource.createPageRenderLink(t5PageClass).toString();
//    } catch (MalformedURLException e) {
//      log.error("", e);
//      
//    }
  }
}
