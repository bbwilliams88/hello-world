/*
 * I don't know what goes here. ~Evan Sonderegger
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.SimpleStatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.ContractMethod;
import mil.dtic.cbes.submissions.ValueObjects.ContractType;
import mil.dtic.cbes.submissions.ValueObjects.FundingVehicle;
import mil.dtic.cbes.submissions.dao.R2ContractMethodTypeFundingVehicleDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class NewContractFundvehJson extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(NewContractFundvehJson.class);
  @Inject
  private R2ContractMethodTypeFundingVehicleDAO cmtfvDAO;
  
  TextStreamResponse onActivate()
  {
    JSONObject responseObject = new JSONObject();
    JSONArray contractMethodsJson = new JSONArray();
    JSONArray contractTypesJson = new JSONArray();
    JSONArray fundingVehiclesJson = new JSONArray();
    
    List<ContractMethod> contractMethods = BudgesContext.getContractMethodDAO().findByProperty(ContractMethod.STATUS_FLAG, SimpleStatusFlag.ACTIVE, true, ContractMethod.NAME);
    List<ContractType> contractTypes = BudgesContext.getContractTypeDAO().findByProperty(ContractType.STATUS_FLAG, SimpleStatusFlag.ACTIVE, true, ContractType.NAME);
    List<FundingVehicle> fundingVehicles = BudgesContext.getFundingVehicleDAO().findByProperty(FundingVehicle.STATUS_FLAG, SimpleStatusFlag.ACTIVE, true, FundingVehicle.NAME);
    
    for (ContractMethod cm : contractMethods) {
      JSONObject cmObject = new JSONObject();
      cmObject.put(cm.getName(), cm.getDescription());
      contractMethodsJson.put(cmObject);
    }
    
    for (ContractType cm : contractTypes) {
      JSONObject cmObject = new JSONObject();
      cmObject.put(cm.getName(), cm.getDescription());
      contractTypesJson.put(cmObject);
    }
    
    for (FundingVehicle fv : fundingVehicles) {
      JSONObject fvObject = new JSONObject();
      fvObject.put(fv.getName(), fv.getDescription());
      fundingVehiclesJson.put(fvObject);
    }
    
    responseObject.put("ContractMethods", contractMethodsJson);
    responseObject.put("ContractTypes", contractTypesJson);
    responseObject.put("FundingVehicles", fundingVehiclesJson);
    return new TextStreamResponse("application/json", responseObject.toString());
  }
}
