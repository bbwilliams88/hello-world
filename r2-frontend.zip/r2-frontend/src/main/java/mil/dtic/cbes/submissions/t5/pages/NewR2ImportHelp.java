package mil.dtic.cbes.submissions.t5.pages;

public class NewR2ImportHelp {
    // Unused class, but needed to load the Help window for the NewR2Import page
}
