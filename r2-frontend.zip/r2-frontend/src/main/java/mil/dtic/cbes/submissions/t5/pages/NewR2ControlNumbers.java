package mil.dtic.cbes.submissions.t5.pages;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.PropertyAccess;
import org.apache.tapestry5.ioc.services.PropertyAdapter;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import mil.dtic.cbes.constants.Constants;
//import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.UserProgramElementList;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.PELockDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.exception.AlreadyLockedException;
import mil.dtic.cbes.submissions.service.SaveService;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.submissions.t5.models.R2ListFilters;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

@Import(
  stack   = {CbesT5SharedModule.DATATABLESBUTTONS },
  library = { "context:/js/urlencoder.js",
              "context:/js/trackingPage.js",
              "context:/js/t5.js",
              "context:/js/jquery.cookie.js",
              "context:/js/r2dataTableExhibitIcons.js",
              "context:/js/timeout.js",
              "context:/js/newR2controls.js" })
public class NewR2ControlNumbers extends PeListBase {
  private static final Logger log = CbesLogFactory.getLog(NewR2ControlNumbers.class);
      @Inject
      private ComponentResources resources;
      @Inject
      private JavaScriptSupport jsSupport;
      @Inject
      private Request request;
      @Inject
      private PropertyAccess propertyAccess;


      @InjectPage
      private AlreadyLockedPage lockedPage;

      @Inject
      private BudgetCycleDAO bcDAO;
      @Inject
      private PELockDAO peLockDAO;
      @Inject
      private ProgramElementDAO peDAO;
      @Inject
      private SaveService saveService;


      @SessionState
      private R2ListFilters filterState;

      @Property
      private List<UserProgramElementList> pes;
      @Persist
      @Property
      private Map<Integer,ProgramElement> fatPesMap; // writes go here
      @Persist
      @Property
      private Map<Integer,UserProgramElementList> pesMap; // writes go here

      @Property
      private ProgramElementList currentPe; // pe currently being iterated over
      @Property
      private int budgetYear;

      @Property
      private BudgetCycle aBudgetCycle;

      @Property
      private ServiceAgency aServiceAgency;

      @Log
      void onActivate()
      {

        if (filterState.getBudgetCycle() == null || filterState.getBudgetCycle().getBudgetYear() == null) {
            log.debug("No budget cycle selected, defaulting to current");
            filterState.setBudgetCycle(Util.getCurrentBudgetCycle());
        }

        budgetYear = filterState.getBudgetCycle().getBudgetYear();
      }


      void afterRender()
      {
        JSONObject links = new JSONObject(
          "budgetCycleReloadUrl", resources.createEventLink("BudgetCycleChange")+"",
          "saveUrl", resources.createEventLink("Save")+"",
          "updateUrl", resources.createEventLink("Update") + "",
          "getPeJsonUrl", resources.createEventLink("GetPeJson").toString(),
          "getRenumberedPeJsonUrl", resources.createEventLink("GetRenumberedPeJson").toString()
          );
        jsSupport.addScript("setCurrentBudgetYear(%s)", budgetYear);
        jsSupport.addScript("setup(%s);", links.toCompactString());
        jsSupport.addScript("pageInit();");
      }

      @Log
      void onBudgetCycleChange(String reloadBudgetCycle)
      {
        filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
      }

      JSONObject onSave()
      {
        log.debug("onSave");
        List<String>success = new LinkedList<String>();
        List<String>errors = new LinkedList<String>();

        JsonArray tabledata = new JsonParser().parse(request.getParameter("tabledata")).getAsJsonArray();
//        boolean reload = false;
        for (JsonElement element : tabledata) {
          JsonObject pejson = element.getAsJsonObject();
          ProgramElement pe = peDAO.findById(pejson.get("id").getAsInt());
          log.debug("Got pe: "+pe.getId()+" "+pe.getNumber() );
          if (pejson.get("locked").getAsBoolean()) {
            log.debug("skipping PE locked by other - " + pe);
            continue;
          }

          try {
            if (copyFundingPropsOver(pejson, pe)) {
              boolean alreadyLockedByMe = peLockDAO.isPeLockedBy(getCurrentBudgesUser().getId(), pe.getId());
              if (!alreadyLockedByMe)
                peLockDAO.lockPEOnly(pe.getId(), getCurrentBudgesUser(), getCurrentBudgesUser(), false);
              log.debug("Saving " + pe);
              pe.setModifiedByBudgesUser(getCurrentBudgesUser());
              pe.setDateModified(new Date());
//              PeSubmissionFlag oldValidity = pe.getSubmissionStatus();
              saveService.doR2Save(pe, getCurrentBudgesUser(), false);
//              if (oldValidity != pe.getSubmissionStatus())
//                reload = true;
              if (!alreadyLockedByMe)
                peLockDAO.lockPEOnly(pe.getId(), getCurrentBudgesUser(), null, false);

              success.add("Program Element "+pe.getNumber()+" updated.");
            } else {
              //log.trace("not saving " + pe);
            }
          } catch (AlreadyLockedException e) {
            log.debug("Already locked - " + pe.getId());
            errors.add("Program Element "+pe.getNumber()+" is locked by someone else.");
          }
        }

        return createResponse(success, errors);
      }

      /**
       * This method handles the auto update of the control numbers.
       * @return
       */
      JSONObject onUpdate()
      {
        log.debug("onUpdate");
        List<String>errors = new LinkedList<String>();
        List<String>success = new LinkedList<String>();

        String tableDataStr = request.getParameter("tabledata");
        JSONArray tabledata = new JSONArray(tableDataStr);

        int newLineNumber = 0;
        int oldLineNumber = 0;
        int difference = 0;

        Integer updateId = new JsonParser().parse(request.getParameter("updateid")).getAsInt();

        if(request.getParameter("updateval") != null && NumberUtils.isDigits(request.getParameter("updateval"))) {
          newLineNumber = new JsonParser().parse(request.getParameter("updateval")).getAsInt();
        }
        else
        {
            errors.add("No new R1 number or Program Element ID found.");
            return createResponse(success, errors);
        }

        ArrayList<JSONObject> jsonObjects = new ArrayList<JSONObject>(tabledata.length());

        // Create a list of the JsonObjects so they can be sorted.

        for (int i=0; i<tabledata.length(); i++){
          JSONObject pejson = tabledata.getJSONObject(i);
          jsonObjects.add(pejson);
        }

        // Sort the incoming JSON elements in line number order.
        Collections.sort(jsonObjects, new Comparator<JSONObject>(){
          @Override
          public int compare(JSONObject o1, JSONObject o2)
          {
            Integer n1 = 0;
            Integer n2 = 0;

            String r1Key = "r1LineNumber";

            if (o1.get(r1Key)!=null)
            {
                n1 = StringUtils.isNumeric(o1.getString(r1Key)) ? o1.getInt(r1Key) : 0;
            }
            if (o2.get(r1Key)!=null)
            {
                n2 = StringUtils.isNumeric(o2.getString(r1Key)) ? o2.getInt(r1Key) : 0;
            }
            if ((n1).equals(n2))
            {
                return o1.getString("number").compareTo(o2.getString("number"));
            }
            else
            {
                return (n1).compareTo(n2);
            }

          };
         }
        );

        ProgramElement fatPe = null;
        UserProgramElementList pe = null;
        boolean bSuccess = false;
        // Loop through the json objects, check if the control number changed, increment subsequent sequential control numbers.
        for (JSONObject pejson : jsonObjects){
            fatPe = fatPesMap.get(Integer.valueOf(pejson.getInt("id")));
            pe = pesMap.get(Integer.valueOf(pejson.getInt("id")));
            if (pejson.get("r1LineNumber")!=null && StringUtils.isNumeric(pejson.getString("r1LineNumber")))
            {
                oldLineNumber = pejson.getInt("r1LineNumber");
            }
            else
            {
                oldLineNumber = 0;
            }


          // Check if this JSON element was updated
          if (updateId.equals(pejson.getInt("id"))) {
            difference = newLineNumber - oldLineNumber;
          }

          // If exhibit locked by someone other than me, return locked pe ID
          if((fatPe.getEntirePeLockedBy() != null && !fatPe.getEntirePeLockedBy().equals(getCurrentBudgesUser()))
            || (fatPe.getLockedBy() != null && !fatPe.getLockedBy().equals(getCurrentBudgesUser()))) {
            if (difference != 0) {
                errors.add("Program Element "+fatPe.getNumber()+" is locked by another user.");
            }
          }
          // Else update subsequent R1 numbers by the difference
          else {
            if (pejson.get("r1LineNumber")!=null && StringUtils.isNumeric(pejson.getString("r1LineNumber")))
            {
                fatPe.setR1LineNumber(pejson.getString("r1LineNumber"));
                pe.setR1LineNumber(String.valueOf( pejson.getInt("r1LineNumber")+difference));
                bSuccess = true;
            }

          }
        }

        if (bSuccess && CollectionUtils.isNotEmpty(errors))
        {
            success.add("Renumbering has partially succeed.  Please see errors listed below.");
        }
        else if (bSuccess)
        {
            success.add("Renumbering has succeeded.");
        }
        return createResponse(success, errors);
      }



      @Log
      public JSONObject onGetPeJson()
      {
          log.debug("getting list");
          pes = getUserPesBasedOnPermissionsAndFilter(UserProgramElementList.LINE_NUM, UserProgramElementList.NUMBER);
          log.debug("list size:"+pes.size());
          if (fatPesMap==null)
          {
              fatPesMap = new LinkedHashMap<Integer,ProgramElement>(pes.size());
              pesMap = new LinkedHashMap<Integer,UserProgramElementList>(pes.size());
          }
          fatPesMap.clear();
          pesMap.clear();



        JSONObject rootObj = new JSONObject();
        rootObj.put("recordsTotal", pes.size());
        rootObj.put("recordsFilter", pes.size());
        rootObj.put("draw", "1");
        JSONArray jsonArray = new JSONArray();
        Set <Integer>peIds = new LinkedHashSet<Integer>();
        for (UserProgramElementList element : pes) {
            peIds.add(element.getId());
            pesMap.put(element.getId(), element);
        }

        List<ProgramElement> fatPes = peDAO.findByIdsPaged(peIds, 0, 0, true, UserProgramElementList.LINE_NUM, UserProgramElementList.NUMBER);
        for (ProgramElement fatPE:fatPes)
        {
            fatPesMap.put(fatPE.getId(), fatPE);
        }
        log.debug("fatPesMap size:"+fatPesMap.size());

        for (UserProgramElementList element : pes) {
            JSONObject obj = convertToJSONObject(element);
          jsonArray.put(obj);
        }
        rootObj.put("aaData", jsonArray);
//        log.debug(rootObj.toString(false));
        return rootObj;
      }

      @Log
      public JSONObject onGetRenumberedPeJson()
      {
          JSONObject rootObj = new JSONObject();
          rootObj.put("recordsTotal", pesMap.size());
            rootObj.put("recordsFilter", pesMap.size());
            rootObj.put("draw", "1");

            JSONArray jsonArray = new JSONArray();
            for (UserProgramElementList element : pesMap.values()) {
                JSONObject obj = convertToJSONObject(element);
              jsonArray.put(obj);
            }
          rootObj.put("aaData", jsonArray);
          return rootObj;
      }
      private boolean copyFundingPropsOver(JsonObject properties, ProgramElement pe)
      {
        boolean modified = false;
        for (String prop : getFatProps()) {
            log.debug("Finding property:"+prop);
          PropertyAdapter pa = propertyAccess.getAdapter(pe).getPropertyAdapter(prop);
          JsonElement val = properties.get(prop);
          log.debug("Finding property:"+prop +", val:"+val);
          if (val instanceof JsonNull) {
            modified |= set(pa, pe, null);
          } else if (pa.getType() == BigDecimal.class) {
            if ("".equals(val.getAsString())) {
              // datatables turns null strings into ""
              modified |= set(pa, pe, null);
            } else {
              modified |= set(pa, pe, val.getAsBigDecimal());
            }
          } else {
            if ("".equals(val.getAsString())) {
              // datatables turns null strings into ""
              modified |= set(pa, pe, (String) null);
            } else {
              modified |= set(pa, pe, val.getAsString());
            }
          }
        }
        return modified;
      }

      // Return true if property modified
      private boolean set(PropertyAdapter pa, Object instance, Object val)
      {
        Object oldval = pa.get(instance);
        if (oldval != null && oldval.equals(val)) {
          return false;
        } else if (oldval == val) {
          return false;
        } else {
          pa.set(instance, val);
          return true;
        }
      }

      // Use compareTo with BigDecimals
      private boolean set(PropertyAdapter pa, Object instance, BigDecimal val)
      {
        BigDecimal oldval = (BigDecimal)pa.get(instance);
        if (oldval != null && val != null && oldval.compareTo(val) == 0) {
          return false;
        } else if (oldval == val) {
          return false;
        } else {
          pa.set(instance, val);
          return true;
        }
      }

      private List<String> getFatProps()
      {
        return Lists.newArrayList(new String[] {
          "r1LineNumber",
          "fundingAllPys","fundingPy","fundingCy","fundingBy1Base","fundingBy1Ooc","fundingBy1",
          "fundingBy2","fundingBy3","fundingBy4","fundingBy5",
          "fundingCompCost","fundingTotalCost"
        });
      }

      @Override
      public List<BudgetCycle> getAllBudgetCycles()
      {
        return bcDAO.getBudgetCycles();
      }

      public List<ServiceAgency> getServiceAgencies()
      {
        return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
      }

      public String getCreatorName(UserProgramElementList pe)
      {
          return Util.formatName(pe.getCreatedByLastName(), pe.getCreatedByFirstName(), pe.getCreatedByMiddleInitial(), pe.getCreatedByLdapId());
      }

      /** Called by tapestry pages to format user name */
      public String getModifierName(UserProgramElementList pe)
      {
          return Util.formatName(pe.getModifiedByLastName(), pe.getModifiedByFirstName(), pe.getModifiedByMiddleInitial(), pe.getModifiedByLdapId());
      }

      private JSONObject createResponse(List<String>success, List<String>errors)
      {
          JSONObject response = new JSONObject();
            JSONArray successArray = new JSONArray();
            for (String sStr : success)
            {
                JSONObject sObj = new JSONObject();
                sObj.put("message", sStr);
                successArray.put(sObj);
            }
            response.put("successMessages", successArray);

            JSONArray errorArray = new JSONArray();
            for (String eStr : errors)
            {
                JSONObject sObj = new JSONObject();
                sObj.put("message", eStr);
                errorArray.put(sObj);
            }
            response.put("errorMessages", errorArray);
            return response;
      }

      private JSONObject convertToJSONObject(UserProgramElementList element)
      {
          List<String> allowedProps = Lists.newArrayList(new String[] {
                  "id",
                  "number","title","baNum","serviceAgencyCode","serviceAgencyName",
                  "budgetCycle", "budgetYear","submissionStatus","test","r1LineNumber","edit","view","r3Exists","r4Exists",
                  "r4aExists","r5Exists", "fundingAllPys", "fundingPy", "fundingCy", "fundingBy1", "fundingBy1Base",
                  "fundingBy1Ooc", "fundingBy2", "fundingBy3", "fundingBy4", "fundingBy5", "fundingCompCost", "fundingTotalCost"
                });

          JSONObject obj = new JSONObject(element.toJson(allowedProps));
          obj.put("numbercopy", element.getNumber());
          obj.put("formattedDateCreated", formatDatetime(element.getDateCreated()));
          obj.put("formattedDateModified", formatDatetime(element.getDateModified()));
          // Somehow the modifier ldap id was null for one of the records...
          // insert a blank string to fail more gracefully
          String creator = getCreatorName(element) == null ? "" : getCreatorName(element);
          String modifier = getModifierName(element) == null ? "" : getModifierName(element);
          obj.put("creatorDisplayName", creator);
          obj.put("modifierDisplayName", modifier);

          // Lock flag - true if PE level edit lock or frozen by other
          boolean locked = false;

          if (element.getEntirePELockedById() != null && element.getEntirePELockedById().intValue() != getCurrentBudgesUser().getId().intValue()) {
                locked = true;
          }

          if (element.getPeLockedById() != null && element.getPeLockedById().intValue() != getCurrentBudgesUser().getId().intValue()) {
            locked = true;
          }
          obj.put("locked", locked);
          if (element.getFormat()!=null && element.getFormat().isR2Long())
          {
              obj.put("r2Long", true);
          }
          else
          {
              obj.put("r2Long", false);
          }
          
          obj.put("edit", checkUserProgramElementAccess(element));
          obj.put("imported", Constants.PE_INITIAL_SOURCE_XML.equals(element.getInitialSource()));
          obj.put("valid", element.getSubmissionStatus().isValid());
          obj.put("allLocked", element.isEntirePeLocked());
          obj.put("anyLocked", element.isAnyProjectLocked());
          obj.put("peLocked", element.isPeOnlyLocked());
          obj.put("errorExists", element.isErrorExists());
          obj.put("warningExists", element.getSubmissionStatus().isInvalid());
          obj.put("peModified",false);
          return obj;
      }
      
      public boolean checkUserProgramElementAccess(UserProgramElementList element) {
    	  boolean result = false;
    	  
    	  ProgramElement programElement = fatPesMap.get(element.getId());
    	  
    	  if(null != programElement) {
    		  result = getUserCredentials().savePeAllowed(programElement);  			  
    	  }
    	  
    	  return result;
      }
}
