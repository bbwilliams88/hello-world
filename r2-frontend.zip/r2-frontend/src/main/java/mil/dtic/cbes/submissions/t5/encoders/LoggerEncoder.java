package mil.dtic.cbes.submissions.t5.encoders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.utility.CbesLogFactory;

public class LoggerEncoder implements ValueEncoder<Logger>{
    private Logger log = CbesLogFactory.getLog(LogLevelEncoder.class);
  
    private final Map<String, Logger> loggerMap = new HashMap<String, Logger>();

    public LoggerEncoder(List<Logger> loggers)
    {
        if (loggers==null) throw new IllegalArgumentException();
        for (Logger logger : loggers)
        {
            loggerMap.put(logger.getName(), logger);
        }
        log.debug("constructed");
    }


    public String toClient(Logger value)
    {
        return value.getName();
    }


    public Logger toValue(String keyAsString)
    {
        log.debug("toValue " + keyAsString);
        return loggerMap.get(keyAsString);
    }
}
