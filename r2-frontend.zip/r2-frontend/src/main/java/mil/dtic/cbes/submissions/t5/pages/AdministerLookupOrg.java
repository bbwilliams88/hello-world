package mil.dtic.cbes.submissions.t5.pages;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;


import org.apache.cayenne.access.DataContext;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import mil.dtic.cbes.p40.vo.BudgetCycleConfig;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.sso.siteminder.SpringUser;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.samanage.model.AdminServiceAgencyDTO;
import mil.dtic.utility.samanage.service.api.AdminService;
import mil.dtic.cbes.p40.vo.ServiceAgency;
import mil.dtic.cbes.p40.vo.Appropriation;
import mil.dtic.cbes.p40.vo.BudgetActivity;

// TODO: need to delete this file.
/** this class extends ManageAppPropsBase because we want to submit email icw
 * changes. */
@Deprecated
@Import(stack = { CbesT5SharedModule.DATATABLESUPDATED }, library = { "context:/js/administerLookupOrg.js" })
public class AdministerLookupOrg extends ManageAppPropsBase {
    private static final Logger Log = CbesLogFactory.getLog(AdministerLookupOrg.class);
    private static final int FORM_VALIDATION_FAILURE = 0;
    private static final int DUPLICATE_ENTRY = 1;
    private static final int FAILURE_PERSISTING_SERVICEAGENCY = 2;
    //private static final int FAILURE_PERSISTING_JOIN_TABLE = 3;
    private static final int SUCCESS = 4;
    private static final int EXCEPTION = 5;
    private static final int UNKNOWN_ISSUE = 6;
    
    //=========================================================================
    
    @Inject
    @Property
    private AdminService saManager;
    
    @Inject
    private JavaScriptSupport jsSupport;
    
    @Inject
    private ComponentResources resources;
    
  //=========================================================================
    // start: repositories
    private Map<String, mil.dtic.cbes.p40.vo.ServiceAgency> voAllAgencyMap;
    private Map<String, mil.dtic.cbes.p40.vo.Appropriation> voAllAppnMap;
    private TreeSet<String> voAppnTreeSet;  // list of approrioations
    private TreeSet<String> voSaTreeSet; // list of service agencies
    // end: repositories
    
    
    @Property
    private List<String> appStrs;

    @Property
    private List<String> serviceAgencyStrs;
    
    @Property
    private Map<String, String> warningIndicators;
    
    @Property
    private Map<String, String> smcaTags;
    
    @Property
    private Map<String, String> saStatus;
    
    @Property
    private Map<String, String> defAppStatus;
    

    //=========================================================================

    // start: properties
    @Property(read = true)
    private ServiceAgency serviceAgencyEntry;
    
    
    @Property
    private int rowIndex;
    
//    @Persist
//    @Property
//    private String activeAgency;
    
    
//    List<String> vals;
    boolean  special = true;
    
    @Persist
    @Property
    private String action;

    @Property
    private String selectedAgency;
    
    // begin: properties wrt create new service agency
 // required param for create
    @Property
    private String newAgencyCode;
 // required param for create
    @Property
    private String newAgencyName;
    
    //SMCA? - Participation under Single Manager for Conventional Ammunition (SMCA) programs
 // required param for create
    @Property
    private String newSmcaTag;
    
 // not required param for create
    @Property
    private String newLogoFileName;
    
 // required param for create
    @Property
    private String newWarningIndicator;
    
 // required param for create
    @Property
    private String newAppropAcctID;
    
 // required param for create
    @Property
    private String selectedAccount;
    
 // required param for create
    @Property
    private String newserviceStatus;

    // required param for create
    @Property
    private String newappStatus;
    
    
    @Property 
    private String editAgencyName;
    
    
    @Persist
    @Property 
    private String viewType;

    @Persist
    @Property
    private String statusMsg;
    // end: properties wrt create new service agency

    // end: properties
    
    
    
    
//    public void onSuccess(String context) {
//        LOG.debug("onSuccess with context: " + context);
//        if (context != null && context.equals("createServiceAgency")){
//            int success = processNewAgency();
//            setCreateNewAgencyStatusInformation(success);
//            viewType = "0";
//            LOG.debug("processed: " + context + " with result: " + success);
//        }
//        else {
//            if (context != null && context.equals("showServiceAgency")){
//                if (null != selectedAgency){
//                    ServiceAgency sa = voAllAgencyMap.get(selectedAgency);
//                    if (null != sa){
//                        viewType = "1";
//                    }
//                }
//            }
//            System.out.println("no actions required");
//        }
//        
//    }
    
//    private void setServiceAgencyForUpdate(ServiceAgency sa){
//        editSa = sa;
//    }
    
    
    public void onActivate() {
        
        if (special) {
            doSpecial();
        }
        
        warningIndicators = new HashMap<>();
        warningIndicators.put("Y", "Yes");
        warningIndicators.put("N", "No");
        
        smcaTags = new HashMap<>();
        smcaTags.put("0","No");
        smcaTags.put("1","Yes");
        
        saStatus = new HashMap<>();
        saStatus.put("A","Active");
        saStatus.put("I","Inactive");
        
        defAppStatus = new HashMap<>();
        defAppStatus.put("A","Active");
        defAppStatus.put("I","Inactive");
    }
    
    void afterRender() {
        //	  jsSupport.addScript("setupDatatable();");
        jsSupport.addScript("setup()");
    }
    
//    @SuppressWarnings("unused")
//    private int processNewAgency(){
//        
//        if (null == newAgencyCode || null == newAgencyName || null == newSmcaTag || null == newWarningIndicator || 
//                null == selectedAccount || null == newserviceStatus || null == newappStatus){
//            return FORM_VALIDATION_FAILURE;
//        }
//        
//        String code = newAgencyCode.toUpperCase();
//        
//        if (null != voAllAgencyMap.get(code)){
//            LOG.debug("duplicate code entry, invalid data");
//            return DUPLICATE_ENTRY;
//        }
//        
//        //Integer scma = Integer.parseInt(newSmcaTag);
//        //Integer appropriationId = null;
//        boolean isRdte = false;
//        boolean isProcurement = false;
//        String saaBudgetFlag = null;
//        
////        if (null != voAllAppnMap){
////            Appropriation appn = voAllAppnMap.get(selectedAccount);
////            if (null == appn){
////                return UNKNOWN_ISSUE;  //need better message
////            }
////            appropriationId = appn.getId();
////            List<BudgetActivity> baList = appn.getBudgetActivityList();
////            for (BudgetActivity ba : baList){
////                isProcurement = ba.isProcurement();
////                if(isProcurement){
////                    saaBudgetFlag = "P40";
////                    break;
////                }
////            }
////            if (!isProcurement){
////                saaBudgetFlag = "R2";
////            }
////        }
//        
//        if (null == newLogoFileName){
//            newLogoFileName = " ";
//        }
//        
//        AdminServiceAgencyDTO nsw = new AdminServiceAgencyDTO();
////        nsw.setCode(code);
////        nsw.setName(newAgencyName);
////        nsw.setSmcaTag(newSmcaTag);
////        nsw.setDefaultAppropriationId(appropriationId);
////        nsw.setNewServiceStatus(newserviceStatus);
////        nsw.setNewLogoFileName(newLogoFileName);
////        nsw.setNewWarningIndicator(newWarningIndicator);
//        
////        nsw.setNewAppstatus(newappStatus);
////        nsw.setSaaBudgetFlag(saaBudgetFlag);
//    
////        try {
////            if (saManager.createNewServiceAgency(nsw)){
////                return SUCCESS;
////            }
////            else{
////               return FAILURE_PERSISTING_SERVICEAGENCY; 
////            }
////        }
////        catch(SQLException sqle){
////            LOG.error("processNewAgency exception: " + sqle.getMessage(), sqle);
////            return EXCEPTION;
////        }
//    }
    
    
    @SuppressWarnings("unchecked")
    private P40User getP40User() {
        P40User p40User = getCurrentP40User();
        
        if (p40User != null) {
            return p40User;
        } else {
            BudgetCycleConfig config = CayenneUtils.createDataContext().newObject(BudgetCycleConfig.class);
            return P40User.fetchWithLdapId(config.getObjectContext(),
                    getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
        }
    }
    
    private void setCreateNewAgencyStatusInformation(int statusIndicator){
        
        switch(statusIndicator){
            case 4:
                statusMsg = "Successfully added new Agency";
                break;
            case 0:
                statusMsg = "Failure, form validation issues ";
                break;
            case 1:    
                statusMsg = "Duplicate Failure, the service agency already exist in system";
                break;
            case 2:
                statusMsg = "Failure persisting Service Agency - database issue";
                break;
            case 3:
                statusMsg = "Failure updating join table - database issue";
                break;
            case 6:
                statusMsg = "Failure.  Cause unknown";
                break;
            default:
                statusMsg = "Failure.  Cause unknown";
                break;
        }
    }
    
    private void doSpecial() {
        //reinitialize these containers.
        appStrs = new ArrayList<>();
        serviceAgencyStrs = new ArrayList<>();
        
        voAllAgencyMap = new HashMap<>();
        voAllAppnMap = new HashMap<>();
        voAppnTreeSet = new TreeSet<>(); //set of unique appropriations
        voSaTreeSet = new TreeSet<>(); // set or unique service agencies
        
        P40User p40User = getP40User();
        DataContext dataContext = CayenneUtils.createDataContext();
        P40User user = CayenneUtils.copyToContext(p40User, dataContext); //add the user to the context
        List<mil.dtic.cbes.p40.vo.ServiceAgency> vo_serviceAgencies = mil.dtic.cbes.p40.vo.ServiceAgency.fetchAll(dataContext);
        
        for (mil.dtic.cbes.p40.vo.ServiceAgency sa : vo_serviceAgencies){
            voAllAgencyMap.put(sa.getCode(), sa);
            voSaTreeSet.add(sa.getCode());
            List<mil.dtic.cbes.p40.vo.Appropriation> saApp = sa.getAllAppropriationsList();
            for (mil.dtic.cbes.p40.vo.Appropriation app : saApp){
                String key = app.getCode();
                //LOG.debug("service agency:" + sa.getCode() + " appropriation key: " + key);
                if (voAppnTreeSet.add(key)){
                    voAllAppnMap.put(key,app);
                }
            }
        }
        appStrs.addAll(voAppnTreeSet);
        Collections.sort(appStrs);
        
        serviceAgencyStrs.addAll(voSaTreeSet);
        Collections.sort(serviceAgencyStrs);
        
        //LOG.debug("total service agencies: " + vo_serviceAgencies.size());
        
        for (mil.dtic.cbes.p40.vo.ServiceAgency sa : vo_serviceAgencies) {
            //System.out.println("processing: " + sa.getCode() + " : " + sa.getStatus());
            voAllAgencyMap.put(sa.getCode(),sa);
        }
        
    }
    
}


///// save this, this is the datatables setup for all appn/appropriations.
//List<ServiceAgencyAccount> serviceAgencyAccounts = serviceAgencyAccountDAO.findAll();

//System.out.println();

//if (serviceAgencyList == null) {
//  //          serviceAgencyList = serviceAgencyDAO.findAllRDTEAllStatus();
//  serviceAgencyList = serviceAgencyDAO.findAllServiceAgencies();
//  String recType = "";
//  serviceAgencyAppList = new ArrayList<ServiceAgencyApp>();
//  //serviceAgencyList.get(0).getAppropriations().spliterator();
//  
//  if (CollectionUtils.isNotEmpty(serviceAgencyList)) {
//      for (int x = 0; x < serviceAgencyList.size(); x = x + 1) {
//          for (int y = 0; y < serviceAgencyList.get(x).getAppropriations().size(); y = y + 1) {
//              
//              if (serviceAgencyList.get(x).getAppropriations().get(y).isRdte()) {
//                  recType = "RDTE";
//              } else {
//                  recType = "Procurement";
//              }
//              
//              serviceAgencyApp = new ServiceAgencyApp();
//              serviceAgencyApp.setAgencyCode(serviceAgencyList.get(x).getCode().toString());
//              serviceAgencyApp.setAgencyName(serviceAgencyList.get(x).getName().toString());
//              serviceAgencyApp.setBudgetType(recType);
//              serviceAgencyApp.setStatus(serviceAgencyList.get(x).getStatusFlag().toString());
//              serviceAgencyApp
//                      .setAppnCode(serviceAgencyList.get(x).getAppropriations().get(y).getCode().toString());
//              serviceAgencyApp
//                      .setAppnName(serviceAgencyList.get(x).getAppropriations().get(y).getName().toString());
//              
//              serviceAgencyAppList.add(x, serviceAgencyApp);
//          }
//      }
//  }
//  
//}
