package mil.dtic.cbes.submissions.t5.etc;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ValidationException;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants.JBLogoImageFileType;


public class FileExtensionSavedUploadValidator extends SavedUploadValidator
{
  private final String[] allowedExts;
  private final String badExtMsg;
  
  public FileExtensionSavedUploadValidator(String badExtMsg, String ... allowedExts)
  {
    this.allowedExts = allowedExts;
    this.badExtMsg = badExtMsg;
  }
  
  public FileExtensionSavedUploadValidator(String badExtMsg, BudgesContentType ... types)
  {
    this(badExtMsg, parseBudgesContentTypes(types));
  }
  
  public FileExtensionSavedUploadValidator(String badExtMsg, JBLogoImageFileType ... types)
  {
    this(badExtMsg, parseJbLogoTypes(types));
  }
  
  private static String[] parseBudgesContentTypes(BudgesContentType[] types)
  {
    if (types==null) return null;
    String[] s = new String[types.length];
    for (int i = 0; i < s.length; i++)
    {
      s[i] = types[i].getFileExtension();
    }
    return s;
  }
  
  private static String[] parseJbLogoTypes(JBLogoImageFileType[] types)
  {
    if (types==null) return null;
    String[] s = new String[types.length];
    for (int i = 0; i < s.length; i++)
    {
      s[i] = types[i].toString().toLowerCase();
    }
    return s;
  }
  
  protected boolean isValid(String filename)
  {
    if (filename==null) return true;
    String ext = FilenameUtils.getExtension(filename);
    if (allowedExts!=null)
    {
      for (String allowed : allowedExts)
      {
        if (StringUtils.equalsIgnoreCase(ext, allowed)) {
          return true;
        }
      }
    }
    return false;
  }
  
  public void validateFilename(String filename) throws ValidationException
  {
    if (!isValid(filename))
      throw new ValidationException(badExtMsg);
  }
}