package mil.dtic.cbes.submissions.t5.pages;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.sql.Blob;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Response;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.ImageUtil;

public class R4ScheduleProfileImage {
  private static final Logger log = CbesLogFactory.getLog(R4ScheduleProfileImage.class);

  @Log
  StreamResponse onActivate(String scheduleProfileId) {
    ScheduleProfile schedProf =
        BudgesContext.getScheduleProfileDAO().findById(Integer.parseInt(scheduleProfileId));
    Blob blobData = schedProf.getImageData();
    String filename = schedProf.getImageFileName();
    // tif files get converted since browsers don't support them
    String tifPlaceholder = "tiffile.png";
    if (filename != null && StringUtils.endsWith(filename.toLowerCase(), "tif")) {
      filename = tifPlaceholder;
    }

    String mimeType = URLConnection.getFileNameMap().getContentTypeFor(filename);

    if (mimeType == null) {
      log.debug("hack since bmp isn't showing up for some reason");
      mimeType = "image/png";
    }
    InputStream is = null;
    try {
      if (tifPlaceholder.equals(filename)) {
        log.debug("Converting TIFF");
        byte[] png = ImageUtil.getPngFromTiff(blobData.getBinaryStream());
        is = new ByteArrayInputStream(png);
      } else {
        is = blobData.getBinaryStream();
      }
    } catch (IOException | SQLException e) {
      log.error("Error getting input stream for image", e);
    }
    return createStreamResponse(mimeType, is);
  }

  private StreamResponse createStreamResponse(final String mimeType, final InputStream is) {
    return new StreamResponse() {
      @Override
	public String getContentType() {
        return "img/jpeg";
      }

      @Override
	public InputStream getStream() throws IOException {
        return is;
      }

      @Override
	public void prepareResponse(Response response) {}
    };
  }
}
