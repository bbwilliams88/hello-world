package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.Link;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.RequestParameter;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.HttpError;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;
import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.jb.DefaultEmbedableFile;
import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.jb.DocumentCreationParams;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.sso.siteminder.UserInfo;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementListDAO;
import mil.dtic.cbes.submissions.delegates.PreviewDelegate;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.submissions.t5.services.UtilService;
import mil.dtic.cbes.t5shared.mixins.ProgressDownload;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.cbes.t5shared.services.DropdownService;
import mil.dtic.cbes.xml.JavaToXml;
import mil.dtic.cbes.xml.JavaToXmlResult;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.XmlUtil;
import mil.dtic.utility.tapestry.SendEmailOnInvalidXML;

@Import(stack = {
        CbesT5SharedModule.DATATABLESTACK,
        CbesT5SharedModule.JQUERYTOOLSSTACK
      },
        library = {
        "classpath:${cb.assetpath}/js/underscore.string.js",
        "classpath:${cb.assetpath}/js/urlencoder.js",
        "classpath:${cb.assetpath}/js/json2.js",
        "classpath:${cb.assetpath}/js/deleteconfirm.coffee",
        "classpath:${cb.assetpath}/js/buttonprogressdownload.coffee",
        "classpath:${cb.assetpath}/js/datatable.coffee",
        "classpath:${cb.assetpath}/js/progressdownload.coffee",
        "context:/js/buildotherdocuments.coffee"
      },
        stylesheet = {"context:css/r2datatables.css"})
public class BuildOtherDocuments extends PeListBase{
    private static final Logger log = CbesLogFactory.getLog(BuildOtherDocuments.class);

    @InjectComponent
    private Zone addZone;

//    @SessionState
//    private R2ListFilters filterState;
    @SessionState
    private DbExhibitSelection selection;
    @SuppressWarnings("unused")
    @Property
    private List<ProgramElementList> programElements;

    @SuppressWarnings("unused")
    @Persist
    private List<ProgramElement> actualProgramElements; //Abe: I HATE MYSELF FOR THIS basically I have no idea why there is a ProgramElementList which isn't a list of ProgramElements. so I'm adding more state allowing for my inconsistancy ::sigh::

    @SuppressWarnings("unused")
    @Property
    private ProgramElementList currentPe;
    @Inject
    private JavaScriptSupport jsSupport;

    @Inject
    private ComponentResources resources;
    @Inject
    private HttpServletRequest httpServletRequest;
    @Inject
    private HttpServletResponse httpServletResponse;

    @Persist
    @Property
    private boolean forceEvenPages;
    @Persist
    @Property
    private String watermark;
    @Persist
    @Property
    private String trackingHeader;
    @Persist
    @Property
    private ServiceAgency agency;
    @Persist
    @Property
    private BudgetCycle budgetCycle;
    @Persist
    @Property
    private String submissionDate;

    @Property
    @Persist
    private BudgesDownloadableObject pdfDownload;

    @Inject
    private UtilService util;

    @InjectPage
    private R2Select r2Select;

    @SuppressWarnings("unused")
    @Inject
    @Property
    private DropdownService ddsvc;
    @Inject
    private ProgramElementListDAO pelDAO;
//    @Inject
//    private BudgetCycleDAO bcDAO;
    @Inject
    private ProgramElementDAO peDAO;


    private String XSLTTypes = null;
    private String FileType = null;

    //@Log
    public List<ServiceAgency> getServiceAgencies()
    {
      return getAvailableRdteAgencies();
    }

//    //@Log
//    public List<BudgetCycle> getAllBudgetCycles()
//    {
//      return get;
//    }

    void onActivate()
    {
      if (selection.getProgramElements() != null) {
        Set<Integer> ids = new HashSet<Integer>();
        for (ProgramElement pe : selection.getProgramElements()) {
          ids.add(pe.getId());

        }
        actualProgramElements = peDAO.findByIdsPaged(ids, 0, -1, true);
        programElements = pelDAO.findByIdsPaged(ids, 0, -1, true);
      }
    }

    @Log
    void onChangeFromWatermark(String watermarkText)
    {
        watermark = watermarkText;
    }

    /**
     *
     * Start of Button Actions
     */
    @Log
    Object onActionFromModify(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token)
    {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

      r2Select.setReturnPage(getClass());
      r2Select.setReturnButton("Return With Selections");
      return r2Select;
    }

    private String getDocTitle(){
        if(StringUtils.equals(XSLTTypes, "r1")){
            return "r1";
        }
        else if(StringUtils.equals(XSLTTypes, "r1summary")){
            return "r1summary";
        }
        else if(StringUtils.equals(XSLTTypes, "r1c")){
            return "r1c";
        }
        else if(StringUtils.equals(XSLTTypes, "r1d")){
            return "r1d";
        }
        else if(StringUtils.equals(XSLTTypes, "r2collection")){
            return "R2_Selections";
        }
        else if(StringUtils.equals(XSLTTypes, "r2collectionIndividualPdfZip")){
            return "R2_Selections_Individual";
        }
        else if(StringUtils.equals(XSLTTypes, "r2XmlFile")){
            return "R2_AllXML";
        }
        return null;
    }

    private BudgesContentType getXSLTFileType(){
        if(StringUtils.equals(FileType, "PDF"))
            return BudgesContentType.PDF;
        else if(StringUtils.equals(FileType, "ZIP"))
            return BudgesContentType.ZIP;
        else if (StringUtils.equals(FileType, "XML"))
            return BudgesContentType.XML;
        else if (StringUtils.equals(FileType, "EXCEL"))
            return BudgesContentType.EXCEL;

        return null;
    }
    private FileSetting getFileSettingType(){
        if(StringUtils.equals(XSLTTypes, "r1")){
            return FileSetting.R1;
        }
        else if(StringUtils.equals(XSLTTypes, "r1summary")){
            return FileSetting.R1SUMMARY;
        }
        else if(StringUtils.equals(XSLTTypes, "r1c")){
            return FileSetting.R1C;
        }
        else if(StringUtils.equals(XSLTTypes, "r1d")){
            return FileSetting.R1D;
        }
        else if(StringUtils.equals(XSLTTypes, "r2collection")){
            return FileSetting.R2COLLECTION;
        }
        else if(StringUtils.equals(XSLTTypes, "r2collectionIndividualPdfZip")){
            return FileSetting.R2COLLECTION;
        }
        else if(StringUtils.equals(XSLTTypes, "r2XmlFile")){
            return FileSetting.R2COLLECTION;
        }

        return null;
    }

    @Log
    Object getInputStream() {
        try {

            String fileName = null;

            if(StringUtils.equals(FileType, "PDF"))
                fileName = FileUtil.createPdfFileName(getDocTitle());
            else if(StringUtils.equals(FileType, "ZIP"))
                fileName = FileUtil.createZipFileName(getDocTitle());
            else if(StringUtils.equals(FileType, "XML"))
                fileName = FileUtil.createZipFileName(getDocTitle());
            else
                fileName = FileUtil.createExcelFileName(getDocTitle());

            File workingFolder = createFileInUpload();

            String fileNamePrefix = createUniqueFileSystemPrefix();
            File sandboxFolder = new File(BudgesContext.getConfigService().getVscanSandboxFolder(), "r2_" + fileNamePrefix + "_dir");
            sandboxFolder.mkdir();

            File virusScanFile = new File(sandboxFolder, "R2_File.xml");

            JavaToXmlResult jtxResult = null;
            R2ExhibitList r2ExhibitList = wrapInR2ExhibitList(actualProgramElements);

            JavaToXml jtx = new JavaToXml(workingFolder);
            jtxResult = jtx.toZip(r2ExhibitList);

            //TODO: Why do we need to send these files to our vscan?
            //Need to run this by other developers as a policy question.
            //For now, this just creates a copy in the vscan sandbox directory.
            //We will get an email if there is a virus...which there shouldn't be.
            JavaToXml jtx2 = new JavaToXml(sandboxFolder);
            jtx2.toZip(r2ExhibitList);

            XmlUtil.sanityValidateXml(jtxResult.getXmlFile(),
                    new SendEmailOnInvalidXML(getUserCredentials()));

            String filePath = jtxResult.getZipFile().getAbsolutePath();

            DocumentAssemblyOptions docAssemblyOptions = new DocumentAssemblyOptions();
            docAssemblyOptions.setForceEvenPages(forceEvenPages);
            docAssemblyOptions.setWatermark(watermark);
            docAssemblyOptions.setTrackingHeader(trackingHeader);

            DocumentCreationParams docCreationParams = new DocumentCreationParams();
            if(agency != null)
                docCreationParams.setServiceAgencyName(agency.getName());
            if(budgetCycle != null)
            {
                docCreationParams.setBudgetCycle(budgetCycle.getValue());

                if (budgetCycle.getSubmissionDates() != null && !budgetCycle.getSubmissionDates().isEmpty())
                {
                  docCreationParams.setSubmissionDate(budgetCycle.getSubmissionDates().get(0).getDate());
                }
            }

            docCreationParams.setR4KvpList(jtxResult.getR4KvpList());

            r2ExhibitList.setContentType(getXSLTFileType());
            r2ExhibitList.setDocCreationParams(docCreationParams);
            r2ExhibitList.setXmlFile(jtxResult.getXmlFile());
            r2ExhibitList.addFileToEmbed(new DefaultEmbedableFile(r2ExhibitList, jtxResult.getZipFile()));
            r2ExhibitList.setWorkingFolder(workingFolder);
            r2ExhibitList.setFileName(fileName);
            r2ExhibitList.setAbsoluteFileName(filePath);
            r2ExhibitList.setFileSetting(getFileSettingType());
            r2ExhibitList.setTitle(getDocTitle());

            BudgesFile budgesFile = new BudgesFile(fileName, workingFolder, null);

            //TODO: Not sure why we need to Virus scan here.  No Files were uploaded.
            //BudgesFile requires this though.  We should investigate.  See above
            budgesFile.setVirusScanFile(virusScanFile);
            budgesFile.setFile(r2ExhibitList.getXmlFile());

            PreviewDelegate pd = new PreviewDelegate(getUserCredentials().getUserInfo().getBudgesUser(), workingFolder, new SendEmailOnInvalidXML(getUserCredentials()),
                    runOnlyVerifiedRules(), docCreationParams, docAssemblyOptions);

            PreviewResultInfo previewResultInfo = null;

            if(StringUtils.equals(FileType, "PDF"))
                previewResultInfo = pd.doBuildR1Pdf(r2ExhibitList, budgesFile);
            if(StringUtils.equals(FileType, "ZIP")){
                docCreationParams.setPdfPerExhibit(true);
                r2ExhibitList.setDocCreationParams(docCreationParams);
                previewResultInfo = pd.doBuildR2SinglePdf(budgesFile);
            }
            if(StringUtils.equals(FileType, "XML"))
                previewResultInfo = pd.doBuildR2SingleXml(budgesFile);
            if(StringUtils.equals(FileType, "EXCEL"))
                previewResultInfo = pd.doBuildR1Excel(r2ExhibitList, budgesFile);

            previewResultInfo.setR2ExhibitList(r2ExhibitList);

            return getStreamResponse(previewResultInfo.getDownloadableObject().getInputStream(), getXSLTFileType().getMimeType(), fileName);

        } catch (IOException | SQLException | DocumentException ex) {
            log.error("Failed to open imput stream: " + ex.getMessage(),ex);
            return ex;
        }
    }

    /**
     * PDF Buttons
     * @return
     */
    @Log
    public Object onActionFromBuildR1(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        log.debug("token: " + token);
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1";
        FileType = "PDF";
        return getInputStream();
    }


    @Log
    public Object onActionFromBuildR1Summary(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1summary";
        FileType = "PDF";
        return getInputStream();

    }


    @Log
    public Object onActionFromBuildR1c(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1c";
        FileType = "PDF";
        return getInputStream();
    }


    @Log
    public Object onActionFromBuildR1d(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1d";
        FileType = "PDF";
        return getInputStream();
    }

    @Log
    public Object onActionFromBuildR2Collection(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r2collection";
        FileType = "PDF";
        return getInputStream();
    }

    @Log
    public Object onActionFromBuildR2CollectionIndividualPdfZip(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r2collectionIndividualPdfZip";
        FileType = "ZIP";
        return getInputStream();
    }
    /**
     * PDF Buttons
     * @return
     */


    /**
     * Excel Buttons
     * @return
     */
    @Log
    public Object onActionFromBuildR1Excel(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1";
        FileType = "EXCEL";
        return getInputStream();
    }

    @Log
    public Object onActionFromBuildR1SummaryExcel(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1summary";
        FileType = "EXCEL";
        return getInputStream();
    }

    @Log
    public Object onActionFromBuildR1cExcel(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1c";
        FileType = "EXCEL";
        return getInputStream();
    }



    @Log
    public Object onActionFromBuildR1dExcel(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r1d";
        FileType = "EXCEL";
        return getInputStream();
    }
    /**
     * Excel Buttons
     * @return
     */

    @Log
    public Object onActionFromBuildR2XmlFile(final int id,@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
        ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);

        XSLTTypes = "r2XmlFile";
        FileType = "XML";
        return getInputStream();
    }
    /**
     *
     * End of Button Actions
     */

    /***
     * Start of the "Exhibit R-2's To Include in Document" T5 Methods
     *
     */

    public String getPeJson() {
        List<String> allowedProps = Lists.newArrayList(new String[] { "id", "lineNum", "number", "title", "userDefinedTag", "baNum", "numProjects",
                "serviceAgencyCode", "serviceAgencyName", "budgetCycle", "budgetYear", "dateCreated", "dateModified", "submissionStatus" });


        JSONArray jsonArray = new JSONArray();
        for (ProgramElementList element : programElements) {
            JSONObject obj = new JSONObject(element.toJson(allowedProps));
            obj.put("numbercopy", element.getNumber());
            obj.put("formattedDateCreated", formatDatetime(element.getDateCreated()));
            obj.put("formattedDateModified", formatDatetime(element.getDateModified()));
            // Somehow the modifier ldap id was null for one of the records...
            // insert a blank string to fail more gracefully
            String creator = getCreatorName(element) == null ? "" : getCreatorName(element);
            String modifier = getModifierName(element) == null ? "" : getModifierName(element);
            obj.put("creatorDisplayName", creator);
            obj.put("modifierDisplayName", modifier);
            obj.put("copyEnabled", false);
            obj.put("deleteEnabled", false);
            jsonArray.put(obj);
        }
        return jsonArray.toString(false);
    }


    void afterRender()
    {
        Link budgetCycleFilterPageLink = resources.createEventLink("BudgetCycleChange");
        jsSupport.addScript("setupBudgetCycleReload('%s');", budgetCycleFilterPageLink);
        JSONObject tableLinks = new JSONObject(
          "number", resources.createEventLink("NumberLink").toString()
          );
        jsSupport.addScript("setupDatatable(%s);", tableLinks.toCompactString());
    }


    @Log
    void onBudgetCycleChange(String reloadBudgetCycle)
    {
//      filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
//
//      // If user did not select a cycle (blank label) then set it to a null
//      // BudgetCycle
//      // so we don't use the default cycle when "onActivate" is invoked
//      if (filterState.getBudgetCycle() == null)
//        filterState.setBudgetCycle(new BudgetCycle());
    }

    /***
     * End of the "Exhibit R-2's To Include in Document" T5 Methods
     *
     */


    /**
     * PDF Build helper Methods
     * @param cycle
     * @param jbPart
     * @param budgetArea
     */
    public R2ExhibitList wrapInR2ExhibitList(List<ProgramElement> peCollection)
    {
      R2ExhibitList r2ExhibitList = new R2ExhibitList();
      List<R2Exhibit> r2Exhibits = new ArrayList<R2Exhibit>();
      r2ExhibitList.setR2Exhibits(r2Exhibits);
      for (ProgramElement pe : peCollection)
      {
        R2Exhibit r2Exhibit = new R2Exhibit();
        r2Exhibit.setProgramElement(pe);
        r2Exhibits.add(r2Exhibit);
      }
      return r2ExhibitList;
    }


    protected String createUniqueFileSystemPrefix()
    {
      return getLdapUserId() + "_" + UUID.randomUUID().toString();
    }


    protected String getLdapUserId()
    {
      String ldapUserId = null;
      UserCredentials uc = getUserCredentials();
      UserInfo userInfo = uc.getUserInfo();
      if (userInfo.getLdapUser() != null)
      {
        ldapUserId = userInfo.getLdapUser().getLdapUserId();
      }
      return ldapUserId;
    }
    /**
     * PDF Build helper Methods
     * @param cycle
     * @param jbPart
     * @param budgetArea
     */
    public Object onSuccess(){
      //on success is running it will return a dummy stream response just so I can
      log.debug("ON SUCCESS RUNNING");
      return new HttpError(204,"dont redirect please");
    }
}
