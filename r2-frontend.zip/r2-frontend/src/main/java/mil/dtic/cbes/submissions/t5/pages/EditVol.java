package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesJbUploadFile;

@Secured({"ROLE_R2AppMgr"})
public class EditVol extends T5Base
{
	
  @Inject
  private ServiceAgencyDAO serviceAgencyDAO;

  @Property
  private List<ServiceAgency> serviceAgencyList; 
  
  @Property
  private ServiceAgency serviceAgency;
  
  @Property
  private BudgesJbUploadFile budgesJbUploadFile;
  
  @Property
  @Persist
  private List<BudgesJbUploadFile> volAgencyList;
  
  @Property
  private List servList; 
  
  @Property
  private String agency;
  
  @Property
  private String bookLblVol;
  
  @Property
  private String bookDesc;
  
  public void onActivate() {
	  if (volAgencyList == null){
		  volAgencyList = BudgesContext.getJbUploadFileListForAgencies();
		  
		  budgesJbUploadFile = volAgencyList.get(0);
	  }
  }
  
  Object onSuccess()
  {
	return AdministerLookupVol.class;
  }	
  
  Object onActionFromCancel()
  {
    return AdministerLookupVol.class;
  }  

}