package mil.dtic.cbes.submissions.uiobjects;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.CbesLogFactory;

/**
 * A UserListItem with PE permission data
 */
public class DetailedUserListItem extends UserListItem
{
  private static final long serialVersionUID = 1L;

  //possible radiobutton values
  public static enum RadioValue
  {
    NONE,VIEW,VIEWEDIT;

    private static final Logger log = CbesLogFactory.getLog(RadioValue.class);

    public static RadioValue fromUpe(BudgesUserAndProgramElementLink upe) {
      if (upe.isEdit()) return VIEWEDIT;
      if (upe.isView()) return VIEW;
      return NONE; //this should not happen
    }

    public void updateUpe(BudgesUserAndProgramElementLink upe) {
      switch(this)
      {
        case VIEWEDIT:
          upe.setView(true);
          upe.setEdit(true);
          break;
        case VIEW:
          upe.setView(true);
          upe.setEdit(false);
          break;
        default:
          //zomg
          log.error("An attempt to create an N/N permission from RadioValue.NONE was found... "+upe);
          //do nothing, hopefully the lack-of-saving would come to our attention
          break;
      }
    }

    @Override
	public String toString() {
      switch(this)
      {
        case VIEWEDIT:
          return "View/Edit";
        case VIEW:
          return "View Only";
        default:
          return "None";
      }
    }
  }



  private Set<ServiceAgency> newAgencies;
  private List<BudgesUserAndProgramElementLink> userPes = Collections.emptyList();
  private List<ProgramElementBase> allPes = Collections.emptyList();

  private Map<Integer, RadioValue> userPePerms = Collections.emptyMap();

  private final BudgesUser budgesUser;

  public DetailedUserListItem(LdapUser luser, BudgesUser buser, List<ServiceAgency> userAgencies,
      List<BudgesUserAndProgramElementLink> userPes,
      List<ProgramElementBase> allPes, Map<Integer, RadioValue> userPePerms)
  {
    super(luser, buser, userAgencies);
    this.budgesUser = buser;
    if (userPes==null || allPes==null || userPePerms==null)
      throw new NullPointerException("DetailedUserListItem()");
    this.userPes = userPes;
    this.allPes = allPes;
    this.userPePerms = userPePerms;
  }

  public Set<ServiceAgency> getNewAgencies()
  {
    return newAgencies;
  }

  public void setNewAgencies(Set<ServiceAgency> newAgencies)
  {
    this.newAgencies = newAgencies;
  }

  public List<BudgesUserAndProgramElementLink> getUserPes() {
    return userPes;
  }

  //Only the factory save should use this, cuz it doesn't update the map
  void setUserPes(List<BudgesUserAndProgramElementLink> userPes) {
    this.userPes = userPes;
  }

  public List<ProgramElementBase> getAllPes() {
    return allPes;
  }

  public Map<Integer, RadioValue> getUserPePerms()
  {
    return userPePerms;
  }

  /** userPes only updated on save */
  public void setUserPePerms(Map<Integer, RadioValue> userPePerms)
  {
    this.userPePerms = userPePerms;
  }

  public BudgesUser getBudgesUser()
  {
    return budgesUser;
  }
}