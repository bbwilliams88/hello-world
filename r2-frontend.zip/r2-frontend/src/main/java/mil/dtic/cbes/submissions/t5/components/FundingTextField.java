/*
 * $Id: R2EventButton.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.corelib.components.TextField;

import mil.dtic.utility.CbesLogFactory;

public class FundingTextField
{
  private static final Logger log = CbesLogFactory.getLog(FundingTextField.class);

  @SuppressWarnings("unused")
  @Component(publishParameters="annotationProvider,clientId,disabled,label,nulls,translate,validate,value", inheritInformalParameters=true)
  private TextField fundingTextField;
}
