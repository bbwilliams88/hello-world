package mil.dtic.cbes.submissions.t5.pages;

import mil.dtic.cbes.submissions.t5.base.T5Base;

public class App extends T5Base {
  public Object onActivate(){
    return NewHomePage.class;
  }
}
