package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.EventConstants;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Cached;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.EventLink;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.FormatFlag;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.NarrowPeListBy;
import mil.dtic.cbes.submissions.ValueObjects.PeSortCriteria;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementListDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.AgencyEncoder;
import mil.dtic.cbes.submissions.t5.encoders.BudgetCycleEncoder;
import mil.dtic.cbes.submissions.t5.encoders.ProgramElementListEncoder;
import mil.dtic.cbes.submissions.t5.models.BudgetCycleSelectModel;
import mil.dtic.cbes.submissions.t5.models.ServiceAgencySelectModel;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardPESelection;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.tapestry.TapestryUtil;

@Import(stylesheet={"context:/css/newPeSelectionPage.css"}, library = { "context:js/NewPeSelectionPage.js"})
public class NewPeSelectionPage extends T5Base {
    // Logger
    private static final Logger log = CbesLogFactory.getLog(NewPeSelectionPage.class);

    // For when done making selections, return back to this page
    @InjectPage
    private MJBWizardPESelection mjbWizPESelectPage;

    // Used for queries
    @Persist
    private ProgramElementListDAO pelDAO;
    @Persist
    private ProgramElementDAO peDAO;

    // Store selected R2s here in session
    private final String STORED_PE_SET_FOR_JB = "mil.dtic.cbes.storedPeSetForJb";
    @Inject
    private HttpServletRequest httpRequest;

    // In page selections
    @Persist
    private HashSet<Integer> leftSelections;
    @Persist
    private HashSet<Integer> rightSelections;

    // Left Program Element Data
    @Property @Persist
    private Map<Integer, ProgramElementList> leftPEMap;
    @Property
    private ProgramElementList currentLeftProgramElement;

    // Right Program Element Data
    @Property @Persist
    private Map<Integer, ProgramElementList> rightPEMap;
    @Property
    private ProgramElementList currentRightProgramElement;

    // Search Criteria
    @Property @Persist
    private NarrowPeListBy narrowPeListBy;

    // Column sort values
    @Property
    private String PE_NUMBER = "PE_NUMBER";
    @Component(parameters = {"event=leftSort", "context=PE_NUMBER"})
    private EventLink leftSortPENum;
    @Component(parameters = {"event=rightSort", "context=PE_NUMBER"})
    private EventLink rightSortPENum;

    @Property
    private String BA_NUMBER = "BA_NUMBER";
    @Component(parameters = {"event=leftSort", "context=BA_NUMBER"})
    private EventLink leftSortBA;
    @Component(parameters = {"event=rightSort", "context=BA_NUMBER"})
    private EventLink rightSortBA;

    @Property
    private String PE_TITLE = "PE_TITLE";
    @Component(parameters = {"event=leftSort", "context=PE_TITLE"})
    private EventLink leftSortPETitle;
    @Component(parameters = {"event=rightSort", "context=PE_TITLE"})
    private EventLink rightSortPETitle;

    @Property
    private String PROJECTS = "PROJECTS";
    @Component(parameters = {"event=leftSort", "context=PROJECTS"})
    private EventLink leftSortProjects;
    @Component(parameters = {"event=rightSort", "context=PROJECTS"})
    private EventLink rightSortProjects;

    @Property
    private String SERVICE_AGENCY = "SERVICE_AGENCY";
    @Component(parameters = {"event=leftSort", "context=SERVICE_AGENCY"})
    private EventLink leftSortSA;
    @Component(parameters = {"event=rightSort", "context=SERVICE_AGENCY"})
    private EventLink rightSortSA;

    @Property
    private String BUDGET_CYCLE = "BUDGET_CYCLE";
    @Component(parameters = {"event=leftSort", "context=BUDGET_CYCLE"})
    private EventLink leftSortBudget;
    @Component(parameters = {"event=rightSort", "context=BUDGET_CYCLE"})
    private EventLink rightSortBudget;

    @Property
    private String DEFAULT = "PE_NUMBER";

    // Maps visible column sort values to real column names
    @Persist
    private Map<String, String> sortColumnMap;

    // Left Table Sort Criteria
    @Persist
    private String leftTableSortColumn;
    @Persist
    private PeSortCriteria leftTableSortCriteria;

    // Right Table Sort Criteria
    @Persist
    private String rightTableSortColumn;
    @Persist
    private PeSortCriteria rightTableSortCriteria;

    /**
     * @brief When the page is activated, ensure persistent properties are not null
     */
    public void onActivate()
    {
        log.info("Activating NewPeSelectionPage");

        // Initialize query objects
        if (this.peDAO == null) this.peDAO = BudgesContext.getProgramElementDAO();
        if (this.pelDAO == null) this.pelDAO = BudgesContext.getProgramElementListDAO();

        // Initialize selection sets
        if (this.leftSelections == null) this.leftSelections = new HashSet<>();
        if (this.rightSelections == null) this.rightSelections = new HashSet<>();

        // Initialize PE filter object
        if (this.narrowPeListBy == null) this.narrowPeListBy = new NarrowPeListBy();

        // Initialize the sort columns
        if (this.leftTableSortColumn == null) this.leftTableSortColumn = this.DEFAULT;
        if (this.rightTableSortColumn == null) this.rightTableSortColumn = this.DEFAULT;

        // Initialize EnumMap
        if (this.sortColumnMap == null)
        {
            this.sortColumnMap = new HashMap<>();
            this.sortColumnMap.put(this.PE_NUMBER, ProgramElementList.NUMBER);
            this.sortColumnMap.put(this.BA_NUMBER, ProgramElementList.BA_NUM);
            this.sortColumnMap.put(this.PE_TITLE, ProgramElementList.TITLE);
            this.sortColumnMap.put(this.PROJECTS, ProgramElementList.NUM_PROJECTS);
            this.sortColumnMap.put(this.SERVICE_AGENCY, ProgramElementList.SERVICE_AGENCY_NAME);
            this.sortColumnMap.put(this.BUDGET_CYCLE, ProgramElementList.BUDGET_CYCLE);
            this.sortColumnMap.put(this.DEFAULT, ProgramElementList.NUMBER);
        }

        // Initialze sort criteria
        if (this.leftTableSortCriteria == null)
        {
            this.leftTableSortCriteria = new PeSortCriteria();
            this.leftTableSortCriteria.setSortColumn(this.sortColumnMap.get(this.leftTableSortColumn));
            this.leftTableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
        }
        if (this.rightTableSortCriteria == null)
        {
            this.rightTableSortCriteria = new PeSortCriteria();
            this.rightTableSortCriteria.setSortColumn(this.sortColumnMap.get(this.rightTableSortColumn));
            this.rightTableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
        }

        // Initialze the maps
        if (this.rightPEMap == null) this.rightPEMap = new LinkedHashMap<>();
        if (this.leftPEMap == null) 
        {
            this.leftPEMap = new LinkedHashMap<>();
            queryForPEs();
        }
    }

    /**
     * @brief User PE filter selections were submitted, so we need to re-query for matching PEs
     */
    public void onSuccessFromNewPeSelectionForm()
    {
        log.info("NewPeSelection Form Submit Success");
        this.leftPEMap.clear();
        queryForPEs();
    }

    /**
     * @brief Based on user's privileges, query for PEs that fit search criteria and put into a map
     */
    private void queryForPEs()
    {
        if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES))
        {
            // show all pe's
            log.info("Retrieving all pe's...");
            List<ProgramElementList> query = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(), false, false, this.narrowPeListBy, null, getStoredPeSetForJb(),
                this.leftTableSortCriteria.isAscending(), this.leftTableSortCriteria.getSortColumn());
            for (ProgramElementList pel : query)
                this.leftPEMap.put(pel.getId(), pel);
        }
        else if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY))
        {
            // show all pes for user's agencies
            log.info("Retrieving all pe's for user's agencies...");
            List<ProgramElementList> query = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(), true, false, this.narrowPeListBy, null, getStoredPeSetForJb(),
                this.leftTableSortCriteria.isAscending(), this.leftTableSortCriteria.getSortColumn());
            for (ProgramElementList pel : query)
                this.leftPEMap.put(pel.getId(), pel);
        }
        else
        { 
            // show only pe's for which user has access
            log.info("Retrieving pe's for user based on user's agencies and pe permissions...");
            List<ProgramElementList> query = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(), true, true, this.narrowPeListBy, null, getStoredPeSetForJb(),
                this.leftTableSortCriteria.isAscending(), this.leftTableSortCriteria.getSortColumn());
            for (ProgramElementList pel : query)
                this.leftPEMap.put(pel.getId(), pel);
        }
    }

    /**
     * @brief When the 'Submit PE Selections' button is pressed, add PE selections to right table
     */
    @OnEvent(component = "leftTableSelectionSubmit", value = EventConstants.SELECTED)
    public void onSelectedFromLeftTableSelectionSubmit()
    {
        log.info("Submitted PE Selections to be added to JB");
        for (Integer pel : this.leftSelections)
        {
            ProgramElementList temp = this.leftPEMap.get(pel);
            this.rightPEMap.put(pel, temp);
            this.leftPEMap.remove(pel);
        }
        this.leftSelections.clear();

        // Resort right table
        List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.rightPEMap.values());
        TapestryUtil.ognlsort(temp, this.rightTableSortCriteria.isAscending(), this.sortColumnMap.get(this.rightTableSortColumn));
        this.rightPEMap.clear();
        for (ProgramElementList pel : temp)
            this.rightPEMap.put(pel.getId(), pel);
    }

    /**
     * @brief When the 'Submit All PEs' button is pressed, add ALL PEs to the right table
     */
    @OnEvent(component = "leftTableSubmitAll", value = EventConstants.SELECTED)
    public void onSelectedFromLeftTableSubmitAll()
    {
        log.info("Submitted ALL PEs to be added to JB");
        for (Integer pel : this.leftPEMap.keySet())
        {
            ProgramElementList temp = this.leftPEMap.get(pel);
            this.rightPEMap.put(pel, temp);
        }
        this.leftPEMap.clear();
        this.leftSelections.clear();

        // Resort right table
        List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.rightPEMap.values());
        TapestryUtil.ognlsort(temp, this.rightTableSortCriteria.isAscending(), this.sortColumnMap.get(this.rightTableSortColumn));
        this.rightPEMap.clear();
        for (ProgramElementList pel : temp)
            this.rightPEMap.put(pel.getId(), pel);
    }

    /**
     * @brief When the 'Remove PE Selections' button is pressed, remove PE selections from right table
     */
    @OnEvent(component = "rightTableSelectionSubmit", value = EventConstants.SELECTED)
    public void onSelectedFromRightTableSelectionSubmit()
    {
        log.info("Submitted PE Selections to be removed from JB");
        for (Integer pel : this.rightSelections)
        {
            this.rightPEMap.remove(pel);
        }
        this.rightSelections.clear();
        
        // Refresh the left side of the table
        queryForPEs();
    }

    /**
     * @brief When the 'Remove All PEs' button is pressed, remove ALL PEs from right table
     */
    @OnEvent(component = "rightTableSubmitAll", value = EventConstants.SELECTED)
    public void onSelectedFromRightTableSubmitAll()
    {
        log.info("Submitted ALL PEs to be removed from JB");
        this.rightPEMap.clear();
        this.rightSelections.clear();
        
        // Refresh the left side of the table
        queryForPEs();
    }

    /**
     * @brief When the 'Return To JB Wizard' button is pressed
     */
    @OnEvent(component = "returnWithSelections", value = EventConstants.SELECTED)
    public Object onSelectedFromReturnWithSelections()
    {
        log.info("Returning to JB Wizard with PE selections");

        // Save right table values to session
        HashSet<Integer> set = new HashSet<Integer>(this.rightPEMap.keySet());
        TapestryUtil.setSessionVar(httpRequest, STORED_PE_SET_FOR_JB, set);

        // Clear all selections
        this.rightSelections.clear();
        this.leftSelections.clear();

        return mjbWizPESelectPage;
    }

    /**
     * @brief Sort the left table based on the provided column
     * 
     * @param sortCol column to sort the left table on
     */
    public void onLeftSort(String sortCol)
    {
        log.info("Left Sort: " + sortCol);

        // If same sort column clicked again
        if (this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(sortCol)))
        {
            // Flip the sort order
            if (this.leftTableSortCriteria.isAscending())
            {
                this.leftTableSortCriteria.setSortOrder(Constants.SORT_ORDER_DESC);
                List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.leftPEMap.values());
                TapestryUtil.ognlsort(temp, false, this.sortColumnMap.get(this.leftTableSortColumn));
                this.leftPEMap.clear();
                for (ProgramElementList pel : temp)
                    this.leftPEMap.put(pel.getId(), pel);
            }
            else 
            {
                this.leftTableSortCriteria.setSortOrder(Constants.SORT_ORDER_ASC);
                List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.leftPEMap.values());
                TapestryUtil.ognlsort(temp, true, this.sortColumnMap.get(this.leftTableSortColumn));
                this.leftPEMap.clear();
                for (ProgramElementList pel : temp)
                    this.leftPEMap.put(pel.getId(), pel);
            }
        }
        // New sort column clicked
        else
        {
            this.leftTableSortColumn = sortCol;
            this.leftTableSortCriteria.setSortColumn(this.sortColumnMap.get(this.leftTableSortColumn));
            this.leftTableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
            List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.leftPEMap.values());
            TapestryUtil.ognlsort(temp, false, this.sortColumnMap.get(this.leftTableSortColumn));
            this.leftPEMap.clear();
            for (ProgramElementList pel : temp)
                this.leftPEMap.put(pel.getId(), pel);
        }
    }

    /**
     * @brief Sort the right table based on the provided column
     * 
     * @param sortCol column to sort the right table on
     */
    public void onRightSort(String sortCol)
    {
        log.info("Right Sort: " + sortCol);

        // If same sort column clicked again
        if (this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(sortCol)))
        {
            // Flip the sort order
            if (this.rightTableSortCriteria.isAscending())
            {
                this.rightTableSortCriteria.setSortOrder(Constants.SORT_ORDER_DESC);
                List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.rightPEMap.values());
                TapestryUtil.ognlsort(temp, false, this.sortColumnMap.get(this.rightTableSortColumn));
                this.rightPEMap.clear();
                for (ProgramElementList pel : temp)
                    this.rightPEMap.put(pel.getId(), pel);
            }
            else 
            {
                this.rightTableSortCriteria.setSortOrder(Constants.SORT_ORDER_ASC);
                List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.rightPEMap.values());
                TapestryUtil.ognlsort(temp, true, this.sortColumnMap.get(this.rightTableSortColumn));
                this.rightPEMap.clear();
                for (ProgramElementList pel : temp)
                    this.rightPEMap.put(pel.getId(), pel);
            }
        }
        // New sort column clicked
        else
        {
            this.rightTableSortColumn = sortCol;
            this.rightTableSortCriteria.setSortColumn(this.sortColumnMap.get(this.rightTableSortColumn));
            this.rightTableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
            List<ProgramElementList> temp = new ArrayList<ProgramElementList>(this.rightPEMap.values());
            TapestryUtil.ognlsort(temp, false, this.sortColumnMap.get(this.rightTableSortColumn));
            this.rightPEMap.clear();
            for (ProgramElementList pel : temp)
                this.rightPEMap.put(pel.getId(), pel);
        }
    }

    /**
     * @brief Gets the selected state of the PE in the left table
     * 
     * @return True if selected, otherwise false
     */
    public boolean getCurrentLeftSelection() 
    {
        return this.leftSelections.contains(this.currentLeftProgramElement.getId());
    } 
  
    /**
     * @brief Sets the selected state of the PE in the left table
     * 
     * @param value the new selected state
     */
    public void setCurrentLeftSelection(boolean value) 
    { 
        if (value) 
        { 
            this.leftSelections.add(this.currentLeftProgramElement.getId()); 
        } 
        else 
        { 
            this.leftSelections.remove(this.currentLeftProgramElement.getId()); 
        } 
    }

    /**
     * @brief Gets the selected state of the PE in the right table
     * 
     * @return True if selected, otherwise false
     */
    public boolean getCurrentRightSelection() 
    {
        return this.rightSelections.contains(this.currentRightProgramElement.getId());
    } 

    /**
     * @brief Sets the selected state of the PE in the right table
     * 
     * @param value the new selected state
     */
    public void setCurrentRightSelection(boolean value) 
    { 
        if (value) 
        { 
            this.rightSelections.add(this.currentRightProgramElement.getId()); 
        } 
        else 
        { 
            this.rightSelections.remove(this.currentRightProgramElement.getId()); 
        } 
    }

    /**
     * @brief Take list of selected PEs(right table) and create a set of their PE IDs
     * 
     * @return Set<Integer> set of PE IDs
     */
    private Set<Integer> getStoredPeSetForJb() {
        return TapestryUtil.ognlsettransform(this.rightPEMap.values(), ProgramElementList.ID);
    }
    
    /**
     * @brief Create T5 SelectModel --> BudgetCycleSelectModel
     * 
     * @return new BudgetCycleSelectModel object
     */
    public SelectModel getBudgetCycleSelectModel()
    {
        return new BudgetCycleSelectModel(getAllBudgetCycles());
    }
    
    /**
     * @brief Create T5 SelectModel --> ServiceAgencySelectModel
     * 
     * @return new ServiceAgencySelectModel object
     */
    public SelectModel getServiceAgencySelectModel()
    {
        return new ServiceAgencySelectModel(getAvailableRdteAgencies());
    }
    
    /**
     * @brief Create T5 ValueEncoder --> BudgetCycleEncoder
     * 
     * @return new BudgetCycleEncoder object
     */
    @Cached
    public ValueEncoder<BudgetCycle> getBudgetCycleEncoder()
    {
        log.debug("getBudgetCycleEncoder");
        return new BudgetCycleEncoder();
    }
    
    /**
     * @brief Create T5 ValueEncoder --> AgencyEncoder
     * 
     * @return new AgencyEncoder object
     */
    @Cached
    public ValueEncoder<ServiceAgency> getAgencyEncoder()
    {
        log.debug("getAgencyEncoder");
        return new AgencyEncoder(getAvailableRdteAgencies());
    }

    /**
     * @brief Create T5 ValueEncoder --> ProgramElementListEncoder
     * 
     * @return new ProgramElementListEncoder object
     */
    @Cached
    public ValueEncoder<ProgramElementList> getProgramElementListEncoder()
    {
        log.debug("getProgramElementListEncoder");
        List<ProgramElementList> temp = new ArrayList<>();
        temp.addAll(this.leftPEMap.values());
        temp.addAll(this.rightPEMap.values());
        return new ProgramElementListEncoder(temp);
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE is a test PE, else false
     */
    public boolean isLeftPETest()
    {
        return this.currentLeftProgramElement.isTest();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true is current PE format is long, else false
     */
    public boolean isLeftPER2Long()
    {
        return FormatFlag.R2Long.equals(this.currentLeftProgramElement.getFormat());
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE was imported, else false
     */
    public boolean isLeftPEImport()
    {
        return Constants.PE_INITIAL_SOURCE_XML.equals(this.currentLeftProgramElement.getInitialSource());
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE is valid, else false
     */
    public boolean isLeftPEValid()
    {
        return this.currentLeftProgramElement.getSubmissionStatus().isValid();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE has warnings, else false
     */
    public boolean isLeftPEWarning()
    {
        return this.currentLeftProgramElement.getSubmissionStatus().isInvalid();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE has errors, else false
     */
    public boolean isLeftPEError()
    {
        return this.currentLeftProgramElement.getSubmissionStatus().hasErrors();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE is a test PE, else false
     */
    public boolean isRightPETest()
    {
        return this.currentRightProgramElement.isTest();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE format is long, else false
     */
    public boolean isRightPER2Long()
    {
        return FormatFlag.R2Long.equals(this.currentRightProgramElement.getFormat());
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE was imported, else false
     */
    public boolean isRightPEImport()
    {
        return Constants.PE_INITIAL_SOURCE_XML.equals(this.currentRightProgramElement.getInitialSource());
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE is valid, else false
     */
    public boolean isRightPEValid()
    {
        return this.currentRightProgramElement.getSubmissionStatus().isValid();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE has warnings, else false
     */
    public boolean isRightPEWarning()
    {
        return this.currentRightProgramElement.getSubmissionStatus().isInvalid();
    }

    /**
     * @brief For displaying badges.
     * 
     * @return true if current PE has errors, else false
     */
    public boolean isRightPEError()
    {
        return this.currentRightProgramElement.getSubmissionStatus().hasErrors();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PE_NUMBER ascending
     */
    public boolean isLeftSortedAscPENumber()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_NUMBER)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PE_NUMBER descending
     */
    public boolean isLeftSortedDescPENumber()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_NUMBER)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on BA_NUMBER ascending
     */
    public boolean isLeftSortedAscBA()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BA_NUMBER)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on BA_NUMBER descending
     */
    public boolean isLeftSortedDescBA()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BA_NUMBER)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PE_TITLE ascending
     */
    public boolean isLeftSortedAscPETitle()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_TITLE)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PE_TITLE descending
     */
    public boolean isLeftSortedDescPETitle()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_TITLE)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PROJECTS ascending
     */
    public boolean isLeftSortedAscProjects()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PROJECTS)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on PROJECTS descending
     */
    public boolean isLeftSortedDescProjects()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PROJECTS)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on SERVICE_AGENCY ascending
     */
    public boolean isLeftSortedAscSA()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.SERVICE_AGENCY)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on SERVICE_AGENCY descending
     */
    public boolean isLeftSortedDescSA()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.SERVICE_AGENCY)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on BUDGET_CYCLE ascending
     */
    public boolean isLeftSortedAscBudget()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BUDGET_CYCLE)) && this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current left sort
     * 
     * @return true if currently sorted on BUDGET_CYCLE descending
     */
    public boolean isLeftSortedDescBudget()
    {
        return this.leftTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BUDGET_CYCLE)) && !this.leftTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PE_NUMBER ascending
     */
    public boolean isRightSortedAscPENumber()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_NUMBER)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PE_NUMBER descending
     */
    public boolean isRightSortedDescPENumber()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_NUMBER)) && !this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on BA_NUMBER ascending
     */
    public boolean isRightSortedAscBA()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BA_NUMBER)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on BA_NUMBER descending
     */
    public boolean isRightSortedDescBA()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BA_NUMBER)) && !this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PE_TITLE ascending
     */
    public boolean isRightSortedAscPETitle()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_TITLE)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PE_TITLE descending
     */
    public boolean isRightSortedDescPETitle()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PE_TITLE)) && !this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PROJECTS ascending
     */
    public boolean isRightSortedAscProjects()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PROJECTS)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on PROJECTS descending
     */
    public boolean isRightSortedDescProjects()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.PROJECTS)) && !this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on SERVICE_AGENCY ascending
     */
    public boolean isRightSortedAscSA()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.SERVICE_AGENCY)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on SERVICE_AGENCY descending
     */
    public boolean isRightSortedDescSA()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.SERVICE_AGENCY)) && !this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on BUDGET_CYCLE ascending
     */
    public boolean isRightSortedAscBudget()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BUDGET_CYCLE)) && this.rightTableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying current right sort
     * 
     * @return true if currently sorted on BUDGET_CYCLE descending
     */
    public boolean isRightSortedDescBudget()
    {
        return this.rightTableSortCriteria.getSortColumn().equals(this.sortColumnMap.get(this.BUDGET_CYCLE)) && !this.rightTableSortCriteria.isAscending();
    }
}
