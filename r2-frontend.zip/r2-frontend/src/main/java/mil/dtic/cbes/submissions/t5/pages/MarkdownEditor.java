package mil.dtic.cbes.submissions.t5.pages;

import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.PersistenceConstants;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.data.config.ConfigTypeFlag;
import mil.dtic.cbes.p40.vo.Config;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CayenneUtils;

@Import( library    = { "js/markdowneditor.js" },
         stylesheet = { "context:/css/simplemde.min.css", "css/font-awesome.min.css" })
@Secured({"ROLE_R2AppMgr"})
public class MarkdownEditor extends T5Base
{
    @Inject
    JavaScriptSupport javaScriptSupport;

    @Property
    private String markdownContent;

    @Persist(PersistenceConstants.CLIENT)
    @Property
    private String configurationKey;

    void onActivate(String section)
    {
        configurationKey = section;

        fetchConfigurationContent();
    }

    Object onSuccessFromMarkdownForm()
    {
        saveConfigurationContent();

        return AdminTools.class;
    }

    public String getTitle()
    {
        if (StringUtils.equals(configurationKey, ConfigService.R2_ANNOUNCMENTS))
            return "R-2 Announcements";

        if (StringUtils.equals(configurationKey, ConfigService.R2_HELP))
            return "R-2 Help";

        if (StringUtils.equals(configurationKey, ConfigService.P40_GUIDE))
            return "P-40 Guide";
        
        if (StringUtils.equals(configurationKey, ConfigService.P40_ANNOUNCEMENTS))
            return "P-40 Announcements";

        return "Nothing or Unknown Content Specified";
    }

    private void fetchConfigurationContent()
    {
        if (configurationKey != null)
        {
            Config configurationObject = Config.fetchByName(CayenneUtils.createDataContext(), configurationKey);

            if (configurationObject != null)
                markdownContent = configurationObject.getValue();
        }
    }

    private void saveConfigurationContent()
    {
        if (configurationKey != null)
        {
            DataContext dataContext = CayenneUtils.createDataContext();

            Config configurationObject = Config.fetchByName(dataContext, configurationKey);

            if (configurationObject == null)
            {
                configurationObject = dataContext.newObject(Config.class);

                configurationObject.setName(configurationKey);
                configurationObject.setType(ConfigTypeFlag.STRING);
                configurationObject.setDescription("Markdown Text");
                configurationObject.setEnv("default");
                configurationObject.setReadOnly(false);
                configurationObject.setCreatedByUser(getUser(dataContext));
            }

            configurationObject.setValue(markdownContent);
            configurationObject.setModifiedByUser(getUser(dataContext));

            dataContext.commitChanges();
        }
    }

    private P40User getUser(DataContext dataContext)
    {
        return P40User.fetchWithLdapId(dataContext, getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
    }
}
