package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.access.DataContext;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.Link;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.PageActivationContext;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.data.config.JobSourceFlag;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.dto.StatusTrackerEntry;
import mil.dtic.cbes.jobs.AsynchJobBudgetCycle;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.output.DefaultBudgesDownloadableObject;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.Role;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.pages.userRole.UserRoleEditor;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.announcement.AnnouncementService;
import mil.dtic.utility.announcement.builder.EmailBuilder;

@Import(stack = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DATATABLESBUTTONS }, library = {"context:/js/trackingPage.js", "context:/js/jquery.jeditable.js"})
public class TrackingPage extends T5Base {
	private static final String DATE_FORMAT = "MMM dd, YYYY HH:mm";
	private static final Logger LOG = CbesLogFactory.getLog(TrackingPage.class);
	private static final String FILTER_KEY = "filterText";
	private static final String PROCDEMO = "PROCDEMO";
	private static final String DEMO = "DEMO";


	private static String STATUS_TRACKER_FIRST_ROW_TITLE = "FY %s %s Exhibit Submission and Clearance";

	@Inject
	private ComponentResources componentResources;

	@Inject
	private Request request;

	@Inject
	private JavaScriptSupport javaScriptSupport;

	@Inject
	private BudgesJobDAO jobDAO;

	@Inject
	private ServiceAgencyDAO saDAO;

	@PageActivationContext(passivate = false)
	@Property
	private String singleJobId;

	@Property
	private BudgesJob singleJob;

	@Property
	private List<BudgesJob> jobList;

	@Property
	private String resultFileSizeStr;

	@Persist
	@Property
	private String dateRange;

	@Persist
	@Property
	private boolean dateRangeChanged;

	@Persist
	@Property
	private String agencyKey;

	@Persist
	@Property
	private String jobKey;

	@Persist
	@Property
	private String sourceKey;

	@Property
	private ServiceAgency currentSA;

	@Persist
	@Property
	private List<ServiceAgency> availableAgencies;

	@Persist
	@Property
	private String workFlowKey;

	@Persist
	@Property
	private JBookWorkFlowStatus currentWorkFlowStatus;

	@Persist
	@Property
	private List<JBookWorkFlowStatus> availableworkFlows;

	@Persist
	@Property
	private String budgetCycleKey;

	@Persist
	@Property
	private Boolean initialProcess;

	@Persist
	@Property
	private AsynchJobBudgetCycle selectedBudgetCycle;

	@Persist
	@Property
	private List<AsynchJobBudgetCycle> budgetCycles;

	@Deprecated
	@Property
	private List<JobTypeFlag> jobTypeList = null;

	@Property
	private String currentJobTitle;

	@Property
	private JobTypeFlag currentJobType;

	@Persist
	@Property
	private List<JobSourceFlag> sourceTypeList;

	@Property
	private JobSourceFlag currentSourceType;

	@Property
	private boolean rfr;

	@Property
	private boolean analyst;

	@Property
	private boolean omb;

	@Property
	private boolean r2;

	@Property
	private boolean fluidUser;

	@Persist
	@Property
	private boolean hideFluidUser;

	@Inject
	@Property
	private AnnouncementService announcementService;

	@Inject
	@Property
	private EmailBuilder emailBuilder;

	public boolean isRfr() {
		r2 = false;
		analyst = false;
		omb = false;
		rfr = false;

		String role = getUserCredentials().getUserInfo().getLdapUser().getR2Role();

		if (role.equals(LdapDAO.GROUP_R2_ANALYST)) {
			if (!hideFluidUser) {
				fluidUser = isFluidUser(getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
			}
			analyst = true;
			rfr = true;
		}

		if (role.equals(LdapDAO.GROUP_OMB_ANALYST)) {
			omb = true;
			rfr = true;
		}

		if (analyst || omb) {
			return true;
		}

		r2 = true;

		return false;
	}
	
	public boolean isDeleteUser() {
		String role = getUserCredentials().getUserInfo().getLdapUser().getR2Role();
		return !omb && !(role.equals(LdapDAO.GROUP_R2_LOCALSITEADMIN) || role.equals(LdapDAO.GROUP_R2_USER));
	}

	public void setupRender() {
		isRfr();
	}

	private boolean isAnalyst() {
		return getUserCredentials().getUserInfo().getLdapUser().getR2Role().equals(LdapDAO.GROUP_R2_ANALYST);
	}

	private boolean isExaminer() {
		return getUserCredentials().getUserInfo().getLdapUser().getR2Role().equals(LdapDAO.GROUP_OMB_ANALYST);
	}

	void onActivate() {
		if (availableAgencies == null) {
			availableAgencies = getUserCredentials().getUserInfo().getAllAvailableAgencies();
			
			if (isAnalyst() || isExaminer()) {
				availableAgencies.remove(saDAO.findByCode(DEMO));
				availableAgencies.remove(saDAO.findByCode(PROCDEMO));
			}
		}

		if (null == budgetCycles) {
			LOG.trace("TrackingPage:onActivate - populate budgetCyles and determine selectedBudgetCycle");

			budgetCycles = jobDAO.getAscendingBudgetCycles();

			// CXE-7448 - start - produce a budget cycle even if AsynchJobBudgetCyles empty
			if (CollectionUtils.isNotEmpty(budgetCycles)) {
				selectedBudgetCycle = budgetCycles.get(budgetCycles.size() - 1);
			} else {
				LOG.warn("TrackingPage:onActivate - no  AsynchJobBudgetCycle's");
				BudgetCycle baseBudgetCycle = Util.getCurrentBudgetCycle();
				budgetCycles.add(new AsynchJobBudgetCycle(0, baseBudgetCycle.getLabel()));
				selectedBudgetCycle = budgetCycles.get(0);
			}
			// CXE-7448 - end
		}

		if (singleJobId != null) {
			BudgesJob requestedJob = jobDAO.findByUUID(singleJobId);

			if (requestedJob != null && availableAgencies != null
					&& availableAgencies.contains(requestedJob.getAgency())) {
				singleJob = requestedJob;
			}
		}

		currentJobType = JobTypeFlag.RFR;

		if (null == availableworkFlows) {
			availableworkFlows = new ArrayList<>();
			availableworkFlows.add(JBookWorkFlowStatus.REVIEW);
			availableworkFlows.add(JBookWorkFlowStatus.FINAL);
		}

		if (sourceTypeList == null) {
			sourceTypeList = new ArrayList<JobSourceFlag>(Arrays.asList(JobSourceFlag.values()));
			Collections.sort(sourceTypeList, new JobSourceComparator());
		}
	}

	void retrieveBooksFromDB(String days, String serviceAgencyId) {
		LOG.trace("TrackingPage:retrieveBooksFromDB - days: " + days + " serviceAgencyId: " + serviceAgencyId);
		if (jobList == null || jobList.size() <= 0) {
			LOG.trace("days = " + days);
		}

		if (StringUtils.isBlank(days)) {
			days = "-1";
		}

		List<ServiceAgency> saFilter = new ArrayList<ServiceAgency>();

		JobSourceFlag sourceTypeFilter = null;
		BudgesUser userFilter = null;

		// restrict to user's own jobs if they're not localsiteadmin or above
		if (!checkPrivilege(Privilege.TRACK_ASYNC_JOBS_FOR_OWN_AGENCIES)) {
			userFilter = getCurrentBudgesUser();
		}

		// filter by a specific agency (if available)
		if (serviceAgencyId != null && !serviceAgencyId.trim().isEmpty() && !StringUtils.equals(serviceAgencyId, "0")) {
			ServiceAgency requestedSa = saDAO.findByCode(serviceAgencyId);
			if (requestedSa != null && availableAgencies != null && availableAgencies.contains(requestedSa)) {
				saFilter.add(requestedSa);
			}
		}

		// if no specific agency, restrict to user's available agencies (unless they're
		// an app manager)
		if (saFilter.isEmpty() && !checkPrivilege(Privilege.MANAGE_ALL_ASYNC_JOBS)) {
			saFilter.addAll(availableAgencies);
		}

		// app/webservice filter
		if (sourceKey != null && !sourceKey.trim().isEmpty()) {
			if (!StringUtils.equals(sourceKey, "All")) {
				sourceTypeFilter = JobSourceFlag.valueOf(sourceKey);
			} else {
				sourceTypeFilter = null; // will skip this criteria, hence "All" of sources
			}
		}

		if (null == initialProcess) {
			LOG.trace(
					"TrackingPage:retrieveBooksFromDB - budgetCycle initialProcess is null, extracting default budgetCycle");
			selectedBudgetCycle = budgetCycles.get(budgetCycles.size() - 1);
			initialProcess = Boolean.FALSE;
		} else if (initialProcess.equals(Boolean.FALSE) && null != budgetCycleKey) {
			LOG.trace(
					"TrackingPage:retrieveBooksFromDB - budgetCycle initialProcess is not null, extracting budgetCycle from budgetCycleKey: "
							+ budgetCycleKey);

			for (AsynchJobBudgetCycle a : budgetCycles) {
				if (a.getSortId() == Integer.parseInt(budgetCycleKey)) {
					selectedBudgetCycle = a;
					break;
				}
			}
		}

		if (isRfr()) {
			if (null != initialProcess && !initialProcess) {
				if (null != workFlowKey) {
					currentWorkFlowStatus = JBookWorkFlowStatus.getByType(Integer.valueOf(workFlowKey));
				} else {
					currentWorkFlowStatus = JBookWorkFlowStatus.ALL;
				}
			}
			jobList = jobDAO.findRFRJobsByCriteria(days, saFilter, sourceTypeFilter, currentWorkFlowStatus,
					selectedBudgetCycle);
			LOG.trace(String.format(
					"retrieveBooksFromDB: R2 Analyst User - No. of jobs: %s currentWorkflowStatus: %s bugetCylce: %s",
					jobList.size(), currentWorkFlowStatus, selectedBudgetCycle));
		} else {
			jobList = jobDAO.findJobsByCriteria(days, saFilter, null, sourceTypeFilter, userFilter,
					selectedBudgetCycle);
			LOG.trace(String.format("retrieveBooksFromDB: Tracking Page User - No. of jobs: %s bugetCylce: %s",
					jobList.size(), selectedBudgetCycle));
		}

	}

	public boolean resultFileAvailable(BudgesJob job) {
		LOG.trace("inside resultfileAvailable");
		boolean rValue = false;

		if (job.getWorkingDirectory() != null && job.getResultFilename() != null) {
			File resultFile = new File(config.getWorkingFolder(), job.getWorkingDirectory());
			resultFile = new File(resultFile, job.getResultFilename());
			long size = resultFile.length();

			if (size > 0) {
				resultFileSizeStr = FileUtil.convertFileSizeToHumanReadable(size);
			} else {
				resultFileSizeStr = "";
			}

			rValue = resultFile.exists();
		}

		return rValue;
	}

	public StreamResponse onDownloadResult(String uuidStr) {
		LOG.trace("TrackingPage:onDownloadResult - start uuidStr: " + uuidStr);

		if (uuidStr != null) {
			BudgesJob job = jobDAO.findByUUID(uuidStr);

			if (job != null && job.getResultFilename() != null) {
				BudgesUser budgesUser = null;

				if (getCurrentBudgesUser().getRole().equals(LdapDAO.GROUP_R2_ANALYST)) {
					budgesUser = getCurrentBudgesUser();
				}

				LOG.trace("TrackingPage:onDownloadResult -  Found db entry for job id " + uuidStr);
				File resultFile = new File(config.getWorkingFolder(), job.getWorkingDirectory());
				resultFile = new File(resultFile, job.getResultFilename());
				if (resultFile.exists()) {
					LOG.trace("TrackingPage:onDownloadResult - Downloading result file " + resultFile + " for job id "
							+ uuidStr);
					BudgesDownloadableObject dbdo = new DefaultBudgesDownloadableObject(resultFile,
							job.getResultFilename());
					if (null != dbdo && null != budgesUser) {
						emailBuilder.buildAnalystReviewEmail(job, budgesUser);
					}
					return getStreamResponse(dbdo);
				} else {
					LOG.trace("TrackingPage:onDownloadResult- Can't download result file " + resultFile + " for job id "
							+ uuidStr + ", does not exist.");
				}
			}
		}
		return null;
	}

	/**
	 * Add the JavaScript to initialize the Datatable at the end of the render
	 * cycle.
	 */
	void afterRender() {
		LOG.trace("TrackingPage:afterRender - start");

		if (singleJobId == null) {
			LOG.trace(
					"TrackingPage:afterRender - processing afterRender for multiple jobs- creating event links for filter components");
			Link ajaxEventLink = componentResources.createEventLink("AjaxSource"); //// r2/trackingpage:ajaxsource
			Link filterByServiceOrAgencyLink = componentResources.createEventLink("FilterByServiceOrAgency"); /// r2/trackingpage:filterbyserviceoragency
			Link filterBySubmittedDateLink = componentResources.createEventLink("FilterBySubmittedDate"); //// r2/trackingpage:filterbysubmitteddate
			Link filterByWorkFlowStatus = componentResources.createEventLink("FilterByWorkFlowStatus"); /// r2/trackingpage:filterbyworkflowstatus
			Link filterByJobSourceLink = componentResources.createEventLink("FilterByJobSource"); //// r2/trackingpage:filterbyjobsource
			Link filterByBudgetCycleLink = componentResources.createEventLink("FilterByBudgetCycle"); /// r2/trackingpage:filterbybudgetcycle
			Link analystSelectChangeLink = componentResources.createEventLink("AnalystSelectChange");
			Link statusTrackerLink = componentResources.createEventLink("StatusTracker");

			// first time page is loaded set default to 24 hours (1 day)
			if (dateRange == null || dateRange.isEmpty()) {
				dateRange = "All";
			}

			if (agencyKey == null || agencyKey.isEmpty()) {
				agencyKey = "0";
			}

			if (null == workFlowKey) {
				workFlowKey = "-2";
			}

			// CXE-6470/1
			if (null == budgetCycleKey) {
				budgetCycleKey = Integer.toString(budgetCycles.get(budgetCycles.size() - 1).getSortId());
			}

			javaScriptSupport.addScript("beforeDatatable();");
			javaScriptSupport.addScript(
					String.format("setupDatatable('%s',%s);", ajaxEventLink.toString(), dateRangeChanged + ""));
			dateRangeChanged = false;

			LOG.trace("TrackingPage:afterRender - using javaScriptSupport to initialize filters");
			javaScriptSupport
					.addScript(String.format("initializeDateFilter('%s');", filterBySubmittedDateLink.toString())); //// r2/trackingpage:filterbysubmitteddate
			javaScriptSupport
					.addScript(String.format("initializeWorkFlowFilter('%s');", filterByWorkFlowStatus.toString())); /// r2/trackingpage:filterbyworkflowstatus
			javaScriptSupport.addScript(
					String.format("initializeServiceAgencyFilter('%s');", filterByServiceOrAgencyLink.toString()));
			javaScriptSupport
					.addScript(String.format("initializeBudgetCycleFilter('%s');", filterByBudgetCycleLink.toString()));
			javaScriptSupport
					.addScript(String.format("initializeSourceFilter('%s');", filterByJobSourceLink.toString()));

			javaScriptSupport.addScript(
					String.format("initializeOSDSelectChangeLink('%s')", analystSelectChangeLink.toString()));

			javaScriptSupport
					.addScript(String.format("initializeStatusTrackerLink('%s')", statusTrackerLink.toString()));
			
			LOG.trace("TrackingPage:afterRender - using javaScriptSupport to provide filter values");
			javaScriptSupport.addScript(String.format("setValueForDateFilter('%s');", dateRange));
			javaScriptSupport.addScript(String.format("setValueForSAFilter('%s');", agencyKey));
			javaScriptSupport.addScript(String.format("setValueForWorkFlowFilter('%s');", workFlowKey));
			javaScriptSupport.addScript(String.format("setValueForBudgetCycleFilter('%s');", budgetCycleKey));

			if (sourceKey == null || sourceKey.isEmpty()) {
				javaScriptSupport.addScript(String.format("setValueForJobSourceFilter('%s');", "All"));
			} else {
				javaScriptSupport.addScript(String.format("setValueForJobSourceFilter('%s');", sourceKey));
			}

			LOG.debug("TrackingPage:afterRender -completed afterRender for multiple jobs");
		} else if (singleJob != null && singleJob.getJobStatus() != null
				&& singleJob.getJobStatus().isStillProcessing()) {
			LOG.debug("TrackingPage:afterRender - processing afterRender single job");
			javaScriptSupport.addScript("refreshUntilComplete(5000);");
		}
	}

	void onAnalystSelectChange() {
		LOG.info("TrackingPage:onAnalystSelectChange - start");

		String uuid = request.getParameter("uuid");

		if (StringUtils.isNotEmpty(request.getParameter("uuid"))) {
			LOG.info("UUID of selected row is: " + uuid);

			boolean checked = new Boolean(request.getParameter("checked"));

			LOG.info(String.format("Analyst select column %s checked", checked ? "is" : "is not"));

			BudgesJob job = jobDAO.findByUUID(uuid);

			if ("osdSelect".equalsIgnoreCase(request.getParameter("userType"))) {
				LOG.info("Processing column selection for OSD analyst user");

				if (checked) {
					job.setOsdAnalystSelected(true);
					job.setOsdAnalystDate(new Date());
					job.setOsdAnalystName(getUserCredentials().getUserInfo().getBudgesUser().getFullName());
				} else {
					job.setOsdAnalystSelected(false);
					job.setOsdAnalystDate(null);
					job.setOsdAnalystName(null);
				}
			} else if ("ombSelect".equalsIgnoreCase(request.getParameter("userType"))) {
				LOG.info("Processing column selection for OMB analyst user");

				if (checked) {
					job.setOmbAnalystSelected(true);
					job.setOmbAnalystDate(new Date());
					job.setOmbAnalystName(getUserCredentials().getUserInfo().getBudgesUser().getFullName());
				} else {
					job.setOmbAnalystSelected(false);
					job.setOmbAnalystDate(null);
					job.setOmbAnalystName(null);
				}
			} else {
				LOG.warn("No OSD or OMB analyst user value detected...");
			}

			jobDAO.saveOrUpdate(job);
			
			if (JBookWorkFlowStatus.FINAL.getType() == job.getReadyForReview() && job.getOmbAnalystSelected() && job.getOsdAnalystSelected()) {
				LOG.info("FINAL Jbook status and OMB/OSD analyst approved. Book is Ready for Print");
				emailBuilder.buildReadyForPrintEmail(job, getCurrentBudgesUser());
			}
		}
	}

	// onFilter called when the filter value changes
	void onFilterBySubmittedDate() {
		LOG.trace("TrackingPage:onFilterBySubmittedDate - start");
		dateRange = request.getParameter(FILTER_KEY);
		dateRangeChanged = true;
	}

	void onFilterByWorkFlowStatus() {
		workFlowKey = request.getParameter(TrackingPage.FILTER_KEY);
		LOG.debug("TrackingPage:onFilterByWorkFlowStatus - activiated with workFLowKey: " + workFlowKey);

		if (null == workFlowKey) {
			currentWorkFlowStatus = JBookWorkFlowStatus.ALL;
		} else {
			currentWorkFlowStatus = JBookWorkFlowStatus.getByType(Integer.valueOf(workFlowKey));
		}
	}

	void onFilterByBudgetCycle() {
		budgetCycleKey = request.getParameter(TrackingPage.FILTER_KEY);
		LOG.debug("TrackingPage:onFilterByBudgetCycle - activiated with budgetCycleKey: " + budgetCycleKey);

		if (null == budgetCycleKey) {
			budgetCycleKey = "0";
		}
	}

	void onFilterByServiceOrAgency() {
		agencyKey = request.getParameter(FILTER_KEY);
		if (agencyKey == null || agencyKey.trim().isEmpty()) {
			agencyKey = "0";
		}
	}

	void onFilterByJobType() {
		jobKey = request.getParameter(FILTER_KEY);
	}

	void onFilterByJobSource() {
		sourceKey = request.getParameter(FILTER_KEY);

		if (sourceKey == null || sourceKey.trim().isEmpty()) {
			sourceKey = "All";
		}
	}

	JSONObject onAjaxSource() {
		LOG.debug("TrackingPage:onAjaxSource - start");
	
		String echo = request.getParameter("sEcho");
		LOG.trace("TrackingPage:onAjaxSource - echo: " + echo);

		JSONObject rootObj = new JSONObject();
		BudgesJob jobEntry;

		if (jobList == null || jobList.size() <= 0) {
			LOG.trace("TrackingPage:onAjaxSource - calling retrieveBooksFromDB");
			retrieveBooksFromDB(dateRange, agencyKey);
		}

		if (jobList != null) {
			LOG.trace("TrackingPage:onAjaxSource - processing jobList");
			
			JSONArray columnsArray = new JSONArray();

			// Iterate the list to add the rows for the table.
			for (int i = 0; i < jobList.size(); i++) {
				JSONObject jsonObject = new JSONObject();

				jobEntry = jobList.get(i);

				if (resultFileAvailable(jobEntry)) {
					String link = componentResources.createEventLink("DownloadResult", jobEntry.getUuidStr())
							.toString();

					String linkText = jobEntry.getUuidStr();

					if (isAnalystOrOMBUser()) {
						linkText = "Download";
					}

					jsonObject.put("trackingNumber", "<a href='" + link + "'>" + linkText + "</a>");
				} else {
					if (isRfr() && jobEntry.getReadyForReview() > 0) { // CXE-6479
						continue; //comment out for local development 
					} else {
						jsonObject.put("trackingNumber", jobEntry.getUuidStr());
					}
				}

				jsonObject.put("budgetCycle", jobEntry.getBudgetCycle());

				String jobAppn = jobEntry.getAppropriation();
				if (null == jobAppn) {
					jobAppn = "";
				}
				else {
					jobAppn = jobAppn.replaceAll("\\( ", "(").replaceAll(" \\)", ")");
				}
				jsonObject.put("appropriation", jobAppn);

				String jobTitle = jobEntry.getVolumeTitleAggregation();
				if (null == jobTitle || jobTitle.equals(Constants.WEB_SERVICE_NULL_VALUE) || jobTitle.equals(Constants.TITLES_UNDEFINED) || jobTitle.equals("null,")) {
					jobTitle = "";
				}
				jsonObject.put("title", jobTitle);

				jsonObject.put("source", jobEntry.getSource().getDesc());

				if (jobEntry.getJobStatus().isCompletedSuccessfully()) {
					jsonObject.put("status",
							"<span class='text-success'>" + jobEntry.getJobStatus().getDesc() + "</span>");
				} else if (jobEntry.getJobStatus().isStillProcessing()) {
					jsonObject.put("status", jobEntry.getJobStatus().getDesc());
				} else {
					jsonObject.put("status",
							"<span class='text-danger'>" + jobEntry.getJobStatus().getDesc() + "</span>");
				}

				jsonObject.put("user", getName(jobEntry.getCreatedByBudgesUser()));

				jsonObject.put("agency", null2empty(jobEntry.getAgency().getCode()));

				if (jobEntry.getDateCreated() != null) {
					String formattedCreatedDate = newDateTimeFormatter(DATE_FORMAT).format(jobEntry.getDateCreated());
					jsonObject.put("dateCreated", formattedCreatedDate);
				} else {
					jsonObject.put("dateCreated", "");
				}

				if (jobEntry.getReadyForReview() != null) {
					JBookWorkFlowStatus.getByType(jobEntry.getReadyForReview()).getDisplayName();
					jsonObject.put("workflowStatus",
							JBookWorkFlowStatus.getByType(jobEntry.getReadyForReview()).getDisplayName());
				} else {
					jsonObject.put("workflowStatus", "");
				}

				jsonObject.put("osdAnalystSelected", jobEntry.getOsdAnalystSelected());
				jsonObject.put("osdAnalystName",
						jobEntry.getOsdAnalystName() == null ? StringUtils.EMPTY : jobEntry.getOsdAnalystName());
				jsonObject.put("osdClearedDate", jobEntry.getOsdAnalystDate() == null ? StringUtils.EMPTY
						: jobEntry.getOsdAnalystDate().toString());

				jsonObject.put("ombAnalystSelected", jobEntry.getOmbAnalystSelected());
				jsonObject.put("ombAnalystName",
						jobEntry.getOmbAnalystName() == null ? StringUtils.EMPTY : jobEntry.getOmbAnalystName());
				jsonObject.put("ombClearedDate", jobEntry.getOmbAnalystDate() == null ? StringUtils.EMPTY
						: jobEntry.getOmbAnalystDate().toString());

				columnsArray.put(jsonObject);
			}
			rootObj.put("sEcho", echo);
			rootObj.put("aaData", columnsArray);
		}

		LOG.trace("TrackingPage:onAjaxSource - finished returning data: " + rootObj);

		return rootObj;
	}

	private List<BudgesJob> newList(String searchText) {
		LOG.trace("TrackingPage:newList - start searchText: " + searchText);
		List<BudgesJob> newList = new ArrayList<BudgesJob>();
		BudgesJob bj;
		String searchStr = searchText.toLowerCase();
		LOG.trace("searchStr: " + searchStr);
		String dateCreated = "";

		for (int i = 0; i < jobList.size(); i++) {
			bj = jobList.get(i);
			if (bj.getDateCreated() != null) {
				dateCreated = formatDatetime(bj.getDateCreated());
			} else {
				dateCreated = " ";
			}

			try {
				if (bj.getUuidStr().toLowerCase().contains(searchStr)
						|| ((null != bj.getAppropriation()) && bj.getAppropriation().toLowerCase().contains(searchStr))
						|| ((null != bj.getBudgetCycle()) && bj.getBudgetCycle().toLowerCase().contains(searchStr))
						|| (null != bj.getVolumeTitleAggregation()
								&& bj.getVolumeTitleAggregation().toLowerCase().contains(searchStr))
						|| bj.getSource().getDesc().toLowerCase().contains(searchStr)
						|| bj.getJobStatus().getDesc().toLowerCase().contains(searchStr)
						|| ((null != bj.getReadyForReview()) && JBookWorkFlowStatus.getByType(bj.getReadyForReview())
								.getDisplayName().toLowerCase().contains(searchStr))
						|| getName(bj.getCreatedByBudgesUser()).toLowerCase().contains(searchStr)
						|| bj.getAgency().getCode().toLowerCase().contains(searchStr)
						|| dateCreated.toLowerCase().contains(searchStr)) {
					LOG.trace(
							"TrackingPage:newList - searchtext is contained within an array value for the processed job: "
									+ bj.getUuidStr());
					newList.add(bj);
				}
			} catch (RuntimeException re) {
				LOG.warn("TrackingPage:newList - tracking filter error: " + re.getMessage() + " on job: "
						+ bj.getUuidStr());
			}
		}

		return newList;
	}

	private String null2empty(String a) {
		return a + " ";
	}

	private class JobSourceComparator implements Comparator<JobSourceFlag> {
		@Override
		public int compare(JobSourceFlag o1, JobSourceFlag o2) {
			int sortDirection = 1; // ascending
			return o1.getDesc().compareTo(o2.getDesc()) * sortDirection;
		}
	}

	// CXE-6609
	void onSuccess() {
		LOG.trace("TrackingPage:onSuccess");
		String ldapId = getUserCredentials().getUserInfo().getLdapUser().getLdapUserId();
		try {
			processRoleChange(ldapId, UserRoleEditor.R2APPMGR);
			hideFluidUser = true;
		} catch (Exception e) {
			LOG.error("TrackingPage:onSuccess - failed to execute processRoleChange: " + e.getMessage(), e);
		}
	}

	// CXE-6609 - TODO: move this to common
	private boolean processRoleChange(String ldapId, String role) throws Exception {
		LOG.trace("TrackingPage:processRoleChange");
		boolean roleUpdated = false;
		if (null == ldapId)
			return roleUpdated;

		BudgesUser user = BudgesContext.getBudgesUserDAO().findByUserLdapId(ldapId);
		if (null == user)
			return roleUpdated;

		boolean roleIntegrated = false;
		String ldapException = null;
		DataContext dataContext = CayenneUtils.createDataContext();

		if (processP40ByFetchedLdap(dataContext, ldapId, role)) {
			roleUpdated = true;
			LdapUser luser = null;
			boolean checkForDevMode = false;

			try {
				luser = BudgesContext.getLdapDAO().getLdapUser(ldapId);
			} catch (Exception ldapE) {
				ldapException = ldapE.getMessage(); // save value if we need to throw the exception
				checkForDevMode = true;
				LOG.error("processRoleChange: LDAPException capturing ldap for user: " + ldapId);
			}

			if (checkForDevMode) { // get mock ldapUser if available.
				luser = getMockLdapUser(user, getUserCredentials().getUserInfo().getBudgesUser());
			}

			if (null != luser) {
				luser.setR2Role(role);
				BudgesContext.getBudgesUserDAO().saveLdapData(user, luser);
				if (user.getRole().equals(role)) {
					roleIntegrated = true;
				}
				BudgesContext.getBudgesUserDAO().evict(user);
			} else {
				throw new Exception(ldapException);
			}
		}

		LOG.debug("processRoleChange: - executed with roleUpdated: " + roleUpdated + " roleIntegrated: "
				+ roleIntegrated);
		return roleIntegrated;
	}

	// CXE-6609
	private boolean processP40ByFetchedLdap(DataContext context, String ldapId, String role) {
		LOG.trace("TrackingPage:processP40ByFetchedLdap: ldapId: " + ldapId);
		boolean updated = false;
		String formattedRole = Role.APPMGR;

		if (null == formattedRole) {
			return updated;
		}
		ObjectContext objectContext = context;
		P40User user = P40User.fetchWithLdapId(objectContext, ldapId);

		if (null == user) {
			LOG.error("processP40ByFetchedLdap: - failed to generate a P40User for ldapId: " + ldapId);
			return updated;
		}

		List<Role> userRoles = user.getRoles();
		if (userRoles.size() > 1) {
			try {
				for (Role r : userRoles) {
					user.removeFromRoles(r);
				}
			} catch (ConcurrentModificationException cme) {
				LOG.error("processP40ByFetchedLdap: ConcurrentModificationException processing roles for user: "
						+ ldapId + " msg: " + cme.getMessage());
			} catch (Exception e) {
				LOG.error("processP40ByFetchedLdap: General Exception processing roles for user: " + ldapId + " msg: "
						+ e.getMessage());
			}
		} else {
			if (userRoles.size() == 1) {
				if (formattedRole.equals(userRoles.get(0).getName())) {
					return true; // no need to further process.
				} else {
					user.removeFromRoles(userRoles.get(0));
				}
			}
		}

		if (null != user && user.getUserLdapId().equals(ldapId)) {
			try {
				CayenneUtils.copyToContext(user, context);
				if (!formattedRole.equals(LdapDAO.GROUP_NONE)) {
					Role p40Role = Role.fetchByName(user.getObjectContext(), formattedRole);
					user.addToRoles(p40Role);
				}
				user.getObjectContext().commitChanges();
				updated = true;
			} catch (RuntimeException re) {
				LOG.error("processP40ByFetchedLdap: failed to update user_role table with new user - msg: "
						+ re.getMessage());
			}
		}
		return updated;
	}

	// CXE-6609 - for dev environment.
	private LdapUser getMockLdapUser(BudgesUser bUser, BudgesUser admin) {
		LOG.error(UserRoleEditor.USING_MOCK_LDAP);
		LdapUser luser = null;
		if (UserRoleEditor.PSUEDO_LDAP) {
			if (admin.getEmail().equals(UserRoleEditor.PSEUDO_LDAP_MAIL)) {
				luser = new LdapUser();
				luser.setLdapUserId(bUser.getUserLdapId());
				luser.setGroupSet(LdapDAO.VALID_GROUPS_SET);
				luser.setEmailAddress(bUser.getEmail());
				luser.setPhoneNumber(bUser.getPhoneNumber());
				luser.setR2Role(bUser.getRole());
				luser.setFullName(bUser.getFullName());
				luser.setFirstName(bUser.getFirstName());
				luser.setLastName(bUser.getLastName());
				luser.setMiddleInitial(bUser.getMiddleInitial());
			}
		}
		return luser;
	}

	public Object onStatusTracker() throws InvalidFormatException {
		Set<StatusTrackerEntry> set;

//		String bcLabel = selectedBudgetCycle.getLabel();

		// List<BudgesJob> jobsTest = jobDAO.findJobsByCriteria(bcLabel, new Integer[] {
		// 1, 3 }, JobStatusFlag.DONE);
		List<BudgesJob> jobsTest = jobDAO.findRFRJobsByCriteria(null, null, null, JBookWorkFlowStatus.ALL,
				selectedBudgetCycle);
		List<BudgesJob> jobsTestOnSystem = new ArrayList<BudgesJob>();
		
		for (BudgesJob job : jobsTest) {
			if (resultFileAvailable(job)) {
				jobsTestOnSystem.add(job);
			}
		}
		
		/* Commented out, use for local development		
		for (BudgesJob job : jobsTest) {
			jobsTestOnSystem.add(job);
		}
		*/
		
		if (CollectionUtils.isNotEmpty(jobsTestOnSystem)) {
			set = createSet(jobsTestOnSystem);

			LOG.info("Set of " + set.size() + " created...");

			if (CollectionUtils.isNotEmpty(set)) {
				try {
					InputStream file = null;

					ClassLoader classLoader = TrackingPage.class.getClassLoader();
					File uploadFile = new File(config.getWorkingFolder() + "/" + R2Storage.STATUS_TRACKER_FILENAME);
//					String titleSplit1 = selectedBudgetCycle.getLabel();
					
					if(uploadFile.exists()) {
						FileInputStream inputStream = new FileInputStream(uploadFile);
						Workbook workbook = new XSSFWorkbook(inputStream);
						processStatusTrackerEntries(set, workbook);
						
						File workingFolder = createFileInUpload();
						String fileName = "JBook_Status_Tracker.xlsx";
						LOG.info("ABSOLUTE FILE PATH: " + workingFolder.getAbsolutePath());
						String filePath = workingFolder.getAbsolutePath() + File.separator + fileName; 

						FileOutputStream outputStream = new FileOutputStream(filePath);
						workbook.write(outputStream);
						workbook.close();
						outputStream.close();

//						InputStream is = new FileInputStream(filePath);
						File resultFile = new File(filePath);
						LOG.info("Retrieved file: " + resultFile);
						BudgesDownloadableObject dbdo = new DefaultBudgesDownloadableObject(resultFile, fileName);

						return getStreamResponse(dbdo);
					}
					
					else if (null != classLoader) {
						file = classLoader.getResourceAsStream("JBook_Status_Tracker_Template.xlsx");
						
						Workbook workbook = new XSSFWorkbook(file);
						
						processStatusTrackerEntries(set, workbook);
						file.close();
						File workingFolder = createFileInUpload();
						String fileName = "JBook_Status_Tracker.xlsx";
						LOG.info("ABSOLUTE FILE PATH: " + workingFolder.getAbsolutePath());
						String filePath = workingFolder.getAbsolutePath() + File.separator + fileName; 

						FileOutputStream outputStream = new FileOutputStream(filePath);
						workbook.write(outputStream);
						workbook.close();
						outputStream.close();

//						InputStream is = new FileInputStream(filePath);
						File resultFile = new File(filePath);
						LOG.info("Retrieved file: " + resultFile);
						BudgesDownloadableObject dbdo = new DefaultBudgesDownloadableObject(resultFile, fileName);

						return getStreamResponse(dbdo);
					}	
					

				} catch (FileNotFoundException e) {
					LOG.warn("File not found!");
				} catch (IOException e) {
					LOG.warn("An IOException was thrown!");
				}
			}
		}
		return null;
	}

	public boolean isAnalystOrOMBUser() {
		return omb || analyst;
	}

	private Set<StatusTrackerEntry> createSet(List<BudgesJob> list) {
		LOG.info("TrackingPage - createSet(); generating Set out of " + list.size() + " jobs...");

		Set<StatusTrackerEntry> resultSet = new HashSet<>();
		Set<StatusTrackerEntry> tempSet = new HashSet<>();

		HashMap<String, Date> books = new HashMap<>();
		HashMap<String, Date> tempBooks= new HashMap<>();

		for (BudgesJob b : list) {
			boolean ombAnalst;
			boolean osdAnalyst;
			String ombDate;
			String osdDate;
			String dateCreatedAj = b.getDateCreated().toString().substring(0, 10);
			Date dateCreatedFormatted = b.getDateCreated();
			String dateFinalSubmitted = b.getDateModified().toString().substring(0, 10);
			String submitter = "";
			String agencyAppr = b.getAgency().getCode() + b.getAppropriation().replaceAll("\\D+", "") + JBookWorkFlowStatus.getByType(b.getReadyForReview()).getCode();
			Date tempDate = b.getDateCreated();

			if(books.isEmpty()) {
				books.put(agencyAppr, b.getDateCreated());
			}
			else {
				for(HashMap.Entry<String,Date> entry : books.entrySet()) {
					String key = entry.getKey();
					Date value = entry.getValue();
					
					if(key.equals(agencyAppr)) {
						if(b.getDateCreated().after(value)){
							tempDate = b.getDateCreated();
						}
						else{
							tempDate = value;
						}
					}

					if(tempBooks.isEmpty()){
						tempBooks.put(agencyAppr, tempDate);
					}
					else{
						tempBooks.remove(agencyAppr);
						tempBooks.put(agencyAppr, tempDate);
					}
					
				}
				books.remove(agencyAppr);
				books.put(agencyAppr, tempBooks.get(agencyAppr));
			}
			

			if(b.getDateCreated().compareTo(books.get(agencyAppr)) == 0){
					
				if(b.getSource().getVal() == "WebService"){
					submitter = "Web Service";
				}
				else{
					submitter = b.getCreatedByBudgesUser().getFullName();
				}
			

				if (null == b.getOmbAnalystSelected() || !b.getOmbAnalystSelected()) {
					ombAnalst = false;
					ombDate = "";
				} else {
					ombAnalst = true;
					ombDate = b.getOmbAnalystDate().toString().substring(0, 10);
				}
			
				if (null == b.getOsdAnalystSelected() || !b.getOsdAnalystSelected()) {
					osdAnalyst = false;
					osdDate = "";
				} else {
					osdAnalyst = true;
					osdDate = b.getOsdAnalystDate().toString().substring(0, 10);
				}
				
				resultSet.add(new StatusTrackerEntry(b.getAgency().getCode(), b.getAppropriation().replaceAll("\\D+", ""),
						osdAnalyst, ombAnalst, osdDate, ombDate, dateCreatedAj, dateCreatedFormatted, dateFinalSubmitted, submitter, JBookWorkFlowStatus.getByType(b.getReadyForReview())));
			}
		}


		for(StatusTrackerEntry element : resultSet){
			String agencyApprTmp = element.getAgencyCode() + element.getAppnNumber() + element.getStatus().getCode();

			if(books.get(agencyApprTmp).compareTo(element.getDateCreatedFormatted()) != 0){
				tempSet.add(element);
			}
		}

		for(StatusTrackerEntry ele : tempSet){
			resultSet.remove(ele);
		}

		return resultSet;
	}

	private void processStatusTrackerEntries(Set<StatusTrackerEntry> set, Workbook workbook) {
		LOG.info("TrackingPage - processStatusTrackerEntries()");

		if (CollectionUtils.isNotEmpty(set) && null != workbook) {
			Sheet sheet = workbook.getSheetAt(0);
			
			int rfrSubCount = 0;
			int rfrOUSDCount = 0;
			int rfrOMBCount = 0;
			int finalSubCount = 0;
			int finalOUSDCount = 0;
			int finalOMBCount = 0;
			
			if (null != sheet) {
				String[] split = selectedBudgetCycle.getLabel().split(" ");
				workbook.setSheetName(0, split[0] + " " + split[1]);
				FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
				LOG.info("Selected Budget Cycle " + selectedBudgetCycle.getLabel());

				Row topRow = sheet.getRow(0);
				Row headerRow = sheet.getRow(1);
				Row colHeaderRow = sheet.getRow(2);
				
				if(split[0].contains("BES")) {
					for(int i=8; i<12; i++) {
						headerRow.removeCell(headerRow.getCell(i));
						colHeaderRow.removeCell(colHeaderRow.getCell(i));
					}
				}

				if (null != topRow) {
					topRow.getCell(0).setCellValue(String.format(STATUS_TRACKER_FIRST_ROW_TITLE, split[1], split[0]));

					LOG.info("Set top row of spreadsheet to "
							+ String.format(STATUS_TRACKER_FIRST_ROW_TITLE, split[1], split[0]));

					for (StatusTrackerEntry statusEntry : set) {
						String agencyCode = statusEntry.getAgencyCode();
						String appn = statusEntry.getAppnNumber();
						String osdDate = statusEntry.getOsdSelectedDate();
						String ombDate = statusEntry.getOmbSelectedDate();
						String dateCreatedAj = statusEntry.getDateCreatedAj();
						String dateFinalSubmitted = statusEntry.getDateFinalSubmitted();
						String submitter = statusEntry.getSubmitter();

						if (StringUtils.isNotBlank(appn) && StringUtils.isNotBlank(agencyCode)) {
							LOG.info("Job Agency code: " + agencyCode);
							LOG.info("Job Appropriation: " + appn);

							for (Row r : sheet) {
								Cell sacell = r.getCell(0);
								Cell appnCell = r.getCell(2);
								Cell submitterCell = r.getCell(3);
								
								
								if (null != sacell && null != appnCell) {
									String saVal = (null != sacell && sacell.getCellType() == Cell.CELL_TYPE_STRING
											? sacell.getRichStringCellValue().getString()
											: StringUtils.EMPTY);

									String appnVal = (null != appnCell ? appnCell.toString() : StringUtils.EMPTY);

									LOG.info("Spreadsheet Agency code: " + saVal);
									LOG.info("Spreadsheet Appropriation: " + appnVal);

									if (appnVal.contains(".")) {
										appnVal = appnVal.substring(0, appnVal.indexOf("."));

										LOG.info("Spreadsheet appropriation value changed too " + appnVal);
									}

									if (StringUtils.isNotBlank(saVal) && StringUtils.isNotBlank(appnVal)) {
										boolean isAppn = false;
										boolean isAgencyCode = false;

										if (appnVal.equals("0360") && saVal.equals("DPAP")) {
											LOG.info("Special case for appnVal: 3060 and saVal: DPAP encountered...");

											isAppn = appnVal.equalsIgnoreCase(appn);
											isAgencyCode = agencyCode.equalsIgnoreCase("OSD");
										} else if (appnVal.equals("0403") && saVal.equals("CHIPS")) {
											LOG.info("Special case for appnVal: 0403 and saVal: CHIPS encountered...");

											isAppn = appnVal.equalsIgnoreCase(appn);
											isAgencyCode = agencyCode.equalsIgnoreCase("OSD");
										} else if ((appnVal.equals("3620") || appnVal.equals("3022"))
												&& saVal.equals("Space Force")) {

											LOG.info(
													"Special case for appnVal: 3620/3022 and saVal: Space Force encountered...");
											isAppn = appnVal.equalsIgnoreCase(appn);
											isAgencyCode = agencyCode.equalsIgnoreCase("AF");
										} else if (appnVal.equals("1109") && saVal.equals("MC")) {
											LOG.info("Special case for appnVal: 1109 and saVal: MC encountered...");

											isAppn = appnVal.equalsIgnoreCase(appn);
											isAgencyCode = agencyCode.equalsIgnoreCase("NAVY");
										}

										else {
											isAppn = appnVal.equalsIgnoreCase(appn);
											isAgencyCode = sacell.getRichStringCellValue().getString()
													.equalsIgnoreCase(agencyCode);
										}
										
										if (isAgencyCode && isAppn) {
											if (statusEntry.getStatus() == JBookWorkFlowStatus.REVIEW) {
												LOG.info("Workflow status: RFRSUB");
												Cell rfrSubCell = r.getCell(6);
												rfrSubCell.setCellType(Cell.CELL_TYPE_STRING);
												rfrSubCell.setCellValue(dateCreatedAj);
												rfrSubCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												rfrSubCount++;
												submitterCell.setCellType(Cell.CELL_TYPE_STRING);
												submitterCell.setCellValue(submitter);
												submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
											}
											if (statusEntry.isOsdSelected() && statusEntry.getStatus() == JBookWorkFlowStatus.REVIEW) { 
												LOG.info("Workflow status: RFROUSD");
												Cell rfrOUSDCell = r.getCell(7);
												rfrOUSDCell.setCellType(Cell.CELL_TYPE_STRING);
												rfrOUSDCell.setCellValue(osdDate);
												rfrOUSDCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												rfrOUSDCount++;
												submitterCell.setCellType(Cell.CELL_TYPE_STRING);
												submitterCell.setCellValue(submitter);
												submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
											}
											if(split[0].contains("PB")) {
												if (statusEntry.isOmbSelected() && statusEntry.getStatus() == JBookWorkFlowStatus.REVIEW) {
													LOG.info("Workflow status: RFROMB");
													Cell rfrOMBCell = r.getCell(8);
													rfrOMBCell.setCellType(Cell.CELL_TYPE_STRING);
													rfrOMBCell.setCellValue(ombDate);
													rfrOMBCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
													rfrOMBCount++;
													submitterCell.setCellType(Cell.CELL_TYPE_STRING);
													submitterCell.setCellValue(submitter);
													submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												}
												if (statusEntry.getStatus() == JBookWorkFlowStatus.FINAL) {
													LOG.info("Workflow status: FINALSUB");
													Cell finalSubCell = r.getCell(9);
													finalSubCell.setCellType(Cell.CELL_TYPE_STRING);
													finalSubCell.setCellValue(dateFinalSubmitted);
													finalSubCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
													finalSubCount++;
													submitterCell.setCellType(Cell.CELL_TYPE_STRING);
													submitterCell.setCellValue(submitter);
													submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												}
												if (statusEntry.isOsdSelected() && statusEntry.getStatus() == JBookWorkFlowStatus.FINAL) {
													LOG.info("Workflow status: FINALOUSD");
													Cell finalOUSDCell = r.getCell(10);
													finalOUSDCell.setCellType(Cell.CELL_TYPE_STRING);
													finalOUSDCell.setCellValue(osdDate);
													finalOUSDCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
													finalOUSDCount++;
													submitterCell.setCellType(Cell.CELL_TYPE_STRING);
													submitterCell.setCellValue(submitter);
													submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												}
												if (statusEntry.isOmbSelected() && statusEntry.getStatus() == JBookWorkFlowStatus.FINAL) {
													LOG.info("Workflow status: FINALOMB");
													Cell finalOMBCell = r.getCell(11);
													finalOMBCell.setCellType(Cell.CELL_TYPE_STRING);
													finalOMBCell.setCellValue(ombDate);
													finalOMBCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
													finalOMBCount++;	
													submitterCell.setCellType(Cell.CELL_TYPE_STRING);
													submitterCell.setCellValue(submitter);
													submitterCell.getCellStyle().setAlignment(CellStyle.ALIGN_CENTER);
												}										
											}
										}
									}
								}
							}
						}
					}
					if(null != headerRow) {
						headerRow.getCell(6).setCellValue(rfrSubCount);
						headerRow.getCell(7).setCellValue(rfrOUSDCount);
						if(split[0].contains("PB")) {					
							headerRow.getCell(8).setCellValue(rfrOMBCount);
							headerRow.getCell(9).setCellValue(finalSubCount);
							headerRow.getCell(10).setCellValue(finalOUSDCount);
							headerRow.getCell(11).setCellValue(finalOMBCount);
						}
					}
				}
			}
		}
	}
}
