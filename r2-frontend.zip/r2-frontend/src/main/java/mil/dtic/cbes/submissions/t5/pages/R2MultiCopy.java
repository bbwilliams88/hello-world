package mil.dtic.cbes.submissions.t5.pages;

import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.tapestry5.FieldFocusPriority;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserAndProgramElementLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.service.SaveService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.validation.ValidationHelper;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.Util.CloneFailedException;


/**
 * Copy multiple R-2s, possibly changing the budget cycle on all of them.
 */
@Import(stack=CbesT5SharedModule.JQUERYSTACK,library="context:/js/r2multicopy.coffee")
public class R2MultiCopy extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(R2MultiCopy.class);
  @Inject
  private JavaScriptSupport jsSupport;
  //@Inject
  //private ComponentResources resources;


  @Inject
  private BudgetCycleDAO bcDAO;
  @Inject
  private ProgramElementDAO peDAO;
  @Inject
  private BudgesUserAndProgramElementLinkDAO peLinkDAO;
  @Inject
  private SaveService saveService;


  @InjectPage
  private R2Select r2Select;
  @InjectPage
  private NewR2Manage newr2Manage;
  @Component
  private Form form;


  @SessionState
  @Property
  private DbExhibitSelection selection;
  @Persist
  @Property
  private BudgetCycle newBudgetCycle;
  @Persist
  @Property
  private ServiceAgency agency;
  @Persist
  private Boolean agencyWasSet;
  @Property
  private Boolean copyPerms;
  @Property
  private Boolean test;
  @Property
  private String tag;


  @Log
  void onActivate()
  {
    if (newBudgetCycle == null) {
      newBudgetCycle = Util.getCurrentBudgetCycle();
    }
    if (agencyWasSet == null && getCurrentBudgesUser().getAgencies().size() > 0) {
      agency = getCurrentBudgesUser().getAgencies().iterator().next();
      agencyWasSet = true;
    }
    if (copyPerms == null) {
      copyPerms = true;
    }
    if (test == null) {
      test = false;
    }
  }

  void afterRender()
  {
    jsSupport.autofocus(FieldFocusPriority.OVERRIDE, "BcSelect");
    jsSupport.addScript("R2.initMultiCopyOptions('#moreoptiontrigger', '#moreoptions')");
  }

  @Log
  void onValidateFromForm() throws ValidationException
  {
    if (form.getHasErrors()) return;
    try
    {
      // need create pe to be allowed to copy
      if (!getUserCredentials().createPeAllowed()) {
        form.recordError("You are not allowed to copy Exhibit R-2's.");
        return;
      }
      if (selection.getProgramElements() == null || selection.getProgramElements().isEmpty()) {
        log.error("No R-2s were selected to copy");
        form.recordError("No R-2s were selected to copy");
        return;
      }
      if (agency == null) {
    	  log.error("An agency must be selected to copy");
          form.recordError("An agency must be selected to copy");
          return;
      }
      Date newSubmDate = newBudgetCycle.getSubmissionDates().get(0).getDate();
      for (ProgramElement pe : selection.getProgramElements()) {
        pe = peDAO.findById(pe.getId()); // needs to be persistent and have a few things initialized
        peDAO.initialize(pe.getBudgetActivity());
        ProgramElement cpe = pe.copy(
          getCurrentBudgesUser(), pe.getNumber(), newBudgetCycle, newSubmDate,
          pe.getBudgetActivity(), pe.isTest());
        cpe.setServiceAgency(agency);
        cpe.setTest(test);
        cpe.setUserDefinedTag(tag);
        // Shift year data to proper years
        int yearDifference = cpe.getBudgetYear() - pe.getBudgetYear();
        if (yearDifference>0) { //shift left x times
          for (int i = 0; i < yearDifference; i++) {
            cpe.shiftYearsLeft();
          }
        }
        ValidationHelper.removeDisallowedData(cpe);
        //copy over permission data
        List<BudgesUserAndProgramElementLink> perms = Collections.emptyList();
        if (copyPerms) {
          perms = peLinkDAO.findByPe(pe);
        }
        // Check for dupes
        if (peDAO.findByBusinessIdIncludingApp(cpe).size() > 0) {
          form.recordError("One of the new R-2s with the selected attributes exists already - " + cpe.getBusinessId());
          break;
        }
        // Do the copy
        saveService.doCopySave(cpe, getCurrentBudgesUser(), checkPrivilege(Privilege.DISABLE_SET_PERM_ON_CREATEPE), perms);
      }
    }
    catch (CloneFailedException | SQLException e)
    {
      log.error("jibx or other error", e);
      form.recordError("Copy failed due to a system error.");
    }
  }

  @Log
  Object onSuccess()
  {
    //resources.discardPersistentFieldChanges();
    return newr2Manage;
  }

  @Log
  Object onCopySelect()
  {
    r2Select.setReturnButton("Return to Copy R-2s");
    r2Select.setReturnPage(getClass());
    return r2Select;
  }


  @Override
public List<BudgetCycle> getAllBudgetCycles()
  {
    return bcDAO.getBudgetCycles();
  }
}
