package mil.dtic.cbes.submissions.t5.encoders;

import java.util.Map;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.utility.CbesLogFactory;

/**
 * Merges form changes with a map of PK to objects given to the constructor
 */
public class MappedEncoder<T extends BudgesBaseValueObject> extends PkAndVersionEncoder<T>
{
  private static final Logger log = CbesLogFactory.getLog(MappedEncoder.class);
  protected final Map<Integer,T> voMap;
  protected final T dummy;


  public MappedEncoder(Map<Integer,T> voMap, T dummy)
  {
    if (voMap==null) throw new IllegalArgumentException();
    log.debug("constructed");
    this.voMap = voMap;
    this.dummy = dummy;
  }
  
  public T toValue(Integer pk, Integer version)
  {
    T value = voMap.get(pk);
    if (value==null)
    {
      log.error("Row " + pk + " not found in map, maybe it was deleted?");
      return dummy;
    }
    return value;
  }
}