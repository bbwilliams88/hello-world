package mil.dtic.cbes.submissions.t5.components;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.submissions.service.annotated.AppCacheReloadController.ReloadCacheInfo;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.validation.backend.ValidationService;

public class AppCacheStatusTable extends T5Base
{

  @Property
  @SuppressWarnings("unused")
  private ReloadCacheInfo currentReloadCacheInfo;

  @Inject
  private ConfigService configService;

  @Inject
  private ValidationService validationService;

  public List<ReloadCacheInfo> getCacheInfoList()
  {
    List<ReloadCacheInfo> configReloadCacheInfoList = configService.getCacheInfoList();
    List<ReloadCacheInfo> validatioinReloadCacheInfoList = validationService.getCacheInfoList();
    List<ReloadCacheInfo> combinedList = new ArrayList<ReloadCacheInfo>(configReloadCacheInfoList);
    combinedList.addAll(validatioinReloadCacheInfoList);
    return combinedList;
  }
  
  public String getStatus(ReloadCacheInfo rci)
  {
    return rci.updatePending() ? "PENDING" : "Complete";
  }
  
  public void onResetCaches()
  {
    configService.resetConfigCache();
    validationService.resetConfigCache();
  }
  
}
