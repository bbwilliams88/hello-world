package mil.dtic.cbes.submissions.t5.components;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.springframework.util.CollectionUtils;

import mil.dtic.cbes.exceptions.ImportException;
import mil.dtic.cbes.output.ImportOptions;
import mil.dtic.cbes.output.R2ImportItem;
import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.delegates.importer.ImportDelegate;
import mil.dtic.cbes.submissions.delegates.importer.ImportResultInfo;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.SendEmailOnInvalidXML;

public class XmlImportToolTab extends T5Base {

  private static final Logger log = CbesLogFactory.getLog(XmlImportToolTab.class);

  @Inject
  private MultipartDecoder decoder;

  @Parameter(required = true)
  @Property
  private File workingDirectory;

  @Inject
  private HttpServletRequest request;

  @Inject
  private ComponentResources resources;

  @Inject
  private JavaScriptSupport jsSupport;

  void afterRender() {
    JSONObject links = new JSONObject("uploadFile", resources.createEventLink("UploadFile")+"");
    jsSupport.addScript("xmlImportToolTabPageInit(%s)", links.toCompactString());
  }

  public JSONObject onUploadFile() {
    log.debug("onUploadFile");
    JSONObject response = new JSONObject();

    // get import options from the HTTP request parameters
    String tag = request.getParameter("exhibitTag");
    boolean isTest = "true".equalsIgnoreCase(request.getParameter("isTest"));
    boolean isCheck = "true".equalsIgnoreCase(request.getParameter("isCheck"));
    log.debug("request parameters: isCheck=" + isCheck + ", isTest=" + isTest + ", tag=" + tag);
    ImportOptions importOptions = new ImportOptions();
    importOptions.setTestExhibit(isTest);
    importOptions.setUserDefinedTag(tag);

    // running tallies for this entire upload (may have multiple files if it's a zip)
    int passCount = 0;
    int passWithWarnCount = 0;
    int failCount = 0;
    JSONArray rejectedFiles = new JSONArray();
    JSONArray exhibits = new JSONArray();
    JSONArray messages = new JSONArray();

    UploadedFile upFile = decoder.getFileUpload("file");
    List<BudgesFile> xmlFiles = new ArrayList<BudgesFile>();
    try {
      xmlFiles = XmlUploadProcessor.getXmlFilesFromUpload(upFile, workingDirectory);
    } catch(FileUploadException e) {
      response.put("status", "error");
      response.put("errorMessage", e.getMessage());
      log.debug(response.toString());
      return response;
    }
    if(!CollectionUtils.isEmpty(xmlFiles)) {
      log.debug("beginning import");
      ImportDelegate importDelegate = new ImportDelegate(getUserCredentials().getUserInfo().getBudgesUser(), workingDirectory,
          new SendEmailOnInvalidXML(getUserCredentials()), runOnlyVerifiedRules(), getUserCredentials(), importOptions);
      importDelegate.setScanEnabled(false); // XMLUploadProcessor already scanned
      ImportResultInfo importResultInfo;

      for(BudgesFile bFile : xmlFiles) {
        importResultInfo = null;
        try {
          log.debug("importing file " + bFile.getOriginalName());
          importResultInfo = importDelegate.importFromXml(bFile, isCheck, ImportDelegate.REFERRING_APP_R2);
        } catch(IOException | ImportException | SQLException e) {
          log.error("error during import of " + bFile.getOriginalName(), e);
          rejectedFiles.put(formatRejectedFile(bFile.getOriginalName(), null, "Unable to process XML for import"));
        }
        if(importResultInfo != null) {
          XmlFullValidationService validator = importResultInfo.getXmlValidationService();
          if(!validator.isSchemaValid()) {
            log.debug("schema errors");
            rejectedFiles.put(formatRejectedFile(bFile.getOriginalName(), validator.getSchemaErrorList(), "Contains XML schema errors"));
          } else {
            log.debug("schema is valid, full steam ahead");
            passCount += importResultInfo.getPassNoWarnCount();
            passWithWarnCount += importResultInfo.getPassWithWarnCount();
            failCount += importResultInfo.getFailCount();
            processImportResult(importResultInfo, bFile.getOriginalName(), rejectedFiles, exhibits, messages);
          }
        }
      }
      String status = passCount > 0 ? "success" : "failure";
      if(passWithWarnCount > 0)
        status = "partial";

      response.put("status", status);
      response.put("importCheckOnly", isCheck);
      response.put("summary", new JSONObject(
          "successCount", Integer.toString(passCount),
          "successWithWarningsCount", Integer.toString(passWithWarnCount),
          "failureCount", Integer.toString(failCount)
          ));
      response.put("rejectedFiles", rejectedFiles);
      response.put("exhibits", exhibits);
      response.put("messages", messages);
    }
    else {
      response.put("status", "error");
      response.put("errorMessage", "Couldn't find XML files in upload");
    }
    log.debug(response.toString());
    return response;
  }

  private JSONObject formatRejectedFile(String fileName, List<String> schemaErrors, String message) {
    JSONObject rf = new JSONObject("filename", fileName);

    if(!CollectionUtils.isEmpty(schemaErrors)) {
      JSONArray schema = new JSONArray();
      for(String msg : schemaErrors) {
        schema.put(msg);
      }
      rf.put("schemaErrors", schema);
    }

    if(message != null) {
      rf.put("message", message);
    }

    return rf;
  }

  private JSONObject formatExhibit(String sourceFile, int xmlIndex, String number, String id, String title, String budgetCycle, String agency, String status) {
    JSONObject ex = new JSONObject(
        "sourceFile", sourceFile,
        "xmlIndex", Integer.toString(xmlIndex),
        "exhibitNumber", number,
        "exhibitId", id,
        "title", title,
        "budgetCycle", budgetCycle,
        "serviceAgency", agency,
        "status", status);
    return ex;
  }

  private JSONObject formatMessage(String type, String location, String message) {
    JSONObject msg = new JSONObject(
        "type", type,
        "location", location,
        "message", message
        );
    return msg;
  }

  private void processImportResult(ImportResultInfo importResultInfo, String filename, JSONArray rejectedFiles, JSONArray exhibits, JSONArray messages) {
    XmlFullValidationService validator = importResultInfo.getXmlValidationService();

    Map<String, List<String>> warningsMap = validator.getRulesWarningListMap();

    if(importResultInfo.getPeImportList() == null) {
      return;
    }

    for(R2ImportItem r2 : importResultInfo.getPeImportList()) {
      ProgramElement pe = r2.getProgramElement();
      String status = "";
      String id = "";
      if(r2.isImportSuccessful()) {
        status = "Import successful";
        id = pe.getId().toString();
      }
      else if(r2.isImportable())
        status = "Can be imported";
      else
        status = "Non-schema error";
      if(r2.isHasWarnings())
        status += ", with business rule warnings";
      exhibits.put(formatExhibit(filename, r2.getXmlIndex(), pe.getNumber(), id, pe.getTitle(),
          pe.getBudgetCycleAndYear(), pe.getServiceAgency().getCode(), status));
      if(!CollectionUtils.isEmpty(r2.getErrorList())) {
        for(String err : r2.getErrorList()) {
          messages.put(formatMessage("Error", pe.getNumber(), err));
        }
      }
      if(!CollectionUtils.isEmpty(warningsMap)) {
        String key = Util.createPeMapKey(pe.getNumber(), r2.getXmlIndex());
        List<String> warnings = warningsMap.get(key);
        if(warnings != null) {
          for(String warn : warnings) {
            log.debug("Adding warning for PE " + pe.getNumber() + ": " + warn);
            messages.put(formatMessage("Warning", pe.getNumber(), warn));
          }
        }
      }
    }
  }
}