package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Cached;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.EventLink;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.ValueObjects.PeSortCriteria;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.LogLevelEncoder;
import mil.dtic.cbes.submissions.t5.encoders.LoggerEncoder;
import mil.dtic.cbes.submissions.t5.models.LogLevelSelectionModel;
import mil.dtic.cbes.t5shared.utils.TapestryUtil;
import mil.dtic.utility.CbesLogFactory;

@Import(stylesheet = {"context:/css/NewAdminLogLevel.css"})
@Secured({"ROLE_R2AppMgr"})
public class NewAdminLogLevel extends T5Base {
    // Logger
    private static final Logger log = CbesLogFactory.getLog(NewAdminLogLevel.class);

    private final String REQUIRED_ROLE = "R2AppMgr";
    
    // Table Sort Criteria
    @Persist
    private String tableSortColumn;
    @Persist
    private PeSortCriteria tableSortCriteria;

    // Sort table by Logger names
    @Property
    private String LOGGER_NAME = "name";
    @Component(parameters = {"event=sort", "context=LOGGER_NAME"})
    private EventLink sortLoggerName;

    // Sort table by Logger levels
    @Property
    private String LOGGER_LEVEL = "level";
    @Component(parameters = {"event=sort", "context=LOGGER_LEVEL"})
    private EventLink sortLoggerLevel;

    // Iterate through all loggers
    @Property @Persist
    private Logger currentLogger;
    @Property @Persist
    private List<Logger> loggerList;

    // Used to set the Log Level of all Loggers
    @Property
    private Level setAllLevel;

    /**
     * @brief When the page is loaded. Provide properties with defaul values if null
     */
    public Object onActivate()
    {
        log.debug("Activating NewAdminLogLevel Page");

        if (!getCurrentBudgesUser().getRole().equals(this.REQUIRED_ROLE)) return R2NotAuthorized.class;

        // Initialize setAllLevel
        if (this.setAllLevel == null) this.setAllLevel = Level.ERROR;

        // Initialize sort column
        if (this.tableSortColumn == null) this.tableSortColumn = this.LOGGER_NAME;

        // Initialze sort criteria
        if (this.tableSortCriteria == null)
        {
            this.tableSortCriteria = new PeSortCriteria();
            this.tableSortCriteria.setSortColumn(this.tableSortColumn);
            this.tableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
        }

        // Initialize the list of loggers
        if (this.loggerList == null) 
        {
            this.loggerList = CbesLogFactory.getCbesLogManagerInstance().getCurrentLoggers();
            TapestryUtil.ognlsort(this.loggerList, false, this.tableSortColumn);
        }
        return null;
    }

    /**
     * @brief SetAllForm successfully submitted. Set log level of all loggers to provided level
     */
    public void onSuccessFromSetAllForm()
    {
        log.debug("onSuccess from SetAllForm");

        CbesLogFactory.getCbesLogManagerInstance().setAllLogLevels(this.setAllLevel);
        this.tableSortColumn = this.LOGGER_NAME;
        this.tableSortCriteria.setSortOrder(Constants.SORT_ORDER_DESC);
        TapestryUtil.ognlsort(this.loggerList, this.tableSortCriteria.isAscending(), this.tableSortColumn);
    }

    /**
     * @brief AdminLogLevelForm successfully submitted. Set new log levels.
     * 
     * This is done via Tapestry using the setCurrentDropdownSelection(Level value) function.
     * 
     * This function is mostly just here to change the sort back to logger name, since sorting on
     * logger level when all levels are the same does not make sense to me.
     */
    public void onSuccessFromAdminLogLevelForm()
    {
        log.debug("onSuccess from AdminLogLevelForm");

        if (this.tableSortColumn.equals(this.LOGGER_LEVEL)) TapestryUtil.ognlsort(this.loggerList, this.tableSortCriteria.isAscending(), this.tableSortColumn);
    }

    /**
     * @brief Sort the table based on the provided column
     * 
     * @param sortCol column to sort the table on
     */
    public void onSort(String sortCol)
    {
        log.debug("Sort: " + sortCol);

        // If same sort column clicked again
        if (this.tableSortCriteria.getSortColumn().equals(sortCol))
        {
            // Flip the sort order
            if (this.tableSortCriteria.isAscending())
            {
                this.tableSortCriteria.setSortOrder(Constants.SORT_ORDER_DESC);
                TapestryUtil.ognlsort(this.loggerList, false, this.tableSortColumn);
            }
            else 
            {
                this.tableSortCriteria.setSortOrder(Constants.SORT_ORDER_ASC);
                TapestryUtil.ognlsort(this.loggerList, true, this.tableSortColumn);
            }
        }
        // New sort column clicked
        else
        {
            this.tableSortColumn = sortCol;
            this.tableSortCriteria.setSortColumn(this.tableSortColumn);
            this.tableSortCriteria.setSortOrder(Constants.DEFAULT_SORT_ORDER);
            TapestryUtil.ognlsort(this.loggerList, false, this.tableSortColumn);
        }
    }

    /**
     * @brief Gets the Log Level of the Logger in the table
     * 
     * @return Log Level of logger
     */
    public Level getCurrentDropdownSelection() 
    {
        return this.currentLogger.getLevel();
    } 
  
    /**
     * @brief Sets the new Log Level of the Logger in the table
     * 
     * @param value the new selected state
     */
    public void setCurrentDropdownSelection(Level value) 
    { 
        CbesLogFactory.getCbesLogManagerInstance().setLogLevel(this.currentLogger.getName(), value);
    }

    
    /**
     * @brief Create T5 SelectModel --> LogLevelSelectionModel
     * 
     * @return new LogLevelSelectionModel object
     */
    public SelectModel getLogLevelSelectionModel()
    {
        return new LogLevelSelectionModel(CbesLogFactory.getCbesLogManagerInstance().getAvailableLogLevels());
    }

    
    /**
     * @brief Create T5 ValueEncoder --> LogLevelEncoder
     * 
     * @return new LogLevelEncoder object
     */
    @Cached
    public ValueEncoder<Level> getLogLevelEncoder()
    {
        log.debug("getLogLevelEncoder");
        return new LogLevelEncoder(CbesLogFactory.getCbesLogManagerInstance().getAvailableLogLevels());
    }

    /**
     * @brief Create T5 ValueEncoder --> LoggerEncoder
     * 
     * @return new LoggerEncoder object
     */
    @Cached
    public ValueEncoder<Logger> getLoggerEncoder()
    {
        log.debug("getLoggerEncoder");
        return new LoggerEncoder(this.loggerList);
    }

    /**
     * @brief For displaying sort image
     * 
     * @return true if sorted on Logger name and is ascending, else false
     */
    public boolean isSortedAscLoggerName()
    {
        return this.tableSortColumn.equals(this.LOGGER_NAME) && this.tableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying sort image
     * 
     * @return true if sorted on Logger name and is descending, else false
     */
    public boolean isSortedDescLoggerName()
    {
        return this.tableSortColumn.equals(this.LOGGER_NAME) && !this.tableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying sort image
     * 
     * @return true if sorted on Logger level and is ascending, else false
     */
    public boolean isSortedAscLoggerLevel()
    {
        return this.tableSortColumn.equals(this.LOGGER_LEVEL) && this.tableSortCriteria.isAscending();
    }

    /**
     * @brief For displaying sort image
     * 
     * @return true if sorted on Logger level and is descending, else false
     */
    public boolean isSortedDescLoggerLevel()
    {
        return this.tableSortColumn.equals(this.LOGGER_LEVEL) && !this.tableSortCriteria.isAscending();
    }
}
