package mil.dtic.cbes.submissions.t5.components;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class R2HeaderWeb extends T5Base{
    
    private static final Logger log = CbesLogFactory.getLog(R2HeaderWeb.class);
    
    @Inject    
    private ConfigService config;        
    
    @Inject    
    private JavaScriptSupport javaScriptSupport;

    @Property
    private boolean rfr;

    @Property
    private boolean analyst;
    
    @Property
    private boolean omb;
    
    @Property
    private boolean r2;

    
    private boolean classification;
    private String banner;
    private String css;
    private String style;
    private Map<String, String> classificationMap;
        
    public void setupRender(){
        classificationMap = Util.getClassificationData();
        banner = classificationMap.get(ConfigService.CLASSIFICATION_BANNER);
        if (null == banner){
            classification = false;
        }
        else{
            classification = true;
            setBanner(banner);
            setStyle(classificationMap.get(ConfigService.CLASSIFICATION_STYLE));
            setCss(classificationMap.get(ConfigService.CLASSIFICATION_CSS));
        }
        
        rfr = isRfr();
    }
    
    public boolean isClassification(){
        return classification;
    }
    

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getCss() {
        return css;
    }

    public void setCss(String css) {
        this.css = css;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public boolean isProd()    
    {      
        return config.isProd();    
    }        
    
    public boolean isShowingBanner()    
    {        
        return isProd() == false;    
    } 
    
    public boolean isReadOnly()    
    {      
        return false;  // check on line item basis not user    
    }        
    
    public boolean isDev()   
    {        
        return config.isDev();    
    }        
    
    @Log    
    public void afterRender(){        
        // Adjust the style attribute of the r2 page header if the banner is present.        
        javaScriptSupport.addScript("if(%s){$('#pageHeader').attr('style', 'margin-bottom:0px')};", isShowingBanner());
    }
    
    public boolean isRfr(){
    	r2=false; analyst=false; omb=false; rfr=false;
        String role = getUserCredentials().getUserInfo().getLdapUser().getR2Role();
        if (role.equals(LdapDAO.GROUP_R2_ANALYST)){
            analyst = true;
            rfr = true;
        }
        if (role.equals(LdapDAO.GROUP_OMB_ANALYST)){
      	  omb = true;
      	  rfr = true;
        }
        
        if (analyst || omb) {
      	  return true;
        }
        r2 = true;
        return false;
    }
    	
    
    public boolean isMaintenanceWarning() {
    	boolean result = false;
    	
    	if(config.getR2MaintenanceWarning()) {
    		result = true;
    	}
    	
    	return result;
    }
    
    public String getR2MaintenanceWarningMessage() {
    	return config.getR2MaintenanceWarningMessage();
    }
}
