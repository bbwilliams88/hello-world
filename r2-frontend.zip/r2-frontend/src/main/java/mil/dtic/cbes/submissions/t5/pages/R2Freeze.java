package mil.dtic.cbes.submissions.t5.pages;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.dao.PELockDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementListDAO;
import mil.dtic.cbes.submissions.dao.exception.AlreadyLockedException;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

/**
 * "Freeze" (long-term lock) a selection of R2s
 */
@Import(
  stack=CbesT5SharedModule.DATATABLESTACK,
  library={
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/json2.js",
    "classpath:${cb.assetpath}/js/datatable.coffee",
    "context:/js/r2freeze.coffee"
  })
public class R2Freeze extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(R2Freeze.class);
  @Inject
  private JavaScriptSupport jsSupport;


  @Inject
  private ProgramElementListDAO pelDAO;
  @Inject
  private ProgramElementDAO peDAO;
  @Inject
  private PELockDAO lockDAO;


  @InjectPage
  private R2Select r2Select;
  @Component
  private Form freezeForm;


  @SessionState
  private DbExhibitSelection selection;
  @SuppressWarnings("unused")
  @Property
  private List<ProgramElementList> programElements;
  @SuppressWarnings("unused")
  @Property
  private ProgramElementList currentPe;
  @Persist
  @Property
  private Boolean force;


  void onActivate()
  {
    if (selection.getProgramElements() != null) {
      Set<Integer> ids = new HashSet<Integer>();
      for (ProgramElement pe : selection.getProgramElements()) {
        ids.add(pe.getId());
      }
      programElements = pelDAO.findByIdsPaged(ids, 0, -1, true);
    }
    if (force == null) {
      force = false;
    }
  }

  void afterRender()
  {
    jsSupport.addScript("setupDatatable();");
  }

  @Log
  Object onFreezeSelect()
  {
    r2Select.setReturnPage(getClass());
    r2Select.setReturnButton("Return to Freeze R-2s");
    return r2Select;
  }

  @Log
  void onSuccessFromFreezeForm()
  {
    if (!checkPrivilege(Privilege.FREEZE_PE)) {
      log.error("freeze without permission???");
      return;
    }
    BudgesUser current = getCurrentBudgesUser();
    BudgesUser lockedby = current;
    if (selection.getProgramElements() != null) {
      for (ProgramElement pe : selection.getProgramElements()) {
        try {
          lockDAO.lockEntirePe(pe.getId(), current, lockedby, force);
        } catch (AlreadyLockedException e) {
          log.error("", e);
          pe = peDAO.merge(pe);
          freezeForm.recordError("Program Element already locked - " + pe.getBusinessId());
        }
      }
    }
  }

  @Log
  void onSuccessFromUnfreezeForm()
  {
    if (!checkPrivilege(Privilege.FREEZE_PE)) {
      log.error("freeze without permission???");
      return;
    }
    BudgesUser current = getCurrentBudgesUser();
    BudgesUser lockedby = null;
    if (selection.getProgramElements() != null) {
      for (ProgramElement pe : selection.getProgramElements()) {
        try {
          lockDAO.lockEntirePe(pe.getId(), current, lockedby, force);
        } catch (AlreadyLockedException e) {
          log.error("", e);
          pe = peDAO.merge(pe);
          freezeForm.recordError("Cannot unfreeze other user's PE - " + pe.getBusinessId());
        }
      }
    }
  }


  public boolean showForce()
  {
    return checkPrivilege(Privilege.UNFREEZE_ANY);
  }

  public String getPeJson()
  {
    List<String> allowedProps = Lists.newArrayList(new String[] {
      "id",
      "lineNum","number","title","baNum","numProjects",
      "serviceAgencyCode","serviceAgencyName", "budgetCycle", "budgetYear"
    });
    JSONArray jsonArray = new JSONArray();
    for (ProgramElementList element : programElements) {
      jsonArray.put(new JSONObject(element.toJson(allowedProps)));
    }
    return jsonArray.toString(false);
  }
}
