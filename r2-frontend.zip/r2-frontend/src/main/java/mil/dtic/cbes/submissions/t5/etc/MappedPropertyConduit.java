package mil.dtic.cbes.submissions.t5.etc;

import java.lang.annotation.Annotation;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.ioc.services.PropertyAccess;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.utility.CbesLogFactory;

/**
 * Redirects a tapestry property to an alternate BudgesBaseValueObject
 * with the same id.
 * @param <E> type of alternate object
 */
public class MappedPropertyConduit<E extends BudgesBaseValueObject> implements PropertyConduit
{
  private final Logger log = CbesLogFactory.getLog(MappedPropertyConduit.class);
  private final Map<Integer, E> map;
  private final String expr;
  private final Class<?> exprClass;
  private final PropertyAccess propertyAccess;


  /**
   * @param propertyAccess injected tapestry service to access expr
   * @param map alternate object map
   * @param expr property needed
   * @param exprClass property type
   */
  public MappedPropertyConduit(PropertyAccess propertyAccess, Map<Integer, E> map, String expr, Class<?> exprClass)
  {
    if (propertyAccess == null || map == null || expr == null || exprClass == null)
      throw new IllegalArgumentException();
    this.propertyAccess = propertyAccess;
    this.map = map;
    this.expr = expr;
    this.exprClass = exprClass;
  }


  public <T extends Annotation> T getAnnotation(Class<T> annotationClass)
  {
    return null;
  }


  public Object get(Object obj)
  {
    E e = map.get(((BudgesBaseValueObject) obj).getId());
    if (e != null)
    {
      return propertyAccess.get(e, expr);
    }
    log.debug("Get: object " + obj + " not found in map");
    return null;
  }


  public Class<?> getPropertyType()
  {
    return exprClass;
  }


  public void set(Object obj, Object value)
  {
    E e = map.get(((BudgesBaseValueObject) obj).getId());
    if (e != null)
    {
      propertyAccess.set(e, expr, value);
      return;
    }
    log.debug("Set: object " + obj + " not found in map");
  }
}