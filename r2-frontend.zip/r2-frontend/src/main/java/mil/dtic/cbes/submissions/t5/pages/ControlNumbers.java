/*
 * $Id: PRPCPage.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.PropertyAccess;
import org.apache.tapestry5.ioc.services.PropertyAdapter;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.PELockDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.exception.AlreadyLockedException;
import mil.dtic.cbes.submissions.service.SaveService;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.submissions.t5.models.R2ListFilters;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;

/**
 * This page presents a list of ProgramElementList, then saves to ProgramElement
 */
@Import( stack={
  CbesT5SharedModule.DATATABLESTACK,
  CbesT5SharedModule.JQUERYTOOLSSTACK
},
library={
  "classpath:${cb.assetpath}/js/underscore.string.js",
  "classpath:${cb.assetpath}/js/urlencoder.js",
  "classpath:${cb.assetpath}/js/json2.js",
  "classpath:${cb.assetpath}/js/datatable.coffee",
  "classpath:${cb.assetpath}/js/editable.coffee",
  "context:/js/controlnumbers.coffee"
},
stylesheet={"context:css/r2datatables.css","context:/css/controlnumbers.css"})
public class ControlNumbers extends PeListBase
{
  private static final Logger log = CbesLogFactory.getLog(ControlNumbers.class);
  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private Request request;
  @Inject
  private PropertyAccess propertyAccess;


  @InjectPage
  private AlreadyLockedPage lockedPage;

  @Inject
  private BudgetCycleDAO bcDAO;
  @Inject
  private PELockDAO peLockDAO;
  @Inject
  private ProgramElementDAO peDAO;
  @Inject
  private SaveService saveService;


  @SessionState
  private R2ListFilters filterState;

  @Property
  private List<ProgramElementList> pes; // read-only list
  @Property
  private Map<Integer,ProgramElement> fatPesMap; // writes go here
  @Property
  private ProgramElementList currentPe; // pe currently being iterated over
  @Property
  private int budgetYear;

  @Log
  void onActivate()
  {
    if (filterState.getBudgetCycle() == null || filterState.getBudgetCycle().getBudgetYear() == null) {
        log.debug("No budget cycle selected, defaulting to current");
        filterState.setBudgetCycle(Util.getCurrentBudgetCycle());
    }
    
    pes = getPesBasedOnPermissionsAndFilter(ProgramElementList.LINE_NUM, ProgramElementList.NUMBER);
    Set<Integer> peIds = TapestryUtil.ognlsettransform(pes, ProgramElementList.ID);
    List<ProgramElement> fatPes = peDAO.findByIdsPaged(peIds, 0, -1, false, new String[]{ProgramElement.LINE_NO, ProgramElement.NUMBER});
    fatPesMap = new LinkedHashMap<Integer,ProgramElement>(fatPes.size());
    
    for (ProgramElement pe : fatPes)
    {
      fatPesMap.put(pe.getId(), pe);
    }
    
    budgetYear = filterState.getBudgetCycle().getBudgetYear();
    
  }


  void afterRender()
  {
    JSONObject links = new JSONObject(
      "budgetCycleReloadUrl", resources.createEventLink("BudgetCycleChange")+"",
      "saveUrl", resources.createEventLink("Save")+"",
      "updateUrl", resources.createEventLink("Update") + ""
      );
    jsSupport.addScript("setup(%s);", links.toCompactString());
  }

  @Log
  void onBudgetCycleChange(String reloadBudgetCycle)
  {
    filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
  }

  JSONObject onSave()
  {
    log.debug("onSave");
    JsonArray tabledata = new JsonParser().parse(request.getParameter("tabledata")).getAsJsonArray();
    boolean reload = false;
    for (JsonElement element : tabledata) {
      JsonObject pejson = element.getAsJsonObject();
      ProgramElement pe = fatPesMap.get(pejson.get("id").getAsInt());
      
      if (pejson.get("locked").getAsBoolean()) {
        log.debug("skipping PE locked by other - " + pe);
        continue;
      }
      
      try {
        if (copyFundingPropsOver(pejson, pe)) {
          boolean alreadyLockedByMe = peLockDAO.isPeLockedBy(getCurrentBudgesUser().getId(), pe.getId());
          if (!alreadyLockedByMe)
            peLockDAO.lockPEOnly(pe.getId(), getCurrentBudgesUser(), getCurrentBudgesUser(), false);
          log.debug("Saving " + pe);
          pe.setModifiedByBudgesUser(getCurrentBudgesUser());
          pe.setDateModified(new Date());
          PeSubmissionFlag oldValidity = pe.getSubmissionStatus();
          saveService.doR2Save(pe, getCurrentBudgesUser(), false);
          if (oldValidity != pe.getSubmissionStatus())
            reload = true;
          if (!alreadyLockedByMe)
            peLockDAO.lockPEOnly(pe.getId(), getCurrentBudgesUser(), null, false);
        } else {
          //log.trace("not saving " + pe);
        }
      } catch (AlreadyLockedException e) {
        log.debug("Already locked - " + pe.getId());
      }
    }
    JSONObject response = new JSONObject();
    if (reload) {
      response.put("reload", true);
    } else {
      response.put("tabledata", new JSONArray(getPeJson()));
    }
    return response;
  }
  
  /**
   * This method handles the auto update of the control numbers.
   * @return
   */
  JSONObject onUpdate()
  {
    log.debug("onUpdate");
    JsonArray tabledata = new JsonParser().parse(request.getParameter("tabledata")).getAsJsonArray();
    boolean reload = false;
    int peLocked = 0;
    int newLineNumber = 0;
    int oldLineNumber = 0;
    int difference = 0;
    
    Integer updateId = new JsonParser().parse(request.getParameter("updateid")).getAsInt();
    
    if(request.getParameter("updateval") != null && NumberUtils.isDigits(request.getParameter("updateval"))) {
      newLineNumber = new JsonParser().parse(request.getParameter("updateval")).getAsInt();
    }
    
    ArrayList<JsonObject> jsonObjects = new ArrayList<JsonObject>(tabledata.size());
    
    // Create a list of the JsonObjects so they can be sorted.
    for (JsonElement element : tabledata) {
      JsonObject pejson = element.getAsJsonObject();
      jsonObjects.add(pejson);
    }
    
    // Sort the incoming JSON elements in line number order.
    Collections.sort(jsonObjects, new Comparator<JsonObject>(){      
      @Override
      public int compare(JsonObject o1, JsonObject o2)
      {
        Integer n1 = 0;
        Integer n2 = 0;
        
        if(!o1.get("r1LineNumber").isJsonNull())
          n1 = NumberUtils.isNumber(o1.get("r1LineNumber").getAsString()) ? o1.get("r1LineNumber").getAsInt() : 0;
        if(!o2.get("r1LineNumber").isJsonNull())
          n2 = NumberUtils.isNumber(o2.get("r1LineNumber").getAsString()) ? o2.get("r1LineNumber").getAsInt() : 0;
        
        if((n1).equals(n2)) {        
          return (o1.get("number").getAsString()).compareTo(o2.get("number").getAsString());
        }
        else {
          return (n1).compareTo(n2);
        }
      };}
    );
    
    ProgramElement pe = null;
    
    // Loop through the json objects, check if the control number changed, increment subsequent sequential control numbers.
    for (JsonObject pejson : jsonObjects) {
      pe = fatPesMap.get(pejson.get("id").getAsInt());
      
      if(!pejson.get("r1LineNumber").isJsonNull() && NumberUtils.isDigits(pejson.get("r1LineNumber").getAsString())) {
        oldLineNumber = pejson.get("r1LineNumber").getAsInt();
      }
      else {
        oldLineNumber = 0;
      }
      
      // Check if this JSON element was updated
      if (updateId.equals(pejson.get("id").getAsInt())) {
        difference = newLineNumber - oldLineNumber;        
      } 

      // If exhibit locked by someone other than me, return locked pe ID
      if((pe.getEntirePeLockedBy() != null && !pe.getEntirePeLockedBy().equals(getCurrentBudgesUser()))
        || (pe.getLockedBy() != null && !pe.getLockedBy().equals(getCurrentBudgesUser()))) {
        if (difference != 0) peLocked = pejson.get("id").getAsInt();
      }
      // Else update subsequent R1 numbers by the difference
      else {
        if(!pejson.get("r1LineNumber").isJsonNull() && NumberUtils.isNumber(pejson.get("r1LineNumber").getAsString()))
          pe.setR1LineNumber(String.valueOf(pejson.get("r1LineNumber").getAsInt() + difference));
      }
    }
    
    JSONObject response = new JSONObject();
    if (reload) {
      response.put("reload", true);
    } 
    else if(peLocked != 0) {
      response.put("pelocked", peLocked);
      response.put("tabledata", new JSONArray(getPeJson()));      
    }
    else {
      response.put("tabledata", new JSONArray(getPeJson()));
    }
    return response;
  }
  
  void onRevert()
  {
    // don't need to do anything
  }

  public String getPeJson()
  {
    List<String> allowedProps = Lists.newArrayList(new String[] {
      "id",
      "number","title","baNum","serviceAgencyCode","serviceAgencyName",
      "budgetCycle", "budgetYear"
    });
    List<String> fatProps = getFatProps();
    JSONArray jsonArray = new JSONArray();
    for (ProgramElementList element : pes) {
      
      JSONObject obj = new JSONObject(element.toJson(allowedProps));
      obj.put("numbercopy", element.getNumber());
      obj.put("formattedDateCreated", formatDatetime(element.getDateCreated()));
      obj.put("formattedDateModified", formatDatetime(element.getDateModified()));
      // Somehow the modifier ldap id was null for one of the records...
      // insert a blank string to fail more gracefully
      String creator = getCreatorName(element) == null ? "" : getCreatorName(element);
      String modifier = getModifierName(element) == null ? "" : getModifierName(element);
      obj.put("creatorDisplayName", creator);
      obj.put("modifierDisplayName", modifier);
      // Copy funding data into obj
      ProgramElement fatPe = fatPesMap.get(element.getId());
      JSONObject fat = new JSONObject(fatPe.toJson(fatProps));
      for (String key : fat.keys()) {
        obj.put(key, fat.get(key));
      }
      // Lock flag - true if PE level edit lock or frozen by other
      boolean locked = false;
      if (fatPe.getEntirePeLockedBy() != null && !fatPe.getEntirePeLockedBy().getId().equals(getCurrentBudgesUser().getId())) {
        locked = true;
      }
      if (fatPe.getLockedBy() != null && !fatPe.getLockedBy().getId().equals(getCurrentBudgesUser().getId())) {
        locked = true;
      }
      obj.put("locked", locked);
      jsonArray.put(obj);
    }
    return jsonArray.toString(false);
  }

  private boolean copyFundingPropsOver(JsonObject properties, ProgramElement pe)
  {
    boolean modified = false;
    for (String prop : getFatProps()) {
      PropertyAdapter pa = propertyAccess.getAdapter(pe).getPropertyAdapter(prop);
      JsonElement val = properties.get(prop);
      if (val instanceof JsonNull) {
        modified |= set(pa, pe, null);
      } else if (pa.getType() == BigDecimal.class) {
        if ("".equals(val.getAsString())) {
          // datatables turns null strings into ""
          modified |= set(pa, pe, null);
        } else {
          modified |= set(pa, pe, val.getAsBigDecimal());
        }
      } else {
        if ("".equals(val.getAsString())) {
          // datatables turns null strings into ""
          modified |= set(pa, pe, (String) null);
        } else {
          modified |= set(pa, pe, val.getAsString());
        }
      }
    }
    return modified;
  }

  // Return true if property modified
  private boolean set(PropertyAdapter pa, Object instance, Object val)
  {
    Object oldval = pa.get(instance);
    if (oldval != null && oldval.equals(val)) {
      return false;
    } else if (oldval == val) {
      return false;
    } else {
      pa.set(instance, val);
      return true;
    }
  }

  // Use compareTo with BigDecimals
  private boolean set(PropertyAdapter pa, Object instance, BigDecimal val)
  {
    BigDecimal oldval = (BigDecimal)pa.get(instance);
    if (oldval != null && val != null && oldval.compareTo(val) == 0) {
      return false;
    } else if (oldval == val) {
      return false;
    } else {
      pa.set(instance, val);
      return true;
    }
  }

  private List<String> getFatProps()
  {
    return Lists.newArrayList(new String[] {
      "r1LineNumber",
      "fundingAllPys","fundingPy","fundingCy","fundingBy1Base","fundingBy1Ooc","fundingBy1",
      "fundingBy2","fundingBy3","fundingBy4","fundingBy5",
      "fundingCompCost","fundingTotalCost"
    });
  }
}
