package mil.dtic.cbes.submissions.t5.components;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SetupRender;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.xml.sax.SAXException;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.io.Files;

import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.cbes.xml.merge.ExhibitListMerge;
import mil.dtic.cbes.xml.merge.MergeCandidate;
import mil.dtic.utility.CbesLogFactory;

/**
 * Server side for the exhibit list xml merge tool.
 *
 * @author AZumkhaw
 *
 */
public class XmlMergeToolTab extends BaseXmlToolTab {

  private static final Logger log = CbesLogFactory.getLog(XmlMergeToolTab.class);

  private static final String DESCRIPTION_JSON_KEY = "description";

  private static final String EXHIBIT_COUNT_JSON_KEY = "count";

  private static final String ADDED_JSON_KEY = "added";

  @Parameter(required = true)
  @Property
  private File workingDirectory;

  @Inject
  private MultipartDecoder decoder;
  
  @Inject
  private HttpServletRequest request;

  @Persist
  private Multimap<String, String> mergeFilePaths;

  @Persist
  private File mergedXmlZipArchive;

  @SetupRender
  public void initMergeFilePaths()
  {
    if (mergeFilePaths == null) {
      mergeFilePaths = HashMultimap.create();
    }
  }

  /**
   *
   * Endpoint for an file uploaded to the merge tool.
   *
   */
  public JSONObject onMergeXmlFileUpload() {
    JSONObject rootObj = new JSONObject();
    rootObj.put("action", "mergeXmlUpload");
    if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
      log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
      + ", expected " + getCurrentBudgesUser().getCsrfToken());
      rootObj.put("error", "Attempted to upload file without proper authorization");
      return rootObj;
    }
    UploadedFile upFile = decoder.getFileUpload("file");
    if(upFile != null && mergeFilePaths.containsKey(upFile.getFileName()))
      rootObj.put("duplicate", "Duplicate");
    else {
      try {
        int exhibitCount = 0;
        int filesAdded = 0;

        for(XmlDocument xd : XmlUploadProcessor.getXmlDocumentsFromUpload(upFile, workingDirectory, true)) {
          MergeCandidate exhibitMergeCandidate = new MergeCandidate(xd.getDocument());
          String description = exhibitMergeCandidate.getDescription();
          log.debug(description);

          File renamedFile = renameWithDescription(xd.getFile(), description);
          if (!description.equalsIgnoreCase(ExhibitListMerge.NOT_A_VALID_EXHIBIT_LIST)) {
            // add the candidate file to our merge list
            mergeFilePaths.put(upFile.getFileName(), renamedFile.getAbsolutePath());
            log.debug("xml candidate: " + renamedFile.getAbsolutePath() + " of " + mergeFilePaths.size() + " candidates");
            rootObj.put(DESCRIPTION_JSON_KEY + filesAdded++, description);
            exhibitCount += exhibitMergeCandidate.exhibitCount();
          }
        }

        if (filesAdded > 0 && exhibitCount > 0) {
          rootObj.put(ADDED_JSON_KEY, filesAdded);
          rootObj.put(EXHIBIT_COUNT_JSON_KEY, exhibitCount);
        }
        log.debug("Discovered " + exhibitCount + " exhibits in " + filesAdded + " xml file(s).");
      }
      catch(IOException | XmlDocumentException | FileUploadException e) {
        log.debug("Exception when determining upload file merge description",e);
        rootObj.put("error", "unable to read jb file");
      }
    }

    log.debug("merge upload request received");
    return rootObj;
  }

  /**
   * Endpoint for initiating a merge and generating a zip archive.
   */
  public JSONObject onMergeXml() {
    JSONObject rootObj = new JSONObject();

    if (mergeFilePaths != null && !mergeFilePaths.isEmpty()) {
      List<File> filesToMerge = new ArrayList<File>();
      for (String filePath : mergeFilePaths.values()) {
        filesToMerge.add(new File(filePath));
      }
      log.debug(filesToMerge.size() + " xml files to merge");

      ExhibitListMerge merge = new ExhibitListMerge(filesToMerge.toArray(new File[filesToMerge.size()]));
      merge.setOutputDirectory(workingDirectory.getAbsolutePath());
      try {
        merge.create();
        mergedXmlZipArchive = merge.getZipArchive();
        rootObj.put("success", mergedXmlZipArchive.getName());
        log.debug("created merged xml files, zip archived");
      } catch (IOException | SAXException | XPathExpressionException e) {
        rootObj.put("error", "exception while merging");
        log.debug("Unable to merge xml files", e);
      }
    }
    else {
      log.debug("no files uploaded to serve merge request with");
      rootObj.put("error", "no uploaded xml files to merge");
    }
    return rootObj;
  }

  /**
   *
   * Endpoint for removing all uploaded files from the merge list.
   *
   */
  public JSONObject onReset() {
    log.debug("merge files reset");
    JSONObject rootObj = new JSONObject();
    if (mergeFilePaths != null) {
      mergeFilePaths.clear();
    }
    mergedXmlZipArchive = null;
    rootObj.put("success", "reset");
    return rootObj;
  }

  /**
   *
   * Endpoint for removing specific uploaded files from the merge list.
   *
   */
  public JSONObject onRemoveFile(String fileName) {
    log.debug("remove files associated with: " + fileName);
    JSONObject rootObj = new JSONObject();
    mergeFilePaths.removeAll(fileName);
    rootObj.put("success", "remove");
    return rootObj;
  }

  /**
   * Endpoint for downloading a zip archive containing merged xml files, per service.
   *
   * @return
   */
  public StreamResponse onActionFromDownloadMergeZip() {
    InputStream is = null;
    try {
      is = new FileInputStream(mergedXmlZipArchive);
    } catch (FileNotFoundException e) {
      log.error("merged file not available for download: " + mergedXmlZipArchive.getAbsoluteFile(), e);
    }
    StreamResponse response = getZipStream(is, mergedXmlZipArchive.getName());
    return response;
  }

  /**
   *
   * Renames an uploaded file with metadata about the budget type and service agency.
   *
   */
  private File renameWithDescription(File scannedFile, String description) throws IOException {
    String newName = scannedFile.getAbsolutePath().replace(FILE_EXTENSION_SEPARATOR + XML_EXTENSION, description + FILE_EXTENSION_SEPARATOR + XML_EXTENSION);
    File renamedFile = new File(newName);
    Files.move(scannedFile, renamedFile);
    log.debug("renamed File: " + renamedFile.getAbsolutePath());
    return renamedFile;
  }
}