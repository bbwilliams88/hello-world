package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.RequestParameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.core.GrantedAuthority;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.service.BudgetFileUploadService;
import mil.dtic.cbes.service.SYSUploadServiceImpl;
import mil.dtic.cbes.service.ValidationException;
import mil.dtic.cbes.service.ValidationMessage;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.SYSFile;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.t5.etc.SYSFileStreamResponse;
import mil.dtic.cbes.t5shared.mixins.ProgressDownload;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

@Import(stack = { CbesT5SharedModule.DATATABLESTACK, CbesT5SharedModule.JQUERYTOOLSSTACK }, library = {
		"classpath:${cb.assetpath}/js/underscore.string.js", "classpath:${cb.assetpath}/js/urlencoder.js",
		"classpath:${cb.assetpath}/js/json2.js", "classpath:${cb.assetpath}/js/deleteconfirm.coffee",
		"classpath:${cb.assetpath}/js/progressdownload.coffee", "classpath:${cb.assetpath}/js/datatable.coffee",
		"context:/js/downloadpage.coffee" }, stylesheet = { "context:css/r2datatables.css" })
public class DownloadPage extends BaseUploadPage<SYSFile> {
	private static final Logger log = CbesLogFactory.getLog(DownloadPage.class);
	@Inject
	private ComponentResources resources;
	@Inject
	private JavaScriptSupport jsSupport;
	@Inject
	private HttpServletRequest httpServletRequest;
	@Inject
	private HttpServletResponse httpServletResponse;
	@Property
	private List<SYSFile> files;
	@Inject
	private SYSUploadServiceImpl budgetFileUploadService;
	// @SuppressWarnings("unused")
	// @InjectComponent
	// private Form errorForm;

	@Log
	void onActivate() {
		log.debug("Retrieving downloads...");
		if (files == null) {
			files = getBudgetFileUploadService().getAllFiles();
		}
	}

	void afterRender() {
		JSONObject tableLinks = new JSONObject("name", resources.createEventLink("nameLink").toString(), "delete",
				resources.createEventLink("delete").toString());
		jsSupport.addScript("setupDatatable(%s);", tableLinks.toCompactString());
	}

	@Log
	StreamResponse onNameLink(final int id,
			@RequestParameter(value = ProgressDownload.PARAM_NAME, allowBlank = true) String token) {
		ProgressDownload.clearCookie(httpServletRequest, httpServletResponse, token);
		SYSFile budgetFile = getBudgetFileUploadService().getFile(id);
		SYSFileStreamResponse streamResponse = new SYSFileStreamResponse(budgetFile);
		return streamResponse;
	}

	@Override
	public BudgetFileUploadService<SYSFile> getBudgetFileUploadService() {
		return budgetFileUploadService;
	}

	@Log
	void onDelete(final int id) {
		getBudgetFileUploadService().deleteFile(id);
	}

	public String getFileJson() {
		List<String> allowedProps = Lists
				.newArrayList(new String[] { "id", "name", "description", "dateCreated", "createdBy", "size" });
		JSONArray jsonArray = new JSONArray();
		for (SYSFile file : files) {
			if (file.isAvailableOnFilesystem()) {
				JSONObject obj = new JSONObject(Util.toJson(file, allowedProps));
				jsonArray.put(obj);
				obj.put("deleteEnabled", isDeleteEnabled());
			}
		}
		if (log.isDebugEnabled()) {
			for (String prop : allowedProps) {
				log.debug("Allowed Props: " + prop);
			}
		}
		return jsonArray.toString(false);
	}

	@Override
	public void onValidateFromUploadForm() {
		R2Storage r2Storage = new R2Storage("BudgetUpload");
		try {
			File sandboxFile = r2Storage.createTempFileInSandbox(FilenameUtils.getExtension(file.getFileName()));
			file.write(sandboxFile);
			getBudgetFileUploadService().saveNewFile(sandboxFile, file.getFileName(), getCurrentUser().getUsername(),
					description, null);
		} catch (ValidationException e) {
			List<ValidationMessage> errors = e.getErrors();
			for (ValidationMessage error : errors) {
				uploadForm.recordError(error.getMessage());
			}
		} catch (IOException e) {
			uploadForm.recordError("There was an error saving the Uploaded file, please contact system administrator");
		}
	}

	public boolean isDeleteEnabled() {
		return checkPrivilege(Privilege.ACCESS_IN_MAINTENANCE_MODE);
	}

	public boolean isR2AppManager()
    {
		if (getCurrentUser() == null) return false;

		Collection<GrantedAuthority> list = getCurrentUser().getAuthorities();
		for (GrantedAuthority grantedAuthority : list)
		{
			if (grantedAuthority.getAuthority() == "ROLE_R2AppMgr") return true;
		}
      	return false;
    }
}
