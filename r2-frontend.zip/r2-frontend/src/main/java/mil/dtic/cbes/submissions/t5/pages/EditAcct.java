package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.annotations.Property;
import org.springframework.security.access.annotation.Secured;
import mil.dtic.cbes.submissions.t5.base.T5Base;

@Secured({"ROLE_R2AppMgr"})
public class EditAcct extends T5Base
{
	
  @Property
  private String agencyCd;
  
  @Property
  private String agencyNm;
  
  @Property
  private String appnCd;
  
  @Property
  private String appnNm;
  
  @Property
  private String peLineItem;
  
  @Property
  private String volNm;
  
  @Property
  private String volNum;
  
  @Property
  private String active;

  public void onActivate() {

  }
  
  Object onActionFromCancel()
  {
    return AdministerLookupAcctTab.class;
  }

}