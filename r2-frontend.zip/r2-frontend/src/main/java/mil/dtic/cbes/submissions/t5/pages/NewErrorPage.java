package mil.dtic.cbes.submissions.t5.pages;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Import;

import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CbesLogFactory;

@Import(stylesheet={"context:/css/NewNotRegisteredPage.css"})
public class NewErrorPage extends T5Base {
    // TODO Update Logger when NewAdminLogLevel page is merged
    private static final Logger log = CbesLogFactory.getLog(NewErrorPage.class);

    public void onActivate()
    {
        log.debug("Activating NewErrorPage");
    }
    
}
