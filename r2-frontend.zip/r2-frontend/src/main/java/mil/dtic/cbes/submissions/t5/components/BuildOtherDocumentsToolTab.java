package mil.dtic.cbes.submissions.t5.components;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.RequestParameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.jibx.extras.DocumentComparator;
import org.apache.logging.log4j.Logger;
import org.xmlpull.v1.XmlPullParserException;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.jb.DocumentCreationParams;
import mil.dtic.cbes.p40.service.P40SelectionService;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.delegates.BuildOtherDocumentsDelegate;
import mil.dtic.cbes.submissions.service.R2SelectionService;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.models.UploadExhibitSelectionModel;
import mil.dtic.cbes.xml.JavaToXml;
import mil.dtic.cbes.xml.XMLToolsUtil;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.BudgesDocumentComparator;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.StringPrintStream;

public class BuildOtherDocumentsToolTab extends BaseXmlToolTab {

  @Parameter(required = true)
  @Property
  private File workingDirectory;

  @Inject
  private MultipartDecoder decoder;

  @Inject
  private BudgetCycleDAO bcDAO;

  @Property
  private BudgetCycle currentBudgetCycle;

  @Property
  private BudgetCycle aBudgetCycle;

  @Property
  private ServiceAgency currentServiceAgency;

  private UploadExhibitSelectionModel uploadSelection = new UploadExhibitSelectionModel();

  private BuildOtherDocumentsDelegate otherDocsDelegate = new BuildOtherDocumentsDelegate();

  @Inject
  private R2SelectionService r2SelectionService;

  private P40SelectionService p40SelectionService;

  private static final Logger log = CbesLogFactory.getLog(BuildOtherDocumentsToolTab.class);

  @Inject
  private ComponentResources resources;

  @Inject
  private JavaScriptSupport jsSupport;

  private HashMap<String, String> downloadFileMap = new HashMap<String, String>();

  public BuildOtherDocumentsToolTab() {
    log.debug("other docs tool tab starting up");
    if (p40SelectionService == null) {
      p40SelectionService = new P40SelectionService();
    }
  }

  void afterRender() {
    JSONObject links = new JSONObject(
        "uploadFile", resources.createEventLink("UploadFile") + "",
        "downloadFile", resources.createEventLink("DownloadFile") + "",
        "buildDoc", resources.createEventLink("BuildDoc") + "",
        "reset", resources.createEventLink("Reset") + "",
        "deleteUploadedExhibit", resources.createEventLink("RemoveUploadedExhibit") + "",
        "getUploadedExhibits", resources.createEventLink("GetUploadSelections") + "");
    jsSupport.addScript("buildOtherDocumentsPageInit(%s)", links.toCompactString());
  }

  @Override
  public List<BudgetCycle> getAllBudgetCycles() {
    List<BudgetCycle> cycles = bcDAO.getBudgetCycles();
    return cycles;
  }

  public List<ServiceAgency> getServiceAgencies() {
    // enable P40 agencies to display in Agency  CXE-6407  
    //return getUserCredentials().getUserInfo().getAvailableRdteAgencies();  
    return getUserCredentials().getUserInfo().getAllAvailableAgencies();
  }

  @Log
  public JSONObject onUploadFile() {
    log.debug("uploaded file");
    String action = "uploadFile";
    JSONObject errorMessages = new JSONObject();

    List<JSONObject> items = new LinkedList<JSONObject>();

    List<XmlDocument> xmlDocumentsToParse = new ArrayList<XmlDocument>();
    try {
      xmlDocumentsToParse = XmlUploadProcessor.getXmlDocumentsFromUpload(
          decoder.getFileUpload("file"), workingDirectory, false);
    } catch (FileUploadException | XmlDocumentException e) {
      log.error("Error processing uploaded file:", e);
      addGeneralMessage(errorMessages, e.getMessage());
      return createResponse(action, null, null, errorMessages, null, null);
    }

    boolean schemaMismatch = false;

    for (XmlDocument xd : xmlDocumentsToParse) {
      try {
        List<String> errors = roundTripComparison(xd);

        if (errors.size() > 0) {
          errors.stream().forEach(errorMessage -> addGeneralMessage(errorMessages, errorMessage));
          schemaMismatch = true;
        }
      } catch (XmlPullParserException | IOException e) {
        addGeneralMessage(errorMessages, e.getMessage());
        xd.closeAllStreams();
        return createResponse(action, null, null, errorMessages, null, null);
      }

      items.addAll(uploadSelection.parseFileForNewItems(xd));
      xd.closeAllStreams();
    }

    if (schemaMismatch)
      return createResponse(action, null, null, errorMessages, null, null);

    if (CollectionUtils.isEmpty(items)) {
      addGeneralMessage(errorMessages, "No readable exhibits in file.");
      return createResponse(action, null, null, errorMessages, null, null);
    }

    JSONArray exhibits = new JSONArray();
    for (JSONObject obj : items) {
      exhibits.put(obj);
    }
    JSONObject response = new JSONObject();
    response.put("exhibits", exhibits);
    return response;
  }

  private List<String> roundTripComparison(XmlDocument xmlDocument) throws IOException, XmlPullParserException {
    String convertedXml = null;
    List<String> result = new ArrayList<>();

    if (XMLToolsUtil.isP40ExhibitDoc(xmlDocument.getDocument()))
      convertedXml = new String(JavaToXml.toXml(xmlDocument.getLineItemList()));
    else if (XMLToolsUtil.isR2ExhibitDoc(xmlDocument.getDocument()))
      convertedXml = new String(JavaToXml.toXml(xmlDocument.getR2ExhibitList()));

    if (convertedXml != null) {
      StringPrintStream compareLogger = new StringPrintStream();
      DocumentComparator documentComparator = new BudgesDocumentComparator(compareLogger);
      Reader originalDocument = new StringReader(IOUtils.toString(xmlDocument.getInputStream()));
      Reader convertedDocument = new StringReader(convertedXml);

      if (documentComparator.compare(originalDocument, convertedDocument) == false)
        new BufferedReader(new StringReader(compareLogger.toString())).lines()
            .forEach(message -> result.add(convertJibxWarning(message)));
    }

    return result;
  }

  private String convertJibxWarning(String message) {
    String parts[] = message.split(":");
    String replacementText = "is missing from second document";
    String result = "";

    for (int i = 1; i < parts.length; i++)
      if (parts[i].contains("attribute") && parts[i].contains(replacementText))
        result += parts[i].replace(replacementText, "is invalid");
      else
        result += parts[i];

    return result;
  }

  @Log
  public JSONObject onBuildDoc(@RequestParameter("json") String jsonStr) {
    String action = "buildDoc";
    JSONObject errorMessages = new JSONObject();

    JSONObject requestObj = null;

    try {
      requestObj = new JSONObject(jsonStr);
    } catch (RuntimeException e) { // Tapestry JSON library throws RuntimeException for parsing errors
      addGeneralMessage(errorMessages, "Request is malformed.");
      return createResponse(action, null, null, errorMessages, null, null);
    }

    String docType = "";
    String formatType = "";

    try {
      docType = requestObj.getString("documentType");
      formatType = requestObj.getString("formatType");
    } catch (RuntimeException e) {
      addGeneralMessage(errorMessages, "Request is missing document type or format type.");
      return createResponse(action, null, null, errorMessages, null, null);
    }
    if ("r2".equalsIgnoreCase(docType) || "p40".equalsIgnoreCase(docType))
      docType = docType + "collection";
    log.debug("docType: " + docType);

    DocumentCreationParams params = null;

    String budgetCycle = "";
    int budgetYear = 0;
    String serviceAgencyName = "";

    try {
      budgetCycle = requestObj.getString("budgetCycle");
      budgetYear = requestObj.getInt("budgetYear");
      serviceAgencyName = requestObj.getString("serviceAgencyName");
    } catch (RuntimeException e) {
      addGeneralMessage(errorMessages, "Request is missing required parameters.");
      return createResponse(action, null, null, errorMessages, null, null);
    }

    params = getDocParams(budgetCycle, budgetYear, serviceAgencyName);

    boolean forceEvenPages = false;
    String watermark = "";
    String trackingHeader = "";

    try {
      forceEvenPages = requestObj.getBoolean("forceEvenPages");
      watermark = requestObj.getString("watermark");
      trackingHeader = requestObj.getString("trackingHeader");
    } catch (RuntimeException e) {
      log.warn("Request missing a field.", e);
    }

    DocumentAssemblyOptions options = getDocumentAssemblyOptions(forceEvenPages, watermark, trackingHeader);

    Set<Integer> ids = getR2Ids(requestObj);
    Integer[] p40Ids = getP40Ids(requestObj);

    boolean includeTestPes = getUserCredentials().checkPrivilege(Privilege.SHOW_TEST_PE);
    boolean restrictToUserPes = !getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY);

    String role = getUserCredentials().getUserInfo().getBudgesUser().getRole();
    boolean hasViewAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role)) {
      hasViewAccess = false;
    }
    boolean hasEditAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role) || StringUtils.equals(LdapDAO.GROUP_R2_LOCALSITEADMIN, role)) {
      hasEditAccess = false;
    }

    DbExhibitSelection dbSelection = new DbExhibitSelection();
    dbSelection.addToProgramElementList(r2SelectionService.getSelectedProgramElements(ids, includeTestPes,
        restrictToUserPes, getUserCredentials().getUserInfo().getBudgesUser()));
    dbSelection.addToLineItemList(
        p40SelectionService.getSelectedLineItems(getUserCredentials().getUserInfo().getBudgesUser().getUserLdapId(),
            hasViewAccess, hasEditAccess, includeTestPes, p40Ids));

    List<ProgramElement> combinedPeSelection = new ArrayList<ProgramElement>();
    combinedPeSelection.addAll(dbSelection.getProgramElements());
    combinedPeSelection.addAll(uploadSelection.getProgramElements());

    List<LineItem> combinedLiSelection = new ArrayList<LineItem>();
    combinedLiSelection.addAll(dbSelection.getLineItems());
    combinedLiSelection.addAll(uploadSelection.getLineItems());

    String fileName = "";
    try {
      if (StringUtils.startsWithIgnoreCase(docType, "r"))
        fileName = otherDocsDelegate.buildRDoc(docType, formatType, options, params,
            combinedPeSelection, workingDirectory);
      else if (StringUtils.startsWithIgnoreCase(docType, "p"))
        fileName = otherDocsDelegate.buildPDoc(docType, formatType, options, params,
            combinedLiSelection, workingDirectory);
      else
        addGeneralMessage(errorMessages, "Invalid document type");
    } catch (IllegalArgumentException e) {
      log.error(e.getMessage());
      addGeneralMessage(errorMessages, "Invalid document type (" + docType + ") or file format (" + formatType + ")");
    } catch (IOException | SQLException | DocumentException e) {
      log.error(e.getMessage());
      addGeneralMessage(errorMessages, "System error during document creation");
    }
    if (fileName == null)
      return createResponse(action, null, null, errorMessages, null, null);

    log.debug(fileName);

    String fileKey = docType + "_" + formatType;
    downloadFileMap.put(fileKey, fileName);
    JSONObject successMessage = new JSONObject();
    addGeneralMessage(successMessage, fileKey);

    return createResponse(action, successMessage, null, errorMessages, null, null);
  }

  public StreamResponse onDownloadFile(String fileKey) throws IOException {
    if (downloadFileMap.containsKey(fileKey)) {
      String fileLocation = downloadFileMap.get(fileKey);
      String fileName = FileUtil.getFileNameWithoutPath(fileLocation);

      InputStream is = null;

      try {
        is = new FileInputStream(fileLocation);
        StreamResponse response = null;
        if (StringUtils.contains(fileKey, "PDF")) {
          response = getStream(is, fileName, "pdf");
        } else if (StringUtils.contains(fileKey, "EXCEL")) {
          response = getStream(is, fileName, "xml");
        } else {
          IOUtils.closeQuietly(is);
          return null;
        }
        return response;
      } catch (FileNotFoundException e) {
        log.error("Could not find file: " + fileLocation + " to download.", e);
        return null;
      }
    }
    return null;
  }

  @Log
  public JSONObject onRemoveUploadedExhibit(@RequestParameter("json") String jsonStr) {
    String action = "deleteUploadedExhibit";
    JSONObject errorMessages = new JSONObject();
    JSONObject successMessages = new JSONObject();
    JSONObject requestObj = null;

    requestObj = new JSONObject(jsonStr);

    String exhibitType = "";
    String title = "";
    String number = "";
    int budgetYear = 0;
    String budgetCycle = "";
    String serviceAgencyCode = "";
    String bsaNumber = "";
    String bsaTitle = "";
    Date submissionDate = null;

    try {
      exhibitType = requestObj.getString("exhibitType");
      title = requestObj.getString("title");
      number = requestObj.getString("exhibitNumber");
      budgetYear = requestObj.getInt("budgetYear");
      budgetCycle = requestObj.getString("budgetCycle");
      serviceAgencyCode = requestObj.getString("serviceAgencyCode");
      bsaNumber = requestObj.getString("budgetActivityNumber");
      bsaTitle = requestObj.getString("budgetActivityTitle");
    } catch (RuntimeException e) {
      log.info("A parameter was not found in request.", e);
      // addGeneralMessage(errorMessages, "Request is missing a required parameter.");
      // return createResponse(action, null, null, errorMessages, null, null);
    }

    if (StringUtils.equals(exhibitType, "P40")) {
      uploadSelection.removeP40UploadedItem(title, number, budgetYear, budgetCycle, serviceAgencyCode,
          bsaNumber, bsaTitle);
    } else if (StringUtils.equals(exhibitType, "R2")) {
      uploadSelection.removeR2UploadedItem(number, budgetYear, budgetCycle, submissionDate, serviceAgencyCode,
          bsaNumber, bsaTitle);
    } else {
      addGeneralMessage(errorMessages, "Invalid exhibit type:" + exhibitType + ".");
      return createResponse(action, null, null, errorMessages, null, null);
    }
    addGeneralMessage(successMessages, "Successfully delete uploaded exhibit.");
    return createResponse(action, successMessages, null, errorMessages, null, null);
  }

  @Log
  public void onReset() {
    uploadSelection.resetLists();
  }

  @Log
  public JSONObject onGetUploadSelections() {
    List<JSONObject> items = uploadSelection.getAllAsJson();
    JSONArray exhibits = new JSONArray();
    JSONObject response = new JSONObject();

    if (!items.isEmpty()) {
      for (JSONObject obj : items) {
        exhibits.put(obj);
      }
      response.put("exhibits", exhibits);
    }

    return response;
  }

  private Set<Integer> getR2Ids(JSONObject requestObj) {
    JSONArray idArray = requestObj.getJSONArray("r2SelectedExhibits");
    int i;
    Set<Integer> ids = new HashSet<Integer>();
    for (i = 0; i < idArray.length(); i++) {
      ids.add(idArray.getInt(i));
    }
    return ids;
  }

  private Integer[] getP40Ids(JSONObject requestObj) {
    JSONArray idArray = requestObj.getJSONArray("p40SelectedExhibits");
    int i;
    Integer[] ids = new Integer[idArray.length()];
    for (i = 0; i < idArray.length(); i++) {
      ids[i] = new Integer(idArray.getString(i));
    }
    return ids;
  }

  private DocumentAssemblyOptions getDocumentAssemblyOptions(boolean forceEvenPages, String watermark,
      String trackingHeader) {
    DocumentAssemblyOptions options = new DocumentAssemblyOptions();
    options.setForceEvenPages(forceEvenPages);
    options.setWatermark(watermark);
    options.setTrackingHeader(trackingHeader);
    return options;
  }

  private DocumentCreationParams getDocParams(String budgetCycle, int budgetYear, String serviceAgencyName) {
    DocumentCreationParams params = new DocumentCreationParams();
    params.setBudgetCycle(budgetCycle);
    params.setBudgetYear(Integer.valueOf(budgetYear));
    params.setServiceAgencyName(serviceAgencyName);
    return params;
  }

}
