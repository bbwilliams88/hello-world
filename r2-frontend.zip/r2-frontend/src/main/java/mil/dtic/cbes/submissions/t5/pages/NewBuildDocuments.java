package mil.dtic.cbes.submissions.t5.pages;



import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;



/**
 * "BuildDocumentsPage" used to reference the R2Select page
 */
@Import(
  stack=CbesT5SharedModule.DATATABLESTACK,
  library={
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/json2.js",
    "classpath:${cb.assetpath}/js/datatable.coffee",
  })

public class NewBuildDocuments extends PeListBase
{
  private static final Logger log = CbesLogFactory.getLog(NewBuildDocuments.class);
  
  @InjectPage
  private R2Select r2Select;

  @Log
  void onActivate()
  {
    log.debug("Nothing to do...");
  }
  
  @Log
  Object onOtherBuildSelect()
  {
    r2Select.setReturnPage(getClass());
    r2Select.setReturnButton("Return to Build Documents");
    return r2Select;
  }

}
