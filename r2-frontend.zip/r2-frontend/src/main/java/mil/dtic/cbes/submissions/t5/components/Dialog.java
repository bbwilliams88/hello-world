package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.model.DialogType;

/**
 * Supplies content for modal user dialogs. This component must be used in
 * conjunction with the DialogTrigger mixin. Multiple triggers can be attached
 * to the same dialog.
 *
 * Dialog supports two different modes: ALERT and CONFIRM. The default is a
 * confirm dialog, which provides YES/NO buttons whereas an alert dialog only
 * has an OK button.
 *
 * A dialog title is required and the component content is used to populate the
 * dialog.
 */
public class Dialog
{
    /**
     * The client id of the dialog. This works in conjunction with the dialogId
     * of the DialogTrigger mixin (they must match).
     */
    @Parameter(required=true, defaultPrefix = BindingConstants.LITERAL)
    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private String dialogId;

    /**
     * The dialog mode (either "alert" or "confirm"). An alert dialog only has
     * an accept button whose label is "OK" by default. A confirm dialog has
     * accept and cancel buttons, whose labels are "Yes" and "No" by default.
     */
    @Parameter(value = "confirm", defaultPrefix = BindingConstants.LITERAL, allowNull=false)
    @Property
    private DialogType mode;

    /**
     * The text for the "accept" button. It defaults to "Yes" for a confirm
     * dialog and "OK" for an alert dialog.
     */
    @Parameter(defaultPrefix=BindingConstants.LITERAL)
    private String acceptButton;

    /**
     * The text for the "cancel" button. It defaults to "No" for a confirm
     * dialog and is invalid for an alert dialog.
     */
    @Parameter(defaultPrefix=BindingConstants.LITERAL)
    private String cancelButton;

    /**
     * The title of the dialog.  Appears above the content.
     */
    @Parameter(required=true, defaultPrefix=BindingConstants.LITERAL)
    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private String title;

    void setupRender()
    {
        if (mode == DialogType.ALERT && cancelButton != null)
            throw new IllegalArgumentException("You cannot have a cancel button on an alert dialog.  Change the mode to 'confirm' or remove the t:cancelButton parameter.");
    }

    public boolean isAlertDialog()
    {
        return mode == DialogType.ALERT;
    }

    public boolean isConfirmDialog()
    {
        return mode == DialogType.CONFIRM;
    }

    public String getAcceptButtonText()
    {
        if (acceptButton != null)
            return acceptButton;
        else if (mode == DialogType.ALERT)
            return "OK";
        else
            return "Yes";
    }

    public String getCancelButtonText()
    {
        if (cancelButton != null)
            return cancelButton;
        else
            return "No";
    }
}
