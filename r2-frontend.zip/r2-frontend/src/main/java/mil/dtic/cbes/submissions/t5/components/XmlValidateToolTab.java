package mil.dtic.cbes.submissions.t5.components;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.upload.services.MultipartDecoder;

import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;



public class XmlValidateToolTab extends BaseXmlToolTab {
  
  private static final Logger log = CbesLogFactory.getLog(XmlValidateToolTab.class);
  
  @Parameter(required = true)
  @Property
  private File workingDirectory;
  
  @Inject
  private MultipartDecoder decoder;
  
  @Inject
  private HttpServletRequest request;
  
  public void onActivate() {

  }
  
  public JSONObject onValidateXml() {
    String action = "validateXml";
    List<JSONObject>itemsList = new LinkedList<JSONObject>();
    
    JSONObject errorMessages = new JSONObject();
    JSONObject successMessages = new JSONObject();
    JSONObject warningMessages = new JSONObject();
    JSONObject infoMessages = new JSONObject();
    
    List<XmlDocument> xmlsToValidate = new ArrayList<XmlDocument>();
    try {
      if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
        log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
        + ", expected " + getCurrentBudgesUser().getCsrfToken());
        throw new FileUploadException("Attempted to upload file without proper authorization");
      }
      xmlsToValidate = XmlUploadProcessor.getXmlDocumentsFromUpload(decoder.getFileUpload("file"), workingDirectory, false);
    } catch(FileUploadException|XmlDocumentException e) {
      log.error("Error processing uploaded file:", e);
      addGeneralMessage(errorMessages, e.getMessage());
      return createResponse(action, null, null, errorMessages, null, null);
    }
    
    for (XmlDocument x : xmlsToValidate) {
      validateXml(x, successMessages, warningMessages, errorMessages, infoMessages, itemsList, x.getOriginalFileName(), workingDirectory);
      x.closeAllStreams();
    }
    
    return createResponse(action, successMessages, warningMessages, errorMessages, infoMessages, itemsList);
  }
  
  private void validateXml(XmlDocument xd, JSONObject successMessages, JSONObject warningMessages, JSONObject errorMessages,  JSONObject infoMessages, List<JSONObject>itemsList, String fileName, File workingDir) {
    List<String>fileErrors = new LinkedList<String>();
    List<String> fileWarnings = new LinkedList<String>();
    List<String> fileInfo = new LinkedList<String>();


    // validate against schema
    log.debug("schema validation");
    List<Map<String, String>> items = new LinkedList<Map<String, String>>();
    XmlFullValidationService xmlValidator = xd.validateXmlSchema();
    
    if (!xmlValidator.isSchemaValid()) {
      fileErrors.addAll(xmlValidator.getSchemaErrorList());
      JSONObject fileErrorObj = formatFileMessage(fileName, fileErrors );
      addFileMessage(errorMessages, fileErrorObj);
      return;
    }
    
    log.debug("business rules validation - checking whether to migrate");
    XmlFullValidationService rulesValidator = null;
    String migratedFilenameBase = null;
    boolean performedMigration = false;
    
    // check if we need to migrate xml schema before validating
    if(xd.isPreviousBudgetCycle()) {
      try {
        performedMigration = xd.migrateXml();
      } catch(XmlDocumentException e) {
        fileErrors.add("There was a problem trying to migrate the XML to the current schema: " + e.getMessage());
        log.error("Error during migration", e);
      }
    }
    
    if(performedMigration) {
      InputStream migratedStream = xd.getMigratedInputStream();
  
      // write it out for user to download before rules validation because
      // rules validation closes the stream
      migratedFilenameBase = "migrated_" + getFileNameBase(fileName);
      File zipFile = new File(workingDir, FileUtil.createZipFileName(migratedFilenameBase));
      FileOutputStream fos = null;
      try {
        fos = new FileOutputStream(zipFile);
      } catch(FileNotFoundException e) {
        fileErrors.add("Unable to create zip of migrated XML files.");
      }
      BufferedOutputStream bos = new BufferedOutputStream(fos);
      ZipOutputStream zipOutputFile = new ZipOutputStream(bos);
      try {
        addToZip(IOUtils.toByteArray(migratedStream), FileUtil.createXmlFileName(migratedFilenameBase), zipOutputFile);
      } catch(IOException e) {
        fileErrors.add("There was a problem creating the migrated XML file for download");
      } finally {
        IOUtils.closeQuietly(zipOutputFile);
        IOUtils.closeQuietly(bos);
        IOUtils.closeQuietly(fos);
        xd.resetAllStreams();
      }
    }
    
    if(xd.checkBusinessRuleErrors()){
      fileErrors.addAll(xd.getBusinessRuleErrors());
      
      JSONObject fileErrorObj = formatFileMessage(fileName, fileErrors);
      
      addFileMessage(errorMessages, fileErrorObj);
      
      return;
    }
    
    rulesValidator = xd.validateBusinessRules(items);
    
    itemsList.add(formatItemsList(fileName, items));

    if (xmlValidator.isSchemaValid() && !xmlValidator.hasSchemaErrors() &&  (rulesValidator==null || !rulesValidator.hasRulesWarnings())){
      addGeneralMessage(successMessages, fileName+" is valid.");
    }
    if (xmlValidator.isSchemaValid() && (rulesValidator!=null && rulesValidator.hasRulesWarnings())){
      addGeneralMessage(successMessages, fileName+" is schema valid, but has business rules warnings ("+rulesValidator.getRulesWarningList().size()+").");
    }
    else if (!xmlValidator.isSchemaValid()) {
      fileErrors.addAll(xmlValidator.getSchemaErrorList());
    }
    if (rulesValidator!=null && rulesValidator.hasRulesWarnings()){
      fileWarnings.addAll(rulesValidator.getRulesWarningList());
    }
    if (migratedFilenameBase!=null){
      fileInfo.add(FileUtil.createZipFileName(migratedFilenameBase));
    }

    if (CollectionUtils.isNotEmpty(fileErrors)){
      JSONObject fileErrorObj = formatFileMessage(fileName, fileErrors );
      addFileMessage(errorMessages, fileErrorObj);
    }
    if (CollectionUtils.isNotEmpty(fileWarnings)){
      JSONObject fileWarningObj = formatFileMessage(fileName, fileWarnings);
      addFileMessage(warningMessages, fileWarningObj);
    }
    if (CollectionUtils.isNotEmpty(fileInfo)){
      JSONObject fileInfoObj = formatFileMessage(fileName, fileInfo);
      addFileMessage(infoMessages, fileInfoObj);
    }    

  }
  
  private JSONObject formatItemsList(String fileName, List<Map<String, String>> itemsList){
    JSONObject fileObj = new JSONObject();
    fileObj.put("fileName", fileName);
    JSONArray items = new JSONArray();
    for (Map<String, String> itemMap : itemsList){
      JSONObject itemObj = new JSONObject();
      for (Map.Entry<String, String> entry: itemMap.entrySet()){
        String key = entry.getKey();
        itemObj.put(key, entry.getValue());
      }
      items.put(itemObj);
    }
    fileObj.put("items", items);
    return fileObj;
  }
   
  public StreamResponse onDownloadFile(String location){
    log.debug("Location:"+location);
    InputStream is = null;
    if (location!=null){
      try {
      is = new FileInputStream(workingDirectory+"/"+location);
      StreamResponse response = getZipStream(is, FileUtil.getFileNameWithoutPath(location));
      return response;
    } catch (FileNotFoundException e) {
      log.error("Could not find file to download.",e);
      return null;
    } 
    }
    return null;
  }
  
 

}
