package mil.dtic.cbes.submissions.t5.components;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.service.P40SelectionService;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

@Import( stack   = {CbesT5SharedModule.DATATABLESBUTTONS },
		library = {"context:/js/p40dataTableExhibitIcons.js","context:/js/p40ExhibitListTable.js" }
		)
public class P40ExhibitListTable extends T5Base {

  private P40SelectionService p40SelectionService;

  private static final Logger log = CbesLogFactory.getLog(P40ExhibitListTable.class);

  @Inject
  private ComponentResources resources;

  @Inject
  private JavaScriptSupport jsSupport;

  @SessionState
  @Property
  private BudgetCycle selectedBudgetCycle;

  @Property
  private ServiceAgency selectedServiceAgency;

  @Inject
  private BudgetCycleDAO bcDAO;


//  @Parameter(required = true)
//  @Property
//  private UserCredentials userCredentials;


  public P40ExhibitListTable() {
    log.debug("init p40exhibitlisttable");
    // TODO Auto-generated constructor stub
    if (p40SelectionService==null){
      p40SelectionService = new P40SelectionService();
    }
  }

  void setupRender() {
    if(selectedBudgetCycle == null || StringUtils.isEmpty(selectedBudgetCycle.getCycle())) {
      log.debug("no p40 budget cycle selected, getting current budget cycle");
      selectedBudgetCycle = Util.getCurrentBudgetCycle();
    }
  }

  void afterRender()
  {
    JSONObject links = new JSONObject(
        "p40ExhibitTableDataUrl", resources.createEventLink("GetLiJson")+"",
        "budgetCycleChangedUrl", resources.createEventLink("BudgetCycleChange")+""
        );
    jsSupport.addScript("p40ExhibitListTablePageInit(%s);", links.toCompactString());
  }

  public JSONObject onGetLiJson(){
    log.debug("getting p40 list");
    String role = getUserCredentials().getUserInfo().getBudgesUser().getRole();

    boolean hasViewAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role)){
      hasViewAccess = false;
    }
    boolean hasEditAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role) || StringUtils.equals(LdapDAO.GROUP_R2_LOCALSITEADMIN,role)){
      hasEditAccess = false;
    }
    boolean hasShowTestExhibits = getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES);


    // psajbh: don't understand why we are getting available RDTE agencies when we should be getting P40 line items.
    //List<ServiceAgency> userAgencies = getUserCredentials().getUserInfo().getAvailableRdteAgencies();
    List<ServiceAgency> userAgencies = getUserCredentials().getUserInfo().getAvailableProcurementAgencies();
    log.debug("Number of user agencies: "+userAgencies.size());
    List<String> codes = new LinkedList<String>();
    for (ServiceAgency sa : userAgencies){
      codes.add(sa.getCode());
    }

    List<String> allowedProps = Lists.newArrayList(new String[] {
        "id",
        "p1LineItemNumber","lineItemNumber","budgetCycleAndYear","lineItemTitle",
        "agencyCode","agencyName", "appropriationNumber","appropriationTitle",
        "budgetActivityNumber","budgetActivityTitle","bsaNum","budgetSubActivityTitle",
        "creatorDisplayName","dateCreated","dateModified","modifierDisplayName","creatorDisplayName",
        "errors", "identifyingString",
        "test", "valid", "warnings", "xmlValidity", "initialSource",
        "status", "frozen", "warningCount", "errorCount"
      });

    JSONArray jsonArray = p40SelectionService.getLineItemsForTableView(getUserCredentials().getUserInfo().getBudgesUser().getUserLdapId(), hasViewAccess, hasEditAccess, hasShowTestExhibits, selectedBudgetCycle, codes, allowedProps, false, null);
    log.debug("got results: "+jsonArray.length());
//    log.debug(jsonArray.toString(false));

    JSONObject rootObj = new JSONObject();
    rootObj.put("aaData", jsonArray);
    return rootObj;


  }


  public void onBudgetCycleChange(String newBudgetCycle){
    selectedBudgetCycle = bcDAO.findByValue(newBudgetCycle);
  }
}
