package mil.dtic.cbes.submissions.t5.models;

import java.util.List;

/**
 * Abstract superclass to provide support for wizard-style navigation.
 */
public abstract class WizardNavigation
{
    private List<PageEntry> pages;

    public PageEntry getPageEntry(int index)
    {
        return pages.get(index);
    }

    /**
     * Given a Class for a page, look up the index of it in the List of
     * PageEntry objects.
     *
     * @param pageClass The page's Class.
     * @return The index value or -1 if not found.
     */
    public int getIndexForClass(Class<?> pageClass)
    {
        for (int i = 0; i < pages.size(); i++)
            if (pages.get(i).getPageClass().toString().equals(pageClass.toString()))
                return i;

        return -1; // FIXME: Throw an exception?
    }

    /**
     * Given the name of a page, look up the index of it in the List of
     * PageEntry objects.
     *
     * @param pageName The page's name.
     * @return The index value or -1 if not found.
     */
    public int getIndexForPage(String pageName)
    {
        for (int i = 0; i < pages.size(); i++)
            if (pages.get(i).getPageName().equals(pageName))
                return i;

        return -1; // FIXME: Throw an exception?
    }

    /**
     * @return The List of PageEntry objects.
     */
    public List<PageEntry> getPageEntries()
    {
        return pages;
    }

    /**
     * Sets the List of PageEntry objects.
     *
     * @param pages The List of PageEntry objects.
     */
    protected void setPageEntries(List<PageEntry> pages)
    {
        this.pages = pages;
    }
}
