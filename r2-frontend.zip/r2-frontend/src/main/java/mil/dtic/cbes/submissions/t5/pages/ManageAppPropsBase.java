package mil.dtic.cbes.submissions.t5.pages;


import org.apache.commons.mail.EmailException;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;

@Secured({"ROLE_R2AppMgr"})
public class ManageAppPropsBase extends T5Base
{
  public static enum configUpdateType {New, Copy, Update, Delete};

  private static final Logger log = CbesLogFactory.getLog(ManageAppProps.class);
  
  public void sendConfigChangedNotificationEmail(configUpdateType updateType, Config newConfig, Config oldConfig)
  {
    String configName = "";
    StringBuilder msg = new StringBuilder();
    if (newConfig != null)
    {
      msg.append("New Value:\n");
      msg.append("========================\n");
      msg.append(newConfig.toString());
      msg.append("\n\n");
      configName = newConfig.getName();
    }
    if (oldConfig != null)
    {
      msg.append("Old Value\n");
      msg.append("========================\n");    
      msg.append(oldConfig.toString());
      configName = oldConfig.getName();
    }
    try
    {
        BudgesContext.getEmailUtil().sendSystemEmail("*** App Config Changed - " + updateType + " Prop [" + configName + "] ***", msg.toString(), getUserCredentials());
    }
    catch (EmailException e)
    {
      log.error("Could not send Application Configuration Changed email", e);
    }
  }
}