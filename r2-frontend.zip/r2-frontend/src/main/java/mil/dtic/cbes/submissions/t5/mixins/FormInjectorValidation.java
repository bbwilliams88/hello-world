package mil.dtic.cbes.submissions.t5.mixins;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.Field;
import org.apache.tapestry5.PersistenceConstants;
import org.apache.tapestry5.ValidationTracker;
import org.apache.tapestry5.annotations.Environmental;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Environment;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.t5.utils.ValidationTrackerDecorator;
import mil.dtic.utility.CbesLogFactory;

public class FormInjectorValidation {

  private static final Pattern FORM_INJECTOR_PATTERN = Pattern.compile("(.+?):([a-z0-9]+)");
  private static final Pattern DUPLICATE_NAME_INDEX_EXTRACTOR = Pattern.compile("(.+?)_([0-9]+)");
  
  private static final Logger log = CbesLogFactory.getLog(FormInjectorValidation.class);
  
  @Persist(PersistenceConstants.FLASH) 
  private Map<String, SortedSet<RepeatingFieldInfo>> formInjectorValueStore;
  private Set<String> submittedFields = new HashSet<String>();
  private RepeatingFieldInfoComparator comparator = new RepeatingFieldInfoComparator();

  @Inject private Environment environment;
  @Environmental private ValidationTracker tracker;
  
  public void onPrepareForSubmit() {

    final ValidationTracker realTracker = environment.peekRequired(ValidationTracker.class);

    ValidationTracker realTracker2 = new ValidationTrackerDecorator() {

      @Override
      public void recordInput(Field field, String input) {  

        submittedFields.add(field.getControlName());

        RepeatingFieldInfo repeatingFieldInfo = getRepeatingFieldInfoForPostBack(field);

        if(repeatingFieldInfo != null) {

          repeatingFieldInfo.setValue(input);     

          log.error(repeatingFieldInfo + ": \"" + input + "\"");
        }

        realTracker.recordInput(field, input);
      }

      @Override
      public void recordError(Field field, String errorMessage) {

        submittedFields.add(field.getControlName());

        RepeatingFieldInfo repeatingFieldInfo = getRepeatingFieldInfoForPostBack(field);

        if(repeatingFieldInfo != null) {

          repeatingFieldInfo.setErrorMessage(errorMessage);         
        }

        realTracker.recordError(field, errorMessage);
      } 

      @Override
      public String getInput(Field field) {
                
        RepeatingFieldInfo repeatingFieldInfo = getFormInjectorFieldForRender(field);

        if(repeatingFieldInfo != null) {

          return repeatingFieldInfo.getValue();
        }
        else {
          
          return realTracker.getInput(field);
        }       
      }

      @Override
      public boolean inError(Field field) {

        RepeatingFieldInfo repeatingFieldInfo = getFormInjectorFieldForRender(field);

        if(repeatingFieldInfo != null) {

          return repeatingFieldInfo.getErrorMessage() != null;

        }
        else {

          return realTracker.inError(field);          
        }     
      } 
    };


    environment.push(ValidationTracker.class, realTracker2);
  }
  
  public void onFailure() {   

    if(this.formInjectorValueStore != null) {

      while(!submittedFields.isEmpty()) {

        String fieldName = submittedFields.iterator().next();       

        RepeatingFieldInfo fieldInfo = getRepeatingFieldInfoForPostBack(new MockField(fieldName));

        if(fieldInfo != null) {

          // i.e. this field matched some sort of repeating name pattern
          if(!submittedFields.contains(fieldInfo.getFieldName())) {

            // oops, the base field wasn't submitted
            SortedSet<RepeatingFieldInfo> set = formInjectorValueStore.get(fieldInfo.getFieldName());
            if(set != null && !set.isEmpty()) {
              
              MockField baseField = new MockField(fieldInfo.getFieldName());

              RepeatingFieldInfo removed = set.first();
              set.remove(removed);
              tracker.recordInput(baseField, removed.getValue());

              if(removed.getErrorMessage() != null) {

                tracker.recordError(baseField, removed.getErrorMessage());
              }             
            }
          }
          
          fieldName = fieldInfo.getFieldName();
        }

        List<String> removeMe = new ArrayList<String>();
        for(String field : submittedFields) {

          if(field.startsWith(fieldName)) {

            removeMe.add(field);
          }
        }
        
        for(String removal : removeMe) {
          
          submittedFields.remove(removal);
        }
      }   
    }
  }



  protected RepeatingFieldInfo getRepeatingFieldInfoForPostBack(Field field) {

    RepeatingFieldInfo ret = null;

    if(!StringUtils.isBlank(field.getControlName())) {

      Matcher formInjectorMatcher = FORM_INJECTOR_PATTERN.matcher(field.getControlName());

      if(formInjectorMatcher.matches()) {

        String controlName = formInjectorMatcher.group(1);          
        String hexTimestamp = formInjectorMatcher.group(2);
        long timestamp = parseHexEncodedLong(hexTimestamp);

        ret = new RepeatingFieldInfo();
        ret.setTimestamp(timestamp);        
        ret.setFieldName(controlName);          
      }
      else {

        Matcher matcher = DUPLICATE_NAME_INDEX_EXTRACTOR.matcher(field.getControlName());
        if(matcher.matches()) {

          String controlName = matcher.group(1);
          int index = Integer.parseInt(matcher.group(2));

          ret = new RepeatingFieldInfo();
          ret.setOrder(index);
          ret.setTimestamp(-1); 
          ret.setFieldName(controlName);        
        }
      }

      if(ret != null) {

        SortedSet<RepeatingFieldInfo> fields = getValuesForFormInjectorField(ret.getFieldName());

        if(fields.contains(ret)) {

          ret = find(fields, comparator, ret);          
        }
        else {

          fields.add(ret);
        } 
      }
    }

    return ret; 
  }
  
  protected RepeatingFieldInfo getFormInjectorFieldForRender(Field field) {

    RepeatingFieldInfo ret = null;

    if(!StringUtils.isBlank(field.getControlName())) {

      Matcher matcher = DUPLICATE_NAME_INDEX_EXTRACTOR.matcher(field.getControlName());
      if(matcher.matches()) {

        String controlName = matcher.group(1);
        String index = matcher.group(2);

        SortedSet<RepeatingFieldInfo> submittedValues = null;
        if((submittedValues = getFormInjectorValueStore().get(controlName)) != null) {

          int fieldIndex = Integer.parseInt(index);
          if(fieldIndex < submittedValues.size()) {
            
            Iterator<RepeatingFieldInfo> itr = submittedValues.iterator();
                        
            while(fieldIndex > 0) {
              
              fieldIndex--;
              itr.next();             
            }

            ret = itr.next();               
          }
        }
      }   
    }
    
    return ret;
  }

  protected RepeatingFieldInfo find(SortedSet<RepeatingFieldInfo> set, 
      RepeatingFieldInfoComparator comparator, RepeatingFieldInfo field) {

    for(RepeatingFieldInfo current : set) {

      if(comparator.compare(current, field) == 0) {

        return current;
      }
    }

    return null;
  }

  protected long parseHexEncodedLong(String s) throws NumberFormatException { 

    if (s.length() > 16)  
      throw new NumberFormatException();  
    int lowstart = s.length() - 8;  
    if (lowstart <= 0)  
      return Long.valueOf(s, 16);  
    else  
      return Long.valueOf(s.substring(0, lowstart), 16) << 32 | Long.valueOf(s.substring(lowstart), 16);  
  } 

  protected SortedSet<RepeatingFieldInfo> getValuesForFormInjectorField(String controlName) {

    SortedSet<RepeatingFieldInfo> ret = getFormInjectorValueStore().get(controlName); 

    if(ret == null) {

      ret = new TreeSet<RepeatingFieldInfo>(comparator);
      getFormInjectorValueStore().put(controlName, ret);
    }

    return ret;
  } 

  protected Map<String, SortedSet<RepeatingFieldInfo>> getFormInjectorValueStore() {

    if(formInjectorValueStore == null) {

      formInjectorValueStore = new HashMap<String, SortedSet<RepeatingFieldInfo>>();
    }

    return formInjectorValueStore;

  } 


  private static class RepeatingFieldInfo implements Serializable {

    private static final long serialVersionUID = 1366608557578376622L;

    private String fieldName;
    private String value;   
    private String errorMessage;
    private int order;
    private long timestamp;

    public String getValue() {
      return value;
    }
    public void setValue(String value) {
      this.value = value;
    }
    public long getTimestamp() {
      return timestamp;
    }
    public void setTimestamp(long timestamp) {
      this.timestamp = timestamp;
    }
    public int getOrder() {
      return order;
    }
    public void setOrder(int order) {
      this.order = order;
    }
    public String getErrorMessage() {
      return errorMessage;
    }
    public void setErrorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
    }
    public String getFieldName() {
      return fieldName;
    }
    public void setFieldName(String fieldName) {
      this.fieldName = fieldName;
    }   

    public String toString() {

      return fieldName + "[" + order + "]" + (timestamp == -1 ? "" : "[injected]");     
    }
  }

  private static class MockField implements Field {

    private final String controlName;   

    public MockField(String controlName) { this.controlName = controlName; }

    @Override
    public String getControlName() { return controlName; }

    @Override
    public String getLabel() { return null; }

    @Override
    public boolean isDisabled() { return false; }

    @Override
    public boolean isRequired() { return false; }

    @Override
    public String getClientId() { return null; }

  }

  private static class RepeatingFieldInfoComparator implements Comparator<RepeatingFieldInfo> {

    @Override
    public int compare(RepeatingFieldInfo o1, RepeatingFieldInfo o2) {

      // one field was added by ajax and the other was not, the non ajax field
      // is earlier in the list...
      if(o1.timestamp == -1 ^ o2.timestamp == -1) {     


        if(o1.timestamp == -1) {

          // o1 comes before o2, i.e. less than
          return -1;
        }
        else {

          return 1;
        }
      }
      else if(o1.timestamp == -1 && o2.timestamp == -1) {

        // neither was ajax, compare their order
        return Integer.valueOf(o1.order).compareTo(o2.order);       
      }
      else {

        // 2 ajax fields, compare their timestamps...
        return Long.valueOf(o1.timestamp).compareTo(o2.timestamp);
      }
    }   
  }
}

