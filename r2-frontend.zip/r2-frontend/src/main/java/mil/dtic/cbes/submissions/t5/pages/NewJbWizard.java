package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

/**
 * Backend for the single-page Justification Book wizard
 */
@Import(
  stack   = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DROPZONESTACK },
  library = { "context:js/urlencoder.js", "context:js/newjbwizard.js" })
public class NewJbWizard extends T5Base {

  @Property
  @Persist
  private File workingDirectory;

  @Inject
  private BudgetCycleDAO bcDAO;

  @Property
  private BudgetCycle currentBudgetCycle;

  @Property
  private SubmissionDate currentSubmissionDate;

  @Property
  private ServiceAgency currentServiceAgency;

  private static final Logger log = CbesLogFactory.getLog(NewJbWizard.class);

  @Inject
  private JavaScriptSupport jsSupport;

  public NewJbWizard() {
    log.debug("Initialize JB Wizard");
  }

  public void onActivate() {
    if (workingDirectory ==null){
      try {
        workingDirectory = createWorkingFolder();
      } catch (IOException e) {
        log.error("Couldn't create working folder.", e);
      }
    }
  }

  void afterRender() {
    log.debug("Initialize JavaScript support for JB wizard tooltab");
    // jsSupport.addScript(...)
  }

  @Override
  public List<BudgetCycle> getAllBudgetCycles()
  {
    List<BudgetCycle> cycles = bcDAO.getBudgetCycles();
    Collections.reverse(cycles);
    List<SubmissionDate> submDates = cycles.get(0).getSubmissionDates();
    currentSubmissionDate = submDates.get(submDates.size() - 1);
    return cycles;
  }

  public List<ServiceAgency> getServiceAgencies()
  {
    return getUserCredentials().getUserInfo().getAllAvailableAgencies();
    //return saDAO.findAllServiceAgencies();
  }
}