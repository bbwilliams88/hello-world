package mil.dtic.cbes.submissions.t5.pages;

import java.io.IOException;

import org.apache.tapestry5.EventContext;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.p40.vo.Config;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.utility.CayenneUtils;

@Import( library = { "js/newhomepage.js" })
public class NewHomePage extends PeListBase
{
    
    @Property
    private boolean rfr;
 
    
    public String getAnnouncementsContent()
    {
        Config configurationObject = Config.fetchByName(CayenneUtils.createDataContext(), ConfigService.R2_ANNOUNCMENTS);

        if (configurationObject != null)
            return configurationObject.getValue();
        else
            return "# Ooops!\nAnnouncements are missing...";
    }
    
    Object onActivate(EventContext evt) throws IOException{
        rfr = isRfr();
        if(rfr){
            
            return TrackingPage.class;
        }
        
        return null;
    }
    
    public boolean isRfr(){
        if (getUserCredentials().getUserInfo().getLdapUser().getR2Role().equals(LdapDAO.GROUP_R2_ANALYST)){
            return true;
            
        }
        return false;
    }

    
    
}
