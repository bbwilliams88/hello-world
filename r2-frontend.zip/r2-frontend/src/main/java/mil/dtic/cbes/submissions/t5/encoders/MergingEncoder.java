package mil.dtic.cbes.submissions.t5.encoders;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.cbes.submissions.dao.BudgesBaseDAO;
import mil.dtic.utility.CbesLogFactory;

public class MergingEncoder<T extends BudgesBaseValueObject> extends PkAndVersionEncoder<T>
{
  private static final Logger log = CbesLogFactory.getLog(MergingEncoder.class);
  protected final BudgesBaseDAO<T> dao;
  protected final T dummy;
  private boolean versionConflict = false;


  public MergingEncoder(BudgesBaseDAO<T> dao, T dummy)
  {
    if (dao==null) throw new IllegalArgumentException();
    log.debug("constructed");
    this.dao = dao;
    this.dummy = dummy;
  }
  
  public T toValue(Integer pk, Integer version)
  {
    log.debug("this is slow " + pk + ":" + version);
    
    T value = dao.findById(pk);
    if (value==null)
    {
      log.error("Row " + pk + " not found in " + dao +", maybe it was deleted?");
      return dummy;
    }
    dao.evict(value); // no auto save plz
    if (value.getVersion()!=null && !version.equals(value.getVersion()))
    {
      log.error("Version conflict - data may have been update since last retrieval");
      versionConflict = true;
    }
    
    return value;
  }

  public boolean isVersionConflict()
  {
    return versionConflict;
  }

  public void setVersionConflict(boolean versionConflict)
  {
    this.versionConflict = versionConflict;
  }
}