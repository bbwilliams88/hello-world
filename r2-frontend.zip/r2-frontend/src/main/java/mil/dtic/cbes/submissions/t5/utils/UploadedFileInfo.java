package mil.dtic.cbes.submissions.t5.utils;

import java.io.Serializable;

import org.apache.tapestry5.upload.services.UploadedFile;


public class UploadedFileInfo implements Serializable
{
  private static final long serialVersionUID = 1L;

  private final String contentType;
  private final String fileName;
  private final long size; 

  public UploadedFileInfo(UploadedFile ufile)
  {
    this.contentType = ufile.getContentType();
    this.fileName = ufile.getFileName();
    this.size = ufile.getSize();
  }

  public String getContentType()
  {
    // TODO Auto-generated method stub
    return contentType;
  }

  public String getFileName()
  {
    // TODO Auto-generated method stub
    return fileName;
  }

  public long getSize()
  {
    return size;
  }
}