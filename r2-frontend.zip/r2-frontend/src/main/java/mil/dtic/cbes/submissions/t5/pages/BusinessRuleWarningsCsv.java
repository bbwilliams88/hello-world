package mil.dtic.cbes.submissions.t5.pages;

import javax.servlet.http.HttpServletRequest;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.RequestGlobals;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.rule.RuleGroup;
import mil.dtic.cbes.rule.RuleGroupVisitor;
import mil.dtic.cbes.rule.RuleGroupVisitorFactory;
import mil.dtic.cbes.rule.RuleViolationList;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.validation.backend.ProgramElementValidator;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CBESFilenameUtils;
import mil.dtic.utility.CbesLogFactory;

public class BusinessRuleWarningsCsv extends NewR2Endpoint {
  private static final Logger log = CbesLogFactory.getLog(BusinessRuleWarningsCsv.class);
  @Inject
  private HttpServletRequest request;
  @Inject
  private RequestGlobals requestGlobals;
  @Property
  @Persist
  private String csvList;

  @Log
  TextStreamResponse onActivate(String peNumber) {
    ProgramElementDAO peDao = BudgesContext.getProgramElementDAO();
    try {
      ProgramElement pe = getRequestedPe(peNumber);

      RuleGroup pev = new ProgramElementValidator(pe);
      RuleGroupVisitor visitor = RuleGroupVisitorFactory.makeVisitor();
      visitor.visit(pev, pe.getServiceAgency().getCode());
      RuleViolationList violations = visitor.getRuleViolations();

      if (visitor.hasViolations()) {
        peDao.updateValidity(pe.getId(), PeSubmissionFlag.INVALID);
      } else {
        peDao.updateValidity(pe.getId(), PeSubmissionFlag.VALID);
      }

      StringBuilder sb = new StringBuilder();
      for (String violation : violations.asCsvLineList()) {
        sb.append(violation);
      }

      csvList = sb.toString();

      JSONObject response = new JSONObject();
      response.put("fileName", CBESFilenameUtils.sanitizeFileName(pe.getNumber()) + "-warnings.csv");
      return new TextStreamResponse("application/json", createSuccessResponse(response, "CSV warning list generated successfully").toString());


    } catch(ApiRequestException e) {
      return new TextStreamResponse("application/json", createErrorResponse(e.getMessage()).toString());
    }
  }

  public StreamResponse onDownloadFile(String location){
    requestGlobals.getResponse().setHeader("Content-Disposition", "attachment; filename=" + location);
    return new TextStreamResponse("application/octet-stream", csvList);
  }
}
