/**
 *
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.p40.vo.BudgetCycleConfig;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * Admin page which will be used to display and manage Budget Cycles.
 *
 * @author sminogue
 *
 */
@Secured({"ROLE_R2AppMgr"})
@Import(stack = {
  CbesT5SharedModule.DATATABLESTACK,
  CbesT5SharedModule.JQUERYTOOLSSTACK
},library = {"context:js/budgetcycleadmin.coffee","classpath:${cb.assetpath}/js/deleteconfirm.coffee"})
public class BudgetCycleAdmin extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(BudgetCycleAdmin.class);

  @Inject
  private JavaScriptSupport javaScriptSupport;

  @Inject
  private ComponentResources resources;

  @Inject
  private Request request;

  @Inject
  private AppDefaults appDefaults;

  @Property
  private String futureYear;

  @Property
  private BudgetCycle databaseBudgetCycle;

  @Property
  private BudgetCycle defaultBudgetCycle;

  @Property
  private SubmissionDate submissionDate;

  /**
   * Gets list containing a list of the next 5 years for drop downs.
   * @return
   */
  public List<String> getFutureYears(){

    Calendar cal = Calendar.getInstance();

    int year = cal.get(Calendar.YEAR);

    List<String> years = new ArrayList<String>();

    for(int i = 0 ; i < 5 ; i++){

      years.add(String.valueOf(year+i));

    }

    return years;

  }

  /**
   * Handler for the submit button on the add budget cycle form
   * @return
   */
  @Log
  JSONObject onAddBudgetCycleHandler(){

    //Construct response object to be returned from method
    JSONObject response = new JSONObject();
//    try{
      //Get form data
      JSONObject data = new JSONObject(request.getParameter("formData"));

      //Check if the budget cycle already exists or not.
      Expression exp = ExpressionFactory.matchExp(BudgetCycleConfig.BUDGET_YEAR_PROPERTY, data.get("year"));
      Expression exp2 = ExpressionFactory.matchExp(BudgetCycleConfig.CYCLE_PROPERTY, data.get("cycle")
          + (StringUtils.equals((String) data.get("amended"), "1") ? "Amended" : "")
          + (StringUtils.equals((String) data.get("amended"), "2") ? "Supplemental" : "" ));
      SelectQuery query = new SelectQuery(BudgetCycleConfig.class, exp.andExp(exp2));
      List<BudgetCycleConfig> cycles = CayenneUtils.createDataContext().performQuery(query);

      if(!cycles.isEmpty()){
        response.put("res", "TAKEN");
        response.put("msg", "The budget cycle already exists in the database.");
      }else{
        //Add cycle

        Integer amended = Integer.valueOf((String)data.get("amended"));
        BudgetCycleConfig config = CayenneUtils.createDataContext().newObject(BudgetCycleConfig.class);
        config.setBudgetYear(Integer.valueOf((String)data.get("year")));
        config.setCycle((String)data.get("cycle") + (amended  == 1 ? "Amended" : "") + (amended == 2 ? "Supplemental" : ""));
        config.setLabel(data.get("cycle") + " " + data.get("year") + (amended == 1 ? " Amended" : "") + (amended == 2 ? " Supplemental" : ""));
        config.setAmended(amended);
        config.setCreated(new Date());
        P40User user = P40User.fetchWithLdapId(config.getObjectContext(), getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
        config.setCreator(user);

        JSONArray submissions = data.getJSONArray("Submissions");

        for(int i = 0 ; i < submissions.length();i++){

          JSONObject submission = submissions.getJSONObject(i);

          mil.dtic.cbes.p40.vo.SubmissionDate submissionDate = config.getObjectContext().newObject(mil.dtic.cbes.p40.vo.SubmissionDate.class);
          submissionDate.setLabel(submission.getString("month") + " " + submission.getString("year"));
          submissionDate.setVal(submission.getString("month") + " " + submission.getString("year"));

          config.addToSubmissionDates(submissionDate);

        }

        config.getObjectContext().commitChanges();
        // this will prompt combined budget cycles and supports having a uniform submission date.
        Util.getCurrentBudgetCycle().getSubmissionDates().get(0);


        response.put("res", "OK");

      }

//    }catch(Exception e){
//      log.error("Error when attempting to insert new budget cycle: " + e.getMessage(),e);
//      response.put("res", "ERR");
//      response.put("msg", "The application suffered an error while attempting to insert new budget cycle.");
//    }

    return response;

  }

  /**
   * Handler for the delete trashcan on the add budget cycle form
   * @return
   */
  @Log
  JSONObject onDeleteBudgetCycleHandler(){

    //Construct response object to be returned from method
    JSONObject response = new JSONObject();
//    try{
      //Get form data
      JSONObject data = new JSONObject(request.getParameter("formData"));

      //Check if the budget cycle already exists or not.
      Expression exp = ExpressionFactory.matchExp(BudgetCycleConfig.BUDGET_YEAR_PROPERTY, data.get("year"));
      Expression exp2 = ExpressionFactory.matchExp(BudgetCycleConfig.CYCLE_PROPERTY, data.get("cycle"));
      SelectQuery query = new SelectQuery(BudgetCycleConfig.class, exp.andExp(exp2));
      List<BudgetCycleConfig> cycles = CayenneUtils.createDataContext().performQuery(query);

      if(cycles.isEmpty()){
        response.put("res", "UNFOUND");
        response.put("msg", "The budget cycle could not be found in the database.");
      }else{
        //Perform Delete

        for(BudgetCycleConfig config: cycles){
          config.delete();
          config.getObjectContext().commitChanges();
        }

        response.put("res", "OK");
      }
      
      Util.getCurrentBudgetCycle().getSubmissionDates().get(0);

//    }catch(Exception e){
//      log.error("Error when attempting to delete a budget cycle: " + e.getMessage(),e);
//      response.put("res", "ERR");
//      response.put("msg", "The application suffered an error while attempting to delete budget cycle.");
//    }

      
    return response;

  }

  // Had to add the DB code because the database cycles from app defaults were different than the values in the dropdown
  public List<BudgetCycle> getDatabaseBudgetCycles(){
    //Create combined list of spring configured and database configured budget cycles
    List<BudgetCycle> combinedCycles = new ArrayList<BudgetCycle>();

    //Add DB configured budget cycles
    SelectQuery query = new SelectQuery(BudgetCycleConfig.class);
    @SuppressWarnings("unchecked")
    List<BudgetCycleConfig> budgetCycleConfigs = CayenneUtils.createDataContext().performQuery(query);
    for(BudgetCycleConfig budgetCycleConfig : budgetCycleConfigs){

      BudgetCycle cycle = new BudgetCycle();
      cycle.setBudgetYear(budgetCycleConfig.getBudgetYear());
      cycle.setCycle(budgetCycleConfig.getCycle());
      cycle.setLabel(budgetCycleConfig.getLabel());

      if(budgetCycleConfig.getAmended() != null && budgetCycleConfig.getAmended() >= 0 && budgetCycleConfig.getAmended() <= 2){
        cycle.setAmended(budgetCycleConfig.getAmended());
      }

      List<mil.dtic.cbes.p40.vo.SubmissionDate> submissionDates = budgetCycleConfig.getSubmissionDates();

      List<SubmissionDate> disconnectedSubmissionDates = new ArrayList<SubmissionDate>();

      for(mil.dtic.cbes.p40.vo.SubmissionDate budgetCycleSubmissionDate : submissionDates){
        SubmissionDate sd = new SubmissionDate();
        sd.setValue(budgetCycleSubmissionDate.getVal());
        sd.setLabel(budgetCycleSubmissionDate.getLabel());
        disconnectedSubmissionDates.add(sd);
      }

      cycle.setSubmissionDates(disconnectedSubmissionDates);
      combinedCycles.add(cycle);
    }

    Collections.sort(combinedCycles);

    return combinedCycles;
  }

  public List<BudgetCycle> getDefaultBudgetCycles(){
    return appDefaults.getDefaultBudgetCycles();
  }

  /**
   * After Render will fire the JS initialize and pass it the URL's of handlers to be used in ajax calls.
   */
  @Log
  void afterRender()
  {
    String addBudgetCycleUrl = resources.createEventLink("addBudgetCycleHandler").toString();
    String deleteBudgetCycleUrl = resources.createEventLink("deleteBudgetCycleHandler").toString();
    javaScriptSupport.addScript("initialize('%s','%s');",addBudgetCycleUrl,deleteBudgetCycleUrl);
  }

}
