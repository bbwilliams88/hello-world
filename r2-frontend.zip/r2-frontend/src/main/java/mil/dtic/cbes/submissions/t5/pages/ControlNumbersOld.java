/*
 * $Id: PRPCPage.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.pages;

import static java.math.BigDecimal.ZERO;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.beaneditor.RelativePosition;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.corelib.components.Grid;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.grid.ColumnSort;
import org.apache.tapestry5.grid.GridSortModel;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.InjectService;
import org.apache.tapestry5.ioc.services.PropertyAccess;
import org.apache.tapestry5.services.BeanModelSource;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.NarrowPeListBy;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.dao.exception.AlreadyLockedException;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.MappedEncoder;
import mil.dtic.cbes.submissions.t5.encoders.PkAndVersionEncoder;
import mil.dtic.cbes.submissions.t5.etc.MappedPropertyConduit;
import mil.dtic.utility.BigDecimalUtil;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;

/**
 * This page presents a list of ProgramElementList, then saves to ProgramElement
 */
public class ControlNumbersOld extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(ControlNumbersOld.class);

  @Inject
  private Messages messages;
  @Inject
  private BeanModelSource beanModelSource;
  @Inject
  private ComponentResources componentResources;
  @InjectService("PropertyAccess")
  private PropertyAccess propertyAccess;
  @InjectPage
  private AlreadyLockedPage lockedPage;

  @Property
  @Persist
  private NarrowPeListBy narrowPeListBy;

  @Property
  @Persist
  private List<ProgramElementList> pes; // read-only list
  private Map<Integer,ProgramElementList> pesMap; // for formfield encoder
  @Property
  @Persist
  private Map<Integer,ProgramElementBase> fatPesMap; // writes go here
  /* Made some manual getters and setters instead
  @SuppressWarnings("unused")
  @Property
  */
  private ProgramElementList pe; // pe currently being iterated over
  @SuppressWarnings("unused")
  @Property
  private ProgramElementBase fatPe; // fat version of current
  @Property
  private PkAndVersionEncoder<ProgramElementList> peEncoder;
  @Property
  private int budgetYear;

  //grid form
  @SuppressWarnings("unused")
  @Component(id = "grid")
  @Property
  private Grid grid;
  @Component(id = "pesedit")
  private Form pesForm;
  private boolean isSortSubmit; // distingiush between Save submit and sort submit in pe edit form

  //switch-to-edit-mode form
  @Property
  @Persist
  private Boolean viewMode; // readonly vs rw fields
  @InjectComponent
  private Zone editModeZone;
  @SuppressWarnings("unused")
  @Property
  private boolean editModeRefresh;
  @Property
  private boolean forceUnlock;
  @Component(id = "editmodeform")
  @Property
  private Form editModeForm;


  void onActivate()
  {
    log.debug("onActivate");

    if (viewMode!=null && viewMode)
    {
      // force view mode to always reload from db
      // for some reason I think getting any changes that
      // could have happened when exhibits were unlocked is a good idea
      nukeSessionData();
    }
    initNarrowBy();
    initPes(narrowPeListBy);
    initViewMode();
    budgetYear = narrowPeListBy.getBudgetCycle().getBudgetYear();
    peEncoder = new MappedEncoder<ProgramElementList>(pesMap, new ProgramElementList());
    isSortSubmit = true;
    //editModeErrors = false;
    editModeRefresh = false;
    forceUnlock = false;
  }

  // edit button
  Object onSuccessFromEditmodeform()
  {
    log.debug("onSuccessFromEditmodeform force=" + forceUnlock);
    try
    {
      lockPes(getCurrentBudgesUser(), forceUnlock);
      viewMode = false;
      editModeRefresh = true; // refresh after this ajax call to make form editable
    } catch (AlreadyLockedException e) {
      log.debug("", e);
      editModeForm.recordError(messages.format("these-exhibits-locked", getPeNumbersFromIds(e.getCauses())));
    }
    return editModeZone.getBody();
  }

  void onNukeSessionData()
  {
    nukeSessionData();
  }

  void onCancel()
  {
    try {
      lockPes(null, false);
    } catch (AlreadyLockedException e) {
      // user doesn't care in this case
      log.error("", e);
      //pesForm.recordError("blah5");
    }
    nukeSessionData();
  }

  void setupRender()
  {
    log.debug("setupRender");
  }

  void afterRender()
  {
    log.debug("afterRender");
    editModeForm.clearErrors();
    pesForm.clearErrors();
  }

  void onPrepare()
  {
    log.debug("onPrepare");
  }

  void onValidateFromNarrowPeListForm()
  {
    log.debug("onValidateFromNarrowPeListForm");
  }

  Object onSuccessFromNarrowPeListForm()
  {
    log.debug("onSuccessFromNarrowPeListForm");
    nukeSessionData(); // narrowby refresh discards changes
    return null;
  }

  void onSortSubmit()
  {
    log.debug("onSortSubmit");
  }

  // switch to and update line item order
  void onUpdateOrder()
  {
    log.debug("onUpdateOrder");
    GridSortModel sortModel = grid.getSortModel();
    ColumnSort cs = sortModel.getColumnSort(ProgramElementBase.LINE_NO);
    if (cs==ColumnSort.UNSORTED) {
      // hit once to get ascending order
      sortModel.updateSort(ProgramElementBase.LINE_NO);
    } else {
      // hit twice to go back to whatever order the user had before
      sortModel.updateSort(ProgramElementBase.LINE_NO);
      sortModel.updateSort(ProgramElementBase.LINE_NO);
    }
  }

  void onSaveSubmit()
  {
    log.debug("onSaveSubmit");
    isSortSubmit = false;
  }

  void onValidateFromPesEdit()
  {
    log.debug("onValidateForm");

    if (!isSortSubmit)
    {
      // run validation checks on pes
      // only base+ooc=total for now
      for (ProgramElementBase pe : fatPesMap.values())
      {
        // I wish we could use ProgramElementValidator here...
        BigDecimal base = pe.getFundingBy1Base()==null ? ZERO : pe.getFundingBy1Base();
        BigDecimal ooc = pe.getFundingBy1Ooc()==null ? ZERO : pe.getFundingBy1Ooc();
        BigDecimal total = pe.getFundingBy1()==null ? ZERO : pe.getFundingBy1();

        if (BigDecimalUtil.notEquals(total, base.add(ooc)))
        {
          pesForm.recordError(messages.format("funding-base-ooc-error", pe.getNumber(), budgetYear));
        }
      }
    }
  }

  Object onSuccessFromPesedit()
  {
    log.debug("onSuccessFromPesedit");
    if (isSortSubmit)
    {
      log.debug("onSuccessFromPesedit isSort");
    }
    else
    {
      try {
        savePes();
        try {
          lockPes(null, false);
        } catch (AlreadyLockedException e) {
          log.error("", e); // doesn't matter to user in this case
        }
        nukeSessionData();
      } catch (AlreadyLockedException e) {
        log.error("onSuccessFromPesedit: AlreadyLockedExcepton " + e.getMessage());
        nukeSessionData();
        lockedPage.setPage(getClass());
        return lockedPage;
      }
    }
    return null;
  }

  void pageDetached()
  {
    log.debug("pageDetached");
  }




  public BeanModel<ProgramElementList> getPesModel()
  {
    log.trace("getPesModel");
    BeanModel<ProgramElementList> model = beanModelSource.createDisplayModel(ProgramElementList.class, componentResources.getMessages());
    model.include("number");
    model.add(RelativePosition.AFTER, "number", "baNum").label(messages.get("pe-number-header"));
    model.add(RelativePosition.AFTER, "baNum","serviceAgencyName").label(messages.get("agency-header"));
    //lineitem needs propertyconduit to be editable and sortable
    model.add(ProgramElementBase.LINE_NO, new FatPePropertyConduit("r1LineNumber", Integer.class)).label(messages.get("lineitem-header"));
    //model.add("r1LineNumber", null).label("Line Item #");
    model.add("fundingPy", null).label(fundingLabel(budgetYear-2));
    model.add("fundingCy", null).label(fundingLabel(budgetYear-1));
    model.add("fundingBy1Base", null).label(messages.format("funding-base-theader", budgetYear));
    model.add("fundingBy1Ooc", null).label(messages.format("funding-ooc-theader", budgetYear));
    model.add("fundingBy1", null).label(messages.format("funding-total-theader", budgetYear));
    model.add("fundingBy2", null).label(fundingLabel(budgetYear+1));
    model.add("fundingBy3", null).label(fundingLabel(budgetYear+2));
    model.add("fundingBy4", null).label(fundingLabel(budgetYear+3));
    model.add("fundingBy5", null).label(fundingLabel(budgetYear+4));
    return model;
  }

  //hook into setter so Grid's update of current pe updates current fatPe
  public void setPe(ProgramElementList pe)
  {
    this.pe = pe;
    if (pe!=null && pe.getId()!=null) {
      fatPe = fatPesMap.get(pe.getId());
    } else {
      fatPe = null;
      log.error("setPe: Null pe encountered");
    }
  }

  public ProgramElementList getPe()
  {
    return pe;
  }

  // formats funding py-by5 labels
  public String fundingLabel(int budgetYear)
  {
    return messages.format("funding-theader", budgetYear);
  }

  private boolean isEvenBudgetYear()
  {
    return false; //budgetYear % 2 == 0;
  }


  class FatPePropertyConduit extends MappedPropertyConduit<ProgramElementBase>
  {
    public FatPePropertyConduit(String expr, Class<?> exprClass)
    {
      super(propertyAccess, fatPesMap, expr, exprClass);
    }
  }

  private void nukeSessionData()
  {
    pes = null;
    fatPesMap = null;
    viewMode = null;
  }

  private void initNarrowBy()
  {
    if (narrowPeListBy==null)
    {
      narrowPeListBy = new NarrowPeListBy();
      narrowPeListBy.setBudgetCycle(Util.getCurrentBudgetCycle());
    }
  }

  private List<ProgramElementList> findByNarrowingFields(NarrowPeListBy nplb, boolean restrictToAgency, boolean restrictToUPes)
  {
    return BudgesContext.getProgramElementListDAO().findByNarrowingFields(getCurrentBudgesUser(), restrictToAgency, restrictToUPes, nplb, null, null, false, ProgramElementList.NUMBER);
  }

  private List<ProgramElementList> fetchPesByUserPerm(NarrowPeListBy nplb)
  {
    if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES))
    {
      // show all pe's
      log.debug("Retrieving all pe's...");
      return findByNarrowingFields(nplb, false, false);
    }
    else if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY))
    {
      // show all pes for user's agencies
      log.debug("Retrieving all pe's for user's agencies...");
      return findByNarrowingFields(nplb, true, false);
    }
    else
    { // show only pe's for which user has access
      log.debug("Retrieving pe's for user based on user's agencies and pe permissions...");
      return findByNarrowingFields(nplb, true, true);
    }
  }

  private void initPes(NarrowPeListBy nplb)
  {
    if (pes==null)
    {
      pes = fetchPesByUserPerm(nplb);
      Set<Integer> peIds = TapestryUtil.ognlsettransform(pes, ProgramElementList.ID);
      List<ProgramElementBase> fatPes = BudgesContext.getProgramElementBaseDAO().findByIdsPaged(peIds, 0, -1, false, new String[]{ProgramElementBase.NUMBER});
      fatPesMap = new HashMap<Integer,ProgramElementBase>(fatPes.size());
      for (ProgramElementBase pe : fatPes)
      {
        fatPesMap.put(pe.getId(), pe);
      }
    }
    pesMap = new HashMap<Integer,ProgramElementList>(pes.size());
    for (ProgramElementList pe : pes)
    {
      pesMap.put(pe.getId(), pe);
    }
  }

  private void initViewMode()
  {
    if (viewMode == null) viewMode = true;
  }

  private void savePes() throws AlreadyLockedException
  {
    // TODO recheck permissions?
    List<ProgramElementBase> fatPes = Util.toArrayList(fatPesMap.values());
    List<Integer> peIds = TapestryUtil.ognllisttransform(fatPes, ProgramElementBase.ID);
    BudgesContext.getSaveService().doPRPCSave(getCurrentBudgesUser(), fatPes, peIds, false);
  }

  private void lockPes(BudgesUser setLockTo, boolean forceLock) throws AlreadyLockedException
  {
    BudgesContext.getPELockDAO().lockAllR2s(getCurrentBudgesUser(), setLockTo, Util.toArrayList(pesMap.keySet()), forceLock);
  }

  private String getPeNumbersFromIds(List<Integer> ids)
  {
    if (ids==null || ids.size()==0) return "";
    StringBuffer sb = new StringBuffer();
    for (Integer id : ids)
    {
      ProgramElementList pe = pesMap.get(id);
      if (pe!=null)
      {
        sb.append(pe.getNumber());
      } else {
        log.error("getPeNumbersFromIds: could not find " + id);
        sb.append("null");
      }
      sb.append(" ");
    }
    return sb.toString();
  }
}
