/*
ldapUserIdldapUserIdCreated new user credentials * $Id$
 */
package mil.dtic.cbes.sso.siteminder;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndServiceAgencyLink;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.uiobjects.UserListItem;
import mil.dtic.cbes.submissions.uiobjects.UserListItemFactory;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;
import netscape.ldap.LDAPException;

public class UserUtils {
  private static final Logger log = CbesLogFactory.getLog(UserUtils.class);

  private UserUtils(){}

  /**
   * Create an LDAP User from ldapUserId string input. 
   * @param ldapUserId - String
   * @return ldapUser - LdapUser
   * @throws LDAPException
   */
  public static LdapUser getLdapUser(String ldapUserId) throws LDAPException {
      
    LdapUser ldapUser = null;

    if (StringUtils.isEmpty(ldapUserId)) {
        // generate a new LdapUser from the config table [user.localUserId entry].
        ldapUser = BudgesContext.getConfigService().getLdapUser();
        
        if (ldapUser != null && StringUtils.isNotEmpty(ldapUser.getLdapUserId())) {
            
            // if the config table indicates the user.fromLdapForLocalUser property is true, get the ldapUser from LdapDaoImpl"
            if (BudgesContext.getConfigService().getAttributesFromLdapForLocalUser()) {
                ldapUser = BudgesContext.getLdapDAO().getLdapUser(ldapUser.getLdapUserId());
            }
            else{
                log.debug("ldap User generated defaulting to using config data");
            }
        } 
        else {
            log.error("No remote or local user, user cannot access this r2 app. Double check that the configuration has LDAP attributes (user id, email, etc.) defined for their host.");
        }
    }
    else {
      //log.debug("ldap user generated from LDAP service (NetLDAP.userinfo");
      ldapUser = BudgesContext.getLdapDAO().getLdapUser(ldapUserId);
    }

    log.debug(String.format("ldap user generated from getLdapUser method user: %s", ldapUser != null ? ldapUser.getLdapUserId() : "no user found"));
    
    return ldapUser;
  }


  public static String getLdapUserIdFromRequest(HttpServletRequest req) {
    String ldapUserId = req.getHeader(Constants.HTTP_HEADER_REMOTE_USER);  //"remote_user"
        
    if (StringUtils.isEmpty(ldapUserId)){ 
        ldapUserId = req.getHeader(Constants.HTTP_HEADER_REMOTE_USER); //"remote_user"

    }
    
    if (StringUtils.isEmpty(ldapUserId)){
        ldapUserId = req.getRemoteUser();
    }
    
    if (StringUtils.isNotEmpty(ldapUserId)){
        ldapUserId = ldapUserId.trim();
    }
    
    return ldapUserId;
  }


  public static List<UserListItem> getManagedUsers(UserCredentials creds, boolean removeAppMgrsAndSiteadmins, boolean asc, String sort)
  {
    if (creds == null || sort == null){
        throw new NullPointerException();
    }
    
    boolean manageAll = creds.checkPrivilege(Privilege.MANAGE_ALL_USERS);
    List<UserListItem> users = new ArrayList<UserListItem>();
    List<BudgesUser> busers = BudgesContext.getBudgesUserDAO().findAllActive(asc, sort);
    UserListItemFactory factory = new UserListItemFactory(creds);

    for (BudgesUser b : busers){
      if (!factory.isInCurrentUserOrg(b) && !manageAll){
          continue; 
      }
                                                                  
      LdapUser luser = BudgesContext.getLdapDAO().getCached(b);
      String r2Group = b.getRole(); // luser.getR2Group();

      if (!factory.isManagedByCurrentUserAllowed(r2Group)){
          continue; 
      }
                                                                     
      boolean isAppMgr = LdapDAO.GROUP_R2_APP_ADMIN.equals(r2Group);
      boolean isSiteAdmin = LdapDAO.GROUP_R2_SITEADMIN.equals(r2Group);
      
      if (removeAppMgrsAndSiteadmins && (isAppMgr || isSiteAdmin)){
          continue; 
      }
                                                                             
      users.add(factory.getFromObjects(luser, b));
    }

    return users;
  }


  /**
   * Returns a list of agencies the user is a member of, sorted by name
   * BudgesUser object must be in hibernate session.
   */
  public static List<ServiceAgency> getMemberAgenciesList(BudgesUser persistBuser){
    List<ServiceAgency> agencies = TapestryUtil.ognllisttransform(persistBuser.getBudgesUserAndServiceAgencyLinks(), BudgesUserAndServiceAgencyLink.SERVICE_AGENCY);
    TapestryUtil.ognlsort(agencies, true, ServiceAgency.NAME);
    return agencies;
  }


  /**
   * The regular getMemberAgenciesList gets lazy objects that can't be stored in
   * session
   */
  public static List<ServiceAgency> getMemberAgenciesListSlow(BudgesUser b)  {
    Set<Integer> agencyIds = BudgesContext.getBudgesUserAndServiceAgencyLinkDAO().findAgencyIdsForUser(b);
    return BudgesContext.getServiceAgencyDAO().findByIdsPaged(agencyIds, 0, -1, true, ServiceAgency.NAME);
  }


  public static BudgesUser addUser(LdapUser luser){
    try {
      BudgesUser bu = BudgesUser.createTransient(luser);
      BudgesContext.getBudgesUserDAO().saveOrUpdate(bu);
      return bu;
    }
    catch (RuntimeException re) {
      log.error("create failed", re);
      throw re;
    }
  }


  public static void setOrgForUser(BudgesUser buser, ServiceAgency org, BudgesUser admin) {
    if (buser.getAgencies() == null) buser.setAgencies(new HashSet<ServiceAgency>(1));
    buser.getAgencies().clear();
    buser.getAgencies().add(org);
    Util.setAuditFieldsForUser(buser, admin);
    BudgesContext.getBudgesUserDAO().saveOrUpdate(buser);
  }


  public static boolean deleteUser(String userLdapId) {
      log.trace("UserUtils:deleteUser - userLdapId: " + userLdapId);
      boolean rValue = false;
      BudgesUser user = BudgesContext.getBudgesUserDAO().findByUserLdapId(userLdapId);
      
      if (null == user) {
          log.error("userLdapId: " + userLdapId + " was not found in database");
      }
      else{
          user.setStatusFlag(StatusFlag.DELETED);
          user.setCreatedByBudgesUser(null); // nuke dates
          BudgesContext.getBudgesUserDAO().saveOrUpdate(user);
          log.warn("userLdapId: " + userLdapId + " status was updated to DELETED");
          rValue = true;
      }
      
    return rValue;
  }


  /**
   * Create user info based on config user.fromLdapForLocalUser setting being true.
   * Cleanup the BudgesUserAndProgramElementLink if necessary
   * @param sessionId - String
   * @param ldapUserId - String
   * @return UserInfo
   */
    public static UserInfo createUserInfo(String sessionId, String ldapUserId){
        BudgesUser budgesUser = null;
        LdapUser ldapUser;
        boolean pullFromLdap = BudgesContext.getConfigService().getAttributesFromLdapForLocalUser();
        log.debug("pullFromLdap: " + pullFromLdap);
    
        try{
            ldapUser = UserUtils.getLdapUser(pullFromLdap ? ldapUserId : null);
      
            if (ldapUser==null) {
                return null;
            }

            ldapUserId = ldapUser.getLdapUserId();

            if (ldapUserId != null){
                if (ldapUserId.trim().length() <= 0 || "null".equalsIgnoreCase(ldapUserId)){
                    return null;
                }
            }
            else{
                return null;
            }
        }
        catch (LDAPException e) {
            log.error("Could not create LdapUser object for user id " + ldapUserId, e);
            return null;
        }
        
        try {
            budgesUser = BudgesContext.getBudgesUserDAO().saveAndGetUserForSession(ldapUser);
        } 
        catch (RuntimeException e) { //lock timeout
            log.warn("Failure to execute saveAndGetUserForSession msg: " + e.getMessage(), e);
            budgesUser = BudgesContext.getBudgesUserDAO().findByUserLdapId(ldapUserId);
            BudgesContext.getBudgesUserDAO().initialize(budgesUser.getBudgesUserAndServiceAgencyLinks());
            BudgesContext.getBudgesUserDAO().initialize(budgesUser.getAgencies());
        }
        
        if (budgesUser != null){
            log.info("Found R2 user for user id " + ldapUserId + " with " + budgesUser.getBudgesUserAndServiceAgencyLinks().size() + " service/agency associations.");
            // If user has recently become siteadmin delete userpe links
            if (LdapDAO.GROUP_R2_APP_ADMIN.equals(budgesUser.getRole())||LdapDAO.GROUP_R2_SITEADMIN.equals(budgesUser.getRole())){
                List<BudgesUserAndProgramElementLink> userpes = BudgesContext.getBudgesUserAndProgramElementLinkDAO().findByUser(budgesUser);
        
                if (userpes!=null && userpes.size()>0){
                    log.info("Found user pes for a " + budgesUser.getRole() + ", deleting...");
                    BudgesContext.getBudgesUserAndProgramElementLinkDAO().deleteAll(userpes);
                }
            } 
        }

        UserInfo userInfo = new UserInfo(ldapUser, budgesUser);
    
        log.info(String.format("Created new user credentials, ldap=%s  budgesUser=%s session id=%s",ldapUser, budgesUser, sessionId));
        return userInfo;
  }

  public static String getRequestInfo(HttpServletRequest req){
    String path = req.getRequestURL().toString() + (req.getQueryString() == null ? "" : "?" + req.getQueryString());
    String user = UserUtils.getLdapUserIdFromRequest(req);
    String useragent = req.getHeader("User-Agent");
    String referer = req.getHeader("Referer");
    String sessionId = req.getSession(false) == null ? null : req.getSession(false).getId();
    return String.format("Request: user=%s path=%s referer=%s user-agent=%s session=%s", user, path, referer, useragent, sessionId);
  }
}