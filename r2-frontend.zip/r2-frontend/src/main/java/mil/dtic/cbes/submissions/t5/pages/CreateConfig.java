package mil.dtic.cbes.submissions.t5.pages;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.ConfigTypeFlag;
import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.utility.CbesLogFactory;

@Secured({"ROLE_R2AppMgr"})
public class CreateConfig extends ManageAppPropsBase
{
  private static final List<String> cycleList = Arrays.asList (Constants.BUDGET_CYCLE_BES, Constants.BUDGET_CYCLE_PB, Constants.BUDGET_CYCLE_PB_AMENDED, Constants.BUDGET_CYCLE_PB_SUPPLEMENTAL);
  private static final Logger log = CbesLogFactory.getLog(CreateConfig.class);

  @Inject
  private ConfigDAO configDAO;
  
  @Inject    
  private JavaScriptSupport javaScriptSupport;

  @Property
  @Persist
  private Config config;

  @Property
  private String useLocalHost = "default";

  @Property
  @Persist
  private Boolean isValueBoolean;

  /*
  @Property
  @Persist
  private Boolean isCycleYearDependent;
  */
  @SuppressWarnings("unused")
  @Property
  private boolean useCustomHostName;

  @SuppressWarnings("unused")
  @Property
  private String localHost;

  @Property
  private String customHost;

  @SuppressWarnings("unused")
  @Inject
  private Request request;

  @InjectComponent
  private Zone valueZone;

  @InjectComponent
  private Zone hostZone;

  @Component(id = "configForm")
  private Form configForm; 
  private boolean _isCancelButton=false;  

  void onActivate(boolean newPageRequest)
  {
    //ManageAppProps will call this method with newPageRequest=true
    if (newPageRequest) {
      nukeSessionData();
      //set default values
      config.setBudgetCycle("xxxxx");
      config.setBudgetYear(0);
    }		  
    try
    {
      localHost=InetAddress.getLocalHost().getHostName();
    }
    catch (UnknownHostException e)
    {
      log.error("Unknown Host: " + e.getMessage(),e);
    }
  }

  @Log
  Object onActionFromCancel()
  {
    // this flag will prevent validation when onValidateFromConfigForm is called
    _isCancelButton=true;  
    nukeSessionData();
    return ManageAppProps.class;
  }

  public List<ConfigTypeFlag> getTypeList(){
    List <ConfigTypeFlag> flagList = new ArrayList<ConfigTypeFlag>();
    for(ConfigTypeFlag value:ConfigTypeFlag.values())
      flagList.add(value);

    return flagList;
  }

  public List<String> getCycleList() {
    return cycleList; 
  }

  Object onChangeValueType(ConfigTypeFlag valueType)
  { 
    if(valueType != ConfigTypeFlag.BOOLEAN) {
      isValueBoolean = false;
      config.setValue("");
    }
    else 
      isValueBoolean = true;

    config.setValueType(valueType);

    return valueZone.getBody();
  }

  Object onChangeHostName(String hostName)
  {
    if(StringUtils.equals(hostName, "custom"))
      useCustomHostName = true;
    else
      useCustomHostName = false;

    config.setHostName(hostName);
    return hostZone.getBody();

  }

  Object onValidateFromConfigForm()
  {
  if (_isCancelButton){ 
      return null;
  }

  configForm.clearErrors();
  if(config.getName() == null)
  {     
    configForm.recordError("Please enter a Configuration Name");
    return this;
  }
  if(StringUtils.equalsIgnoreCase(useLocalHost, "custom"))
  {
    if(customHost == null){
      configForm.recordError("Please enter a Custom Host Name");
      return this;  
    }
  }
  /*
  if (config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD) || config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE) ) {
    //set this indicator to ensure budget cycle/year fields are displayed so user can enter required data for cycle/year
    isCycleYearDependent = true;
    if (config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD) && !config.getValueType().equals(ConfigTypeFlag.STRING))
    {
      configForm.recordError("The value type for " + ConfigService.R2_JB_PDF_PASSWORD + " must be STRING.");
      return this;  
    }
    if (config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE) && !config.getValueType().equals(ConfigTypeFlag.BOOLEAN))
    {
      configForm.recordError("The value type for " + ConfigService.R2_JB_PDF_PASSWORD_ENABLE + " must be BOOLEAN.");
      return this;  
    }
    if (config.getBudgetCycle() == null)
    {
      configForm.recordError("Please enter a Budget Cycle");
      return this;  
    }
    if(config.getBudgetYear() == null)
    {
      configForm.recordError("Please enter a Budget Year");
      return this;  
    }
    //r2.jbPdfPassword should be unique per host/cycle/year
    if (config.getBudgetCycle() != null && config.getBudgetYear() != null) {
      if (configDAO.findByNameAndCycle(config.getName(), customHost, config.getBudgetCycle(), config.getBudgetYear().intValue() ) != null)
      {
        configForm.recordError("The Configuration Name cannot match one that is already in the database for the environment, cycle, and year you selected.");
        return this;
      }  
    }
  }
  // Other attributes should be unique with respect to host name
  else
    if (configDAO.findByName(config.getName(), config.getHostName()) != null)
    {
      configForm.recordError("The Configuration Name cannot match one that is already in the database for the environment you selected.");
      return this;
    }   
  */
  
  if (configDAO.findByNameAndCycle(config.getName(), customHost, config.getBudgetCycle(), config.getBudgetYear().intValue() ) != null)
  {
    configForm.recordError("The Configuration Name cannot match one that is already in the database for the environment, cycle, and year you selected.");
    return this;
  }  
  
  if (config.getValue() == null || StringUtils.isEmpty(config.getValue())) {
    configForm.recordError("Please enter a Configuration Value.");
    
    //TODO: This was working initially and then stopped, figure out what is going on with it.
    // This manually changes the CSS of the Configuration Value label in the tml to match the styling of the other labels when
    // a validation error is detected, which wasn't being done by Tapestry directly. 
    // javaScriptSupport.addScript("{$(#configurationValueId).attr('class','t-error')}");
    
    return this;
  }

  switch (config.getValueType())
  {
    case BOOLEAN:
      if (!(StringUtils.equalsIgnoreCase(config.getValue(), "true") || StringUtils.equalsIgnoreCase(config.getValue(), "false")))
      {
        configForm.recordError("You have not entered a boolean. Change the value to either true or false or change the value type.");
      }
      break;
    case NUM:
      try
      {
        Long.parseLong(config.getValue());
      }
      catch (NumberFormatException e)
      {
        configForm.recordError("You have entered a non-numeric value. Change the value to a number or change the value type.");
      }
      break;
    case EMAIL:
    case HOST:
    case PATH:
    case URL:
  }

  return null;
  }


  Object onSuccess()
  {
    config.setCreatedByBudgesUser(getCurrentBudgesUser());
    config.setModifiedByBudgesUser(getCurrentBudgesUser());
    config.setDateCreated(new Date());
    config.setDateModified(new Date());
    if(false == StringUtils.equalsIgnoreCase(useLocalHost, "default"))
    {
      if(StringUtils.equalsIgnoreCase(useLocalHost, "custom"))
      {
        config.setHostName(customHost);
      }else{
        try
        {
          config.setHostName(InetAddress.getLocalHost().getHostName());
        }
        catch (UnknownHostException e)
        {
          config.setHostName("default");
        }
      }
    }else
      config.setHostName("default");

    // Set default values 
    //if(!config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD) && !config.getName().equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE)) {
    //  config.setBudgetCycle("xxxxx");
    //  config.setBudgetYear(0);
    //}

    configDAO.saveByConfig(config);
    sendConfigChangedNotificationEmail(configUpdateType.New, config, null);
    nukeSessionData();
    return ManageAppProps.class;
  }

  private void nukeSessionData () {
    // clean up 
    isValueBoolean = true;
    //isCycleYearDependent = null;
    config = new Config();
  }
}
