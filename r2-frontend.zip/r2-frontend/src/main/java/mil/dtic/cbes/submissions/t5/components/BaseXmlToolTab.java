package mil.dtic.cbes.submissions.t5.components;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Response;

import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.FileUtil;

public class BaseXmlToolTab extends T5Base {
  
  protected static final String ZIP_EXTENSION = "zip";

  protected static final String PDF_EXTENSION = "pdf";

  protected static final String XML_EXTENSION = "xml";
  
  protected static final String FILE_EXTENSION_SEPARATOR = ".";

  protected static final String TMP_FILE_PREFIX = "mxt";
  
  // Strip file path and extension
  protected String getFileNameBase(String filename) {
    String base = FileUtil.getFileNameWithoutPath(filename);
    int idx = filename.lastIndexOf(".");
    return base.substring(0, idx);
  }
  
  protected void addToZip(byte[] bytes, String name, ZipOutputStream zipOs) throws IOException {
    ZipEntry zipEntry = new ZipEntry(name);
    zipOs.putNextEntry(zipEntry);
    zipOs.write(bytes);
  }
  
  protected void addGeneralMessage(JSONObject obj, String msg){
    JSONObject msgObj = new JSONObject();
    msgObj.put("message", msg);
    JSONArray generalArray = null;
    if (obj.has("general")){
       generalArray = obj.getJSONArray("general");
    }
    else {
      generalArray = new JSONArray();
      obj.put("general", generalArray);
    }
    generalArray.put(msgObj);
  }
  
  protected void addFileMessage(JSONObject messageObj, JSONObject fileMessageObj ){
    JSONArray fileArray = null;
    if (messageObj.has("files")){
      fileArray = messageObj.getJSONArray("files");
    }
    else {
      fileArray = new JSONArray();
      messageObj.put("files", fileArray);
    }
    fileArray.put(fileMessageObj);
  }
  
  protected JSONObject formatFileMessage(String fileName, List<String> msgs){
    JSONObject fileObj = new JSONObject();
    fileObj.put("fileName", fileName);
    JSONArray msgArray = new JSONArray();
    for (String str: msgs) {
      JSONObject obj = new JSONObject();
      obj.put("message", str);
      msgArray.put(obj);
    }
    fileObj.put("messages", msgArray);
    return fileObj;
  }

  protected JSONObject createResponse(String action, JSONObject successMessages, JSONObject warningMessages, JSONObject errorMessages,  JSONObject infoMessages, List<JSONObject> itemsList){
    JSONObject rootObj = new JSONObject();
    rootObj.put("action", action);
    rootObj.put("errorMessages", errorMessages);
    rootObj.put("successMessages", successMessages);
    rootObj.put("infoMessages", infoMessages);
    rootObj.put("warningMessages", warningMessages);
    JSONArray itemsArray = new JSONArray();
    if (itemsList!=null){
      for (JSONObject obj: itemsList){
        itemsArray.put(obj);
      }
      rootObj.put("files", itemsArray);
    }
    
    return rootObj;
  }
  

  protected StreamResponse getZipStream(final InputStream is, final String fileName){
    return new StreamResponse(){
      public String getContentType(){
        return "application/zip";
      }
      public InputStream getStream() throws IOException{
        return is;
        
      }
      public void prepareResponse(Response response){
        response.setHeader("Content-Disposition", "attachment; filename="+fileName);
      }
    };
  }
  
  protected StreamResponse getStream(final InputStream is, final String fileName, final String contentType){
    return new StreamResponse(){
      public String getContentType(){
        return "application/"+contentType;
      }
      public InputStream getStream() throws IOException{
        return is;
        
      }
      public void prepareResponse(Response response){
        response.setHeader("Content-Disposition", "attachment; filename="+fileName);
      }
    };
  }
  
  
}
