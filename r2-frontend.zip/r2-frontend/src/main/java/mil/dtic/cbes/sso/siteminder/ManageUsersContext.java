/*
 * $Id$
 */
package mil.dtic.cbes.sso.siteminder;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;

import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.uiobjects.DetailedUserListItem.RadioValue;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;
import netscape.ldap.LDAPException;

@SuppressWarnings("unused")
public class ManageUsersContext {
	private static final Logger log = CbesLogFactory.getLog(ManageUsersContext.class);

	public static enum PeShowMethod {
		SHOW_ALL, SHOW_ALL_IN_AGENCY, SHOW_FROM_UPE_TABLE
	};

	private UserCredentials creds;
	private UserInfo userInfo;

	private final PeShowMethod peShowMethod;
	private final Set<ServiceAgency> adminAgencies;
	private final Set<Integer> adminAgencyIds;
	private List<BudgesUserAndProgramElementLink> adminUserPes = Collections.emptyList();
	private final List<Integer> viewablePes;
	private final List<Integer> editablePes;
	private final boolean showTestPes;
	private final boolean showAllUsers;
	
	public ManageUsersContext(UserCredentials creds) {
		if (creds == null)
			throw new NullPointerException("UserListItemFactory()");
		this.creds = creds;
		userInfo = creds.getUserInfo();
		if (creds.checkPrivilege(Privilege.SHOW_ALL_PES)) {
			peShowMethod = PeShowMethod.SHOW_ALL;
		} else if (creds.checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY)) {
			peShowMethod = PeShowMethod.SHOW_ALL_IN_AGENCY;
		} else {
			peShowMethod = PeShowMethod.SHOW_FROM_UPE_TABLE;
		}

		this.showTestPes = creds.checkPrivilege(Privilege.SHOW_TEST_PE);
		this.showAllUsers = creds.checkPrivilege(Privilege.MANAGE_ALL_USERS);
		this.adminAgencies = new HashSet<ServiceAgency>(userInfo.getAllAvailableAgencies());
		this.adminAgencyIds = TapestryUtil.ognlsettransform(adminAgencies, ServiceAgency.ID);

		BudgesUser adminUser = BudgesContext.getBudgesUserDAO().findById(userInfo.getBudgesUser().getId());

		if (peShowMethod == PeShowMethod.SHOW_FROM_UPE_TABLE) {
			// localsiteadmin will only see PEs assigned to him
			viewablePes = BudgesContext.getBudgesUserAndProgramElementLinkDAO().findViewablePeIds(adminUser);
			editablePes = BudgesContext.getBudgesUserAndProgramElementLinkDAO().findEditablePeIds(adminUser);
		} else {
			// save on fetching this for siteadmin/appmgr
			viewablePes = Collections.emptyList();
			editablePes = Collections.emptyList();
		}
	}

	public void sortAndLoadAdminPes(boolean asc, String[] peSorts) {
		log.debug("sortAndLoadAdminPes");
		if (getPeShowMethod(PeShowMethod.SHOW_FROM_UPE_TABLE)) {
			this.adminUserPes = getUserPesForView(creds.getUserInfo().getBudgesUser(), asc, peSorts);
		}
	}

	public List<BudgesUser> getManagedUsers(boolean removeAppMgrsAndSiteadmins, boolean sortByAgenciesFirst,
			boolean asc, String[] sorts) {
		if (sorts == null)
			throw new NullPointerException();

		Set<String> roles = new HashSet<String>(LdapDAO.VALID_GROUPS_SET);
		if (creds.checkPrivilege(Privilege.MANAGE_ALL_USERS)) {
			roles.add(LdapDAO.GROUP_NONE);
		}
		Iterator<String> i = roles.iterator();

		while (i.hasNext()) {
			if (!isManagedByCurrentUserAllowed(i.next()))
				i.remove();
		}
		if (removeAppMgrsAndSiteadmins) {
			roles.remove(LdapDAO.GROUP_R2_APP_ADMIN);
			roles.remove(LdapDAO.GROUP_R2_SITEADMIN);
			roles.remove(LdapDAO.GROUP_NONE);
		}

		List<BudgesUser> managedUsers;
		if (showAllUsers) {
			managedUsers = BudgesContext.getBudgesUserDAO().findManagedUsers(roles.toArray(new String[0]),
					Collections.<Integer>emptySet(), 0, -1, asc, sorts);
		} else {
			managedUsers = BudgesContext.getBudgesUserDAO().findManagedUsers(roles.toArray(new String[0]),
					adminAgencyIds, 0, -1, asc, sorts);
		}

		if (!BudgesContext.getConfigService().getR2MaintenanceModeValue()
				&& !creds.getUserInfo().getBudgesUser().getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN)) {
			managedUsers = managedUsers.stream().filter(u -> !u.isTestUser()).collect(Collectors.toList());
		}
		return managedUsers;
	}

	public List<BudgesUser> getManagedUsers(ServiceAgency peAgency, String sort, boolean asc) {
		String[] sorts = getOverriddenSorts(sort);
		List<BudgesUser> l = getManagedUsers(true, false, asc, sorts);
		for (Iterator<BudgesUser> i = l.iterator(); i.hasNext();) {
			BudgesUser b = i.next();
			if (!b.getAgencies().contains(peAgency))
				i.remove();
		}
		return l;
	}

	public static final String USER_ID_COL = BudgesUser.USER_LDAP_ID;
	public static final String FIRST_NAME_COL = BudgesUser.FIRST_NAME;
	public static final String LAST_NAME_COL = BudgesUser.LAST_NAME;
	public static final String FORMATTEDNAME_COL = "formattedName";
	public static String[] getOverriddenSorts(String sortCol) {
		if (sortCol.equals(FORMATTEDNAME_COL))
		{
		  return new String[] { LAST_NAME_COL, FIRST_NAME_COL, USER_ID_COL };
		}
		return new String[] { sortCol};
	}

	public List<BudgesUserAndProgramElementLink> getUserPesForView(BudgesUser buser, boolean asc, String[] sorts) {
		return BudgesContext.getBudgesUserAndProgramElementLinkDAO().findByUserWithPes(buser, asc, sorts);
	}

	public List<ProgramElementBase> getProgramElementsForEdit(BudgesUser buser, boolean asc, String[] sorts) {
		List<ServiceAgency> buserAgencies = UserUtils.getMemberAgenciesList(buser);
		for (Iterator<ServiceAgency> i = buserAgencies.iterator(); i.hasNext();) {
			if (!adminAgencyIds.contains(i.next().getId()))
				i.remove();
		}

		if (peShowMethod == PeShowMethod.SHOW_ALL || peShowMethod == PeShowMethod.SHOW_ALL_IN_AGENCY) {
			return BudgesContext.getProgramElementBaseDAO().findByAgencies(sorts, asc, showTestPes,
					buserAgencies.toArray(new ServiceAgency[0]));
		}

		List<ProgramElementBase> adminPes = TapestryUtil.ognllisttransform(adminUserPes,
				BudgesUserAndProgramElementLink.PROGRAM_ELEMENT);
		List<Integer> buserAgencyIds = TapestryUtil.ognllisttransform(buserAgencies, ServiceAgency.ID);
		for (Iterator<ProgramElementBase> i = adminPes.iterator(); i.hasNext();) {
			if (!buserAgencyIds.contains(i.next().getServiceAgency().getId()))
				i.remove();
		}
		return adminPes;
	}

	public Map<Integer, RadioValue> getUserRvMapForProfile(BudgesUser buser) {
		log.debug("getUserRvMapForProfile");
		List<BudgesUserAndProgramElementLink> userPes;
		userPes = BudgesContext.getBudgesUserAndProgramElementLinkDAO().findByUser(buser);

		Map<Integer, RadioValue> userPePerms = new HashMap<Integer, RadioValue>(adminUserPes.size());

		for (BudgesUserAndProgramElementLink aupe : adminUserPes) {
			userPePerms.put(aupe.getProgramElement().getId(), RadioValue.NONE);
		}

		for (BudgesUserAndProgramElementLink upe : userPes) {
			Integer peId = upe.getProgramElement().getId();
			RadioValue rv = RadioValue.fromUpe(upe);
			if (rv == RadioValue.NONE) {
				log.error("An N/N permission is lying around: " + upe);
			}
			if (userPePerms.get(peId) != null) {
				userPePerms.put(peId, rv);
			}
		}
		return userPePerms;
	}

	public Map<Integer, RadioValue> getUserRvMapForPe(List<BudgesUser> managedUsers, Integer peId) {
		List<BudgesUserAndProgramElementLink> userPes = BudgesContext.getBudgesUserAndProgramElementLinkDAO()
				.findByPe(peId);
		Map<Integer, RadioValue> userRvMap = new HashMap<Integer, RadioValue>(userPes.size());
		//Map<Integer, RadioValue> userRvMap = new HashMap<>();

		for (BudgesUserAndProgramElementLink upe : userPes) {
			userRvMap.put(upe.getUser().getId(), RadioValue.fromUpe(upe));
		}

		for (BudgesUser b : managedUsers) {
			if (userRvMap.get(b.getId()) == null) {
				userRvMap.put(b.getId(), RadioValue.NONE);
			}
		}

		return userRvMap;
	}

	public JSONObject updateLdapCache() {
		JSONObject responseObject = new JSONObject();
		JSONArray errorMessages = new JSONArray();
		JSONArray successMessages = new JSONArray();

		int successCount = 0;

		for (BudgesUser b : BudgesContext.getBudgesUserDAO().findAllActive(true, BudgesUser.ID)) {
			String ldapid = b.getUserLdapId();
			try {
				LdapUser freshluser = BudgesContext.getLdapDAO().getLdapUser(ldapid);
				freshluser.setR2Role(b.getRole()); // we don't want to update the user role based on LDAP group
				BudgesContext.getBudgesUserDAO().saveLdapData(b, freshluser);
				log.debug("successfully updated ldap cache: " + b.getUserLdapId());
				successCount++;
			} catch (LDAPException le) {
				// https://docs.oracle.com/cd/E19957-01/816-5618-10/netscape/ldap/LDAPException.html
				if (le.getMessage().contains("failed to connect to server")) {
					errorMessages.put("Unable to update cache: " + le.getMessage());
					break;
				} else {
					log.error("Error updating ldap data in user list", le);
					String errorMsg = "error: " + b.getUserLdapId() + " msg: " + le.getMessage();
					errorMessages.put(errorMsg);
				}
			}
		}

		if (errorMessages.length() > 0) {
			responseObject.put("errorMessages", errorMessages);
		} else {
			String msg = "successfully updated " + successCount + " user account(s)";
			successMessages.put(msg);
			responseObject.put("successMessages", successMessages);
		}
		return responseObject;
	}

	public void saveCreate(List<BudgesUser> sessionUsers) {
		for (BudgesUser b : sessionUsers) {
			BudgesContext.getBudgesUserDAO().evict(b);
		}
		// get the db ones
		Set<Integer> updatedIds = TapestryUtil.ognlsettransform(sessionUsers, BudgesUser.ID);
		List<BudgesUser> dbUsers = BudgesContext.getBudgesUserDAO().findByIdsPaged(updatedIds, 0, -1, true,
				new String[] { BudgesUser.ID });
		// put them in map for easy access
		Map<Integer, BudgesUser> dbUserMap = new HashMap<Integer, BudgesUser>(dbUsers.size());
		for (BudgesUser b : dbUsers) {
			dbUserMap.put(b.getId(), b);
		}

		// check for changes & save
		for (BudgesUser b : sessionUsers) {
			BudgesUser dbb = dbUserMap.get(b.getId());
			if (b.isCreatePeAllowed() != dbb.isCreatePeAllowed()) {
				log.debug("Saving Create on user=" + dbb + " " + b.isCreatePeAllowed());
				// copy changes to db original, then save it
				dbb.setCreatePeAllowed(b.isCreatePeAllowed());
				Util.setAuditFieldsForUser(dbb, creds.getUserInfo().getBudgesUser());
				BudgesContext.getBudgesUserDAO().saveOrUpdate(dbb);
			}
		}
	}

	public boolean isManagedByCurrentUserAllowed(String r2Role) {
		return creds.getUserInfo().checkManageRole(r2Role);
	}

	public UserCredentials getCreds() {
		return creds;
	}

	public boolean getPeShowMethod(PeShowMethod peShowMethod) {
		if (peShowMethod == PeShowMethod.SHOW_ALL) {
			return true;
		}
		
		if (peShowMethod == PeShowMethod.SHOW_ALL_IN_AGENCY) {
			return true;
		}
		
		if (peShowMethod == PeShowMethod.SHOW_ALL_IN_AGENCY) {
			return true;
		}
		
		if (peShowMethod == PeShowMethod.SHOW_FROM_UPE_TABLE) {
			return true;
		}
		
		return false;
	}
	
	public PeShowMethod getPeShowMethod() {
		return this.peShowMethod; 
	}

}