/*
 * $Id: LogoUpload.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLConnection;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.utility.CbesLogFactory;

public class LogoUpload extends T5Base
{
  private static final String IMGEVENT = "selectedImage";

  private static final Logger log = CbesLogFactory.getLog(LogoUpload.class);
  @Inject
  private ComponentResources componentResources;


  @Inject
  private ConfigService config;


  private boolean makeDefault;

  @Parameter(required = true)
  @Property
  private File file;

  @Parameter(required = true)
  @Property
  private ServiceAgency agency;

  @Component(publishParameters="workingDir,showSaved,originalName,filevalidator,validate", inheritInformalParameters=true)
  private SavedUpload uploadcomponent;

  @Property
  @Parameter(defaultPrefix=BindingConstants.LITERAL, value="200px")
  @SuppressWarnings("unused") // Used in the TML.
  private String maxHeight, maxWidth;

  @OnEvent(value=IMGEVENT)
  StreamResponse onSelectedImage() throws IOException
  {
    if (agency==null) //no logo is expected when agency not set
      return null;
    File streamthis;
    if (file !=null && file.exists())
      streamthis = file;
    else if (getDefaultLogoFile().exists())
      streamthis = getDefaultLogoFile();
    else {
      log.error("No logo file found! " + getDefaultLogoFile(), new FileNotFoundException());
      return null;
    }
    String mimeType = URLConnection.getFileNameMap().getContentTypeFor(streamthis.getName());
    return getStreamResponse(FileUtils.openInputStream(streamthis), mimeType, null);
  }

  public Object getSelectedImage()
  {
    //tack on unused random context to nuke caching
    return componentResources.createEventLink(IMGEVENT, UUID.randomUUID().toString());
  }

  public boolean isDefault()
  {
    //is previewed image the default one
    return file==null || !file.exists();
  }

  public boolean getMakeDefault()
  {
    return makeDefault;
  }

  public void setMakeDefault(boolean makeDefault)
  {
    this.makeDefault = makeDefault;
    if (makeDefault && file!=null && file.exists())
      doDefault();
  }

  public boolean showCheckbox()
  {
    UserCredentials uc = getUserCredentials();
    return uc !=null && uc.checkPrivilege(Privilege.LOGODEFAULT);
  }

  private File getDefaultLogoFile()
  {
    String logosDir = config.getLogoImagesFolder();
    String agencyLogo = agency == null ? "doesnotexist.png" : agency.getLogoFileName();
    return new File(logosDir, agencyLogo);
  }

  //do the copying over to the /d2 directory
  private void doDefault()
  {
    log.info("Setting " + file + " as default image for agency " + agency);
    if (!getDefaultLogoFile().exists())
    {
      log.error("Failed to copy logo file - original didn't exist");
      return;
    }
    try {
      FileUtils.copyFile(file, getDefaultLogoFile());
      uploadcomponent.delete();
      file = null;
      makeDefault = false;
    } catch (IOException e) {
      log.error("Failed to copy logo file", e);
    }
  }

}
