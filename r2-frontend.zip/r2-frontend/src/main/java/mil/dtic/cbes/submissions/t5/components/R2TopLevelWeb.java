package mil.dtic.cbes.submissions.t5.components;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.data.config.FormatFlag;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.t5.base.T5Base;

public class R2TopLevelWeb extends T5Base
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;

  @Property
  private ServiceAgency serviceAgency;

  public int addIntegers(int intOne, int intTwo)
  {
    return intOne + intTwo;
  }

  public List<ServiceAgency> getServiceAgencies()
  {
    return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
  }

  public int yearFromDate(Date theDate)
  {
    // Template should look like:
    // ${addIntegers(yearFromDate(PEBase.submissionDate), -1}
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
    String s = yearFormat.format(theDate);
    return Integer.valueOf(s);
  }
  
  public boolean isR2Long()
  {
    if (PEBase.getFormat() == FormatFlag.R2Long) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isEditRights()
  {
    return getUserCredentials().checkPrivilege(Privilege.MANAGE_USERS) || getUserCredentials().checkPrivilege(Privilege.ADMIN_ALL_AGENCIES);
  }
}
