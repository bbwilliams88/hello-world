package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;

public class R5ExhibitWeb
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  
  public int addIntegers(int intOne, int intTwo)
  {
      return intOne + intTwo;
  }
}
