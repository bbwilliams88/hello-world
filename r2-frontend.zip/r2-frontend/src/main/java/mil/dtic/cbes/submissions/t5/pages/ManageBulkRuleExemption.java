package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
//import org.apache.tapestry5.annotations.SetupRender;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import mil.dtic.cbes.constants.BulkExemptionControl;
import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.p40.vo.BudgetCycleConfig;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.rule.Rule;
import mil.dtic.cbes.rule.RuleRepository;
import mil.dtic.cbes.rule.RuleRepositoryFactory;
import mil.dtic.cbes.sso.siteminder.SpringUser;
import mil.dtic.cbes.submission.bulkexemption.ManageBulkRuleHelper;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.ValidationExemption;
import mil.dtic.cbes.submissions.dao.ValidationExemptionDAO;
import mil.dtic.cbes.submissions.service.annotated.AppCacheReloadControllerRules;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.validation.backend.ValidationService;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;

/**
 * Provides adminstrative support for processing validation exemptions in bulk.
 *
 */
@SuppressWarnings("deprecation")
@Import(library = { "context:js/manageBulkValidationRules.js" })
@Secured({ "ROLE_R2AppMgr" })
public class ManageBulkRuleExemption extends T5Base {
    private static final Logger log = CbesLogFactory.getLog(ManageBulkRuleExemption.class);
    private static final String NEW_ACTIVE = "NEW ACTIVE";
    private static final String NEW_INACTIVE = "NEW INACTIVE";
    private static final String UPDATED_ACTIVE = "UPDATED ACTIVE";
    private static final String UPDATED_INACTIVE = "UPDATED INACTIVE";
    private static final String SUCCESS_COMMIT = "Successful commit";
    //private static final String P40USER_FAIL = "Failed to create a P40User";
    private static final String RESET_MSG = "xxx";
    private static final String WELCOME_MSG = "Welcome!\n Select an organization, action and appropriation. Click Execute button to generate bulk exemptions.";
    private static final String BULK_EXEMPT_OK = "Successfully processed exemptions for all rules for (org: %s appn: %s action: %s) as follow: ";
    private static final String BULK_NO_PROCESS = "No exemptions were processed as they are already identified as existing for the specified organization (%s)";
    private static final String REQUIRED_FIELDS = "Organization, Action and Appropriation values are all required fields";
    private static final String APP_NOT_AVAIL = "The appropriation value selected (%s) is not currently available.";

    @Inject
    private JavaScriptSupport javaScriptSupport;

    @Inject
    private ValidationService validationService;

    @Inject
    private AppCacheReloadControllerRules appCacheReloadController;

    @Persist
    @Property
    private List<ManageBulkRuleHelper> businessRuleList;

    @Property
    private String msg;

    @Persist
    @Property
    private String agency;

    @Persist
    @Property
    private String action;

    @Persist
    @Property
    private String appropriation;

    @Property
    private List<String> appropriations;
    
    @Property
    private List<String> actions;

    @Property
    private List<String> agencies;

    @Property
    private Map<String, ServiceAgency> serviceAgencies;

    private StringBuilder statusResult = null;

    private List<mil.dtic.cbes.submissions.ValueObjects.ValidationExemption> validationRDTEExemptions;

    @Persist
    @Property
    private String statusMessage;

    @Persist
    @Property
    String previousMsg;
    
    void afterRender() {
      javaScriptSupport.addScript("setup();");
    }

    void onPrepare() {
        if (null == businessRuleList) {
            businessRuleList = makeRDTEBusinessRuleList();
        }

        if (null == validationRDTEExemptions) {
            setRDTEValidationExemptions();
        }

        if (null == agencies) {
            createAgencies();
        }

        if (null == actions) {
            createActions();
        }

        if (null == appropriations) {
            createAppns();
        }

        if (statusMessage != null) {
            if (statusMessage.equals(previousMsg)) {
                msg = ManageBulkRuleExemption.WELCOME_MSG;
            } else {
                msg = statusMessage;
                previousMsg = msg;
            }
        } else {
            msg = ManageBulkRuleExemption.WELCOME_MSG;
        }

    }

    public void onSuccess(String context) {
        previousMsg = ManageBulkRuleExemption.RESET_MSG;

        if (null == action || null == agency || null == appropriation) {
            statusMessage = ManageBulkRuleExemption.REQUIRED_FIELDS;
            return;
        }

        String actionCode = getBulkExemptionControlFromName(action).getCode();
        String agencyCode = serviceAgencies.get(agency).getCode();
        String appnCode = getBulkExemptionControlFromName(appropriation).getCode();
        String orgName = serviceAgencies.get(agency).getName();

        if (null == actionCode || null == agencyCode || null == appnCode) {
            statusMessage = "\n" + ManageBulkRuleExemption.REQUIRED_FIELDS;
        } else {

            try {
                if (bulkExempt(actionCode, agencyCode, appnCode)) {
                    appCacheReloadController.markForReload();
                    statusMessage = String.format("\n" + ManageBulkRuleExemption.BULK_EXEMPT_OK, agencyCode, appnCode,
                            actionCode) + statusResult.toString();
                } else {
                    statusMessage = String.format("\n" + ManageBulkRuleExemption.BULK_NO_PROCESS, orgName);
                }
            } catch (Exception e) {
                statusMessage = "\nFailed to process exemptions. exception indicated - " + e.getMessage();
                log.error(e);
            }
        }
        appCacheReloadController.markForReload();
    }

    private void processStatusMsg(String data) {
        if (null == statusResult) {
            statusResult = new StringBuilder();
        }
        statusResult.append("\n" + data);
    }

    private void createAppns(){
        appropriations = new ArrayList<>();
        appropriations.add(BulkExemptionControl.PROC.getName());
        appropriations.add(BulkExemptionControl.RDTE.getName());
    }

    private void createActions(){
        actions = new ArrayList<String>();
        actions.add(BulkExemptionControl.ADD.getName());
        actions.add(BulkExemptionControl.REMOVE.getName());
    }

    private void createAgencies() {
        TreeSet<String> agencySet = new TreeSet<>();
        serviceAgencies = new HashMap<>();

        for (ServiceAgency sa : getAvailableRdteAgencies()) {
            String name = sa.getName();
            agencySet.add(name);
            serviceAgencies.put(name, sa);
        }

        for (ServiceAgency sa : getAvailableProcurementAgencies()) {
            String name = sa.getName();
            agencySet.add(name);
            serviceAgencies.put(name, sa);
        }

        agencies = new ArrayList<String>(agencySet);
        Collections.sort(agencies);
    }

    private List<ManageBulkRuleHelper> makeRDTEBusinessRuleList() {
        setRDTEValidationExemptions();
        RuleRepository ruleRepository = RuleRepositoryFactory.makeRepository();
        List<ManageBulkRuleHelper> rules = new ArrayList<>();

        for (Rule rule : ruleRepository.getRules()) {
            ManageBulkRuleHelper helper = new ManageBulkRuleHelper(rule.getRuleNumber(), rule.getRuleMessage(),
                    rule.getRuleGroup());
            rules.add(helper);
        }

        return rules;
    }

    /**
     * Validation exemption processing method.
     * @param actionCode - String
     * @param agencyCode - String
     * @param appnCode - String
     * @return result - boolean
     * @throws Exception - Exception
     */
    private boolean bulkExempt(String actionCode, String agencyCode, String appnCode) throws Exception {
        boolean result = false;
        msg = "";
        if (appnCode.equals(BulkExemptionControl.RDTE.getCode())) {
            result = processRDTE(actionCode, agencyCode, appnCode);
        } 
        else if (appnCode.equals(BulkExemptionControl.PROC.getCode())) {
            ServiceAgency sa = serviceAgencies.get(agency);
            String rValue = validationService.processP40validationExemption(sa, actionCode, getP40User());
            if (null != rValue && rValue.indexOf(ManageBulkRuleExemption.SUCCESS_COMMIT) > 0) {
                result = true;
                processStatusMsg(rValue);
            }

        } else {

            statusMessage = String.format(ManageBulkRuleExemption.APP_NOT_AVAIL, appnCode);
        }

        return result;
    }

    private void processRDTEValidationExemptions(
            Map<String, mil.dtic.cbes.submissions.ValueObjects.ValidationExemption> noProcessRDTERulesForAgency,
            String actionCode, String agencyCode) {

        for (mil.dtic.cbes.submissions.ValueObjects.ValidationExemption ve : getRDTEValidationExemptions()) {
            if (agencyCode.equals(ve.getOrganization().getCode())) {
                noProcessRDTERulesForAgency.put(ve.getRdteRule(), ve);
            } else {
                continue;
            }
        }
    }

    private BulkExemptionControl getBulkExemptionControlFromName(String name) {

        for (BulkExemptionControl bec : BulkExemptionControl.values()) {
            if (name.equals(bec.getName())) {
                return bec;
            }
        }

        return null;
    }

    private void setRDTEValidationExemptions() {
        ValidationExemptionDAO veDAO = BudgesContext.getValidationExemptionDAO();
        validationRDTEExemptions = veDAO.findAll();
    }

    private List<ValidationExemption> getRDTEValidationExemptions() {
        if (null == validationRDTEExemptions) {
            return new ArrayList<>();
        }
        return validationRDTEExemptions;
    }

    private P40User getP40User(){
        P40User p40User = getCurrentP40User();

        if (p40User != null) {
            return p40User;
        } else {
            BudgetCycleConfig config = CayenneUtils.createDataContext().newObject(BudgetCycleConfig.class);
            return P40User.fetchWithLdapId(config.getObjectContext(), getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
        }
    }
    
    //TODO: should be backend code
    @SuppressWarnings("deprecation")
    private boolean processRDTE(String actionCode, String agencyCode, String appnCode){
        boolean result = false;
        Map<String, mil.dtic.cbes.submissions.ValueObjects.ValidationExemption> noProcessRDTERulesForAgency = new HashMap<>();
        processRDTEValidationExemptions(noProcessRDTERulesForAgency, actionCode, agencyCode);
        ServiceAgency sa = serviceAgencies.get(agency);

        for (ManageBulkRuleHelper br : businessRuleList) {

            ValidationExemption validationExemption = noProcessRDTERulesForAgency.get(br.getRuleNumber());
            String objStatus;
            String status;

            if (null == validationExemption) { // new record
                validationExemption = new ValidationExemption();
                validationExemption.setRdteRule(br.getRuleNumber());
                validationExemption.setCreatedByBudgesUser(getCurrentBudgesUser().getFullName());
                validationExemption.setModifiedByBudgesUser(getCurrentBudgesUser().getFullName());
                validationExemption.setDateCreated(new Date());
                validationExemption.setDateModified(new Date());
                validationExemption.setOrganization(sa);
                if (actionCode.equals(BulkExemptionControl.ADD.getCode())) {
                    validationExemption.setStatus(StatusFlag.ACTIVE);
                    objStatus = ManageBulkRuleExemption.NEW_ACTIVE;
                } else {
                    validationExemption.setStatus(StatusFlag.INACTIVE);
                    objStatus = ManageBulkRuleExemption.NEW_INACTIVE;
                }
            } else { // persisted record

                if (validationExemption.getStatus().isActive()
                        && actionCode.equals(BulkExemptionControl.ADD.getCode())) {
                    continue;
                }

                if (validationExemption.getStatus().isInactive()
                        && actionCode.equals(BulkExemptionControl.REMOVE.getCode())) {
                    continue;
                }

                validationExemption.setDateModified(new Date());
                if (actionCode.equals(BulkExemptionControl.ADD.getCode())) {
                    validationExemption.setStatus(StatusFlag.ACTIVE);
                    objStatus = ManageBulkRuleExemption.UPDATED_ACTIVE;
                } else {
                    validationExemption.setStatus(StatusFlag.INACTIVE);
                    objStatus = ManageBulkRuleExemption.UPDATED_INACTIVE;
                }
            }

            try {
                BudgesContext.getValidationExemptionDAO().saveOrUpdate(validationExemption);
                status = "processed exemption for " + sa.getName() + " on RDTE rule: " + br.getRuleNumber()
                        + " as: " + objStatus;
                processStatusMsg(status);
                log.debug(status);
                result = true;
            } catch (Exception e) {
                status = "failed to process exemption for " + sa.getName() + " on RDTE rule: " + br.getRuleNumber();
                log.error(e.getStackTrace());
            }
        }
        return result;
    }
    
}
