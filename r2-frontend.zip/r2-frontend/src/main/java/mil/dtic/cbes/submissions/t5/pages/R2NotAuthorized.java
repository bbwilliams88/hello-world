package mil.dtic.cbes.submissions.t5.pages;

import java.io.IOException;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CbesLogFactory;

/**
 * Replaces ErrorNotAuthorizedPage
 */
@Import(stylesheet = {"context:/css/R2NotAuthorized.css"})
public class R2NotAuthorized extends T5Base {
    // Logger
    private static final Logger log = CbesLogFactory.getLog(R2NotAuthorized.class);

    // Config service
    @Inject
    private ConfigService config;

    /**
     * @brief When the page is loaded
     */
    public Object onActivate()
    {
        log.error("Activating R2NotAuthorized Page");

        BudgesUser user = getCurrentBudgesUser();

        if (config.getNotRegisteredUrl() == null) return null;

        try
        {
            if (user == null) return new URL(config.getNotRegisteredUrl());
            else if(user.getStatusFlag()!=null && (user.getStatusFlag().isDeleted() || user.getStatusFlag().isInactive())) return new URL(config.getNotRegisteredUrl());
        }
        catch (IOException error)
        {
            log.error("Failed to redirect: " + error);
        }

        return null;
    }
}
