package mil.dtic.cbes.submissions.t5.etc;

import java.io.File;

import org.apache.tapestry5.ValidationException;


/**
 * Pass this to SavedUpload to validate an uploaded file
 */
public abstract class SavedUploadValidator
{
  public void validateFilename(String filename) throws ValidationException {}
  public void validateFile(File f, String originalName) throws ValidationException {}
}