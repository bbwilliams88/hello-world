package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgencyApp;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

@Import( stack   = { CbesT5SharedModule.DATATABLESUPDATED },
library = { "context:/js/administerLookupSubAcct.js" })
public class AdministerLookupSubAcct extends T5Base{

	  @Inject
	  private ServiceAgencyDAO serviceAgencyDAO;	
	  
	  @Property(read = true)
	  private ServiceAgency serviceAgencyEntry;
	  
	  @Property(read = true)
	  private ServiceAgencyApp serviceAgencyAppEntry;
	  
	  @Property
	  private int rowIndex;
	  
	  @Property
	  private List<ServiceAgency> serviceAgencyList;
	  
	  @Property
	  private List<ServiceAgencyApp> serviceAgencyAppList;
	  
	  @Property
	  private Set<ServiceAgency> serviceAgencySet;
	  
	  @Property
	  private ServiceAgency serviceAgency;
	  
	  @Property
	  private ServiceAgencyApp serviceAgencyApp;
	  
	  @Inject
	  private JavaScriptSupport jsSupport;
	  
	  @Inject
	  private ComponentResources resources;
	  
	  @Property
	  @Persist
	  private List<ServiceAgency> orgRows;
	  
	  List<String> vals;
	  
	  public void onActivate(String agency,String apn, String ba) {
		  
			  serviceAgency = serviceAgencyDAO.findByCode(agency);
			  
			  
			  serviceAgencyAppList = new ArrayList<ServiceAgencyApp>();

			    	for(int x = 0; x < serviceAgency.getAppropriations().size(); x = x + 1) {
			    		
			    	   if(serviceAgency.getAppropriations().get(x).getCode().equals(apn)){
			    		   
			    		   for(int b = 0; b < serviceAgency.getAppropriations().get(x).getProcurementBudgetActivities().size(); b = b + 1) {
			    		   
			    			   if(serviceAgency.getAppropriations().get(x).getProcurementBudgetActivities().get(b).equals(ba)){
			    				   
//			    				   for(int y = 0; y < serviceAgency.getAppropriations().get(x).getProcurementBudgetActivities().get(b).get   get.size(); y = y + 1) {   
			    				   
//			    					   serviceAgency.getAppropriations().get(0).getProcurementBudgetActivities().get(0).		   
//			    			   }	   
			    		  }
			    	   }
			    	   		
			
			    		   
			    		 /*  for(int b = 0; b < serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().size(); b = b + 1) {
				    	   serviceAgencyApp = new ServiceAgencyApp(); 
				    	   serviceAgencyApp.setAgencyCode(serviceAgencyList.get(x).getCode().toString());
					       serviceAgencyApp.setAppnCode(serviceAgencyList.get(x).getAppropriations().get(y).getCode().toString());
					       serviceAgencyApp.setBudgetActivityNumber(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getNumber().toString());
					       serviceAgencyApp.setBudgetActivityTitle(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getTitle().toString());
					       serviceAgencyApp.setStatus(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getStatus());
					       serviceAgencyAppList.add(x, serviceAgencyApp);
				    	 } */ 	
			    	   		
			    	   }
			    	}  
	  }
	  
	  void afterRender()
	  {
		  jsSupport.addScript("setupDatatable();");
	  }
	  
	  Object onActionFromCancel()
	  {
	    return AdministerLookupAcctTab.class;
	  }
	  
}
