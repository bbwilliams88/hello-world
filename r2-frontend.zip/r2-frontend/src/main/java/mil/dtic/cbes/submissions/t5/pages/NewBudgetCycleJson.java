/*
 * I don't know what goes here. ~Evan Sonderegger
 */
package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;

public class NewBudgetCycleJson extends T5Base
{
  @Inject
  private BudgetCycleDAO bcDAO;
  
  TextStreamResponse onActivate()
  {
    JSONObject responseObject = new JSONObject();
    JSONArray cycles = new JSONArray();
    for (BudgetCycle cycle : bcDAO.getBudgetCycles()) {
      JSONObject cycleObject = new JSONObject();
      cycleObject.put("BudgetYear", cycle.getBudgetYear());
      cycleObject.put("cycle", cycle.getCycle());
      cycleObject.put("label", cycle.getLabel());
      cycleObject.put("value", cycle.getValue());
      JSONArray submissionDates = new JSONArray();
      for (SubmissionDate submDate : cycle.getSubmissionDates()) {
        submissionDates.put(submDate.getValue());
      }
      cycleObject.put("SubmissionDates", submissionDates);
      cycles.put(cycleObject);
    }
    responseObject.put("cycles", cycles);
    return new TextStreamResponse("application/json", responseObject.toString());
  }
}
