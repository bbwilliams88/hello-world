package mil.dtic.cbes.submissions.t5.components;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.tapestry5.upload.services.MultipartDecoder;

import com.itextpdf.text.DocumentException;

import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.jb.DocumentCreationParams;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.delegates.DocumentDelegate;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.xml.XMLToolsUtil;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.InvalidXMLListener;

public class BuildPdfToolTab extends BaseXmlToolTab {

  private static final Logger log = CbesLogFactory.getLog(BuildPdfToolTab.class);

  @Parameter(required = true)
  @Property
  private File workingDirectory;

  @Inject
  private MultipartDecoder decoder;

  @Inject
  private HttpServletRequest request;

  @Inject
  private ComponentResources resources;

  @Inject
  private JavaScriptSupport jsSupport;

  public BuildPdfToolTab() {
    log.debug("xml-to-pdf tooltab starting up");
  }

  public void afterRender() {
    JSONObject links = new JSONObject(
        "uploadR2", resources.createEventLink("UploadR2")+"",
        "uploadJb", resources.createEventLink("UploadJb")+"",
        "downloadFile", resources.createEventLink("DownloadFile")+""
        );
    jsSupport.addScript("buildPDFToolTabInit(%s)",links.toCompactString());
  }

  public JSONObject onUploadR2() {
    JSONObject response = new JSONObject();
    boolean asZip = getFlag("asZip");

    List<XmlDocument> xmls = new ArrayList<XmlDocument>();
    try {
      xmls = XmlUploadProcessor.getXmlDocumentsFromUpload(decoder.getFileUpload("file"), workingDirectory, false);
    } catch(FileUploadException|XmlDocumentException e) {
      log.debug("Couldn't extract XML: ", e);
      return createErrorResponse(response, e.getMessage());
    }

    List<ProgramElement> pes = new ArrayList<ProgramElement>();
    for(XmlDocument x : xmls) {
      R2ExhibitList r2List = x.getR2ExhibitList();
      pes.addAll(r2List.getProgramElements());
    }

    R2ExhibitList allR2s = new R2ExhibitList();
    allR2s.setProgramElements(pes);
    allR2s.setWorkingFolder(workingDirectory);

    DocumentCreationParams docCreationParams = new DocumentCreationParams();
    docCreationParams.setPdfPerExhibit(asZip);

    DocumentDelegate dd = new DocumentDelegate(workingDirectory, InvalidXMLListener.DO_NOTHING, docCreationParams, new DocumentAssemblyOptions());
    String downloadFilePath = "";

    if(asZip) {
      try {
        downloadFilePath = dd.createPdfPerPeInZip(allR2s);
      } catch(IOException | SQLException | DocumentException e) {
        log.error("Error creating zip of pdfs", e);
        return createErrorResponse(response, "Error creating zip of PDFs");
      }
    } else {
      try {
        downloadFilePath = dd.createSinglePdf(allR2s);
      } catch(IOException | SQLException | DocumentException e) {
        log.error("Error creating single PDF", e);
        return createErrorResponse(response, "Error creating single PDF");
      }
    }
    if(downloadFilePath.length() > 0) {
      File downloadFile = new File(downloadFilePath);
      response.put("success", true);
      response.put("downloadUrl", downloadFile.getName());
      return response;
    }
    return createErrorResponse(response, "Error creating PDF(s)");
  }

  public JSONObject onUploadJb() {
    JSONObject response = new JSONObject();
    boolean isMjb = getFlag("isMjb");
    DocumentAssemblyOptions docOptions = new DocumentAssemblyOptions();
    docOptions.setHonorSubordinateDocumentAssemblyOptions(!getFlag("overrideXml"));
    docOptions.setForceEvenPages(getFlag("xmlToPdfForceEvenPages"));
    docOptions.setWatermark(request.getParameter("xmlToPdfWatermark"));
    docOptions.setTrackingHeader(request.getParameter("xmlToPdfTrackingHeader"));
    docOptions.setGenerateR1Summary(getFlag("r1summary"));
    docOptions.setGenerateR1(getFlag("r1"));
    docOptions.setGenerateR1c(getFlag("r1c"));
    docOptions.setGenerateR1d(getFlag("r1d"));
    docOptions.setGenerateProgramElementTocByBA(getFlag("peTocBA"));
    docOptions.setGenerateProgramElementTocByTitle(getFlag("peTocTitle"));
    docOptions.setGenerateP1(getFlag("p1"));
    docOptions.setGenerateLineItemTocByBA(getFlag("liTocBA"));
    docOptions.setGenerateLineItemTocByTitle(getFlag("liTocTitle"));
    log.debug("use options from xml: " + docOptions.isHonorSubordinateDocumentAssemblyOptions() + ",  force even: " + docOptions.isForceEvenPages()
    + ", watermark: " + docOptions.getWatermark() + ", tracking header: " + docOptions.getTrackingHeader());
    List<XmlDocument> xmls = new ArrayList<XmlDocument>();
    try {
      xmls = XmlUploadProcessor.getXmlDocumentsFromUpload(decoder.getFileUpload("file"), workingDirectory, true);
    } catch(FileUploadException|XmlDocumentException e) {
      log.debug("Couldn't extract XML: ", e);
      return createErrorResponse(response, e.getMessage());
    }
    if(xmls.size() != 1) {
      return createErrorResponse(response, "Please upload a single XML file");
    }
    XmlDocument jbXml = xmls.get(0);
    String downloadFilePath = "";
    if(isMjb) {
      if(!XMLToolsUtil.isMJB(jbXml.getDocument())) {
        return createErrorResponse(response, "XML source must be a master justification book");
      }
      MasterJustificationBook mjb = jbXml.getMjb();
      if(!docOptions.isHonorSubordinateDocumentAssemblyOptions()) {
        mjb.setDocAssemblyOptions(docOptions);
      }
      DocumentDelegate dd = new DocumentDelegate(workingDirectory, InvalidXMLListener.DO_NOTHING, new DocumentCreationParams(), mjb.getDocAssemblyOptions());
      try {
        downloadFilePath = dd.createSinglePdf(mjb);
      } catch(IOException | SQLException | DocumentException e) {
        log.error("Error creating MJB PDF", e);
        return createErrorResponse(response, "Error creating MJB PDF");
      }
    } else {
      if(!XMLToolsUtil.isJB(jbXml.getDocument())) {
        return createErrorResponse(response, "XML source must be a justification book");
      }
      JustificationBook jb = jbXml.getJb();
      if(!docOptions.isHonorSubordinateDocumentAssemblyOptions()) {
        jb.setDocAssemblyOptions(docOptions);
      }
      DocumentDelegate dd = new DocumentDelegate(workingDirectory, InvalidXMLListener.DO_NOTHING, new DocumentCreationParams(), jb.getDocAssemblyOptions());
      try {
        downloadFilePath = dd.createSinglePdf(jb);
      } catch(IOException | SQLException | DocumentException e) {
        log.error("Error creating JB PDF", e);
        return createErrorResponse(response, "Error creating JB PDF");
      }
    }
    if(downloadFilePath.length() > 0) {
      File downloadFile = new File(downloadFilePath);
      response.put("success", true);
      response.put("downloadUrl", downloadFile.getName());
      return response;
    }
    return createErrorResponse(response, "Error creating PDF(s)");
  }

  private boolean getFlag(String flag) {
    return request.getParameterMap() != null && request.getParameterMap().containsKey(flag)
        && "true".equals(request.getParameter(flag));
  }

  public StreamResponse onDownloadFile(String fileName) {
    if(fileName != null) {
      try {
        String ext = FilenameUtils.getExtension(fileName);
        InputStream is = new FileInputStream(workingDirectory + "/" + fileName);
        return getStream(is, fileName, ext);
      } catch(FileNotFoundException e) {
        log.error("File " + fileName + " does not exist", e);
      }
    }
    return null;
  }

  private JSONObject createErrorResponse(JSONObject response, String msg) {
    response.put("success", false);
    response.put("errorMessage", msg);
    return response;
  }
}