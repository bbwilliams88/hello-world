/*
 * $Id: SubmittingGridSortLink.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.Asset;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Path;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.beaneditor.PropertyModel;
import org.apache.tapestry5.grid.ColumnSort;
import org.apache.tapestry5.grid.GridConstants;
import org.apache.tapestry5.grid.GridSortModel;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.utility.CbesLogFactory;
/**
 * <p>Replacement sort header for Tapestry Grid. Hooks into Grid's built-in sort.
 * By using linksubmit instead of actionlink, any changes in editable fields get
 * sent to the server instead of being discarded.
 * <p>Example:
 * <p><pre>
 * {@code
 * <grid .... include="serviceAgencyName" >
 * <p:serviceAgencyNameHeader>
 *   <t:SubmittingSortHeader header="Agency" sortModel="grid.sortModel" columnModel="grid.dataModel.get('serviceAgencyName')" />
 * </p:serviceAgencyNameHeader>
 * </grid>
 * }
 * </pre>
 */
public class SubmittingGridSortLink
{
  private static final Logger log = CbesLogFactory.getLog(SubmittingGridSortLink.class);

  @SuppressWarnings("unused")
  @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
  @Property
  private String header;

  @Parameter(required = true)
  @Property
  private GridSortModel sortModel;

  @Parameter(required = true)
  @Property
  private PropertyModel columnModel;

  @Inject
  private Messages messages;

  @Inject
  @Path("classpath:/org/apache/tapestry5/corelib/components/sort-asc.png")
  private Asset ascendingAsset;

  @Inject
  @Path("classpath:/org/apache/tapestry5/corelib/components/sort-desc.png")
  private Asset descendingAsset;

  @Inject
  @Path("classpath:/org/apache/tapestry5/corelib/components/sortable.png")
  private Asset sortableAsset;

  void onSelectedFromSubmittingSortHeader()
  {
    log.debug("onSelectedFromSubmittingSortHeader");
      sortModel.updateSort(columnModel.getId());
  }
  

  public String getSortLinkClass()
  {
    switch (getSortForColumn())
    {
      case ASCENDING:
        return GridConstants.SORT_ASCENDING_CLASS;
      case DESCENDING:
        return GridConstants.SORT_DESCENDING_CLASS;
      default:
        return null;
    }
  }
  
  public Asset getIcon()
  {
    switch (getSortForColumn())
    {
      case ASCENDING:
        return ascendingAsset;
      case DESCENDING:
        return descendingAsset;
      default:
        return sortableAsset;
    }
  }
  
  public String getIconLabel()
  {
    switch (getSortForColumn())
    {
      case ASCENDING:
        return messages.get("ascending");
      case DESCENDING:
        return messages.get("descending");
      default:
        return messages.get("sortable");
    }
  }

  private ColumnSort getSortForColumn()
  {
    return sortModel.getColumnSort(columnModel.getId());
  }
}
