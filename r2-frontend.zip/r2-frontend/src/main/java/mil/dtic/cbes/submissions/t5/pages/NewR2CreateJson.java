package mil.dtic.cbes.submissions.t5.pages;

import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.FormatFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2aExhibit;
import mil.dtic.cbes.submissions.ValueObjects.R3Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R4aExhibit;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleDetail;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubProjectSchedule;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgesUserAndProgramElementLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgetActivityDAO;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class NewR2CreateJson extends NewR2Endpoint
{
  private static final Logger log = CbesLogFactory.getLog(NewR2CreateJson.class);

  @Inject
  private BudgetCycleDAO bcDAO;
  @Inject
  private BudgetActivityDAO baDAO;
  @Inject
  private ServiceAgencyDAO saDao;
  @Inject
  private ProgramElementDAO peDao;
  @Inject
  private HttpServletRequest request;

  private static final String APPTYPE = "application/json";

  TextStreamResponse onActivate()
  {
      if (StringUtils.equals(request.getParameter("r2-csrf"), getCurrentBudgesUser().getCsrfToken()) == false) {
        log.debug("csrf token mismatch: provided " + request.getParameter("r2-csrf") 
        + ", expected " + getCurrentBudgesUser().getCsrfToken());
          return new TextStreamResponse("application/json", createErrorResponse("Attempted to create PE without proper authorization.").toString());
      }
    JSONObject responseObject = new JSONObject();
    if(!getUserCredentials().createPeAllowed()) {
      return new TextStreamResponse("application/json", createErrorResponse("This user does not have permission to create new program elements.").toString());
    }

    String requestNumber = request.getParameter("r2-number");
    String requestCycle = request.getParameter("r2-cycle");
    log.debug("requestCycle: " + requestCycle);
    BudgetCycle thisCycle = bcDAO.findByValue(requestCycle);

    List<ProgramElement> existingPEs = peDao.findByProgramElementNumber(requestNumber);

    if (!existingPEs.isEmpty()) {
      for (ProgramElement current: existingPEs) {
        String currentBC = current.getBudgetCycle();
        Integer currentBY = current.getBudgetYear();
        if (currentBC.equals(thisCycle.getCycle()) && (thisCycle.getBudgetYear().intValue() == currentBY.intValue())) {
          return new TextStreamResponse(APPTYPE, createErrorResponse("Program Element Number " + requestNumber + " already exists in " + requestCycle + ".").toString());
        }
      }
    }
    
    Date nowDate = new Date();

    String requestAgency = request.getParameter("r2-agency");
    String requestActivity = request.getParameter("r2-activity");
    
    String requestTitle = request.getParameter("r2-title");
    String requestR1Num = request.getParameter("r2-r1num");
    String requestR2Long = request.getParameter("r2-r2long");
    String requestTag = request.getParameter("r2-tag");
    String requestTestPe = request.getParameter("r2-testpe");

    SubmissionDate thisSubmissionDate = thisCycle.getSubmissionDates().get(thisCycle.getSubmissionDates().size() - 1);
    ServiceAgency thisAgency = saDao.findByCode(requestAgency);
    BudgetActivity thisActivity = baDAO.findById(Integer.parseInt(requestActivity));
    boolean isTest = "true".equals(requestTestPe);

    ProgramElement newPe = new ProgramElement(requestNumber, thisCycle, thisActivity, false, thisSubmissionDate, true);

    newPe.setServiceAgency(thisAgency);
    newPe.setTitle(requestTitle);
    newPe.setR1LineNumber(requestR1Num);
    log.debug("requestR2Long: " + requestR2Long);
    if ("true".equals(requestR2Long)) {
      newPe.setFormat(FormatFlag.R2Long);
      newPe.setMissionDescription("");
      log.debug("setting pe as r2 long");
    } else {
      newPe.setFormat(null);
      log.debug("PE is not an r2 long");
    }
    newPe.setUserDefinedTag(requestTag);

    log.debug("requestTestPE: " + requestTestPe);
    newPe.setTest(isTest);
    newPe.setCreatedByBudgesUser(getCurrentBudgesUser());
    newPe.setDateCreated(nowDate);
    newPe.setOverallModifiedByUser(getCurrentBudgesUser());
    newPe.setOverallDateModified(nowDate);

    Project starterProject = new Project(newPe, false, 10);
    starterProject.setNumber("0");
    starterProject.setTitle(StringUtils.EMPTY);
    starterProject.setDateCreated(nowDate);
    starterProject.setCreatedByBudgesUser(getCurrentBudgesUser());
    starterProject.setDateModified(nowDate);
    starterProject.setModifiedByBudgesUser(getCurrentBudgesUser());
    R2aExhibit starterR2a = new R2aExhibit(starterProject);
    starterR2a.setDateCreated(nowDate);
    starterR2a.setCreatedByBudgesUser(getCurrentBudgesUser());
    starterR2a.setDateModified(nowDate);
    starterR2a.setModifiedByBudgesUser(getCurrentBudgesUser());
    starterProject.setR2aExhibit(starterR2a);
    if (Arrays.asList(Constants.VALID_R3_to_R5_BA_NUMS).contains(thisActivity.getNumber())) {
      R3Exhibit starterR3 = new R3Exhibit();
      starterR3.setDateCreated(nowDate);
      starterR3.setCreatedByBudgesUser(getCurrentBudgesUser());
      starterR3.setDateModified(nowDate);
      starterR3.setModifiedByBudgesUser(getCurrentBudgesUser());
      starterProject.setR3Exhibit(starterR3);
      R4aExhibit starterR4a = new R4aExhibit();
      SubProjectSchedule starterSchedule = new SubProjectSchedule(starterProject, StringUtils.EMPTY, 10);
      ScheduleDetail starterDetail = new ScheduleDetail(starterSchedule, StringUtils.EMPTY, 4, 2016, 3, 2017, 10);
      LinkedHashSet<ScheduleDetail> starterDetailSet = new LinkedHashSet<ScheduleDetail>(1);
      starterDetailSet.add(starterDetail);
      starterSchedule.setScheduleDetails(starterDetailSet);
      LinkedHashSet<SubProjectSchedule> starterScheduleSet = new LinkedHashSet<SubProjectSchedule>(1);
      starterScheduleSet.add(starterSchedule);
      starterR4a.setSubProjectSchedules(starterScheduleSet);
      starterR4a.setDateCreated(nowDate);
      starterR4a.setCreatedByBudgesUser(getCurrentBudgesUser());
      starterR4a.setDateModified(nowDate);
      starterR4a.setModifiedByBudgesUser(getCurrentBudgesUser());
      starterProject.setR4aExhibit(starterR4a);
    }
    LinkedHashSet<Project> starterProjectSet = new LinkedHashSet<Project>(1);
    starterProjectSet.add(starterProject);
    newPe.setProjects(starterProjectSet);

    //to set the permissions correctly
    BudgesUserAndProgramElementLinkDAO userPeDAO = BudgesContext.getBudgesUserAndProgramElementLinkDAO();
    BudgesUserAndProgramElementLink userPe = BudgesUserAndProgramElementLink.createTransient(getCurrentBudgesUser(), newPe);
    userPe.setView(true);
    userPe.setEdit(true);

      peDao.save(newPe);
      userPeDAO.saveOrUpdate(userPe);
      responseObject.put("id", newPe.getId());
      responseObject = createSuccessResponse(responseObject, "Program element created successfully.");

    return new TextStreamResponse("application/json", responseObject.toString());
  }
}
