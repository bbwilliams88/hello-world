package mil.dtic.cbes.submissions.t5.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.Appropriation;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;

@Secured({"ROLE_R2AppMgr"})
public class EditOrg extends T5Base
{
	
  @Inject
  private ServiceAgencyDAO serviceAgencyDAO;

//  @Property
//  private List<ServiceAgency> serviceAgencyList; 
  
  @Property
  @Persist
  private ServiceAgency serviceAgency;
  
  @Property
  @Persist
  private Appropriation appropriation;
  
  
  @Property
  @Persist
  private String agencyCd;
  
  @Property
  @Persist
  private String agencyNm;
    
  @Persist
  @Property
  private String agencyStatus;
  
  @Property
  @Persist
  private String appnCd;
  
  @Property
  @Persist
  private String appnNm;

  @Property
  @Persist
  private String appropriationStatus;
  
  
  @SuppressWarnings("deprecation")
  @Property
  private StatusFlag statusFlag;  

  public void onActivate(String agency, String appnCode) {
      
      serviceAgency = serviceAgencyDAO.findByCode(agency);
      agencyStatus = serviceAgency.getStatusFlag().toString();
      
      List<Appropriation> appropriations = serviceAgency.getAppropriations();
     
      for (Appropriation appn : appropriations){
          if (appn.getCode().equals(appnCode)){
              this.appropriation = appn;
              appnCd = appn.getCode();
              appnNm = appn.getName();
              appn.getCodePlusName();
              
              Set<ServiceAgency> setOfAgencies = appn.getServiceAgencies();
              
              for(Object o : setOfAgencies){
                  ServiceAgency sa = (ServiceAgency)o;
                  
              }
              
          }
      }
  }

  Object onSuccessFromOrgForm() {
	  
      if(agencyStatus.equals("I")){
          serviceAgency.setStatusFlag(statusFlag.I);	 
      }
      else{
          serviceAgency.setStatusFlag(statusFlag.A);
      }
      
      serviceAgencyDAO.update(serviceAgency); 

      return AdministerLookupOrg.class;
      
  }	
  
  Object onActionFromCancel() {
      return AdministerLookupOrg.class;
  }
  

}