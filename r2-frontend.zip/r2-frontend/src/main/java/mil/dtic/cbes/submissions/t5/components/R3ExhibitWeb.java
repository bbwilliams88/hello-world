package mil.dtic.cbes.submissions.t5.components;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

//import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryGroup;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryItem;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.utility.BigDecimalUtil;

public class R3ExhibitWeb
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  @Property
  private CostCategoryGroup ccGroup;
  @Property
  private CostCategoryItem ccItem;
  @Property
  private String ccgName;

  public int addIntegers(int intOne, int intTwo)
  {
    return intOne + intTwo;
  }
  
  public String formatContractInfo(CostCategoryItem cci)
  {
    String result = StringUtils.EMPTY;
    
    if (cci != null)
    {
      if (cci.getContractMethod() != null)
      {
        result = cci.getContractMethod().getName();
        
        if (cci.getContractType() != null){
          result += "/" + cci.getContractType().getName();
        }  
      } 
      
      else if (cci.getFundingVehicle() != null)
      {
        result = cci.getFundingVehicle().getName();
      }
    }
    
    return result;
  }
  
  public boolean isContracted(CostCategoryItem cci) {
      boolean isContracted = false;
      
      if (cci != null) {
          isContracted = cci.getContractMethod() != null;
      }
    
      return isContracted;
  }
  
  public String yearDashMonth(Date inputDate) {
    if (inputDate != null) {
      SimpleDateFormat format1 = new SimpleDateFormat("MM-yyyy");
      
      return format1.format(inputDate);
    } 

      return StringUtils.EMPTY;
  }

  public BigDecimal ccGroupSubtotal(CostCategoryGroup group, String budgetCycle)
  {
    BigDecimal subtotal = new BigDecimal(0);
    
    if(budgetCycle != null && !StringUtils.isEmpty(budgetCycle)){
        switch(budgetCycle){
            case "TotalPys":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingTotalPys());
                }
                
                break;
            case "Py":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingPy());
                }
                
                break;
            case "Cy":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingCy());
                }
                
                break;
            case "By1Base":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingBy1Base());
                }
                
                break;
            case "BY1OOC":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingBy1Ooc());
                }
                
                break;
            case "By1":
                for (CostCategoryItem item : group.getCostCategoryItems())
                {
                  subtotal = BigDecimalUtil.add(subtotal, item.getFundingBy1());
                }
                
                break;
            default:
                break;
        }
    }
    
    return subtotal;
  }
  
  public BigDecimal ccGroupsTotal(Set<CostCategoryGroup> groups, String budgetCycle){
    BigDecimal total = new BigDecimal(0);
    
    if (groups != null) {
      for (CostCategoryGroup group : groups) {
        total = BigDecimalUtil.add(total, ccGroupSubtotal(group, budgetCycle));
      }
    }
    
    return total;
  }
  
  public boolean setHasElements(Set<Object> theSet)
  {
      return theSet.size() > 0;
  }
  
  public String dashIfNullOrZero(BigDecimal aValue) {
    if (aValue == null) {
      return "-";
    } 
    
    else if (BigDecimalUtil.equals(aValue, new BigDecimal("0.000"))){
      return "-";
    }
    
    else {
      return aValue.toString();
    }
  }
  
  public Set<String> allCcgNames() {
    Set<String> theNames = new LinkedHashSet<String>();
    theNames.add("Product Development");
    theNames.add("Support");
    theNames.add("Test and Evaluation");
    theNames.add("Management Services");
    
    return theNames;
  }
  
  public boolean sameCcgName(String theName, CostCategoryGroup ccg) {
      boolean isSameCcgName = false;
      
      if(theName != null && ccg != null){
          isSameCcgName  = theName.equals(ccg.getCostCategoryGroupName().getName());
      }
      
      return isSameCcgName;
  }
  public boolean ccgExistsForName(String theName, Set<CostCategoryGroup> ccgs) {
    if (ccgs != null) {
      for (CostCategoryGroup ccg : ccgs) {
        if (theName.equals(ccg.getCostCategoryGroupName().getName())) {
          return true;
        }
      }
    }
    return false;
  }
}