package mil.dtic.cbes.submissions.t5.models;

/**
 * Stores information about a page used for wizard navigation.
 */
public class PageEntry
{
    private final Class<?> pageClass;
    private final String   pageName;
    private final String   pageTitle;


    public PageEntry(Class<?> pageClass, String pageName, String pageTitle)
    {
        this.pageClass    = pageClass;
        this.pageName     = pageName;
        this.pageTitle    = pageTitle;
    }

    public Class<?> getPageClass()
    {
        return this.pageClass;
    }

    public String getPageName()
    {
        return this.pageName;
    }

    public String getPageTitle()
    {
        return this.pageTitle;
    }
}
