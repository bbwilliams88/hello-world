package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.sourcepath.SourcePath;
import mil.dtic.cbes.enums.Roles;

public class NewUserProfile extends T5Base implements SourcePath{
    private static final Logger log = CbesLogFactory.getLog(NewUserProfile.class);

    @Property
    private BudgesUser cbesUser;

    @Property
    private ServiceAgency agency;
    
    @Property
    private boolean r2AppMgr;
    
    @Property
    private boolean notR2AppMgr;
    
    private String sourceUrl;
    private String returnLabel;
    private boolean hasPath;
    private String sourcePath;

    private static final String NOT_APPLICABLE = "Not Applicable";
    private static final String YES = "Yes";
    private static final String NO = "No";

    @Log
    void onActivate() {
        this.cbesUser = getCurrentBudgesUser();
        this.r2AppMgr = isAppMgr(cbesUser);
        this.notR2AppMgr = isNotR2AppMgr(cbesUser);
    }
    
    void onActivate(String path) {
        this.setSourcePath(path);
        BudgesContext.getSourcePathManager().createSource(this);
    }

    public String peCreationAllowedString() {
        if (showPeCreationControls()) {
            return getYesNoFromBoolean(cbesUser.isCreatePeAllowed());
        } else {
            return NewUserProfile.NOT_APPLICABLE;
        }
    }

    public String liCreationAllowedString() {
        if (showLiCreationControls()) {
            return getYesNoFromBoolean(cbesUser.isCreateLiAllowed());
        } else {
            return NewUserProfile.NOT_APPLICABLE;
        }
    }

    public String getReadableUserRole() {
        if (cbesUser.getRole().equals(LdapDAO.GROUP_NONE)) {
            return LdapDAO.GROUP_NONE;
        }
        else {
            return Roles.valueOf(cbesUser.getRole()).getName();
        }
    }

    private String getYesNoFromBoolean(boolean b) {
        return b ? NewUserProfile.YES : NewUserProfile.NO;
    }

    private boolean showLiCreationControls() {
        if (isSiteAdmin(cbesUser) || isAppMgr(cbesUser) || isAnalyst(cbesUser) || isOMBAnalyst(cbesUser)) {
            return false;
        }
        return true;
    }

    private boolean showPeCreationControls() {
        if (isSiteAdmin(cbesUser) || isAppMgr(cbesUser) || isAnalyst(cbesUser) || isOMBAnalyst(cbesUser)) {
            return false;
        }
        return true;
    }
    
    private boolean isNotR2AppMgr(BudgesUser user) {
        if (isAppMgr(user)) {
            return false;
        }
        return true;
    }

    private boolean isAppMgr(BudgesUser user) {
        return user.getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN);
    }

    private boolean isSiteAdmin(BudgesUser user) {
        return user.getRole().equals(LdapDAO.GROUP_R2_SITEADMIN);
    }
    
    private boolean isAnalyst(BudgesUser user) {
    	return user.getRole().equals(LdapDAO.GROUP_R2_ANALYST);
    }
    
    private boolean isOMBAnalyst(BudgesUser user) {
    	return user.getRole().equals(LdapDAO.GROUP_OMB_ANALYST);
    }
    
    //-- SourcePath interface getter/setter methods
    
    @Override
    public String getSourcePath() {
        return sourcePath;
    }
    
    @Override
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    @Override
    public String getSourceUrl(){
        return sourceUrl;
    }

    @Override
    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }
    
    @Override
    public void setReturnLabel(String returnLabel) {
        this.returnLabel = returnLabel;
    }

    @Override
    public String getReturnLabel() {
        return returnLabel;
    }

    @Override
    public boolean isHasPath() {
        return hasPath;
    }

    @Override
    public void setHasPath(boolean hasPath) {
        this.hasPath = hasPath;
    }

}
