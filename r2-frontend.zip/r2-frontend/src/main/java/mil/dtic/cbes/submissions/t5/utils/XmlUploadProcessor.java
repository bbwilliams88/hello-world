package mil.dtic.cbes.submissions.t5.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.encryption.BadSecurityHandlerException;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.springframework.util.CollectionUtils;

import mil.dtic.cbes.exceptions.InvalidFileTypeException;
import mil.dtic.cbes.service.UnzipService;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.UploadPdfUtils;

public class XmlUploadProcessor {
  private static final String ZIP_EXTENSION = "zip";

  private static final String PDF_EXTENSION = "pdf";

  private static final String XML_EXTENSION = "xml";
  
  private static final String FILE_EXTENSION_SEPARATOR = ".";

  private static final String TMP_FILE_PREFIX = "mxt";
  
  private static final Logger log = CbesLogFactory.getLog(XmlUploadProcessor.class);
  
  public static List<XmlDocument> getXmlDocumentsFromUpload(UploadedFile upFile, File workingDirectory, boolean createTemps) throws FileUploadException, XmlDocumentException {
    log.info("Extracting xml from uploaded file...");
    
    List<XmlDocument> docs = new ArrayList<XmlDocument>();
    if(upFile == null) {
      throw new FileUploadException("No file was uploaded.");
    }
    String fileName = FileUtil.getFileNameWithoutPath(upFile.getFileName());
    File scannedFile = null;
    try {
      scannedFile = scanAndCopy(upFile, workingDirectory);
      
      if(FileUtil.isPdfFile(fileName)) {
        XmlDocument fromPdf = extractFromPdf(scannedFile, workingDirectory, fileName, createTemps);
        if(fromPdf != null)
          docs.add(fromPdf);
        else
          throw new FileUploadException("No XML attachment found in PDF file.");
      }
      else if(FileUtil.isXmlFile(fileName)) {
        docs.add(new XmlDocument(scannedFile, fileName, workingDirectory));
      }
      else if(FileUtil.isZipFile(fileName)) {
        BudgesFile bFile = new BudgesFile(scannedFile.getName(), scannedFile);
        UnzipService unzipService = new UnzipService(scannedFile.getParentFile());
        unzipService.unzipOriginalNames(bFile);
        
        List<XmlDocument> fromZip = xmlsFromZip(unzipService, bFile);
        if(fromZip != null && fromZip.size() > 0) {
          docs.addAll(fromZip);
        }
        
        for (BudgesFile f : unzipService.getUnzippedPdfFileList()) {
          XmlDocument fromPdf = extractFromPdf(f.getFile(), workingDirectory, fileName, createTemps);
          if(fromPdf != null) {
            docs.add(fromPdf);
          }
        }
      }
      else {
        throw new FileUploadException("File extension must be XML, PDF, or ZIP.");
      }
      
    } catch(VirusScanException e) {
      throw new FileUploadException("There was a problem scanning the uploaded file for viruses.", e);
    } catch(InvalidFileTypeException e) {
      throw new FileUploadException("Invalid file extension in zip: " + e.getMessage(), e);
    } catch(IOException e) {
      throw new FileUploadException("Unable to read uploaded file.", e);
    }
    return docs;
  }
  
  public static List<BudgesFile> getXmlFilesFromUpload(UploadedFile upFile, File workingDirectory) throws FileUploadException {
    List<BudgesFile> files = new ArrayList<BudgesFile>();
    
    if(upFile == null) {
      throw new FileUploadException("No file was uploaded.");
    }
    File scannedFile = null;
    try {
      scannedFile = scanAndCopy(upFile, workingDirectory);
      String workingFileName = scannedFile.getName().toLowerCase();
      String originalFileName = upFile.getFileName();
      
      if(FileUtil.isPdfFile(workingFileName)) {
        files.add(new BudgesFile(originalFileName, extractPdfXmlToTempFile(scannedFile, workingDirectory)));
      } 
      else if(FileUtil.isXmlFile(workingFileName)) {
        files.add(new BudgesFile(originalFileName, scannedFile));
      }
      else if(FileUtil.isZipFile(workingFileName)) {
        files.addAll(extractXmlFilesFromZip(scannedFile, workingDirectory));
      }
      else {
        throw new FileUploadException("File extension must be XML, PDF, or ZIP.");
      }
    
    } catch(VirusScanException e) {
      throw new FileUploadException("There was a problem scanning the uploaded file for viruses.", e);
    } catch(InvalidFileTypeException e) {
      throw new FileUploadException("Invalid file extension in zip: " + e.getMessage(), e);
    } catch(IOException e) {
      throw new FileUploadException("Unable to read uploaded file.", e);
    }
    return files;
  }
  
  private static XmlDocument extractFromPdf(File pdfFile, File workingDirectory, String originalFileName, boolean createTemps) throws XmlDocumentException, FileUploadException {
    try {
    if(createTemps) {
      // full extraction with attachments
      List<File> zzzFiles = UploadPdfUtils.extractHighestOrderZzz(pdfFile);
      BudgesFile zzz;
      if(!CollectionUtils.isEmpty(zzzFiles)) {
        zzz = new BudgesFile(zzzFiles.get(0).getName(), zzzFiles.get(0));
      } else {
        return null;
      }
      UnzipService us = new UnzipService(workingDirectory);
      us.unzipOriginalNames(zzz);
      List<XmlDocument> xmls = xmlsFromZip(us, zzz);
      if(!CollectionUtils.isEmpty(xmls)) {
        return xmls.get(0);
      }
    } else {
      // just grab the XML input stream
      List<InputStream> pdfXmlStreams = null;
      pdfXmlStreams = UploadPdfUtils.extractHighestOrderXmlFromPdfFile(pdfFile);
      if(!CollectionUtils.isEmpty(pdfXmlStreams)) {
        return new XmlDocument(pdfXmlStreams.get(0), originalFileName, workingDirectory);
      }
    }
    } catch(VirusScanException e) {
      throw new FileUploadException("There was a problem scanning the uploaded file for viruses.", e);
    } catch(BadSecurityHandlerException|CryptographyException e) {
      throw new FileUploadException("Unable to read encrypted PDF file.", e);
    } catch(IOException e) {
      // UploadPdfUtils throws IOException if there are no XML attachments
      // log and return null in case it's a non-exhibit PDF attachment in a zip
      log.warn("Couldn't extract any XML attachments for PDF " + pdfFile.getName() + ": " + e.getMessage());
    }
    return null;
  }
  
  private static List<XmlDocument> xmlsFromZip(UnzipService unzipService, BudgesFile zipFile) throws XmlDocumentException {
    List<XmlDocument> xmls = new ArrayList<XmlDocument>();
    for (BudgesFile f : unzipService.getUnzippedXmlFileList()) {
      if(f.getOriginalName() != null && !f.getOriginalName().startsWith("xmlresponse")) {
        XmlDocument xd = new XmlDocument(f.getFile(), f.getOriginalName(), unzipService.getWorkingFolder());
        xd.setAttachmentResolutionMap(unzipService.getUnzipMap(zipFile));
        xmls.add(xd);
      }
    }
    return xmls;
  }
  
  private static File extractPdfXmlToTempFile(File pdfFile, File workingDirectory) throws FileUploadException, VirusScanException {
    List<InputStream> pdfXmlAttachments = null;
    File temp = null;
    try {
      pdfXmlAttachments = UploadPdfUtils.extractHighestOrderXmlFromPdfFile(pdfFile);
    } catch(BadSecurityHandlerException|CryptographyException e) {
      throw new FileUploadException("Unable to read encrypted PDF file.", e);
    } catch(IOException e) {
      log.warn("Couldn't extract any XML attachments for PDF " + pdfFile.getName() + ": " + e.getMessage());
    }
    if(!CollectionUtils.isEmpty(pdfXmlAttachments) && pdfXmlAttachments.get(0) != null) {
      try {
        temp = File.createTempFile(TMP_FILE_PREFIX, FILE_EXTENSION_SEPARATOR + XML_EXTENSION, workingDirectory);
        FileUtils.copyInputStreamToFile(pdfXmlAttachments.get(0), temp);
      } catch(IOException e) {
        throw new FileUploadException("Application error while extracting PDF attachments.", e);
      }
    }
    return temp;
  }
  
  private static List<BudgesFile> extractXmlFilesFromZip(File zipFile, File workingDirectory) throws FileUploadException, VirusScanException {
    List<BudgesFile> unzippedFiles = new ArrayList<BudgesFile>();
    BudgesFile bFile = new BudgesFile(zipFile.getName(), zipFile);
    UnzipService unzipService = new UnzipService(zipFile.getParentFile());
    unzipService.unzipOriginalNames(bFile);
    
    for (BudgesFile f : unzipService.getUnzippedXmlFileList()) {
      if(f.getOriginalName() != null && !f.getOriginalName().startsWith("xmlresponse")) {
        unzippedFiles.add(f);
      }
    }
    for (BudgesFile f : unzipService.getUnzippedPdfFileList()) {
      unzippedFiles.add(f);
    }
    return unzippedFiles;
  }

  private static File createFileInSandbox(String filename) throws IOException {
    ConfigService config = BudgesContext.getConfigService();
    File sandboxDir = new File(config.getVscanSandboxFolder());
    String sfx = FilenameUtils.getExtension(filename);
    if (sfx.length()>0) sfx = "." + sfx;
    else sfx = null; //.tmp
    return File.createTempFile("___", sfx, sandboxDir);
  }
  
  public static File scanAndCopy(UploadedFile upFile, File workingDir) throws IOException, VirusScanException{
    File sandboxedFile = createFileInSandbox(upFile.getFileName());
    upFile.write(sandboxedFile);
    return R2Storage.scanAndPutInUpload(workingDir, sandboxedFile.getName(), sandboxedFile, upFile.getFileName());
  }
}