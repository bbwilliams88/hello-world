package mil.dtic.cbes.submissions.t5.components;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.RequestGlobals;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Environment;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.cbes.t5shared.services.UserAgent;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;


@Import(
  stack      = { CbesT5SharedModule.JQUERYSTACK, CbesT5SharedModule.BOOTSTRAPSTACK },
  library    = { "context:/js/confirm.js", "classpath:${cb.assetpath}/js/log.js", "context:/js/t5.js" },
  stylesheet = { "context:/css/r2.css","context:/css/style.css" }
       )
public class NewLayout extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(NewLayout.class);
  @Inject
  private RequestGlobals requestGlobals;
  @Inject
  private HttpServletRequest servletRequest;
  @Inject
  private ConfigService config;
  @Inject
  private UserAgent userAgent;

  @Parameter(required=true, defaultPrefix = BindingConstants.LITERAL)
  @Property
  private String title;

  @Parameter(value="false", required=false)
  @Property
  private boolean ignoreContentContainer;//newR2Manague uses its own content container

  @Parameter @Property
  private BudgesDownloadableObject download;

  @Property @Persist
  private BudgesDownloadableObject cachedDownload; //cache the dbdo to get around crappy IE security settings

  @Parameter @Property
  private Object redirect; //do not set this to java.lang.Object. Any subclass will do.

  @Property
  private boolean jquery;

  @Property
  private boolean treeview;


  public String getHostInfo()
  {
    try {
      return InetAddress.getLocalHost().toString();
    } catch (UnknownHostException e) {
      log.debug("getHostInfo: Unknown host");
      return "[UNKNOWN]";
    }
  }

  public String getSessionId()
  {
    if (getRequestGlobals()!=null && getRequestGlobals().getHTTPServletRequest()!=null && getRequestGlobals().getHTTPServletRequest().getSession()!=null && getRequestGlobals().getHTTPServletRequest().getSession().getId()!=null)
    {
      return getRequestGlobals().getHTTPServletRequest().getSession().getId();
    }
    return "[NO SESSION]";
  }

  public String getCurrentTime()
  {
    DateFormat formatter = new SimpleDateFormat(Constants.HEADER_DATETIME_FORMAT);
    return formatter.format(new Date());
  }

  /**
   * Getter for the Maintenance Message string.
   * @return
   */
  public String getMaintenanceMessage(){
    return config.getMaintenanceMessage();
  }

  public boolean showLinks()
  {
    return getUserCredentials()!=null && getUserCredentials().getUserInfo()!=null && getUserCredentials().getUserInfo().isLoggedIn();
  }

  public boolean isMaintenanceMode()
  {
    return Util.isMaintenanceMode();
  }

  public Environment getEnv()
  {
    return config.getEnv();
  }

  public boolean isProd()
  {
    return config.isProd();
  }

  public boolean isClassified()
  {
    return Util.isClassified();
  }


  /**
   * @return The WebTrends DCSID based upon the environment.
   */
  public String getDcsid()
  {
//      R2 Development Data Source dcsid: dcsu9icwm10000wkhc0bxk0hr_4b3v
//      R2 Staging Data Source dcsid: dcssyyhp500000w4xh2ncq0hr_6p1m
//      R2 Production Data Source dcsid: dcsytxh0o1000008yn7nds0hr_8u4t

      if (config.isProd())
          return "dcsytxh0o1000008yn7nds0hr_8u4t";
      else if (config.isStaging())
          return "dcssyyhp500000w4xh2ncq0hr_6p1m";
      else
          return "dcsu9icwm10000wkhc0bxk0hr_4b3v";
  }

  public String getDomain()
  {
    return config.getHostName();
  }

  public String getBrowserClass(){
	  if(userAgent.isIE7()){
		  return "ie ie7";
	  } else if(userAgent.isIE8()) {
		  return "ie ie8";
	  } else if (userAgent.isIE9()){
		  return "ie ie9";
	  } else if (userAgent.isIE10()){
		  return "ie ie10";
	  } else if (userAgent.isIE11()){
		  return "ie ie11";
	  } else if (userAgent.isIE()) {
		  return "ie";
	  } else if (userAgent.isChrome()){
		  return "chrome";
	  } else if (userAgent.isBadIE()){
		  return "bad";
	  } else if (userAgent.isFirefox()){
		  return "firefox";
	  } else if (userAgent.isSafari()){
		  return "safari";
	  } else if (userAgent.isEdge()){
		  return "edge";
	  } else {
		  return "other";
	  }
  }

    public boolean isUnsupportedBrowser()
    {
        return userAgent.isBadIE();
    }
}
