package mil.dtic.cbes.submissions.t5.pages;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.CongressionalAddDetail;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryGroup;
import mil.dtic.cbes.submissions.ValueObjects.CostCategoryItem;
import mil.dtic.cbes.submissions.ValueObjects.JointFunding;
import mil.dtic.cbes.submissions.ValueObjects.MajorPerformer;
import mil.dtic.cbes.submissions.ValueObjects.OtherAdjustmentDetail;
import mil.dtic.cbes.submissions.ValueObjects.OtherProgramFundingSummary;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleDetail;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.ValueObjects.SubProjectSchedule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class PeJson extends NewR2Endpoint
{
  private static final Logger log = CbesLogFactory.getLog(PeJson.class);
  @Inject
  private HttpServletRequest request;

  /**
   * Endpoint to get program element data.
   *
   * @param peNumber
   * The program element's database ID
   *
   * @return
   * A JSON representation of the program element
   * { ProgramElement: {
   *     ProgramElementNumber: xxxxx,
   *     ProgramElementTitle: xxxxx,
   *     R1LineNumber: xxxxx,
   *     MdapCode: xxxxx,
   *     etc },
   *   errorMessage: xxxxx
   * }
   */

  @Log
  TextStreamResponse onActivate(String peNumber)
  {
    try {
      ProgramElement pe = getRequestedPe(peNumber);
      JSONObject response = jsonFromProgramElement(pe, getCurrentBudgesUser().getCsrfToken());
      response.put("showTest", getUserCredentials().checkPrivilege(Privilege.SHOW_TEST_PE));
      response.put("userRole", getCurrentBudgesUser().getRole());
      response.put("showUnlock", (getUserCredentials().isLockedByMe(pe) || (pe.getLockedBy() != null && getUserCredentials().editPeUsersAllowed(pe))));
      response.put("isFrozen", (pe.getEntirePeLockedBy() != null));
      if(pe.getEntirePeLockedBy() != null){
    	  response.put("frozenBy", (pe.getEntirePeLockedBy().getFullName()));
      }
      response.put("showProjectButtons", (
    		  !(pe.getEntirePeLockedBy() != null && pe.getEntirePeLockedBy().getId().equals(getCurrentBudgesUser().getId()))
    		  || !getCurrentBudgesUser().getRole().equals("R2User")));
      return new TextStreamResponse("application/json", response.toString());
    } catch(ApiRequestException e) {
      return new TextStreamResponse("application/json", createErrorResponse(e.getMessage()).toString());
    }
  }

  public static String jsonSafe(String input) {
    return input == null ? "" : input;
  }

  public static String jsonSafe(BigDecimal input) {
    return input == null ? "" :  input.toString();
  }

  public static String jsonSafe(Integer input) {
    return input == null ? "" : input.toString();
  }

  public static String jsonSafe(Date input) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
    return input == null ? "" : sdf.format(input);
  }

//  private static BigDecimal getBigDecimalViaInvocation(Object obj, String methodName) {
//    Invocation invocation = new Invocation(obj, methodName);
//    BigDecimal bd = invocation.fire()
//  }



  public static JSONObject jsonFromProgramElement(ProgramElement pe, String csrfToken) {
    JSONObject responseObject = new JSONObject();
    JSONObject peJson = new JSONObject();
    peJson.put("id", pe.getId());
    peJson.put("@csrfToken", csrfToken);
    peJson.put("@monetaryUnit", "Millions");
    peJson.put("@isR2Long", pe.getFormat() != null && pe.getFormat().isR2Long());
    peJson.put("@userDefinedTag", jsonSafe(pe.getUserDefinedTag()));
    peJson.put("@trackingNote", jsonSafe(pe.getTrackingNote()));
    peJson.put("@isTest", pe.isTest());
    peJson.put("@classification", Util.isClassified() ? "CLASSIFIED" : "UNCLASSIFIED");
    peJson.put("ProgramElementNumber", jsonSafe(pe.getNumber()));
    peJson.put("ProgramElementTitle", jsonSafe(pe.getTitle()));
    peJson.put("R1LineNumber", jsonSafe(pe.getR1LineNumber()));
    peJson.put("MdapCode", jsonSafe(pe.getMdapCode()));
    peJson.put("PriorYearsDelta", jsonSafe(pe.getPysDelta()));
    peJson.put("BudgetYear", jsonSafe(pe.getBudgetYear()));
    peJson.put("BudgetCycle", jsonSafe(pe.getBudgetCycle()));
    peJson.put("SubmissionDate", jsonSafe(pe.getSubmissionDate()));
    peJson.put("ServiceAgencyName", jsonSafe(pe.getServiceAgency().getName()));
    peJson.put("AppropriationCode", jsonSafe(pe.getBudgetActivity().getAppropriation().getCode()));
    peJson.put("AppropriationName", jsonSafe(pe.getBudgetActivity().getAppropriation().getName()));
    peJson.put("BudgetActivityNumber", pe.getBudgetActivity().getNumber() != null ? pe.getBudgetActivity().getNumber().toString() : "");
    peJson.put("BudgetActivityTitle", jsonSafe(pe.getBudgetActivity().getTitle()));
    peJson.put("ProgramElementFunding", fundingObject(pe));
    peJson.put("ProgramElementNote", jsonSafe(pe.getNotes()));
    peJson.put("ProgramElementMissionDescription", jsonSafe(pe.getMissionDescription()));
    peJson.put("ChangeSummary", changeSummary(pe));
    peJson.put("ProjectList", projectList(pe));
    responseObject.put("ProgramElement", peJson);
    return responseObject;
  }

  private static JSONObject fundingObject(ProgramElement p) {
    JSONObject obj = new JSONObject();
    obj.put("AllPriorYears", jsonSafe(p.getFundingAllPys()));
    obj.put("PriorYear", jsonSafe(p.getFundingPy()));
    obj.put("CurrentYear", jsonSafe(p.getFundingCy()));
    obj.put("BudgetYearOneBase", jsonSafe(p.getFundingBy1Base()));
    obj.put("BudgetYearOneOOC", jsonSafe(p.getFundingBy1Ooc()));
    obj.put("BudgetYearOne", jsonSafe(p.getFundingBy1()));
    obj.put("BudgetYearTwo", jsonSafe(p.getFundingBy2()));
    obj.put("BudgetYearThree", jsonSafe(p.getFundingBy3()));
    obj.put("BudgetYearFour", jsonSafe(p.getFundingBy4()));
    obj.put("BudgetYearFive", jsonSafe(p.getFundingBy5()));
    obj.put("CostToComplete", jsonSafe(p.getFundingCompCost()));
    obj.put("TotalCost", jsonSafe(p.getFundingTotalCost()));
    return obj;
  }

  private static JSONObject fundingObject(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("AllPriorYears", jsonSafe(p.getFundingAllPys()));
    obj.put("PriorYear", jsonSafe(p.getFundingPy()));
    obj.put("CurrentYear", jsonSafe(p.getFundingCy()));
    obj.put("BudgetYearOneBase", jsonSafe(p.getFundingBy1Base()));
    obj.put("BudgetYearOneOOC", jsonSafe(p.getFundingBy1Ooc()));
    obj.put("BudgetYearOne", jsonSafe(p.getFundingBy1()));
    obj.put("BudgetYearTwo", jsonSafe(p.getFundingBy2()));
    obj.put("BudgetYearThree", jsonSafe(p.getFundingBy3()));
    obj.put("BudgetYearFour", jsonSafe(p.getFundingBy4()));
    obj.put("BudgetYearFive", jsonSafe(p.getFundingBy5()));
    obj.put("CostToComplete", jsonSafe(p.getFundingCompCost()));
    obj.put("TotalCost", jsonSafe(p.getFundingTotalCost()));
    return obj;
  }

  private static JSONObject changeSummary(ProgramElement pe) {
    JSONObject obj = new JSONObject();

    JSONObject prevBudget = new JSONObject();
    prevBudget.put("PriorYear", jsonSafe(pe.getPreviousPresidentBudgetPy()));
    prevBudget.put("CurrentYear", jsonSafe(pe.getPreviousPresidentBudgetCy()));
    prevBudget.put("BudgetYearOneBase", jsonSafe(pe.getPreviousPresidentBudgetBy1Base()));
    prevBudget.put("BudgetYearOneOOC", jsonSafe(pe.getPreviousPresidentBudgetBy1Ooc()));
    prevBudget.put("BudgetYearOne", jsonSafe(pe.getPreviousPresidentBudgetBy1()));
    obj.put("PreviousPresidentBudget", prevBudget);

    JSONObject currentBudget = new JSONObject();
    currentBudget.put("PriorYear", jsonSafe(pe.getCurrentPresidentBudgetPy()));
    currentBudget.put("CurrentYear", jsonSafe(pe.getCurrentPresidentBudgetCy()));
    currentBudget.put("BudgetYearOneBase", jsonSafe(pe.getCurrentPresidentBudgetBy1Base()));
    currentBudget.put("BudgetYearOneOOC", jsonSafe(pe.getCurrentPresidentBudgetBy1Ooc()));
    currentBudget.put("BudgetYearOne", jsonSafe(pe.getCurrentPresidentBudgetBy1()));
    obj.put("CurrentPresidentBudget", currentBudget);

    JSONObject totalAdjustments = new JSONObject();
    totalAdjustments.put("PriorYear", jsonSafe(pe.getTotalAdjustmentsPy()));
    totalAdjustments.put("CurrentYear", jsonSafe(pe.getTotalAdjustmentsCy()));
    totalAdjustments.put("BudgetYearOneBase", jsonSafe(pe.getTotalAdjustmentsBy1Base()));
    totalAdjustments.put("BudgetYearOneOOC", jsonSafe(pe.getTotalAdjustmentsBy1Ooc()));
    totalAdjustments.put("BudgetYearOne", jsonSafe(pe.getTotalAdjustmentsBy1()));
    obj.put("TotalAdjustments", totalAdjustments);

    JSONObject adjDetails = new JSONObject();

    JSONObject congGenReds = new JSONObject();
    congGenReds.put("PriorYear", jsonSafe(pe.getCongressionalGeneralReductionsPy()));
    congGenReds.put("CurrentYear", jsonSafe(pe.getCongressionalGeneralReductionsCy()));
    adjDetails.put("CongressionalGeneralReductions", congGenReds);

    JSONObject congDirReds = new JSONObject();
    congDirReds.put("PriorYear", jsonSafe(pe.getCongressionalDirectedReductionsPy()));
    congDirReds.put("CurrentYear", jsonSafe(pe.getCongressionalDirectedReductionsCy()));
    adjDetails.put("CongressionalDirectedReductions", congDirReds);

    JSONObject congRescs = new JSONObject();
    congRescs.put("PriorYear", jsonSafe(pe.getCongressionalRescissionsPy()));
    congRescs.put("CurrentYear", jsonSafe(pe.getCongressionalRescissionsCy()));
    adjDetails.put("CongressionalRescissions", congRescs);

    JSONObject congAdds = new JSONObject();
    congAdds.put("PriorYear", jsonSafe(pe.getCongressionalAddsPy()));
    congAdds.put("CurrentYear", jsonSafe(pe.getCongressionalAddsCy()));
    adjDetails.put("CongressionalAdds", congAdds);

    JSONObject congDirXfers = new JSONObject();
    congDirXfers.put("PriorYear", jsonSafe(pe.getCongressionalDirectedXfersPy()));
    congDirXfers.put("CurrentYear", jsonSafe(pe.getCongressionalDirectedXfersCy()));
    adjDetails.put("CongressionalDirectedTransfers", congDirXfers);

    JSONObject reprogs = new JSONObject();
    reprogs.put("PriorYear", jsonSafe(pe.getReprogrammingPy()));
    reprogs.put("CurrentYear", jsonSafe(pe.getReprogrammingCy()));
    adjDetails.put("Reprogrammings", reprogs);

    JSONObject sbirXfers = new JSONObject();
    sbirXfers.put("PriorYear", jsonSafe(pe.getSbirSttrXferPy()));
    sbirXfers.put("CurrentYear", jsonSafe(pe.getSbirSttrXferCy()));
    adjDetails.put("SBIRSTTRTransfer", sbirXfers);

    JSONObject otherAddList = new JSONObject();
    JSONArray otherDetailArray = new JSONArray();
    for (OtherAdjustmentDetail otherDetail : Util.getSortedByDisplayOrder(pe.getOtherAdjustmentDetails())) {
      JSONObject detail = new JSONObject();
      detail.put("id", otherDetail.getId());
      detail.put("Title", jsonSafe(otherDetail.getTitle()));
      JSONObject detailFunding = new JSONObject();
      detailFunding.put("PriorYear", jsonSafe(otherDetail.getFundingPy()));
      detailFunding.put("CurrentYear", jsonSafe(otherDetail.getFundingCy()));
      detailFunding.put("BudgetYearOneBase", jsonSafe(otherDetail.getFundingBy1Base()));
      detailFunding.put("BudgetYearOneOOC", jsonSafe(otherDetail.getFundingBy1Ooc()));
      detailFunding.put("BudgetYearOne", jsonSafe(otherDetail.getFundingBy1()));
      detail.put("Funding", detailFunding);
      otherDetailArray.put(detail);
    }
    otherAddList.put("OtherAdjustmentDetail", otherDetailArray);
    adjDetails.put("OtherAdjustmentDetailList", otherAddList);
    obj.put("AdjustmentDetails", adjDetails);
    obj.put("SummaryExplanation", jsonSafe(pe.getChangeSummaryExplanation()));
    return obj;
  }
  private static JSONObject projectList(ProgramElement pe) {
    JSONObject obj = new JSONObject();
    JSONArray projArray = new JSONArray();
    for (Project proj : Util.getSortedByDisplayOrder(pe.getProjects())) {
      JSONObject projObj = new JSONObject();
      projObj.put("id", proj.getId());
      projObj.put("ProjectNumber", jsonSafe(proj.getNumber()));
      projObj.put("ProjectTitle", jsonSafe(proj.getTitle()));
      projObj.put("SpecialProject", jsonSafe(proj.getSpecialProject()));
      projObj.put("MdapCode", jsonSafe(proj.getMdapCode()));
      projObj.put("PriorYearsDelta", jsonSafe(proj.getPysDelta()));
      projObj.put("ProjectFunding", fundingObject(proj));
      projObj.put("R2aExhibit", r2aObject(proj));
      if (proj.hasR3Exhibit_xml()) {
        projObj.put("R3Exhibit", r3Object(proj));
      }
      if (proj.hasR4Exhibit_xml()) {
        projObj.put("R4Exhibit", r4Object(proj));
      }
      if (proj.hasR4aExhibit_xml()) {
        projObj.put("R4aExhibit", r4aObject(proj));
      }
      if (proj.hasR5Exhibit_xml()) {
        projObj.put("R5Exhibit", r5Object(proj));
      }
      projArray.put(projObj);
    }
    obj.put("Project", projArray);
    return obj;
  }
  private static JSONObject r2aObject(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("ProjectArticles", projectArticles(p));
    obj.put("ProjectNote", jsonSafe(p.getR2aExhibit().getNotes()));
    obj.put("ProjectMissionDescription", jsonSafe(p.getR2aExhibit().getMissionDescription()));
    obj.put("CongressionalAddDetailList", congAddDetailList(p));
    obj.put("AccomplishmentPlannedProgramList", accPlannedProgramList(p));
    obj.put("JointFundingList", jointFundingList(p));
    obj.put("OtherProgramFundingSummaryList", otherProgramFundingList(p));
    obj.put("OtherProgramFundingSummaryRemarks", jsonSafe(p.getR2aExhibit().getOtherProgramFundingSummaryRemarks()));
    obj.put("AcquisitionStrategy", jsonSafe(p.getR2aExhibit().getAcquisitionStrategy()));
    obj.put("MajorPerformers", majorPerformers(p));
    return obj;
  }
  private static JSONObject r3Object(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("Remarks", jsonSafe(p.getR3Exhibit().getR3Remarks()));
    obj.put("CostCategoryGroupList", costCategoryGroupList(p));
    return obj;
  }
  private static JSONObject r4Object(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray schedProfileArray = new JSONArray();
    for (ScheduleProfile prof : Util.getSortedByDisplayOrder(p.getR4Exhibit().getScheduleProfiles())) {
      JSONObject schedProfileObj = new JSONObject();
      schedProfileObj.put("id", prof.getId());
      schedProfileObj.put("ImageFileName", jsonSafe(prof.getImageFileName()));
      schedProfileObj.put("Notes", jsonSafe(prof.getNotes()));
      schedProfileArray.put(schedProfileObj);
    }
    obj.put("ScheduleProfile", schedProfileArray);
    obj.put("ScheduleProfileNote", jsonSafe(p.getR4Exhibit().getR4Notes()));
    return obj;
  }
  private static JSONObject r4aObject(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("ScheduleDetailNote", jsonSafe(p.getR4aExhibit().getR4aNotes()));
    obj.put("SubProjectScheduleList", subProjectScheduleList(p));
    return obj;
  }
  private static JSONObject r5Object(Project p) {
    JSONObject obj = new JSONObject();
    JSONObject termLiability = new JSONObject();
    JSONObject r5Cost = new JSONObject();
    r5Cost.put("AllPriorYears", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingAllPys()));
    r5Cost.put("PriorYear", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingPy()));
    r5Cost.put("CurrentYear", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingCy()));
    r5Cost.put("BudgetYearOne", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingBy1()));
    r5Cost.put("BudgetYearTwo", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingBy2()));
    r5Cost.put("BudgetYearThree", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingBy3()));
    r5Cost.put("BudgetYearFour", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingBy4()));
    r5Cost.put("BudgetYearFive", jsonSafe(p.getR5Exhibit().getTerminationLiability().getFundingBy5()));
    termLiability.put("Cost", r5Cost);
    termLiability.put("Remarks", jsonSafe(p.getR5Exhibit().getTerminationLiability().getRemarks()));
    obj.put("TerminationLiability", termLiability);
    return obj;
  }
  private static JSONObject projectArticles(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("AllPriorYears", jsonSafe(p.getR2aExhibit().getArticleCountAllPys()));
    obj.put("PriorYear", jsonSafe(p.getR2aExhibit().getArticleCountPy()));
    obj.put("CurrentYear", jsonSafe(p.getR2aExhibit().getArticleCountCy()));
    obj.put("BudgetYearOneBase", jsonSafe(p.getR2aExhibit().getArticleCountBy1Base()));
    obj.put("BudgetYearOneOOC", jsonSafe(p.getR2aExhibit().getArticleCountBy1Ooc()));
    obj.put("BudgetYearOne", jsonSafe(p.getR2aExhibit().getArticleCountBy1()));
    obj.put("BudgetYearTwo", jsonSafe(p.getR2aExhibit().getArticleCountBy2()));
    obj.put("BudgetYearThree", jsonSafe(p.getR2aExhibit().getArticleCountBy3()));
    obj.put("BudgetYearFour", jsonSafe(p.getR2aExhibit().getArticleCountBy4()));
    obj.put("BudgetYearFive", jsonSafe(p.getR2aExhibit().getArticleCountBy5()));
    return obj;
  }
  private static JSONObject congAddDetailList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray detailArray = new JSONArray();
    for (CongressionalAddDetail detail : Util.getSortedByDisplayOrder(p.getR2aExhibit().getCongressionalAddDetails())) {
      JSONObject detailObj = new JSONObject();
      detailObj.put("id", detail.getId());
      detailObj.put("Title", jsonSafe(detail.getTitle()));
      JSONObject py = new JSONObject();
      py.put("Funding", jsonSafe(detail.getFundingPy()));
      py.put("Text", jsonSafe(detail.getTextPy()));
      detailObj.put("PriorYear", py);
      JSONObject cy = new JSONObject();
      cy.put("Funding", jsonSafe(detail.getFundingCy()));
      cy.put("Text", jsonSafe(detail.getTextCy()));
      detailObj.put("CurrentYear", cy);
      detailArray.put(detailObj);
    }
    obj.put("CongressionalAddDetail", detailArray);
    return obj;
  }
  private static JSONObject accPlannedProgramList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray appArray = new JSONArray();
    for (AccomplishmentPlannedProgram apProgram : Util.getSortedByDisplayOrder(p.getR2aExhibit().getAccomplishmentsPlannedPrograms())) {
      JSONObject appObj = new JSONObject();
      appObj.put("id", apProgram.getId());
      appObj.put("Title", jsonSafe(apProgram.getTitle()));
      appObj.put("Description", jsonSafe(apProgram.getDescription()));
      JSONObject accomplishmentObj = new JSONObject();
      JSONObject py = new JSONObject();
      py.put("Funding", jsonSafe(apProgram.getFundingPy()));
      py.put("Articles", jsonSafe(apProgram.getArticleCountPy()));
      py.put("Text", jsonSafe(apProgram.getTextPy()));
      accomplishmentObj.put("PriorYear", py);
      appObj.put("Accomplishment", accomplishmentObj);
      JSONObject ppObj = new JSONObject();
      JSONObject cy = new JSONObject();
      cy.put("Funding", jsonSafe(apProgram.getFundingCy()));
      cy.put("Articles", jsonSafe(apProgram.getArticleCountCy()));
      cy.put("Text", jsonSafe(apProgram.getTextCy()));
      ppObj.put("CurrentYear", cy);
      JSONObject by1base = new JSONObject();
      by1base.put("Funding", jsonSafe(apProgram.getFundingBy1Base()));
      by1base.put("Articles", jsonSafe(apProgram.getArticleCountBy1Base()));
      by1base.put("Text", jsonSafe(apProgram.getTextBy1Base()));
      ppObj.put("BudgetYearOneBase", by1base);
      JSONObject by1ooc = new JSONObject();
      by1ooc.put("Funding", jsonSafe(apProgram.getFundingBy1Ooc()));
      by1ooc.put("Articles", jsonSafe(apProgram.getArticleCountBy1Ooc()));
      by1ooc.put("Text", jsonSafe(apProgram.getTextBy1Ooc()));
      ppObj.put("BudgetYearOneOOC", by1ooc);
      JSONObject by1 = new JSONObject();
      by1.put("Funding", jsonSafe(apProgram.getFundingBy1()));
      by1.put("Articles", jsonSafe(apProgram.getArticleCountBy1()));
      ppObj.put("BudgetYearOne", by1);
      appObj.put("PlannedProgram", ppObj);
      JSONObject cs = new JSONObject();
      cs.put("Text", jsonSafe(apProgram.getTextChangeSummary()));
      ppObj.put("ChangeSummary", cs);
      appObj.put("PlannedProgram", ppObj);
      appArray.put(appObj);
    }
    obj.put("AccomplishmentPlannedProgram", appArray);
    return obj;
  }
  private static JSONObject jointFundingList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray fundingArray = new JSONArray();
    for (JointFunding jf : Util.getSortedByDisplayOrder(p.getR2aExhibit().getJointFundings())) {
      JSONObject jfObj = new JSONObject();
      jfObj.put("id", jf.getId());
      jfObj.put("Title", jsonSafe(jf.getTitle()));
      JSONObject fundingObj = new JSONObject();
      fundingObj.put("AllPriorYears", jsonSafe(jf.getFundingPys()));
      fundingObj.put("PriorYear", jsonSafe(jf.getFundingPy()));
      fundingObj.put("CurrentYear", jsonSafe(jf.getFundingCy()));
      fundingObj.put("BudgetYearOneBase", jsonSafe(jf.getFundingBy1Base()));
      fundingObj.put("BudgetYearOneOOC", jsonSafe(jf.getFundingBy1Ooc()));
      fundingObj.put("BudgetYearOne", jsonSafe(jf.getFundingBy1()));
      fundingObj.put("CostToComplete", jsonSafe(jf.getFundingCompCost()));
      fundingObj.put("TotalCost", jsonSafe(jf.getFundingTotalCost()));
      fundingObj.put("TargetValue", jsonSafe(jf.getFundingTargetValue()));
      jfObj.put("Funding", fundingObj);
      fundingArray.put(jfObj);
    }
    obj.put("JointFunding", fundingArray);
    return obj;
  }
  private static JSONObject otherProgramFundingList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray opfsArray = new JSONArray();
    for (OtherProgramFundingSummary opfs : Util.getSortedByDisplayOrder(p.getR2aExhibit().getOtherProgramFundingSummaries())) {
      JSONObject opfsObj = new JSONObject();
      opfsObj.put("id", opfs.getId());
      opfsObj.put("LineItem", jsonSafe(opfs.getLineItem()));
      opfsObj.put("Title", jsonSafe(opfs.getLineItemTitle()));
      JSONObject fundingObj = new JSONObject();
      fundingObj.put("PriorYear", jsonSafe(opfs.getFundingPy()));
      fundingObj.put("CurrentYear", jsonSafe(opfs.getFundingCy()));
      fundingObj.put("BudgetYearOneBase", jsonSafe(opfs.getFundingBy1Base()));
      fundingObj.put("BudgetYearOneOOC", jsonSafe(opfs.getFundingBy1Ooc()));
      fundingObj.put("BudgetYearOne", jsonSafe(opfs.getFundingBy1()));
      fundingObj.put("BudgetYearTwo", jsonSafe(opfs.getFundingBy2()));
      fundingObj.put("BudgetYearThree", jsonSafe(opfs.getFundingBy3()));
      fundingObj.put("BudgetYearFour", jsonSafe(opfs.getFundingBy4()));
      fundingObj.put("BudgetYearFive", jsonSafe(opfs.getFundingBy5()));
      fundingObj.put("CostToComplete", jsonSafe(opfs.getFundingCompCost()));
      fundingObj.put("TotalCost", jsonSafe(opfs.getFundingTotalCost()));
      opfsObj.put("Funding", fundingObj);
      opfsArray.put(opfsObj);
    }
    obj.put("OtherProgramFundingSummary", opfsArray);
    return obj;
  }
  private static JSONObject majorPerformers(Project p) {
    JSONObject obj = new JSONObject();
    obj.put("Text", p.getR2aExhibit().getMajorPerformersText());
    JSONObject mpListObj = new JSONObject();
    JSONArray mpArray = new JSONArray();
    for (MajorPerformer mp : Util.getSortedByDisplayOrder(p.getR2aExhibit().getMajorPerformers())) {
      JSONObject mpObj = new JSONObject();
      mpObj.put("id", mp.getId());
      mpObj.put("Name", jsonSafe(mp.getName()));
      mpObj.put("Description", jsonSafe(mp.getDescription()));
      mpObj.put("Location", jsonSafe(mp.getLocation()));
      mpObj.put("AwardDate", jsonSafe(mp.getDateAwarded()));
      mpObj.put("Cost", jsonSafe(mp.getCost()));
      mpArray.put(mpObj);
    }
    mpListObj.put("MajorPerformer", mpArray);
    obj.put("MajorPerformerList", mpListObj);
    return obj;
  }
  private static JSONObject costCategoryGroupList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray ccgArray = new JSONArray();
    for (CostCategoryGroup ccg : Util.getSortedByDisplayOrder(p.getR3Exhibit().getCostCategoryGroups())) {
      JSONObject ccgObj = new JSONObject();
      ccgObj.put("id", ccg.getId());
      ccgObj.put("Name", jsonSafe(ccg.getCostCategoryGroupName().getName()));
      ccgObj.put("Remarks", jsonSafe(ccg.getRemarks()));
      ccgObj.put("CostCategoryItemList", costCategoryItemList(ccg));
      ccgArray.put(ccgObj);
    }
    obj.put("CostCategoryGroup", ccgArray);
    return obj;
  }
  private static JSONObject costCategoryItemList(CostCategoryGroup ccg) {
    JSONObject obj = new JSONObject();
    JSONArray cciArray = new JSONArray();
    for (CostCategoryItem cci : Util.getSortedByDisplayOrder(ccg.getCostCategoryItems())) {
      JSONObject cciObj = new JSONObject();
      cciObj.put("id", cci.getId());
      cciObj.put("Name", jsonSafe(cci.getName()));
      cciObj.put("ContractMethod", cci.getContractMethod() != null ? cci.getContractMethod().getName() : "");
      cciObj.put("ContractType", cci.getContractType() != null ? cci.getContractType().getName() : "");
      cciObj.put("FundingVehicle", cci.getFundingVehicle() != null ? cci.getFundingVehicle().getName() : "");
      cciObj.put("PerformingActivity", jsonSafe(cci.getPerformingActivity()));
      cciObj.put("PerformingActivityLocation", jsonSafe(cci.getPerformingActivityLocation()));
      JSONObject costObj = new JSONObject();
      costObj.put("TotalPreviousYears", jsonSafe(cci.getFundingTotalPys()));
      JSONObject pyObj = new JSONObject();
      pyObj.put("Amount", jsonSafe(cci.getFundingPy()));
      pyObj.put("AwardDate", jsonSafe(cci.getAwardDatePy()));
      costObj.put("PriorYear", pyObj);
      JSONObject cyObj = new JSONObject();
      cyObj.put("Amount", jsonSafe(cci.getFundingCy()));
      cyObj.put("AwardDate", jsonSafe(cci.getAwardDateCy()));
      costObj.put("CurrentYear", cyObj);
      JSONObject by1BaseObj = new JSONObject();
      by1BaseObj.put("Amount", jsonSafe(cci.getFundingBy1Base()));
      by1BaseObj.put("AwardDate", jsonSafe(cci.getAwardDateBy1Base()));
      costObj.put("BudgetYearOneBase", by1BaseObj);
      JSONObject by1OocObj = new JSONObject();
      by1OocObj.put("Amount", jsonSafe(cci.getFundingBy1Ooc()));
      by1OocObj.put("AwardDate", jsonSafe(cci.getAwardDateBy1Ooc()));
      costObj.put("BudgetYearOneOOC", by1OocObj);
      JSONObject by1Obj = new JSONObject();
      by1Obj.put("Amount", jsonSafe(cci.getFundingBy1()));
      costObj.put("BudgetYearOne", by1Obj);
      costObj.put("CostToComplete", jsonSafe(cci.getFundingCompCost()));
      costObj.put("TotalCost", jsonSafe(cci.getFundingTotalCost()));
      costObj.put("TargetValue", jsonSafe(cci.getFundingTargetValue()));
      cciObj.put("Cost", costObj);
      cciArray.put(cciObj);
    }
    obj.put("CostCategoryItem", cciArray);
    return obj;
  }
  private static JSONObject subProjectScheduleList(Project p) {
    JSONObject obj = new JSONObject();
    JSONArray spSchedArray = new JSONArray();
    try
    {
      Util.getSortedByDisplayOrder(p.getR4aExhibit().getSubProjectSchedules());
    }
    catch (NullPointerException npe)
    {
      Util.generateDisplayOrder(p.getR4aExhibit().getSubProjectSchedules());
    }
    for (SubProjectSchedule spSched : Util.getSortedByDisplayOrder(p.getR4aExhibit().getSubProjectSchedules())) {
      JSONObject spSchedObj = new JSONObject();
      spSchedObj.put("id", spSched.getId());
      spSchedObj.put("Title", jsonSafe(spSched.getTitle()));
      spSchedObj.put("ScheduleDetailList", scheduleDetailList(spSched));
      spSchedArray.put(spSchedObj);
    }
    obj.put("SubProjectSchedule", spSchedArray);
    return obj;
  }
  private static JSONObject scheduleDetailList(SubProjectSchedule spSched) {
    JSONObject obj = new JSONObject();
    JSONArray detailArray = new JSONArray();
    for (ScheduleDetail detail : Util.getSortedByDisplayOrder(spSched.getScheduleDetails())) {
      JSONObject detailObj = new JSONObject();
      detailObj.put("id", detail.getId());
      detailObj.put("EventTitle", jsonSafe(detail.getEventTitle()));
      JSONObject schedObj = new JSONObject();
      JSONObject startObj = new JSONObject();
      startObj.put("Quarter", jsonSafe(detail.getStart().getQuarter()));
      startObj.put("Year", jsonSafe(detail.getStart().getYear()));
      schedObj.put("Start", startObj);
      JSONObject endObj = new JSONObject();
      endObj.put("Quarter", jsonSafe(detail.getEnd().getQuarter()));
      endObj.put("Year", jsonSafe(detail.getEnd().getYear()));
      schedObj.put("End", endObj);
      detailObj.put("Schedule", schedObj);
      detailArray.put(detailObj);
    }
    obj.put("ScheduleDetail", detailArray);
    return obj;
  }
}
