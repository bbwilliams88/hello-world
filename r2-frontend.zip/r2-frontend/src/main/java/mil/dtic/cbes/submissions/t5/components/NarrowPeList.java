/*
 * $Id: NarrowPeList.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Cached;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.NarrowPeListBy;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.AgencyEncoder;
import mil.dtic.cbes.submissions.t5.encoders.BudgetCycleEncoder;
import mil.dtic.cbes.submissions.t5.models.BudgetCycleSelectModel;
import mil.dtic.cbes.submissions.t5.models.ServiceAgencySelectModel;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;


public class NarrowPeList extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(NarrowPeList.class);
  
  @SuppressWarnings("unused")
  @Parameter(required=true)
  @Property
  private NarrowPeListBy narrowPeListBy;
  
  public List<BudgetCycle> getAllBudgetCycles()
  {
    return BudgesContext.getBudgetCycleDAO().getBudgetCycles();
  }
  
  public SelectModel getBudgetCycleSelectModel()
  {
    return new BudgetCycleSelectModel(getAllBudgetCycles());
  }
  
  public SelectModel getAgencySelectModel()
  {
    return new ServiceAgencySelectModel(getAvailableRdteAgencies());
  }
  
  @Cached
  public ValueEncoder<BudgetCycle> getBudgetCycleEncoder()
  {
    log.debug("getBudgetCycleEncoder");
    return new BudgetCycleEncoder();
  }
  
  @Cached
  public ValueEncoder<ServiceAgency> getAgencyEncoder()
  {
    log.debug("getAgencyEncoder");
    return new AgencyEncoder(getAvailableRdteAgencies());
  }
  
  public boolean showCreatedBy()
  {
    return true;
  }
}
