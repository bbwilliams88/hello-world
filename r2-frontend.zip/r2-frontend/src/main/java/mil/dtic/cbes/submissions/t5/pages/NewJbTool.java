package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.annotations.Import;

@Import(library = {"context:js/angular.js","context:js/angular-route.js","context:js/newJbTool.js"})
public class NewJbTool {

}
