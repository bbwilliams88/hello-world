package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.Link;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.ajax.AjaxResponseRenderer;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.p40.vo.Role;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.AuditableObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.ValueObjects.UserProgramElementList;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.submissions.t5.models.R2ListFilters;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * Lists/links to R-2 exhibits.
 */
@Import(
  stack   = {CbesT5SharedModule.DATATABLESBUTTONS},
  library = { "context:/js/urlencoder.js",
              "context:/js/trackingPage.js",
              "context:/js/t5.js",
              "context:/js/jquery.cookie.js",
              "context:/js/r2dataTableExhibitIcons.js",
              "context:/js/newR2Manage.js" },
  stylesheet = { "css/jquery-ui.css", "css/jquery-ui-1.8.5.custom.css" })
public class NewR2Manage extends PeListBase
{
  private static final Logger log = CbesLogFactory.getLog(NewR2Manage.class);

  @Property
  private ProgramElementList currentPe;
//  @Property
//  @Persist
//  private List<ProgramElementList> peList;

  @Inject
  private BudgetCycleDAO bcDAO;

  @SessionState
  private R2ListFilters filterState;

  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;

//  @InjectComponent
//  private Zone r2modalCopyZone;

  @Inject
  private Request request;

  @Property
  private Integer peNumber;

  @Inject
  private AjaxResponseRenderer ajaxResponseRenderer;

  @Property
  private BudgetCycle aBudgetCycle;

  @Property
  private ServiceAgency aServiceAgency;


  @Log 
  void onActivate() {
		BudgetCycle currentBudgetCycle = Util.getCurrentBudgetCycle();
  }

  void afterRender()
  {
	  String url = resources.createEventLink("GetPeJson").toString();
	  Link budgetCycleFilterPageLink = resources.createEventLink("BudgetCycleChange");
	  jsSupport.addScript("r2ManagePageInit('%s');", url);
	  jsSupport.addScript("setupBudgetCycleReload('%s');", budgetCycleFilterPageLink);

  }


  @Override
  public String getCreatorName(AuditableObject item)
  {
    if (item instanceof ProgramElementList)
    {
      ProgramElementList pel = (ProgramElementList) item;
      return Util.formatName(pel.getCreatedByLastName(), pel.getCreatedByFirstName(), pel.getCreatedByMiddleInitial(), pel.getCreatedByLdapId());
    }
    return super.getCreatorName(item);
  }


  @Override
  public String getModifierName(AuditableObject item)
  {
    if (item instanceof ProgramElementList)
    {
      ProgramElementList pel = (ProgramElementList) item;
      return Util.formatName(pel.getModifiedByLastName(), pel.getModifiedByFirstName(), pel.getModifiedByMiddleInitial(), pel.getModifiedByLdapId());
    }
    return super.getModifierName(item);
  }


  public boolean isCopyEnabled()
  {
    return getUserCredentials().getPrivs().showCopyPe();
  }

  public boolean isTestEnabled()
  {
	  return getUserCredentials().getPrivs().showTestPeBox();
  }


  public boolean isDeleteEnabled()
  {
	  // CXE-7285 Only AppMgr and SiteAdmins can delete
	  String role = getUserCredentials().getUserInfo().getBudgesUser().getRole();
	  if (role.equals(LdapDAO.GROUP_R2_SITEADMIN) || role.equals(LdapDAO.GROUP_R2_APP_ADMIN)) {
		  return true;
	  }
	  return false;
  }

  public boolean isFreezeEnabled()
  {
	  return getUserCredentials().getUserInfo().checkPrivilege(Privilege.FREEZE_PE);
  }

  public boolean isForceUnFreezeEnabled()
  {
	  return getUserCredentials().getUserInfo().checkPrivilege(Privilege.UNFREEZE_ANY);
  }


  JSONObject onGetPeJson()
  {
	  List<UserProgramElementList> peList = getUserPesBasedOnPermissionsAndFilter();
	  log.debug("Getting pejson:"+peList.size());
    List<String> allowedProps = Lists.newArrayList(new String[]{
      "id",
      "r1LineNumber", "number", "title", "userDefinedTag", "baNum", "numProjects",
      "serviceAgencyCode", "serviceAgencyName", "budgetCycle", "budgetYear",
      "dateCreated", "dateModified",
      "submissionStatus"
    });
    JSONObject rootObj = new JSONObject();
    rootObj.put("recordsTotal", peList.size());
    rootObj.put("recordsFilter", peList.size());
    rootObj.put("draw", "1");
    JSONArray jsonArray = new JSONArray();
    for (UserProgramElementList element : peList)
    {
      JSONObject obj = new JSONObject(element.toJson(allowedProps));
      obj.put("numbercopy", element.getNumber());
      obj.put("formattedDateCreated", formatDatetime(element.getDateCreated()));
      obj.put("formattedDateModified", formatDatetime(element.getDateModified()));
      // Somehow the modifier ldap id was null for one of the records...
      // insert a blank string to fail more gracefully
      String creator = getCreatorName(element) == null ? "" : getCreatorName(element);
      String modifier = getModifierName(element) == null ? "" : getModifierName(element);
      obj.put("creatorDisplayName", creator);
      obj.put("modifierDisplayName", modifier);
      obj.put("copyEnabled", isCopyEnabled());
      obj.put("deleteEnabled", isDeleteEnabled());
      obj.put("r3Exists", element.isR3Exists());
      obj.put("r4Exists", element.isR4Exists());
      obj.put("r4aExists", element.isR4aExists());
      obj.put("r5Exists", element.isR5Exists());
      obj.put("test", element.isTest());
      obj.put("testEnabled", isTestEnabled());
      if (element.getFormat()!=null && element.getFormat().isR2Long())
      {
    	  obj.put("r2Long", true);
      }
      else
      {
    	  obj.put("r2Long", false);
      }
      obj.put("imported", Constants.PE_INITIAL_SOURCE_XML.equals(element.getInitialSource()));
      obj.put("valid", element.getSubmissionStatus().isValid());
      obj.put("allLocked", element.isEntirePeLocked());
      obj.put("anyLocked", element.isAnyProjectLocked());
      obj.put("peLocked", element.isPeOnlyLocked());
      obj.put("errorExists", element.isErrorExists());
      obj.put("warningExists", element.getSubmissionStatus().isInvalid());
      obj.put("freezeEnabled", isFreezeEnabled());
      jsonArray.put(obj);
    }
    rootObj.put("aaData", jsonArray);
//    log.debug(rootObj.toString(false));
    return rootObj;
  }

  void onBudgetCycleChange(String reloadBudgetCycle)
  {
      filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
      if (filterState.getBudgetCycle()==null)
      {
          filterState.setBudgetCycle(new BudgetCycle());
      }
  }

  @Override
  public List<BudgetCycle> getAllBudgetCycles()
  {
    return bcDAO.getBudgetCycles();
  }

  public List<ServiceAgency> getServiceAgencies()
  {
    return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
  }
}
