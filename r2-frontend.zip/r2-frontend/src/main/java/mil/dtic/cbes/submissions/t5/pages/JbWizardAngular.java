package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.vo.JbVolume;
import mil.dtic.cbes.submissions.ValueObjects.Appropriation;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.t5shared.models.UploadExhibitSelectionModel;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.specialcategory.api.service.SpecialCategoryService;

public class JbWizardAngular extends T5Base
{
  @Property
  @Persist
  private File workingDirectory;
  
  @Inject
  private BudgetCycleDAO bcDao;
  
  @Inject
  private ServiceAgencyDAO saDao;
  
  private static final Logger log = CbesLogFactory.getLog(JbWizardAngular.class);
  
  @Inject
  private MultipartDecoder decoder;
  
  @Inject
  private ComponentResources resources;
  
  @Inject
  private JavaScriptSupport jsSupport;
  
  @Inject
  protected SpecialCategoryService specialCategoryService;
  
  private UploadExhibitSelectionModel uploadSelection = new UploadExhibitSelectionModel();
  
  public void onActivate() {
    if(workingDirectory == null) {
      try {
        workingDirectory = createWorkingFolder();
      } catch(IOException e) {
        log.error("Couldn't create working folder for JBook Wizard");
      }
    }
  }
  
  public void afterRender() {
    /* Populate lists of available agencies, jbook volumes, budget cycles, and event links */
    JSONObject info = new JSONObject();
    info.put("agencies", agencyJson());
    info.put("volumes", volumeJson());
    info.put("cycles", cyclesJson());
    info.put("links", linksJson());
    log.debug(info.toString());
    jsSupport.addScript("setInfo(%s);", info.toCompactString());
  }
  
  public JSONObject onUploadExhibit() {
    log.debug("in onUploadExhibit");
    JSONArray exhibitList = new JSONArray();
    JSONArray errorList = new JSONArray();
    JSONObject response = new JSONObject();
    List<XmlDocument> xmlUploads = new ArrayList<XmlDocument>();
    try {
      xmlUploads = XmlUploadProcessor.getXmlDocumentsFromUpload(decoder.getFileUpload("file"), workingDirectory, false);
    } catch(FileUploadException|XmlDocumentException e) {
      errorList.put(e.getMessage());
      response.put("errorMessages", errorList);
      return response;
    }
    for(XmlDocument xd : xmlUploads) {
      for(JSONObject exhibit : uploadSelection.parseFileForNewItemsWithValidation(xd)) {
        if(exhibit.has("warningMessages")) {
          exhibit.put("submissionStatus", "W");
          exhibit.put("valid", false);
        } else {
          exhibit.put("submissionStatus", "V");
          exhibit.put("valid", true);
        }
        exhibitList.put(exhibit);
      }
      xd.closeAllStreams();
    }
    response.put("exhibits", exhibitList);
    if(errorList.length() > 0) {
      response.put("errorMessages",  errorList);
    }
    return response;
  }
  
  public JSONObject onUploadAttachment() {
    JSONObject response = new JSONObject();
    
    return response;
  }
  
  private JSONObject agencyJson() {
    
    List<ServiceAgency> allAgencies = getUserCredentials().getUserInfo().getAllAvailableAgencies();
    List<String> agencyProps = Lists.newArrayList(new String[]{
        "id", "name", "code", "logoFileName"
    });
    List<String> apprProps = Lists.newArrayList(new String[]{
        "id", "name", "code", "codePlusName"
    });
    JSONArray r2AgencyList = new JSONArray();
    JSONArray p40AgencyList = new JSONArray();
    
    for(ServiceAgency sa : allAgencies) {
       //CXE-5873
       boolean isDodService = (sa != null && specialCategoryService.isDodService(sa.getCode()));
       boolean isDodBigAgency = (sa != null && specialCategoryService.isDodService(sa.getCode()));
       
       if(sa.isRDTE()) {
           JSONObject r2saJson = new JSONObject(sa.toJson(agencyProps));
           r2saJson.put("isService", isDodService);
           r2saJson.put("isBigAgency", isDodBigAgency);
        
           JSONArray r2appropriationsJson = new JSONArray();
           for(Appropriation appropriation : saDao.merge(sa).getRDTEAppropriations()) {
               r2appropriationsJson.put(new JSONObject(appropriation.toJson(apprProps)));
           }
           r2saJson.put("appropriations", r2appropriationsJson);
           r2AgencyList.put(r2saJson);
       }
       if(sa.isProcurement()) {
           JSONObject p40saJson = new JSONObject(sa.toJson(agencyProps));
           p40saJson.put("isService", isDodService);
           p40saJson.put("isBigAgency", isDodBigAgency);
        
           JSONArray p40appropriationsJson= new JSONArray();
           for(Appropriation appropriation : saDao.merge(sa).getProcurementAppropriations()) {
               p40appropriationsJson.put(new JSONObject(appropriation.toJson(apprProps)));
           }
           p40saJson.put("appropriations", p40appropriationsJson);
           p40AgencyList.put(p40saJson);
       }
    }
    JSONObject agencies = new JSONObject();
    agencies.put("r2", r2AgencyList);
    agencies.put("p40", p40AgencyList);
    return agencies;
  }
  
  private JSONObject volumeJson() {
    List<JbVolume> jbVolumes = JbVolume.fetchAll(CayenneUtils.createDataContext());
    JSONArray r2ServiceVols = new JSONArray();
    JSONArray p40ServiceVols = new JSONArray();
    JSONArray r2AgencyVols = new JSONArray();
    JSONArray p40AgencyVols = new JSONArray();
    for(JbVolume jbv : jbVolumes) {
      JSONObject vol = new JSONObject();
      vol.put("code", jbv.getAgencyCode() != null? jbv.getAgencyCode() : "");
      vol.put("description", jbv.getBookDescription() != null? jbv.getBookDescription() : "");
      vol.put("num", jbv.getBookGroup() != null? jbv.getBookGroup() : "");
      vol.put("tovEntry", jbv.getBookLabelAndNumber() != null? jbv.getBookLabelAndNumber() : "");
      if(jbv.isAgencyVolume()) {
        if(jbv.isP40Volume()) {
          p40AgencyVols.put(vol);
        } else {
          r2AgencyVols.put(vol);
        }
      } else {
        if(jbv.isP40Volume()) {
          p40ServiceVols.put(vol);
        } else {
          r2ServiceVols.put(vol);
        }
      }
    }
    JSONObject volumes = new JSONObject();
    JSONObject allR2Vols = new JSONObject();
    allR2Vols.put("services", r2ServiceVols);
    allR2Vols.put("agencies", r2AgencyVols);
    volumes.put("r2", allR2Vols);
    JSONObject allP40Vols = new JSONObject();
    allP40Vols.put("services", p40ServiceVols);
    allP40Vols.put("agencies", p40AgencyVols);
    volumes.put("p40", allP40Vols);
    return volumes;
  }
  
  private JSONArray cyclesJson() {
    List<BudgetCycle> allCycles = bcDao.getBudgetCycles();
    Collections.reverse(allCycles);
    JSONArray cycles = new JSONArray();
    for(BudgetCycle bc : allCycles) {
      JSONObject cycle = new JSONObject();
      cycle.put("value", bc.getValue());
      cycle.put("label", bc.getLabel());
      cycle.put("year", bc.getBudgetYear());
      cycle.put("cycle", bc.getCycle());
      JSONArray submissionDates = new JSONArray();
      for(SubmissionDate sd : bc.getSubmissionDates()) {
        submissionDates.put(sd.getValue());
      }
      cycle.put("submissionDates", submissionDates);
      cycles.put(cycle);
    }
    return cycles;
  }
  
  private JSONObject linksJson() {
    JSONObject response = new JSONObject(
        "uploadExhibit", resources.createEventLink("UploadExhibit")+"",
        "uploadAttachment", resources.createEventLink("UploadAttachment")+""
      );
    return response;
  }

}
