package mil.dtic.cbes.submissions.t5.pages;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.service.P40SelectionService;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.service.R2SelectionService;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class NewExhibitList extends NewR2Endpoint {
  private static final Logger log = CbesLogFactory.getLog(NewExhibitList.class);
  @Inject
  private HttpServletRequest request;
  @Inject
  private BudgetCycleDAO bcDao;
  @Inject
  private R2SelectionService r2SelectionService;
  private P40SelectionService p40SelectionService;
  private BudgesUser currentUser;
  private BudgetCycle bc;
  
  @Log
  TextStreamResponse onActivate(String budgetArea, String budgetCycle, String budgetYear) {
    log.debug("receive request: " + budgetArea + "/" + budgetCycle + "/" + budgetYear);
    if(!"r2".equalsIgnoreCase(budgetArea) && !"p40".equalsIgnoreCase(budgetArea)) {
      log.debug("invalid budget area");
      return new TextStreamResponse("application/json", createErrorResponse("Budget area must be R2 or P40").toString());
    }
    JSONArray exhibitJson;
    currentUser = getUserCredentials().getUserInfo().getBudgesUser();
    bc = bcDao.findByValue(budgetCycle + " " + budgetYear);
    if(bc == null) {
      bc = Util.getCurrentBudgetCycle();
    }
    if("r2".equalsIgnoreCase(budgetArea)) {
      exhibitJson = getProgramElementJson();
    } else {
      exhibitJson = getLineItemJson();
    }
    
    JSONObject rootObj = new JSONObject();
    rootObj.put("recordsTotal", exhibitJson.length());
    rootObj.put("recordsFilter", exhibitJson.length());
    rootObj.put("draw", "1");
    rootObj.put("aaData", exhibitJson);
    log.debug(rootObj.toString(true));
    
    return new TextStreamResponse("application/json", rootObj.toString());
  }
  
  private JSONArray getProgramElementJson() {
    boolean restrictToUserPes = true;
    boolean restrictToUserAgencies = true;
    boolean showTest = false;
    List<String> allowedProps = Lists.newArrayList(new String[]{
        "id",
        "lineNum", "number", "title", "userDefinedTag", "baNum", "numProjects",
        "serviceAgencyCode", "serviceAgencyName", "budgetCycle", "budgetYear",
        "dateCreated", "dateModified",
        "submissionStatus"
      });

    
    log.debug("finding PEs for budget cycle " + bc.getLabel());
    if(getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES)) {
      log.debug("Retrieving all pe's...");
      restrictToUserPes = false;
      restrictToUserAgencies = false;
      showTest = true;
    }
    if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY)) {
      log.debug("Retrieving all pe's for user's agencies...");
      restrictToUserPes = false;
    } else {
      log.debug("Retrieving pe's for user based on user's agencies and pe permissions...");
    }
    JSONArray peListJson = r2SelectionService.getProgramElementsForTableView(bc, showTest, restrictToUserAgencies, restrictToUserPes, currentUser, allowedProps);
    return peListJson;
  }
  
  private JSONArray getLineItemJson() {
    log.debug("getting p40 list");
    if (p40SelectionService==null){
      p40SelectionService = new P40SelectionService();
    }
    String role = currentUser.getRole();
    
    boolean hasViewAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role)){
      hasViewAccess = false;
    }
    boolean hasEditAccess = true;
    if (StringUtils.equals(LdapDAO.GROUP_R2_USER, role) || StringUtils.equals(LdapDAO.GROUP_R2_LOCALSITEADMIN,role)){
      hasEditAccess = false;
    }
    boolean hasShowTestExhibits = getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES);
    
    
    List<ServiceAgency> userAgencies = getUserCredentials().getUserInfo().getAvailableProcurementAgencies();
    log.debug("Number of user agencies: "+userAgencies.size());
    List<String> codes = new LinkedList<String>();
    for (ServiceAgency sa : userAgencies){
      codes.add(sa.getCode());
    }
    
    List<String> allowedProps = Lists.newArrayList(new String[] {
        "id",
        "p1LineItemNumber","lineItemNumber","budgetCycleAndYear","lineItemTitle",
        "agencyCode","agencyName", "appropriationNumber","appropriationTitle",
        "budgetActivityNumber","budgetActivityTitle","bsaNum","budgetSubActivityTitle",
        "creatorDisplayName","dateCreated","dateModified","modifierDisplayName","creatorDisplayName",
        "errors", "identifyingString",
        "test", "valid", "warnings", "xmlValidity", "initialSource",
        "status", "frozen", "warningCount", "errorCount"
      });
    JSONArray jsonArray = p40SelectionService.getLineItemsForTableView(currentUser.getUserLdapId(), hasViewAccess, hasEditAccess, hasShowTestExhibits, bc, codes, allowedProps, false, null);
    log.debug("got results: "+jsonArray.length());
    log.debug(jsonArray.toString(false));
    return jsonArray;
  }
}