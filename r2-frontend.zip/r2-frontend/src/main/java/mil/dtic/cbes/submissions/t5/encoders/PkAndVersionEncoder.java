package mil.dtic.cbes.submissions.t5.encoders;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.ioc.internal.util.CollectionFactory;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.utility.CbesLogFactory;

/**
 * Provides client-side form ids for BudgesBaseValueObjects.
 * Child classes decide how to re-create the BudgesBaseValueObjects (store in session or re-retrieve)
 */
public abstract class PkAndVersionEncoder<T extends BudgesBaseValueObject> implements ValueEncoder<T>
{
  private static final Logger log = CbesLogFactory.getLog(PkAndVersionEncoder.class);
  private final Map<Integer, T> keyToValue = new LinkedHashMap<Integer, T>();


  public PkAndVersionEncoder()
  {
    log.debug("constructed");
  }


  public String toClient(T value)
  {
    Integer id = value.getId()==null ? 0 : value.getId();
    Integer version = value.getVersion()==null ? 0 : value.getVersion();
    return id + ":" + version;
  }


  public T toValue(String keyAsString)
  {
    Integer key = new Integer(keyAsString.split(":")[0]);
    Integer version = new Integer(keyAsString.split(":")[1]);
    T person = toValue(key, version);
    keyToValue.put(key, person);
    return person;
  }
  
  public abstract T toValue(Integer pk, Integer version);


  public final List<T> getAllValues()
  {
    List<T> result = CollectionFactory.newList();

    for (Map.Entry<Integer, T> entry : keyToValue.entrySet())
    {
      result.add(entry.getValue());
    }

    return result;
  }
};