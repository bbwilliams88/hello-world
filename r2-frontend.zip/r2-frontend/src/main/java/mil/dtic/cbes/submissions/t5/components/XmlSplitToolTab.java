package mil.dtic.cbes.submissions.t5.components;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;

import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.xml.JavaToXml;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;

public class XmlSplitToolTab extends BaseXmlToolTab {
  
  private static final Logger log = CbesLogFactory.getLog(XmlSplitToolTab.class);
  
  @Parameter(required = true)
  @Property
  private File workingDirectory;
  @Inject
  private MultipartDecoder decoder;
  @Inject
  private HttpServletRequest request;
  
  public JSONObject onSplitXml(){
    String action = "splitXml";
    List<String> fileErrors = new LinkedList<String>();
    JSONObject errorMessages = new JSONObject();
    JSONObject successMessages = new JSONObject();
    
    UploadedFile upFile = decoder.getFileUpload("file");
    
    List<XmlDocument> xmlDocumentsToSplit = new ArrayList<XmlDocument>();
    try {
      if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
        log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
        + ", expected " + getCurrentBudgesUser().getCsrfToken());
        throw new FileUploadException("Attempted to upload file without proper authorization");
      }
      xmlDocumentsToSplit = XmlUploadProcessor.getXmlDocumentsFromUpload(upFile, workingDirectory, false);
    } catch(FileUploadException|XmlDocumentException e) {
      log.error("Error processing uploaded file", e); 
      addGeneralMessage(errorMessages, e.getMessage());
      return createResponse(action, null, null, errorMessages, null, null);
    }
    
    String localFileName = getFileNameBase(upFile.getFileName());
    
    File f = new File(workingDirectory, FileUtil.createZipFileName("split_" + localFileName));
    FileOutputStream fos = null;
    try {
      fos = new FileOutputStream(f);
    } catch(FileNotFoundException e) {
      addGeneralMessage(errorMessages, "Unable to create zip of migrated XML files.");
      return createResponse(action, successMessages, null, errorMessages, null, null);
    }
    BufferedOutputStream bos = new BufferedOutputStream(fos);
    ZipOutputStream zipOs = new ZipOutputStream(bos);
    
    for(XmlDocument xd : xmlDocumentsToSplit) {
      try {
        validateXmlDocument(xd, xd.getOriginalFileName(), fileErrors);
        if(CollectionUtils.isEmpty(fileErrors)) {
            splitXml(xd, zipOs);
        }
      } catch(IOException|XmlDocumentException e) {
        fileErrors.add("Could not read XML for exhibits in file.");
        log.error("Error occurred while reading file for exhibits", e);
        return createResponse(action, null, null, errorMessages, null, null);
      } finally {
        xd.closeAllStreams();
      }
    }
    
    IOUtils.closeQuietly(zipOs);
    IOUtils.closeQuietly(bos);
    IOUtils.closeQuietly(fos);
    ZipFile zipFile = null;
    try {
      zipFile = new ZipFile(f);
      if (zipFile.size()>0){
        addGeneralMessage(successMessages, FileUtil.getFileNameWithoutPath(zipFile.getName()));
        IOUtils.closeQuietly(zipFile);
      }
    } catch (ZipException e) {
      log.error("Could not read final zip file", e);
    } catch (IOException e) {
      log.error("Could not read final zip file", e);
    }
    finally {
      IOUtils.closeQuietly(zipFile);
    }
    
    if (CollectionUtils.isNotEmpty(fileErrors)){
    JSONObject fileErrorObj = formatFileMessage(upFile.getFileName(), fileErrors);
    addFileMessage(errorMessages, fileErrorObj);
    }
    return createResponse(action, successMessages, null, errorMessages, null, null);
    
  }
  
  private void validateXmlDocument(XmlDocument xd, String uploadedFileName, List<String>fileErrors) {
      // validate against schema
      XmlFullValidationService xmlValidator = xd.validateXmlSchema();
      xd.resetAllStreams();
      
      if (xmlValidator.hasRulesErrors() || xmlValidator.hasSchemaErrors()){
        //done don't do anything else
        fileErrors.addAll(xmlValidator.getSchemaErrorList());
        fileErrors.addAll(xmlValidator.getRulesErrorList());
      }
      
      // if doc is in current budget cycle, continue
      if(xd.isPreviousBudgetCycle()) {
        try {
          xd.migrateXml();
        } catch (XmlDocumentException e) {
          fileErrors.add("Could not complete migration prior to splitting Xml.");
          log.error("Could not complete migration for split tool.", e);
        }
      }
      
    
  }
  
  private void splitXml(XmlDocument xmlDoc, ZipOutputStream zipOs) throws XmlDocumentException, IOException {
    R2ExhibitList r2List = xmlDoc.getR2ExhibitList();
    LineItemList p40List = xmlDoc.getLineItemList();
    if(r2List != null) {
      splitR2(r2List, zipOs);
    } else if(p40List != null) {
      splitP40(p40List, zipOs);
    }
  }

  private void splitP40(LineItemList liList, ZipOutputStream zipOs) throws IOException{
    if (liList!=null){
      List<LineItemWrapper>liWrappers = liList.getLineItems();
      for (LineItemWrapper liWrapper:liWrappers){
        LineItemList outerList = new LineItemList();
        List<LineItemWrapper> innerList = new ArrayList<LineItemWrapper>();
        innerList.add(liWrapper);
        outerList.setLineItems(innerList);
        if(liWrapper.getBusinessId() == null)
          throw new FileNotFoundException("Unable to create XML filename: invalid or missing ID info");
        String fName = FileUtil.createXmlFileName(liWrapper.getBusinessId());
        addToZip(JavaToXml.toXml(outerList), fName, zipOs);
      }
    }
  }
  
  private void splitR2(R2ExhibitList r2List,  ZipOutputStream zipOs) throws IOException{
    if (r2List!=null){
      List<R2Exhibit>r2s = r2List.getR2Exhibits();
      for (R2Exhibit r2 :r2s){
        R2ExhibitList outerList = new R2ExhibitList();
        List<R2Exhibit> innerList = new ArrayList<R2Exhibit>();
        innerList.add(r2);
        outerList.setR2Exhibits(innerList);
        if(r2.getBusinessId() == null)
          throw new FileNotFoundException("Unable to create XML filename: invalid or missing ID info");
        String fName = FileUtil.createXmlFileName(r2.getBusinessId());
        addToZip(JavaToXml.toXml(outerList), fName, zipOs);
      }
    }
  }
  
  public StreamResponse onDownloadFile(String location){
    log.debug("Location:"+location);
    InputStream is = null;
    if (location!=null){
      try {
      is = new FileInputStream(workingDirectory+"/"+location);
      StreamResponse response = getZipStream(is, FileUtil.getFileNameWithoutPath(location));
      return response;
    } catch (FileNotFoundException e) {
      log.error("Could not find file to download.",e);
      return null;
    } 
    }
    return null;
  }

}
