package mil.dtic.cbes.submissions.t5.pages;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.Field;
import org.apache.tapestry5.FieldValidator;
import org.apache.tapestry5.PersistenceConstants;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.FieldValidatorSource;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.ConfigTypeFlag;
import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.CbesLogFactory;

@Secured({"ROLE_R2AppMgr"})
public class EditConfig extends ManageAppPropsBase
{
  private static final String DEFAULT_VALUE_VALIDATOR_STRING = "required, maxlength=65534";
  private static final String JB_DRAFT_STAMP_VALUE_VALIDATOR_STRING = "maxlength=65534";

  private static final List<String> cycleList = Arrays.asList (Constants.BUDGET_CYCLE_BES, Constants.BUDGET_CYCLE_PB, Constants.BUDGET_CYCLE_PB_AMENDED, Constants.BUDGET_CYCLE_PB_SUPPLEMENTAL);

  private static final Logger log = CbesLogFactory.getLog(EditConfig.class);
  @Inject
  private ConfigDAO configDAO;

  @Property
  @Persist
  private String name;

  @Property
  @Persist
  private Config config;

  @Property
  @Persist
  private Config oldConfig;
 
  @Property
  private boolean isValueBoolean;
  
  @InjectComponent
  private Zone valueZone;
  /*
  @Property 
  @Persist
  private boolean isCycleYearDependent;
  */
  @Property
  @Persist(PersistenceConstants.FLASH)
  private String copyHost;

  @Property
  @Persist(PersistenceConstants.FLASH)
  private String copyCycle;

  @Property
  @Persist(PersistenceConstants.FLASH)
  private int copyYear;

  @Component(id = "form")
  private Form form;

  @Persist
  private Config dbConfig;
  
  private boolean copy = false;
  private boolean _isDeleteButton = false;
  
  @Inject
  private FieldValidatorSource fieldValidatorSource;

  @InjectComponent
  private Field value;

  @Log
  void onActivate(String name, String hostName, String budgetCycle, int budgetYear)
  {
    this.name = name;
    dbConfig = configDAO.findByNameAndCycle(name, hostName, budgetCycle, budgetYear);
    config = dbConfig.copy();
    oldConfig = dbConfig.copy();
    
    copyCycle = budgetCycle;
    copyYear = budgetYear;

    /*
    if (name.equals(ConfigService.R2_JB_PDF_PASSWORD) || name.equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE)) {
      isCycleYearDependent = true;
      copyCycle = budgetCycle;
      copyYear = budgetYear;
    }
    else 
      isCycleYearDependent = false;
      */
    
    if (dbConfig.getValueType() == ConfigTypeFlag.BOOLEAN)
      isValueBoolean = true;

    try {
      if (copyHost == null)
        copyHost = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      log.error("", e);
    }
  }

  // Only the jb.draftStamp entry is allowed to be empty or null.
  public FieldValidator getValueValidation() {
	  String validator = DEFAULT_VALUE_VALIDATOR_STRING;
	  if (config.getName().equals(ConfigService.JB_DRAFT_STAMP))
		  validator = JB_DRAFT_STAMP_VALUE_VALIDATOR_STRING;
		  
	  return fieldValidatorSource.createValidators(value, validator);
  }

  public List<ConfigTypeFlag> getTypeList(){
      List <ConfigTypeFlag> flagList = new ArrayList<ConfigTypeFlag>();
      for(ConfigTypeFlag value:ConfigTypeFlag.values())
        flagList.add(value);

      return flagList;
    }
  
  String[] onPassivate()
  {
    return new String[]{config.getName(), config.getHostName()};
  }

  void onSelectedFromCopy()
  { 
    copy = true;
  }


  Object onActionFromCancel()
  {
    return ManageAppProps.class;
  }

  public List<String> getCycleList() {
    return cycleList; 
  }
  
  void onValidateFromForm()
  { 
    if (!_isDeleteButton) {
      form.clearErrors();
      if (isValueJson())
      {
        boolean isObject = false, isArray = false;
        try {
          new JSONObject(config.getValue());
          isObject = true;
        } catch (RuntimeException e) { // Tapestry's JSON lib throws RuntimeException if parsing fails
          log.info("Not json object...");
          log.trace("", e);
        }
        try {
          new JSONArray(config.getValue());
          isArray = true;
        } catch (RuntimeException e) {
          log.info("Not json array...");
          log.trace("", e);
        }
        if (!isObject && !isArray) 
          form.recordError("That looks like invalid json");
      }

      if (copy)
      {
    	  if (configDAO.findByNameAndCycle(name, copyHost, copyCycle, copyYear) != null)
              form.recordError("This configuration already exists for this host name, budget cycle and year");
    	  /*
        if (name.equals(ConfigService.R2_JB_PDF_PASSWORD) || name.equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE)) {
          if (configDAO.findByNameAndCycle(name, copyHost, copyCycle, copyYear) != null)
            form.recordError("This configuration already exists for this host name, budget cycle and year");
        }
        else {
          if (configDAO.findByName(name, copyHost) != null)
            form.recordError("This configuration already exists for this host name");
        }
        */
      }

      if (config.getValue() == null){
    	  // jb.draftStamp entry is allowed to be empty or null. Any other entry should throw an error if empty/null.
    	  if (config.getName().equals(ConfigService.JB_DRAFT_STAMP))
    		  return;
          form.recordError("Value is required.");  
      }
      else
      {
        switch (config.getValueType())
        {
          case BOOLEAN:
            if (!(StringUtils.equalsIgnoreCase(config.getValue(), "true") || StringUtils.equalsIgnoreCase(config.getValue(), "false")))
              form.recordError("You have not entered a boolean. Change the value to either true or false.");
            break;

          case NUM:
            try
            {
              Long.parseLong(config.getValue());
            }
            catch (NumberFormatException e) {
              form.recordError("You have entered a non-numeric value. Change the value to a number.");
            }
            break;

          case EMAIL:
            Pattern emailPattern = Pattern.compile(".+@.+\\.[a-z]+");
            if (!(emailPattern.matcher(config.getValue()).matches() || StringUtils.equals(config.getValue(), "%CURRENT_USER_EMAIL%")))
              form.recordError("You have entered a invalid email address.");
            break;

          case HOST:
            Pattern hostPattern = Pattern.compile("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
            if (!hostPattern.matcher(config.getValue()).matches())
              form.recordError("You have entered a invalid IP address.");
            break;

          case DATE:
            try{
              newDateTimeFormatter(config.getValue());
            }catch(IllegalArgumentException e) {
              form.recordError("You have not entered a valid date."); 
            }
            break;

          case URL:
            Pattern urlPattern = Pattern.compile("^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]");
            if (!urlPattern.matcher(config.getValue()).matches())
              form.recordError("You have entered a invalid URL.");
            break;
        }
      }
    }	//if (!_isDeleteButton)
  }

  Object onChangeValueType(ConfigTypeFlag valueType)
  { 
    if(valueType != ConfigTypeFlag.BOOLEAN) {
      isValueBoolean = false;
      config.setValue("");
    }
    else 
      isValueBoolean = true;

      config.setValueType(valueType);

      return valueZone.getBody();
  }

  Object onSuccess()
  {
    if (copy)
    {
      // For copy only the following attributes can be updated
      config.setName(name);
      config.setCreatedByBudgesUser(getCurrentBudgesUser());
      config.setModifiedByBudgesUser(getCurrentBudgesUser());
      config.setHostName(copyHost);      
      //if (name.equals(ConfigService.R2_JB_PDF_PASSWORD) || name.equals(ConfigService.R2_JB_PDF_PASSWORD_ENABLE)) {
        config.setBudgetCycle(copyCycle);
        config.setBudgetYear(copyYear);
      //}
      configDAO.saveByConfig(config);
      sendConfigChangedNotificationEmail(configUpdateType.Copy, config, oldConfig);
      cleanUp();
      return ManageAppProps.class;
    }
    else
    {
      dbConfig.setDescription(config.getDescription());
      dbConfig.setReadOnly(config.getReadOnly());
      dbConfig.setValue(config.getValue());
      dbConfig.setModifiedByBudgesUser(getCurrentBudgesUser());
      dbConfig.setValueType(config.getValueType());
      dbConfig.setBudgetCycle(config.getBudgetCycle());
      dbConfig.setBudgetYear(config.getBudgetYear());
      configDAO.saveByConfig(dbConfig);
      sendConfigChangedNotificationEmail(configUpdateType.Update, config, oldConfig);
      //return null;
      cleanUp();
      return ManageAppProps.class;
    }
  }


  Object onSelectedFromDelete()
  {
    configDAO.delete(dbConfig);
    sendConfigChangedNotificationEmail(configUpdateType.Delete, null, config);
    _isDeleteButton = true;
    cleanUp();
    return ManageAppProps.class;
  }


  public boolean isValueString()
  {
    return !isValueBoolean && !isValueJson() && !isHtml();
  }

  public boolean isHtml()
  {
    return config.getValueType().equals(ConfigTypeFlag.HTML);
  }

  public boolean isValueJson()
  {
    return config.getValueType() == ConfigTypeFlag.JSON || config.getValueType() == ConfigTypeFlag.JSONJOB;
  }

  private void cleanUp () {
    // clean up 
    config = null;
    dbConfig = null;
    oldConfig = null;
    //isCycleYearDependent = false;
  }

}