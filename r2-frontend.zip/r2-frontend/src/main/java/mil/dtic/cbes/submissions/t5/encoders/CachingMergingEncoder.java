package mil.dtic.cbes.submissions.t5.encoders;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.cbes.submissions.dao.BudgesBaseDAO;
import mil.dtic.utility.CbesLogFactory;

public class CachingMergingEncoder<T extends BudgesBaseValueObject> extends MergingEncoder<T>
{
  private static final Logger log = CbesLogFactory.getLog(CachingMergingEncoder.class);
  private final Runnable cacheLoader;

  public CachingMergingEncoder(Runnable cacheLoader, BudgesBaseDAO<T> dao, T dummy)
  {
    super(dao,dummy);
    if (cacheLoader==null) throw new IllegalArgumentException();
    this.cacheLoader = cacheLoader;
    log.debug("constructed");
  }
  
  public T toValue(Integer pk, Integer version)
  {
    cacheLoader.run(); //NOSONAR - Want this to run in the same thread.
    return super.toValue(pk, version);
  }
}