package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.ajax.AjaxResponseRenderer;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.rule.Rule;
import mil.dtic.cbes.rule.RuleRepository;
import mil.dtic.cbes.rule.RuleRepositoryFactory;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.ValidationExemption;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

/**
 * R2 Exhibit Edit Validation Rules Exemptions administration page.
 */
//@Import( stack      = { CbesT5SharedModule.DATATABLESTACK },
//         stylesheet = { "context:css/r2.css", "context:css/bootstrap.min.css" } )
@Secured({"ROLE_R2AppMgr"})
public class EditValidationRuleR2 extends T5Base {
    private static final Logger log = CbesLogFactory.getLog(ManageValidationRules.class);


	@Persist
	@Property
	private Rule rule;

	@Inject
	private ServiceAgencyDAO serviceAgencyDAO; 

//    @Inject
//    ValidationExemptionDAO ValidationExemptionDAO;

    @Property
    private ValidationExemption currentExemption;

    @Property
    @Persist
    List<ValidationExemption> currentExemptions;

	@Persist
	@Property
	private String ruleNumber;

	@Persist
	@Property
	private String ruleMessage;

	@Property
	private List<ServiceAgency> allAgencies;

	@Property
	private Set<String> exemptAgencies;

	@Property
	private String agency;

	@Property
	private List<String> nonExemptAgencies;

	@Property
	private boolean foundRule;

	@InjectComponent
	private Zone ruleEditZone;

	@Inject
	private Request request;

	@Property
	private String organization;

	@Inject
	private AjaxResponseRenderer ajaxResponseRenderer;

  	public void setBusinessRule (String ruleId){
  		RuleRepository ruleRepository = RuleRepositoryFactory.makeRepository();
  		rule = ruleRepository.narrowTo(ruleId).getFirstRule();
  		ruleNumber = rule.getRuleNumber();
  		ruleMessage = rule.getRuleMessage();
  	}
  	public Rule getBusinesRule(){
  		return rule;
  	}

	public void setupRender()
	{  
	  currentExemptions = new ArrayList<>();
	  
	  for(ValidationExemption v : BudgesContext.getValidationExemptionDAO().findByProperty("rdteRule", ruleNumber)){
	      if(v.getStatus().isActive()){
	        currentExemptions.add(v);
	      }
	    }
	}

  	public void onActivate() {
		if(rule == null){
			foundRule = false;
		} else {
			foundRule = true;
			allAgencies = serviceAgencyDAO.findAllRDTE();
			updateExemptAgencies();
		}
	}

    // Add One
    public void onSuccess()
    {
        if (request.isXHR())
        {
            if (organization != null)
            {
                for (ServiceAgency sa : serviceAgencyDAO.findAllRDTE())
                {
                    if (sa.getName().equals(organization))
                    {
                        ValidationExemption exemption = findValidationExemption(sa.getCode());

                        if (exemption == null)
                            exemption = createValidationExemption(sa);
                        else
                            updateValidationExemption(exemption, StatusFlag.ACTIVE);

                        rule.addExemptOrganization(sa.getCode());
                        currentExemptions.add(exemption);
                        updateExemptAgencies();
                        ajaxResponseRenderer.addRender(ruleEditZone);
                    }
                }
            }
        }
    }

	public void onFailure() {
		log.debug("failure");
		if (request.isXHR()) {
			ajaxResponseRenderer.addRender(ruleEditZone);
		}
	}

    // Remove Organization
    public void onRemove(String organizationCode)
    {
        // Update exemption to inactive and save in DB.
        updateExemption(organizationCode, StatusFlag.INACTIVE);

        // Update pulldown settings.
        updateExemptAgencies();    
        
        currentExemptions.remove(findValidationExemption(organizationCode));
        
        ajaxResponseRenderer.addRender(ruleEditZone);
    }

    // Reactivate Organization
    public void onReactivate(String organizationCode)
    {
        // Update exemption to active and save in DB.
        updateExemption(organizationCode, StatusFlag.ACTIVE);

        // Update pulldown settings.
        updateExemptAgencies();

        ajaxResponseRenderer.addRender(ruleEditZone);
    }

    private void updateExemption(String organizationCode, StatusFlag statusFlag)
    {
        ValidationExemption exemption = findValidationExemption(organizationCode);

        if (exemption != null)
        {
            // Activate/Deactivate in the DB.
            updateValidationExemption(exemption, statusFlag);

            // Add/Remove the organization's exemption to the validation rule.
            if (statusFlag == StatusFlag.ACTIVE)
                rule.addExemptOrganization(organizationCode);
            else{
                rule.removeExemptOrganization(organizationCode);
            }
            
            
            // Update the current exemption list for the UI.
            for (int i = 0; i < currentExemptions.size(); i++)
                if (StringUtils.equalsIgnoreCase(organizationCode, currentExemptions.get(i).getOrganization().getCode())){
                    currentExemptions.set(i, exemption);
                }
       }
    }

	//Update Agencies
	public void updateExemptAgencies(){
  		exemptAgencies = new HashSet<String>();
  		for(String saCode : rule.getExemptOrganizations()){
  			exemptAgencies.add(serviceAgencyDAO.findByCode(saCode).getName());
  		}
  		updateNonExemptAgencies();
  	}

  	public void updateNonExemptAgencies() {
  		nonExemptAgencies = new ArrayList<String>();
  		for(ServiceAgency sa : allAgencies){
  			if(!exemptAgencies.contains(sa.getName())){
  				nonExemptAgencies.add(sa.getName());
  			}
  		}
  	}

  	public boolean isCurrentExemptionActive()
  	{
  		return currentExemption.getStatus() == StatusFlag.ACTIVE;
  	}  	
  	
    private ValidationExemption findValidationExemption(String organizationCode)
    {
        List<ValidationExemption> exemptions = BudgesContext.getValidationExemptionDAO().findByProperty("rdteRule", ruleNumber);

        for (ValidationExemption validationExemption : exemptions)
            if (validationExemption.getOrganization().getCode().equals(organizationCode))
                return validationExemption;

        return null;
    }

    private ValidationExemption createValidationExemption(ServiceAgency organization)
    {
        ValidationExemption exemption = new ValidationExemption();

        // Set initial/creation information.
        exemption.setCreatedByBudgesUser(getCurrentBudgesUser().getFullName());
        exemption.setDateCreated(new Date());
        exemption.setOrganization(organization);
        exemption.setRdteRule(ruleNumber);

        // Activate, set modification information, and save in DB.
        updateValidationExemption(exemption, StatusFlag.ACTIVE);

        return exemption;
    }

    private void updateValidationExemption(ValidationExemption exemption, StatusFlag statusFlag)
    {
        // Set modification information and status.
        exemption.setDateModified(new Date());
        exemption.setModifiedByBudgesUser(getCurrentBudgesUser().getFullName());
        exemption.setStatus(statusFlag);

        // Save in DB.
        BudgesContext.getValidationExemptionDAO().saveOrUpdate(exemption);
    }
}