package mil.dtic.cbes.submissions.t5.pages;

import java.util.Hashtable;
import java.util.Vector;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.ldap.NetLDAP;
import mil.dtic.utility.CbesLogFactory;
import netscape.ldap.LDAPException;

@Secured({"ROLE_R2AppMgr"})
@Import(library = {"classpath:${cb.assetpath}/js/handlebars-v1.3.0.js","classpath:${cb.assetpath}/js/ember.prod.js","context:js/ldaptools.coffee"})
public class LDAPTools extends T5Base {

  //NetLDAP user attributes
  private static final String ATTR_FULL_NAME = "cn";
  private static final String ATTR_FIRST_NAME = "givenname";
  private static final String ATTR_MIDDLE_INITIAL = "initials";
  private static final String ATTR_LAST_NAME = "sn";
  private static final String ATTR_EMAIL = "mail";
  private static final String ATTR_PHONE = "telephonenumber";
  private static final String ATTR_CREATED = "accountcreated";
  private static final String ATTR_ORGANIZATION = "organization";
  private static final String ATTR_EDIPI = "edipi";
  private static final String ATTR_MODIFIED = "accountmodified";
  private static final String[] LDAP_USER_ATTRIBUTES = { "cn", // first-name
                                                                // last-name
      "givenname", // first-name
      "initials", // middle initial
      "sn", // last-namen
      "mail", // email address
      "telephonenumber", // work number
      "accountcreated", //Account Created
      "organization", //Organization
      "edipi",
      "accountmodified"
  };
  
  private static final Logger log = CbesLogFactory.getLog(LDAPTools.class);
  
  @Inject
  private JavaScriptSupport javaScriptSupport;
  
  @Inject
  private ComponentResources resources;
  
  @Inject
  private Request request;
 
  /**
   * After Render will fire the JS initialize and pass it the URL's of handlers to be used in ajax calls.
   */
  @Log
  void afterRender()
  {
    
    String searchLdapLink = resources.createEventLink("searchLdapHandler").toString();
    String lookupLdapLink = resources.createEventLink("lookupLdapHandler").toString();
    
    javaScriptSupport.addScript("initialize('%s','%s');", searchLdapLink,lookupLdapLink);
    
  }
  
  /**
   * Handler which will respond to a user looking up a specific LDAP user.
   * @return
   */
  @Log
  JSONObject onLookupLdapHandler()
  {
      //Construct response object(s)
      JSONObject response = new JSONObject();
    
      try{
      
        String ldapUserId = request.getParameter("ldap_id");
        System.out.println("LDAPY: " + ldapUserId);
        //If ldap id passed then look the user up.
        if(StringUtils.isNotBlank(ldapUserId)){
          response.put("term",ldapUserId);
            
          
          Hashtable<String, String> attrTable = NetLDAP.userinfo(ldapUserId, LDAP_USER_ATTRIBUTES);
          
          response.put("ldapid", ldapUserId);
          response.put("email", attrTable.get(ATTR_EMAIL));
          response.put("name", attrTable.get(ATTR_FULL_NAME));
          response.put("phone", attrTable.get(ATTR_PHONE));
          response.put("org", attrTable.get(ATTR_ORGANIZATION));
          response.put("created", attrTable.get(ATTR_CREATED));
          response.put("modified", attrTable.get(ATTR_MODIFIED));
          response.put("edipi", attrTable.get(ATTR_EDIPI));
                  
        }else{
          log.error("Failed to lookup lday user: No LDAP ID specified");
          throw new RuntimeException("No LDAP ID specified.");
          
        }
        
        return response;
    
      }catch(LDAPException lde){
        
        log.error("Encountered Error while trying to query LDAP: " + lde.getMessage(),lde);
        throw new RuntimeException("Server Error.");
        
      }
        
  }
  
  /**
   * Handler which will respond to a user searching LDAP and reply with JSON results of ldap search.
   * @return
   */
/*  
  @Log
  JSONObject onSearchLdapHandler()
  {
      //Construct response object(s)
      JSONObject response = new JSONObject();
      JSONArray ldapRecords = new JSONArray();
      
      try{
      
        String ldapUserId = request.getParameter("term");
        
        //If ldap id passed then look the user up.
        if(StringUtils.isNotBlank(ldapUserId)){
          response.put("term",request.getParameter("term"));
                     
          String filter = "(&(objectclass=dticwebuser)(uid="+ ldapUserId + "))";

          Vector<String> peeps = NetLDAP.search(NetLDAP.baseDn(), filter, "uid");
          System.out.println("Peeps: " + peeps);
          for(String peep : peeps){
            
            JSONObject ldapUser = new JSONObject();
            ldapUser.put("ldapid", peep);
            ldapRecords.put(ldapUser);
            
          }
          
          response.put("results", ldapRecords);
          
        }else{
          
          response.put("warn", "No search term provided.");
          
        }
            
        return response;
      
      }catch(LDAPException lde){
        
        log.error("Encountered Error while trying to query LDAP: " + lde.getMessage(),lde);
        response.put("err", "Server encountered an error while attempting to search LDAP.");
        return response;
        
      }
      
  }
*/
}
