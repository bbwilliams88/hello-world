package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.t5.base.T5Base;

public class Dropzone extends T5Base {
  
  @Property
  @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
  private String prefix;
  
  @Property
  @Parameter(defaultPrefix = BindingConstants.LITERAL)
  private String actionLabel;
  
  @Property
  @Parameter
  private Block instructions;
  
  @Property
  @Parameter
  private Block formInputs;
  
  @Property
  @Parameter
  private Block submitControls;

  public Dropzone() {
    // TODO Auto-generated constructor stub
  }

}