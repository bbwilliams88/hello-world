package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;


/**
 * Creates a new R2 Exhibit
 */
@Import( library = { "context:js/newR2create.js" })
public class NewR2Create extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(NewR2Create.class);
  @Inject
  private BudgetCycleDAO bcDAO;

  @Property
  private BudgetCycle currentBudgetCycle;
  @Property
  private BudgetCycle aBudgetCycle;
  @Property
  private List<BudgetCycle> allTheBudgetCycles;
  @Property
  private ServiceAgency serviceAgency;
  @Property
  private String currentSubmissionDate;
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private ConfigService config;

  @Log
  void onActivate()
  {
    log.debug("Creating...");
    currentBudgetCycle = Util.getCurrentBudgetCycle();
    allTheBudgetCycles = bcDAO.getBudgetCycles();
    List<SubmissionDate> submDates = currentBudgetCycle.getSubmissionDates();
    currentSubmissionDate = submDates.get(submDates.size() - 1).getValue();
  }

  void afterRender() {
    jsSupport.addScript("setR2SupportEmailAddress('" + config.getEmailTo() + "');");
    jsSupport.addScript("initialize();");  // this is the origin of the call to NewR2Create.java
    jsSupport.addScript("changeInit();");
  }

  public int addIntegers(int intOne, int intTwo)
  {
    return intOne + intTwo;
  }

  public List<ServiceAgency> getServiceAgencies()
  {
      List<ServiceAgency> serviceAgencies = getUserCredentials().getUserInfo().getAvailableRdteAgencies();
      return serviceAgencies;
      
    //return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
  }

  public boolean hasCreatePermissions()
  {
    return getUserCredentials().createPeAllowed();
  }
}
