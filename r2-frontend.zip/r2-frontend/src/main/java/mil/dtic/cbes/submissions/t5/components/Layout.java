package mil.dtic.cbes.submissions.t5.components;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.RequestGlobals;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Environment;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;


@Import(
  stack   = { CbesT5SharedModule.JQUERYTOOLSSTACK,CbesT5SharedModule.BEAUTYTIPSSTACK },
  library={"context:/js/timeout.js", "context:/js/confirm.js", "classpath:${cb.assetpath}/js/log.js", "context:/js/t5.js"})
public class Layout extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(Layout.class);
  @Inject
  private RequestGlobals requestGlobals;
  @Inject
  private HttpServletRequest servletRequest;
  @Inject
  private ConfigService config;

  @SuppressWarnings("unused")
  @Parameter(required=true, defaultPrefix = BindingConstants.LITERAL)
  @Property
  private String title;

  @Parameter @Property
  private BudgesDownloadableObject download;

  @Property @Persist
  private BudgesDownloadableObject cachedDownload; //cache the dbdo to get around crappy IE security settings

  @Parameter @Property
  private Object redirect; //do not set this to java.lang.Object. Any subclass will do.

  @SuppressWarnings("unused")
  @Property
  private boolean jquery;

  @SuppressWarnings("unused")
  @Property
  private boolean treeview;

  @Log
  Object onDownload() throws FileNotFoundException
  {
    try
    {
      if (download!=null)
        cachedDownload = download;
      if (download==null && cachedDownload==null) {
        log.error("Someone's knocking on the download door, but nobody's home", new NullPointerException("just making it scarier"));
        return null;
      }
      return getStreamResponse(cachedDownload);
    } finally {
      // Make sure we set download to null, otherwise we'll try to stream every time this component is hit (every page) ;)
      //(the script checks for the presence of "download")
      download = null;
    }
  }

  @SuppressWarnings("unchecked")
  @Log
  Object onRedirect() throws IOException, ServletException
  {
    try
    {
      if (redirect==null) {
        log.error("Someone's knocking on the redirect door, but nobody's home", new NullPointerException("just making it scarier"));
        return null;
      }
      return redirect;
    } finally {
      redirect = null;
    }
  }

  //sees if o is a complete classname string (package included), return null if it isn't
  private Class<?> getClass(Object o)
  {
    if (o instanceof Class<?>)
      return (Class<?>)o; //well that was easy
    if (o instanceof String) {
      try {
        return Class.forName((String)o);
      } catch (ClassNotFoundException e) {
        //normal
      }
    }
    log.debug(o + " is not a class name");
    return null;
  }

  public String getHostInfo()
  {
    try {
      return InetAddress.getLocalHost().toString();
    } catch (UnknownHostException e) {
      log.debug("getHostInfo: Unknown host");
      return "[UNKNOWN]";
    }
  }

  public String getSessionId()
  {
    if (getRequestGlobals()!=null && getRequestGlobals().getHTTPServletRequest()!=null && getRequestGlobals().getHTTPServletRequest().getSession()!=null && getRequestGlobals().getHTTPServletRequest().getSession().getId()!=null)
    {
      return getRequestGlobals().getHTTPServletRequest().getSession().getId();
    }
    return "[NO SESSION]";
  }

  public String getCurrentTime()
  {
    DateFormat formatter = new SimpleDateFormat(Constants.HEADER_DATETIME_FORMAT);
    return formatter.format(new Date());
  }

  public boolean showWelcome()
  {
    return true;
  }

  /**
   * Getter for the Maintenance Message string.
   * @return
   */
  public String getMaintenanceMessage(){
    return config.getMaintenanceMessage();
  }

  public boolean showLinks()
  {
    return getUserCredentials()!=null && getUserCredentials().getUserInfo()!=null && getUserCredentials().getUserInfo().isLoggedIn();
  }

  public boolean showHelpIcon()
  {
    return true;
  }

  public boolean showLockIcons()
  {
    return true;
  }

  public boolean isMaintenanceMode()
  {
    return Util.isMaintenanceMode();
  }

  public Environment getEnv()
  {
    return config.getEnv();
  }

  public boolean isProd()
  {
    return config.isProd();
  }

  public boolean isClassified()
  {
    return Util.isClassified();
  }


  public String getDcsid()
  {
//      R2 Development Data Source dcsid: dcsu9icwm10000wkhc0bxk0hr_4b3v
//      R2 Staging Data Source dcsid: dcssyyhp500000w4xh2ncq0hr_6p1m
//      R2 Production Data Source dcsid: dcsytxh0o1000008yn7nds0hr_8u4t

      if (config.isProd())
          return "dcsytxh0o1000008yn7nds0hr_8u4t";
      else if (config.isStaging())
          return "dcssyyhp500000w4xh2ncq0hr_6p1m";
      else
          return "dcsu9icwm10000wkhc0bxk0hr_4b3v";
  }
  public String getDomain()
  {
    return config.getHostName();
  }
  
  public boolean isR2Analyst() {
		return getCurrentBudgesUser().getRole().equals("R2Analyst");
	}

}
