package mil.dtic.cbes.submissions.t5.pages;


import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

@Import(stack = {CbesT5SharedModule.DATATABLESBUTTONS}, library={
  "classpath:${cb.assetpath}/js/underscore.string.js",
  "context:js/manageAppProps.js"
  })
@Secured({"ROLE_R2AppMgr"})
public class ManageAppProps extends ManageAppPropsBase
{
  @Inject
  private ConfigDAO configDAO;
  @Inject
  private ConfigService config;
  @Inject
  private ComponentResources componentResources;
  @Inject
  private JavaScriptSupport javaScriptSupport;

  private static final Logger log = CbesLogFactory.getLog(ManageAppProps.class);

  //@SuppressWarnings("unused")
  @Property(read = true)
  private Config configEntry;

  @Property
  private List<Config> configList;
  
  @Property
  private List<String> hostList;
  
  @Property
  private String hostName;

  // Used in the TML.
  @Property
  @SuppressWarnings("unused")
  private int rowIndex;
  
  @Property
  @SuppressWarnings("unused")
  private boolean newCreateConfigRequest=true;

  void onActivate()
  {
      if (configList == null){
          configList = configDAO.findAll();
      }
  }

  @Log
  void onRefreshConfig()
  {
    config.markConfigCacheForReload();
  }
  
  void afterRender()
  {
      javaScriptSupport.addScript("setupDatatable();");
  }

}
