package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Path;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.vo.util.IdPredicate;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementListDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.models.R2ListFilters;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.cbes.t5shared.utils.wizard.ExhibitSelectionPage;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;

/**
 * Selects R2s and saves their ids in session for use in other pages
 */
@Import(
  stack=CbesT5SharedModule.DATATABLESTACK,
  library={
    "${jquery.ui.path}/jquery.ui.effect-transfer.js",
    "classpath:${cb.assetpath}/js/json3.js",
    "classpath:${cb.assetpath}/js/jquery.pfSelect.js",
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/urlencoder.js",
    "classpath:${cb.assetpath}/js/datatable.coffee",
    "classpath:${cb.assetpath}/js/selectdatatable.coffee",
    "context:/js/r2select.coffee"
  },
  stylesheet={"context:/css/r2datatables.css", "context:/css/r2select.css"})
public class R2Select extends T5Base implements ExhibitSelectionPage
{
    private static final String JSON_ARRAY_PARAMETER  = "jsonarray";
    private static final String NUMBER_COPY_PARAMETER = "numbercopy";

    private static final Logger log = CbesLogFactory.getLog(R2Select.class);
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private ComponentResources resources;
  @Inject
  private Request request;


  @Inject
  private BudgetCycleDAO bcDAO;
  @Inject
  private ProgramElementListDAO pelDAO;
  @Inject
  private ProgramElementDAO peDAO;


  @SuppressWarnings("unused")
  @Inject
  @Path("classpath:/${cb.assetpath}/images/highlight-shot.png")
  @Property
  private Asset highlightScreenshot;


  @SessionState
  @Property
  private R2ListFilters filterState;
  @SessionState
  private DbExhibitSelection selection;
  @Persist
  private Object returnPage;
  @Persist
  private Object buildDocsPage;
  @SuppressWarnings("unused")
  @Persist
  @Property
  private String returnButtonMessage;
  @Persist
  private boolean showDeleted;
  //loop stuff
  @Property
  private List<ProgramElementList> leftList;
  @Persist
  @Property
  private List<ProgramElementList> rightList;
  @SuppressWarnings("unused")
  @Property
  private ProgramElementList currentPe;
  @SuppressWarnings("unused")
  @Property
  private int rowIndex;


  @Log
  void onActivate()
  {
    if (filterState.getBudgetCycle() == null) {
      filterState.setBudgetCycle(Util.getCurrentBudgetCycle());
    }

    if (rightList == null) {
      rightList = new ArrayList<ProgramElementList>();
    }
    if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES))
    {
      // show all pe's
      log.debug("Retrieving all pe's...");
      leftList = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(),
        false, false, filterState, null, getStoredPeSetForJb(), true, ProgramElementList.ID);
    }
    else if (getUserCredentials().checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY))
    {
      // show all pes for user's agencies
      log.debug("Retrieving all pe's for user's agencies...");
      leftList = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(),
        true, false, filterState, null, getStoredPeSetForJb(), true, ProgramElementList.ID);
    }
    else
    { // show only pe's for which user has access
      log.debug("Retrieving pe's for user based on user's agencies and pe permissions...");
      leftList = pelDAO.findByNarrowingFields(getUserCredentials().getUserInfo().getBudgesUser(),
        true, true, filterState, null, getStoredPeSetForJb(), true, ProgramElementList.ID);
    }
    log.debug("left " + leftList + "");
    log.debug("right " + rightList + "");
    log.debug("st " + getStoredPeSetForJb() + "");
  }

  void afterRender()
  {
    String cyclereload = resources.createEventLink("BudgetCycleChange").toString();
    String left = resources.createEventLink("MoveLeft").toString();
    String right = resources.createEventLink("MoveRight").toString();
    jsSupport.addScript("setupBudgetCycleReload('%s');", cyclereload);
    jsSupport.addScript("setupDatatable('%s');", right);
    jsSupport.addScript("setupSelectedDatatable('%s');", left);
  }

  @Log
  void onBudgetCycleChange(String reloadBudgetCycle)
  {
    filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
    leftList = null;

    //If user did not select a cycle (blank label) then set it to a null BudgetCycle
    //so we don't use the default cycle when "onActivate" is invoked
    if (filterState.getBudgetCycle() == null)
      filterState.setBudgetCycle(new BudgetCycle());
  }

  void onMoveRight()
  {
    log.debug("onMoveRight " + request.getParameter(JSON_ARRAY_PARAMETER));
    JSONArray arr = new JSONArray(request.getParameter(JSON_ARRAY_PARAMETER));
    for (final Object id : arr) {
      ProgramElementList pe = Iterables.find(leftList, new IdPredicate<ProgramElementList>(Integer.parseInt(id+"")));
      leftList.remove(pe);
      rightList.add(pe);
    }
  }

  void onMoveLeft()
  {
    log.debug("onMoveLeft " + request.getParameter(JSON_ARRAY_PARAMETER));
    JSONArray arr = new JSONArray(request.getParameter(JSON_ARRAY_PARAMETER));
    for (final Object id : arr) {
      ProgramElementList pe = Iterables.find(rightList, new IdPredicate<ProgramElementList>(Integer.parseInt(id+"")));
      rightList.remove(pe);
      leftList.add(pe);
    }
  }

  Object onActionFromReturn()
  {
    log.trace("onActionFromReturn " + rightList);
    applySelections();
    showDeleted = false;
    return returnPage;
  }

  Object onActionFromBuildOtherDocuments()
  {
    log.trace("onActionFromBuildOtherDocuments " + rightList);
    applySelections();
    showDeleted = false;

    return BuildOtherDocuments.class;
  }

  @Log
  void onActionFromReset()
  {
    leftList = null;
    rightList = null;
  }

  @Override
  public void setReturnPage(Object returnPage)
  {
    this.returnPage = returnPage;
  }

  @Override
  public void setReturnButton(String returnButtonMessage)
  {
    this.returnButtonMessage = returnButtonMessage;
  }

  public void setShowDeleted(boolean showDeleted)
  {
    this.showDeleted = showDeleted;
  }

  public List<ProgramElementList> getAllList()
  {
    List<ProgramElementList> l = new ArrayList<ProgramElementList>();
    l.addAll(leftList);
    l.addAll(rightList);
    return l;
  }

  public String getLeftJson()
  {
    JSONArray jsonArray = new JSONArray();
    for (ProgramElementList element : leftList) {
      JSONObject obj = new JSONObject(element.toJson(getAllowedProps()));
      obj.put(NUMBER_COPY_PARAMETER, element.getNumber());
      jsonArray.put(obj);
    }
    return jsonArray.toString(false);
  }

  public String getRightJson()
  {
    JSONArray jsonArray = new JSONArray();
    for (ProgramElementList element : rightList) {
      JSONObject obj = new JSONObject(element.toJson(getAllowedProps()));
      obj.put(NUMBER_COPY_PARAMETER, element.getNumber());
      jsonArray.put(obj);
    }
    return jsonArray.toString(false);
  }

  private List<String> getAllowedProps()
  {
    return Lists.newArrayList(new String[] {
      "id",
      "lineNum","number","title","userDefinedTag","baNum","numProjects",
      "serviceAgencyCode","serviceAgencyName", "budgetCycle", "budgetYear"
    });
  }

  private void applySelections()
  {
    selection.getProgramElements().clear();
    //get the regular pes in one big IN query
    List<ProgramElement> thegoodstuff = peDAO.findByIdsPaged(getStoredPeSetForJb(), 0, -1, true, ProgramElementList.ID);
    selection.getProgramElements().addAll(thegoodstuff);
  }

  private Set<Integer> getStoredPeSetForJb() {
    return TapestryUtil.ognlsettransform(rightList, ProgramElementList.ID);
  }
}
