package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgencyApp;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

@Import( stack   = { CbesT5SharedModule.DATATABLESUPDATED },
library = { "context:/js/administerLookupAcct.js" })
public class AdministerLookupAcctTab extends T5Base{

	  @Inject
	  private ServiceAgencyDAO serviceAgencyDAO;	
	  
	  @Property(read = true)
	  private ServiceAgency serviceAgencyEntry;
	  
	  @Property(read = true)
	  private ServiceAgencyApp serviceAgencyAppEntry;
	  
	  @Property
	  private int rowIndex;
	  
	  @Property
	  private List<ServiceAgency> serviceAgencyList;
	  
	  @Property
	  private List<ServiceAgencyApp> serviceAgencyAppList;
	  
	  @Property
	  private Set<ServiceAgency> serviceAgencySet;
	  
	  @Property
	  private ServiceAgency serviceAgency;
	  
	  @Property
	  private ServiceAgencyApp serviceAgencyApp;
	  
	  @Inject
	  private JavaScriptSupport jsSupport;
	  
	  @Inject
	  private ComponentResources resources;
	  
	  @Property
	  @Persist
	  private List<ServiceAgency> orgRows;
	  
	  List<String> vals;
	  
	  public void onActivate() {
		  
		  if (serviceAgencyList == null){
			  serviceAgencyList = serviceAgencyDAO.findAllRDTE();
			  
			  serviceAgencyAppList = new ArrayList<ServiceAgencyApp>();

			    if(CollectionUtils.isNotEmpty(serviceAgencyList)) 
			    {
			      for(int x = 0; x < serviceAgencyList.size(); x = x + 1) {
			    	for(int y = 0; y < serviceAgencyList.get(x).getAppropriations().size(); y = y + 1) {
			    		
			    	  for(int b = 0; b < serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().size(); b = b + 1) {
			    	    serviceAgencyApp = new ServiceAgencyApp(); 
			    	    serviceAgencyApp.setAgencyCode(serviceAgencyList.get(x).getCode().toString());
				        serviceAgencyApp.setAppnCode(serviceAgencyList.get(x).getAppropriations().get(y).getCode().toString());
				        serviceAgencyApp.setBudgetActivityNumber(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getNumber().toString());
				        serviceAgencyApp.setBudgetActivityTitle(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getTitle().toString());
				        serviceAgencyApp.setStatus(serviceAgencyList.get(x).getAppropriations().get(y).getRDTEBudgetActivities().get(b).getStatus());
				        serviceAgencyAppList.add(x, serviceAgencyApp);
			    	  }   
			    	}  
		          }	
			   	}
		  }  
	  }
	  
	  void afterRender()
	  {
		  jsSupport.addScript("setupDatatable();");
	  }
	  
}
