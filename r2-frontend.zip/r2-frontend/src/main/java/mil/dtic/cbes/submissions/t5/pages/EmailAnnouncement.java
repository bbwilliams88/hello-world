package mil.dtic.cbes.submissions.t5.pages;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.tapestry5.util.EnumSelectModel;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.announcement.Announcement;
import mil.dtic.utility.announcement.AnnouncementService;
import mil.dtic.utility.announcement.exception.AnnouncementException;
import mil.dtic.utility.announcement.options.Audience;


/**
 * EmailAnnouncement.java is responsible for providing UI properties
 * to support various UI components. It stores the values submitted
 *
 */
@Import(library = { "context:js/emailAnnouncement.js" })
@Secured({"ROLE_R2AppMgr"})
public class EmailAnnouncement extends T5Base{
    private static final Logger log = CbesLogFactory.getLog(EmailAnnouncement.class);
    private static String OK = "OK";
    private static String OK_MSG = "Successfully processed latest email announcement";
    private static String SUBJECT_PREFIX = "[CXE Announcement]: ";

    
    @Inject
    @Property
    private AnnouncementService announcementService;
    
    @Inject
    private ConfigService configService;

    @Persist
    @Property
    private Audience audience;
    
    @Inject
    private JavaScriptSupport javaScriptSupport;

    @Persist
    @Property
    private String addOnEmail;
    
    @Persist
    @Property
    private String subject;
    
    @Persist
    @Property
    private String content;

    @Persist
    @Property
    private String sender;

    @Persist
    @Property
    private String statusMsg;
    
    @Inject
    private org.apache.tapestry5.ioc.Messages messages;
    
    /**
     * options is the model for the audience selection.
     * @return SelectModel
     */
    public SelectModel getOptions() {
        return new EnumSelectModel(Audience.class, messages);
    }
    
    /**
     * provides a sender default email address if the UI to provide it.
     */
    void onPrepare(){
        
        if (this.sender == null){
            this.sender =configService.getEmailFrom();
        }
    }

    /**
     * initiate backend processing of announcemt email.
     * @param context - String (not used)
     */
    public void onSuccess(String context) {

        //Announcement is immutable, so we need to modify the subject content before we construct it.
        if (this.subject != null){
            if (!this.subject.contains(EmailAnnouncement.SUBJECT_PREFIX)){
                this.subject = EmailAnnouncement.SUBJECT_PREFIX + this.subject;
            }
        }
        
        Announcement announcement = new Announcement(this.audience, this.addOnEmail, this.subject, this.content, this.sender);
        
        try{
            statusMsg = announcementService.validate(announcement);
            log.debug("validation result: " + statusMsg);
            if (statusMsg.equals(EmailAnnouncement.OK)){
                statusMsg = EmailAnnouncement.OK_MSG;
                this.addOnEmail = null;
                this.subject = null;
                this.content = null;
            }
        }
        catch(AnnouncementException ae){
            log.error("failure to process announcement: " + ae.getMessage());
        }
    }
    
    void afterRender() {
        javaScriptSupport.addScript("setup();");
        this.statusMsg = "";
      }
    
}
