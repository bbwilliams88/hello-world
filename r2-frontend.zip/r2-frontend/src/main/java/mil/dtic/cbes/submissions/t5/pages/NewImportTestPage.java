package mil.dtic.cbes.submissions.t5.pages;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Constants.XML_RESOURCES_SOURCE;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

@Import(
  stack   = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DROPZONESTACK },
  library = { "context:/js/newR2xmltools.js", "context:/js/xmlImport.js" })
public class NewImportTestPage extends T5Base {

  @Property
  @Persist
  private File workingDirectory;

  private static final Logger log = CbesLogFactory.getLog(NewImportTestPage.class);

  public void onActivate() {
    if (workingDirectory==null)
    {
      log.debug("*** Start creating working folder.");
      try
      {
        workingDirectory = createWorkingFolder();
      } catch (IOException ex)
      {
        log.error("Couldn't create working folder.", ex);
      }
    }
  }

  public StreamResponse onDownloadSchemaPackage() throws IOException
  {
    File xmlPackageFile = null;
    InputStream xmlPackageFileInputStream = null;
    XML_RESOURCES_SOURCE xmlResourcesLoadFrom = BudgesContext.getConfigService().getXmlResourcesLoadFrom();
    if (XML_RESOURCES_SOURCE.CLASSPATH.equals(xmlResourcesLoadFrom))
    {
      ClassLoader cl = NewR2XmlTools.class.getClassLoader();
      if (cl != null)
      {
        xmlPackageFileInputStream = new BufferedInputStream(cl.getResourceAsStream(Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME));
      }
    }
    else if (XML_RESOURCES_SOURCE.FILESYSTEM.equals(xmlResourcesLoadFrom))
    {
      String baseDirName = BudgesContext.getConfigService().getXmlResourceBaseDir();
      xmlPackageFile = new File(baseDirName, Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME);
      if (xmlPackageFile.exists())
      {
        xmlPackageFileInputStream = new BufferedInputStream(new FileInputStream(xmlPackageFile));
      }
      else
      {
        log.error("Comptroller XML Package file does not exist: " + xmlPackageFile);
      }
    }

    if (xmlPackageFileInputStream == null)
    {
      log.error ("Unable to download the Comptroller XML Package file");
      return null;
    }
    else
    {
      log.debug("Downloading Comptroller XML Package from " + xmlResourcesLoadFrom);
      return getStreamResponse(xmlPackageFileInputStream, BudgesContentType.ZIP.getMimeType(), Constants.R2_SCHEMA_PACKAGE_ZIP_FILE_NAME);
    }
  }
}
