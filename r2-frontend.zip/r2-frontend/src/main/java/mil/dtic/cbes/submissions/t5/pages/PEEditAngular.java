package mil.dtic.cbes.submissions.t5.pages;

import java.util.Date;

import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.submissiondate.SubmissionDateProcessorFactory;

@Import(library = {"js/jquery-ui.min.js", "js/bootstrap.min.js", "js/jquery.form.js", "js/angular.js", "js/peeditangular.js", "js/jquery.dataTables.js"},
        stylesheet = {"css/jquery-ui.css", "context:/css/r2.css", "css/bootstrap.min.css"})
public class PEEditAngular extends T5Base
{
  @Inject
  private JavaScriptSupport jsSupport;

  @Inject
  private ProgramElementDAO peDao;

  private ProgramElement pe;

  private String errorMessage;

  void onActivate(String peNumber) {
    Integer peID = null;
    try
    {
      peID = Integer.parseInt(peNumber);
    }
    catch (NumberFormatException e)
    {
      errorMessage = "Invalid program element ID number.";
      return;
    }
    pe = peDao.findById(peID);
    if(pe == null) {
      errorMessage = "Program element not found.";
      return;
    }
    
    if(!getUserCredentials().viewPeAllowed(pe)) {
      errorMessage = "User does not have permission to view this PE.";
    }
    else {
        Date date = SubmissionDateProcessorFactory.getSubmissionDateProcessor().getDate(pe.getBudgetCycleAndYear());
        pe.setSubmissionDate(date);
        
    }
  }

  // void afterRender() {
  //   if(errorMessage == null) {
  //     JSONObject peJson = PeJson.jsonFromProgramElement(pe, getCurrentBudgesUser().getCsrfToken());
  //     peJson.put("showTest", getUserCredentials().checkPrivilege(Privilege.SHOW_TEST_PE));
  //     peJson.put("userRole", getCurrentBudgesUser().getRole());
  //     peJson.put("showUnlock", (getUserCredentials().isLockedByMe(pe) || (pe.getLockedBy() != null && getUserCredentials().editPeUsersAllowed(pe))));
  //     peJson.put("isFrozen", (pe.getEntirePeLockedBy() != null));
  //     if(pe.getEntirePeLockedBy() != null){
  //   	  peJson.put("frozenBy", (pe.getEntirePeLockedBy().getFullName()));
  //     }
  //     peJson.put("showProjectButtons", (
  //   		  !(pe.getEntirePeLockedBy() != null && pe.getEntirePeLockedBy().getId().equals(getCurrentBudgesUser().getId()))
  //   		  || !getCurrentBudgesUser().getRole().equals("R2User")));
  //     jsSupport.addScript("setPeData(%s, %d);", peJson, getCurrentBudgesUser().getId());
  //   } else {
  //     JSONObject errorJson = NewR2Endpoint.createErrorResponse(errorMessage);
  //     jsSupport.addScript("setPeData(%s, %d);", errorJson, getCurrentBudgesUser().getId());
  //   }
  // }
}
