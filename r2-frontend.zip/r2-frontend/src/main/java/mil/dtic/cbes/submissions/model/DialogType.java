package mil.dtic.cbes.submissions.model;

/**
 * Enumeration for type of modal dialog. Used by the Dialog component. An alert
 * dialog only has one button (to accept the dialog) and a confirm dialog has
 * two buttons (to accept/cancel the action).
 */
public enum DialogType
{
    ALERT, CONFIRM;
}
