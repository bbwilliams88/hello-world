package mil.dtic.cbes.submissions.t5.components;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.poi.POIXMLProperties.CoreProperties;
import org.apache.poi.POIXMLProperties.CustomProperties;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tapestry5.ContentType;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SetupRender;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.Response;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;

import mil.dtic.cbes.prcp.PRCPDataFileService;
import mil.dtic.cbes.service.SYSUploadServiceImpl;
import mil.dtic.cbes.submissions.ValueObjects.R1Data;
import mil.dtic.cbes.submissions.ValueObjects.SYSFile;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.service.P1R1Service;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.Util;

@Import( stack   = { CbesT5SharedModule.DROPZONESTACK },
library = { "context:/js/PrcpUpdate.js" })
public class PrcpUpdate extends T5Base {

  private static final Logger log = CbesLogFactory.getLog(PrcpUpdate.class);
  
  @Inject
  private Request request;
  @Inject
  private MultipartDecoder decoder;
  @Inject
  private SYSUploadServiceImpl budgetFileUploadService;
  @Inject
  private P1R1Service p1R1Service;
  
  private PRCPDataFileService prcpDataFileService = new PRCPDataFileService(budgetFileUploadService);
  
  @Property
  private String r1PRCPTimestamp = StringUtils.EMPTY;

  @Property
  private String p1PRCPTimestamp = StringUtils.EMPTY;

  @Property
  private String r1PRCPFilename = StringUtils.EMPTY;

  @Property
  private String p1PRCPFilename = StringUtils.EMPTY;
  
  @Property
  private int currentR1Cnt = 0;
  
  @Property
  private int previousR1Cnt = 0;
  
  private List<R1Data> PreviousPB_r1Rows;
  private List<R1Data> CurrentPB_r1Rows;
  
  @SetupRender
  public void onSetupRender() {
    try {
      SYSFile r1 = prcpDataFileService.getPrcpR1DataFile();
      r1PRCPTimestamp = r1.getDateString();
      r1PRCPFilename = r1.getName();
      
      log.debug("set R1 timestamp to " + r1.getDateString() + ", filename to " + r1.getName());
    } catch (FileNotFoundException e) {
      log.warn("No R-1 PRCP data available");
    }
    try {
      SYSFile p1 = prcpDataFileService.getPrcpP1DataFile();
      p1PRCPTimestamp = p1.getDateString();
      p1PRCPFilename = p1.getName();
      log.debug("set P1 timestamp to " + p1.getDateString() + ", filename to " + p1.getName());
    } catch (FileNotFoundException e) {
      log.warn("No P-1 PRCP data available");
    }
    
    R1Counts();
  }

  /**
   * End point for accepting prcp update files.
 * @throws IOException 
   *
   */
  public JSONObject onPrcpUpdate() throws IOException {
    log.debug("Start PRCP Update");
    
    if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
      log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
      + ", expected " + getCurrentBudgesUser().getCsrfToken());
      JSONObject rootObj = new JSONObject();
      rootObj.put("error", "Attempted to upload file without proper authorization");
      return rootObj;
    }

    // verify that the user has appropriate privileges to update PRCP data
    if (!getUserCredentials().getPrivs().showAdminTools()) {
      JSONObject rootObj = new JSONObject();
      rootObj.put("error", "User does not have permission to update PRCP data.");
      return rootObj;
    }
    File sandboxFile = null;
    UploadedFile upFile = null;

    upFile = decoder.getFileUpload("file");
    
    // write the uploaded file to our sandbox
    sandboxFile = writeFileToSandbox(upFile);
    if (sandboxFile == null) {
      JSONObject rootObj = new JSONObject();
      rootObj.put("error", "Unable to save uploaded file to sandbox on server for verification.");
      return rootObj;
    }
    
    // Save the P1/R1 file to the database  
    int prcp_type=0;
    if(upFile.getFileName().substring(5,upFile.getFileName().indexOf(".")).toLowerCase().equals("p1")){
      prcp_type=1;
    }else{
      if(upFile.getFileName().substring(5,upFile.getFileName().indexOf(".")).toLowerCase().equals("r1")){ 
      prcp_type=2; 
      }
    }
    
    String fname = upFile.getFileName();
    int budget_year = Integer.parseInt(fname.substring((fname.lastIndexOf(".") - 7), (fname.lastIndexOf(".") - 3)));
    
    p1R1Service.process(prcp_type, sandboxFile.getAbsolutePath(), budget_year);

    // record the upload in long term storage
    /**    
    InputStream upFileStream = upFile.getStream();
    XSSFWorkbook upWorkbook = new XSSFWorkbook(upFileStream);
    org.apache.poi.POIXMLProperties props = upWorkbook.getProperties();
    CustomProperties custProp = props.getCustomProperties();
    CTProperty downloadedDate = custProp.getProperty("prcpDownloadDate");
    DateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
    Date date = null;
	try {
		date = format.parse(downloadedDate.getLpwstr());
	} catch (ParseException e) {
		log.warn("DateFormat Parse error in onPRCPUpdate()");
	}
    if (!prcpDataFileService.storeUploadedPRCPUpdateFile(sandboxFile, upFile.getFileName(),
        getCurrentUser().getUsername(), date)) {
      JSONObject rootObj = new JSONObject();
      rootObj.put("error", "PRCP data updated, but spreadsheet file could not be saved on the server.");
      upWorkbook.close();
      upFileStream.close();
      return rootObj;
    }
    upWorkbook.close();
    upFileStream.close();

    // success, inform user
    JSONObject rootObj = new JSONObject();
    rootObj.put("success", "PRCP Updated.");
    if (upFile.getFileName().contains("_R1")) {
      r1PRCPTimestamp = downloadedDate.getLpwstr();
      r1PRCPFilename = upFile.getFileName();
      rootObj.put("r1PrcpTimestamp", r1PRCPTimestamp);
      rootObj.put("r1PrcpFilename", r1PRCPFilename);
    }
    if (upFile.getFileName().contains("_P1")) {
      p1PRCPTimestamp = downloadedDate.getLpwstr();
      p1PRCPFilename = upFile.getFileName();
      rootObj.put("p1PrcpTimestamp", p1PRCPTimestamp);
      rootObj.put("p1PrcpFilename", p1PRCPFilename);
    }
  */
    JSONObject jsonObject = new JSONObject();
    jsonObject.append("p1Uploaded", prcp_type == 1 ? true : false);
    return jsonObject;
  }
  
  public Object onActionFromR1CurrentDelete() {
    if (!getUserCredentials().getPrivs().showAdminTools()) {
      return null;
    }
    
    int bYear = Util.getCurrentBudgetCycle().getBudgetYear();
    BudgesContext.getR1DataDAO().deleteData(bYear);
    try {
      budgetFileUploadService.deleteFile(prcpDataFileService.getPrcpR1DataFile().getId());
    } catch(FileNotFoundException e) {
      log.warn("R1 data file doesn't exist");
    }
    return null;
  }
  
  public void R1Counts() {
	    int bYear = Util.getCurrentBudgetCycle().getBudgetYear();
	    this.PreviousPB_r1Rows = BudgesContext.getR1DataDAO().findByProperty(R1Data.BUDGET_YEAR, bYear-1);
	    this.CurrentPB_r1Rows = BudgesContext.getR1DataDAO().findByProperty(R1Data.BUDGET_YEAR, bYear);
	    previousR1Cnt = this.PreviousPB_r1Rows.size();
	    currentR1Cnt = this.CurrentPB_r1Rows.size();
  }
  
  public Object onActionFromR1PreviousDelete() {
	    if (!getUserCredentials().getPrivs().showAdminTools()) {
	      return null;
	    }
	    int bYear = Util.getCurrentBudgetCycle().getBudgetYear();
	    BudgesContext.getR1DataDAO().deleteData(bYear-1);

	    try {
	      budgetFileUploadService.deleteFile(prcpDataFileService.getPrcpR1DataFile().getId());
	    } catch(FileNotFoundException e) {
	      log.warn("R1 data file doesn't exist");
	    }
	    return null;
	  }
  
  public Object onActionFromP1Delete() {
    if (!getUserCredentials().getPrivs().showAdminTools()) {
      return null;
    }
    
    BudgesContext.getP1DataDAO().deleteData();
    try {
      budgetFileUploadService.deleteFile(prcpDataFileService.getPrcpP1DataFile().getId());
    } catch(FileNotFoundException e) {
      log.warn("P1 data file doesn't exist");
    }
    return null;
  }

  /**
   * Endpoint for downloading prcp r1 file.
   *
   * @return
   *
   */
  public StreamResponse onActionFromPRCPR1Download() {
    PRCPDataFileService prcpDataFileService = new PRCPDataFileService(budgetFileUploadService);
    StreamResponse response = null;
    try {
      SYSFile r1file = prcpDataFileService.getPrcpR1DataFile();
      response = readPRCPFileToResponse(r1file);
    } catch (FileNotFoundException e) {
      log.warn("Unable to read r1", e);
    }
    return response;
  }

  /**
   * Endpoint for downloading the prcp p1 file.
   *
   * @return
   */
  public StreamResponse onActionFromPRCPP1Download() {
    PRCPDataFileService prcpDataFileService = new PRCPDataFileService(budgetFileUploadService);
    StreamResponse response = null;
    try {
      SYSFile p1file = prcpDataFileService.getPrcpP1DataFile();
      response = readPRCPFileToResponse(p1file);
    } catch (FileNotFoundException e) {
      log.warn("Unable to read p1", e);
    }
    return response;
  }

  /**
   * Reads a prcp file on disk, and prepares the data for file transfer to
   * user.
   */
  private StreamResponse readPRCPFileToResponse(SYSFile prcpSysFile) {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try {
      File prcpFile = new File(prcpSysFile.getFileURI());
      byte[] bytes = FileUtil.getByteArrayFromFile(prcpFile);
      outputStream.write(bytes);
    } catch (IOException e) {
      log.error("Unable to prepare r1 prcp data for download", e);
    }
    /**
     * Implement Tapestry's StreamResponse interface for an Excel spreadsheet
     */
    StreamResponse response = new StreamResponse() {
      public String getContentType() {
        // TODO Just something to check back up on
        return new ContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=utf-8").toString();
      }
      public InputStream getStream() throws IOException {
        return new ByteArrayInputStream(outputStream.toByteArray());
      }
      public void prepareResponse(Response response) {
        response.setHeader("Content-Disposition", "attachment; filename="+prcpSysFile.getName());
      }
    };
    return response;
  }

  /**
   * Write a file to our temporary sandbox.
   *
   * @param upFile
   * @return
   */
  private File writeFileToSandbox(UploadedFile upFile) {
    File sandboxDir = new File(BudgesContext.getConfigService().getVscanSandboxFolder());
    File sandboxFile = null;
    if (upFile != null) {
      try {
        // move file to sandbox
        String sfx = FilenameUtils.getExtension(upFile.getFileName());
        if (sfx.length() > 0)
          sfx = "." + sfx;
        else
          sfx = null; // .tmp
        sandboxFile = File.createTempFile("BudgetUpload", sfx, sandboxDir);
        upFile.write(sandboxFile);
      } catch (IOException e) {
        log.error("Unable to save uploaded file to sandbox", e);
      }
    }
    return sandboxFile;
  }
  
  public boolean isAppManager() {
    return getCurrentBudgesUser().getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN);
  }
}

