package mil.dtic.cbes.submissions.t5.components;

//import java.math.BigDecimal;
//import java.util.Set;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

//import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
//import mil.dtic.utility.BigDecimalUtil;
import mil.dtic.cbes.submissions.ValueObjects.QuarterDate;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleDetail;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.ValueObjects.SubProjectSchedule;


public class R4ExhibitWeb
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  @Property
  private SubProjectSchedule SPSchedule;
  @Property
  private ScheduleDetail SPDetails;
  @Property
  private QuarterDate qDate;
  @Property
  private ScheduleProfile schedProfile;
  
  public int addIntegers(int intOne, int intTwo)
  {
      return intOne + intTwo;
  }
  public String ganttCssClass(ProgramElement pe, QuarterDate start, QuarterDate end) {
    int begin;
    int length;
    if (start.getYear() + 2 < pe.getBudgetYear()) {
      begin = 0;
    } else {
      begin = (start.getYear() - pe.getBudgetYear() + 2) * 4;
      begin = begin + start.getQuarter() - 1;
    }
    if (start.getYear() + 2 < pe.getBudgetYear()) {
      length = (end.getYear() - (pe.getBudgetYear() - 2)) * 4;
      length = length + end.getQuarter();
    } else {
      length = (end.getYear() - start.getYear()) * 4;
      length = length + (end.getQuarter() - start.getQuarter()) + 1;
    }
    return "r4gantt-" + Integer.toString(begin) + "-" + Integer.toString(length);
  }
  public String r4ImageUrl(ScheduleProfile theProfile) {
    return "/r2/R4ScheduleProfileImage/" + theProfile.getId();// + "/" + theProfile.getImageFileName();
  }
}