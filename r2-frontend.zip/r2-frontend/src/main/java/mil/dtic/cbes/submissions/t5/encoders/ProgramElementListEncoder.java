package mil.dtic.cbes.submissions.t5.encoders;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.utility.CbesLogFactory;

public class ProgramElementListEncoder implements ValueEncoder<ProgramElementList>{

    private static final Logger log = CbesLogFactory.getLog(ProgramElementListEncoder.class);

    private final Map<String, ProgramElementList> peMap = new HashMap<>();

    public ProgramElementListEncoder(Collection<ProgramElementList> peList)
    {
        if (peList == null) throw new IllegalArgumentException();
        for (ProgramElementList pel : peList)
        {
            peMap.put(pel.getId().toString(), pel);
        }
        log.debug("Constructed Encoder Map");
    }

    @Override
    public String toClient(ProgramElementList value) {
        return value.getId().toString();
    }

    @Override
    public ProgramElementList toValue(String clientValue) {
        return peMap.get(clientValue);
    }
}
