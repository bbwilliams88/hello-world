package mil.dtic.cbes.submissions.t5.components;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.FormatFlag;
import mil.dtic.cbes.submissions.ValueObjects.CongressionalAddDetail;
import mil.dtic.cbes.submissions.ValueObjects.OtherAdjustmentDetail;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BigDecimalUtil;

public class R2ExhibitWeb extends T5Base
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Property
  private Project PEProject;
  @Property
  private CongressionalAddDetail CongressAdd;
  @Property
  private OtherAdjustmentDetail PEOtherAdjustmentDetail;
  @Property
  private ServiceAgency serviceAgency;

  public int addIntegers(int intOne, int intTwo)
  {
    return intOne + intTwo;
  }

  public List<ServiceAgency> getServiceAgencies()
  {
    return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
  }
  public int yearFromDate(Date theDate)
  {
    // Template should look like:
    // ${addIntegers(yearFromDate(PEBase.submissionDate), -1}
    SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
    String s = yearFormat.format(theDate);
    return Integer.valueOf(s);
  }
  public boolean isValidR3toR5() {
    return Arrays.asList(Constants.VALID_R3_to_R5_BA_NUMS).contains(PEBase.getBudgetActivity().getNumber());
  }
  public BigDecimal projectCongressionalAddsSubtotal(Set<CongressionalAddDetail> addDetails, String year) {
    BigDecimal sumTotal = new BigDecimal("0.000");
    
    if(year != null && !StringUtils.isEmpty(year)){
        if (year.equals("py")) {
          for (CongressionalAddDetail addDetail : addDetails)
          {
            sumTotal = BigDecimalUtil.add(sumTotal, addDetail.getFundingPy());
          }
        }
        if (year.equals("cy")) {
          for (CongressionalAddDetail addDetail : addDetails)
          {
            sumTotal = BigDecimalUtil.add(sumTotal, addDetail.getFundingCy());
          }
        }
    }
    return sumTotal;
  }
  public String dashIfNullOrZero(BigDecimal aValue) {
    if (aValue == null) {
      return "-";
    } else if (BigDecimalUtil.equals(aValue, new BigDecimal("0.000"))){
      return "-";
    }
    else {
      return aValue.toString();
    }
  }
  public boolean isR2Long() {
    if (PEBase.getFormat() == FormatFlag.R2Long) {
      return true;
    } else {
      return false;
    }
  }
  
  /*only called to get project when exhibit is R2Long*/
  public Project firstProject() {
    for (Project onlyProject : PEBase.getProjects()) {
      return onlyProject;
    }
    //this next part was to address cxe-4424
    //it is designed to fix a npe I can't reproduce. 
    Project newProject = new Project();
    if (PEBase.getProjects() == null){
      PEBase.setProjects(new LinkedHashSet<Project>(1));
    }
    PEBase.getProjects().add(newProject);
    return newProject;
  }
}
