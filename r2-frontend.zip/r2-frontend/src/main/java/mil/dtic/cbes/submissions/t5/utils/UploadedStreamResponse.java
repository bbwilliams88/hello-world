package mil.dtic.cbes.submissions.t5.utils;

import java.io.IOException;
import java.io.InputStream;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.services.Response;


public class UploadedStreamResponse implements StreamResponse
{
  private final UploadedFileInfo uf;
  private final InputStream is;

  public UploadedStreamResponse(UploadedFileInfo uf, InputStream is)
  {
    if (uf==null) throw new NullPointerException();
    if (is==null) throw new NullPointerException();
    this.uf = uf;
    this.is = is;
  }

  public String getContentType()
  {
    return uf.getContentType();
  }

  public InputStream getStream() throws IOException
  {
    return is;
  }

  public void prepareResponse(Response arg0)
  {
    arg0.setHeader("Content-Disposition", "attachment; filename=" + uf.getFileName());
    arg0.setHeader("Expires", "0");
    arg0.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
    arg0.setHeader("Pragma", "public");
    arg0.setContentLength((int)uf.getSize());
  }
}