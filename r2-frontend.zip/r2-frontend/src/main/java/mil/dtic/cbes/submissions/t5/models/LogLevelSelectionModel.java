package mil.dtic.cbes.submissions.t5.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.util.AbstractSelectModel;

public class LogLevelSelectionModel extends AbstractSelectModel {
        private List<OptionModel> optionModels;

    public LogLevelSelectionModel(Level[] levels)
    {
        optionModels = new ArrayList<OptionModel>(levels.length);
        for (int i = 0; i < levels.length; i++)
        {
           optionModels.add(new OptionModelImpl(levels[i].name(), levels[i]));
        }
    }

    public List<OptionGroupModel> getOptionGroups() {return null;}

    public List<OptionModel> getOptions()
    {
      return this.optionModels;
    }
}
