package mil.dtic.cbes.submissions.t5.pages;

import javax.servlet.http.HttpServletRequest;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.utility.CbesLogFactory;

public class BusinessRuleWarningsJson extends NewR2Endpoint {
  private static final Logger log = CbesLogFactory.getLog(BusinessRuleWarningsJson.class);
  @Inject
  private HttpServletRequest request;

  @Log
  TextStreamResponse onActivate(String peNumber) {
    JSONObject responseObject = new JSONObject();
    try {
      ProgramElement pe = getRequestedPe(peNumber);
      
      String hasWarnings = "The program element has business rule violations.";
      String isValid = "The program element is valid.";
      responseObject = validateAndCreateResponse(responseObject, pe, isValid, hasWarnings);
      
      return new TextStreamResponse("application/json", responseObject.toString());
    } catch(ApiRequestException e) {
      return new TextStreamResponse("application/json", createErrorResponse(e.getMessage()).toString());
    }
  }
}
