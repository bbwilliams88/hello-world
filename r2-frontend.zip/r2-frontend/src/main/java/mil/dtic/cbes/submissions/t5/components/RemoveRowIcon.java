/*
 * $Id: PeIcon.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;


public class RemoveRowIcon
{
	  @Parameter(value="false") @Property @SuppressWarnings("unused")
	  private boolean hidden;

}
