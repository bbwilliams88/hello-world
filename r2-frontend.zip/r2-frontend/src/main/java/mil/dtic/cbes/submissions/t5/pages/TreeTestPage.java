/*
 * $Id: PRPCPage.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.pages;

import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

/**
 * This page presents a list of ProgramElementList, then saves to ProgramElement
 */
public class TreeTestPage
{
  private static final Logger log = CbesLogFactory.getLog(TreeTestPage.class);
}
