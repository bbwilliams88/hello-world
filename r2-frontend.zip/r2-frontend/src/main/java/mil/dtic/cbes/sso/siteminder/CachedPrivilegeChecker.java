package mil.dtic.cbes.sso.siteminder;

import java.util.HashMap;
import java.util.Map;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;

//Convenience class that just has privilege-checker methods
//Used by tapestry pages
public class CachedPrivilegeChecker
{
  private final UserCredentials creds;
  private Map<Integer,Boolean> savePeAllowedCache = new HashMap<Integer,Boolean>(2);
  
  public CachedPrivilegeChecker(UserCredentials creds) {
    this.creds = creds;
  }
  
  public boolean savePeAllowed(ProgramElementBase pe) {
    Boolean savePeAllowed = savePeAllowedCache.get(pe.getId());
    if (savePeAllowed==null) {
      savePeAllowed = creds.savePeAllowed(pe);
      savePeAllowedCache.put(pe.getId(), savePeAllowed);
    }
    return savePeAllowed;
  }
  
  public boolean showPeEditButtons(ProgramElementBase pe) {
    return savePeAllowed(pe);
  }
}
