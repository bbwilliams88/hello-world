package mil.dtic.cbes.submissions.t5.encoders;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.utility.CbesLogFactory;

public class LogLevelEncoder implements ValueEncoder<Level>{
    private Logger log = CbesLogFactory.getLog(LogLevelEncoder.class);
  
    private final Map<String, Level> levelMap = new HashMap<String, Level>();

    public LogLevelEncoder(Level[] levels)
    {
        if (levels==null) throw new IllegalArgumentException();
        for (Level level : levels)
        {
            levelMap.put(level.name(), level);
        }
        log.debug("constructed");
    }


    public String toClient(Level value)
    {
        return value.name();
    }


    public Level toValue(String keyAsString)
    {
        log.debug("toValue " + keyAsString);
        return levelMap.get(keyAsString);
    }
}
