/**
 * NewActivityJson is a javascript call, specifically from
 * newJbWizard.js and newR2Create.js. user browser setting should be 
 * set to "every time you visit a webpage" for the data package
 * in this class to be renewed.  Generally not likely, but very much
 * so now that super admin can change objects that rarely if at all change. 
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.util.List;

import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;

import mil.dtic.cbes.submissions.ValueObjects.Appropriation;
import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.PeSuffix;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.AppropriationDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;

public class NewActivityJson extends T5Base
{
  @Inject
  private ServiceAgencyDAO saDao;
  @Inject
  private AppropriationDAO appDao;

  /*
    This endpoint takes a long time (2 minutes) to send a response on local, which causes 
    problems in the create R2 page. This issue along with details and fixes has been documented 
    on the CXE TroubleShooting Issues wiki page, and the Jira ticket CXE-8031. 
    Please refer to those for more information.
  */
  TextStreamResponse onActivate()
  {
    JSONObject responseObject = new JSONObject();
    JSONArray agencies = new JSONArray();
    List<ServiceAgency> availableRdteAgencies = getUserCredentials().getUserInfo().getAvailableRdteAgencies();
    for (ServiceAgency agency : availableRdteAgencies) {
      JSONObject agencyObject = new JSONObject();
      agencyObject.put("name", agency.getName());
      agencyObject.put("code", agency.getCode());
      agencyObject.put("id", agency.getId());
      JSONArray suffixes = new JSONArray();
      // the demo agency can use any available agency or service suffix
      if (agency.getCode().equalsIgnoreCase("DEMO")) {
        availableRdteAgencies.stream()
            .map(ara -> saDao.merge(ara).getSuffixes())
            .flatMap(pesset -> pesset.stream())
            .forEach(pesuffix -> suffixes.put(pesuffix.getSuffix()));
      }
      else {
        for (PeSuffix aSuffix : saDao.merge(agency).getSuffixes()) {
          suffixes.put(aSuffix.getSuffix());
        }
      }
      agencyObject.put("suffixes", suffixes);
      JSONArray appropriations = new JSONArray();
      for (Appropriation appropriation : saDao.merge(agency).getRDTEAppropriations()) {
        JSONObject appropriationObject = new JSONObject();
        appropriationObject.put("code", appropriation.getCode());
        appropriationObject.put("name", appropriation.getName());
        appropriationObject.put("codeplusname", appropriation.getCodePlusName());
        appropriationObject.put("id", appropriation.getId());
        JSONArray activities = new JSONArray();
        for (BudgetActivity activity : appDao.merge(appropriation).getRDTEBudgetActivities()) {
          JSONObject activityObject = new JSONObject();
          activityObject.put("number", activity.getNumber());
          activityObject.put("title", activity.getTitle());
          activityObject.put("id", activity.getId());
          activities.put(activityObject);
        }
        appropriationObject.put("budgetactivities", activities);
        appropriations.put(appropriationObject);
      }
      agencyObject.put("appropriations", appropriations);
      agencies.put(agencyObject);
    }

    responseObject.put("agencies", agencies);
    return new TextStreamResponse("application/json", responseObject.toCompactString());
  }
}
