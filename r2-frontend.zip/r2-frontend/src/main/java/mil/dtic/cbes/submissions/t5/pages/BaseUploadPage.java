package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.upload.services.UploadedFile;

import mil.dtic.cbes.service.BudgetFileUploadService;
import mil.dtic.cbes.service.ValidationException;
import mil.dtic.cbes.service.ValidationMessage;
import mil.dtic.cbes.submissions.ValueObjects.UploadedBudgetFile;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.t5.base.T5Base;

public abstract class BaseUploadPage<F extends UploadedBudgetFile> extends
		T5Base {

	@Component
	protected Form uploadForm;

	@Property
  protected UploadedFile file;

	@Property
	protected String description;

	private F uploadedBudgetFile;

	public abstract BudgetFileUploadService<F> getBudgetFileUploadService();

	public void onSuccess() {

	}

	public void onValidateFromUploadForm() {
		//String fileName = file.getFileName();
		//String fileExtension = fileName
		//		.substring(fileName.lastIndexOf('.') + 1).toLowerCase();

		R2Storage r2Storage = new R2Storage("BudgetUpload");
		//File sandboxFile = new File(BudgesContext.getConfigCAO().getVscanSandboxFolder()
		//		+ "/" + r2Storage.leSystemPrefix() + "." + fileExtension);
    try {
      File sandboxFile = r2Storage.createTempFileInSandbox(FilenameUtils.getExtension(file.getFileName()));
      file.write(sandboxFile);
      getBudgetFileUploadService().saveNewFile(sandboxFile, file.getFileName(), getCurrentUser().getUsername(), description, null);
		} catch (ValidationException e) {
			List<ValidationMessage> errors = e.getErrors();
			for (ValidationMessage error : errors) {
				uploadForm.recordError(error.getMessage());
			}
		} catch (IOException e) {
			uploadForm
					.recordError("There was an error saving the Uploaded file, please contact system administrator");
		}
	}

//	public abstract UploadedBudgetFileStreamResponse<F> onActionFromDownload(
//			Integer id);

//	public void onActionFromDelete(Integer id) {
//		getBudgetFileUploadService().deleteFile(id);
//	}

	public List<F> getFileList() {
		return getBudgetFileUploadService().getAllFiles();
	}

	public F getUploadedBudgetFile() {
		return uploadedBudgetFile;
	}

	public void setUploadedBudgetFile(F uploadedBudgetFile) {
		this.uploadedBudgetFile = uploadedBudgetFile;
	}

	public UploadedFile getFile2() {
		return file;
	}

	public Form getUploadForm2() {
		return uploadForm;
	}
}
