/*
 * $Id$
 */
package mil.dtic.cbes.submissions.validation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.TerminationLiability;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class ValidationHelper {
	private static final String DEMO_AGENCY_SUFFIX = "DEMO";
	private static final Logger log = CbesLogFactory.getLog(ValidationHelper.class);

	/** Validate PE Number format and uniqueness in db, return list of errors */
  public static List<String> validatePENum(String peNum, BudgetCycle budgetCycle, BudgetActivity ba, Boolean isTest)
  {
    List<String> errors = new ArrayList<String>(5);
    Pattern peRegex = Pattern.compile("^[0-9A-Za-z\\(\\)\\[\\]\\-\\_\\#\\@\\:\\.\\s]*$", Pattern.CASE_INSENSITIVE);
	  Matcher matcher = peRegex.matcher(peNum);
    if (StringUtils.isEmpty(peNum))
    {
      errors.add("PE number is required.");
      return errors;
    }
    else if (peNum.length() < Constants.MIN_LENGTH_PENUM)
    {
      errors.add("PE number must be at least " + Constants.MIN_LENGTH_PENUM + " characters in length.");
    }
    else if (peNum.length() > 40)
    {
    	errors.add("PE number length can not be greater than 40.");
    }
    else if (!matcher.find()) 
    {
    	errors.add("The program element number contains invalid characters.");
    }
//    else
//    {
//      try
//      {
//        int intValue = Integer.parseInt(peNum.substring(0, 7));
//        log.debug("The first 7 characters of PE number: " + intValue);
//      }
//      catch (NumberFormatException e)
//      {
//        errors.add("The first 7 characters of PE number must be a numeric value.");
//      }
//    }

    ProgramElementDAO peDAO = BudgesContext.getProgramElementDAO();
    List<ProgramElement> pe = peDAO.findByBusinessIdIncludingApp(budgetCycle.getCycle(), budgetCycle.getBudgetYear(), peNum, ba.getNumber(), ba.getAppropriation().getCode(), isTest);

    if (pe.size() > 0)
    {
//      errors.add("Same PE number for Budget Cycle '" + budgetCycle.getValue() + "' and Budget Activity '" + ba + "' already exists.");
      errors.add(String.format("Same PE Number for Budget Cycle '%s', Budget Activity '%s', and Appropriation '%s' already exists.", budgetCycle.getValue(), ba, ba.getAppropriation().getCode()));
    }
    return errors;
  }

	/**
	 * Check pe suffix and add errors if necessary
	 *
	 * @return the agency matching peNum's suffix, or null
	 */
	public static ServiceAgency validatePESuffix(List<String> errors, UserCredentials creds, String peNum,
			boolean allowBad, boolean allowNotInYours, ServiceAgency peAgency) {
		/*
		 * // most suffixes correspond to only one agency, but a few services/agencies
		 * share a suffix so we have to start with a list List<ServiceAgency>
		 * suffixAgencies = null; ServiceAgency suffixAgency = null; //peRegex is used
		 * to verify that the suffix is uppercase Pattern peRegex =
		 * Pattern.compile("[A-Z0-9]{1,3}");
		 * 
		 * 
		 * if (peNum != null && peNum.length() >= Constants.MIN_LENGTH_PENUM) { // last
		 * 1-3 chars are agency suffix String suffix = peNum.substring(7);
		 * 
		 * suffixAgencies =
		 * BudgesContext.getServiceAgencyDAO().findByActivePeSuffix(suffix);
		 * 
		 * // narrow down the results for this suffix to a single agency // usually we
		 * want the first one; for multiple results we need to be sure we aren't
		 * discarding a valid // match for the agency listed in the PE
		 * if(suffixAgencies.size() > 1 && suffixAgencies.contains(peAgency)) {
		 * suffixAgency = peAgency; } else if(suffixAgencies.size() > 0) { suffixAgency
		 * = suffixAgencies.get(0); }
		 * 
		 * if (suffixAgency == null) { log.debug("no agency found for suffix in " +
		 * peNum); if (!allowBad) errors.add("The PE Number suffix \"" + suffix +
		 * "\" was not recognized as belonging to an agency."); } else if (!allowBad &&
		 * !peRegex.matcher(suffix).matches()){ errors.add("The PE Number \"" + peNum +
		 * "\" is not seven digits followed by the capitalized alphanumeric agency suffix."
		 * ); } else if (!allowBad && !StringUtils.equals(suffixAgency.getCode(),
		 * peAgency.getCode()) && !StringUtils.equals(peAgency.getCode(),
		 * DEMO_AGENCY_SUFFIX)) { log.debug("agency suffix '" + suffix +
		 * "' does not match selected agency '" + peAgency.getName() + "'");
		 * errors.add("The PE Number suffix \"" + suffix +
		 * "\" does not belong to the selected agency \"" + peAgency.getName() + "\".");
		 * } else { // check credentials log.debug("found agency " + suffixAgency +
		 * " for suffix " + peNum); if
		 * (!creds.getUserInfo().getBudgesUser().getAgencies().contains(suffixAgency)) {
		 * log.debug("agency is not one of user's agencies"); if (!(allowBad ||
		 * allowNotInYours)) errors.add("The PE Number suffix \"" + suffix +
		 * "\" does not belong to an agency you are a member of."); }
		 * 
		 * if (StringUtils.equals(peAgency.getCode(), DEMO_AGENCY_SUFFIX)) { // permit
		 * any known suffix with the demo agency List<ServiceAgency> rdteServiceAgencies
		 * = BudgesContext.getServiceAgencyDAO().findAllRDTE(); boolean matchesOneAgency
		 * = rdteServiceAgencies.stream() .map(a -> a.getSuffixes())
		 * .flatMap(Collection::stream) .anyMatch(s -> StringUtils.equals(s.getSuffix(),
		 * suffix));
		 * 
		 * if (matchesOneAgency) { suffixAgency = peAgency; } else {
		 * errors.add("The PE Number suffix \"" + suffix +
		 * "\" does not belong to any service agency."); suffixAgency = null; } } } }
		 */
		return peAgency;
	}

	public static void removeDisallowedData(ProgramElement pe) {
		log.debug("Removing disallowed data from pe " + pe);
		boolean R3toR5Allowed = Util.contains(Constants.VALID_R3_to_R5_BA_NUMS, pe.getBudgetActivity().getNumber());
		boolean articlesAllowed = Util.contains(Constants.VALID_ARTICLES_BA_NUMS, pe.getBudgetActivity().getNumber());

		for (Project project : pe.getProjects()) {
			if (!R3toR5Allowed) {
				log.debug("Removing R3, R4, R4a, R5 from pe " + pe);

				if (project.getR3Exhibit() != null) {
					project.getR3Exhibit().clearData();
					Util.setAuditFieldsForDeletedObject(project.getR3Exhibit());
				}
				if (project.getR4Exhibit() != null) {
					project.getR4Exhibit().clearData();
					Util.setAuditFieldsForDeletedObject(project.getR4Exhibit());
				}
				if (project.getR4aExhibit() != null) {
					project.getR4aExhibit().clearData();
					Util.setAuditFieldsForDeletedObject(project.getR4aExhibit());
				}
				// project.getR5Exhibit().clearData(); //r5 clearData does not work
				// thanks to hibernate

				if (project.getR5Exhibit() != null && project.getR5Exhibit().getTerminationLiability() != null) {
					TerminationLiability tl = project.getR5Exhibit().getTerminationLiability();
					BudgesContext.getTerminationLiabilityDAO().delete(tl);
					project.getR5Exhibit().setTerminationLiability(null);
					Util.setAuditFieldsForDeletedObject(project.getR5Exhibit());
				}
			}
			if (!articlesAllowed && project.getR2aExhibit() != null) {
				log.debug("Removing articles from project " + project);
				project.getR2aExhibit().setArticleCountPy(null);
				project.getR2aExhibit().setArticleCountCy(null);
				project.getR2aExhibit().setArticleCountBy1(null);
				project.getR2aExhibit().setArticleCountBy1Base(null);
				project.getR2aExhibit().setArticleCountBy1Ooc(null);
				project.getR2aExhibit().setArticleCountBy2(null);
				project.getR2aExhibit().setArticleCountBy3(null);
				project.getR2aExhibit().setArticleCountBy4(null);
				project.getR2aExhibit().setArticleCountBy5(null);
				if (CollectionUtils.isNotEmpty(project.getR2aExhibit().getAccomplishmentsPlannedPrograms())) {
					for (AccomplishmentPlannedProgram app : project.getR2aExhibit()
							.getAccomplishmentsPlannedPrograms()) {
						log.debug("Removing articles from a/pp " + app);
						app.setArticleCountPy(null);
						app.setArticleCountCy(null);
						app.setArticleCountBy1(null);
						app.setArticleCountBy1Base(null);
						app.setArticleCountBy1Ooc(null);
					}
				}
			}

			if (!Util.contains(Constants.BUDGET_CYCLE_BES_PBR_POM, pe.getBudgetCycle())
					&& project.getR2aExhibit() != null) {
				log.debug("Removing major performers from project " + project);
				project.getR2aExhibit().setMajorPerformersText(null);
				project.getR2aExhibit().setMajorPerformers(null);
			}
		}
	}

}
