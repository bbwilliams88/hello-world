/*
 * I don't know what goes here. ~Evan Sonderegger
 */
package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.tapestry.SendEmailOnInvalidXML;

public class NewR2Word extends NewR2Endpoint
{
    private static final Logger log = CbesLogFactory.getLog(NewR2Word.class);

    public StreamResponse onActivate(String programElementNumber)
    {
        try
        {
            ProgramElement programElement = getRequestedPe(programElementNumber);
            File           workingFolder  = createFileInUpload();
            String         filePath       = programElement.createWord(workingFolder, new SendEmailOnInvalidXML(getUserCredentials()), true);
            String         fileName       = FileUtil.createWordFileName("R2", programElement.getBusinessId());
            InputStream    inputStream    = new FileInputStream(filePath);

            // Tapestry will automatically close the input stream.
            return getStreamResponse(inputStream, BudgesContentType.WORD.getMimeType(), fileName);
        }
        catch (ApiRequestException | IOException | SQLException e)
        {
            log.error("Error during download of R2 PDF", e);

            return plainErrorResponse("Error during download of R2 PDF.");
        }
    }
}
