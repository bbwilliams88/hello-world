package mil.dtic.cbes.submissions.t5.components;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.EventLink;

import mil.dtic.utility.CbesLogFactory;

public class R2EmailEventButton
{
  private static final Logger log = CbesLogFactory.getLog(R2EventButton.class);

  @SuppressWarnings("unused")
  @Parameter(defaultPrefix = BindingConstants.LITERAL)
  @Property
  private String text;
  
  @SuppressWarnings("unused")
  @Component(publishParameters="anchor,context,disabled,event,zone", inheritInformalParameters=true)
  private EventLink eventLink;
}