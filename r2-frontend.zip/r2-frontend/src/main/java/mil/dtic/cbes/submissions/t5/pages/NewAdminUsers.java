package mil.dtic.cbes.submissions.t5.pages;

import java.net.URL;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.RequestParameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.RequestGlobals;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Lists;

import jnr.ffi.provider.NullMemoryIO;
import mil.dtic.cbes.data.config.StatusFlag;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.Role;
import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.sso.siteminder.ManageUsersContext;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.sso.siteminder.UserUtils;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.pages.userRole.UserRoleEditor;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;
import mil.dtic.utility.Util;
import mil.dtic.utility.sourcepath.SourcePath;
import mil.dtic.utility.sourcepath.SourcePathManagerImpl;
import netscape.ldap.LDAPException;

@SuppressWarnings({"deprecation", "unused"})
@Import(stack = {CbesT5SharedModule.DATATABLESBUTTONS}, library = {"context:/js/urlencoder.js", "context:/js/newAdminUsers.js"})
public class NewAdminUsers extends T5Base implements SourcePath{
    private static final Logger log = CbesLogFactory.getLog(NewAdminUsers.class);
    private static final boolean SUCCESS = true;
    private static final boolean FAILURE = false;
    private static final String SUCCESS_MESSAGES = "successMessages";
    private static final String ERROR_MESSAGES = "errorMessages";
    private static final String LDAP_CONNECTION_FAILURE = "failed to connect to server";
    private static final String MOCKED_USER_PROCESS = "Mocked user processed";

    // developers: you can change these values if you need to interface with mock ldap on local work station 
    private static final boolean PSUEDO_LDAP = true;
    private static final String PSEUDO_LDAP_MAIL = "john.b.hart.ctr@mail.mil";
  
    // mock user constants for adding a new user
    private static final String PSEUDO_LDAP_ID = "foxtwo0000";
    private static final String USING_MOCK_LDAP = "USING MOCK LDAP";
    private static final String MOCK_EMAIL_ADDRESS = "jhart@masslight.com";
    private static final String MOCK_PHONE_NUMBER = "703-767-8007";
    private static final String MOCK_ROLE = "R2User";
    private static final String MOCK_FULL_NAME = "Fox Two";
    private static final String MOCK_FIRST_NAME = "Fox";
    private static final String MOCK_LAST_NAME = "Two";
    private static final String MOCK_MIDDLE_INITIAL = "N";
    private static final String MOCK_DELETER = "hartj0000";
  
    //onDelete messaging constants
    private static final String USER_NOT_DELETED = "User with ID: %s not deleted";
    private static final String USER_SUCCESSFULLY_DELETED = "User with ID: %s was successfully deleted";
    private static final String USER_FAILED_TO_DELETE = "User with ID: %s failed to delete";
    private static final String USER_STATUS_NOT_DELETE = "User status was not changed to deleted";
  
    //onAdd messaging constants
    private static final String NO_LDAP_ACCT_ASSOC_WITH_LDAPID = "No LDAP account associated with ldapId: %s";
    private static final String NON_ADMIN_NULL_OR_INACTIVE_LDAP = "The user you attempted to add is associated | with other agencies than the ones you administer. | Please contact an Application Manager to add this user";
    private static final String SITE_ADMIN_CANNOT_ADD_DELETED_USERS = "Site Admins and Local Site Admins may not add deleted users, | please contact an Application Manager";
    private static final String FAILURE_TO_ADD = "Failed to add new user: %s to user_roles table, deleted entry in USER table";
    private static final String FAILURE_NOT_IN_APPROVED_LDAP_GRP = "User not in approved LDAP group";
    private static final String FAILURE_DUPLICATE = "User not added. Duplicate user found for user: %s";
    private static final String UNREGISTERED_LDAP_ID = "User not added. The LDAP ID is unregistered.";
    private static final String FAILURE_RUNTIME_EXCEPTION = "User not added, runtime exception error: %s";
    private static final String SUCCESSFULLY_ADDED_USER = "Successfully added user %s to R2 application";
    private static final String FAILURE_CANNOT_DELETE_SELF = "Users cannot delete themselves";
    
    private static final String[] props = new String[]{"userLdapId", "firstName", "lastName", "email", "role", "createPeAllowed", "createLiAllowed"}; 

    @Inject
    private ComponentResources resources;

    @Inject
    private JavaScriptSupport jsSupport;

    @Inject
    private RequestGlobals requestGlobals;

    private String sourceUrl;
    private String returnLabel;
    private boolean hasPath;
    private String sourcePath;
    private ManageUsersContext muc;
    private String userRole;
    
    @Property
    private boolean appMgr;
    
    private void setup() {
        muc = new ManageUsersContext(getUserCredentials());
        userRole = muc.getCreds().getUserInfo().getLdapUser().getR2Role();
    }

    void onActivate() {
        setup();
    }

    void onActivate(String path) {
        this.setSourcePath(path);
        BudgesContext.getSourcePathManager().createSource(this);
        setup();
    }

    void afterRender() {
        log.trace("afterRender - start");
        JSONObject links = new JSONObject("getUserTableUrl", resources.createEventLink("GetUserTable") + "", "editPePrivUrl",
            resources.createEventLink("EditPePriv") + "", "updateFromLdapURL", resources.createEventLink("UpdateLdapCache") + "", "addUserURL",
            resources.createEventLink("AddUser") + "", "deleteUserUrl", resources.createEventLink("DeleteUser") + "", "controller", userRole + "" 
        );
        jsSupport.addScript("setLinkUrls(%s);", links.toCompactString());
        jsSupport.addScript("pageInit();");
    }

    JSONObject onGetUserTable() {
        JSONObject responseObj = new JSONObject();

        log.trace("onGetUserTable: checking privilege.");
        if (getUserCredentials().checkPrivilege(Privilege.MANAGE_USERS) || getUserCredentials().checkPrivilege(Privilege.ADMIN_ALL_AGENCIES)) {
            List<BudgesUser> users = muc.getManagedUsers(false, false, true, new String[]{});
            integrateUserRole(users);
            responseObj.put("recordsTotal", users.size());
            responseObj.put("recordsFilter", users.size());
            responseObj.put("draw", "1");
            JSONArray userList = new JSONArray();
            
            ArrayList<String> desiredProps = Lists.newArrayList(props);

            for (BudgesUser user : users) {
                JSONArray userAgencies = new JSONArray();

                for (ServiceAgency agency : user.getAgencies()) {
                    userAgencies.put(agency.getName());
                }

                JSONObject thisUser = new JSONObject(user.toJson(desiredProps));
                thisUser.put("agencies", userAgencies);
                userList.put(thisUser);
            }

            responseObj.put("aaData", userList);
        }

        log.trace("onGetUserTable: user list json: " + responseObj.toString());
        return responseObj;
    }

    JSONObject onEditPePriv(@RequestParameter("json") String jsonStr) {
        JSONArray errorMessages = new JSONArray();
        JSONArray successMessages = new JSONArray();
        JSONArray requestObj = null;
        JSONObject responseObj = new JSONObject();
        List<BudgesUser> originalUserPrivsList = muc.getManagedUsers(false, false, true, new String[]{});
        
        try {
            requestObj = new JSONArray(jsonStr);

            for (Object userJ : requestObj) {
                JSONObject userJson = (JSONObject) (userJ);

                if (userJson.has("LdapId") && userJson.has("canCreate")) {
                    String frontEndLdapID = userJson.getString("LdapId");
                    boolean frontEndPrivs = userJson.getBoolean("canCreate");

                    for (BudgesUser user : originalUserPrivsList) {
                        if ((user.getUserLdapId()).equals((frontEndLdapID)) && !(user.getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN) || user.getRole().equals(LdapDAO.GROUP_R2_SITEADMIN))) {
                            user.setCreatePeAllowed(frontEndPrivs);
                        }
                    }
                }
            }

            muc.saveCreate(originalUserPrivsList);
            successMessages.put("success");
            responseObj.put("successMessages", successMessages);
        } catch (RuntimeException e) {
            log.debug(e.getMessage());
            errorMessages.put("Request is malformed");
            responseObj.put("errorMessages", errorMessages);
        }
        return responseObj;
    }

    JSONObject onUpdateLdapCache() {
        return muc.updateLdapCache();
    }
    
    JSONObject onAddUser(String newUserLdapId) {
        boolean noOrgAllowed = getUserCredentials().checkPrivilege(Privilege.ADD_USER_NO_ORG);
        log.trace("onAddUser: - adding new user: " + newUserLdapId + " noOrgAllowed: " + noOrgAllowed);
        
        String msg = null;
        BudgesUser admin = getUserCredentials().getUserInfo().getBudgesUser();
        String theRole;

        try {
            BudgesUser buser = BudgesContext.getBudgesUserDAO().findByUserLdapId(newUserLdapId); 
            if (null != buser) {
                log.debug("onAddUser: - captured new user from database - ldapId: " + buser.getUserLdapId() + " DB Role: " + buser.getRole() + " Current status: " + buser.getStatusFlag());
                if (buser.getRole().equals(LdapDAO.GROUP_NONE)) {
                    buser.setRole(LdapDAO.GROUP_R2_USER);
                    log.debug("onAddUser: - user " + buser.getUserLdapId() + " DB Role reset to: " + buser.getRole());
                }

                theRole = buser.getRole();
            } 
            else {
                theRole = LdapDAO.GROUP_R2_USER;
                log.trace("onAddUser: - ** user not existing in DB, assigning new user role of: " + theRole);
            }

            log.debug("onAddUser: theRole: " + theRole);
            
            if ((buser == null || buser.getAgencies().size() == 0) && !noOrgAllowed) {
                msg = String.format(NewAdminUsers.NO_LDAP_ACCT_ASSOC_WITH_LDAPID, newUserLdapId);
                return getResponseObject(msg, FAILURE, newUserLdapId);
            }

            if (buser == null || !buser.getStatusFlag().isActive()) { 
                if (buser != null && !noOrgAllowed && !admin.getAgencies().containsAll(buser.getAgencies())) {
                    msg = NewAdminUsers.NON_ADMIN_NULL_OR_INACTIVE_LDAP;
                    return getResponseObject(msg, FAILURE, newUserLdapId);
                }
                
                if (buser != null && !noOrgAllowed && buser.getStatusFlag().isDeleted()) {
                    msg = NewAdminUsers.SITE_ADMIN_CANNOT_ADD_DELETED_USERS;
                    return getResponseObject(msg, FAILURE, newUserLdapId);
                }

                LdapUser luser = null;
                boolean checkForDevMode = false;

                try {
                    luser = BudgesContext.getLdapDAO().getLdapUser(newUserLdapId); 
                    log.debug("onAddUser: LDAP user information: " + luser);

                    if (null != luser) {
                        luser.setR2Role(theRole);
                        log.debug("onAddUser: set role " + theRole + " to user: " + luser.getLdapUserId()); 
                    }

                } catch (LDAPException ldapE) {
                    log.error("onAddUser: LDAPException capturing ldap for user: " + newUserLdapId + " msg: " + ldapE.getMessage(), ldapE);
                    checkForDevMode = true;
                } catch (Exception e) {  
                    log.error("onAddUser: Exception capturing ldap for user: " + newUserLdapId + " msg: " + e.getMessage(), e);
                }

                if (checkForDevMode) {
                    luser = getMockLdapUser(newUserLdapId, admin, buser);
                }

                if (null == luser) {
                    msg = String.format(NewAdminUsers.NO_LDAP_ACCT_ASSOC_WITH_LDAPID, newUserLdapId);
                    return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
                }

                // processing if role is in valid set
                log.trace("onAddUser: " + luser == null ? null : luser.getR2Role());
                if (luser != null && (LdapDAO.VALID_GROUPS_SET.contains(luser.getR2Role()) || luser.getR2Role().equals(LdapDAO.GROUP_R2_USER))) {
                    log.trace("onAddUser: user is in a valid role group set - " + newUserLdapId);

                    if (null == buser) {
                        buser = UserUtils.addUser(luser); 
                        buser.setRole(theRole);
                        log.trace("onAddUser: buser created via UserUtils - " + newUserLdapId);
                    }

                    buser.setStatusFlag(StatusFlag.ACTIVE);
                    log.debug("onAddUser: buser status set to ACTIVE - " + newUserLdapId);
                    Util.setAuditFieldsForUser(buser, admin);
                    BudgesContext.getBudgesUserDAO().saveLdapData(buser, luser);

                    if (null == buser.getUserLdapId()) {
                        msg = String.format("Failed to persist ldap data to USER table for ldapId: %s", newUserLdapId);
                        log.warn("onAddUser: " + msg);
                        return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
                    }

                    if (!processUserRoles(buser.getUserLdapId(), null)) {
                        log.trace("onAddUser: failed to process user_role - " + newUserLdapId);
                        msg = String.format(NewAdminUsers.FAILURE_TO_ADD, newUserLdapId);
                        boolean deleted = deleteUser(buser);
                        log.trace("onAddUser: deleted BudgesUser after failure to process P40: " + deleted + " - " + newUserLdapId);
                        return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
                    } 
                    else {
                        try {
                            boolean sendEmailToAdmins = BudgesContext.getConfigService().getRegistrationEmailToAdmins();
                            Integer agencyId = buser.getAgencies().size() == 1  && sendEmailToAdmins ? buser.getAgencies().iterator().next().getId() : null;

                            if (agencyId == null) {
                                log.error("onAddUser: Not emailing admins, agencie s= " + buser.getAgencies());
                            }

                            log.trace("onAddUser: send user email");
                            BudgesContext.getEmailUtil().sendUserAddedEmail(getUserCredentials(), luser, agencyId);
                        } catch (EmailException e) {
                            log.error("onAddUser: Failed to send profile update email", e);
                        } catch (LDAPException e) {
                            log.error("onAddUser: Failed to send profile update email", e);
                        }

                        log.trace("onAddUser: get budges User DAO evict: " + buser.getUserLdapId());
                        BudgesContext.getBudgesUserDAO().evict(buser);
                    }
                } 
                else {
                    log.debug("onAddUser: role failed to be contained in approved ldap group - role is: " + luser == null ? null : luser.getR2Role());
                    msg = NewAdminUsers.FAILURE_NOT_IN_APPROVED_LDAP_GRP;
                    log.debug(msg);
                    return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
                }
            } 
            else {
                msg = String.format(FAILURE_DUPLICATE, newUserLdapId);
                log.warn(msg);
                return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
            }
        } catch (RuntimeException e) {
            msg = NewAdminUsers.UNREGISTERED_LDAP_ID;
            log.error(msg, e);
            return getResponseObject(msg, NewAdminUsers.FAILURE, newUserLdapId);
        }

        msg = String.format(NewAdminUsers.SUCCESSFULLY_ADDED_USER, newUserLdapId);
        log.debug("onAddUser: finished onAddUser(): - " + msg + " - " + newUserLdapId);
        return getResponseObject(msg, NewAdminUsers.SUCCESS, newUserLdapId);
    }
    
    JSONObject onDeleteUser(String userLdapId) {
        log.debug("onDeleteUser: - userLdapId: " + userLdapId + " by: " + getUserCredentials().getUserInfo().getBudgesUser().getUserLdapId());
        String msg = null;

        if (userLdapId.equals(getUserCredentials().getUserInfo().getBudgesUser().getUserLdapId())) {
            return getResponseObject(NewAdminUsers.FAILURE_CANNOT_DELETE_SELF, FAILURE, userLdapId);
        }

        Boolean doubleCheck = null;
        boolean statusChangedToDelete = false;
        doubleCheck = doublecheckDelete(userLdapId);

        // mock deletion only for development
        if (null == doubleCheck) {
            log.debug("onDeleteUser: MOCK_DELETION IN PROGRESS");
            statusChangedToDelete = UserUtils.deleteUser(userLdapId);

            if (!statusChangedToDelete) {
                log.debug("onDeleteUser: failed to change status to delete on user: " + userLdapId);
                msg = String.format(NewAdminUsers.USER_NOT_DELETED, userLdapId);
                return getResponseObject(msg, FAILURE, userLdapId);
            } 
            else {
                doubleCheck = true;
                log.debug("onDeleteUser: successfully changed status to delete on mocked user: " + userLdapId);
            }
        }

        if (BooleanUtils.isFalse(doubleCheck)) {
            log.debug("onDeleteUser: failed to delete (ldapId was either not in LDAP or the deleter does not have privileges to delete user.");

            if (LdapDAO.GROUP_R2_APP_ADMIN.equals(getUserCredentials().getUserInfo().getBudgesUser().getRole())) {
                log.debug("onDeleteUser: execute delete via R2AppMgr privileges");
                statusChangedToDelete = UserUtils.deleteUser(userLdapId);
            } 
            else {
                msg = String.format(NewAdminUsers.USER_NOT_DELETED, userLdapId);
                return getResponseObject(msg, FAILURE, userLdapId);
            }
        } 
        else {
            statusChangedToDelete = UserUtils.deleteUser(userLdapId);
        }

        if (statusChangedToDelete) { 
            BudgesUser user = BudgesContext.getBudgesUserDAO().findByUserLdapId(userLdapId);
            
            if (user != null && StatusFlag.DELETED.equals(user.getStatusFlag())) {
                msg = String.format(NewAdminUsers.USER_SUCCESSFULLY_DELETED, userLdapId);
                return getResponseObject(msg, NewAdminUsers.SUCCESS, userLdapId);
            } 
            else {
                log.debug("onDeleteUser: failed to delete user - status flag was not set to DELETE");
                msg = String.format(NewAdminUsers.USER_FAILED_TO_DELETE, userLdapId);
                return getResponseObject(msg, NewAdminUsers.FAILURE, userLdapId);
            }
        } 
        else {
            msg = NewAdminUsers.USER_STATUS_NOT_DELETE;
            return getResponseObject(msg, NewAdminUsers.FAILURE, userLdapId);
        }
    }

    private Boolean doublecheckDelete(String userId) {
        log.debug("doublecheckDelete: start - userId: " + userId);
        LdapUser ldapUser = null;
        Boolean rValue = Boolean.FALSE;

        try {
            ldapUser = BudgesContext.getLdapDAO().getLdapUser(userId);

            if (null != ldapUser) {
                rValue = new Boolean(getUserCredentials().getUserInfo().checkManageRole(ldapUser.getR2Role()));
                log.debug("doublecheckDelete: rValue: " + rValue + " for userId: " + userId);
            } 
            else {
                log.debug("doublecheckDelete: unable to get ldapUser from Ldap for userId: " + userId);
            }
        } catch (LDAPException ldapE) {
            if (ldapE.getMessage().contains(NewAdminUsers.LDAP_CONNECTION_FAILURE)) {
                log.warn("doublecheckDelete: Exception while attempting delete: " + NewAdminUsers.LDAP_CONNECTION_FAILURE + "ldapId: " + userId);
                
                if (getCurrentBudgesUser().getUserLdapId().equals(NewAdminUsers.MOCK_DELETER) && userId.equals(NewAdminUsers.PSEUDO_LDAP_ID)) {
                    return null;
                } 
                else {
                    return Boolean.FALSE;
                }

            } 
            else {
                log.error("doublecheckDelete: exception: " + ldapE.getMessage(), ldapE);
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            log.error("doublecheckDelete: exception - msg: " + e.getMessage(), e);
            return Boolean.FALSE;
        }

        return rValue;
    }

    private boolean deleteUser(BudgesUser bu) {
        String ldapId = bu.getUserLdapId();
        
        try {
            BudgesContext.getBudgesUserDAO().delete(bu);
            log.debug("deleteUser: successfully deleted budgesUser ldapId: " + ldapId);
            return true;
        } catch (RuntimeException re) {
            log.error("deleteUser: failed to delete budgesUser ldapId: " + ldapId);
            return false;
        }
    }

    private String getP40Role(String role) {
        if (null == role) {
            return Role.USER;
        }
        switch (role) {
            case UserRoleEditor.P40USER :
                return Role.USER;
            case UserRoleEditor.P40ANALYST :
                return Role.ANALYST;
            case UserRoleEditor.P40LOCALSITEADMIN :
                return Role.LOCALSITEADMIN;
            case UserRoleEditor.P40SITEADMIN :
                return Role.SITEADMIN;
            case UserRoleEditor.P40APPMGR :
                return Role.APPMGR;
            case UserRoleEditor.R2APPMGR :
                return Role.APPMGR;
            case UserRoleEditor.R2SITEADMIN :
                return Role.SITEADMIN;
            case UserRoleEditor.R2LOCALSITEADMIN :
                return Role.LOCALSITEADMIN;
            case UserRoleEditor.R2USER :
                return Role.USER;
            case UserRoleEditor.R2ANALYST :
                return Role.ANALYST;
            case UserRoleEditor.R2OMBANALYST :
            	return Role.OMBANALYST;
            default :
                return LdapDAO.GROUP_NONE;
        }
    }

    private boolean processUserRoles(String ldapId, String role) {
        log.debug("processUserRoles - ldapId: " + ldapId + " role: " + role);
        boolean p40updated = (null == ldapId) ? false : processP40ByFetchedLdap(CayenneUtils.createDataContext(), ldapId, role);
        log.debug("processUserRoles - success status: " + p40updated);
        return p40updated;
    }

    private JSONObject getResponseObject(String message, boolean status, String ldapId) {
        log.debug("getResposeObject: " + String.format("getResponseObject: message: %s status: %s ldapId: %s", message, Boolean.toString(status), ldapId));
        JSONObject responseObject = new JSONObject();

        if (null == ldapId) {
            ldapId = "Undetermined";
        }

        if (status) {
            log.trace("getResposeObject: processing success messages");
            JSONArray successMessages = new JSONArray().put(message);

            if (null != ldapId && ldapId.equals(NewAdminUsers.PSEUDO_LDAP_ID)) {
                successMessages.put(NewAdminUsers.MOCKED_USER_PROCESS);
            }
            
            responseObject.put(NewAdminUsers.SUCCESS_MESSAGES, successMessages);
        } 
        else {
            log.debug("processing error messages");
            JSONArray errorMessages;
            
            if (message.equals(NewAdminUsers.SITE_ADMIN_CANNOT_ADD_DELETED_USERS) || message.equals(NewAdminUsers.NON_ADMIN_NULL_OR_INACTIVE_LDAP)) {
                errorMessages = new JSONArray(); 
                String[] msgSplit = message.split("\\|");
                
                for (String s : msgSplit) {
                    errorMessages.put(s);
                }
            } 
            else {
                errorMessages = new JSONArray().put(message);
                
                if (ldapId.equals(PSEUDO_LDAP_ID)) {
                    errorMessages.put(NewAdminUsers.MOCKED_USER_PROCESS);
                }
            }

            responseObject.put(NewAdminUsers.ERROR_MESSAGES, errorMessages);
        }

        return responseObject;
    }

    private void integrateUserRole(List<BudgesUser> users) {
        log.trace("integrateUserRole: - start");
        
        if (users.size() < 1) {
            return;
        }
        
        DataContext dataContext = CayenneUtils.createDataContext();

        for (BudgesUser user : users) {
            String ldapId = user.getUserLdapId();
            boolean ok = processP40ByFetchedLdap(dataContext, ldapId, user.getRole());
            
            if (ok) {
                log.trace("successfully synchronized with user_role table ldapId: " + ldapId);
            } 
            else {
                log.warn("failed to synchronize with user_role table ldapId: " + ldapId);
            }
        }
    }

    private boolean processP40ByFetchedLdap(DataContext context, String ldapId, String role) {
        log.trace("processP40ByFetchedLdap: ldapId: " + ldapId + " role: " + role);
        boolean updated = false;
        String formattedRole = getP40Role(role);
        log.trace("processP40ByFetchedLdap: formattedRole: " + formattedRole);

        if (null == formattedRole) {
            log.error("processP40ByFetchedLdap: - failed to generate a formatted role for ldapId: " + ldapId);
            return false;
        }
        
        ObjectContext objectContext = (ObjectContext) context;
        P40User user = P40User.fetchWithLdapId(objectContext, ldapId);

        if (null == user) {
            log.error("processP40ByFetchedLdap: - failed to generate a P40User for ldapId: " + ldapId);
            return false;
        }

        List<Role> userRoles = user.getRoles();

        if (userRoles.size() > 1) {
            log.trace("processP40ByFetchedLdap: removing roles for user - no. of roles: " + userRoles.size());
            
            try {
                for (Role r : userRoles) {
                    user.removeFromRoles(r);
                }
            } catch (ConcurrentModificationException cme) {
                log.error("processP40ByFetchedLdap: Exception processing roles for user: " + ldapId + " msg: " + cme.getMessage());
            } catch (Exception e) {
                log.error("processP40ByFetchedLdap: General Exception processing roles for user: " + ldapId + " msg: " + e.getMessage());
            }
        } 
        else if (userRoles.size() == 1) {
            if (formattedRole.equals(userRoles.get(0).getName())) {
                log.trace("processP40ByFetchedLdap: - no processing required, role already set for ldapId: " + ldapId);
                return true;
            } 
            else {
                user.removeFromRoles(userRoles.get(0));
            }
        }

        if (null != user && user.getUserLdapId().equals(ldapId)) {
            try {
                log.debug("processP40ByFetchedLdap: attempting to add p40Role: " + formattedRole + " to: " + ldapId);
                CayenneUtils.copyToContext(user, context);
                Role p40Role = Role.fetchByName(user.getObjectContext(), formattedRole);

                if (null != p40Role) {
                    user.addToRoles(p40Role);
                    user.getObjectContext().commitChanges();
                    updated = true;
                }
                else {
                    log.debug("failed to capture P40Role from formattedRole: " + formattedRole);
                }
            } catch (Exception e) {
                log.warn("processP40ByFetchedLdap: apparently failed to update user_role table with user " + ldapId + " role: " + formattedRole  + " - msg: " + e.getMessage());
            }
        }
        
        return updated;
    }

    private LdapUser getMockLdapUser(String newUser, BudgesUser admin, BudgesUser buser) {
        log.trace("onMockLdapUser: validating use of mock user feature");
        LdapUser luser = null;

        if (NewAdminUsers.PSUEDO_LDAP && newUser.equals(NewAdminUsers.PSEUDO_LDAP_ID)) {
            if (admin.getEmail().equals(NewAdminUsers.PSEUDO_LDAP_MAIL)) {
                log.error(USING_MOCK_LDAP);
                luser = new LdapUser();
                luser.setLdapUserId(newUser);
                luser.setGroupSet(LdapDAO.VALID_GROUPS_SET);
                luser.setEmailAddress(NewAdminUsers.MOCK_EMAIL_ADDRESS);
                luser.setPhoneNumber(NewAdminUsers.MOCK_PHONE_NUMBER);

                if (null != buser && null != buser.getRole()) {
                    luser.setR2Role(buser.getRole());
                } 
                else {
                    luser.setR2Role(NewAdminUsers.MOCK_ROLE);
                }

                luser.setFullName(NewAdminUsers.MOCK_FULL_NAME);
                luser.setFirstName(NewAdminUsers.MOCK_FIRST_NAME);
                luser.setLastName(NewAdminUsers.MOCK_LAST_NAME);
                luser.setMiddleInitial(NewAdminUsers.MOCK_MIDDLE_INITIAL);
            }
        }

        return luser;
    }
    
    public boolean isAppMgr(){
        if (getUserCredentials().getUserInfo().getLdapUser().getR2Role().equals(LdapDAO.GROUP_R2_APP_ADMIN)) {
            return true;
        }
        return false;
    }

    //-- SourcePath interface getter/setter methods
    @Override
    public String getSourcePath() {
        return sourcePath;
    }
    
    @Override
    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    @Override
    public String getSourceUrl() {
        return sourceUrl;
    }

    @Override
    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }
    
    @Override
    public void setReturnLabel(String returnLabel) {
        this.returnLabel = returnLabel;
    }

    @Override
    public String getReturnLabel() {
        return returnLabel;
    }

    @Override
    public boolean isHasPath() {
        return hasPath;
    }

    @Override
    public void setHasPath(boolean hasPath) {
        this.hasPath = hasPath;
    }
}
