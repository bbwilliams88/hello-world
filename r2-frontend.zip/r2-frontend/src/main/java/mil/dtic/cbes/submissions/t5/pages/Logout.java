package mil.dtic.cbes.submissions.t5.pages;

import mil.dtic.cbes.submissions.t5.base.T5Base;

public class Logout extends T5Base{

	public boolean isR2Analyst() {
		return getCurrentBudgesUser().getRole().equals("R2Analyst");
	}
}
