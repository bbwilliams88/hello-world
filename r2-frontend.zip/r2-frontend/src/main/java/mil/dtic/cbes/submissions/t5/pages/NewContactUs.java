package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.ajax.AjaxResponseRenderer;
import org.hibernate.validator.internal.util.logging.Messages;
import org.apache.logging.log4j.Logger;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.commons.mail.EmailException;
import org.apache.tapestry5.annotations.Persist;


/**
 * Creates Email and send it to contact Technical Support 
 */

public class NewContactUs extends T5Base
{
  private static final Logger log = CbesLogFactory.getLog(NewContactUs.class);
  @Property
  private UserCredentials currentUserCreds;
  @Inject
  @Property
  private ConfigService config;
   
  @Persist
  @Property    
  private String currentUserName;
  
  @Persist
  @Property
  private String currentUserEmail;
  
  @Property
  private String emailMessage;
  
  @Persist
  @Property
  private String phoneNumber;  
  
  @Property
  private boolean messageSent;
  
  @InjectComponent
  private Zone messageZone;
   
  @Component(id ="emailForm")
  private Form emailForm;
  
  @Inject
  private AjaxResponseRenderer ajaxResponseRenderer;
  
  @Inject
  private ComponentResources componentResources;
    
  
  @Log
  void onSuccess()
  {
      
      currentUserName = null;
      currentUserEmail = null;
      phoneNumber = null ;
      emailMessage = null;
      messageSent = true;               
                 
  } 
    
  void onValidateFromemailForm()
  {
	       
      String[] toList = new String[1];
      toList[0] = config.getEmailTo(); 
           
      String[] ccList = new String[1]; 
      ccList[0]= currentUserEmail; 
      
      String messageSubject = "R2 User Message (from Contact Us Page) name: " + currentUserName + " phone: " + phoneNumber;
                   
      try
      {    	 
          BudgesContext.getEmailUtil().sendEmail(config.getEmailFrom(), toList, ccList, messageSubject, emailMessage, false);	  
      }  
      catch (EmailException e)
      {
    	  
          emailForm.recordError("Sorry, there was an error sending e-mail");
          emailForm.recordError("Please send an Email to the Email Address above");
      }       
  }  
  
  void setupRender()
  {	  	  
      
      currentUserName = currentUserCreds.getUserInfo().getLdapUser().getFullName();
      currentUserEmail = currentUserCreds.getUserInfo().getLdapUser().getEmailAddress();
      phoneNumber = currentUserCreds.getUserInfo().getLdapUser().getPhoneNumber();  
  }  
  
  Object onSubmit()
  {	  	 
	  
	  return messageZone.getBody();
	  
  }
  
  void onRefreshPage()
  {
	  
  }
  
  @Log
  void onActivate()
  {	
      
      currentUserCreds = getUserCredentials();
  }
    
  void afterRender()
  {	  
	 
  }
  
}