package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.encryption.BadSecurityHandlerException;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionAttribute;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.ajax.AjaxResponseRenderer;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.itextpdf.text.exceptions.BadPasswordException;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.BudgetArea;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.Constants.JBLogoImageFileType;
import mil.dtic.cbes.constants.Constants.JBPageNumberingModel;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.jb.IAppropriation;
import mil.dtic.cbes.jb.JBSupplementalDoc;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.p40.vo.BudgetCycleConfig;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.service.XmlFullValidationServiceFactory;
import mil.dtic.cbes.sso.siteminder.SpringUser;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.delegates.BudgesUploadFileT5;
import mil.dtic.cbes.submissions.delegates.BuildMjbDelegate;
import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.validation.backend.SubmissionDateValidator;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.UploadJbUtils;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.BudgesJbUploadFile;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.ImageUtil;
import mil.dtic.utility.KeyValuePair;
import mil.dtic.utility.PdfUtil;
import mil.dtic.utility.SendEmailOnInvalidXML2;
import mil.dtic.utility.UploadPdfUtils;
import mil.dtic.utility.Util;
import mil.dtic.utility.samanage.service.api.AdminService;

@Import( library = { "js/BuildMJB.js" },
         stack   = { CbesT5SharedModule.JQUERYTOOLSSTACK } )
public class BuildMJB extends T5Base {
  
  private static final String BUDGET_ESTIMATE_DOWNLOAD_KEY = "MJBWizardPage:BudgetEstimateDownload";
  
  private List<String> FILTERED_AGENCIES_R2 = Arrays.asList("DARPA", "MDA", "OSD", "CBDP");
  private List<String> FILTERED_AGENCIES_P40 = Arrays.asList("MDA");
  
  private static final Logger log = CbesLogFactory.getLog(BuildMJB.class);
  
  @Persist
  private List<String> errorMessages;
  
  @Persist
  private List<String> warningMessages;
  
  @Inject
  private AppDefaults appDefaults;
  
  @Inject
  private ServiceAgencyDAO agencyDAO;
  
  @Inject
  private BudgetCycleDAO budgetCycleDAO;
  
  @Inject
  private BudgesUserDAO userDAO;
  
  @Inject
  private Messages messages;
  
  @Inject
  private AdminService adminService;

  @Inject
  private ConfigService config;

  @Inject
  private BudgesJobDAO jobDAO;

  @Property
  private String errorMessage; // Used in the TML.

  @Property
  private String warningMessage; // Used in the TML.

  @Component
  private Zone submDateZone;
  
  @Persist
  private JBFormData mfdata;
  
  @Property
  private BudgesUploadFileT5 supFile; // Used in the TML
  
  @Property
  private KeyValuePair tovEntry; // Used in the TML
  
  @Property
  private BudgesJbUploadFile jbUploadFile;
  
  @Property
  @Persist
  private List<BudgesJbUploadFile> jbUploadFileList;
  
  @SessionAttribute(value=BUDGET_ESTIMATE_DOWNLOAD_KEY)
  private BudgesDownloadableObject mjbDownloadableObject;
  
  @Persist
  @Property
  private String budgetSection;

  private boolean timeToBuildBook = false;
  
  @Property
  @Persist
  private String trackingUrl;
  
  @Property
  private int index;
  
  @Inject
  private JavaScriptSupport jsSupport;
  
  @Property
  private String overviewHelp;
  
  //mjbUpload
  @Property
  private File mjbUploadFile;
  
  @Property
  private String pageTitle;

  @Inject
  private AjaxResponseRenderer ajaxResponseRenderer;
  
  public void onActivate() throws IOException
  {
    if (budgetSection == null){
    	onActivate("r2");
    }
    else{
     onActivate(null);
    }
  }

  public void onActivate(String bSection) throws IOException
  {
	  if(bSection == null) {
		  if(pageTitle == null) {
			  if(null != budgetSection && budgetSection.equalsIgnoreCase("p40")) {
				  pageTitle = "Build Procurement Volume 1 Defense-Wide Master Justification Book";
			  }
			  else {
				  pageTitle = "Build RDT&E Volume 5 Defense-Wide Master Justification Book";
			  }
		  }
	  }
	  else if(bSection.equalsIgnoreCase("r2")) {
		  pageTitle = "Build RDT&E Volume 5 Defense-Wide Master Justification Book";
	  }
	  else {
		  pageTitle = "Build Procurement Volume 1 Defense-Wide Master Justification Book";
	  }
	  
    if (bSection != null && (budgetSection == null || bSection.compareToIgnoreCase(budgetSection) == 0)){
      budgetSection = bSection;
    }
    
    else if(bSection != null){
      log.debug("nulling out mfdata because we are switching budgetSections");
      budgetSection = bSection;
      jbUploadFileList=null;
      mfdata = null;
      trackingUrl = null;
    }
    if (mfdata == null){
      log.debug("initializing mfdata in on Activate because it is null");
      if(jbUploadFileList==null){
        jbUploadFileList = new ArrayList<BudgesJbUploadFile>();
      }
      mfdata = new JBFormData(getUserId(), isRDTE(), !isRDTE());
      mfdata.setGenerateP1m(false);
      mfdata.setUseLegacyMJBFormat(false);//I don't know what this is but I dont think we should be doing it
      mfdata.setServiceAgency(BudgesContext.getServiceAgencyDAO().findByCode("DW"));
      mfdata.setOverrideDocumentAssemblyOptionsInXml(true);
      mfdata.setWorkFlowStatus(JBookWorkFlowStatus.FINAL.getCode());

      mfdata.getTov().clear();
      
      List<BudgesJbUploadFile> tovList = isRDTE() ? filterVolumes(BudgesContext.getJbUploadFileListForAgencies(), BudgetArea.RDTE)
              : filterVolumes(BudgesContext.getJbUploadFileListForP40Agencies(), BudgetArea.PROC);
      
      tovList = adminService.processTovList(tovList, isRDTE(), null);
      
      for (BudgesJbUploadFile uf : tovList){
        if (uf.getBookNumber() != null){
          mfdata.getTov().add(new KeyValuePair(uf.getBookDescription(), uf.getBookLabelAndNumber()));
          
          if (uf.getBookGroup() != null){
            jbUploadFileList.add(uf);
            
            uf.setOverrideDocumentAssemblyOptionsInXml(true);
          }
        }
      }

      //mfdata.setTitle("mjb dummy title");

      mfdata.getSupplementalFiles().add(new BudgesUploadFileT5());
      mfdata.getSupplementalFiles().add(new BudgesUploadFileT5());
      mfdata.getSupplementalFiles().add(new BudgesUploadFileT5());
      mfdata.getSupplementalFiles().add(new BudgesUploadFileT5());
      mfdata.getSupplementalFiles().add(new BudgesUploadFileT5());
      //these are here just to prevent NPE's in the build process
      errorMessages = new ArrayList<String>();
      warningMessages = new ArrayList<String>();
    }
    //initialize help
    if (StringUtils.equals(budgetSection, "r2"))
      overviewHelp = config.getBuildR2MJBOverviewHelp();
    else
      overviewHelp = config.getBuildP40MJBOverviewHelp();
  }

  void afterRender()
  {
    jsSupport.addScript("setup('%s');", Constants.COLOR_ROW_HIGHLIGHT);
    jsSupport.addScript("jQuery('#uploadMJbCell #upload').on('change', function() {return $('#uploadMJbCell input[type=submit]').click();});jQuery('#uploadMJbCell input[type=submit]').hide();");
  }
  public Object onSuccess() throws IOException, VirusScanException, CryptographyException, BadSecurityHandlerException{
    if (timeToBuildBook == true){
      buildMjb();
    }
    return null;
  }

  public Object onFailure(){
    timeToBuildBook = false;
    return null;
  }
  
  @Log
  public void onPrepareForSubmit(){
    errorMessages = new ArrayList<String>();
    warningMessages = new ArrayList<String>();
  }
 
  @Log
  public void onSelectedFrombuildMJBook(){
    timeToBuildBook = true;
    trackingUrl = null;
  }

  @Log
  public void onSelectedFromresetForm(){
    onResetForm();
    timeToBuildBook = false;
  }
  public void onResetForm(){
    trackingUrl = null;
    mfdata = null;
    jbUploadFileList = null;
    timeToBuildBook = false;

    try {
      onActivate(budgetSection);
    } catch (IOException e) {
      log.error("IOException while initializing new form after form reset: " + e.getLocalizedMessage());
    }
  }

  @Log
  private void buildMjb() throws VirusScanException, CryptographyException, BadSecurityHandlerException
  {
    try {

      DocumentAssemblyOptions docAssemblyOptions = new DocumentAssemblyOptions();

      docAssemblyOptions.setAllDocumentAssemblyOptions(mfdata);
      boolean hasUploadedComponentJbook = false;

      // find and process component jbook uploads
      for(int i = 0; i < jbUploadFileList.size(); i++){
        BudgesJbUploadFile uf = jbUploadFileList.get(i);

        if (uf.getUploadFile() != null) {
          hasUploadedComponentJbook = true;

          // if an exception is thrown during file processing, add info about which JBook caused the problem and rethrow

            try {
				processComponentJbookUpload(uf);
			} catch (VirusScanException | CryptographyException | BadSecurityHandlerException e) {
				addErrorMessage("Could not process uploaded file for Component Jbook #" + (i+1) + " (" + uf.getBookDescription() + ").");
				throw e;
			}
        }
      }

      if (hasUploadedComponentJbook == false){
        throw new ValidationException("You must upload at least one component Jbook to build a Master Jbook");
      }
      log.debug("Current working directory: " + mfdata.getWorkingDirectory());
      R2Storage r2storage = new R2Storage("mjbbuild");
      File workingFolder = mfdata.getWorkingDirectory();//r2storage.createEmptyFolderInUpload(mfdata.getWorkingDirectory().getAbsolutePath());
      log.debug("Created working folder for new MJB build: " + workingFolder);

      // Check if Submission Date is available in selected BudgetCycle
      SubmissionDateValidator sdv = new SubmissionDateValidator(mfdata.getSubmissionDate(), mfdata.getBudgetCycle());
      if (!sdv.isValidSubmissionDate())
        throw new ValidationException(sdv.getSubmissionDateError());
      BuildMjbDelegate bjbbd = getPopulatedMjbDelegate(workingFolder, docAssemblyOptions);
      bjbbd.setInvalidXMLListener(new SendEmailOnInvalidXML2()); //TODO fix email

      if (mfdata.getCoverLogoFile().getUploadFile() != null){
        bjbbd.setCoverLogoBudgesFile(mfdata.getCoverLogoFile());
      }
      if (mfdata.getIntroFile().getUploadFile() != null){
        bjbbd.setIntroDocBudgesFile(mfdata.getIntroFile());
      }
      if (mfdata.getSummaryFile().getUploadFile() != null){
        bjbbd.setSummaryDocBudgesFile(mfdata.getSummaryFile());
      }
      if (mfdata.getAcronymsFile().getUploadFile() != null){
        bjbbd.setAcronymDocBudgesFile(mfdata.getAcronymsFile());
      }
      if (mfdata.getR1File().getUploadFile() != null){
        bjbbd.setUserR1BudgesFile(mfdata.getR1File());
      }
      if (mfdata.getP1File().getUploadFile() != null){
        bjbbd.setUserP1BudgesFile(mfdata.getP1File());
      }
//      bjbbd.setSupplementalDocBudgesFileList(createSupplementalDocBudgesFileList(mfdata.getSupplementalFiles(), workingFolder));
      bjbbd.setUserSuppliedData(mfdata);
      log.debug("bjbbd.getWorkingFolder().getAbsolutePath(): " + bjbbd.getWorkingFolder().getAbsolutePath());

      if (!config.getRunWizardJobsImmediately()) {
         log.debug("running wizard jobs delayed");
        if (!scheduleMjbJob(bjbbd, r2storage.getUuid()) && !bjbbd.getResultInfo().hasErrors())
          bjbbd.getResultInfo().addError("A system error occurred. Could not generate MJB.");
        if (bjbbd.getResultInfo().hasErrors()) {
          addErrorMessages(bjbbd.getResultInfo().getErrorList());
          for(String s: bjbbd.getResultInfo().getErrorList()){
            log.error("ERROR : " + s);
          }
        }
      } else {
        log.debug("running wizard jobs immediately");
        throw new ValidationException("running wizard jobs delayed is selected in the db but isnt supported at this time");
      }
    } catch (BadPasswordException e) {
      log.error("", e);
      addErrorMessage("One of the PDF attachments is a secure PDF. You cannot use secured PDFs as attachments.");
    } catch (ValidationException e) {
      addErrorMessage(e.getMessage());
    } catch (IOException e) {
      log.error("", e);
      addErrorMessage("Error reading from file. File may be malformed or have no readable attachments.");
    } catch (SQLException e) {
        log.error("", e);
        addErrorMessage("Error with MJB Job");
    }
  }

  @Log
  private void processComponentJbookUpload(BudgesJbUploadFile uf) throws ValidationException, IOException, VirusScanException, CryptographyException, BadSecurityHandlerException {

    if(uf.getBookDescription() == null || uf.getBookDescription().isEmpty()){
      throw new ValidationException("Book description is empty");
    }
    if(uf.getBookNumber() == null || uf.getBookNumber().isEmpty()){
      throw new ValidationException("Book number is empty");
    }
    if(uf.getBookGroup() == null || uf.getBookGroup().isEmpty()){
      throw new ValidationException("Book group is empty");
    }

    if (uf.getUploadFile() instanceof JustificationBook){
      processComponentJbookZzz(uf);
    } else {
      // extract Jbook zzz from pdf
      for(File f: UploadJbUtils.unwrapJbookFile((File) uf.getUploadFile(), false)) { //isMjb = false
        uf.setUploadFile(f);
        processComponentJbookZzz(uf);

        if (uf.getBudgesFile() == null && (uf.getUploadFile() instanceof File)){
          uf.setBudgesFile(new BudgesFile(((File)uf.getUploadFile()).getName(), (File)uf.getUploadFile(), null)); //i have no idea why there are both getuploadfiler and get budgesfile
        }else if(uf.getBudgesFile().getFile().getAbsolutePath().compareTo(((File)uf.getUploadFile()).getAbsolutePath()) != 0){
          log.debug("budgesfile inconsistenct with uploaded file within uf resetting budgesFile. BudgesJbUploadFile: " + uf.getBookLabelAndNumber());
          uf.setBudgesFile(new BudgesFile(uf.getBudgesFile().getOriginalName(), (File)uf.getUploadFile())); //i have no idea why there are both getuploadfiler and get budgesfile
        }else{
          log.error("internal Error, UNFORSEEN VALUE for UF: " + uf.getBookLabelAndNumber());
        }
      }
    }
  }

  @Log
  private void processComponentJbookZzz(BudgesJbUploadFile zzzFile) throws VirusScanException, IOException, ValidationException
  {
    if (zzzFile.getUploadFile() instanceof JustificationBook){
      /* don't add already-processed jbooks to the volume list, they are already there
      MJBVolumeModel x = UploadJbUtils.jbToMJBVolModel((JustificationBook)zzzFile.getUploadFile(), zzzFile.isOverrideDocumentAssemblyOptionsInXml());
      x.setNumber(zzzFile.getBookNumber());
      x.setDescription(zzzFile.getBookDescription());
      mfdata.getVolumes().add(x);*/
      return;
    }
    PreviewResultInfo processedXml = UploadPdfUtils.processZzz((File) zzzFile.getUploadFile(), mfdata.getWorkingDirectory(),
        getErrorMessages(), getCurrentBudgesUser(), runOnlyVerifiedRules());
    if (processedXml.getR2ExhibitList() != null){
      if(false == isRDTE()){
        zzzFile.setUploadFile(null);
        throw new ValidationException("This is the Procurement BuildMJB tool. Uploaded JBooks cannot contain R2's");
      }
    }else if (processedXml.getLineItemList() != null){
      if(true == isRDTE()){
        zzzFile.setUploadFile(null);
        throw new ValidationException("This is the RDT&E BuildMJB tool. Uploaded JBooks cannot contain P40's");
      }
    }else{
      log.debug("processedXml.getR2ExhibitList and lineItemList are null");
    }
    if (processedXml.getJb() == null){
      zzzFile.setUploadFile(null);
      throw new ValidationException("Uploaded File isn't a valid Jbook");
    }else{
      MJBVolumeModel x = UploadJbUtils.jbToMJBVolModel(processedXml.getJb(), zzzFile.isOverrideDocumentAssemblyOptionsInXml());
      x.setNumber(zzzFile.getBookNumber());
      x.setDescription(zzzFile.getBookDescription());
      mfdata.getVolumes().add(x);
    }
  }

  @Log
  private boolean scheduleMjbJob(BuildMjbDelegate bjbbd, UUID uuid) throws IOException, SQLException
  {
    boolean success = false;
    trackingUrl = null;
    File zipFile = bjbbd.buildJbSingleZip();
    if (bjbbd.getResultInfo().getMjb() != null) {
      log.debug("Running business rules validation on full MJB");
      validateBusinessRules(bjbbd.getResultInfo().getMjb());
    }
    if (zipFile != null)
    {
      log.debug("Scheduling MJB build job from Wizard, uuid=" + uuid);

      // Zip file has format 'MasterJB_File.zzz'
      File renamedFile = new File(zipFile.getParentFile(), FileUtil.createZipFileName("MJB_XML_From_Wizard"));
      log.debug("Renaming " + zipFile + " to " + renamedFile);
      if (zipFile.renameTo(renamedFile))
      {
        String workingFolder =  bjbbd.getWorkingFolder().getName();
        String queueName = config.getQueueName();
        BudgesUser budgesUser = getCurrentBudgesUser();
        if (budgesUser == null) {
          if (getP40User() != null) { //P40
            budgesUser = userDAO.findByUserLdapId(getP40User().getUserLdapId());
          } else {
            log.error("No user found to set on job", new NullPointerException());
          }
        }
        JobTypeFlag jobType =  JobTypeFlag.MJBXMLTOPDF;
        BudgesJob job = new BudgesJob(uuid, jobType, workingFolder, renamedFile.getName(), budgesUser, mfdata.getServiceAgency(),queueName);
        job.setBudgetCycle(mfdata.getBudgetCycle().getLabel());
        jobDAO.saveOrUpdate(job);

        // TODO just a demo, not really the right url, gotta fix this by adding a tracking url property to *envsettings*.xml files...
        trackingUrl = Util.concat("/", config.getTrackingUrl(), uuid.toString());
        success = true;
      } else {
        log.debug("Could not rename " + zipFile + " to " + renamedFile);
      }
    } else {
      log.debug("NOT scheduling MJB build job from Wizard -- no zip file generated, uuid=" + uuid);
    }

    return success;
  }

  @Log
  private void validateBusinessRules(MasterJustificationBook mjb) {
    // business rules only, schema was already checked in SanityValidateXML while building zip
    XmlFullValidationService validator = XmlFullValidationServiceFactory.getFullValidator();
    validator.validateRules(mjb, runOnlyVerifiedRules());
    if(validator.hasRulesWarnings())
      addWarningMessages(validator.getRulesWarningList());
    if(validator.hasRulesErrors())
      addErrorMessages(validator.getRulesErrorList());
  }

  private void addErrorMessage(String errorText) {
    errorMessages.add(errorText);
  }

  private void addWarningMessage(String warningText) {
    warningMessages.add(warningText);
  }

  private void addErrorMessages(List<String> errorList) {
    for (String error : errorList){
      addErrorMessage(error);
    }
  }

  private void addWarningMessages(List<String> warningList) {
    for (String warning : warningList) {
      addWarningMessage(warning);
    }
  }

  @Log
  void onChangeFromBcSelect(String value)
  {
    mfdata.setBudgetCycle(budgetCycleDAO.findByCycleAndBudgetYear(value.split(" ")[0], new Integer(value.split(" ")[1])));
    submDateZone.getBody();

    ajaxResponseRenderer.addRender("submDateZone", submDateZone);
  }

  private BuildMjbDelegate getPopulatedMjbDelegate(File workingFolder, DocumentAssemblyOptions docAssemblyOptions){
    BuildMjbDelegate ans = new BuildMjbDelegate(workingFolder, new SendEmailOnInvalidXML2(), null, docAssemblyOptions, false);
    ans.setMjbTocItemList(mfdata.getTov());
    ans.setJbFileList(jbUploadFileList);
    ans.setJbPageNumberingModel(JBPageNumberingModel.CONTINUOUS);
    log.debug("for my BuildMjbDelegate setting jbFileList to: " + jbUploadFileList.size());
    return ans;
  }

  ///// below this is basic accessors and stuff copy pasta'd from other parts of the code base.
  public boolean isRDTE()
  {
    if (budgetSection == null)
    {
       log.debug("isRDTE getting called. budgetSection is null so defaulting to r2");
       return true;
    }else{
      return (budgetSection.compareToIgnoreCase("r2") == 0) ||(budgetSection.compareToIgnoreCase("rdte") == 0);
    }
  }

  public List<BudgetCycle> getBudgetCycles()
  {
    return appDefaults.getBudgetCycles();
  }
  public List<SubmissionDate> getSubmissionDates()
  {
    return appDefaults.getSubmissionDates();
  }


  public List<String> getErrorMessages()
  {
    if (errorMessages == null)
      errorMessages = new ArrayList<String>();

    return errorMessages;
  }

  public List<String> getWarningMessages()
  {
    if(warningMessages == null)
      warningMessages = new ArrayList<String>();

    return warningMessages;
  }

  public JBFormData getMfdata()
  {
    return mfdata;
  }

  public String getUserId()
  {
    if (getCurrentBudgesUser() != null) {
      return getCurrentBudgesUser().getUserLdapId();
    }
    if (getP40User() != null) {
      return getP40User().getUserLdapId();
    }
    return "blowj2109";
  }

  @Override
public UserCredentials getUserCredentials()
  {
    if (getRequestGlobals().getRequest().getSession(false) != null)
    {
      return (UserCredentials)getRequestGlobals().getRequest().getSession(false).getAttribute("state:r2:user.credentials");
    }
    return null;
  }

  @Override
public BudgesUser getCurrentBudgesUser()
  {
    if (getUserCredentials() != null && getUserCredentials().getUserInfo() != null)
    {
      return getUserCredentials().getUserInfo().getBudgesUser();
    }
    return null;
  }

  public P40User getP40User()
  {
    return getCurrentP40User();
  }
  
  private P40User getAdminP40User(){
    P40User p40User = getCurrentP40User();
        
      if (p40User != null) {
        return p40User;
      } else {
          BudgetCycleConfig config = CayenneUtils.createDataContext().newObject(BudgetCycleConfig.class);
          return P40User.fetchWithLdapId(config.getObjectContext(), getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
      }
  }

  

  public List<ServiceAgency> getAgencies()
  {
    if (!isRDTE())
    {
      List<ServiceAgency> agencyList = new ArrayList<ServiceAgency>();
      for (ServiceAgency r2Agency : BudgesContext.getServiceAgencyDAO().findAllProcurement()) //Get the r2 version full procurement agency list
      {
        for (mil.dtic.cbes.p40.vo.ServiceAgency p40Agency : getP40User().getActiveAgencies()) //Get the P40 version of the subset of agencies this user is authorized to see
        {
          if (r2Agency.getName().equals(p40Agency.getName())) //Add matches
          {
            agencyList.add(r2Agency);
          }
        }
      }

      if (agencyList.isEmpty() || getP40User().getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN))
        return BudgesContext.getServiceAgencyDAO().findAllProcurement();

      return agencyList;
    }
    else
    {
      return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
    }
  }
  public List<IAppropriation> getApprs()
  {
    List<IAppropriation> appropriations;

    if (!isRDTE())
    {
      if (mfdata.getServiceAgency() != null)
        appropriations = new ArrayList<IAppropriation>(mil.dtic.cbes.p40.vo.ServiceAgency.fetchWithCode(CayenneUtils.createDataContext(),
            mfdata.getServiceAgency().getCode())
          .getActiveProcurementAppropriationList());
      else
        appropriations = new ArrayList<IAppropriation>(mil.dtic.cbes.p40.vo.ServiceAgency.fetchWithCode(CayenneUtils.createDataContext(), getAgencies().get(0).getCode())
          .getActiveProcurementAppropriationList());
    }
    else
    {
      if (mfdata.getServiceAgency() != null)
        appropriations = new ArrayList<IAppropriation>(agencyDAO.findByCode(mfdata.getServiceAgency().getCode()).getRDTEAppropriations());
      else
        appropriations = new ArrayList<IAppropriation>(agencyDAO.findByCode(getAgencies().get(0).getCode()).getRDTEAppropriations());
    }


    return appropriations;
  }

  public <T> int getNonzeroIndex(List<T> l, T obj)
  {
    return l.indexOf(obj) + 1;
  }
  public int getIndexPlusOne(){
    return index+1;
  }
  public BudgesJbUploadFile getJbUploadFileListAt(int i){
    return jbUploadFileList.get(i);
  }
  public String getBackgroundColorStyleForIndex(int index)
  {
    String color = (index%2) == 0 ? Constants.COLOR_WHITE : Constants.COLOR_LIGHT_GRAY;
    return color;
  }
  public ValueEncoder<BudgesJbUploadFile> getJBUploadFileEncoder(){
    return new ValueEncoder<BudgesJbUploadFile>(){
       @Override
	public String toClient(BudgesJbUploadFile foo){
          return String.valueOf(jbUploadFileList.indexOf(foo));
       }
       @Override
	public BudgesJbUploadFile toValue(String clientValue){
          return jbUploadFileList.get(Integer.parseInt(clientValue));
       }

    };
 }
  //these are the validator
  @Log
  public SavedUploadValidator getZipFileValidator()
  {
    return new FileExtensionSavedUploadValidator("", BudgesContentType.ZZZ, BudgesContentType.ZIP,BudgesContentType.PDF)
    {
        @Override
        public void validateFilename(String filename) throws ValidationException
        {
          final String errorString = "The supplied jbook file does not end in extension .zzz, .zip, or .pdf";
            if (!isValid(filename)){
              addErrorMessage(errorString);
              throw new ValidationException(errorString);
            }
        }
    };
  }

  public SavedUploadValidator getPdfFileValidator(String s1, String s2){
    return getPdfFileValidator(s1 + s2);
  }
  public SavedUploadValidator getPdfFileValidator(final String documentName)
  {
      return new FileExtensionSavedUploadValidator("", BudgesContentType.PDF)
      {
          @Override
          public void validateFilename(String filename) throws ValidationException
          {
            final String errorString = "The supplied " + documentName + " is not a valid PDF: " + filename;
              if (!isValid(filename)){
                addErrorMessage(errorString);
                throw new ValidationException(errorString);
              }
          }

          @Override
          public void validateFile(File f, String originalName) throws ValidationException
          {

              if (!PdfUtil.isPdf(f)){
                final String errorString = messages.format("pdfattach-bad", documentName, originalName);
                addErrorMessage(errorString);
                throw new ValidationException(errorString);
              }

              if (PdfUtil.isSecured(f)){
                final String errorString = messages.format("pdfattach-bad-sec", documentName, originalName);
                addErrorMessage(errorString);
                throw new ValidationException(errorString);
              }
          }
      };
  }
  public SavedUploadValidator getJbImageValidator()
  {
      return new FileExtensionSavedUploadValidator("", JBLogoImageFileType.values())
      {
          @Override
          public void validateFilename(String filename) throws ValidationException
          {
              if (!isValid(filename))
                  throw new ValidationException("The logo image file is invalid; make sure it has the correct extension " + filename);
          }

          @Override
          public void validateFile(File f, String originalName) throws ValidationException
          {
              if (!ImageUtil.validateImageFile(f))
              {
                  throw new ValidationException("The logo image file is invalid; make sure it has the correct extension and content: " + originalName);
              }
          }
      };
  }

  public Boolean onSavedUploadDelete(File f){
    //this function is called from the savedUpload's in the jbUploadFileList loop. It probably will be called by other stuff in that circumstance it shouldn't do anything.
    log.debug("buildMJB being called with f: " + f.getAbsolutePath());
    for(BudgesJbUploadFile uf: jbUploadFileList){
       if ((uf.getUploadFile() instanceof File) && (((File)uf.getUploadFile()).getAbsolutePath().compareTo(f.getAbsolutePath()) == 0)){
        uf.setUploadFile(null);
        return Boolean.TRUE;
      }
    }
    for(BudgesUploadFileT5 uf: mfdata.getSupplementalFiles()){
      if (uf.getAbsolutePath() != null && uf.getAbsolutePath().compareTo(f.getAbsolutePath()) == 0){
        uf.setUploadFile(null);
        return Boolean.TRUE;
      }
    }
    return Boolean.FALSE;
  }
  
  private List<BudgesJbUploadFile> filterVolumes(List<BudgesJbUploadFile> volumes, BudgetArea budgetArea){
	  List<BudgesJbUploadFile> resultList = new ArrayList<>();
	  
	  if(BudgetArea.RDTE == budgetArea) {
		  for(BudgesJbUploadFile b : volumes) {
			  if(!FILTERED_AGENCIES_R2.contains(b.getAgencyCode())) {
				  resultList.add(b);
			  }
		  }
	  }
	  
	  if(BudgetArea.PROC == budgetArea) {
		  for(BudgesJbUploadFile b : volumes) {
			  if(!FILTERED_AGENCIES_P40.contains(b.getAgencyCode())) {
				  resultList.add(b);
			  }
		  }
	  }
	  
	  return resultList;
  }
}
