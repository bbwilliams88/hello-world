package mil.dtic.cbes.submissions.t5.pages;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.apache.tapestry5.util.TextStreamResponse;
import org.hibernate.SessionFactory;

import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.dao.ProjectDAO;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.ImageUtil;

public class R4UploadImage extends T5Base {

  private static final Logger log = CbesLogFactory.getLog(R4UploadImage.class);
  @Inject
  private HttpServletRequest request;
  @Inject
  private MultipartDecoder decoder;
  @Inject
  private SessionFactory sessionFactory;


  TextStreamResponse onActivate(String projectNumber) {
    JSONObject responseObject = new JSONObject();
    JSONArray files = new JSONArray();

    ProjectDAO projDao = BudgesContext.getProjectDAO();
    Project proj = projDao.findById(Integer.parseInt(projectNumber));

    if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
      log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken")
      + ", expected " + getCurrentBudgesUser().getCsrfToken());
      responseObject.put("message", "Unauthorized attempt to upload R4 image");
      responseObject.put("success", false);
    }
    else {
      for(int i=1; i<=5; i++) {
          UploadedFile upFile = decoder.getFileUpload("file" + (i+1));
          if(upFile != null) {
            JSONObject fileJson = processFile(upFile, proj);
            files.put(fileJson);
          }
      }
    }
    responseObject.put("files", files);
    responseObject.put("projTitle", proj.getTitle());

    return new TextStreamResponse("application/json", responseObject.toString());
  }

  private JSONObject processFile(UploadedFile upFile, Project proj) {
    JSONObject responseObject = new JSONObject();
    ConfigService config = BudgesContext.getConfigService();
    try {
      String tempUniqueFolderName = getCurrentUser().getUsername() +"_" +UUID.randomUUID().toString();
      log.debug("tempUniqueFolderName: " + tempUniqueFolderName);
      File newWorkingDirectory = new File(config.getWorkingFolder(), tempUniqueFolderName+"_r4img");
      log.debug("newWorkingDirectory: " + newWorkingDirectory);
      newWorkingDirectory.mkdir();
      log.debug("successfully created working directory");
      File r4File = scanAndCpToUpload(config.getVscanSandboxFolder(), upFile, newWorkingDirectory);
      log.debug("r4File: " + r4File);
      boolean isGood = ImageUtil.validateImageFile(r4File);
      log.debug("isGood: " + isGood);
      responseObject.put("filesize", upFile.getSize());
      responseObject.put("validimage", isGood);
      int spId = addScheduleProfile(proj, r4File, upFile.getFileName());
      responseObject.put("spId", spId);
      responseObject.put("filename", upFile.getFileName());
    } catch (IOException | VirusScanException | NullPointerException ex) {
      log.error(ex.toString());
      responseObject.put("message", "There was a problem uploading the file.");
      responseObject.put("success", false);
    }

    return responseObject;
  }

  private int addScheduleProfile(Project proj, File newImage, String filename) {
    try {
      byte[] data = FileUtils.readFileToByteArray(newImage);
      byte[] thumbnail = ImageUtil.getPngThumbnail(new ByteArrayInputStream(data), filename);
      ScheduleProfile sp = new ScheduleProfile(proj, filename, data, thumbnail, 0, sessionFactory.getCurrentSession().getLobHelper());
      proj.getR4Exhibit().getScheduleProfiles().add(sp);
      BudgesContext.getSaveService().doSubexhibitSave(BudgesContext.getProjectDAO(), proj, proj.getProgramElement(), getCurrentBudgesUser(), true);
      return sp.getId();
    } catch (IOException | NullPointerException ex) {
      log.error(ex);
      return 0;
    }
  }

  private static File createTemp(File destDir, String filewithext) throws IOException
  {
    String sfx = FilenameUtils.getExtension(filewithext);
    log.debug("sfx: " + sfx);
    if (sfx.length()>0) sfx = "." + sfx;
    else sfx = null; //.tmp
    log.debug("sfx: " + sfx + ", destDir: " + destDir);
    return File.createTempFile("___", sfx, destDir);
  }

  private static File scanAndCpToUpload(String sandbox, UploadedFile ufile, File workingDir) throws IOException, VirusScanException
  {
      log.debug("sandbox: " + sandbox + ", working dir: " + workingDir);
    File sandboxDir = new File(sandbox);
    log.debug("successfully created sandbox dir");
    log.debug("creating upload file: " + ufile.getFileName());
    File file = createTemp(sandboxDir, ufile.getFileName());
    log.debug("successfully created file in sandbox: " + file);
    ufile.write(file);
    log.debug("successfully wrote file");
    return R2Storage.scanAndPutInUpload(workingDir, file.getName(), file, ufile.getFileName());
  }
}
