package mil.dtic.cbes.submissions.uiobjects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.sso.siteminder.UserUtils;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndServiceAgencyLink;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementBase;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserAndProgramElementLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserAndServiceAgencyLinkDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.uiobjects.DetailedUserListItem.RadioValue;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.tapestry.TapestryUtil;
import netscape.ldap.LDAPException;



public class UserListItemFactory
{
  private static final Logger log = CbesLogFactory.getLog(UserListItemFactory.class);

  private UserCredentials creds;
  private final Set<ServiceAgency> adminAgencies;
  private final List<ProgramElementBase> adminPes;
  private final boolean showAllPesAgency;
  private final boolean showAllPes;
  private final boolean showTestPes;


  public UserListItemFactory(UserCredentials creds)
  {
    if (creds == null) throw new NullPointerException("UserListItemFactory()");
    this.creds = creds;
    this.showAllPesAgency = creds.checkPrivilege(Privilege.SHOW_ALL_PES_IN_AGENCY);
    this.showAllPes = creds.checkPrivilege(Privilege.SHOW_ALL_PES);
    this.showTestPes = creds.checkPrivilege(Privilege.SHOW_TEST_PE);
    this.adminAgencies = new HashSet<ServiceAgency>(creds.getUserInfo().getAllAvailableAgencies());

    BudgesUser adminUser = BudgesContext.getBudgesUserDAO().findById(
      creds.getUserInfo().getBudgesUser().getId());

    if (showAllPes || showAllPesAgency)
    {
      // appmgrs/siteadmins will see all PEs
      adminPes = Collections.emptyList(); // save on fetching this
    }
    else
    {
      // localsiteadmin will only see his PEs
      adminPes = Collections.unmodifiableList(getEditablePes(adminUser, showTestPes));
    }
  }


  private static List<ProgramElementBase> getEditablePes(BudgesUser user, boolean showTestPes)
  {
    List<ProgramElementBase> list = TapestryUtil.ognllisttransform(
        BudgesContext.getBudgesUserAndProgramElementLinkDAO().findEditableByUser(user),
        BudgesUserAndProgramElementLink.PROGRAM_ELEMENT
        );
    if (!showTestPes)
    {
      // filter out test PEs
      Iterator<ProgramElementBase> i = list.iterator();
      while (i.hasNext())
      {
        if (i.next().isTest()) i.remove();
      }
    }
    return list;
  }


  private static List<BudgesUserAndProgramElementLink> getViewableUserPes(BudgesUser user, boolean showTestPes)
  {
    List<BudgesUserAndProgramElementLink> list =
        BudgesContext.getBudgesUserAndProgramElementLinkDAO().findByUser(user);
    if (!showTestPes)
    {
      // filter out test PEs
      Iterator<BudgesUserAndProgramElementLink> i = list.iterator();
      while (i.hasNext())
      {
        if (i.next().getProgramElement().isTest()) i.remove();
      }
    }
    return list;
  }


  public UserListItem getFromObjects(LdapUser luser, BudgesUser buser)
  {
    return new UserListItem(luser, buser, UserUtils.getMemberAgenciesList(buser));
  }


  public DetailedUserListItem getDetailedFromLdapId(
    String ldapId, boolean filterUpeForLocal, String peSortProperty, boolean asc)
  {
    log.debug("getDetailedFromLdapId");

    BudgesUser buser = BudgesContext.getBudgesUserDAO().findByUserLdapId(ldapId);
    LdapUser luser;
    try
    {
      luser = BudgesContext.getLdapDAO().getLdapUser(ldapId);
    }
    catch (LDAPException e)
    {
      log.error("Error retrieving ldap user", e);
      luser = BudgesContext.getLdapDAO().getCached(buser);
    }

    // populate permission table
    // usableAgencies for siteadmin/appmgr
    List<ServiceAgency> usableAgencies = new ArrayList<ServiceAgency>();
    usableAgencies.addAll(UserUtils.getMemberAgenciesList(buser));
    usableAgencies.retainAll(adminAgencies); // Intersection of user's agencies
                                             // and admin's agencies
    // fetch list of current user-pe perms
    List<BudgesUserAndProgramElementLink> userPes = getViewableUserPes(buser, showTestPes);

    log.debug("getDetailedFromLdapId - getting pes");
    // Now remove from user perms any PEs the admin user shouldn't reach
    // Populate list of available PEs
    Iterator<BudgesUserAndProgramElementLink> i = userPes.iterator();
    List<ProgramElementBase> availPes;
    if (showAllPes)
    {
      while (i.hasNext())
      {
        // appmgr: any in this user's agencies
        ProgramElementBase pe = i.next().getProgramElement();
        boolean removeTest = (!showTestPes) ^ pe.isTest(); // remove test pes if
                                                           // not allowed
        if ((!usableAgencies.contains(pe.getServiceAgency())))
        {
          // A permission for a PE not in this user's agency
          // This should not happen
          log.error("Found pe=" + pe + " assigned to user=" + buser + ", but is not in one of his agencies");
          i.remove();
          continue;
        }
        if (removeTest) i.remove();
      }
      availPes = BudgesContext.getProgramElementBaseDAO().findByAgencies(
        new String[]{peSortProperty}, asc, showTestPes, usableAgencies.toArray(new ServiceAgency[]{}));
    }
    else if (showAllPesAgency)
    {
      // siteadmin: any in his agency ok
      // filter PEs this user has
      while (i.hasNext())
      {
        ProgramElementBase pe = i.next().getProgramElement();
        boolean removeTest = !(showTestPes || (!pe.isTest())); // remove test PEs if not allowed
        if ((!adminAgencies.contains(pe.getServiceAgency())) || removeTest)
        {
          i.remove();
        }
      }
      // All PEs in those agencies are available
      availPes = BudgesContext.getProgramElementBaseDAO().findByAgencies(
        new String[]{peSortProperty}, asc, showTestPes, usableAgencies.toArray(new ServiceAgency[]{}));
    }
    else
    {
      List<Integer> adminPeIds = TapestryUtil.ognllisttransform(adminPes, ProgramElementBase.ID);
      // localsiteadmin: only can access stuff in his perm table
      while (i.hasNext())
      {
        if (!adminPeIds.contains(i.next().getProgramElement().getId()))
        {
          if (filterUpeForLocal) i.remove();
        }
      }
      availPes = BudgesContext.getProgramElementBaseDAO().findByIdsAndAgencies(
        new String[]{peSortProperty}, asc, showTestPes, adminPeIds, usableAgencies);
    }

    // init selected userpe map, a mirror of the userPes
    Map<Integer, RadioValue> userPePerms =
      new HashMap<Integer, RadioValue>(availPes.size());
    for (BudgesUserAndProgramElementLink upe : userPes)
    {
      RadioValue rv = RadioValue.fromUpe(upe);
      if (rv == RadioValue.NONE)
      {
        log.error("An N/N permission is lying around: " + upe);
      }
      userPePerms.put(upe.getProgramElement().getId(), rv);
    }
    // set the rest of the pes to both view & edit false
    for (ProgramElementBase pe : availPes)
    {
      if (userPePerms.get(pe.getId()) == null)
      {
        userPePerms.put(pe.getId(), RadioValue.NONE);
      }
    }

    return new DetailedUserListItem(
      luser, buser, UserUtils.getMemberAgenciesList(buser), userPes, availPes, userPePerms);
  }


  /**
   * Checks if <tt>b</tt> is managed by the current UserCredentials entered into
   * this factory
   */
  public boolean isInCurrentUserOrg(BudgesUser b)
  {
    List<ServiceAgency> bagencies = UserUtils.getMemberAgenciesList(b);
    bagencies.retainAll(adminAgencies);
    boolean isInCurrentsOrg = bagencies.size() > 0;
    return isInCurrentsOrg;
  }


  /**
   * Checks if the current UserCredentials has the ldap privilege to manage
   * <tt>r2Role</tt>.
   */
  public boolean isManagedByCurrentUserAllowed(String r2Role)
  {
    return creds.getUserInfo().checkManageRole(r2Role);
  }


  public static void save(DetailedUserListItem uli, BudgesUser admin)
  {
    BudgesUser buser = BudgesContext.getBudgesUserDAO().findByUserLdapId(uli.getLdap().getLdapUserId());
    Util.setAuditFieldsForUser(buser, admin);
    // save createPeAllowed
    if (buser.isCreatePeAllowed() != uli.isCreatePeAllowed())
    {
      buser.setCreatePeAllowed(uli.isCreatePeAllowed());
      BudgesContext.getBudgesUserDAO().saveOrUpdate(buser);
    }
    saveBudgesUserAgencyData(buser, uli.getNewAgencies());
    List<BudgesUserAndProgramElementLink> userPes =
      saveUserPeData(buser, uli.getUserPePerms(), uli.getAllPes());
    uli.setUserPes(userPes); // refresh userpe list

    // evict budgesuser for lame session purposes
    BudgesContext.getBudgesUserDAO().evict(buser);
  }


  static void saveBudgesUserAgencyData(BudgesUser perstBuser, Set<ServiceAgency> newagencies)
  {
    if (newagencies == null)
    {
      log.error("Null newagencies");
      return;
    }
    BudgesUserAndServiceAgencyLinkDAO userAgencyDAO = BudgesContext.getBudgesUserAndServiceAgencyLinkDAO();
    List<BudgesUserAndServiceAgencyLink> dbUserAgencies = userAgencyDAO.findByBudgesUserId(perstBuser.getId());

    // add or remove BudgesUserAndServiceAgencyLinks as necessary
    // remove
    Iterator<BudgesUserAndServiceAgencyLink> i = dbUserAgencies.iterator();
    while (i.hasNext())
    {
      BudgesUserAndServiceAgencyLink busa = i.next();
      if (!newagencies.contains(busa.getServiceAgency()))
      {
        // this agency was removed from this user just now
        userAgencyDAO.delete(busa);
      } // else new data matches old, nothing to be done

      newagencies.remove(busa.getServiceAgency()); // stop the add for this,
                                                   // it's in the db already
      i.remove();
    }
    // add whatever agencies left in newagencies to the db
    for (ServiceAgency agency : newagencies)
    {
      BudgesUserAndServiceAgencyLink newbusa = new BudgesUserAndServiceAgencyLink();
      newbusa.setBudgesUser(perstBuser);
      newbusa.setServiceAgency(agency);
      userAgencyDAO.saveOrUpdate(newbusa);
    }
  }


  /**
   * 
   * @return updated list of BudgesUserAndProgramElementLinks
   */
  static List<BudgesUserAndProgramElementLink> saveUserPeData(BudgesUser perstBuser, Map<Integer, RadioValue> _userPePerms, List<ProgramElementBase> allPes)
  {
    BudgesUserAndProgramElementLinkDAO userPeDAO = BudgesContext.getBudgesUserAndProgramElementLinkDAO();
    ProgramElementDAO peDAO = BudgesContext.getProgramElementDAO();

    List<BudgesUserAndProgramElementLink> userPes = userPeDAO.findByUser(perstBuser);

    // make a copy
    HashMap<Integer, RadioValue> userPePerms = new HashMap<Integer, RadioValue>();
    userPePerms.putAll(_userPePerms);

    // add, update, or remove BudgesUserAndProgramElementLinks
    // decide whether to remove or update first
    Iterator<BudgesUserAndProgramElementLink> dbIter = userPes.iterator();
    while (dbIter.hasNext())
    {
      BudgesUserAndProgramElementLink userPe = dbIter.next();
      RadioValue dbRv = RadioValue.fromUpe(userPe);
      RadioValue newRv = userPePerms.get(userPe.getProgramElement().getId());
      userPePerms.remove(userPe.getProgramElement().getId()); // remove from
                                                              // to-be-added
                                                              // list
      if (newRv == null) continue; // this pe was not accessible by this admin
      if (newRv == RadioValue.NONE)
      {
        // removal time
        userPeDAO.delete(userPe); // from db
        dbIter.remove(); // from userPes list
      }
      else if (dbRv != newRv)
      {
        // update time
        newRv.updateUpe(userPe);
        userPeDAO.saveOrUpdate(userPe); // db it
      } // else do nothing, no changes
    }
    // add any new ones now
    for (Entry<Integer, RadioValue> peEntry : userPePerms.entrySet())
    {
      Integer peId = peEntry.getKey();
      RadioValue rv = peEntry.getValue();
      // skip & ignore the both-false entries
      if (rv != RadioValue.NONE)
      {
        // one of them is true, create a new BudgesUserAndProgramElementLink
        BudgesUserAndProgramElementLink userPe = new BudgesUserAndProgramElementLink();
        userPe.setUser(perstBuser);
        userPe.setProgramElement(peDAO.findById(peId)); // hopefully that find
                                                        // is cached
        rv.updateUpe(userPe);
        userPeDAO.saveOrUpdate(userPe); // plop it into the db
        userPes.add(userPe);
      }
    }

    return userPes;
  }
}