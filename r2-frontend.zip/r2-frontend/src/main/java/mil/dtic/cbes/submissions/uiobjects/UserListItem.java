package mil.dtic.cbes.submissions.uiobjects;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import mil.dtic.cbes.sso.siteminder.LdapUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.Util;


public class UserListItem extends BudgesBaseValueObject
{
  private static final long serialVersionUID = -2791544330034911568L;

  //These sort strings are OGNL specifications,
  //they should be updated match the
  //structure of this object if any
  //changes are made

  public static final String  BUDGES_USER_ID = "budgesUserId";

  private final LdapUser ldap;
  private final Integer budgesUserId;
  private final List<ServiceAgency> agenciesList;
  private final Set<ServiceAgency> agencies;
  private final String agenciesString;
  private boolean createPeAllowed;

  UserListItem(LdapUser luser, BudgesUser buser, List<ServiceAgency> agencies)
  {
    if (luser==null || buser==null || agencies==null) throw new NullPointerException("UserListItem()");
    this.ldap = luser;
    this.budgesUserId = buser.getId();
    this.createPeAllowed = buser.isCreatePeAllowed();
    this.agenciesList = agencies;
    this.agencies = new HashSet<ServiceAgency>(agencies);
    this.agenciesString = getAgenciesString(agenciesList);
  }
  
  public Set<ServiceAgency> getAgencies() {
    return agencies;
  }
  
  public List<ServiceAgency> getAgenciesList() {
    return agenciesList;
  }
  
  /** Comma delimited list of agencies this user's a member of. */
  public String getAgenciesString() {
    return agenciesString;
  }

  public LdapUser getLdap() {
    return ldap;
  }

  public Integer getBudgesUserId()
  {
    return budgesUserId;
  }
  
  public String getFormattedName() {
    return Util.formatName(ldap.getLastName(), ldap.getFirstName(),
      ldap.getMiddleInitial(), ldap.getLdapUserId());
  }
  
  public boolean isCreatePeAllowed()
  {
    return createPeAllowed;
  }

  public void setCreatePeAllowed(boolean createPeAllowed)
  {
    this.createPeAllowed = createPeAllowed;
  }

  public boolean equals(Object o) {
    if (o instanceof UserListItem) return ((UserListItem)o).budgesUserId.equals(budgesUserId);
    return false;
  }
  
  public int hashCode() {
    return budgesUserId.hashCode();
  }
  
  private static String getAgenciesString(List<ServiceAgency> agencies) {
    StringBuilder sb = new StringBuilder();
    Iterator<ServiceAgency> i = agencies.iterator();
    while(i.hasNext()) {
      sb.append(i.next().getName());
      if (i.hasNext()) sb.append(", ");
    }
    return sb.toString();
  }
}