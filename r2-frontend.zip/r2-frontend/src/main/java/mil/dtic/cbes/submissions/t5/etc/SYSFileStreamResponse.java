package mil.dtic.cbes.submissions.t5.etc;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.tapestry5.services.Response;

import mil.dtic.cbes.submissions.ValueObjects.SYSFile;

public class SYSFileStreamResponse extends UploadedBudgetFileStreamResponse<SYSFile> {
	
	public SYSFileStreamResponse(SYSFile sysFile) {
		super(sysFile);
	}

	@Override
	public void prepareResponse(Response response) {
		try {
			URI fileNameUri = new URI(null, null, uploadedBudgetFile.getName(), null);
			response.setHeader("Content-Disposition", "attachment; filename=" + fileNameUri.toASCIIString() + ";");
		} catch (URISyntaxException e) {
			
		}
	}

}
