package mil.dtic.cbes.submissions.t5.models;

import java.util.ArrayList;
import java.util.List;

import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardAttachments;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardBasicInformation;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardConfirmation;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardPESelection;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardPeBreakdown;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardSummaryAndBuild;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardTableOfContents;
import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardVolumes;
import mil.dtic.cbes.t5shared.utils.wizard.BaseMjbWizardNavigation;
import mil.dtic.cbes.t5shared.utils.wizard.PageEntry;

/**
 * Keeps the list of MJB wizard pages in the order they appear.
 */
public class R2MJBWizardNavigation extends BaseMjbWizardNavigation
{
  public R2MJBWizardNavigation()
  {
    List<PageEntry> pages = new ArrayList<PageEntry>();
    pages.add(new PageEntry(MJBWizardBasicInformation.class, "cb/MJBWizard/BasicInformation", "Basic Information"));
    pages.add(new PageEntry(MJBWizardPESelection.class, "cb/MJBWizard/PESelection", "PE Selection"));
    pages.add(new PageEntry(MJBWizardVolumes.class, "cb/MJBWizard/Volumes", "Volumes"));
    pages.add(new PageEntry(MJBWizardTableOfContents.class, "cb/MJBWizard/TableOfContents", "Table of Contents"));
    pages.add(new PageEntry(MJBWizardPeBreakdown.class, "cb/MJBWizard/PeBreakdown", "PE Volume Breakdown"));
    pages.add(new PageEntry(MJBWizardAttachments.class, "cb/MJBWizard/Attachments", "Attachments"));
    pages.add(new PageEntry(MJBWizardSummaryAndBuild.class, "cb/MJBWizard/SummaryAndBuild", "Summary and Build"));
    pages.add(new PageEntry(MJBWizardConfirmation.class, "cb/MJBWizard/Confirmation", "Confirmation"));
    setPageEntries(pages);
  }

  @Override
  public boolean isP40()
  {
    return false;
  }

  @Override
  public boolean isR2()
  {
    return true;
  }
}
