package mil.dtic.cbes.submissions.t5.encoders;

import java.util.HashMap;
import java.util.List;

import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;

/**
 * Maps PKs to an in-memory list
 */
public class PkListEncoder<T extends BudgesBaseValueObject> extends MappedEncoder<T>
{
  //private Logger log = CbesLogFactory.getLog(PkListEncoder.class);


  public PkListEncoder(List<T> objects)
  {
    super(new HashMap<Integer,T>(objects.size()), null);
    for (T obj : objects) {
      voMap.put(obj.getId(), obj);
    }
  }
}