package mil.dtic.cbes.submissions.t5.mixins;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

/**
 * The DialogTrigger mixin is used to trigger a modal dialog prompt to the user.
 * It is typically attached to a link, button, pulldown, etc. It works in
 * conjunction with the Dialog component. The DialogTrigger is bound to a Dialog
 * component and multiple triggers can be bound to the same Dialog component.
 *
 * The DialogTrigger supports callbacks to determine if the dialog should show
 * (dialogWillShow) and when the user acknowledges the dialog (dialogDidAccept,
 * dialogDidCancel). These callbacks are the names of JavaScript functions and
 * can be in the following format styles:
 *
 * Simple: "isDirty"
 * Parenthesis: "isDirty()" or "setDirty(true)"
 * Semicolon: "isDirty();" or "setDirty(true);"
 */
@Import(stack      = { CbesT5SharedModule.JQUERYTOOLSSTACK },
        library    = { "context:js/simulateClick.js", "js/DialogTrigger.js" },
        stylesheet = { "context:/css/components.css" } )
public class DialogTrigger
{
    /**
     * ID of the dialog component this trigger activates. This value MUST match
     * the Dialog component's dialogId.
     */
    @Parameter(required=true, defaultPrefix = BindingConstants.LITERAL, allowNull = false)
    private String dialogId;

    /**
     * Client event that will trigger the dialog. Typically "click" or "change".
     */
    @Parameter(value = "click", defaultPrefix = BindingConstants.LITERAL, allowNull = false)
    private String dialogEvent;

    /**
     * An optional JavaScript callback function that will be called before
     * showing the dialog. If it returns <tt>true</tt>, the dialog is shown,
     * otherwise if it returns <tt>false</tt>, the dialog is bypassed.
     */
    @Parameter(defaultPrefix=BindingConstants.LITERAL)
    private String dialogWillShow;

    /**
     * An optional JavaScript callback function that will be called after the
     * user accepts the dialog prompt. Any return values are ignored.
     */
    @Parameter(defaultPrefix=BindingConstants.LITERAL)
    private String dialogDidAccept;

    /**
     * An optional JavaScript callback function that will be called after the
     * user cancels the dialog prompt. Any return values are ignored.
     */
    @Parameter(defaultPrefix=BindingConstants.LITERAL)
    private String dialogDidCancel;

    @Inject
    private JavaScriptSupport javaScriptSupport;

    @InjectContainer
    private ClientElement element;

    void afterRender()
    {
        // Create the callbacks.
        JSONObject callbacks =
                new JSONObject("willShow",  fixCallbackMethod(dialogWillShow),
                               "didAccept", fixCallbackMethod(dialogDidAccept),
                               "didCancel", fixCallbackMethod(dialogDidCancel));

        // Initialize the JavaScript.
        javaScriptSupport.addScript("new P40.DialogTrigger('%s', '%s', '%s', %s);",
                                    element.getClientId(), dialogId, dialogEvent, callbacks);
    }

    /**
     * Fixes callbacks to be actual function calls if the user omitted the parenthesis.
     *
     * @param callbackMethod The callback function name.
     * @return A fixed callback function with parenthesis added if necessary.
     */
    private String fixCallbackMethod(String callbackMethod)
    {
        if ((callbackMethod = StringUtils.trimToNull(callbackMethod)) != null)
            if (StringUtils.endsWith(callbackMethod, ")"))
                callbackMethod += ";";
            else if (StringUtils.endsWith(callbackMethod, ");") == false)
                callbackMethod += "();";

        return callbackMethod;
    }
}
