/*
 * $Id: PeIcon.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;

public class PeIcon
{
  // private static final Logger log = CbesLogFactory.getLog(PeIcon.class);

  @Parameter(required = true)
  @Property
  private ProgramElementList pe;
  @Parameter(value = "true")
  @Property
  private boolean showLockIcons;


  public boolean isAnyEditLocks()
  {
    return pe.isPeOnlyLocked() || pe.isAnyProjectLocked();
  }

  public boolean isImported()
  {
    return Constants.PE_INITIAL_SOURCE_XML.equals(pe.getInitialSource());
  }
}
