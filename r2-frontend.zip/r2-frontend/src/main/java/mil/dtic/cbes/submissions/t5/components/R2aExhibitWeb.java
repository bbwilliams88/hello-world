package mil.dtic.cbes.submissions.t5.components;

import java.math.BigDecimal;
import java.util.Arrays;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.utility.BigDecimalUtil;

public class R2aExhibitWeb
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  
  public int addIntegers(int intOne, int intTwo)
  {
      return intOne + intTwo;
  }
  
  public String dashIfNullOrZero(BigDecimal aValue) {
    if (aValue == null) {
      return "-";
    } else if (BigDecimalUtil.equals(aValue, new BigDecimal("0.000"))){
      return "-";
    }
    else {
      return aValue.toString();
    }
  }
  public boolean isValidR3toR5() {
    return Arrays.asList(Constants.VALID_R3_to_R5_BA_NUMS).contains(PEBase.getBudgetActivity().getNumber());
  }

}