package mil.dtic.cbes.submissions.t5.components;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Response;
import org.apache.tapestry5.upload.services.MultipartDecoder;
import org.apache.tapestry5.upload.services.UploadedFile;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.t5.utils.XmlUploadProcessor;
import mil.dtic.cbes.xml.XMLToolsUtil;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.cbes.xml.XmlDocument.XmlDocumentException;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;

public class XmlMigrateToolTab extends BaseXmlToolTab {
  
  private static final Logger log = CbesLogFactory.getLog(XmlMigrateToolTab.class);
  
  @Parameter(required = true)
  @Property
  private File workingDirectory;
  @Property
  private BudgetCycle currentBudgetCycle;
  @Inject
  private MultipartDecoder decoder;
  @Inject
  private HttpServletRequest request;
  
  private HashMap<String, String> downloadList;
  
  public XmlMigrateToolTab()  {
    log.debug("XML MIGRATE TOOL TAB.");
    if (downloadList==null){
      downloadList = new HashMap<String, String>();
    }
  }
  
  public List<BudgetCycle> getBudgetCycles() {
    List<BudgetCycle> budgetCycles = getAllBudgetCycles();
    Collections.reverse(budgetCycles);
    return budgetCycles;
  }
  
  public JSONObject onMigrate(String selectedBudgetCycle) {
    List<String>errors = new LinkedList<String>();
    List<String>successList = new LinkedList<String>();
    List<String>warnings = new LinkedList<String>();
    List<JSONObject> itemsList = new LinkedList<JSONObject>();
    
    log.debug("Selected Budget Cycle:"+selectedBudgetCycle);
    
    List<XmlDocument> xmlsToMigrate = new ArrayList<XmlDocument>();
    UploadedFile upFile = decoder.getFileUpload("file");
    
    try {
      if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
        log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
        + ", expected " + getCurrentBudgesUser().getCsrfToken());
        throw new FileUploadException("Attempted to upload file without proper authorization");
      }
      xmlsToMigrate = XmlUploadProcessor.getXmlDocumentsFromUpload(decoder.getFileUpload("file"), workingDirectory, true);
    } catch(FileUploadException|XmlDocumentException e) {
      log.error(e.getMessage(), e.getCause());
      errors.add(e.getMessage());
      if(upFile == null) {
        return createResponse("No file.", errors, successList);
      } else {
        return createResponse(upFile.getFileName(), errors, successList);
      }
    }
    
    log.debug("Uploaded file name: "+upFile.getFileName());
    String localFileName = getFileNameBase(upFile.getFileName());
    
    if (StringUtils.isEmpty(selectedBudgetCycle)){
      errors.add("No budget cycle was selected.");
      return createResponse(localFileName, errors, successList);
    }
    String[] bc = StringUtils.split(selectedBudgetCycle, "_");
    String budgetCycle = bc[0];
    String budgetYear = bc[1];
    
    boolean success = false;
    File zipFile = new File(workingDirectory, "migrated_"+localFileName+".zip");
    try(FileOutputStream fos = new FileOutputStream(zipFile); 
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        ZipOutputStream zipOutputFile = new ZipOutputStream(bos);
        ) {
      for(XmlDocument xd : xmlsToMigrate) {
        String fileName = xd.getOriginalFileName();
        log.debug("Migrating XML file: " + fileName);
        String docCycle = XMLToolsUtil.getBudgetCycle(xd.getDocument());
        String docYear = XMLToolsUtil.getBudgetYear(xd.getDocument());
        boolean performedMigration = false;
        try {
          performedMigration = xd.migrateXml(budgetCycle, budgetYear);
          if(performedMigration) {
            addToZip(IOUtils.toByteArray(xd.getMigratedInputStream()), "migrated_" + getFileNameBase(fileName) + ".xml", zipOutputFile);
            itemsList.add(formatJSONItem(fileName, docCycle+" "+docYear, budgetCycle+" "+budgetYear, null, "Migration successful."));
            success = true;
          } else {
            String msg = "No migration performed: original document's XML schema is already compatible.";
            itemsList.add(formatJSONItem(fileName, docCycle+" "+docYear, budgetCycle+" "+budgetYear, msg, null));
          }
        } catch(XmlDocumentException e) {
          itemsList.add(formatJSONItem(fileName, docCycle+" "+docYear, budgetCycle+" "+budgetYear, e.getMessage(), null));
        } catch(IOException e) {
          String msg = "Unable to add migrated XML from " + fileName + " to zip file.";
          itemsList.add(formatJSONItem(fileName, docCycle+" "+docYear, budgetCycle+" "+budgetYear, msg, null));
        } finally {
          xd.closeAllStreams();
        }
      }
    } catch(FileNotFoundException e) {
      errors.add("Unable to create zip of migrated XML files.");
      return createResponse(localFileName, errors, successList);
    } catch(IOException e) {
      errors.add("Unable to create zip of migrated XML files.");
      log.error("Error closing stream", e);
      return createResponse(localFileName, errors, successList);
    }
    if (success){
      log.debug("adding " + zipFile.getAbsolutePath() + " to download list");
      String random = UUID.randomUUID().toString();
      successList.add(random);
      downloadList.put(random, zipFile.getAbsolutePath());
    }
    return createMigrationResponse(upFile.getFileName(), errors, warnings, successList, itemsList);
  }
  
  public StreamResponse onDownloadFile(String id){
    InputStream is = null;
    if (downloadList.containsKey(id)){
      try {
        is = new FileInputStream(downloadList.get(id));
        StreamResponse response = getStream(is, FileUtil.getFileNameWithoutPath(downloadList.get(id)));
        return response;
      } catch (FileNotFoundException e) {
        log.error("Could not find file to download ("+downloadList.get(id)+")",e);
        return null;
      }
      
    }
    return null;
  }
  
  private StreamResponse getStream(final InputStream is, final String fileName){
    return new StreamResponse(){
      public String getContentType(){
        return "application/zip";
      }
      public InputStream getStream() throws IOException{
        return is;
        
      }
      public void prepareResponse(Response response){
        response.setHeader("Content-Disposition", "attachment; filename="+fileName);
      }
    };
  }
  
  private JSONObject formatJSONItem(String fileName, String budgetCycle, String migratedCycle, String error, String success){
    JSONObject obj = new JSONObject();
    obj.put("filename", fileName);
    obj.put("budgetCycle", budgetCycle);
    obj.put("migratedCycle", migratedCycle);
    
    JSONObject resultsObj = new JSONObject();
    resultsObj.put("error", error);
    resultsObj.put("success", success);
    obj.put("results", resultsObj);
    return obj;
  }
  
  private JSONObject createMigrationResponse(String uploadedFileName, List<String>errors, List<String>warnings, List<String>success, List<JSONObject>itemsList){
    JSONObject rootObj = createResponse(uploadedFileName, errors, success);
    
    JSONArray warningArray = new JSONArray();
    for (String str: warnings){
      JSONObject jobj = new JSONObject();
      jobj.put("message", str);
      warningArray.put(jobj);
    }
    rootObj.put("warningMessages", warningArray);
    
    JSONArray itemsArray = new JSONArray();
    for (JSONObject jo: itemsList){
      itemsArray.put(jo);
    }
    rootObj.put("items", itemsArray);
    log.debug(rootObj.toString());
    return rootObj;
  }
  
  private JSONObject createResponse(String uploadedFileName, List<String> errors, List<String>success){
    JSONObject rootObj = new JSONObject();
    rootObj.put("action", "migrateXml");
    rootObj.put("uploadedfilename", uploadedFileName);
    
    JSONArray successArray = new JSONArray();
    for (String str: success){
      JSONObject jobj = new JSONObject();
      jobj.put("message", str);
      successArray.put(jobj);
    }
    rootObj.put("successMessages", successArray);
    
    JSONArray errorArray = new JSONArray();
    for (String str: errors){
      JSONObject jobj = new JSONObject();
      jobj.put("message", str);
      errorArray.put(jobj);
    }
    rootObj.put("errorMessages", errorArray);
    return rootObj;
  }

}
