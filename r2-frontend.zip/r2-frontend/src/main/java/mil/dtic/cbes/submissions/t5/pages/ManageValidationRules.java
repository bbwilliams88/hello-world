package mil.dtic.cbes.submissions.t5.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.mail.EmailException;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SetupRender;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.rule.Rule;
import mil.dtic.cbes.rule.RuleRepository;
import mil.dtic.cbes.rule.RuleRepositoryFactory;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.RDTERuleStatus;
import mil.dtic.cbes.submissions.ValueObjects.ValidationExemption;
import mil.dtic.cbes.submissions.dao.RDTERuleStatusDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.dao.ValidationExemptionDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.EmailUtil;

/**
 * R2 Exhibit Validation Rules administration page.
 */
@Import (
  stack   = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DATATABLESBUTTONS },
  library = { "context:js/jquery.jeditable.js", "context:js/ManageValidationRules.js" })
@Secured({"ROLE_R2AppMgr"})
public class ManageValidationRules extends T5Base {
  private static final Logger log = CbesLogFactory.getLog(ManageValidationRules.class);
  
  @Inject
  private ServiceAgencyDAO serviceAgencyDAO; 

  /**
   * POJO for rule table row.
   *
   */
  public static class BusinessRule {
    private String ruleNumber;
    private String ruleMessage;
    private String ruleGroup;
    private boolean active;
    private String audit;
//    private int exemptions;
    private String agencies;

    public String getRuleNumber() { return ruleNumber; };
    public String getRuleMessage() { return ruleMessage; };
    public String getRuleGroup() { return ruleGroup; };
    public String getAudit() { return audit; };
//    public int getExemptions() { return exemptions; };
    public String getAgencies() {return this.agencies;};

    public boolean getActive() { return active; };
    public void setActive(boolean active) { this.active = active; };
    public void setRuleNumber(String ruleNumber) { this.ruleNumber = ruleNumber; };
    public void setRuleMessage(String ruleMessage) { this.ruleMessage = ruleMessage; };
    public void setRuleGroup(String ruleGroup) { this.ruleGroup = ruleGroup; };
    public void setAudit(String audit) { this.audit = audit; };
    public void setAgencies(String agencies) {this.agencies = agencies;};

    public BusinessRule(String ruleNumber, String ruleMessage, String ruleGroup, String agencies) {
      this.ruleNumber = ruleNumber;
      this.ruleMessage = ruleMessage;
      this.ruleGroup = ruleGroup;
      this.active = true;
      this.agencies = agencies;
    }

    /**
     * Generates an audit string in the rule administration
     * table for rules with administration history.
     *
     * @param status
     * @return
     */
    private static String makeAuditString(RDTERuleStatus status) {
      StringBuilder b = new StringBuilder();
      if (status.isActive()) {
        b.append("Reactivated on ");
        
        if (null != status.getRuleActiveDate()){
        	b.append(status.getRuleActiveDate().toString());
        }
        else {
        	b.append(status.getDateModified().toString());
        }
        
      }
      else {
        b.append("Deactivated on ");
        if (null != status.getRuleInactiveDate()){
        	b.append(status.getRuleInactiveDate().toString());
        }
        else {
        	b.append(status.getDateModified().toString());
        }
      }
      BudgesUser user = status.getModifiedByBudgesUser();
      
      if (user != null) {
        b.append(" by ");
        b.append(user.getFormattedName());
      }
      return b.toString();
    }

  }

  @Inject
  private JavaScriptSupport javaScriptSupport;

  @Inject
  private ComponentResources componentResources;

  @Inject
  private Request request;

  @Persist
  @Property
  private List<BusinessRule> businessRuleList;

  @Property
  private BusinessRule businessRule;

  @Property
  private int ruleRowIndex;

  @Property
  private String message;


  @InjectPage
  private EditValidationRuleR2 editRulePage;
  
  @InjectPage
  private ManageBulkRuleExemption manageBulkRuleExemption;


  @SetupRender
  void onSetupRender()
  {
    businessRuleList = makeBusinessRuleList();
    javaScriptSupport.addScript("setupValidationRuleDatatable('%s');",componentResources.createEventLink("updateValidationActive"));
  }
  public EditValidationRuleR2 onActionFromEditRule(int index){
	  BusinessRule bRule = businessRuleList.get(index);
	  editRulePage.setBusinessRule(bRule.getRuleNumber());
	  return editRulePage;
  }

    public int getRuleExemptionCount()
    {
        Rule rule = RuleRepositoryFactory.makeRepository().narrowTo(businessRule.getRuleNumber()).getFirstRule();

        if (rule != null)
            return rule.getExemptOrganizations().size();
        else
            return 0;
    }

  @OnEvent("updateValidationActive")
  JSONArray updateValidationActive() {
    
    // determine new rule status
    String activeIndex = request.getParameter("value");
    boolean active = false;
    if (StringUtils.equals(activeIndex, "0")) {
      active = true;
    }

    String ruleIndex = request.getParameter("index");
    BusinessRule rule = businessRuleList.get(Integer.parseInt(ruleIndex));
    
    // check CSRF token and abort if invalid
    if(!StringUtils.equals(request.getParameter("csrfToken"), getCurrentBudgesUser().getCsrfToken())) {
      log.debug("csrf token mismatch: provided " + request.getParameter("csrfToken") 
      + ", expected " + getCurrentBudgesUser().getCsrfToken());
      JSONArray response = new JSONArray();
      response.put(Boolean.toString(rule.getActive()));
      response.put(rule.getAudit());
      response.put("Attempted to change rule status without proper authorization - change not saved.");
      return response;
    }
    else {
      // update rule status
      updateRuleStatus(rule, active);
  
      // build JSON response for javascript callback
      JSONArray jsonArray = new JSONArray();
      jsonArray.put(Boolean.toString(active));
      jsonArray.put(rule.getAudit());
      String adminMessage = "Updated status for " + rule.getRuleNumber() + " to " + (active ? "active." : "inactive.");
      jsonArray.put(adminMessage);
  
      generateAuditEmail(adminMessage);
  
      return jsonArray;
    }
  }

  /**
   * Enables all rules. Delete all administered rule status and
   * audit information.
   *
   */
  public void onActionFromReset() {
    RDTERuleStatusDAO dao = BudgesContext.getRDTERuleStatusDAO();
    List<RDTERuleStatus> allStatus = dao.findAll();
    dao.deleteAll(allStatus);
    String msg = "Enabling all r2 businesss rules and purging the rule status table.";
    log.info(msg);
    generateAuditEmail(msg);
  }
  
  public ManageBulkRuleExemption onActionFromBulkExemption() {
	   return manageBulkRuleExemption;
  }
  
  /**
   * Notify r2 support via email of rule administration actions.
   *
   * @param message
   */
  private void generateAuditEmail(String message) {
    try
    {
      String subject = "R2 Manage Rules Message";
      BudgesContext.getEmailUtil().sendSystemEmail(subject, message, getUserCredentials());
    }
    catch (EmailException e)
    {
      log.error("Could not send email for r2 manage rules update", e);
    }
  }

  /**
   * Alter admin page session rule status
   * Persist rule status in the database.
   *
   * @param rule
   * @param active
   */
  private void updateRuleStatus(BusinessRule rule, boolean active) {
    RDTERuleStatusDAO dao = BudgesContext.getRDTERuleStatusDAO();

    // find an existing status
    List<RDTERuleStatus> allRuleStatus = dao.findAll();
    RDTERuleStatus status = null;
    for (RDTERuleStatus s : allRuleStatus) {
      if (rule.getRuleNumber().equals(s.getRuleNumber())) {
        status = s;
        break;
      }
    }

    if (status != null && active) {
      status.activate();
    }
    else if (status != null && !active) {
      status.deactivate();
    }
    else if (status == null && !active) {
      // deactivate
      status = new RDTERuleStatus();
      status.setRuleNumber(rule.getRuleNumber());
      status.deactivate();
    }
    else if (status == null && active)
    {
      status = new RDTERuleStatus();
      status.setRuleNumber(rule.getRuleNumber());
      status.activate();
    }
    
    if (status != null) {
      // persist
      BudgesUser user = getCurrentBudgesUser();
      status.setModifiedByBudgesUser(user);
      dao.saveOrUpdate(status);

      // Alter session based business rule
      System.out.println("set audit string");
      rule.setAudit(BusinessRule.makeAuditString(status));
      rule.setActive(active);
    }
  }

  /**
   * Build a list of rules, for display within the page.
   *
   * @return
   */
  private List<BusinessRule> makeBusinessRuleList() {
    // Create a list of business rules with audit information

    // get all audit info
    RDTERuleStatusDAO dao = BudgesContext.getRDTERuleStatusDAO();
    Map<String, RDTERuleStatus> allRuleStatus = new HashMap<String, RDTERuleStatus>();
    for (RDTERuleStatus ruleStatus : dao.findAll()) {
      allRuleStatus.put(ruleStatus.getRuleNumber(), ruleStatus);
    }

    // mrg
    ValidationExemptionDAO veDAO = BudgesContext.getValidationExemptionDAO();
    List<ValidationExemption> ves = veDAO.findAll();

    // get all rules
    RuleRepository ruleRepository = RuleRepositoryFactory.makeRepository();

    // generate rule administration list
    List<BusinessRule> rules = new ArrayList<BusinessRule>();
    for (Rule rule : ruleRepository.getRules()) {
      BusinessRule businessRule = new BusinessRule(rule.getRuleNumber(), rule.getRuleMessage(), rule.getRuleGroup(), createExemptAgenciesList(rule));
      rules.add(businessRule);
      
      if (allRuleStatus.containsKey(rule.getRuleNumber())) {
        // display stored rule status and audit info
    	try {  
    		RDTERuleStatus status = allRuleStatus.get(rule.getRuleNumber());
    		businessRule.setAudit(BusinessRule.makeAuditString(status));
    		businessRule.setActive(status.isActive());
    	}
    	catch(Exception e){
    		log.warn("Failure processing audit data for rule " + rule.getRuleNumber());
    	}
      }
    }

    setAdminMessage(rules.size() + " rules. " + allRuleStatus.size() + " have audit history.");

    return rules;
  }

  private void setAdminMessage(String adminMessage) {
    message = adminMessage;
  }
  
  
  /**
   * Create a list of exempt agencies for each rule
   * 
   * @param rule
   * @return
   */
  private String createExemptAgenciesList(Rule rule){
      List<String> exemptAgencies = new ArrayList<>();
      
      for(String saCode : rule.getExemptOrganizations()){
          exemptAgencies.add(serviceAgencyDAO.findByCode(saCode).getName());
      }
      
      return exemptAgencies.stream().collect(Collectors.joining(", ")).toString();
  }
}