package mil.dtic.cbes.submissions.t5.pages;

import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.util.TextStreamResponse;
import org.springframework.util.CollectionUtils;

import mil.dtic.cbes.exceptions.ApiRequestException;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleProfile;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.xml.XmlToJava;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util.CloneFailedException;

public class NewR2SaveXml extends NewR2Endpoint
{
  private static final Logger log = CbesLogFactory.getLog(NewR2SaveXml.class);

  @Inject
  private HttpServletRequest request;

  @Log
  TextStreamResponse onActivate(String peNumber)
  {
    JSONObject responseObject = new JSONObject();
    ProgramElementDAO peDao = BudgesContext.getProgramElementDAO();
//    ProjectDAO projDao = BudgesContext.getProjectDAO();
    XmlToJava xtj = new XmlToJava(getCurrentBudgesUser());
    try {
      ProgramElement pe = getRequestedPe(peNumber);
      if (!getUserCredentials().savePeAllowed(pe))
      {
        throw new ApiRequestException("User does not have permission to edit this PE.");
      }
      if (getUserCredentials().isLockedByOther(pe))
      {
        throw new ApiRequestException("This PE has already been locked for editing by another user.");
      }

      String r2XmlString = request.getParameter("r2-xml");
      String requestTestPe = request.getParameter("r2-testpe");
      JSONObject requestR4ids = new JSONObject(request.getParameter("r4-image-ids"));
//    String requestProjectIds = request.getParameter("r2-project-ids");
//    JSONArray reqProjectIds = new JSONArray(requestProjectIds);

      if(r2XmlString == null) {
        throw new ApiRequestException("No XML provided.");
      }

      R2ExhibitList r2el = xtj.xmlToR2ExhibitList(r2XmlString.getBytes()).getR2ExhibitList();
      if(r2el == null || CollectionUtils.isEmpty(r2el.getProgramElements())) {
        throw new ApiRequestException("Could not parse any Program Element(s) in XML.");
      }
      ProgramElement pe2 = r2el.getProgramElements().get(0);

      pe2.setSubmissionStatus(pe.getSubmissionStatus());
      pe2.setEditable(pe.getEditable());
      pe2.setInitialSource(pe.getInitialSource());
      pe2.setState(pe.getState());
      pe2.setId(pe.getId());

      if ("true".equals(requestTestPe)) {
        pe2.setTest(true);
      } else {
        pe2.setTest(false);
      }

      for (Project pe2proj : pe2.getProjects()) {
        if (pe2proj.getR4Exhibit() != null) {
          Set<ScheduleProfile> pe2r4set = new LinkedHashSet<ScheduleProfile>();
          for (ScheduleProfile newProfile : pe2proj.getR4Exhibit().getScheduleProfiles()) {
            log.debug(newProfile.getImageFileName());
            int oldSpId = requestR4ids.getInt(newProfile.getImageFileName());
            try {
              ScheduleProfile newSp = BudgesContext.getScheduleProfileDAO().findById(oldSpId).copy(getCurrentBudgesUser(), pe2proj);
              log.debug(newSp.getImageFileName());
              pe2r4set.add(newSp);
            } catch (CloneFailedException | SQLException e) {
              log.error(e.toString());
              log.error("it is likely we could not find a schedule profile with that id.");
            }
          }

          pe2proj.getR4Exhibit().setScheduleProfiles(pe2r4set);
        }
      }

      pe.getProjects().clear();
      pe.getOtherAdjustmentDetails().clear();
      peDao.update(pe);
      peDao.evict(pe);
      peDao.update(pe2);

      JSONArray newProjectIds = new JSONArray();
      JSONObject newR4ids = new JSONObject();
      for (Project pe2newProj : pe2.getProjects()) {
        newProjectIds.put(pe2newProj.getId());
        if (pe2newProj.getR4Exhibit() != null) {
          for (ScheduleProfile newProf : pe2newProj.getR4Exhibit().getScheduleProfiles()) {
            newR4ids.put(newProf.getImageFileName(), newProf.getId());
          }
        }
      }
      responseObject.put("projectIDs", newProjectIds);
      responseObject.put("r4ImageIds", newR4ids);

      String hasWarnings = "The program element successfully saved, but some problems were found.";
      String isValid = "The program element successfully saved. Everything is valid.";

      responseObject = validateAndCreateResponse(responseObject, pe, isValid, hasWarnings);

    } catch (ApiRequestException e) {
      responseObject = createErrorResponse(e.getMessage());
    }
    return new TextStreamResponse("application/json", responseObject.toString());
  }
}
