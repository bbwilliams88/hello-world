package mil.dtic.cbes.submissions.t5.components;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.ValueObjects.AccomplishmentPlannedProgram;
import mil.dtic.cbes.submissions.ValueObjects.CongressionalAddDetail;
import mil.dtic.cbes.submissions.ValueObjects.JointFunding;
import mil.dtic.cbes.submissions.ValueObjects.MajorPerformer;
import mil.dtic.cbes.submissions.ValueObjects.OtherProgramFundingSummary;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.utility.BigDecimalUtil;

public class R2aAccomplishmentsThroughPerformers
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  @Property
  private AccomplishmentPlannedProgram r2aAccomplishmentPlannedProgram;
  @Property
  private JointFunding jointFunding;
  @Property
  private CongressionalAddDetail CongressionalAddDetail;
  @Property
  private OtherProgramFundingSummary otherProgramFundingSummary;
  @Property
  private MajorPerformer r2aMajorPerformer;
  
  public int addIntegers(int intOne, int intTwo)
  {
      return intOne + intTwo;
  }
  public boolean isValidR3toR5() {
    return Arrays.asList(Constants.VALID_R3_to_R5_BA_NUMS).contains(PEBase.getBudgetActivity().getNumber());
  }
  
  public String yearDashMonth(Date inputDate) {
    if (inputDate != null) {
      SimpleDateFormat format1 = new SimpleDateFormat("MM-yyyy");
      return format1.format(inputDate);
    } else {
      return "";
    }
  }
  
  public BigDecimal r2aAccomplishmentsTotalPy(Set<AccomplishmentPlannedProgram> plannedPrograms)
  {
    BigDecimal sumTotal = new BigDecimal(0);
    for (AccomplishmentPlannedProgram plannedProgram : plannedPrograms)
    {
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingPy());
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getOtherFundingPy());
    }
    return sumTotal;
  }
  public BigDecimal r2aAccomplishmentsTotalCy(Set<AccomplishmentPlannedProgram> plannedPrograms)
  {
    BigDecimal sumTotal = new BigDecimal(0);
    for (AccomplishmentPlannedProgram plannedProgram : plannedPrograms)
    {
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingCy());
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getOtherFundingCy());
    }
    return sumTotal;
  }
  public BigDecimal r2aAccomplishmentsTotalBy1Base(Set<AccomplishmentPlannedProgram> plannedPrograms)
  {
    BigDecimal sumTotal = new BigDecimal(0);
    for (AccomplishmentPlannedProgram plannedProgram : plannedPrograms)
    {
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1Base());
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getOtherFundingBy1Base());
    }
    return sumTotal;
  }
  public BigDecimal r2aAccomplishmentsTotalBy1Ooc(Set<AccomplishmentPlannedProgram> plannedPrograms)
  {
    BigDecimal sumTotal = new BigDecimal(0);
    for (AccomplishmentPlannedProgram plannedProgram : plannedPrograms)
    {
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1Ooc());
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getOtherFundingBy1Ooc());
    }
    return sumTotal;
  }
  public BigDecimal r2aAccomplishmentsTotalBy1(Set<AccomplishmentPlannedProgram> plannedPrograms)
  {
    BigDecimal sumTotal = new BigDecimal(0);
    for (AccomplishmentPlannedProgram plannedProgram : plannedPrograms)
    {
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1());
      sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getOtherFundingBy1());
    }
    return sumTotal;
  }
  public String dashIfNullOrZero(BigDecimal aValue) {
    if (aValue == null) {
      return "-";
    } else if (BigDecimalUtil.equals(aValue, new BigDecimal("0.000"))){
      return "-";
    }
    else {
      return aValue.toString();
    }
  }
  public BigDecimal projectCongressionalAddsSubtotal(Set<CongressionalAddDetail> addDetails, String year) {
    BigDecimal sumTotal = new BigDecimal("0.000");
    
    if(year != null && !StringUtils.isEmpty(year)){
        if (year.equals("py")) {
          for (CongressionalAddDetail addDetail : addDetails)
          {
            sumTotal = BigDecimalUtil.add(sumTotal, addDetail.getFundingPy());
          }
        }
        if (year.equals("cy")) {
          for (CongressionalAddDetail addDetail : addDetails)
          {
            sumTotal = BigDecimalUtil.add(sumTotal, addDetail.getFundingCy());
          }
        }
    }
    return sumTotal;
  }
  public BigDecimal agencyFundingSubtotal(String year) {
    BigDecimal sumTotal = new BigDecimal("0.000");
    if(year != null && !StringUtils.isEmpty(year)){
        if (year.equals("Py")) {
          for (AccomplishmentPlannedProgram plannedProgram : PEProject.getR2aExhibit().getAccomplishmentsPlannedPrograms()) {
            sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingPy());
          }
          for (JointFunding jf : PEProject.getR2aExhibit().getJointFundings()) {
            sumTotal = BigDecimalUtil.subtract(sumTotal, jf.getFundingPy());
          }
        }
        if (year.equals("Cy")) {
          for (AccomplishmentPlannedProgram plannedProgram : PEProject.getR2aExhibit().getAccomplishmentsPlannedPrograms()) {
            sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingCy());
          }
          for (JointFunding jf : PEProject.getR2aExhibit().getJointFundings()) {
            sumTotal = BigDecimalUtil.subtract(sumTotal, jf.getFundingCy());
          }
        }
        if (year.equals("By1Base")) {
          for (AccomplishmentPlannedProgram plannedProgram : PEProject.getR2aExhibit().getAccomplishmentsPlannedPrograms()) {
            sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1Base());
          }
          for (JointFunding jf : PEProject.getR2aExhibit().getJointFundings()) {
            sumTotal = BigDecimalUtil.subtract(sumTotal, jf.getFundingBy1Base());
          }
        }
        if (year.equals("BY1OOC")) {
          for (AccomplishmentPlannedProgram plannedProgram : PEProject.getR2aExhibit().getAccomplishmentsPlannedPrograms()) {
            sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1Ooc());
          }
          for (JointFunding jf : PEProject.getR2aExhibit().getJointFundings()) {
            sumTotal = BigDecimalUtil.subtract(sumTotal, jf.getFundingBy1Ooc());
          }
        }
        if (year.equals("By1")) {
          for (AccomplishmentPlannedProgram plannedProgram : PEProject.getR2aExhibit().getAccomplishmentsPlannedPrograms()) {
            sumTotal = BigDecimalUtil.add(sumTotal, plannedProgram.getFundingBy1());
          }
          for (JointFunding jf : PEProject.getR2aExhibit().getJointFundings()) {
            sumTotal = BigDecimalUtil.subtract(sumTotal, jf.getFundingBy1());
          }
        }
    }
    return sumTotal;
  }
  
  public boolean hasOtherProgramFundingSummaries(Project testProject) {
      return testProject.getR2aExhibit().getOtherProgramFundingSummaries().size() > 0;
  }
}