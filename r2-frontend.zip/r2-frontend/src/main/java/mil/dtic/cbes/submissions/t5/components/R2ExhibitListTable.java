package mil.dtic.cbes.submissions.t5.components;

import java.util.List;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElementList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.cbes.submissions.t5.models.R2ListFilters;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

@Import(stack   = {CbesT5SharedModule.DATATABLESBUTTONS },
		library={
				"context:/js/r2dataTableExhibitIcons.js",
				"classpath:${cb.assetpath}/js/urlencoder.js",
				"context:/js/r2ExhibitListTable.js"
				}
		)
public class R2ExhibitListTable extends PeListBase {

  private static final Logger log = CbesLogFactory.getLog(R2ExhibitListTable.class);

  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;

  @Inject
  private BudgetCycleDAO bcDAO;

  @SessionState
  private R2ListFilters filterState;

  public R2ExhibitListTable() {
    // TODO Auto-generated constructor stub
  }

  void afterRender()
  {
//    String url = resources.createEventLink("GetPeJson").toString();
//    Link budgetCycleFilterPageLink = resources.createEventLink("BudgetCycleChange");
//    jsSupport.addScript("setupBudgetCycleReload('%s');", budgetCycleFilterPageLink);
//    jsSupport.addScript("setUrl('%s');", url);

    JSONObject links = new JSONObject(
        "r2ExhibitTableDataUrl", resources.createEventLink("GetPeJson")+"",
        "budgetCycleChangedUrl", resources.createEventLink("BudgetCycleChange")+""
        );
    jsSupport.addScript("r2ExhibitTablePageInit(%s);", links.toCompactString());
  }


  JSONObject onGetPeJson()
  {
    List<ProgramElementList> peList = getPesBasedOnPermissionsAndFilter();
    log.debug("Getting pejson:"+peList.size());
    List<String> allowedProps = Lists.newArrayList(new String[]{
      "id",
      "lineNum", "number", "title", "userDefinedTag", "baNum", "numProjects",
      "serviceAgencyCode", "serviceAgencyName", "budgetCycle", "budgetYear",
      "dateCreated", "dateModified",
      "submissionStatus"
    });
    JSONObject rootObj = new JSONObject();
    rootObj.put("recordsTotal", peList.size());
    rootObj.put("recordsFilter", peList.size());
    rootObj.put("draw", "1");
    JSONArray jsonArray = new JSONArray();
    for (ProgramElementList element : peList)
    {
      JSONObject obj = new JSONObject(element.toJson(allowedProps));
      obj.put("numbercopy", element.getNumber());
      obj.put("formattedDateCreated", formatDatetime(element.getDateCreated()));
      obj.put("formattedDateModified", formatDatetime(element.getDateModified()));
      // Somehow the modifier ldap id was null for one of the records...
      // insert a blank string to fail more gracefully
      String creator = getCreatorName(element) == null ? "" : getCreatorName(element);
      String modifier = getModifierName(element) == null ? "" : getModifierName(element);
      obj.put("creatorDisplayName", creator);
      obj.put("modifierDisplayName", modifier);
      obj.put("r3Exists", element.isR3Exists());
      obj.put("r4Exists", element.isR4Exists());
      obj.put("r4aExists", element.isR4aExists());
      obj.put("r5Exists", element.isR5Exists());
      obj.put("test", element.isTest());
      if (element.getFormat()!=null && element.getFormat().isR2Long())
      {
        obj.put("r2Long", true);
      }
      else
      {
        obj.put("r2Long", false);
      }
      obj.put("imported", Constants.PE_INITIAL_SOURCE_XML.equals(element.getInitialSource()));
      obj.put("valid", element.getSubmissionStatus().isValid());
      obj.put("allLocked", element.isEntirePeLocked());
      obj.put("anyLocked", element.isAnyProjectLocked());
      obj.put("peLocked", element.isPeOnlyLocked());
      obj.put("errorExists", element.isErrorExists());
      obj.put("warningExists", element.getSubmissionStatus().isInvalid());

      jsonArray.put(obj);
    }
    rootObj.put("aaData", jsonArray);
    return rootObj;
  }

  @Override
  public List<BudgetCycle> getAllBudgetCycles()
  {
    return bcDAO.getBudgetCycles();
  }

  public List<ServiceAgency> getServiceAgencies()
  {
    return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
  }

  void onBudgetCycleChange(String reloadBudgetCycle)
  {
    filterState.setBudgetCycle(bcDAO.findByValue(reloadBudgetCycle));
    if (filterState.getBudgetCycle()==null)
    {
      filterState.setBudgetCycle(new BudgetCycle());
    }
  }

}
