package mil.dtic.cbes.submissions.t5.components;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.ValueObjects.QuarterDate;
import mil.dtic.cbes.submissions.ValueObjects.ScheduleDetail;
import mil.dtic.cbes.submissions.ValueObjects.SubProjectSchedule;

public class R4aExhibitWeb
{
  @Parameter(required = true)
  @Property
  private ProgramElement PEBase;
  @Parameter(required = true)
  @Property
  private Project PEProject;
  @Property
  private SubProjectSchedule SPSchedule;
  @Property
  private ScheduleDetail SPDetails;
  @Property
  private QuarterDate qDate;
  
  public int addIntegers(int intOne, int intTwo)
  {
      return intOne + intTwo;
  }
  public boolean areIntsEqual(int intOne, int intTwo)
  {
    return intOne == intTwo;
  }
}
