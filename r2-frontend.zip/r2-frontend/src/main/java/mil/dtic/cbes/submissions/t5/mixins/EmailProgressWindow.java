package mil.dtic.cbes.submissions.t5.mixins;

import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.InitializationPriority;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

@Import(stack=CbesT5SharedModule.JQUERYSTACK, library="context:/js/progress.js")
public class EmailProgressWindow
{
  @Inject
  private JavaScriptSupport jsSupport;
  @InjectContainer
  private ClientElement element;

  void afterRender()
  {
    jsSupport.addScript(InitializationPriority.LATE, String.format("R2.emailProgressWindow('#%s');", element.getClientId()));
  }
}