package mil.dtic.cbes.submissions.t5.models;

import java.io.Serializable;

import mil.dtic.cbes.submissions.ValueObjects.NarrowPeListBy;

/**
 * R2Manage/R2Select filter dropdown state
 */
public class R2ListFilters extends NarrowPeListBy implements Serializable
{
  private static final long serialVersionUID = 1L;
}