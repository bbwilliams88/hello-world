package mil.dtic.cbes.submissions.t5.pages;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Logger;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.io.FileUtils;
import org.apache.tapestry5.PersistenceConstants;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Response;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.hibernate.HibernateException;
import org.springframework.security.access.annotation.Secured;

import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.rule.RuleGroup;
import mil.dtic.cbes.rule.RuleGroupVisitor;
import mil.dtic.cbes.rule.RuleGroupVisitorFactory;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.sso.siteminder.UserUtils;
import mil.dtic.cbes.submissions.ValueObjects.BudgesBaseValueObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.PELockDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.t5.encoders.PkListEncoder;
import mil.dtic.cbes.submissions.t5.pages.saAdmin.ManageAppropriation;
import mil.dtic.cbes.submissions.t5.pages.saAdmin.ManageServiceAgency;
import mil.dtic.cbes.submissions.t5.pages.saAdmin.ManageVolumes;
import mil.dtic.cbes.submissions.t5.pages.saAdmin.user.ManageLIPriv;
import mil.dtic.cbes.submissions.t5.pages.saAdmin.user.ManagePEPriv;
import mil.dtic.cbes.submissions.validation.backend.CacheFactory;
import mil.dtic.cbes.submissions.validation.backend.ProgramElementValidator;
import mil.dtic.cbes.submissions.validation.backend.ValidationService;
import mil.dtic.cbes.t5shared.utils.TapestryUtil;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

@Secured({ "ROLE_R2AppMgr" })
public class AdminTools extends T5Base {
    private static final Logger log = CbesLogFactory.getLog(AdminTools.class);
    private static final String MANAGE_SVC_AGENCY = "Manage Service Agencies";
    private static final String MANAGE_APPNS = "Manage Appropriations";
    private static final String MANAGE_JB_VOLUMES = "Manage DW MJB Volumes";
    private static final String MANAGE_LI_PRIV = "Manage LI Privileges";
    private static final String MANAGE_PE_PRIV = "Manage PE Privileges";

    @Inject
    private ServletContext servletContext;
    @Inject
    private HttpServletRequest servletRequest;
    @Inject
    private HttpServletResponse servletResponse;

    // @Inject
    // @Property
    // private CbesLogManager cbesLogManager;
    @Inject
    @Property
    private ConfigService config;
    @Inject
    private ValidationService validationService;
    @Inject
    private BudgesUserDAO userDAO;
    @Inject
    private ProgramElementDAO peDAO;
    @Inject
    private PELockDAO peLockDAO;

    @InjectComponent
    private Form deleteUserForm;

    @InjectPage
    private NewAdminUsers adminUsers;

    @InjectPage
    private NewHomePage newHomePage;

    @Property
    private BudgesUser selectedBudgesUser;
    @Property
    private String validationBudgetCycle;
    @Property
    private int validationBudgetYear;
    @Property
    private String deletedUserId;
    @Property
    private int sleepVal;
    @Property
    private String loggerName;
    @Property
    private String logLevel;
    
    //@Property
    //@SuppressWarnings("unused")
    //private org.apache.log4j.Logger currentLogger;
    //private org.apache.logging.log4j.Logger currentLogger;
    
    @Property
    private HttpSession currentSession;
    @Property
    private long allocatedMemory;
    @Property
    private long freeMemory;
    @Property
    private long maxMemory;

    @InjectComponent
    private Form xmlResourcesForm;

    @Property
    private UploadedFile xmlResourcesZipFile;

    @Property
    private String adminAgencySelect;
    
    @Property
    private UploadedFile statusTrackerTemplateFile;
    
    @Persist(PersistenceConstants.FLASH)
    @Property
    private String errorMessage;

    void setupRender() {
        allocatedMemory = Runtime.getRuntime().totalMemory() / 1024 / 1024;
        freeMemory = Runtime.getRuntime().freeMemory() / 1024 / 1024;
        maxMemory = Runtime.getRuntime().maxMemory() / 1024 / 1024;
    }

    @Log
    void onRefreshConfig() {
        config.markConfigCacheForReload();
    }

    @Log
    void onRefreshBusiness() {
        validationService.markRulesCacheForReload();
    }

    @Log
    void onOldRefreshConfig() {
        // config.reload(true);
    }

    @Log
    void onOldRefreshBusiness() {
        // validationService.resetValidators();
    }

    @Log
    void onInvalidateSession(String sessionId) {
        HttpSession killit = null;
        for (HttpSession hs : getSessions()) {
            if (hs.getId().equals(sessionId)) {
                killit = hs;
                break;

            }
        }
        if (killit != null) {
            log.info("Invalidating " + killit);
            killit.invalidate();
        } else {
            log.error("Didn't find that session, oh noes - " + sessionId);
        }
    }

    Object onAllUserEmails() {
        List<String> emailList = userDAO.getEmailOfAllActiveUsers();
        if (CollectionUtils.isNotEmpty(emailList)) {
            // average # of chars in an email address = 20?
            StringBuilder sb = new StringBuilder(20 * emailList.size());
            for (String email : emailList)
                sb.append(email + ";");
            String emailsAsString = sb.toString();
            byte[] emailsAsByteArray = emailsAsString.getBytes();
            log.debug("Returning email addresses for all active users, total of " + emailList.size() + " : "
                    + emailsAsString);
            final ByteArrayInputStream bis = new ByteArrayInputStream(emailsAsByteArray);
            return new StreamResponse() {
                @Override
                public void prepareResponse(Response response) {
                    response.setHeader("Content-Disposition", "attachment; filename=" + "R2UserEmails.txt");
                    response.setContentLength(bis.available());
                }

                @Override
                public String getContentType() {
                    return "text/plain";
                }

                @Override
                public InputStream getStream() throws IOException {
                    return bis;
                }
            };
        }
        return null;
    }

    @Log
    void onClearAllLocks(boolean clearEntireToo) {
        peLockDAO.lockClearAll(clearEntireToo);
    }

    @Log
    Object onSuccessFromLoginAsForm() throws IOException {
        // TODO what we really need to do is log in as the new user in a brand new
        // session
        if (null == selectedBudgesUser || selectedBudgesUser.getRole().equals(LdapDAO.GROUP_NONE)) {
            log.debug("AdminTools:onSuccessFromLoginAsForm - selectedBudgesUser is null or has no roles"); // CXE-6630
            return AdminTools.class;
        }
        log.debug("AdminTools:onSuccessFromLoginAsForm - Attempting Login as " + selectedBudgesUser.getUserLdapId());
        getUserCredentials().setUserInfo(UserUtils.createUserInfo(servletRequest.getSession().getId(),
                selectedBudgesUser.getUserLdapId()));
        log.debug("AdminTools:onSuccessFromLoginAsForm -Logged in as " + getUserCredentials().getUserInfo());
        return newHomePage;
    }

    @Log
    Object onSuccessFromAgencyAdminForm() throws IOException {

        Object defaultPage = ManageServiceAgency.class;

        if (null == adminAgencySelect) {
            return defaultPage;
        }

        if (adminAgencySelect.equals(AdminTools.MANAGE_SVC_AGENCY)) {
            return ManageServiceAgency.class;
        } else if (adminAgencySelect.equals(AdminTools.MANAGE_APPNS)) {
            return ManageAppropriation.class;
        } else if (adminAgencySelect.equals(AdminTools.MANAGE_JB_VOLUMES)) {
            return ManageVolumes.class;
        } else if (adminAgencySelect.equals(AdminTools.MANAGE_LI_PRIV)) {
            return ManageLIPriv.class;
        } else if (adminAgencySelect.equals((AdminTools.MANAGE_PE_PRIV))) {
            return ManagePEPriv.class;
        }

        return defaultPage;
    }

    private List<ProgramElement> selectPes(String budgetcycle, int budgetyear) {
        List<ProgramElement> pes;
        BudgetCycle bc = new BudgetCycle();
        bc.setCycle(budgetcycle);
        bc.setBudgetYear(budgetyear);
        if ("*".equals(budgetcycle))
            pes = peDAO.findAll();
        else
            pes = peDAO.findByBudgetCycle(bc);
        log.debug("selectPes - " + pes.size() + " pes");
        return pes;
    }

    /** Check each PE in db for validity and mark as such */
    public void onSuccessFromValidatePesForm() {
        String budgetcycle = validationBudgetCycle;
        Integer budgetyear = validationBudgetYear;
        log.debug("doUpdateValidPes " + budgetcycle + budgetyear);

        List<ProgramElement> allPes = selectPes(budgetcycle, budgetyear);

        Map<String, List<ServiceAgency>> agencyCache = CacheFactory.getSuffixAgencyCache();
        Map<String, ServiceAgency> saCache = CacheFactory.getServiceAgencyCache();

        int errorCount = 0;

        for (ProgramElement pe : allPes) {
            log.debug("doUpdateValidPes - first pass " + pe);
            boolean valid = false;
            boolean hasErrors = false;
            RuleGroup pev = new ProgramElementValidator(pe, saCache, agencyCache, true /* Enable Cache Query */);
            RuleGroupVisitor visitor = RuleGroupVisitorFactory.makeVisitor();
            visitor.visit(pev, pe.getServiceAgency().getCode());
            valid = visitor.getRuleViolations().isEmpty();
            if (valid)
                pe.setSubmissionStatus(PeSubmissionFlag.VALID);
            else
                pe.setSubmissionStatus(PeSubmissionFlag.INVALID);
            log.debug("doUpdateValidPes - " + pe + " valid=" + valid + " errors=" + hasErrors);
        }
        BudgesContext.getProgramElementDAO().saveOrUpdateAll(allPes);
        log.debug("doUpdateValidPes - done - errors=" + errorCount);
        BudgesContext.getCacheService().nukeCaches();
    }

    @Log
    void onSuccessFromDeleteUserForm() {
        try {
            BudgesUser user = userDAO.findByUserLdapId(deletedUserId);
            if (user != null) {
                userDAO.delete(user);
            } else {
                String msg = "User id " + deletedUserId + " not found";
                deleteUserForm.recordError(msg);
                log.error(msg);
            }
        } catch (HibernateException e) {
            log.error("doDeleteUserRow failed", e);
            deleteUserForm.recordError("Delete user failed due to database error: " + e.getMessage());
        } catch (RuntimeException e) {
            log.error("doDeleteUserRow failed", e);
            deleteUserForm.recordError("System error while trying to delete user: " + e.getMessage());
        }
    }

    @Log
    void onSuccessFromSleepForm() throws InterruptedException {
        int secs = Integer.valueOf(sleepVal);
        log.debug("doSleep " + secs);
        Thread.sleep(secs * 1000);
    }

    // @Log
    // void onSuccessFromLogForm() {
    //     setLogLevel(loggerName, logLevel);
    // }

    public long getTotalFreeMemory() {
        return maxMemory - allocatedMemory + freeMemory;
    }

    public int getProcessors() {
        return Runtime.getRuntime().availableProcessors();
    }

    @SuppressWarnings("unchecked")
    public Collection<HttpSession> getSessions() {
        ArrayList<HttpSession> sessions = new ArrayList<HttpSession>((Set<HttpSession>) servletContext.getAttribute(
                Constants.APPKEY_ALL_SESSIONS));
        Collections.sort(sessions, new Comparator<HttpSession>() {
            @Override
            public int compare(HttpSession o1, HttpSession o2) {
                try {
                    return Long.valueOf(o2.getLastAccessedTime()).compareTo(o1.getLastAccessedTime());
                } catch (IllegalStateException e) {
                    log.error("error sorting: invalidated session", e);
                    return 0;
                }
            }
        });
        return sessions;
    }

    public BudgesUser getCurrentActiveUser() {
        try {
            UserCredentials uc = (UserCredentials) currentSession.getAttribute("state:r2:user.credentials");
            if (uc != null && uc.getUserInfo() != null)
                return uc.getUserInfo().getBudgesUser();
        } catch (IllegalStateException e) {
            log.error("couldn't get active user due to invalidated session:  " + e.getMessage());
        }
        return null;
    }

    public List<String> getCurrentAgencies() {
        BudgesUser user = getCurrentActiveUser();
        if (user != null) {
            return TapestryUtil.ognllisttransform(user.getAgencies(), ServiceAgency.CODE);
        }
        return Collections.emptyList();
    }

    public Date getCurrentAccessDate() {
        try {
            return new Date(currentSession.getLastAccessedTime());
        } catch (IllegalStateException e) {
            log.error("couldn't get current access date due to invalidated session", e);
            return new Date(0);
        }
    }

//    private void setLogLevel(String loggerName, String logLevelName) {
//        if (StringUtils.isNotEmpty(loggerName)) {
//            loggerName = loggerName.trim();
//            cbesLogManager.setLogLevel(loggerName, logLevelName);
//        }
//    }

    public List<BudgesUser> getAllActiveUsers() {
        return userDAO.findAllActive(true, BudgesUser.LAST_NAME);
    }

    // CXE--6630
    public List<BudgesUser> getLegitimateUsers() {
        return userDAO.findLegitimateUsers();
    }

    public <T extends BudgesBaseValueObject> ValueEncoder<T> getEncoder(List<T> objects) {
        return new PkListEncoder<T>(objects);
    }

    @Log
    void onSuccessFromXmlResourcesForm() {
        String filePrefix = getUserCredentials().getUserInfo().getLdapUser().getLdapUserId()
                + "_XmlResourcesZipUpload_";
        R2Storage r2Storage = new R2Storage(filePrefix);
        try {
            File sandboxFile = r2Storage.createTempFileInSandbox(FilenameUtils.getExtension(xmlResourcesZipFile
                    .getFileName()));
            xmlResourcesZipFile.write(sandboxFile);
            File xmlPackageFile = r2Storage.scanAndPutInUpload(new File(config.getWorkingFolder()), sandboxFile
                    .getName(), sandboxFile, xmlResourcesZipFile.getFileName());
            Util.unzipComptrollerXMLPackageToXmlResourceBaseDir(xmlPackageFile);
            BudgesContext.getBudgesXslCache().clearXsltCache();
        } catch (IOException | VirusScanException e) {
            String msg = "Failed to process Xml Resources Zip file (see logs)";
            log.error(msg, e);
            xmlResourcesForm.recordError(e.getMessage() + " - " + msg);
        }

    }
    
    @Log
    void onSuccessFromChangeStatusTrackerTemplateForm() {
    	log.info(String.format("Filename: %s, file size: %d bytes, file content type: %s", statusTrackerTemplateFile.getFileName(), 
    			statusTrackerTemplateFile.getSize(), statusTrackerTemplateFile.getContentType()));
    	
    	File file = R2Storage.writeUploadedFileToDisk(statusTrackerTemplateFile, config.getWorkingFolder(), R2Storage.STATUS_TRACKER_FILENAME);
    		
    	try {
			R2Storage.scan(file);
		} catch (VirusScanException e) {
			FileUtils.deleteQuietly(file);
			e.printStackTrace();
		}
    }
    
    Object onUploadException(FileUploadException ex) {
    	errorMessage = "Upload exception: " + ex.getMessage();
    	return this;
    }
}
