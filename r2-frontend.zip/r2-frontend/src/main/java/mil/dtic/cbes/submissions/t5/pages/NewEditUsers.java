package mil.dtic.cbes.submissions.t5.pages;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.CayenneRuntimeException;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.RequestParameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.enums.Roles;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.UserLineItem;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndProgramElementLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUserAndServiceAgencyLink;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgesUserAndProgramElementLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserAndServiceAgencyLinkDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.submissions.uiobjects.DetailedUserListItem.RadioValue;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;

@Import(stack = { CbesT5SharedModule.DATATABLESUPDATED }, library = { "context:/js/urlencoder.js",
        "context:/js/r2dataTableExhibitIcons.js", "context:/js/newEditUsers.js" })
public class NewEditUsers extends T5Base {
    // @formatter:off
	public static final String NAME_SHORTER = " ..";
	public  static final int SHORT_NAME_LIMITER = 40;
	public static final int EDIT_USER_SA_COLS = 4;

	public static final String NO_PRIV = "NONE";
	public static final String VIEW_PRIV = "VIEW";
	public static final String EDIT_PRIV = "VIEWEDIT";
	public  static final String SUCCESS_MSG = "successMessages";
	public static final String LINE_ITEM_PRIVS = "LineItemPrivs";
	public static final String BUDGET_CYCLE = "BudgetCycle";
	public static final String CAMEL_BUDGET_CYCLE = "budgetCycle";
	public static final String AGENCY = "agency";
	public  static final String AGENCIES = "agencies";
	public static final String LINE_ITEM_NUMBER = "LineItemNumber";
	public static final String PROGRAM_ELEMENT_PRIVS = "ProgamElementsPrivs";
	public static final String TEST = "test";
	public static final String LINE_ITEM_ID = "lineItemId";
	public static final String PRIVILEGE = "priv";
	public static final String PRIMARY_KEY_DECONFLICTOR = "_";

	public static final String RECORDS_TOTAL = "recordsTotal";
	public  static final String RECORDS_FILTER = "recordsFilter";
	public static final String DRAW = "draw";
	public static final String EXECUTE_DRAW = "1";
	public static final String AA_DATA = "aaData";
	public static final String ACCESS = "access";
	public static final String OK = " successfully updated";
	public static final String AOK = " successfully";
	public static final String CAN_CREATE_LINEITEM = "canCreateLI";
	public static final String CAN_CREATE_PE = "canCreatePE";
	public static final String CREATE_PE_SUCCESS = " PE creation updated";
	public static final String CREATE_LI_SUCCESS = " LI creation updated";
	public static final String CREATE_PE_FAILURE = " PE creation failure";
	public static final String CREATE_LI_FAILURE = " LI creation failure";
	public static final String PE_ID = "peID";
	public static final String LINEITEM_ID = "lineItemId";
	public static final String TEST_LINE_ITEM_MSG = " not processed (Test LineItem)";
	public static final String PE_TITLE = "PE: ";
	public static final String LI_TITLE = "LI: ";
	public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("EEEE, MMM d, yyyy HH:mm:ss");
	public static final String ZONEID = "America/New_York";

	@Persist
	@Property
	private int colWidth;

    private static final Logger log = CbesLogFactory.getLog(NewEditUsers.class);

	@Inject
	private ComponentResources resources;

	@Inject
	private JavaScriptSupport jsSupport;

	@Inject
	private BudgesUserAndProgramElementLinkDAO budgesUserPELinkDAO;

	@Inject
	private BudgesUserDAO budgesUserDAO;

	@Inject
	private BudgetCycleDAO budgetCycleDAO;

	@Inject
	private ServiceAgencyDAO serviceAgencyDAO;

	@Inject
	private ProgramElementDAO peDAO;

	@Inject
	private BudgesUserAndServiceAgencyLinkDAO bUaSaLinkDAO;

	@Property
	@Persist
	private BudgesUser buser; // the user being edited

	@Property
	private ServiceAgency agency;

	@Property
	@Persist
	private List<ServiceAgency> agencies; // the edited users' agencies

	@Property
	@Persist
	List<List<ServiceAgency>> editUserMasterList; // used in quad format agencies

	@Property
	private List<ServiceAgency> editUserList; // used in quad format agencies

	@Persist
	private Set<ServiceAgency> currentUserAgencies; // the admin's agencies i.e. siteAdmin for Army, Navy, AF

	@Property
	private List<ProgramElement> peList;

	@Property
	private BudgesUserAndProgramElementLink link;

	@Inject
	private BudgesUserAndProgramElementLinkDAO userPeDao;

	@Property
	@Persist
	private List<BudgetCycle> bcList;

	@Property
	private BudgetCycle bcycle;

    @Property
    @Persist
	private BudgetCycle currentbCycle;

	@Property
	@Persist
	private List<BudgetCycle> p40bcList;

	@Property
	@Persist
	private List<LineItem> lineItems;

	@Property
	@Persist
	private boolean isLocalSiteAdmin;

    @Property
    @Persist
	private BudgetCycle p40bcycle;

    @Property
    @Persist
	private BudgetCycle currentp40bCycle;

	@Property
	private Boolean returnPage = false;

	@Property
	@Persist
	P40User p40EditedUser;

	@Property
	@Persist
	P40User p40LocalEditor;

	@Property
	@Persist
	private boolean foundUser;

	@Property
	@Persist
	private boolean peliEnable;

	@Property
	@Persist
	private String createdBy;

	@Property
	@Persist
	private String modifiedBy;

	@Property
	@Persist
	private String creationDate;

	@Property
	@Persist
	private String modificationDate;

	@Property
	@Persist
	private String lastLoginDate;

	@Property
	private String keyLdapId;

	// @formatter:on

    public NewEditUsers(BudgesUserDAO budgesUserDAO) {
        this.budgesUserDAO = budgesUserDAO;
    }

    void onActivate(String previousPage, String ldapId) {
        log.debug("onActivate- ");
        keyLdapId = ldapId;

        log.info(String.format("onActivate: -  previousPage: %s ldapId: %s", previousPage, ldapId));

        if (previousPage.equalsIgnoreCase("adminTools")) {
            log.debug("onActivate-  returnPage is true");
            returnPage = true;
        }

        buser = budgesUserDAO.findByUserLdapId(ldapId);
        foundUser = (buser == null) ? false : true;
        if (foundUser) {
            setupLineItemProcessing(ldapId);

            if (buser.getRole().equals(LdapDAO.GROUP_R2_ANALYST) || buser.getRole()
                    .equals(LdapDAO.GROUP_R2_APP_ADMIN) || buser.getRole().equals(LdapDAO.GROUP_OMB_ANALYST)
                    || isLocalSiteAdmin) {
                peliEnable = false;
            } else {
                peliEnable = true;
            }
            setupUserData(ldapId);
        }

        agencies = serviceAgencyDAO.findAllActiveServiceAgencies();
        bcList = budgetCycleDAO.getBudgetCycles();
        p40bcList = budgetCycleDAO.getBudgetCycles();

        currentbCycle = bcList.get(0);
        currentp40bCycle = p40bcList.get(0);

        currentUserAgencies = getCurrentBudgesUser().getAgencies();
        serviceAgencyUIBuilder(agencies);
        colWidth = NewEditUsers.EDIT_USER_SA_COLS;
    }

    void afterRender() {
        log.debug("afterRender-");
        JSONObject links;
        log.debug("peliEnable - " + peliEnable);
        if (isLocalSiteAdmin) {
            peliEnable = false;
        }

        links = new JSONObject("getUserTablePeUrl", resources.createEventLink("GetUserPeTable").toURI(),
                "getUserTableLiUrl", resources.createEventLink("GetUserLiTable").toURI(), "onSaveUpdatesURL",
                resources.createEventLink("SaveUpdates").toURI());
        jsSupport.addScript("newEditUserPageInit(%s);", links.toCompactString());
    }

    boolean canCreatePE() {
        return buser.isCreatePeAllowed();
    }

    void setupLineItemProcessing(String ldapId) {
        log.debug("setupLineItemProcessing: " + ldapId);
        String p40LocalEditorInput = getCurrentBudgesUser().getUserLdapId();

        if (getCurrentBudgesUser().getRole().equals("R2LocalSiteAdmin")) {
            isLocalSiteAdmin = true;
        }

        DataContext dataContext = CayenneUtils.createDataContext();
        p40EditedUser = P40User.fetchWithLdapId(dataContext, ldapId);
        if (null == p40EditedUser) {
            log.error("failed to initialize p40EditedUser ldapId: " + ldapId);
        }
        p40LocalEditor = P40User.fetchWithLdapId(dataContext, getCurrentBudgesUser().getUserLdapId());
        if (null == p40LocalEditor) {
            log.error("failed to initialize p40LocalEditor ldapId: " + p40LocalEditorInput);
        }

    }

    JSONObject onGetUserPeTable(@RequestParameter(NewEditUsers.CAMEL_BUDGET_CYCLE) String cycleYear) {
        JSONArray peListByBudgetCycleArray = new JSONArray();
        JSONObject responseObject = new JSONObject();
        Set<Integer> ids = bUaSaLinkDAO.findAgencyIdsForUser(buser);

        if (ids == null) {
            ids = new HashSet<Integer>();
        }

        BudgetCycle bc = budgetCycleDAO.findByValue(cycleYear);
        peList = (bc != null ? peDAO.findByBudgetCycle(bc) : new ArrayList<ProgramElement>());

        for (ProgramElement pe : peList) {
            log.debug("onGetUserPeTable: pe: id" + pe.getId() + " sa: " + pe.getServiceAgency().getId() + " peNum: "
                    + pe.getNumber());
            if (getUserCredentials().editPeUsersAllowed(pe) && ids.contains(pe.getServiceAgency().getId())) {
                BudgesUserAndProgramElementLink link = budgesUserPELinkDAO.findByUserAndPeId(buser, pe.getId());
                JSONObject userPePermissions = new JSONObject();
                userPePermissions.put(NewEditUsers.BUDGET_CYCLE, pe.getBudgetCycleAndYear());
                userPePermissions.put(NewEditUsers.AGENCY, pe.getServiceAgency().getName());
                userPePermissions.put("PeNumber", pe.getNumber());
                userPePermissions.put(NewEditUsers.TEST, pe.isTest());
                userPePermissions.put("PeID", pe.getId());
                if (link != null && link.isEdit()) {
                    userPePermissions.put(NewEditUsers.PRIVILEGE, NewEditUsers.EDIT_PRIV);
                } else if (link != null && link.isView()) {
                    userPePermissions.put(NewEditUsers.PRIVILEGE, NewEditUsers.VIEW_PRIV);
                } else if (link != null && !link.isEdit() && !link.isView() || pe.isTest()) {
                    userPePermissions.put(NewEditUsers.PRIVILEGE, NewEditUsers.NO_PRIV);
                } else if (link == null) {
                    userPePermissions.put(NewEditUsers.PRIVILEGE, NewEditUsers.NO_PRIV);
                }
                peListByBudgetCycleArray.put(userPePermissions);
            }
        }
        responseObject.put("recordsTotal", peListByBudgetCycleArray.length());
        responseObject.put("recordsFilter", peListByBudgetCycleArray.length());
        responseObject.put("draw", "1");
        responseObject.put("aaData", peListByBudgetCycleArray);
        return responseObject;
    }

    JSONObject onGetUserLiTable(@RequestParameter(NewEditUsers.CAMEL_BUDGET_CYCLE) String cycleYear) {
        JSONArray liListByBudgetCycleArray = new JSONArray();
        JSONObject responseObject = new JSONObject();
        log.debug("onGetUserLiTable: cycleYear: " + cycleYear);

        if (!foundUser) {
            return responseObject.put("error", "User Not Found");
        }

        BudgetCycle selectedBudgetCycle = budgetCycleDAO.findByValue(cycleYear);

        if (null != p40EditedUser && null != p40LocalEditor) {
            log.debug("onGetUserLiTable: p40EditedUser: " + p40EditedUser.getFullName() + "("
                    + p40EditedUser.getUserLdapId() + ")");
        } else {
            return responseObject.put("error", "Users Not Found");
        }

        String role = getCurrentBudgesUser().getRole();
        log.debug("onGetUserLiTable: p40LocalEditor role: " + role);

        ObjectContext objectContext = p40EditedUser.getObjectContext();

        if (role.equals(LdapDAO.GROUP_R2_APP_ADMIN)) {
            log.trace("onGetUserLiTable: processing role: " + role);
            lineItems = LineItem.fetchActiveByServiceAgencyAndBudgetCycle(objectContext,
                    p40EditedUser.getActiveAgencies(), selectedBudgetCycle);
        } else if (role.equals(LdapDAO.GROUP_R2_SITEADMIN)) {
            log.trace("onGetUserLiTable: processing role " + role);
            List<Integer> lineItemServiceAgencyIdList = new ArrayList<>();
            for (ServiceAgency serviceAgency : getAvailableProcurementAgencies()) {
                lineItemServiceAgencyIdList.add(serviceAgency.getId());
            }

            lineItems = LineItem.fetchActiveByServiceAgencyAndBudgetCycle(objectContext,
                    p40EditedUser.getActiveAgencies(), selectedBudgetCycle);
            log.trace("onGetUserLiTable: processing role SiteManager initial lineItem size: " + lineItems.size());
            Iterator<LineItem> liIterator = lineItems.iterator();
            while (liIterator.hasNext()) {
                LineItem lineItem = liIterator.next();
                if (!lineItemServiceAgencyIdList.contains(lineItem.getServiceAgency().getId())) {
                    liIterator.remove();
                }
            }
            log.debug("onGetUserLiTable: processing role SiteManager final lineItem size: " + lineItems.size());
        } else if (role.equals(LdapDAO.GROUP_R2_LOCALSITEADMIN)) {
            log.debug("onGetUserLiTable: processing role " + role);

            List<LineItem> editableLineItems = p40LocalEditor.getEditableLineItems();
            log.debug("editable line item: " + editableLineItems);
            List<mil.dtic.cbes.p40.vo.ServiceAgency> activeServiceAgencies = p40LocalEditor.getActiveAgencies();

            List<LineItem> targetLineItems = new ArrayList<>();

            for (LineItem lineItem : editableLineItems) {
                mil.dtic.cbes.p40.vo.ServiceAgency serviceAgency = lineItem.getServiceAgency();
                for (mil.dtic.cbes.p40.vo.ServiceAgency activeServiceAgency : activeServiceAgencies) {
                    if (activeServiceAgency.equals(serviceAgency)) {
                        log.debug("onGetUserLiTable: add lineItem: " + lineItem.getId() + " to targetLineItems list");
                        if (selectedBudgetCycle.getLabel().equals(lineItem.getBudgetCycleAndYear())) {
                            targetLineItems.add(lineItem);
                        }
                    }
                    break;
                }
            }
            log.debug("target line items: " + targetLineItems);
            lineItems = targetLineItems;

            log.debug("onGetUserLiTable: processing role LocalSiteManager final lineItem size: " + lineItems.size());
        }

        log.debug("onGetUserLiTable: completed processing line items by user role, lineItems generated: "
                + lineItems.size());

        if (!p40EditedUser.isApplicationManager()) { // don't display test line items if not an appMgr.
            Expression exp = ExpressionFactory.matchExp(LineItem.TEST_PROPERTY, new Boolean(false));
            lineItems = exp.filterObjects(lineItems);
        }

        for (LineItem lineItem : lineItems) {
            String priv = NewEditUsers.NO_PRIV;
            for (UserLineItem uli : lineItem.getUserLineItems()) {
                P40User p40User = uli.getUser();
                if (p40User.getUserLdapId().equals(p40EditedUser.getUserLdapId())) {
                    priv = getUserLineItemPrivilege(lineItem, uli);
                }
            }

            JSONObject userLiPermissions = new JSONObject();
            userLiPermissions.put(NewEditUsers.BUDGET_CYCLE, lineItem.getBudgetCycleAndYear());
            userLiPermissions.put(NewEditUsers.AGENCY, lineItem.getServiceAgency().getName());
            userLiPermissions.put(NewEditUsers.LINE_ITEM_NUMBER, lineItem.getLineItemNumber());
            userLiPermissions.put(NewEditUsers.TEST, lineItem.getTest());
            userLiPermissions.put(NewEditUsers.LINE_ITEM_ID, NewEditUsers.PRIMARY_KEY_DECONFLICTOR + lineItem.getId());
            userLiPermissions.put(NewEditUsers.PRIVILEGE, priv);
            liListByBudgetCycleArray.put(userLiPermissions);
        }

        responseObject.put(NewEditUsers.RECORDS_TOTAL, liListByBudgetCycleArray.length());
        responseObject.put(NewEditUsers.RECORDS_FILTER, liListByBudgetCycleArray.length());
        responseObject.put(NewEditUsers.DRAW, NewEditUsers.EXECUTE_DRAW);
        responseObject.put(NewEditUsers.AA_DATA, liListByBudgetCycleArray);
        log.debug("onGetUserLiTable- " + responseObject);
        return responseObject;
    }

    JSONObject onSaveUpdates(@RequestParameter("json") String keyValues) {
        log.trace("onSaveUpdates: keyValues - " + keyValues);
        JSONArray updateMessage = new JSONArray();
        JSONArray statusArray = new JSONArray();
        JSONObject responseObj = new JSONObject();
        JSONObject valuesToSave = new JSONObject(keyValues);
        log.debug("valuesToSave: " + valuesToSave.toString());

        if (valuesToSave.has(NewEditUsers.AGENCIES)) {
            bUaSaLinkDAO.deleteAll(bUaSaLinkDAO.findByBudgesUserId(buser.getId()));
            String agencyString = valuesToSave.getString(NewEditUsers.AGENCIES);
            List<String> organizations = new ArrayList<>();

            JSONArray organizationArray = new JSONArray(agencyString);
            for (int i = 0; i < organizationArray.length(); i++) {
                organizations.add(organizationArray.getString(i));
            }

            for (String organizationCode : organizations) {
                ServiceAgency organizationToAdd = serviceAgencyDAO.findByCode(organizationCode);
                BudgesUserAndServiceAgencyLink newLinkToAdd = new BudgesUserAndServiceAgencyLink();
                newLinkToAdd.setServiceAgency(organizationToAdd);
                newLinkToAdd.setBudgesUser(buser);
                bUaSaLinkDAO.save(newLinkToAdd);
            }

            responseObj.put("reload", updateMessage);
        }

        if (valuesToSave.has(NewEditUsers.PROGRAM_ELEMENT_PRIVS)) {
            statusArray
                    .put(processProgramElementPrivileges(valuesToSave.getString(NewEditUsers.PROGRAM_ELEMENT_PRIVS)));
        }

        if (valuesToSave.has(NewEditUsers.LINE_ITEM_PRIVS)) {
            statusArray.put(processLineItemPrivileges(valuesToSave.getString(NewEditUsers.LINE_ITEM_PRIVS)));
        }

        if (valuesToSave.has(NewEditUsers.CAN_CREATE_PE)) {
            boolean canCreatePE = valuesToSave.getBoolean(NewEditUsers.CAN_CREATE_PE);
            log.trace("valuesToSave - PE creation: - canCreatePE: " + canCreatePE);

            if (buser.isCreatePeAllowed() != canCreatePE) {
                buser.setCreatePeAllowed(canCreatePE);
                log.trace("valuesToSave - PE creation: - calling saveCreationLink");
                saveCreationLink(statusArray, buser, NewEditUsers.CAN_CREATE_PE);
            } else {
                log.trace("valuesToSave - PE creation: - no processing necessary");
            }
        }

        if (valuesToSave.has(NewEditUsers.CAN_CREATE_LINEITEM)) {
            boolean canCreateLI = valuesToSave.getBoolean(NewEditUsers.CAN_CREATE_LINEITEM);
            log.trace("valuesToSave - LI creation: - canCreateLI: " + canCreateLI);
            if (buser.isCreateLiAllowed() != canCreateLI) {
                buser.setCreateLiAllowed(canCreateLI);
                log.trace("valuesToSave - LI creation: - calling saveCreationLink");
                saveCreationLink(statusArray, buser, NewEditUsers.CAN_CREATE_LINEITEM);
            } else {
                log.trace("valuesToSave - LI creation: - no processing necessary");
            }
        }

        if (statusArray.length() > 0) {
            responseObj.put(NewEditUsers.SUCCESS_MSG, statusArray);
        }

        return responseObj;
    }

    public boolean isUserServiceAgency() {
        return buser.getAgencies().contains(agency);
    }

    public boolean canEditAgency(ServiceAgency serviceAgency) {
        if (currentUserAgencies.contains(serviceAgency)
                || getCurrentBudgesUser().getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN)) {
            return true;
        } else {
            return false;
        }
    }

    private BudgesUserAndProgramElementLink isExistingUser(Integer userID,
            List<BudgesUserAndProgramElementLink> userPes) {
        for (BudgesUserAndProgramElementLink userPELink : userPes) {
            if (userPELink.getUser().getId().compareTo(userID) == 0) {
                return userPELink;
            }
        }
        return null;
    }

    // serviceagency builder
    private List<ServiceAgency> getNewUserList() {
        return new ArrayList<>();
    }

    // serviceagency builder
    private void serviceAgencyUIBuilder(List<ServiceAgency> agencies) {
        editUserMasterList = new ArrayList<>();
        editUserList = null;

        int count = 0;
        for (ServiceAgency agency : agencies) {
            agency.setShortName(getShortName(agency.getName()));
            if (count == 0) {
                editUserList = getNewUserList();
            } else if (count == NewEditUsers.EDIT_USER_SA_COLS) {
                editUserMasterList.add(editUserList);
                editUserList = getNewUserList();
                editUserList.add(agency);
                count = 1;
                continue;
            }
            count++;
            editUserList.add(agency);
            log.trace("adminEditUserBuilder added agency: " + agency.getShortName());
        }
        editUserMasterList.add(editUserList);
    }

    private String getShortName(String name) {
        if (name.length() < NewEditUsers.SHORT_NAME_LIMITER) {
            return name;
        }
        return name.substring(0, NewEditUsers.SHORT_NAME_LIMITER) + NewEditUsers.NAME_SHORTER;
    }

    private void updateUserLineItemPrivilege(String newAccess, UserLineItem userLineItem) {
        if (StringUtils.equals(newAccess, NewEditUsers.EDIT_PRIV)) {
            userLineItem.setEditPrivilege(true);
            userLineItem.setViewPrivilege(false);
        } else if (StringUtils.equals(newAccess, NewEditUsers.VIEW_PRIV)) {
            userLineItem.setEditPrivilege(false);
            userLineItem.setViewPrivilege(true);
        } else if (StringUtils.equals(newAccess, NewEditUsers.NO_PRIV)) {
            userLineItem.setEditPrivilege(false);
            userLineItem.setViewPrivilege(false);
        }
    }

    private String getUserLineItemPrivilege(LineItem lineItem, UserLineItem userLineItem) {
        if (null == userLineItem || lineItem.getTest()) {
            return NewEditUsers.NO_PRIV;
        }

        if (userLineItem.isEditPrivilege()) {
            return NewEditUsers.EDIT_PRIV;
        }

        if (userLineItem.isViewPrivilege()) {
            return NewEditUsers.VIEW_PRIV;
        }

        return NewEditUsers.NO_PRIV;
    }

    private JSONArray processProgramElementPrivileges(String privsString) {
        log.trace(":processProgramElementPrivileges - privsString: " + privsString);
        JSONArray updateMessage = new JSONArray();
        JSONArray privArray = new JSONArray(privsString);
        for (int i = 0; i < privArray.length(); i++) {
            JSONObject jsonObj = privArray.getJSONObject(i);
            int peID = jsonObj.getInt(NewEditUsers.PE_ID);
            List<BudgesUserAndProgramElementLink> userPes = userPeDao.findByPe(peID);
            ProgramElement pe = peDAO.findById(peID);

            if (pe.isTest()) {
                continue;
            }

            RadioValue value = RadioValue.valueOf(jsonObj.getString(NewEditUsers.ACCESS).toUpperCase()); // view / edit
                                                                                                         // / none

            // If the access rights are not none, we need to make sure they have an entry in
            // the link table.
            if (value != RadioValue.NONE) {
                BudgesUserAndProgramElementLink existingLink = isExistingUser(buser.getId(), userPes);
                if (existingLink != null) {
                    // If one found, and it's different than the new setting updated it, otherwise
                    // no change needed.
                    if (value != RadioValue.fromUpe(existingLink)) {
                        value.updateUpe(existingLink); // This is updating fields in existingLink, not in value
                        userPeDao.update(existingLink);
                        updateMessage.put(NewEditUsers.PE_TITLE + pe.getNumber() + NewEditUsers.OK);
                    }
                } else { // If none found add one.
                    BudgesUserAndProgramElementLink newLink = BudgesUserAndProgramElementLink.createTransient(buser,
                            pe);
                    value.updateUpe(newLink);
                    userPeDao.saveOrUpdate(newLink);
                    updateMessage.put(NewEditUsers.PE_TITLE + pe.getNumber() + NewEditUsers.OK);
                }
            } else {// Access rights being set to none, check for existing entry. If existing one
                    // found delete it, otherwise do nothing.
                BudgesUserAndProgramElementLink existingLink = isExistingUser(buser.getId(), userPes);
                if (existingLink != null) {
                    userPeDao.delete(existingLink);
                    updateMessage.put(NewEditUsers.PE_TITLE + pe.getNumber() + NewEditUsers.OK);
                }
            }
        }

        return updateMessage;
    }

    private JSONArray processLineItemPrivileges(String privsString) {
        JSONArray updateMessage = new JSONArray();
        JSONArray privArray = new JSONArray(privsString);

        for (int i = 0; i < privArray.length(); i++) {
            log.trace("processLineItemPrivileges: processing lineItem privilege #" + i);
            Integer lineItemId;
            String sLineItemId;
            JSONObject jsonObj = privArray.getJSONObject(i);

            try {
                sLineItemId = jsonObj.getString(NewEditUsers.LINEITEM_ID).substring(1); // remove the _ here.
                lineItemId = Integer.valueOf(sLineItemId);
            } catch (NumberFormatException nfe) {
                log.error("failed to parse: " + privsString + " ** did not process");
                updateMessage.put(jsonObj.getString(NewEditUsers.LINEITEM_ID) + " failed to process");
                continue;
            }

            String access = jsonObj.getString(NewEditUsers.ACCESS);
            log.trace("onSaveUpdates: LineItemPrivs process lineItemID: " + lineItemId + " access: " + access);

            DataContext dataContext = CayenneUtils.createDataContext();
            CayenneUtils.copyToContext(p40EditedUser, dataContext);
            Collection<Integer> idList = new ArrayList<>();
            idList.add(lineItemId); // only process one lineitem at a time.
            List<LineItem> currentLineItems = LineItem.fetchWithIds(dataContext, idList);

            if (currentLineItems.get(0).getTest()) {
                updateMessage.put(currentLineItems.get(0).getLineItemNumber() + NewEditUsers.TEST_LINE_ITEM_MSG);
                continue;
            }

            boolean ok = false;
            String msg = null;

            if (currentLineItems.size() >= 0) { // it should only be 1.
                List<UserLineItem> uli = currentLineItems.get(0).getUserLineItems();
                boolean foundUser = false;
                for (UserLineItem userLineItem : uli) {
                    if (userLineItem.getUser().getUserLdapId().equals(buser.getUserLdapId())) {
                        updateUserLineItemPrivilege(access, userLineItem);
                        foundUser = true;
                        ok = true;
                        break;
                    }
                }

                if (!foundUser) { // add new userLineItem to the user_line_item table.
                    try {
                        LineItem lineItem = currentLineItems.get(0);
                        CayenneUtils.copyToContext(lineItem, dataContext);
                        UserLineItem newUserLineItem = dataContext.newObject(UserLineItem.class);
                        newUserLineItem.setUser(CayenneUtils.copyToContext(p40EditedUser, dataContext));
                        newUserLineItem.setLineItem(CayenneUtils.copyToContext(lineItem, dataContext));
                        updateUserLineItemPrivilege(access, newUserLineItem);
                        newUserLineItem.setCreatedBy(CayenneUtils.copyToContext(p40LocalEditor, dataContext));
                        newUserLineItem.setModifiedBy(CayenneUtils.copyToContext(p40LocalEditor, dataContext));
                        newUserLineItem.setDateCreated(new Date());
                        newUserLineItem.setDateModified(new Date());
                        ok = true;
                    } catch (Exception e) {
                        log.error("failed to create new lineItem, msg: " + e.getMessage(), e);
                        msg = e.getMessage();
                    }
                }
            }

            if (ok) {
                try {
                    dataContext.commitChanges();
                    updateMessage
                            .put(NewEditUsers.LI_TITLE + currentLineItems.get(0).getLineItemNumber() + NewEditUsers.OK);
                } catch (CayenneRuntimeException cre) {
                    updateMessage.put(NewEditUsers.LI_TITLE + currentLineItems.get(0).getLineItemNumber()
                            + "failed to save changes");
                }
            } else {
                updateMessage.put(NewEditUsers.LI_TITLE + currentLineItems.get(0) + " failed to update - " + msg);
            }
        }
        return updateMessage;
    }

    public boolean isAppManagerUser() {
        return buser.getRole().equalsIgnoreCase(LdapDAO.GROUP_R2_APP_ADMIN);
    }

    private void saveCreationLink(JSONArray statusArray, BudgesUser buser, String creationType) {
        log.debug("saveCreationLink: " + buser.getFullName() + " changing creationType: " + creationType);

        String success = null;
        String failure = null;
        boolean creationValue = false;

        if (creationType.equals(NewEditUsers.CAN_CREATE_LINEITEM)) {
            success = NewEditUsers.CREATE_LI_SUCCESS;
            failure = NewEditUsers.CREATE_LI_FAILURE;
            creationValue = buser.isCreateLiAllowed();
            log.trace("saveCreationLink: LI change - userName: " + buser.getFullName() + " changing to: "
                    + creationValue);

        } else if (creationType.equals(NewEditUsers.CAN_CREATE_PE)) {
            success = NewEditUsers.CREATE_PE_SUCCESS;
            failure = NewEditUsers.CREATE_PE_FAILURE;
            creationValue = buser.isCreatePeAllowed();
            log.trace("saveCreationLink: PE change - userName: " + buser.getFullName() + " changing to: "
                    + creationValue);
        } else {
            log.error(
                    "saveCreationLink: failure to decipher creationType: " + creationType + " - not saving bugesUser");
            statusArray.put(buser.getUserLdapId() + "failure processing creationType: " + creationType);
            return;
        }

        try {
            budgesUserDAO.saveOrUpdate(buser);
            log.debug("saveCreationLink: successfully saved creationType: " + creationType + " for user: "
                    + buser.getFullName() + " creationValue: " + creationValue);
            statusArray.put(buser.getUserLdapId() + success + NewEditUsers.AOK);

        } catch (RuntimeException re) {
            log.error("saveCreationLink: failure to savedupdate creationType: " + creationType + " for user: "
                    + buser.getFullName() + " value: " + creationValue + " masg: " + re.getMessage(), re);
            statusArray.put(buser.getUserLdapId() + failure);
        }
    }

    // CXE-6807
    private void setupUserData(String ldapId) {
        ObjectContext objectContext = CayenneUtils.createDataContext();
        P40User user = P40User.fetchWithLdapId(objectContext, ldapId);
        if (null != user.getCreatedBy()) {
            createdBy = user.getCreatedBy().getUserLdapId();
        }

        if (null != user.getModifiedBy()) {
            modifiedBy = user.getModifiedBy().getUserLdapId();
        }

        lastLoginDate = setDate(user.getLastVisitDate());
        creationDate = setDate(user.getDateCreated());
        modificationDate = setDate(user.getDateModified());

    }

    private String setDate(Date d) { // CXE-6807

        if (null == d) {
            return null;
        } else {
            Instant instant = d.toInstant();
            LocalDateTime ldt = instant.atZone(ZoneId.of(ZONEID)).toLocalDateTime();
            return ldt.format(DATE_FORMATTER);
        }
    }

    public String getReadableUserRole() {
        if (buser.getRole().equals(LdapDAO.GROUP_NONE)) {
            return LdapDAO.GROUP_NONE;
        }
        else {
            return Roles.valueOf(buser.getRole()).getName();
        }
    }

}
