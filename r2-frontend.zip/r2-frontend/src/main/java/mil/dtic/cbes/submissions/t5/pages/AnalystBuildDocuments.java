package mil.dtic.cbes.submissions.t5.pages;

import java.io.File;
import java.io.IOException;

import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.t5.base.T5Base;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

@Import(
		  stack   = { CbesT5SharedModule.DATATABLESUPDATED, CbesT5SharedModule.DROPZONESTACK },
		  library = { "context:/js/newR2XmlTools.js",
		               "context:/js/xmlImport.js",
		               "context:/js/urlencoder.js",
		               "context:/js/largeCheckbox.js", })
public class AnalystBuildDocuments extends T5Base {
	
	  @Property
	  @Persist
	  private File workingDirectory;

	  private static final Logger log = CbesLogFactory.getLog(AnalystBuildDocuments.class);


	  public void onActivate() {
	    if (workingDirectory ==null){
	      try {
	        workingDirectory = createWorkingFolder();
	      } catch (IOException e) {
	        log.error("Couldn't create working folder.", e);
	      }
	    }
	  }

}
