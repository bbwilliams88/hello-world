package mil.dtic.cbes.submissions.t5.pages;

import org.apache.tapestry5.annotations.Import;

import mil.dtic.cbes.p40.vo.Config;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.t5.base.PeListBase;
import mil.dtic.utility.CayenneUtils;

@Import( library = { "js/newuserguide.js" })
public class NewUserGuide extends PeListBase
{
    public String getHelpContent()
    {
        Config configurationObject = Config.fetchByName(CayenneUtils.createDataContext(), ConfigService.R2_HELP);

        if (configurationObject != null)
            return configurationObject.getValue();
        else
            return "# Ooops!\nHelp is missing...";
    }
}
