(function() {
    var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  
    if (!window.R2) {
      window.R2 = {};
    }
  
    R2.ButtonAnimations = (function() {
  
      function ButtonAnimations(element) {
        this.buttonupcss = __bind(this.buttonupcss, this);
  
        this.buttondowncss = __bind(this.buttondowncss, this);
  
        var _this = this;
        element = jQuery(element);
        this.div = element.children().first();
        jQuery(document).bind("mouseup", function(e) {
          return _this.ismousedown = false;
        });
        element.bind("mouseup", function(e) {
          return _this.ismousedown = false;
        });
        element.bind("mouseover", function(e) {
          if (_this.ismousedown) {
            return _this.buttondowncss();
          }
        });
        element.bind("mousedown", function(e) {
          _this.ismousedown = true;
          return _this.buttondowncss();
        });
        element.bind("mouseup", function(e) {
          _this.ismousedown = false;
          return _this.buttonupcss();
        });
        element.bind("mouseout", this.buttonupcss);
      }
  
      ButtonAnimations.prototype.buttondowncss = function() {
        this.div.removeClass("buttonUpLinkDiv");
        return this.div.addClass("buttonDownLinkDiv");
      };
  
      ButtonAnimations.prototype.buttonupcss = function() {
        this.div.removeClass("buttonDownLinkDiv");
        return this.div.addClass("buttonUpLinkDiv");
      };
  
      return ButtonAnimations;
  
    })();
  
  }).call(this);