$.ajaxSetup({
	cache : false
});

/*
 * Not sure if this is even necessary, but I could no longer set the ng-app and ng-controller attributes in the tml
 * because the new Tapestry dependency manager, require.js, is difficult to work with.
 */
$("html").attr("ng-app", "angularCBES")
$("html").attr("ng-controller","cbesCtrl as ctrl")

const CONTINUING = 'Continuing';

function peFundingCorrectionNeeded(pe, year) {
	if (undefined == pe || null === pe) {
		return 'N/A';
	}

	var totalFromProjects = 0.0;
	for (var i = 0; i < pe.ProjectList.Project.length; i++) {
		var funding = pe.ProjectList.Project[i].ProjectFunding[year];
		if (!isNaN(parseFloat(funding))) {
			totalFromProjects += parseFloat(funding);
		}
	}
	if (year === 'AllPriorYears') {
		if (!isNaN(parseFloat(pe.PriorYearsDelta))) {
			totalFromProjects += parseFloat(pe.PriorYearsDelta);
		}
	}
	var peTotal = parseFloat(pe.ProgramElementFunding[year]);
	if (isNaN(peTotal)) {
		if (pe.ProgramElementFunding[year] === '') {
			return (0.0 - totalFromProjects).toFixed(3);
		} else {
			return 'N/A';
		}
	} else {
		return (peTotal - totalFromProjects).toFixed(3);
	}
}

function peFundingCorrectionClass(pe, year) {
	var amount = peFundingCorrectionNeeded(pe, year);
	return correctionClass(amount);
}

function updateSaveModal(data) {
	var hasBusinessRuleWarnings = "warningMessages" in data
			&& data.warningMessages.length > 0;

	if (!hasBusinessRuleWarnings) {
		$('#r2modalFeedbackBody').html('<div class="alert alert-success"><p>Everything is valid.</p></div>');
	} else {
		$('#r2modalFeedbackBody').html('<div class="alert alert-warning"><p>Program element advisory - warnings found.</p></div>');
	}

	if (hasBusinessRuleWarnings) {
		var fancyWarnings = {};
		for (var i = 0; i < data.warningMessages.length; i++) {
			var splitWarnings = data.warningMessages[i].message.split('|');
			var warnObj = {
				'place' : splitWarnings[1],
				'msg' : splitWarnings[2]
			};
			if (fancyWarnings[splitWarnings[0]]) {
				fancyWarnings[splitWarnings[0]].push(warnObj);
			} else {
				fancyWarnings[splitWarnings[0]] = [ warnObj ];
			}
		}
		$.each(sortedOnKeys(fancyWarnings), function(key, value) {
			var warningsListGroup = $('<div class="list-group"></div>');
			var li = $('<a href="#" class="list-group-item active"></a>');
			var aHtml = '<span class="badge">' + value.length + '</span>';
			aHtml += key.substring(1, key.length - 1);
			li.append(aHtml);
			var wListDiv = $('<div class="modalWarningTexts"></div>');
			var wText;
			for (var j = 0; j < value.length; j++) {
				wText = '<div class="list-group-item">' + value[j].msg;
				wText += ' ' + value[j].place + '</div>';
				wListDiv.append(wText);
			}
			li.click(function() {
				wListDiv.slideToggle();
			});
			wListDiv.hide();
			warningsListGroup.append(li);
			warningsListGroup.append(wListDiv);
			$('#r2modalFeedbackBody').append(warningsListGroup);
		});
		if (data.warningMessages.length > 0) {
			$('#ruleViolationsCsvLink').show();
		} else {
			$('#ruleViolationsCsvLink').hide();
		}
	}
	var modalBodyMaxHeight = $(window).height() - 190 + 'px';
	$('#r2modalFeedbackBody').css('max-height', modalBodyMaxHeight);
	$('#r2modalFeedbackBody').css('overflow-y', 'auto');
	$('#r2modalFeedback').modal();
}

function toggleSpecialProject(project) {
	if (project.SpecialProject === true) {
		var shortConfirm = 'This will remove all data for this project except for ';
		shortConfirm += 'Mission Description and Budget Item Justification. ';
		shortConfirm += 'Please consult with the appropriate OUSD Analyst for ';
		shortConfirm += 'clarification of R-2A Short status and guidance ';
		shortConfirm += 'concerning acceptable narrative content. ';
		shortConfirm += 'This operation cannot be undone. ';
		shortConfirm += 'Are you sure?';
		if (confirm(shortConfirm)) {
			project.SpecialProject = '1';
			project.R2aExhibit.AcquisitionStrategy = '';
			project.R2aExhibit.OtherProgramFundingSummaryRemarks = '';
			project.R2aExhibit.ProjectNote = '';
			project.R2aExhibit.AccomplishmentPlannedProgramList.AccomplishmentPlannedProgram = [];
			project.R2aExhibit.CongressionalAddDetailList.CongressionalAddDetail = [];
			project.R2aExhibit.JointFundingList.JointFunding = [];
			project.R2aExhibit.OtherProgramFundingSummaryList.OtherProgramFundingSummary = [];
			project.R2aExhibit.MajorPerformers.MajorPerformerList.MajorPerformer = [];
			$.each(CXE_CONSTANTS.FISCAL_YEARS_OOC, function(key, value) {
				project.R2aExhibit.ProjectArticles[value] = '';
			});
			delete project.R3Exhibit;
			delete project.R4Exhibit;
			delete project.R4aExhibit;
			delete project.R5Exhibit;
		} else {
			project.SpecialProject = '0';
		}
	} else {
		project.SpecialProject = '0';
	}
}

function r2aAccPpTotal(project, year) {
	var total = 0.0;
	var accPps = project.R2aExhibit.AccomplishmentPlannedProgramList.AccomplishmentPlannedProgram;
	for (var i = 0; i < accPps.length; i++) {
		var funding = 0.0;
		if (year === 'PriorYear') {
			funding = parseFloat(accPps[i].Accomplishment[year].Funding);
		} else {
			funding = parseFloat(accPps[i].PlannedProgram[year].Funding);
		}
		if (!isNaN(funding)) {
			total += funding;
		}
	}
	return total.toFixed(3);
}

function r2aCongAddTotal(project, year) {
	var total = 0.0;
	var congAdds = project.R2aExhibit.CongressionalAddDetailList.CongressionalAddDetail;
	for (var i = 0; i < congAdds.length; i++) {
		if (congAdds[i][year]) {
			var funding = parseFloat(congAdds[i][year].Funding);
			if (!isNaN(funding)) {
				total += funding;
			}
		}
	}
	return total.toFixed(3);
}

function r2aJointFundingTotal(project, year) {
	var total = 0.0;
	var jointFunds = project.R2aExhibit.JointFundingList.JointFunding;
	for (var i = 0; i < jointFunds.length; i++) {
		var funding = parseFloat(jointFunds[i].Funding[year]);
		if (!isNaN(funding)) {
			total += funding;
		}
	}
	return total.toFixed(3);
}

function formattedDifference(num1, num2) {
	var float1 = isNaN(parseFloat(num1)) ? 0.0 : parseFloat(num1);
	var float2 = isNaN(parseFloat(num2)) ? 0.0 : parseFloat(num2);
	var diff = float1 - float2;
	
	return diff.toFixed(3);
}

function formattedSum(nums) {
	var sum = 0.0;
	for (var i = 0; i < nums.length; i++) {
		var floatVal = isNaN(parseFloat(nums[i])) ? 0.0 : parseFloat(nums[i]);
		sum += floatVal;
	}
	
	return sum.toFixed(3);
}

function correctionClass(amount) {
	if (amount === '0.000' || amount === '-0.000') {
		return 'r2FundingCorrectionGood';
	} else if (amount === 'N/A') {
		return 'r2FundingCorrectionNA';
	} else {
		return 'r2FundingCorrectionError';
	}
}

function r2AdjustmentCorrectionNeeded(changeSummary, year) {
	if (undefined == changeSummary || null === changeSummary) {
		return null;
	}
	var adjustments = [];
	if (year === 'PriorYear' || year === 'CurrentYear') {
		for ( var adj in CXE_CONSTANTS.ADJUSTMENTS) {
			adjustments.push(changeSummary.AdjustmentDetails[adj][year]);
		}
	}
	var otherList = changeSummary.AdjustmentDetails.OtherAdjustmentDetailList.OtherAdjustmentDetail;
	for (var i = 0; i < otherList.length; i++) {
		adjustments.push(otherList[i].Funding[year]);
	}
	var sum = formattedSum(adjustments);
	return formattedDifference(changeSummary.TotalAdjustments[year], sum);
}

function r2AdjustmentCorrectionClass(changeSummary, year) {
	var amount = r2AdjustmentCorrectionNeeded(changeSummary, year);
	return correctionClass(amount);
}

function r2aServiceTotal(project, year) {
	return formattedDifference(r2aAccPpTotal(project, year),
			r2aJointFundingTotal(project, year));
}

function r2aCorrectionNeeded(project, year) {
	var sum = formattedSum([ r2aCongAddTotal(project, year),
			r2aAccPpTotal(project, year) ]);
	sum = formattedDifference(sum, r2aJointFundingTotal(project, year));
	return formattedDifference(project.ProjectFunding[year], sum);
}

function r2aCorrectionClass(project, year) {
	var amount = r2aCorrectionNeeded(project, year);
	return correctionClass(amount);
}

function r3Total(project, year) {
	var total = 0.0;
	var ccgs = project.R3Exhibit.CostCategoryGroupList.CostCategoryGroup;
	
	for (var i = 0; i < ccgs.length; i++) {
		var ccgTotal = r3ccgTotal(ccgs[i], year);
		
		if (!isNaN(parseFloat(ccgTotal))) {
			total += parseFloat(ccgTotal);
		}
		
		else if (isContinuingText(ccgTotal)){
			return CONTINUING;
		}
	}
	
	return total.toFixed(3);
}

function r3TotalMinusJf(project, year) {
	
	if (isContinuingText(r3Total(project, year))) {
		return CONTINUING;
	}

	if (year === 'TotalPreviousYears') {
		return formattedDifference(r3Total(project, year),
				r2aJointFundingTotal(project, 'AllPriorYears'));
	} else {
		return formattedDifference(r3Total(project, year),
				r2aJointFundingTotal(project, year));
	}
}

function r3CorrectionNeeded(project, year) {
	var sum = '0.000';
	
	if (year === 'TotalPreviousYears' ) {
		sum = r3TotalMinusJf(project, year);
		return formattedDifference(project.ProjectFunding.AllPriorYears, sum);
	} 
	
	else if (year === 'TargetValue') {
		return 'N/A';
	}
	
	else if(year === 'CostToComplete' || year === 'TotalCost'){
		if (isContinuingText(r3Total(project, year))) {
			return CONTINUING;
		}
		
		else{
			sum = r3TotalMinusJf(project, year);
			return formattedDifference(project.ProjectFunding[year], sum);
		}
	}
	
	else {
		sum = r3TotalMinusJf(project, year);
		return formattedDifference(project.ProjectFunding[year], sum);
	}
}

function r3CorrectionClass(project, year) {
	var amount = r3CorrectionNeeded(project, year);
	return correctionClass(amount);
}

function r3ccgTotal(ccg, year) {
	var total = 0.0;
	
	for (var i = 0; i < ccg.CostCategoryItemList.CostCategoryItem.length; i++) {
		var yearHasAmount = false;
		
		for ( var y in CXE_CONSTANTS.PY_CY_BY1OOC) {
			if (year === CXE_CONSTANTS.PY_CY_BY1OOC[y]) {
				yearHasAmount = true;
			}
		}
		
		var cost = '';
		
		if (yearHasAmount) {
			cost = ccg.CostCategoryItemList.CostCategoryItem[i].Cost[year].Amount;
		} 
		
		else {
			cost = ccg.CostCategoryItemList.CostCategoryItem[i].Cost[year];
		}
		
		if (!isNaN(parseFloat(cost))) {
			total += parseFloat(cost);
		}
		
		else if (isContinuingText(cost)){
			return CONTINUING;
		}

	}
	
	return total.toFixed(3);
}

var isContinuingText = function(value){
	return CONTINUING.toLowerCase() === value.toLowerCase();
}

function initR3ModalSelects(isFundingVehicle) {
	if (isFundingVehicle) {
		$('#r3GovtPerformingActivityCheckbox').prop('checked', true);
		$('#r3ModalContractMethodSelect').val('');
		$('#r3ModalContractTypeSelect').val('');
		$('#r3ModalContractMethodSelectParent').hide();
		$('#r3ModalContractTypeSelectParent').hide();
		$('#r3ModalFundingVehicleSelectParent').show();
	} else {
		$('#r3GovtPerformingActivityCheckbox').prop('checked', false);
		$('#r3ModalFundingVehicleSelect').val('');
		$('#r3ModalContractMethodSelectParent').show();
		$('#r3ModalContractTypeSelectParent').show();
		$('#r3ModalFundingVehicleSelectParent').hide();
	}
}

function r4AutogeneratedQuarters() {
	var q = [];
	for (var a = 0; a < 7; a++) {
		for (var b = 1; b < 5; b++) {
			q.push(b);
		}
	}
	return q;
}

function r4aYears(budgetYear) {
	var pbMinusNine = parseInt(budgetYear) - 9;
	var years = [];
	for (var i = 0; i < 14; i++) {
		years.push((pbMinusNine + i).toString());
	}
	return years;
}

function ganttClass(schedule, pbYear) {
	var pbMinusTwo = parseInt(pbYear) - 2;
	var startQuarter = parseInt(schedule.Start.Quarter);
	var startYear = parseInt(schedule.Start.Year);
	var endQuarter = parseInt(schedule.End.Quarter);
	var endYear = parseInt(schedule.End.Year);
	var startInt = ((startYear - pbMinusTwo) * 4) + startQuarter - 1;
	if (startInt < 0) {
		startInt = 0;
		startYear = pbMinusTwo;
		startQuarter = 1;
	}
	var lengthInt = ((endYear - startYear) * 4) + endQuarter - startQuarter + 1;
	var ganttClassName = 'r4gantt-' + startInt + '-' + lengthInt;
	return ganttClassName;
}

function buildUserRightsTable(incomingJson) {
	$('#r2UserRightsTable')
			.DataTable(
					{
						'data' : incomingJson.userRightsList,
						'paging' : true,
						'searching' : true,
						'lengthChange' : false,
						'compact' : true,
						'columns' : [
								{
									'title' : 'LDAP',
									'width' : '25%',
									'data' : 'ldap',
									'bSearchable' : true,
									'bSortable' : true
								},
								{
									'title' : 'User Name',
									'width' : '30%',
									'data' : 'userName',
									'bSearchable' : true,
									'bSortable' : true
								},
								{
									'title' : 'User Role',
									'width' : '15%',
									'data' : 'role',
									'bSearchable' : true,
									'bSortable' : false
								},
								{
									'title' : 'View / Edit',
									'width' : '10%',
									'data' : null,
									'bSearchable' : false,
									'bSortable' : false,
									'render' : function(data, type, full, meta) {
										var radio = '<input type="radio" class="userRightsModalRadioCell"';
										radio += ' name="' + meta.row;
										radio += '" value="VIEWEDIT" label="View/Edit"';
										if (data.access === 'VIEWEDIT') {
											radio += ' checked="checked"';
										}
										radio += '/>';
										return radio;
									},
									'defaultContent' : ''
								},
								{
									'title' : 'View',
									'width' : '10%',
									'data' : null,
									'bSearchable' : false,
									'bSortable' : false,
									'render' : function(data, type, full, meta) {
										var radio = '<input type="radio" class="userRightsModalRadioCell"';
										radio += ' name="' + meta.row + '" value="VIEW" label="View"';
										if (data.access === 'VIEW') {
											radio += ' checked="checked"';
										}
										radio += '/>';
										return radio;
									},
									'defaultContent' : ''
								},
								{
									'title' : 'None',
									'width' : '10%',
									'data' : null,
									'bSearchable' : false,
									'bSortable' : false,
									'render' : function(data, type, full, meta) {
										var radio = '<input type="radio" class="userRightsModalRadioCell"';
										radio += ' name="' + meta.row
												+ '" value="NONE" label="None"';
										if (data.access === 'NONE') {
											radio += ' checked="checked"';
										}
										radio += '/>';
										return radio;
									},
									'defaultContent' : ''
								} ],
						'destroy' : true,
						'drawCallback' : function() {
							var radioButtons = $('.userRightsModalRadioCell');
							radioButtons.unbind('click');
							radioButtons.click(function() {
										// Get the radio buttons corresponding
										// element in the original JSON array
										var selectedElementIndex = $(this).attr('name');
										// Update rights.
										incomingJson.userRightsList[selectedElementIndex].access = $(this).val();
									});
						}
					});
}

function blankOtherAdjustmentDetail() {
	return {
		'Funding' : {
			'PriorYear' : '',
			'CurrentYear' : '',
			'BudgetYearOneBase' : '',
			'BudgetYearOneOOC' : '',
			'BudgetYearOne' : ''
		},
		'Title' : ''
	};
}

function blankProject(budgetYear, includeR3R4a) {
	var p = {
		'ProjectNumber' : '0',
		'ProjectTitle' : '',
		'SpecialProject' : '0',
		'MdapCode' : '',
		'PriorYearsDelta' : '',
		'ProjectFunding' : {
			'AllPriorYears' : '',
			'PriorYear' : '0.000',
			'CurrentYear' : '0.000',
			'BudgetYearOneBase' : '0.000',
			'BudgetYearOneOOC' : '',
			'BudgetYearOne' : '0.000',
			'BudgetYearTwo' : '0.000',
			'BudgetYearThree' : '0.000',
			'BudgetYearFour' : '0.000',
			'BudgetYearFive' : '0.000',
			'CostToComplete' : 'Continuing',
			'TotalCost' : 'Continuing'
		},
		'R2aExhibit' : blankR2aExhibit()
	};
	if (includeR3R4a) {
		p.R3Exhibit = blankR3Exhibit();
		p.R4aExhibit = blankR4aExhibit(budgetYear);
	}
	return p;
}

function blankR2aExhibit() {
	return {
		'CongressionalAddDetailList' : {
			'CongressionalAddDetail' : [ blankR2aCongressionalAddDetail() ]
		},
		'ProjectMissionDescription' : '',
		'OtherProgramFundingSummaryList' : {
			'OtherProgramFundingSummary' : []
		},
		'JointFundingList' : {
			'JointFunding' : []
		},
		'MajorPerformers': {
		  'Text' : '',
		  'MajorPerformerList' : {
		    'MajorPerformer' : []
		  }
		},
		'AccomplishmentPlannedProgramList' : {
			'AccomplishmentPlannedProgram' : [ blankR2aAccomplishmentPlannedProgram() ]
		},
		'ProjectArticles' : {
			'BudgetYearFour' : '',
			'BudgetYearThree' : '',
			'BudgetYearFive' : '',
			'BudgetYearOneBase' : '',
			'AllPriorYears' : '',
			'BudgetYearTwo' : '',
			'CurrentYear' : '',
			'PriorYear' : '',
			'BudgetYearOne' : '',
			'BudgetYearOneOOC' : ''
		}
	};
}

function blankR2aCongressionalAddDetail() {
	return {
		'CurrentYear' : {
			'Text' : '',
			'Funding' : ''
		},
		'PriorYear' : {
			'Text' : '',
			'Funding' : ''
		},
		'Title' : ''
	};
}

function blankR2aAccomplishmentPlannedProgram() {
	return {
		'Title' : '',
		'Accomplishment' : {
			'PriorYear' : {
				'Text' : '',
				'Funding' : '0.000',
				'Articles' : ''
			}
		},
		'PlannedProgram' : {
			'BudgetYearOneBase' : {
				'Text' : '',
				'Funding' : '',
				'Articles' : ''
			},
			'BudgetYearOneOOC' : {
				'Text' : '',
				'Funding' : '',
				'Articles' : ''
			},
			'CurrentYear' : {
				'Text' : '',
				'Funding' : '',
				'Articles' : ''
			},
			'BudgetYearOne' : {
				'Text' : '',
				'Funding' : '',
				'Articles' : ''
			},
			'ChangeSummary' : {
			    'Text' : ''
			}
		}
	};
}

function blankR2aJointFunding() {
	return {
		'Title' : '',
		'Funding' : {
			'AllPriorYears' : '',
			'PriorYear' : '0.000',
			'CurrentYear' : '0.000',
			'BudgetYearOneBase' : '0.000',
			'BudgetYearOneOOC' : '0.000',
			'BudgetYearOne' : '0.000',
			'CostToComplete' : '',
			'TotalCost' : '',
			'TargetValue' : ''
		}
	};
}

function blankR2aOtherProgramFunding() {
	return {
		'LineItem' : '',
		'Title' : '',
		'Funding' : {
			'PriorYear' : '0.000',
			'CurrentYear' : '0.000',
			'BudgetYearOneBase' : '0.000',
			'BudgetYearOneOOC' : '0.000',
			'BudgetYearOne' : '0.000',
			'BudgetYearTwo' : '0.000',
			'BudgetYearThree' : '0.000',
			'BudgetYearFour' : '0.000',
			'BudgetYearFive' : '0.000',
			'CostToComplete' : 'Continuing',
			'TotalCost' : 'Continuing'
		}
	};
}

function blankR3Exhibit() {
	return {
		'CostCategoryGroupList' : {
			'CostCategoryGroup' : []
		},
		'Remarks' : ''
	};
}

function blankR3CCItem() {
	return {
		'Cost' : {
			'TotalPreviousYears' : '',
			'PriorYear' : {
				'Amount' : '',
				'AwardDate' : ''
			},
			'CurrentYear' : {
				'Amount' : '',
				'AwardDate' : ''
			},
			'BudgetYearOneBase' : {
				'Amount' : '',
				'AwardDate' : ''
			},
			'BudgetYearOneOOC' : {
				'Amount' : '',
				'AwardDate' : ''
			},
			'BudgetYearOne' : {
				'Amount' : ''
			},
			'CostToComplete' : 'Continuing',
			'TotalCost' : 'Continuing',
			'TargetValue' : ''
		},
		'Name' : '',
		'ContractType' : '',
		'PerformingActivity' : '',
		'FundingVehicle' : '',
		'PerformingActivityLocation' : '',
		'ContractMethod' : ''
	};
}

function blankR4Exhibit() {
	return {
		'ScheduleProfile' : [],
		'ScheduleProfileNote' : ''
	};
}

function blankR4aExhibit(budgetYear) {
	return {
		'SubProjectScheduleList' : {
			'SubProjectSchedule' : [ blankR4aSubProject(budgetYear) ]
		}
	};
}

function blankR4aSubProject(budgetYear) {
	return {
		'Title' : '',
		'ScheduleDetailList' : {
			'ScheduleDetail' : [ blankR4aScheduleDetail(budgetYear) ]
		}
	};
}

function blankR4aScheduleDetail(budgetYear) {
	return {
		'EventTitle' : '',
		'Schedule' : {
			'Start' : {
				'Year' : stringPlusNum(budgetYear, -1),
				'Quarter' : '4'
			},
			'End' : {
				'Year' : stringPlusNum(budgetYear, 1),
				'Quarter' : '3'
			}
		}
	};
}

function stringPlusNum(intAsStr, intVal) {
	var total = parseInt(intAsStr) + intVal;
	return total.toString();
}

var CXE_CONSTANTS = {
	'PY_CY' : {
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear'
	},

	'PY_CY_BY1OOC' : {
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC',
		'By1' : 'BudgetYearOne'
	},

	'IN_YEARS' : {
		'AllPys' : 'AllPriorYears',
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1' : 'BudgetYearOne',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC'
	},

	'FISCAL_YEARS' : {
		'AllPys' : 'AllPriorYears',
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1' : 'BudgetYearOne',
		'By2' : 'BudgetYearTwo',
		'By3' : 'BudgetYearThree',
		'By4' : 'BudgetYearFour',
		'By5' : 'BudgetYearFive'
	},

	'FISCAL_YEARS_OOC' : {
		'AllPys' : 'AllPriorYears',
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC',
		'By1' : 'BudgetYearOne',
		'By2' : 'BudgetYearTwo',
		'By3' : 'BudgetYearThree',
		'By4' : 'BudgetYearFour',
		'By5' : 'BudgetYearFive'
	},

	'COMP_TOTAL' : {
		'CompCost' : 'CostToComplete',
		'TotalCost' : 'TotalCost'
	},

	'ALL_YEARS' : {
		'AllPys' : 'AllPriorYears',
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC',
		'By1' : 'BudgetYearOne',
		'By2' : 'BudgetYearTwo',
		'By3' : 'BudgetYearThree',
		'By4' : 'BudgetYearFour',
		'By5' : 'BudgetYearFive',
		'CompCost' : 'CostToComplete',
		'TotalCost' : 'TotalCost'
	},

	'ALL_YEARS_NO_PYS' : {
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC',
		'By1' : 'BudgetYearOne',
		'By2' : 'BudgetYearTwo',
		'By3' : 'BudgetYearThree',
		'By4' : 'BudgetYearFour',
		'By5' : 'BudgetYearFive'
	},

	'ACC_PP_YEARS' : {
		'PriorYear' : 'Accomplishment',
		'CurrentYear' : 'PlannedProgram',
		'BudgetYearOneBase' : 'PlannedProgram',
		'BudgetYearOneOOC' : 'PlannedProgram',
		'BudgetYearOne' : 'PlannedProgram'
	},

	'R3_IN_YEARS' : {
		'TotalPys' : 'TotalPreviousYears',
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC',
		'By1' : 'BudgetYearOne',
		'CompCost' : 'CostToComplete',
		'TotalCost' : 'TotalCost',
		'TargetValue' : 'TargetValue'
	},

	'R3_AWARD_YEARS' : {
		'Py' : 'PriorYear',
		'Cy' : 'CurrentYear',
		'By1Base' : 'BudgetYearOneBase',
		'By1Ooc' : 'BudgetYearOneOOC'
	},

	'R3_COST_GROUP_NAMES' : [ 'Product Development', 'Support',
			'Test and Evaluation', 'Management Services' ],

	'PRESIDENTS_BUDGETS' : {
		'PreviousPresidentBudget' : 'Previous President\'s Budget',
		'CurrentPresidentBudget' : 'Current President\'s Budget'
	},

	'ADJUSTMENTS' : {
		'CongressionalGeneralReductions' : {
			'name' : 'Congressional General Reductions',
			'allowsPositive' : false,
			'allowsNegative' : true
		},
		'CongressionalDirectedReductions' : {
			'name' : 'Directed Reductions',
			'allowsPositive' : false,
			'allowsNegative' : true
		},
		'CongressionalRescissions' : {
			'name' : 'Congressional Rescissions',
			'allowsPositive' : false,
			'allowsNegative' : true
		},
		'CongressionalAdds' : {
			'name' : 'Congressional Adds',
			'allowsPositive' : true,
			'allowsNegative' : false
		},
		'CongressionalDirectedTransfers' : {
			'name' : 'Congressional Directed Transfers',
			'allowsPositive' : true,
			'allowsNegative' : true
		},
		'Reprogrammings' : {
			'name' : 'Reprogrammings',
			'allowsPositive' : true,
			'allowsNegative' : true
		},
		'SBIRSTTRTransfer' : {
			'name' : 'SBIR/STTR Transfer',
			'allowsPositive' : true,
			'allowsNegative' : true
		}
	}
};

var peData;
var currentUserID;
function setPeData(dataFromServer, userID) {
	peData = dataFromServer;
	currentUserID = userID;
}

function validMmYyyy(inputStr) {
	var regexText = /^[0-1][0-9]-[0-9]{4}$/.test(inputStr);
	if (regexText) {
		var monthInt = parseInt(inputStr.substring(0, 2));
		if (monthInt < 1 || monthInt > 12) {
			return false;
		}
		var yearInt = parseInt(inputStr.substring(3, 7));
		if (yearInt < 2000 || yearInt > 2099) {
			return false;
		}
		return true;
	} else {
		return false;
	}
}

function validPartialMmYyyy(inputStr) {
	var regexText = /^[0-1]?[0-9]?-?[0-9]{0,4}$/.test(inputStr);
	if (regexText) {
		var dashPos = inputStr.indexOf('-');
		if (dashPos != -1 && dashPos != 2) {
			return false;
		}
		if (dashPos == -1 && inputStr.length > 2) {
			return false;
		}
		var monthInt = parseInt(inputStr.substring(0, 2));
		if (inputStr.length == 1 && (monthInt < 0 || monthInt > 1)) {
			return false;
		}
		if (inputStr.length >= 2 && (monthInt < 1 || monthInt > 12)) {
			return false;
		}
		var yearSubString = inputStr.substring(3, 7);
		var yearInt = parseInt(yearSubString);
		if (yearSubString.length == 1 && yearInt != 2) {
			return false;
		}
		if (yearSubString.length == 2 && yearInt != 20) {
			return false;
		}
		if (yearSubString.length == 3 && (yearInt < 200 || yearInt > 209)) {
			return false;
		}
		if (yearSubString.length == 4 && (yearInt < 2000 || yearInt > 2099)) {
			return false;
		}
		return true;
	} else {
		return false;
	}
}

function validYyyyMm(inputStr) {
	var regexText = /^[0-9]{4}-[0-1][0-9]$/.test(inputStr);
	if (regexText) {
		var monthInt = parseInt(inputStr.substring(5, 7));
		if (monthInt < 1 || monthInt > 12) {
			return false;
		}
		var yearInt = parseInt(inputStr.substring(0, 4));
		if (yearInt < 2000 || yearInt > 2099) {
			return false;
		}
		return true;
	} else {
		return false;
	}
}

function sortedOnKeys(unordered) {
	var ordered = {};
	Object.keys(unordered).sort().forEach(function(key) {
		ordered[key] = unordered[key];
	});
	return ordered;
}

// Shim to give Internet Explorer a .startsWith method
if (!String.prototype.startsWith) {
	String.prototype.startsWith = function(searchString, position) {
		position = position || 0;
		return this.indexOf(searchString, position) === position;
	};
}

function specialCharactersValidator(modelValue, viewValue, msg, canBeEmpty,
		allowSpecialChars, elm, ctrl) {

	if (ctrl.$isEmpty(modelValue)) {
		if (canBeEmpty) {
			$(elm).popover('destroy');
			return true;
		} else {
			jqPopover(elm, 'This field cannot be empty.');
			return false;
		}
	}
	var value = modelValue || viewValue;
	if (!allowSpecialChars) {
		if (!/^[a-zA-Z0-9-]*$/.test(value)) {
			jqPopover(elm, msg);
			return false;
		} else {
			$(elm).popover('destroy');
			return true;
		}
	}
	jqPopover(elm, msg);
	return false;
}

function dollarAmountValidator(modelValue, viewValue, sign, msg, canBeEmpty,
		canBeContinuing, canBeNA, elm, ctrl) {
	if (ctrl.$isEmpty(modelValue)) {
		if (canBeEmpty) {
			$(elm).popover('destroy');
			return true;
		} else {
			jqPopover(elm, 'This field cannot be empty.');
			return false;
		}
	}
	if ($.isNumeric(viewValue)) {
		if (Math.abs(parseFloat(viewValue)) >= 1000000.0) {
			jqPopover(elm, 'This field must be less than 1 Million');
			return false;
		}
		if (viewValue.indexOf('.') > -1 && viewValue.split('.')[1].length > 3) {
			jqPopover(elm, msg);
			return false;
		}
		if (sign === 'positive') {
			if (parseFloat(viewValue) < 0.0) {
				jqPopover(elm, msg);
				return false;
			}
		}
		if (sign === 'negative') {
			if (parseFloat(viewValue) > 0.0) {
				jqPopover(elm, msg);
				return false;
			}
		}
		$(elm).popover('destroy');
		return true;
	}
	if (canBeContinuing) {
		if ('continuing'.startsWith(viewValue.toLowerCase())) {
			return true;
		}
	}
	if (canBeNA) {
		if ('N/A'.startsWith(viewValue.toUpperCase())) {
			return true;
		}
	}
	jqPopover(elm, msg);
	return false;
}

function dollarInputBlur(elm, scope, ctrl) {
	elm.bind('blur', function(ngObj) {
		if (ngObj.target.classList.contains('ng-valid')) {
			if (ngObj.target.value.trim() !== '') {
				scope.$apply(function() {
					ctrl.$setViewValue(parseFloat(ngObj.target.value)
							.toFixed(3));
					ctrl.$render();
				});
			}
		}
	});
}

function continuingInputBlur(elm, scope, ctrl) {
	elm.bind('blur', function(ngObj) {
		if (ngObj.target.classList.contains('ng-valid')) {
			if (ngObj.target.value.trim() !== '') {
				if ('continuing'.startsWith(ngObj.target.value.trim().toLowerCase())) {
					scope.$apply(function() {
						ctrl.$setViewValue('Continuing');
						ctrl.$render();
					});
				} else {
					scope.$apply(function() {					   
						ctrl.$setViewValue(parseFloat(ngObj.target.value.trim()).toFixed(3));
						ctrl.$render();
					});
				}
			}
		}
	});
}

function naContinuingInputBlur(elm, scope, ctrl) {
	elm.bind('blur', function(ngObj) {
		if (ngObj.target.classList.contains('ng-valid')) {
			if (ngObj.target.value !== '') {
				if ('continuing'.startsWith(ngObj.target.value.toLowerCase())) {
					scope.$apply(function() {
						ctrl.$setViewValue('Continuing');
						ctrl.$render();
					});
				} else if ('N/A'.startsWith(ngObj.target.value.trim().toUpperCase())) {
					scope.$apply(function() {
						ctrl.$setViewValue('N/A');
						ctrl.$render();
					});
				} else {
					scope.$apply(function() {
						ctrl.$setViewValue(parseFloat(ngObj.target.value.trim())
								.toFixed(3));
						ctrl.$render();
					});
				}
			}
		}
	});
}

function mmYyyyInputBlur(elm, scope, ctrl) {
	elm.bind('blur', function(ngObj) {
		if (ngObj.target.classList.contains('ng-valid')) {
			if (ngObj.target.value.trim() !== '') {
				ctrl.$validate();
				scope.$apply();
			}
		}
	});
}

function jqPopover(element, msg) {
	var popoverOptions = {
		'placement' : 'top',
		'trigger' : 'focus',
		'content' : msg
	};
	try{
		$(element).popover(popoverOptions);
		if ($(element).is(':focus')) {
			$(element).popover('show');
		}
	}
	catch(e)
	{
		element.popover(popoverOptions);
		if (element.is(':focus')) {
			element.popover('show');
		}
	}
}

var cbesApp = angular.module('angularCBES', []);

cbesApp.filter('paragraphs', function() {
	return function(input) {
		return input ? input.split('\n') : '';
	};
});

cbesApp.filter('dashIfNullOrZero', function() {
	return function(input) {
		if (!input) {
			return '-';
			// } else if (input === '0.000') { // We no longer replace 0.000
			// with -
			// return '-';
		} else {
			return input;
		}
	};
});

cbesApp.filter('monthAndYear', function() {
	return function(input) {
		if (!validYyyyMm(input)) {
			return '-';
		} else {
			var monthNames = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul','Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
			var monthIndex = parseInt(input.substring(5, 7)) - 1;
			return monthNames[monthIndex] + ' ' + input.substring(0, 4);
		}
	};
});

cbesApp.filter('fullMonthAndYear', function() {
	return function(input) {
		if (!validYyyyMm(input)) {
			return '-';
		} else {
			var monthNames = [ 'January', 'February', 'March', 'April', 'May',
					'June', 'July', 'August', 'September', 'October',
					'November', 'December' ];
			var monthIndex = parseInt(input.substring(5, 7)) - 1;
			return monthNames[monthIndex] + ' ' + input.substring(0, 4);
		}
	};
});

cbesApp.directive('cxePing', function() {
	return {
		link : function(scope, elm) {
			elm.on('keydown', function() {
				pingToResetCounter();
			});
			elm.on('click', function() {
				pingToResetCounter();
			});
		}
	};
});

cbesApp.directive('cxeDollarAmount', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.dollar = function(modelValue, viewValue) {
				var msg = 'Must be a number with 3 or fewer decimal places.';
				return dollarAmountValidator(modelValue, viewValue, 'either',
						msg, true, false, false, elm, ctrl);
			};
			dollarInputBlur(elm, scope, ctrl);
		}
	};
});

cbesApp.directive('notNull', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.notNull = function(modelValue, viewValue) {
				if (attrs.longYear !== 'BudgetYearOneOOC') {
					var msg = 'This field cannot be left blank';
					return dollarAmountValidator(modelValue, viewValue,
							'either', msg, false, false, false, elm, ctrl);
				} else {
					return dollarAmountValidator(modelValue, viewValue,
							'either', msg, true, false, false, elm, ctrl);
				}

			};
			dollarInputBlur(elm, scope, ctrl);
		}
	}
})

cbesApp.directive('cxePositiveDollarAmount',function() {
					return {
						require : 'ngModel',
						link : function(scope, elm, attrs, ctrl) {
							ctrl.$validators.positivedollar = function(
									modelValue, viewValue) {
								var msg = 'Must be a positive number with 3 or fewer decimal places.';
								return dollarAmountValidator(modelValue,
										viewValue, 'positive', msg, true,
										false, false, elm, ctrl);
							};
							dollarInputBlur(elm, scope, ctrl);
						}
					};
				});

cbesApp.directive('cxeNegativeDollarAmount', function() {
					return {
						require : 'ngModel',
						link : function(scope, elm, attrs, ctrl) {
							ctrl.$validators.negativedollar = function(
									modelValue, viewValue) {
								var msg = 'Must be a negative number with 3 or fewer decimal places.';
								return dollarAmountValidator(modelValue,
										viewValue, 'negative', msg, true,
										false, false, elm, ctrl);
							};
							dollarInputBlur(elm, scope, ctrl);
						}
					};
				});

cbesApp.directive('cxeContinuingAmount', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.continuing = function(modelValue, viewValue) {
				var msg = 'Must be either "Continuing" or a positive number ';
				msg += 'with 3 or fewer decimal places.';
				return dollarAmountValidator(modelValue, viewValue, 'positive',
						msg, true, true, false, elm, ctrl);
			};
			continuingInputBlur(elm, scope, ctrl);
		}
	};
});

cbesApp.directive('cxeNaContinuingAmount',function() {
					return {
						require : 'ngModel',
						link : function(scope, elm, attrs, ctrl) {
							ctrl.$validators.continuing = function(modelValue,
									viewValue) {
								var msg = 'Must be either "Continuing" or "N/A" or a positive number ';
								msg += 'with 3 or fewer decimal places.';
								return dollarAmountValidator(modelValue.trim(),
										viewValue.trim(), 'positive', msg, true, true,
										true, elm, ctrl);
							};
							naContinuingInputBlur(elm, scope, ctrl);
						}
					};
				});

cbesApp.directive('cxeNotEmptyPositiveDollar', function() {
					return {
						require : 'ngModel',
						link : function(scope, elm, attrs, ctrl) {
							ctrl.$validators.positivedollar = function(
									modelValue, viewValue) {
								var msg = 'Must be a positive number with 3 or fewer decimal places.';
								return dollarAmountValidator(modelValue,
										viewValue, 'positive', msg, false,
										false, false, elm, ctrl);
							};
							dollarInputBlur(elm, scope, ctrl);
						}
					};
				});

cbesApp.directive('cxeMdapValidator', function() {
					return {
						require : 'ngModel',
						link : function(scope, elm, attrs, ctrl) {
							ctrl.$validators.validmdap = function(modelValue,
									viewValue) {
								var msg = 'The MDAP/MAIS Code cannot contain any special characters.';
								return specialCharactersValidator(modelValue,
										viewValue, msg, true, false, elm, ctrl);
							};
						}
					};
				});

cbesApp.directive('cxeInteger', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.integer = function(modelValue, viewValue) {
				if (ctrl.$isEmpty(modelValue)) {
					// consider empty models to be valid
					$(elm).popover('destroy');
					return true;
				}
				var INTEGER_REGEXP = /^\-?\d+$/;
				if (INTEGER_REGEXP.test(viewValue)) {
					// it is valid
					$(elm).popover('destroy');
					return true;
				}
				var msg = 'Must be an integer.';
				jqPopover(elm, msg);
				return false;
			};
		}
	};
});

cbesApp.directive('cxeNonNegativeInteger', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.nonnegativeinteger = function(modelValue,
					viewValue) {
				if (ctrl.$isEmpty(modelValue)) {
					// consider empty models to be valid
					$(elm).popover('destroy');
					return true;
				}
				var INTEGER_REGEXP = /^\d+$/;
				if (INTEGER_REGEXP.test(viewValue)) {
					// it is valid
					$(elm).popover('destroy');
					return true;
				}
				var msg = 'Must be a positive integer or zero.';
				jqPopover(elm, msg);
				return false;
			};
		}
	};
});

cbesApp.directive('cxeNotEmpty', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			$(elm).attr('placeholder', 'Required');
			ctrl.$validators.notempty = function(modelValue) {
				if (ctrl.$isEmpty(modelValue)) {
					var msg = 'This field cannot be empty.';
					jqPopover(elm, msg);
					return false;
				} else {
					$(elm).popover('destroy');
					return true;
				}
			};
		}
	};
});

cbesApp.directive('cxeNotEmptySaveable', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			$(elm).attr('placeholder', attrs.cxeNotEmptySaveable !== '' ? attrs.cxeNotEmptySaveable : 'Required');
			ctrl.$validators.notempty = function(modelValue) {
				if (ctrl.$isEmpty(modelValue)) {
					var msg = 'This field cannot be empty.';
					jqPopover(elm, msg);
		
					return true;
				} else {
					$(elm).popover('destroy');
					
					return true;
				}
			};
		}
	};
});


cbesApp.directive('cxeMmYyyy', function() {
	return {
		require : 'ngModel',
		link : function(scope, elm, attrs, ctrl) {
			ctrl.$validators.integer = function(modelValue, viewValue) {
				if (ctrl.$isEmpty(viewValue)) {
					$(elm).popover('destroy');
					return true;
				}
				if (validMmYyyy(viewValue)) {
					$(elm).popover('destroy');
					return true;
				}
				if (validPartialMmYyyy(viewValue) && $(elm).is(":focus")) {
					$(elm).popover('destroy');
					return true;
				}
				var msg = 'Must be in the format MM-YYYY after 01-2000.';
				jqPopover(elm, msg);
				return false;
			};
			ctrl.$parsers.push(function(data) {
				// convert data from view format to model format
				if (validMmYyyy(data)) {
					return data.substring(3, 7) + '-' + data.substring(0, 2);
				} else {
					return data;
				}
			});
			ctrl.$formatters.push(function(data) {
				// convert data from model format to view format
				if (validYyyyMm(data)) {
					return data.substring(5, 7) + '-' + data.substring(0, 4);
				} else {
					return data;
				}
			});
			mmYyyyInputBlur(elm, scope, ctrl);
		}
	};
});

cbesApp.directive('cxeLengthConstrained', function($compile) {
	return {
		link : function(scope, element, attrs) {
			attrs.$set('ngTrim', "false");
			var maxchars = parseInt(attrs.maxlength);
			var remaining = maxchars - element.val().length;
			var divHtml = '<div class="cxe-input-remaining">';

			divHtml += remaining.toString() + ' characters remaining</div>';
			var contentDiv = $(divHtml);
			contentDiv.insertAfter(element);

			$compile(contentDiv)(scope);
			var hasFocus = false;
			element.bind('focus',
					function() {
						hasFocus = true;
						contentDiv.attr('style', 'opacity:1; color: #777777');
						contentDiv.text(remaining.toString()
								+ ' characters remaining');
						if (remaining == 1) {
							contentDiv.attr('style', 'color: #bb0000');
						} else if ((remaining / maxchars) < .05) {
							contentDiv.attr('style', 'color: #dd7733');
						}
						$compile(contentDiv)(scope);
						scope.$apply();
					});
			element.bind('blur', function() {
				hasFocus = false;
				contentDiv.attr('style', 'opacity:0');
				$compile(contentDiv)(scope);
				scope.$apply();
			});
			scope.$watch(attrs.ngModel,
					function(v) {
						if (typeof v == "undefined") {
							return;
						}
						remaining = parseInt(attrs.maxlength) - v.length;
						contentDiv.text(remaining.toString()
								+ ' characters remaining');
						if (remaining < 1) {
							contentDiv.attr('style', 'color: #bb0000');
						} else if (remaining / maxchars < 0.05) {
							contentDiv.attr('style', 'color: #dd7733');
						} else if (remaining < attrs.maxlength && hasFocus) {
							contentDiv.attr('style',
									'opacity:1; color: #777777');
						} else {
							contentDiv.attr('style', 'opacity:0');
						}
						$compile(contentDiv)(scope);
					});
			$compile(contentDiv)(scope);
		}
	};
});

cbesApp.factory('templateCacheInjector', [ function() {
	var templateCacheInjector = {
		request : function(config) {
			// cache ng-if lazy loaded r2 angular html templates
			if (config.url.search('/r2/angular/') > -1) {
				config.cache = true;
			}
			return config;
		}
	};

	return templateCacheInjector;
} ]);

cbesApp.config([ '$httpProvider', function($httpProvider) {
	$httpProvider.interceptors.push('templateCacheInjector');
	$httpProvider.useApplyAsync(true);
} ]);

cbesApp.controller('cbesCtrl',function($scope, $http, $compile) {
					var thisctrl = this;
					var urlArr = document.URL.split('/');
					var peID = urlArr[urlArr.length - 1];
					$scope.exhibitsInEditMode = 0;
					$scope.byInt = 0;
					$scope.isLoaded = false;
					$scope.loadFailed = false;
					$scope.loadFailedMessage = 'There was a problem while trying to load this PE.';

					/*
					 * The ng-include that used to be in the tml file was no longer functioning after the Tapestry upgrade.
					 * This is related to no longer being able to set the ng-app and ng-controller attributes in the tml due to require.js.
					*/
					$http.get('/r2/angular/peEditAngular.html').then(function(response) {
						  var element = $('.cxeContentContainer')[1];
						  element.innerHTML += response.data;
						  $compile(angular.element(element))($scope); // Compile the content
					});
				
					/*
					 * Had to throw all of this stuff in an ajax call because the controller was trying to load without the peData being set
					 * peData was being set by the afterRender function in PEEditAngular, but with the Tapestry upgrade it was no longer functioning properly
					 * We have Tapestry 5.4.1 to thank 
					 */
					$http.get('/r2/PeJson/' + peID)
					.then(function(response) {
						setPeData(response.data);
						if (peData.ProgramElement) {
							$scope.r4aYears = r4aYears(peData.ProgramElement.BudgetYear);
							$scope.showTest = peData.showTest;
							$scope.userRole = peData.userRole;
							$scope.showUnlock = peData.showUnlock;
							$scope.isFrozen = peData.isFrozen;
							$scope.frozenBy = peData.frozenBy;
							$scope.frozenByID = peData.frozenByID;
							$scope.showProjectButtons = peData.showProjectButtons;
							$scope.pe = peData.ProgramElement;
							$scope.saved = angular.copy($scope.pe);
							$scope.byInt = parseInt(peData.ProgramElement.BudgetYear);
							$scope.isLoaded = true;
							$("#r2LoadingBannerText").text("Found...");
						} else {
							$scope.loadFailed = true;
							if (peData.errorMessages) {
								$scope.loadFailedMessage = peData.errorMessages[0].message;
								console.log(JSON.stringify(peData.errorMessages[0].message));
							}
						}

						$scope.saveProgramElement = function(programElementForm) {
							if (programElementForm.$invalid) {
								var msg = 'This program element cannot be saved in its current state.';
								msg += ' Please correct errors before saving.';
								alert(msg);
							} else if (!$scope.isModified()) {
								// console.log('Program element is not modified, so
								// we are not saving.');
							} else if ($scope.r4withNoImages()) {
								var msg = 'This program element has an R-4 exhibit with no schedule ';
								msg += 'profile images. Please either upload an image file or delete ';
								msg += ' the R-4 exhibit before continuing.';
								alert(msg);
							} else {
								$scope.performSave(true);
							}
						};
						$scope.performSave = function(showModal) {
							$.post('/r2/PeJsonSave/' + peID, {'pe-json' : JSON.stringify({'ProgramElement' : $scope.pe})})
									.done(function(data) {
												if (data.success) {
													var hasExceptionsDuringSave = "exceptions" in data
															&& data.exceptions.length > 0;
													if (!hasExceptionsDuringSave) {
														$('#r2modalFeedbackHeader').text('Saved Successfully');
													} else {
														$('#r2modalFeedbackHeader').text('Caution, all changes may not saved');
													}
													if (showModal) {
														updateSaveModal(data);
													}
													$scope.r4aYears = r4aYears(data.ProgramElement.BudgetYear);
													$scope.pe = data.ProgramElement;
													$scope.saved = angular.copy($scope.pe);
													$scope.byInt = parseInt(data.ProgramElement.BudgetYear);
													$scope.$apply();
												} else {
													var message = "An unknown error occurred.";
													
													if(data.errorMessages && data.errorMessages.length > 0){
														message = data.errorMessages[0].message;
													}
													
													$('#r2modalFeedbackHeader').text('Unable to save exhibit.');
													$('#r2modalFeedbackBody').html(message);
													$('#ruleViolationsCsvLink').hide();
													$('#r2modalFeedback').modal();
													
												}
											})
									.fail(
											function(data) {
												$('#r2modalFeedbackHeader').text('Unable to save exhibit.');
												var ef = $('<iframe id="eFram" height="600px" width="570px"></iframe>');
												$('#r2modalFeedbackBody').html('<p>Exception traceback:</p>');
												$('#r2modalFeedbackBody').append(ef);
												var errorDoc = ef[0].contentDocument || ef[0].contentWindow.document;
												errorDoc.write(data.responseText);
												errorDoc.close();
												$('#ruleViolationsCsvLink').hide();
												$('#r2modalFeedback').modal();
											});
						};
						$scope.reorderViaModal = function(hostObj, arrayKey,
								labelKey, headerLabel, confirmDelete, cantBeEmpty) {
							$('#r2modalReorderDone').unbind();
							$('#r2modalReorderHeader').text('Delete / Reorder ' + headerLabel);
							$('#r2modalSortable').html('');
							var theArray = hostObj[arrayKey];
							$.each(theArray,function(i, item) {
								var liString = '<li class="cxeModalReorderItem" data-order="'+ i + '" >';
								liString += '<img src="/r2/images/datatables_sort/sort_both.png" /> ';
								liString += item[labelKey];
								liString += '<span class="cxeModalDelete pull-right">&times;</span></li>';
								var liSelection = $(liString);
								liSelection.find('.cxeModalDelete').click(
									function(e) {
										e.preventDefault();
										if (confirmDelete) {
											if (confirm('Are you sure you want to delete this project?')) {
												$(this).parent().remove();
											}
										} else {
											$(this).parent().remove();
										}
										if (cantBeEmpty) {
											if ($('.cxeModalReorderItem').length === 1) {
												$('.cxeModalDelete').hide();
											}
										}
									});
									$('#r2modalSortable').append(liSelection);
								});

							if (cantBeEmpty) {
								if ($('.cxeModalReorderItem').length === 1) {
									$('.cxeModalDelete').hide();
								}
							}
							$('#r2modalReorderDone').bind('click', function(f) {
								f.preventDefault();
								var newArray = [];
								$('.cxeModalReorderItem').each(function() {
									newArray.push(theArray[$(this).data('order')]);
								});
								hostObj[arrayKey] = newArray;
								$scope.$apply();
								$('#r2modalReorder').modal('hide');
							});
							$('#r2modalSortable').sortable();
							$('#r2modalSortable').disableSelection();
							$('#r2modalReorder').modal();
						};
						$scope.isModified = function() {
							return !angular.equals($scope.pe, $scope.saved);
						};
						$scope.isUserEditing = function() {
							return $scope.exhibitsInEditMode > 0;
						};
						$scope.isR2User = function(){
							if(peData.userRole === 'R2User'){
								return true;
							} else {
								return false;
							}
						}

						$scope.revertPe = function() {
							if (confirm('This will revert the entire program element. Are you sure?')) {
								$scope.pe = angular.copy($scope.saved);
								// in case images were added before revert, save to
								// delete those
								$scope.performSave(false);
							}
						};
						$scope.lockAndEdit = function(exhibit) {
							$.post('/r2/endpoints/R2Lock',
											{
												'action' : 'lockProgramElement',
												'id' : peID,
												'csrfToken': $scope.pe['@csrfToken']
											},
											function(data) {
												if (data.successMessages) {
													$scope.exhibitsInEditMode++;
													$scope.showUnlock = true;
													exhibit.edit = true;
													($scope.exhibitsBeingEdited = $scope.exhibitsBeingEdited || []).push(exhibit);
													$scope.$apply();
												} else {
													$('#r2modalFeedbackHeader').text('Unable to edit exhibit.');
													$('#r2modalFeedbackBody').html(data.errorMessages[0].message);
													$('#ruleViolationsCsvLink').hide();
													$('#r2modalFeedback').modal();
												}
											});
							return true;
						};
						$scope.doneEditing = function(exhibit) {
							$scope.exhibitsInEditMode--;
							exhibit.edit = false;
							if ($scope.exhibitsInEditMode < 1) {
								$.post('/r2/endpoints/R2Unlock', {
									'action' : 'unlockProgramElement','id' : peID, 'csrfToken': $scope.pe['@csrfToken']
								}, function(data) {
									$scope.showUnlock = false;
								});
							}
						};
						$scope.unlockPe = function() {
							if ($scope.isModified()) {
								$('#r2modalFeedbackHeader').text('Unable to unlock exhibit.');
								$('#r2modalFeedbackBody').html('<p>The Program Element has changes that have been made, but not saved. Please either save changes or revert the exhibit to its last saved state prior to unlocking.</p>');
								$('#ruleViolationsCsvLink').hide();
								$('#r2modalFeedback').modal();
								return;
							}
							$scope.showUnlock = false;
							if ($scope.exhibitsBeingEdited) {
								for (i = 0; i < $scope.exhibitsBeingEdited.length; i++) {
									$scope.exhibitsBeingEdited[i].edit = false;
								}
							}
							$scope.exhibitsBeingEdited = [];
							$scope.exhibitsInEditMode = 0;
							$.post('/r2/endpoints/R2Unlock',
											{
												'action' : 'unlockProgramElement',
												'id' : peID,
												'csrfToken': $scope.pe['@csrfToken']
											},
											function(data) {
												if (data.successMessages) {
													$('#r2modalFeedbackHeader').text('Exhibit unlocked');
													$('#r2modalFeedbackBody').html('<p>The exhibit has been unlocked</p>');
													$('#ruleViolationsCsvLink').hide();
													$('#r2modalFeedback').modal();
													$scope.$apply();
												} else {
													$('#r2modalFeedbackHeader').text('Unable to unlock Program Element.');
													$('#r2modalFeedbackBody').html(data.errorMessages[0].message);
													$('#ruleViolationsCsvLink').hide();
													$('#r2modalFeedback').modal();
												}
											});
						}
						$scope.noteTextDiv = {};
						$scope.missionDescDiv = {};
						$scope.r2aMissionDescDiv = {};
						$scope.changeSummaryExplanationDiv = {};


						$scope.expandTextArea = function(divObj){
							if (divObj.expansionVerb === undefined) {
								divObj.expansionVerb = "Expand";
							}
							if(divObj.expansionVerb === "Expand") {
								divObj.expansion = "expanded";
								divObj.expansionVerb = "Restore";
							} else if (divObj.expansionVerb === "Restore") {
								divObj.expansion = "collapsed";
								divObj.expansionVerb = "Expand";
							}
							else {
								divObj.expansionVerb = "Restore";
								divObj.expansion = "collapsed";
							}
							$scope[divObj] = divObj;
						}

						$scope.addProject = function() {
							$scope.pe.ProjectList.Project.push(blankProject(
									$scope.pe.BudgetYear, $scope.isR3R4()));
						};
						$scope.reorderProjects = function() {
							$scope.reorderViaModal($scope.pe.ProjectList,
									'Project', 'ProjectTitle', 'Projects', true,
									true);
						};
						$scope.addR3 = function(project) {
							project.R3Exhibit = blankR3Exhibit();
						};
						$scope.deleteR3 = function(project) {
							if (confirm('Are you sure you want to delete this R-3 exhibit?')) {
								delete project.R3Exhibit;
							}
						};
						$scope.addR4 = function(project) {
							project.R4Exhibit = blankR4Exhibit();
						};
						$scope.deleteR4 = function(project) {
							if (confirm('Are you sure you want to delete this R-4 exhibit?')) {
								delete project.R4Exhibit;
							}
						};
						$scope.addR4a = function(project) {
							project.R4aExhibit = blankR4aExhibit($scope.pe.BudgetYear);
						};
						$scope.deleteR4a = function(project) {
							if (confirm('Are you sure you want to delete this R-4A exhibit?')) {
								delete project.R4aExhibit;
							}
						};
						$scope.deleteR5 = function(project) {
							if (confirm('Are you sure you want to delete this R-5 exhibit?')) {
								delete project.R5Exhibit;
							}
						};
						$scope.r2AddOtherAdjustment = function() {
							$scope.pe.ChangeSummary.AdjustmentDetails.OtherAdjustmentDetailList.OtherAdjustmentDetail.push(blankOtherAdjustmentDetail());
						};

						$scope.r2ReorderOtherAdjustments = function() {
							$scope.reorderViaModal($scope.pe.ChangeSummary.AdjustmentDetails.OtherAdjustmentDetailList,
											'OtherAdjustmentDetail', 'Title','Adjustments', false, false);
						};
						$scope.r2aAddCongAdd = function(r2a) {
							r2a.CongressionalAddDetailList.CongressionalAddDetail.push(blankR2aCongressionalAddDetail());
						};
						$scope.r2aReorderCongAdd = function(r2a) {
							$scope.reorderViaModal(r2a.CongressionalAddDetailList,
									'CongressionalAddDetail', 'Title','Congressional Add Details', false, false);
						};
						$scope.r2aAddAccPp = function(r2a) {
							r2a.AccomplishmentPlannedProgramList.AccomplishmentPlannedProgram
									.push(blankR2aAccomplishmentPlannedProgram());
						};
						$scope.r2aReorderAccPp = function(r2a) {
							$scope.reorderViaModal(
									r2a.AccomplishmentPlannedProgramList,
									'AccomplishmentPlannedProgram', 'Title',
									'Accomplishments / Planned Programs', false, false);
						};
						$scope.r2aAddJointFunding = function(r2a) {
							r2a.JointFundingList.JointFunding.push(blankR2aJointFunding());
						};
						$scope.r2aReorderJointFunding = function(r2a) {
							$scope.reorderViaModal(r2a.JointFundingList,'JointFunding', 'Title', 'Joint Fundings',false, false);
						};
						$scope.r2aAddOtherProgramFunding = function(r2a) {
							r2a.OtherProgramFundingSummaryList.OtherProgramFundingSummary.push(blankR2aOtherProgramFunding());
						};
						$scope.r2aReorderOtherProgramFunding = function(r2a) {
							$scope.reorderViaModal(
											r2a.OtherProgramFundingSummaryList,
											'OtherProgramFundingSummary', 'Title',
											'Other Program Funding Summaries', false, false);
						};
						$scope.r2aDeleteMajorPerformers = function(r2a) {
							r2a.MajorPerformers.Text = '';
						r2a.MajorPerformers.MajorPerformerList.MajorPerformer = [];
						};
						$scope.r3CCIContractFormatted = function(cci) {
							if (cci.FundingVehicle === '') {
								return cci.ContractMethod + ' / '+ cci.ContractType;
							} else {
								return cci.FundingVehicle;
							}
						};
						$scope.r3CostsInCCG = function(ccgList, ccgName) {
							for (var i = 0; i < ccgList.length; i++) {
								if (ccgList[i].Name === ccgName) {
									if (ccgList[i].CostCategoryItemList.CostCategoryItem.length > 0) {
										return true;
									}
								}
							}
							return false;
						};
						$scope.r3ModalCci = blankR3CCItem();
						$scope.r3AddNewCCG = function(r3, ccgName) {
							var ccgObj = {};
							ccgObj.Name = ccgName;
							ccgObj.CostCategoryItemList = {
								'CostCategoryItem' : []
							};
							ccgObj.Remarks = '';
							$scope.r3AddNewCCItem(ccgObj, r3);
						};
						$scope.r3HasCcgName = function(r3, ccgName) {
							var ccgArray = r3.CostCategoryGroupList.CostCategoryGroup;
							for (var i = 0; i < ccgArray.length; i++) {
								if (ccgArray[i].Name === ccgName) {
									return true;
								}
							}
							return false;
						};
						$scope.r3AddNewCCItem = function(ccg, r3) {
							$('#r2modalR3Header').text('Add Cost Item');
							var newcci = blankR3CCItem();
							$scope.r3EditCCItem(newcci, ccg, true, r3);
						};
						$scope.r3EditExistingCCItem = function(cci, ccg, r3) {
							$('#r2modalR3Header').text('Edit Cost Item');
							$scope.r3EditCCItem(cci, ccg, false, r3);
						};
						$scope.r3EditCCItem = function(cci, ccg, cciIsNew, r3) {
							$scope.r3ModalCci = angular.copy(cci);
							initR3ModalSelects(cci.FundingVehicle !== '');
							$('#r3GovtPerformingActivityCheckbox').unbind();
							$('#r3GovtPerformingActivityCheckbox').change(
									function() {
										$scope.r3ModalCci.ContractMethod = '';
										$scope.r3ModalCci.ContractType = '';
										$scope.r3ModalCci.FundingVehicle = '';
										$scope.$apply();
										initR3ModalSelects($(this).prop('checked'));
									});
							$('#r2modalR3Cancel').unbind();
							$('#r2modalR3Cancel').bind('mousedown', function(f) {
								f.preventDefault();
								$('#r2modalR3').modal('hide');
								thisctrl.r3ModalForm.$setUntouched(true)
							});
							$('#r2modalR3Done').unbind();
							$('#r2modalR3Done').bind('mousedown',
											function(f) {
												f.preventDefault();
												if (thisctrl.r3ModalForm.$invalid) {
													alert('Please fill in the required fields before continuing');
												} else if (!(($scope.r3ModalCci.ContractMethod !== '' && $scope.r3ModalCci.ContractType !== '') || $scope.r3ModalCci.FundingVehicle !== '')) {
													var alertText = 'You must select either:\n\n';
													alertText += '- a contract method and a contract type,\n\n';
													alertText += 'or if a government agency is performing activity:\n\n';
													alertText += '- a funding vehicle.\n\n';
													alertText += 'Please select a contract method/type or funding vehicle';
													alertText += ' before continuing';
													alert(alertText);
												} else {
													// cci =
													// angular.copy($scope.r3ModalCci);
													// // this doesn't work, so we
													// do these 6 lines:
													cci.Name = $scope.r3ModalCci.Name;
													cci.ContractMethod = $scope.r3ModalCci.ContractMethod;
													cci.ContractType = $scope.r3ModalCci.ContractType;
													cci.FundingVehicle = $scope.r3ModalCci.FundingVehicle;
													cci.PerformingActivity = $scope.r3ModalCci.PerformingActivity;
													cci.PerformingActivityLocation = $scope.r3ModalCci.PerformingActivityLocation;

													if (cciIsNew) {
														ccg.CostCategoryItemList.CostCategoryItem.push(cci);
													}
													if (!$scope.r3HasCcgName(r3,ccg.Name)) {
														$scope.r3sortedCCGadd(ccg,r3);
													}
													$scope.$apply();
													$('#r2modalR3').modal('hide');
												}
											});
							$('#r2modalR3').modal();
						};
						$scope.r3sortedCCGadd = function(ccg, r3) {
							r3.CostCategoryGroupList.CostCategoryGroup.push(ccg);
							r3.CostCategoryGroupList.CostCategoryGroup
									.sort(function(a, b) {
										return CXE_CONSTANTS.R3_COST_GROUP_NAMES
												.indexOf(a.Name)
												- CXE_CONSTANTS.R3_COST_GROUP_NAMES
														.indexOf(b.Name);
									});
						};
						$scope.$watch("pe['@isR2Long']",
										function(newValue, oldValue) {
											if (undefined == oldValue
													|| newValue !== oldValue) {
												if (newValue) {
													if ($scope.pe.ProgramElementNote !== '' || $scope.pe.ProgramElementMissionDescription !== '') {
														$scope.pe['@isR2Long'] = false;
														var notBlankMsg = 'The "Note" and "Mission Description" fields for';
														notBlankMsg += ' the program element must be blank before marking';
														notBlankMsg += ' this exhibit "R-2 Long".';
														alert(notBlankMsg);
													}
													if ($scope.pe.ProjectList.Project.length > 1) {
														$scope.pe['@isR2Long'] = false;
														var tooManyProjectsMsg = 'A program element may not have more than ';
														tooManyProjectsMsg += 'one project and also be marked "R-2 Long".';
														alert(tooManyProjectsMsg);
													}
												}
											}
										});
						$scope.$watch('pe.ProjectList',
										function(newValue, oldValue) {
											if (!$scope.isLoaded) {
												return;
											}
											// this is horribly inefficient, but I
											// don't know of a better way.
											for (var a = 0; a < newValue.Project.length; a++) {
												var thisProject = newValue.Project[a];
												if (thisProject.R3Exhibit) {
													var ccgList = thisProject.R3Exhibit.CostCategoryGroupList;
													// we're going to be modifying
													// this array in place, so we
													// loop backwards
													for (var b = ccgList.CostCategoryGroup.length - 1; b >= 0; b--) {
														var ccg = ccgList.CostCategoryGroup[b];
														if (ccg.CostCategoryItemList.CostCategoryItem.length < 1) {
															ccgList.CostCategoryGroup
																	.splice(b, 1);
														}
													}
												}
											}
										}, true);
						$scope.r3ReorderCCItems = function(ccg) {
							$scope.reorderViaModal(ccg.CostCategoryItemList,
									'CostCategoryItem', 'Name',ccg.Name + ' Costs', false, false);
						};
						$scope.r4UploadImage = function(project) {
							// The only real way to get IE to reset a file input is
							// to remove
							// the input and make a new one.
							$('.r4imageuploadfile').remove();
							var inputHtml = '';
							for (var i = 1; i <= 5; i++) {
								inputHtml += '<input type="file" class="r4imageuploadfile" name="file'+ (i + 1) + '"/>';
							}
							$('#r2modalUploadImageBody').prepend(inputHtml);
							$('#r4uploadspinner').hide();
							var formAction = '/r2/R4UploadImage/';
							formAction += project.id;
							var uploadForm = $('#r4ImageUploadForm');
							uploadForm.attr('action', formAction);
							// due to IE's security, you can't set the value of in
							// input[file] value
							// file input values are considered READ ONLY as part of
							// the browser security implementation
							// you have to reset the form
							uploadForm[0].reset();
							var submitButton = uploadForm
									.find('input[type="submit"]');
							submitButton.unbind();
							submitButton.click(function() {
								$('#r4uploadspinner').show();
							});
							$('#r2modalImageUpload').unbind();
							uploadForm.ajaxForm({
										dataType : 'json',
										success : function(data) {
											$('#r4uploadspinner').hide();
											if (data.files) {
												$.each(data.files,
													function(idx, file) {
														if (file.validimage) {
															project.R4Exhibit.ScheduleProfile.push({
																		'Notes' : '',
																		'id' : file.spId,
																		'ImageFileName' : file.filename
																	});
														} else {
															alert(file.filename+ ' is not a valid image file.');
														}
													});
												$('#r2modalUploadImage').modal('hide');
												$scope.$apply();
											} else {
												alert('There was a problem uploading the image(s).');
											}
											return false;
										},
										error : function() {
											$('#r4uploadspinner').hide();
										}
									});
							$('#r2modalUploadImage').modal();
						};
						$scope.r4ReorderImages = function(r4) {
							$scope.reorderViaModal(r4, 'ScheduleProfile','ImageFileName', 'Images', false, false);
						};
						$scope.r4withNoImages = function() {
							for (var i = 0; i < $scope.pe.ProjectList.Project.length; i++) {
								var p = $scope.pe.ProjectList.Project[i];
								if (p.R4Exhibit) {
									if (p.R4Exhibit.ScheduleProfile.length < 1) {
										return true;
									}
								}
							}
							return false;
						};
						$scope.addR4aSubProject = function(r4a) {
							r4a.SubProjectScheduleList.SubProjectSchedule.push(blankR4aSubProject($scope.pe.BudgetYear));
						};

						$scope.addR4aScheduleDetail = function(r4a) {
							var spsList = r4a.SubProjectScheduleList.SubProjectSchedule;
							var lastSPS = spsList[spsList.length - 1];
							lastSPS.ScheduleDetailList.ScheduleDetail.push(blankR4aScheduleDetail($scope.pe.BudgetYear));
						};

						$scope.r4aNumberOfScheduleDetails = function(r4a) {
							var numberOfScheduleDetails = 0;
							for (var i = 0; i < r4a.SubProjectScheduleList.SubProjectSchedule.length; i++) {
								numberOfScheduleDetails += r4a.SubProjectScheduleList.SubProjectSchedule[i].ScheduleDetailList.ScheduleDetail.length;
							}
							return numberOfScheduleDetails;
						}

						$scope.r4aReorderDetails = function(r4a) {
							$('#r2modalReorderDone').unbind();
							$('#r2modalReorderHeader').text('Delete / Reorder Schedule Details');
							$('#r2modalSortable').html('');
							var childIndex = 0;
							var originalParents = angular.copy(r4a.SubProjectScheduleList.SubProjectSchedule);
							var originalChildren = [];
							$.each(originalParents,
											function(i, item) {
												var liString = '<li class="cxeModalReorderItem" data-order="'+ i + '" >';
												liString += '<img src="/r2/images/datatables_sort/sort_both.png" /> ';
												liString += item.Title;
												liString += '<span class="cxeModalDelete pull-right">&times;</span></li>';
												var liSelection = $(liString);
												var scheduleEvents = $('<ul class="r4aModalReorderEvents"></ul>');
												var innerArray = item.ScheduleDetailList.ScheduleDetail;
												$.each(innerArray,
														function(j, detail) {
															originalChildren.push(detail);
															var liString = '<li class="cxeModalSubItem" data-order="';
															liString += childIndex+ '" >';
															childIndex += 1;
															liString += '<img src="/r2/images/datatables_sort/sort_both.png" /> ';
															liString += detail.EventTitle;
															liString += '<span class="cxeModalDelete pull-right">&times;';
															liString += '</span></li>';
															var liSelection = $(liString);
															scheduleEvents.append(liSelection);
														});
												scheduleEvents.sortable({connectWith : '.r4aModalReorderEvents'});
												scheduleEvents.disableSelection();
												liSelection.append(scheduleEvents);
												liSelection.find('.cxeModalDelete').click(
																function(e) {e.preventDefault();
																	$(this).parent().remove();
																});
												$('#r2modalSortable').append(liSelection);
											});
							$('#r2modalReorderDone').bind('click',function(f) {
												f.preventDefault();
												var reorderValid = true;
												var reorderedParents = [];
												$('.cxeModalReorderItem').each(
																function() {
																	var reorderedParent = angular.copy(originalParents[$(this).data('order')]);
																	reorderedParent.ScheduleDetailList.ScheduleDetail = [];
																	if ($(this).find('.cxeModalSubItem').length < 1) {
																		reorderValid = false;
																	}
																	$(this).find('.cxeModalSubItem').each(
																			function() {
																						reorderedParent.ScheduleDetailList.ScheduleDetail.push(originalChildren[$(this).data('order')]);
																					});
																	reorderedParents.push(reorderedParent);
																});
												if (reorderValid) {
													r4a.SubProjectScheduleList.SubProjectSchedule = reorderedParents;
													$scope.$apply();
													$('#r2modalReorder').modal('hide');
												} else {
													var msg = 'All sub projects must have at least one schedule detail. ';
													msg += 'Please delete all empty sub projects before continuing, ';
													msg += 'or cancel to restore deleted schedule details.';
													alert(msg);
												}
											});
							$('#r2modalSortable').sortable();
							$('#r2modalSortable').disableSelection();
							$('#r2modalReorder').modal();
						};
						$scope.r5HasCostData = function() {
							var hasCost = false;
							// for each BY field check whether or not it's blank
						};
						$scope.partialPDF = function() {
							$('#r2PartialProjectPdfTableBody').find('input').prop('checked', true);
							$('#r2modalPartialProjectPdfDone').unbind();
							$('#r2modalPartialProjectPdfDone').bind('click',
											function() {
												var projectsToInclude = [];
												var checkedProjectList = $('#r2PartialProjectPdfTableBody').find('input:checked');
												checkedProjectList.each(function() {
													projectsToInclude.push({
														projectId : $(this).data('id')
													});
												});
												$('#r2modalPartialProjectPdfDone')
														.prop('href','/r2/endpoints/R2DownloadPartialProjectPdf/'
																+ peID
																+ '?projectIds='
																+ encodeURIComponent(JSON.stringify(projectsToInclude)));
												$('#r2modalPartialProjectPdf').modal('hide');
											});
							$('#r2modalPartialProjectPdf').modal();
						};
						$scope.downloadFrom = function(clickEvent,downloadEndpoint, extraParams) {
							// trigger file generation; if successful, receive the
							// link in the response
							$.get(downloadEndpoint + "/" + peID + extraParams,
											function(data) {
												if (data.success) {
													if (typeof data.fileName != 'undefined'
															&& data.fileName.length) {
														// create a hidden download
														// link, simulate a click,
														// then remove link from DOM
														var linkStr = "<a id='"
																+ data.fileName
																+ "' href='"
																+ downloadEndpoint
																+ ":downloadfile/"
																+ data.fileName
																+ "' download='"
																+ data.fileName
																+ "'></a>";
														$(clickEvent.target).after(linkStr);
														var linkElement = document.getElementById(data.fileName);
														linkElement.click();
														$(linkElement).remove();
													} else {
														alert("System error: file not found");
													}
												} else {
													alert(data.errorMessages[0].message);
												}
											});
						}
						$scope.validateProgramElement = function() {
							$.get('/r2/BusinessRuleWarningsJson/' + peID, function(data) {
								if (data.success) {
									$('#r2modalFeedbackHeader').text('Validation Result');
									updateSaveModal(data);
								} else {
									alert(data.errorMessages[0].message);
								}
							});
						};
						$scope.r4AutogeneratedQuarters = r4AutogeneratedQuarters();
						$scope.editUserAccess = function() {
							$('#r2modalUserRightsRevert').unbind();
							$('#r2modalUserRightsDone').unbind();
							var incomingJson;
							$.getJSON('/r2/endpoints/R2GetUserList/' + peID,
									function(data) {
										incomingJson = data;
										buildUserRightsTable(incomingJson);
									});
							$('#r2modalUserRightsDone').bind('click',function(event) {
								event.preventDefault();
								var userRight = [];
								for (var a = 0; a < incomingJson.userRightsList.length; a++) {
									userRight.push({
										userID : incomingJson.userRightsList[a].userID,
										access : incomingJson.userRightsList[a].access });
								}
								var userRights = JSON.stringify(userRight);
								$.post('/r2/endpoints/R2UpdateUserRights/'+ peID,{'userRightsList' : userRights, 'csrfToken': $scope.pe['@csrfToken']},
								function(data) {
									if (data.success) {
										$('#r2modalFeedbackHeader').text('Changes saved');
										$('#r2modalFeedbackBody').html('<p>'+ data.message+ '</p>');
									} else {
										$('#r2modalFeedbackHeader').text('Changes were not saved');
										$('#r2modalFeedbackBody').html('<p>'+ data.message+ '</p>');
									}
									$('#ruleViolationsCsvLink').hide();
									$('#r2modalFeedback').modal();
								});
								$('#r2modalUserRights').modal('hide');
							});

							$('#r2modalUserRightsRevert').bind('click',function() {
										$.getJSON('/r2/endpoints/R2GetUserList/'+ peID,
												function(data) {
											incomingJson = data;
											buildUserRightsTable(incomingJson);
										});
									});
							$('#r2modalUserRights').modal();
						};
						$scope.peFundingCorrectionNeeded = peFundingCorrectionNeeded;
						$scope.peFundingCorrectionClass = peFundingCorrectionClass;
						$scope.r2AdjustmentCorrectionNeeded = r2AdjustmentCorrectionNeeded;
						$scope.r2AdjustmentCorrectionClass = r2AdjustmentCorrectionClass;
						$scope.toggleSpecialProject = toggleSpecialProject;
						$scope.r2aAccPpTotal = r2aAccPpTotal;
						$scope.r2aCongAddTotal = r2aCongAddTotal;
						$scope.r2aJointFundingTotal = r2aJointFundingTotal;
						$scope.r2aServiceTotal = r2aServiceTotal;
						$scope.r2aCorrectionNeeded = r2aCorrectionNeeded;
						$scope.r2aCorrectionClass = r2aCorrectionClass;
						$scope.r3ccgTotal = r3ccgTotal;
						$scope.r3Total = r3Total;
						$scope.r3TotalMinusJf = r3TotalMinusJf;
						$scope.r3CorrectionNeeded = r3CorrectionNeeded;
						$scope.r3CorrectionClass = r3CorrectionClass;
						$scope.ganttClass = ganttClass;
						$scope.cxeConstants = CXE_CONSTANTS;
						$scope.isR3R4 = function() {
							return [ '3', '4', '5', '7', '8']
									.indexOf($scope.pe.BudgetActivityNumber) > -1;
						};
					}).catch(function(jqXHR, textStatus, errorThrown) {
						console.log(textStatus + ": " + errorThrown);
						$scope.loadFailed = true; $scope.loadFailedMessage = 'The program element load failed. Please try again.';
					});
				});

var TIME_TO_ALERT = 13 * 60;

var timeoutCounter = 0;

function alertIfTimeoutIminent() {
	if (timeoutCounter === TIME_TO_ALERT) {
		alert('Your session is about to expire due to inactivity.');
	}
	timeoutCounter += 1;
}

function pingToResetCounter() {
	$.get('/r2/endpoints/R2Ping', function(data) {
		if (data.pinged === 'true') {
			timeoutCounter = 0;
		}
	});
}

setInterval(alertIfTimeoutIminent, 1000);

/* 
 * Manually load the model we just spent time creating
 * ng-app attribute used to do this for us, but it no longer functioned in the tml file
 */
angular.bootstrap(document, ['angularCBES']);