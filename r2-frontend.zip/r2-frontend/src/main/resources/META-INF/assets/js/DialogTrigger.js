(function() {
    var $, _,
      __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  
    $ = jQuery;
  
    _ = T5._;
  
    if (!window.P40) {
      window.P40 = {};
    }
  
    if (!window.P40.ModalDialogWindow) {
      window.P40.ModalDialogWindow = '<div class="oldModal" id="modal-dialog">\n    <h2 id="modal-dialog-title"></h2>\n    <p id="modal-dialog-message"></p>\n    <p>\n      <button id="modal-dialog-accept-button" class="close" style="float: right;"/>\n      <button id="modal-dialog-cancel-button" class="close" style="float: right;"/>\n    </p>\n</div>';
    }
  
    P40.DialogTrigger = (function() {
  
      function DialogTrigger(triggerId, dialogId, triggerEvent, callbacks) {
        var _ref, _ref1, _ref2;
        this.triggerId = triggerId;
        this.dialogId = dialogId;
        this.triggerEvent = triggerEvent;
        this.callbacks = callbacks;
        this.cancelHandler = __bind(this.cancelHandler, this);
  
        this.acceptHandler = __bind(this.acceptHandler, this);
  
        this.open = __bind(this.open, this);
  
        if ($("#modal-dialog").length === 0) {
          $("body").append(window.P40.ModalDialogWindow);
          window.P40.ModalDialogOverlay = $("#modal-dialog").overlay({
            top: 160,
            mask: {
              color: "#ebecff",
              loadSpeed: 200,
              opacity: 0.6,
              zIndex: 99999
            },
            closeOnClick: false,
            closeOnEsc: false,
            oneInstance: false,
            load: false,
            speed: "fast",
            target: "#modal-dialog"
          });
        }
        this.modalOverlay = window.P40.ModalDialogOverlay;
        this.dialogIdSelector = "#" + this.dialogId;
        this.triggerIdSelector = "#" + this.triggerId;
        if ($(this.dialogIdSelector).length === 0) {
          log("DialogTrigger: Could not find dialog ID '" + this.dialogId + "' for triggering element '" + this.triggerId + "'");
        }
        if ($(this.triggerIdSelector).length === 0) {
          log("DialogTrigger: Could not find dialog ID '" + this.dialogId + "' for triggering element '" + this.triggerId + "'");
        }
        this.callbacks.willShow = this.fixCallback((_ref = this.callbacks) != null ? _ref.willShow : void 0);
        this.callbacks.didAccept = this.fixCallback((_ref1 = this.callbacks) != null ? _ref1.didAccept : void 0);
        this.callbacks.didCancel = this.fixCallback((_ref2 = this.callbacks) != null ? _ref2.didCancel : void 0);
        $(this.triggerIdSelector).bind(this.triggerEvent, this.open);
      }
  
      DialogTrigger.prototype.fixCallback = function(callback) {
        try {
          if (typeof callback === "function") {
            return callback;
          } else if (typeof callback === "string") {
            return eval("(0 || function() { return " + callback + "; } )");
          } else {
            return null;
          }
        } catch (exception) {
          return log("DialogTrigger: Couldn't convert callback '" + callback + "' into a function.");
        }
      };
  
      DialogTrigger.prototype.open = function(event) {
        var showDialog, _ref;
        if (this.bypassDialog) {
          return true;
        }
        if (event.button === 1 || event.button === 4) {
          return false;
        }
        if (((_ref = this.callbacks) != null ? typeof _ref.willShow === "function" ? _ref.willShow() : void 0 : void 0) === false) {
          showDialog = false;
        } else {
          showDialog = true;
        }
        if (showDialog) {
          $("body").off("click", "#modal-dialog-accept-button");
          $("body").off("click", "#modal-dialog-cancel-button");
          $("body").on("click", "#modal-dialog-accept-button", this.acceptHandler);
          $("body").on("click", "#modal-dialog-cancel-button", this.cancelHandler);
          $("#modal-dialog-title").text($("" + this.dialogIdSelector + " .title").text());
          $("#modal-dialog-message").html($("" + this.dialogIdSelector + " .message").html());
          $("#modal-dialog-accept-button").text($("" + this.dialogIdSelector + " .accept").text());
          $("#modal-dialog-cancel-button").text($("" + this.dialogIdSelector + " .cancel").text());
          if ($("" + this.dialogIdSelector + " .mode").text() === "ALERT") {
            $("#modal-dialog-cancel-button").css("visibility", "hidden");
          } else if ($("" + this.dialogIdSelector + " .mode").text() === "CONFIRM") {
            $("#modal-dialog-cancel-button").css("visibility", "visible");
          } else {
            log("DialogTrigger: Unknown dialog type!  It needs to be ALERT or CONFIRM.");
          }
          this.modalOverlay.overlay().load();
        }
        return false;
      };
  
      DialogTrigger.prototype.acceptHandler = function() {
        var _ref;
        this.bypassDialog = true;
        if ((_ref = this.callbacks) != null) {
          if (typeof _ref.didAccept === "function") {
            _ref.didAccept();
          }
        }
        this.modalOverlay.overlay().close();
        if (this.triggerEvent === "click") {
          if ($.browser.msie) {
            $(this.triggerIdSelector)[0].click();
          } else {
            simulateClick($(this.triggerIdSelector)[0]);
          }
        }
        this.bypassDialog = false;
        return true;
      };
  
      DialogTrigger.prototype.cancelHandler = function() {
        var _ref;
        if ((_ref = this.callbacks) != null) {
          if (typeof _ref.didCancel === "function") {
            _ref.didCancel();
          }
        }
        return this.modalOverlay.overlay().close();
      };
  
      return DialogTrigger;
  
    })();
  
  }).call(this);
  