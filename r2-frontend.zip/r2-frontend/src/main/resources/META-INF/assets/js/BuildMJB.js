(function() {
    var initializeHelpPopups;
  
    initializeHelpPopups = function() {
      $("#bt-buildmjb-overview-help").bt({
        contentSelector: "$('#bt-buildmjb-overview-help-content')",
        positions: ['bottom'],
        trigger: 'mouseenter',
        width: '550px'
      });
      return $("#bt-buildmjb-overview-help2").bt({
        contentSelector: "$('#bt-buildmjb-overview-help-content')",
        positions: ['bottom'],
        trigger: 'mouseenter',
        width: '550px'
      });
    };
  
    window.setup = function(highlightColor) {
      var originalColor;
      originalColor = "#FFFFFF";
      $('.highlightable').mouseenter(function() {
        if ($(this).css('background-color') === highlightColor) {
          return;
        }
        originalColor = $(this).css('background-color');
        $(this).css('background-color', highlightColor);
        return highlightColor = $(this).css('background-color');
      });
      $('.highlightable').mouseleave(function() {
        return $(this).css('background-color', originalColor);
      });
      initializeHelpPopups();
      return $('.savedUploadDeleteIcon').click(function() {
        return $(this).parents('.savedUploadInfo').hide();
      });
    };
  
  }).call(this);
  