(function() {
    define(["marked.min"], function(marked) {
        // Marked options.
        options = {
            "renderer": new marked.Renderer(),
            "gfm": true,
            "tables": true,
            "breaks": true,
            "pedantic": false,
            "sanitize": false,
            "smartLists": true,
            "smartypants": true
        }

        // Fixes annoying issue with the list numbers being broken
        var test = $("#helpText").html();
        $("#helpText").html(test.replaceAll("## ", "\n## "))

        // Convert the help Markdown text to HTML and stick it in the help box.
        $("#help").html(marked($("#helpText").html(), options));

        // Remove the original Markdown text since it is no longer required.
        $("#helpText").remove();

        // The rest of this script is about generating the dropdown Table of Contents menu ...

        // Returns an integer of the heading level (1-6) from the element, which better be H1-H6.
        function getLevel(element) {
            return parseInt(element.tagName.substring(1));
        }

        // Returns a string with non-breakable spaces for each given level.
        function getIndentation(level) {
            spacing = "";

            // Add non-breakable spaces for each heading level > 1.
            while (level > 1)
            {
                spacing += "&nbsp;&nbsp;&nbsp;&nbsp;"
                level--
            }
            return spacing
        }

        // Returns a string with the HTML for the dropdown title.
        function getDropdwonTitle(element) {
            level = getLevel(element)
            title = ""

            // Bold the top-level title.
            if (level == 1)
            {
                title += "<b>"
            }

            title += element.textContent

            // Bold the top-level title.
            if (level == 1)
            {
                title += "</b>"
            }

            return title
        }

        // Returns the LI HTML String for the dropdown.
        function getLDropdownistItem(element) {
            return `<li><a href='#${element.id}'>${getIndentation(getLevel(element))} ${getDropdwonTitle(element)}</a></li>\n`
        }

        // Holds the dropdown HTML as it is built.
        dropdownHtml = ""

        // Iterate over all headings in the Markdown text and build the dropdown HTML.
        $("#help :header").each(function(index, element) {
            // Make the element's ID unique to avoid duplicates when headers have the same title.
            element.id = element.id + "-" + index

            // Include separators between major headings (H1).
            if (getLevel(element) == 1 && index > 0)
            {
                dropdownHtml += "<li role='separator' class='divider'></li>\n"
            }

            // Add the dropdown LI HTML for this element.
            dropdownHtml += getLDropdownistItem(element)
        });

        // Replace the TOC dropdown with our new HTML content.
        $("#help-toc-dropdown").html(dropdownHtml)

        });
}).call(this);