(function() {

    define(["simplemde.min"], function(SimpleMDE) {
        var $, _;
    
        $ = jQuery;
    
        _ = T5._;
    
        var options;
        options = {
            autoDownloadFontAwesome: false,
            element: $("#markdownEditor")[0],
            indentWithTabs: false,
            promptURLs: true,
            spellChecker: false,
            toolbar: ["bold", "italic", "strikethrough", "heading-1", "heading-2", "heading-3", "code", "quote", "unordered-list", "ordered-list", "clean-block", "link", "image", "table", "horizontal-rule", "preview", "side-by-side", "fullscreen", "guide"]
        };
        return new SimpleMDE(options);
    });
  
  }).call(this);
  