(function() {
    define(["marked.min"], function(marked) {
        var text = document.getElementById("announcementsText").innerHTML;
        var container = document.getElementById("announcements");

        options = {
            renderer: new marked.Renderer(),
            gfm: true,
            tables: true,
            breaks: true,
            pedantic: false,
            sanitize: false,
            smartLists: true,
            smartypants: true
        }
        var html = marked(text, options);
        container.innerHTML = html;
    });
}).call(this);