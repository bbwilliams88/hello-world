#  R-2 Release 7.9 - put date here
## What's New

### General Changes
* Submission Date changed to December 2016.

### User Interface Changes
* XML Tools refactoring.

### R-2 & P-40 PDF Changes
* See XSL change log in XML package distribution.

### XML Changes
* N/A.

## Tips
* Validation **errors** prevent saving, but **warnings** do not.
* If you create an R-2 Long (single Project PE), enter the Mission Description in the R-2a.

## Help
 If you require assistance, please contact us at [dtic.belvoir.pm.list.r2-support@mail.mil](mailto:dtic.belvoir.pm.list.r2-support@mail.mil).

-----

The U.S. Department of Defense is committed to making its electronic and information technologies accessible to individuals with disabilities in accordance with Section 508 of the Rehabilitation Act (29 U.S.C. § 794d), as amended in 1999.  Send feedback or concerns related to the accessibility of this website to: [DoDSection508@osd.mil](mailto:DoDSection508@osd.mil).  For more information about Section 508, please visit the DoD Section 508 website. Last Updated: 08/06/2013
