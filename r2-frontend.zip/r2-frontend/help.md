# Exhibit R-2

## General Instructions

1. An Exhibit R-2 shall be prepared for each program element.
1. All funding with any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Care should be taken to see that exhibits are clear and concise. Abbreviations shall be identified on the page on which they occur.
1. Classified material shall be submitted separately so that the RDT&E backup book can be submitted in an unclassified version.


## Heading Section

1. Include the month and year of submission of the exhibit. If an Amended Budget is submitted, identify the date of the revised submission.
1. Identify BES or PB for Budget Cycle, the Budget Year, and Service Agency Name must match the PRCP (R-1) lock position.
1. Appropriation (Treasury) Code and Name/Budget Activity Number and Title. Identify the appropriation and budget activity. This information must match the PRCP (R-1) lock position.
1. Identify the name of the R-1 line item, as listed in PRCP.
1. An Exhibit R-2 with a Budget Activity Number that is different from the previous years should include PY and CY information within the current Exhibit R-2.

## Resource Summary (Program Element Cost) Section

1. Every Project must have an R-2A exhibit; including where a Project is an aggregate of Congressional Adds.
1. Budget Activity Number must be equal to one of the digits 1-7.
1. Service Agency Name must be specified exactly as shown in the Rules.
1. Budget Cycle must be equal to "POM", "BES", or "PB". (update with OOC when appropriate)
1. Cost To Complete and Total Cost funding values are included in this check for a given budget year if and only if they are all numeric for that budget year.
1. If Budget Activity Number is 4, 5, or 7, an R-3 Exhibit must be provided.
1. Project Number and Nomenclature. Identify the project number and nomenclature, as identified in PRCP.
1. The Exhibit R-2 shall include a fiscal resource summary total for the total program element and for each project in that program element. Ensure the funding matches the PRCP (R-1) lock position and that total costs for Acquisition Category 1 programs are consistent with Selected Acquisition Reports.
1. It will also accept the non-numeric value "Continuous".

## Program Element Note Section

1. Identify when a Program Element or a Project: 1) is a new start, 2) was terminated/completed, 3) was previously funded, or will be funded, in a different Program Element, or 4) has had a Title changes.
1. For Program Element or Project transfers, include the current and previous Program Element number and title, and Project number and title, if applicable.

## Program Element Mission Description Section

1. The R-2 shall include a general description and justification of the efforts included in the program element. (The R-2A shall include a detailed description and justification of the efforts included in the specific project.)

## Program Change Summary Section

1. Total Congressional Adds in the Program Change Summary section is an appropriated amount.
1. An XML Warning will occur when a given budget year's Total Adjustments does not equal the Current President Budget minus the Previous President Budget.
1. Change Summary Explanation shall be a concise narrative summary explaining the changes in the total program element.
1. Program Change Summary (R-2 only). Previous and Current President's budget submissions, with the Total Adjustment shall be identified for PY, CY, BY1 and BY 2 (if applicable). Total Adjustments shall be further broken out into the following categories, as a minimum:
    * Congressional General Reductions
    * Congressional Directed Reductions
    * Congressional Rescissions
    * Congressional Adds
    * Congressional Directed Transfers
    * Reprogrammings
    * SBIR/STTR Transfers

## Other Adjustments Details

1. Other Adjustments may be created if the above standard Adjustments are not adequate. There are no limits on the number of Other Adjustments.
1. A title is required.
1. At least one of Previous Year, Current Year or Budget Year One is required.

## Congressional Add Detail Section

1. Congressional Add Details repeat for each Congressional Adds Title.
1. Congressional Add Details are not submitted in the R-2, they will be extracted from the R-2A Exhibit.
1. Congressional Adds may be: 1) treated as individual projects; 2) grouped, but separately identified, in one or more "Congressional Add" projects; and/or 3) included within "core" projects. (repeated for R-2A).
1. Congressional Adds should include only funding provided by Congress in addition to the Department's request; interdepartmental "transfers", even if Congressionally directed, are not included.
1. Each Congressional Add Title must be unique.
1. If a section for Congressional Add appears, then cost data for at least one year must be present.

# Exhibit R-2A

## General Instructions

1. An Exhibit R-2A shall be prepared for each project, even if there is only one project and even if a project is funded only in a PY and/or CY, regardless of funding amount.
1. All funding with any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Care should be taken to see that exhibits are clear and concise. Abbreviations shall be identified on the page on which they occur.
1. Classified material shall be submitted separately so that the RDT&E backup book can be submitted in an unclassified version.

## Resource Summary (Project Cost) Section

1. If none are submitted, the Articles row will not appear in the PDF.
1. Project Articles and Accomplishments/Planned Programs Articles are no longer mutually exclusive.
1. Project Number and Nomenclature. Identify the project number and nomenclature, as identified in PRCP.
1. Activities in the R-2A should be easily associated to Costs in the Exhibit R-3, where one is submitted.

## Project Note Section

1. Identify when a Project: 1) is a new start, 2) was terminated/completed, 3) was previously funded, or will be funded, in a different Program Element, or 4) has had Title changes.
1. For Project transfers, include the current and previous Program Element number and title, and Project number and title, if applicable.

## Mission Description and Budget Item Justification Section

1. Required for BAs 1, 2, and 3. Specify the technology area as defined in annual budget guidance.
1. On the R-2 this shall be a general description and justification of the efforts included in the program element.
1. The R-2A shall include a detailed description and justification of the efforts included in the specific project.
1. The R-2A shall identify the military requirement(s) that this Project will meet. Identify new start efforts for the budget year(s) within the Program Element and new start efforts since the previous President's budget.

## Accomplishments/Planned Program Section

1. Project Articles and Accomplishments/Planned Programs Articles are no longer mutually exclusive.
1. Accomplishments/Planned Programs Descriptions are optional.
1. Provide a brief description using key terms of the Accomplishment and/or Planned Program. Include objectives, output or end product, and specific program name or major technology effort.
1. An XML Warning will occur when the Project Funding for a budget year does not equal the sum of all Accomplishments/Planned Program Funding and Congressional Add funding for that year.
1. A general description may also be included for each activity, but is not a substitute for the specific bullets.
1. Each Accomplishments/Planned Programs title must be unique.
1. If a section for Accomplishments/Planned Programs appears, then cost data for at least one year must be present.

## Congressional Add Details Section

1. Congressional Add Details repeat for each Congressional Add Title.
1. Data from R-2A Congressional Add details will be automatically re-populated to the Program Element level, within the R-2 Congressional Add Details section.
1. Congressional Adds may be: 1) treated as individual projects; 2) grouped, but separately identified, in one or more "Congressional Add" projects; and/or 3) included within "core" projects.
1. Congressional Adds should include only funding provided by Congress in addition to the Department's request; interdepartmental "transfers", even if Congressionally Directed, are not included.
1. Each Congressional Add Title must be unique.
1. If a section for Congressional Add appears, then cost data for at least one year must be present.

## Other Program Funding Summary Section

1. P-1 Procurement Line Item No./Name; C-1 MilCon Project No./Name; Related RDTE: PE Number/Name (it is not necessary to include the related RDT&E funding profile unless there is a funding dependency between the RDT&E programs)

## Acquisition Strategy Section

1. An explanation of acquisition, management, and contracting strategies shall be provided for each project.
1. This section is not required for Program Elements in Budget Activities 1, 2, 3, and 6.

## Major Performers Section

1. Major Performers text/data is required for the BES cycle only.
1. This data is required for the program budget review submission only.
1. List major contractors, universities, colleges, government facilities, federally funded research and development centers, laboratories, centers, or other organizations contributing to this effort through BY 2.
1. List only those who were primary recipients of funds (e.g., received 15% or over $10 million, whichever is less).
1. Include name or titles, locations, and brief description of work performed. Include actual or projected award date (month/year).
1. Tabular data is optional, and can be included in addition to a general description.
1. If tabular data is present, then the Major Performers name must be unique.

# Exhibit R-3

## General Instructions

1. All funding with any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Care should be taken to see that exhibits are clear and concise. Abbreviations shall be identified on the page on which they occur.
1. The R-3 exhibit is required for ACAT 1D programs funded in budget activities 4, 5, and 7 only, regardless of funding amount. It can not be provided for other budget activities.
1. A separate R-3 exhibit shall be prepared for each project in an applicable R-1 line item. These exhibits shall be printed on 8 1/2 by 11 inch paper in landscape format.
1. All funding within any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Classified material shall be submitted separately so that the RDT&E backup book can be submitted in an unclassified version.
1. Within any one (of the four) Project Information Category, the subtotals for each year should be equal to the sum of all cost amounts within the Project Information Categories for that year.
1. The Project Cost, on the last page, should be equal to the sum of the Subtotals for that year.

## Project Cost Category Section

1. Cost information shall be provided for each project, regardless of funding amount, with project costs broken down into cost categories.
1. Sample cost categories shown are typical of various types of defense research and development efforts.
1. Costs shall be distributed among categories in accordance with the project work breakdown structure (WBS) or other categories used by the project office in project execution. The illustrated sample cost categories may be used if these correspond to the project's structure; however, there is no requirement to use cost categories other than those used by the project office in project execution. Sample cost categories not used in project execution need not be included in the exhibit for that project. If the program office tracks efforts by major contract, then display the information accordingly.
1. The cost categories shall be separated into 4 information categories as follows:
    1. Product Development. Efforts associated with the delivery of a fully integrated system that are in direct support of the system and essential to the development, training, operation, and maintenance of the system. Include all efforts directly supporting system development and delivery to include primary contracts, major component contracts, contracted services, in-house support, and government furnished property. Contracts or government efforts greater than $1 million in any displayed budget year shall be reported individually.
    1. Support Costs. Efforts not directly associated with the delivery of the primary product, including technical engineering services, research studies, and technical support not related directly to product development or to testing and evaluation. Contracts or government efforts greater than $1 million in any displayed budget year shall be reported individually.
    1. Test and Evaluation. Efforts (other than those included within contracts or government efforts included above) associated with engineering or support activities to determine the acceptability of a system, subsystem, or component. Contracts or government efforts greater than $1 million in any displayed budget year shall be reported individually.
    1. Management Services. Efforts associated with services provided in support of program office management and administration processes such as: program oversight, resource justification, budget and programming, milestone and schedule tracking. Federally Funded Research and Development Centers (FFRDCs) are in this category. Contracts or government efforts greater than $1 million in any displayed budget year shall be reported individually.
1. Government Furnished Property. Property, such as hardware, software, or information, which the government is contractually obligated to furnish a contractor or government performing activity shall be identified. Provide a brief identification of the item to be provided, and the contractor or government activity providing the item. Provide estimated date that the government furnished property will be provided to the requiring contractor or activity. Provide the name of the requiring contractor or activity.
1. Award Fees. Identify amounts budgeted for award fees and indicate contractor performance and percentage of award fees actually awarded in past award fee periods.
1. Contract Method/Type or Funding Vehicle. The following codes shall be used to identify the contract method, contract type, and funding vehicle:
    1. Contract Type Contract Method
        1. FP - Fixed Price SS - Sole Source
        1. CPIF - Cost Plus Incentive Fee C - Competitive
        1. FPI - Fixed Price Incentive
        1. CPAF - Cost Plus Award Fee
        1. CPFF - Cost Plus Fixed Fee
        1. FFP - Firm Fixed Price
        1. TBD - To Be Determined
        1. Various - More Than One Source
    1. Funding Vehicle (when a government agency is the performing activity)
        1. MIPR - Military Interdepartmental Purchase Request
        1. PO - Project Order
        1. WR - Work Request
        1. Allot - Allotment
        1. Reqn - Requisition
        1. BPA - Blanket Purchase Agreement
        1. FFRDC - Federally Funded Research and Development Centner
        1. RO - Reimbursable Order
        1. TM - Time and Materials
        1. Various - More Than One Source
1. Performing Organizations. Identify each contractor and government or performing activity and the location for each effort greater than $1 million in any of the displayed years.
1. Total PY Cost. Provide actual amounts for the total of all years before the current year (CY).
1. CY - BY1. Provide actual or budget amounts for each year for current year (CY) and budget year one (BY1).
1. Award or Obligation Date. Provide actual or estimated date of contract award or the estimated date that funds will be obligated to government performing activities.
1. Cost To Complete. Provide the amount required to complete this effort beyond BY1.

## Project Cost Total Section

1. Total Cost. Provide the cumulative total of all budgeted funds for the program (including funds obligated/budgeted for PY, CY, BY1, and to complete). Provide a comment in the Remarks section when the Project Office Estimate at Completion (EAC) differs from the total cost. Also provide a comment when the Performing Activity EAC differs from the Project Office EAC.
1. Target Value of Contract. Identify the target value of the contract and explain those cases where total cost differs significantly. For example, if the budget is at ceiling value of the contract vice target value or if budget is "program manager's best estimate" vice target value, then explain.

## Remarks

1. The R-3 Exhibit contains 2 different types of Remarks fields. Each Cost Category Group has it's own Remarks and the overall exhibit Remarks, which appears on the user interface above the Cost Category Groups. The overall Remarks appear at the bottom of the R-3 template and PDF.

# Exhibit R-4

## General Instructions

1. If an R-4 image is not uploaded, one will be generated automatically from the data in the R-4A Exhibit.
1. Upload/insert R-4 Image Instructions:
    1. The image will automatically be resized to fit in a 10.4" x 5.25" area.
    1. To avoid a stretched look in the Exhibit R-4 PDF, images should be rendered in high resolution. Recommended resolution is typically 200 DPI.
    1. For example, the image size for 10.4" x 5.25" would be 10.4" * 200 x 5.25" * 200 = 2080 x 1050.
    1. The image must not span more than one page.
    1. Allowed formats for images are: tif, jpg, gif, bmp, and png.
1. Download RDT&E R2 Image Export Instructions Package

# Exhibit R-4A

## General Instructions

1. All funding with any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Care should be taken to see that exhibits are clear and concise. Abbreviations shall be identified on the page on which they occur.
1. Classified material shall be submitted separately so that the RDT&E backup book can be submitted in an unclassified version.

## Project / Sub Project Section

NOTES:

* The capability to add sub projects has been added to the R-4A.
* Project Milestones and Sub Project Milestones are mutually exclusive.
* Enter sub projects only if your project is detailed into sub projects.


1. If you added a Project Schedule (R-4A), then a graph (R-4) will be automatically generated for the Exhibit R-2.
1. Enter the Sub Project Name if you want to show sub projects. Otherwise enter "N/A" for the subproject Name.
1. Name is a required field. Name must be unique. Cannot exceed 200 characters.

## Schedule Detail Section

1. Within a Schedule Detail, the Start and End elements must be chronologically correct (value of Start <= value of end).
1. Within a Schedule Detail, the Start and End elements cannot refer to years before the PriorYear (BudgetYear - 2) and after the last budget year.
1. Schedule Detail Title is a required field. Title must be unique and cannot exceed 200 characters.

# Overall Justification Book Help

## General Instructions

1. All funding with any R-Exhibit will be expressed in Millions, with three decimal places, unless specifically noted otherwise.
1. Care should be taken to see that exhibits are clear and concise. Abbreviations shall be identified on the page on which they occur.
1. These pages shall be printed on 8 1/2 by 11-inch paper in landscape format.
1. Classified material shall be submitted separately so that the RDT&E backup book can be submitted in an unclassified version.
1. Include the month and year of submission of the exhibit. If an Amended Budget is submitted, identify the date of the revised submission.

# PRCP Help

## General Instructions

1. Visit the new UI XML tools page.
1. Select the PRCP Validation tab.
1. Click Add File...
1. Select an xml, pdf, or zip file with exhibits.
1. Upload the exhibit data and review the results.
    1. A valid exhibit matches the P-1 or R-1.
    1. An invalid exhibit does not match the P-1 or R-1, with the calculated delta shown in a column.
    1. An unverified exhibit is unmatchable to the PRCP data in the CXE system. This is observed more often with P-40 exhibits.
        1. Verify that a P-1 exists for the PE number of Line Item Number.
        1. For AP Exhibits, check for a PRCP entry with cost type B or C.
        1. Verify the exhibits Budget Activity (BA) and Budet Sub Activity (BSA) numbers match PRCP.
        1. Verify that the exhibit uses the same zero padding as PRCP for the Line Item Number, such as "000034" and not just "34."



