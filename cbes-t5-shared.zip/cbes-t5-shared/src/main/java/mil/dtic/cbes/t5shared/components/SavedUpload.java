/*
 * $Id: SavedUpload.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.ComponentEventCallback;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionAttribute;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.upload.components.Upload;
import org.apache.tapestry5.upload.services.UploadedFile;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.UploadedFileInfo;
import mil.dtic.cbes.t5shared.utils.UploadedStreamResponse;
import mil.dtic.utility.CbesLogFactory;

//@SuppressWarnings("unused")
public class SavedUpload{
  private static final String MJB_FORM_DATA_KEY = "MJBWizardPage:JBFormData";

  private static final Logger log = CbesLogFactory.getLog(SavedUpload.class);
  @Inject
  private ComponentResources componentResources;
  
  @Property
  @SessionAttribute(value=MJB_FORM_DATA_KEY)
  protected JBFormData mfdata;

  @Inject
  private Messages messages;

  @Inject
  private ConfigService config;

  @Parameter(required = true)
  @Property
  private File file;
  
  @Parameter(required = true)
  @Property
  private File workingDir;
  
  @Parameter(value="true")
  @Property
  private boolean showSaved; //this component will still save a file even if the parent validation fails. hide it plz.
  @Parameter
  private String originalName;
  
  @Parameter
  private SavedUploadValidator filevalidator;
  
  @Parameter @Property
  private Block block;
  
  @Parameter
  @Property
  private ServiceAgency agency;
  
  @Parameter
  @Property
  private Boolean uploadDisabled;
  
  @Parameter(value="true")
  @Property
  private boolean showDelete;
  
  @Property
  private boolean cancelMidDelete = false;
  
  @Component(parameters="disabled=inherit:uploadDisabled", publishParameters="validate", inheritInformalParameters=true)
  private Upload upload;
  
  @Component
  private Zone suzone;
  
  private String uuid;  

  //cache for later display and use (since the FileItem itself gets deleted pretty fast)
  private static HashMap<String,UploadedFileInfo> cacheMap= new HashMap<String,UploadedFileInfo>();


  ///////this next block is the UFile block. check commit msg for this comment with more details
  public UploadedFile getUfile(){
      return null;//return ufile;
  }
  
  public void setUfile(UploadedFile newUfile){//ufile = newUfile;
      
  }
  
  public void delete(){
      _delete();
  }
  
  // public as it is called from tml page: MJBWizardBasicInformation line 87,
  public UploadedFileInfo getCached(){     
      if (file != null){ 
    	  log.info("Retrieving file name: " + file.getName());
    	  
    	  if(file.getName() != null && file.getName().contains(".zzz")) {
    		  log.info(String.format("File name %s will be checked for .zzz extension", file.getName()));
    		  
    		  String val = StringUtils.substringBetween(file.getAbsolutePath(), "___", "_");
    		  
    		  log.info(String.format("String value %s extracted from file absolute path %s", val, file.getAbsolutePath()));
    		  
    		  if(StringUtils.isNotBlank(val)) {
	    		  for(String key : cacheMap.keySet()) {
	    			  if(StringUtils.isNotEmpty(key) && key.contains(val)) {    				  
	    				  UploadedFileInfo uploadedFileInfo = cacheMap.get(key);
	    				  
	    				  log.info(String.format("File found with name %s", uploadedFileInfo.getFileName()));
	    				  
	    				  return uploadedFileInfo;
	    			  }
	    		  }
    		  }
    	  }
    	  else if(cacheMap.containsKey(file.getAbsolutePath())) {
              log.trace("SavedUpload:getCached - absolutePath: " + file.getAbsolutePath());
              UploadedFileInfo uploadedFileInfo = cacheMap.get(file.getAbsolutePath());
              log.trace("SavedUpload:getCached - uploadFileInfo(fileName) : " + uploadedFileInfo.getFileName());
              return uploadedFileInfo;
    	  }
//          log.trace("SavedUpload:getCached - absolutePath: " + file.getAbsolutePath());
//          UploadedFileInfo uploadedFileInfo = cacheMap.get(file.getAbsolutePath());
//          log.trace("SavedUpload:getCached - uploadFileInfo(fileName) : " + uploadedFileInfo.getFileName());
//          return uploadedFileInfo;
      }
      log.trace("SavedUpload:getCached - returning null - not recognized as being uploaded");
      return null;
  }
  
  public String getSize(){
      if (file == null){
          return "No File";
      }
      else if(! file.exists()){
          return "File size unavailable";
      }
      else{
          return FileUtils.byteCountToDisplaySize(file.length());
      }
  }
  
  //unique id for zone
  public String getUniqueId(){
      log.debug("SavedUpload:getUniqueId - uuid: " + uuid);
      return uuid;
  }
  
  void setupRender() {
      uuid = "a" + UUID.randomUUID().toString();
      UploadedFileInfo cached = getCached();
        
      if (file != null && cached == null && agency != null){
          cacheMap.put(file.getAbsolutePath(), new UploadedFileInfo(file, agency.getCode()));
      }
    
      if (originalName == null && cached != null){
          originalName = cached.getFileName();
      }    
  }
  
  @Log
  void onValidateFromUpload(UploadedFile preufile) throws ValidationException {
      
      boolean delete = false;
      
      try {
          if (preufile!=null) {
              delete = true; // delete on any exception        
              checkExtension(preufile);           
              file = scanAndCpToUpload(config.getVscanSandboxFolder(), preufile, workingDir);
              checkFile(file, preufile.getFileName());
              cacheMap.put(file.getAbsolutePath(),  new UploadedFileInfo(preufile));
              
              originalName = preufile.getFileName();

              delete = false;
          }
      } 
      catch (IOException e) {
          log.error("", e);
          throw new ValidationException("System Error while uploading file");
      } 
      catch (VirusScanException e) {
          log.error("virus scan exception", e);
          throw new ValidationException(e.getMessage());
      } 
      finally {
          if (delete){
              _delete();
          }
      }
  }


  @Log
  StreamResponse onDownload(String fileName) throws IOException{
    //TODO: this should not just return null but hae some sort of better error message. //?really. doesn't null say enough -- it's not here, maybe an email, if its that important.
    if (cacheMap.containsKey(fileName) && new File(fileName).exists()){
      return new UploadedStreamResponse(cacheMap.get(fileName), new FileInputStream(new File(fileName)));
    }
    else{
      return null;
    }
  }
  
  Object onDelete(File f){
    if (f != null){
      log.debug("savedupload f: " + f.getAbsolutePath());
    }
    
    if (file != null){
      log.debug("savedupload file: " + file.getAbsolutePath());
    }
    
    final boolean onCallParametersWereCorrect = (f !=null && file != null && f.getAbsolutePath().compareTo(file.getAbsolutePath()) ==0);
    componentResources.getContainerResources().triggerEvent("savedUploadDelete", new File[]{f},
        new ComponentEventCallback<Boolean>(){
          @Override
          public boolean handleResult(Boolean b){
            log.debug("componentEventCallback being called with: " + b + "; onCallParametersWereCorrect: " + onCallParametersWereCorrect); 
            if (Boolean.TRUE.compareTo(b) != 0){
              _delete();
            }
            return true;
          }
        });
    
    if (file!= null && onCallParametersWereCorrect){ //this will happen if nothing calls the above callback
      _delete();
    }
    
    //return suzone.getBody(); //broken in components since 2009 apparently
    return componentResources.getEmbeddedComponent("suzone");
  }
  
  private static File createTemp(File destDir, String filewithext) throws IOException  {
      String sfx = FilenameUtils.getExtension(filewithext);
      if (sfx.length()>0) {
          sfx = "." + sfx;
      }
      else {
          sfx = null; //.tmp
      }
      return File.createTempFile("___", sfx, destDir);
  }
  
  @SuppressWarnings("unused")
  private File copyFile(File src) {
      try {
          File dest = createTemp(src.getParentFile(), src.getName());
          FileUtils.copyFile(src, dest);
          //tracker.track(dest, dest); //TODO
          return dest;
      } 
      catch (IOException e) {
          log.error("", e);
          return null;
      }
  }
  
  @Log
  private void _delete() {
      //this is commented out because when you have 2 upload widgets which share the same file (which can happen)
      //you don't want to delete the shared file from the file system.  Ahh what?
      if (file!=null){
          cacheMap.remove(file.getAbsolutePath());
      }
      file = null;
      originalName = null;
  }
  
  private static File scanAndCpToUpload(String sandbox, UploadedFile ufile, File workingDir) throws IOException, VirusScanException {
      File sandboxDir = new File(sandbox);
      File file = createTemp(sandboxDir, ufile.getFileName());
      ufile.write(file);
      return R2Storage.scanAndPutInUpload(workingDir, file.getName(), file, ufile.getFileName());
  }
  
  private void checkExtension(UploadedFile uf) throws ValidationException {
      if (filevalidator!=null){
          filevalidator.validateFilename(uf.getFileName());
      }
  }
  
  private void checkFile(File f, String _originalName) throws ValidationException {
      log.debug("SavedUpload:checkFile: " + _originalName);
      if (filevalidator!=null){
          filevalidator.validateFile(f, _originalName);
      }
      
  }
  
  public String getOriginalName() {
    return originalName;
  }
  
  public boolean isDownloadable() {
	  boolean result = false;
	  
	  if(null != file && null != file.getName()) {
		  if(FilenameUtils.isExtension(file.getName(), "zzz")) {
			  result = true;
		  }
	  }
	    
	  return result;
  }
}
