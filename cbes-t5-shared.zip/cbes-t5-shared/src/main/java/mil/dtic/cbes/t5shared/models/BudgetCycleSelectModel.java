package mil.dtic.cbes.t5shared.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.util.AbstractSelectModel;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;

public class BudgetCycleSelectModel extends AbstractSelectModel
{
    private List<OptionModel> optionModels;

    public BudgetCycleSelectModel(List<BudgetCycle> cycles)
    {
        optionModels = new ArrayList<OptionModel>(cycles.size());
        for (BudgetCycle cycle : cycles)
        {
           optionModels.add(new OptionModelImpl(cycle.getLabel(), cycle));
        }
    }

    public List<OptionGroupModel> getOptionGroups() {return null;}

    public List<OptionModel> getOptions()
    {
      return this.optionModels;
    }
}