package mil.dtic.cbes.t5shared.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.util.AbstractSelectModel;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;

public class ServiceAgencySelectModel extends AbstractSelectModel
{
    private List<OptionModel> optionModels;

    public ServiceAgencySelectModel(List<ServiceAgency> agencies)
    {
        optionModels = new ArrayList<OptionModel>(agencies.size());
        for (ServiceAgency agency : agencies)
        {
           optionModels.add(new OptionModelImpl(agency.getName(), agency));
        }
    }

    public List<OptionGroupModel> getOptionGroups() {return null;}

    public List<OptionModel> getOptions()
    {
      return this.optionModels;
    }
}