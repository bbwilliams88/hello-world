package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.ioc.annotations.Symbol;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class JQueryToolsJavaScriptStack extends AbstractJavaScriptStack
{
  public JQueryToolsJavaScriptStack(
    AssetSource assetSource, SymbolSource symbolSource, @Symbol(SymbolConstants.PRODUCTION_MODE) boolean productionMode)
  {
      super(assetSource, 
        symbolSource,
        productionMode ?
            new String[] {
              symbolSource.expandSymbols("${cb.assetpath}/js/jquery.tools.min.js"),
              symbolSource.expandSymbols("${cb.assetpath}/js/jquery.tools.toolbox.expose.min.js"),
            }
            :
            new String[] {
              symbolSource.expandSymbols("${cb.assetpath}/js/jquerytools/toolbox.expose.js"),
              symbolSource.expandSymbols("${cb.assetpath}/js/jquerytools/tabs.js"),
              symbolSource.expandSymbols("${cb.assetpath}/js/jquerytools/tooltip.js"),
              symbolSource.expandSymbols("${cb.assetpath}/js/jquerytools/overlay.js"),
              symbolSource.expandSymbols("${cb.assetpath}/js/jquerytools/scrollable.js"),
            }, new String[] {});
  }

  @Override
  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
      return assetSource.getClasspathAsset(path, null);
  }

  @Override
  public List<String> getStacks()
  {
      // load jquery stack first
      return Collections.singletonList(CbesT5SharedModule.JQUERYSTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
