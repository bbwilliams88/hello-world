package mil.dtic.cbes.t5shared.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.util.AbstractSelectModel;

import mil.dtic.cbes.jb.IAppropriation;
import mil.dtic.cbes.p40.vo.Appropriation;

public class AppropriationsSelectModel extends AbstractSelectModel {

    private List<OptionModel> optionModels;

    public AppropriationsSelectModel(List<IAppropriation> appropriations, boolean isP40)
    {
        optionModels = new ArrayList<OptionModel>(appropriations.size());
        if (!isP40)
        {
          for (IAppropriation appropriation : appropriations)
          {
            String optionValue = appropriation.getCode() + " - " + appropriation.getName();
            optionModels.add(new OptionModelImpl(optionValue, appropriation));
          }
        }
        else
        {
          for (IAppropriation appropriation : appropriations)
          {
            Appropriation p40Appropriation = (Appropriation)appropriation; 
            String optionValue = p40Appropriation.getCode() + " - " + p40Appropriation.getName();
            optionModels.add(new OptionModelImpl(optionValue, p40Appropriation));
          }
        }

    }

    public List<OptionGroupModel> getOptionGroups() {return null;}

    public List<OptionModel> getOptions()
    {
      return this.optionModels;
    }
}
