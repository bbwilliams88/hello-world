package mil.dtic.cbes.t5shared.components.mjb;

import java.util.List;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.cbes.t5shared.services.DropdownService;
import mil.dtic.utility.CbesLogFactory;

@Import( stack={
    CbesT5SharedModule.DATATABLESTACK,
    CbesT5SharedModule.JQUERYTOOLSSTACK
  },
  library={
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/urlencoder.js",
    "classpath:${cb.assetpath}/js/json2.js",
    "../js/p40datatable.js",
    "../js/editable.js",
    "../js/LiListDatatable.js"
  },
  stylesheet={"context:css/lineitemdatatables.css","../css/controlnumbers.css"})

public class LiListDatatable {
  private static final Logger log = CbesLogFactory.getLog(LiListDatatable.class);

  @Inject
  private ComponentResources resources; 
  @Inject
  private Request request;
  @Parameter(required=true)  
  @Property
  private List<LineItem> lineItems;
  
  @Parameter(value="datatable")  
  @Property
  private String tableId;

  @Inject
  private JavaScriptSupport jsSupport;

  @SuppressWarnings("unused")
  @Property
  private LineItem li; //current pe in loop

  @Inject
  @Property
  @SuppressWarnings("unused") // Used in the TML.
  private DropdownService dropDownService;
  
  public int getBudgetYear()
  {
    return 2000;
  }

  public String getBudgetYearByOffset(int yearOffset)
  {
    return "getBudgetYearByOffset(" +yearOffset + ")";
  }

  public String getCalendarYear()
  {
    return "getCalendarYear()";
  }

  public String getPriorYear()
  {
    return "getPriorYear()";
  }

  public String getLineItemJson()
  {
    JSONArray jsonArray = new JSONArray();
    int i = 0;
    for (LineItem li : lineItems) {
      JSONObject obj = new JSONObject();

      obj.put("p1LineItemNumber", li.getSortableP1LineItemNumber());
      obj.put("lineItemNumber", li.getLineItemNumber());
      obj.put("budgetCycleAndYear", li.getBudgetCycleAndYear());
      obj.put("lineItemTitle", li.getLineItemTitle());
      
      obj.put("appropriationNumber", li.getBudgetSubActivity().getBudgetActivity().getAppropriation().getCode());
      obj.put("appropriationTitle", li.getBudgetSubActivity().getBudgetActivity().getAppropriation().getName());
      
      obj.put("agencyCode", li.getServiceAgency().getCode());
      obj.put("agencyName", li.getServiceAgency().getName());
      obj.put("budgetActivityTitle", li.getBudgetSubActivity().getBudgetActivity().getTitle());

      obj.put("budgetActivityNumber", li.getBudgetSubActivity().getBudgetActivity().getNumber());
      obj.put("bsaNum", li.getBudgetSubActivity().getNumber());
      obj.put("budgetSubActivityTitle", li.getBudgetSubActivity().getTitle());
      obj.put("id", i++);

      jsonArray.put(obj);
    }
    log.debug("getLineItemJson returning: " + jsonArray);
    return jsonArray.toString(false);
  }
  
  public BudgetCycle getBudgetCycle(){
    return dropDownService.getAllBudgetCycles().get(0);
  }

  void afterRender()
  {
    if (lineItems != null && lineItems.size() != 0){
      jsSupport.addScript("setup(\"%s\");", tableId);
    }
  }
}
