package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.encryption.BadSecurityHandlerException;
import org.apache.tapestry5.EventConstants;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Cached;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Zone;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.PropertyAccess;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;


import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.jb.IAppropriation;
import mil.dtic.cbes.jb.JBSupplementalDoc;
import mil.dtic.cbes.p40.vo.Appropriation;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.P40Privileges;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.BudgetCycleDAO;
import mil.dtic.cbes.submissions.dao.LdapDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.delegates.BudgesUploadFileT5;
import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.XmlValidationInfo;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.encoders.AgencyEncoder;
import mil.dtic.cbes.t5shared.encoders.AppropriationsEncoder;
import mil.dtic.cbes.t5shared.encoders.BudgetCycleEncoder;
import mil.dtic.cbes.t5shared.encoders.GenericValueEncoder;
import mil.dtic.cbes.t5shared.models.AppropriationsSelectModel;
import mil.dtic.cbes.t5shared.models.BudgetCycleSelectModel;
import mil.dtic.cbes.t5shared.models.ServiceAgencySelectModel;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.UploadJbUtils;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.UploadPdfUtils;
import mil.dtic.utility.XmlUtil;

/**
 * Basic Information wizard page for Master Justification Book.
 */
@Import(library = { "context:js/jbookFinalWorkflow.js" })
public class MJBWizardBasicInformation extends MJBWizardPage
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardBasicInformation.class);
  @Inject
  private PropertyAccess propertyAccess;

  @Inject
  private ServiceAgencyDAO agencyDAO;
  @Inject
  private BudgetCycleDAO budgetCycleDAO;

  @Component
  private Zone apprZone;
  @Component
  private Zone submDateZone;
  @Inject
  private JavaScriptSupport jsSupport;


  @Property
  private String jbWizBasicInfoHelp;

  // /////upload jb feature///////////////
  @Component(id = "jbFile")
  private SavedUpload jbFileComp;

  @Persist
  @Property
  private File jbFile;

  @InjectPage("cb/MJB/wizardliselection")
  private MJBWizardLiSelection liSelectPage;
  @InjectPage("cb/MJB/wizardpeselection")
  private MJBWizardPESelection peSelectPage;
  @Property
  private String originalJbFileName;

  private boolean processUploadJb = false;
  
  @Property
  private JBookWorkFlowStatus checked;
  
  @Inject
  private ConfigService configService;
  
  @Inject
  private Request request;
  
  @Inject
  private HttpServletRequest httpRequest;
    
  @Override
  @Log
  Object onActivate() throws IOException
  {
	  if (isMaintenanceRedirectNeeded()) {
      // TODO: This might not work on Zone C.
		  String homepageURLString = httpRequest.getRequestURL().toString().replace(request.getPath(), ""); 
			
		  return new URL(homepageURLString);
	  }

	  
	  Object obj = super.onActivate();

	  if (navigation.isP40()){
		  jbWizBasicInfoHelp = config.getJbWizP40BasicInfoHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
	  }
	  else if (navigation.isR2()){
		  jbWizBasicInfoHelp = config.getJbWizR2BasicInfoHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
	  }
	  else{
		  jbWizBasicInfoHelp = "";
	  }

	  checked = setDefault();

	  return obj;
  }

  void afterRender()
  {
    jsSupport.addScript("jQuery('#upload').on('change', function() {return $('#UploadJb').click();});jQuery('#UploadJb').hide();");
    jsSupport.addScript("setup();");
    
    if(JBookWorkFlowStatus.NONE != checked) {
    	jsSupport.addScript(String.format("$(\"input[value=%s]\").prop('checked', true)", checked.getCode()));
    }
  }

  @Log
  @OnEvent(value = EventConstants.VALUE_CHANGED, component = "BcSelect")
  Object onChangeFromBcSelect(BudgetCycle cycle)
  {
    // ajax-update the submission date on change from budget cycle
    getJBFormData().setBudgetCycle(cycle);
    return submDateZone.getBody();
  }


  @Log
  @OnEvent(value = EventConstants.VALUE_CHANGED, component = "agencySelect")
  Object onChangeFromAgencySelect(ServiceAgency agency) {
    if (agency != null) {
      getJBFormData().setServiceAgency(agency);
      //CXE-6831
      getJBFormData().getCoverLogoFile().setUploadFile(null);
      
      return apprZone.getBody();
    }
    log.error("Bad agency code", new IllegalArgumentException("Bad agency code"));
    return null;
  }

  @Override
  public void validate()
  {
    log.debug("Validating Basic Information");

    // set default TOC options for first volume
    if(processUploadJb == false) {

      MJBVolumeModel v = getJBFormData().getVolumes().get(0);

      if(navigation.isR2()) {
        v.getDaOptions().setGenerateProgramElementTocByBA(true);
        v.getDaOptions().setGenerateProgramElementTocByTitle(true);
        v.getDaOptions().setIncludeMasterProgramElementTocByBA(false);
        v.getDaOptions().setIncludeMasterProgramElementTocByTitle(false);
      }

      if(navigation.isP40()) {
        v.getDaOptions().setGenerateLineItemTocByBA(true);
        v.getDaOptions().setGenerateLineItemTocByTitle(true);
        v.getDaOptions().setIncludeMasterLineItemTocByBA(false);
        v.getDaOptions().setIncludeMasterLineItemTocByTitle(false);
      }
    }

    if (jbFile == null && processUploadJb == true)
    {
      addErrorMessage("uploaded Jbook not found");
    }
  }


  public List<IAppropriation> getApprs()
  {
    List<IAppropriation> appropriations;

    if (getNavigation().isP40())
    {
      if (getJBFormData().getServiceAgency() != null) {
        appropriations = new ArrayList<IAppropriation>(mil.dtic.cbes.p40.vo.ServiceAgency.fetchWithCode(CayenneUtils.createDataContext(),
          getJBFormData().getServiceAgency().getCode())
          .getActiveProcurementAppropriationList());
        
        if (getJBFormData().getServiceAgency().getCode().equals("OSD")) {
          Collections.swap(appropriations, 0, 1);
        }
      }
      else {
        appropriations = new ArrayList<IAppropriation>(mil.dtic.cbes.p40.vo.ServiceAgency.fetchWithCode(CayenneUtils.createDataContext(), getAgencies().get(0).getCode())
          .getActiveProcurementAppropriationList());
      }
    }
    else
    {
      if (getJBFormData().getServiceAgency() != null)
        appropriations = new ArrayList<IAppropriation>(agencyDAO.findByCode(getJBFormData().getServiceAgency().getCode()).getRDTEAppropriations());
      else
        appropriations = new ArrayList<IAppropriation>(agencyDAO.findByCode(getAgencies().get(0).getCode()).getRDTEAppropriations());
    }

    return appropriations;
  }

  /**
   * @brief Create T5 SelectModel --> AppropriationsSelectModel
   * 
   * @return new AppropriationsSelectModel object
   */
  public SelectModel getAppropriationsSelectModel()
  {
      return new AppropriationsSelectModel(getApprs(), getNavigation().isP40());
  }

  /**
   * @brief Create T5 SelectModel --> BudgetCycleSelectModel
   * 
   * @return new BudgetCycleSelectModel object
   */
  public SelectModel getBudgetCycleSelectModel()
  {
      return new BudgetCycleSelectModel(getBudgetCycles());
  }
    
  /**
   * @brief Create T5 SelectModel --> ServiceAgencySelectModel
   * 
   * @return new ServiceAgencySelectModel object
   */
  public SelectModel getServiceAgencySelectModel()
  {
      return new ServiceAgencySelectModel(getAgencies());
  }

  /**
   * @brief Create T5 ValueEncoder --> GenericValueEncoder
   * 
   * @return new GenericValueEncoder object 
   */
  public ValueEncoder<IAppropriation> getAppropriationsEncoder()
  {
    return new AppropriationsEncoder(getApprs());
  }
    
  /**
   * @brief Create T5 ValueEncoder --> BudgetCycleEncoder
   * 
   * @return new BudgetCycleEncoder object
   */
  public ValueEncoder<BudgetCycle> getBudgetCycleEncoder()
  {
      log.debug("getBudgetCycleEncoder");
      return new BudgetCycleEncoder(getBudgetCycles());
  }
  
  /**
   * @brief Create T5 ValueEncoder --> AgencyEncoder
   * 
   * @return new AgencyEncoder object
   */
  public ValueEncoder<ServiceAgency> getAgencyEncoder()
  {
      log.debug("getAgencyEncoder");
      return new AgencyEncoder(getAgencies());
  }

  /**
   * Hack to return a list of approved agencies for a user. Since P40
   * ServiceAgency is a different type, this gets the full list of R2 type
   * agencies, and only includes those that match the set the P40 user is
   * approved for.
   *
   * @return A list of the agencies the given user is authorized to edit.
   */
  public List<ServiceAgency> getAgencies()
  {
    if (getNavigation().isP40())
    {
      List<ServiceAgency> agencyList = new ArrayList<ServiceAgency>();
      // Get the r2 version full procurement agency list
      for (ServiceAgency r2Agency : BudgesContext.getServiceAgencyDAO().findAllProcurement())
      {
        // Get the P40 version of the subset of agencies this user is authorized to see
        for (mil.dtic.cbes.p40.vo.ServiceAgency p40Agency : getP40User().getActiveAgencies())
        {
          if (r2Agency.getName().equals(p40Agency.getName())) // Add matches
          {
            agencyList.add(r2Agency);
          }
        }
      }

      if (agencyList.isEmpty() || getP40User().getRole().equals(LdapDAO.GROUP_R2_APP_ADMIN))
        return BudgesContext.getServiceAgencyDAO().findAllProcurement();

      return agencyList;
    }
    else
    {
      return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
    }
  }


  public boolean isShowApprs()
  {
    return getApprs().size() > 1;
  }

  // /////////////uploadJBook feature///////////////

  @Log
  @OnEvent(component = "UploadJb", value = EventConstants.SELECTED)
  void uploadJB()
  {
    log.debug("uploadJB PARTY TIME");
    processUploadJb = true;
  }


  @Log
  @OnEvent(component = "jbFile", value = EventConstants.VALIDATE)
  void onChangeFromjbFile() throws ValidationException
  {
    if (jbFile != null && processUploadJb == true)
    {
      throw new ValidationException("uploaded Jbook not found: " + jbFile.exists());
    }
    else if (processUploadJb == true)
    {
      throw new ValidationException("uploaded Jbook not found isnull? " + (jbFile == null));
    }
    else
    {
      log.debug("never validate: null?" + (jbFile == null) + "; processUploadJb: " + processUploadJb);
    }
  }


  @Override
  public Object successResponse()
  {
    log.debug("SUCCESS RESPONCE PARTY TIME");
    if (processUploadJb)
    {
      if (jbFile != null)
      {
        try
        {
            
          mfdata = new JBFormData(getUserId(), getNavigation().isR2(), getNavigation().isP40());
          for(File file: UploadJbUtils.unwrapJbookFile(jbFile, true)) { //isMjb = true
            processZzz(file);
          }
        }
        catch (VirusScanException e)
        {
          addErrorMessage("Wizard Upload Failed: " + e);
          log.error(e.getMessage(), e);
        }
        catch (IOException e)
        {
          addErrorMessage(e.getMessage() == null ? "Error Uploading Justificationbook Malformed File" : "Error " + e.getMessage());
          log.error(e.getMessage(), e);
        }
        catch (BadSecurityHandlerException e)
        {
          addErrorMessage("Wizard Upload Failed: " + e);
          log.error(e.getMessage(), e);
        }
        catch (CryptographyException e)
        {
          addErrorMessage("Wizard Upload Failed: " + e);
          log.error(e.getMessage(), e);
        }
        catch (ValidationException e)
        {
          addErrorMessage(e.getMessage() == null ? "Error Validating Uploaded Justificationbook  File" : "Error " + e.getMessage());
          log.error(e.getMessage(), e);
        }
        catch (NullPointerException e)
        {
          addErrorMessage(e.getMessage() == null ? "Error Uploading Justificationbook Malformed File" : "Error " + e.getMessage());
          log.error(e.getMessage(), e);
        }
      }
      processUploadJb = false;
    }
    return super.successResponse();
  }


  public SavedUploadValidator getJbFileValidator()
  {
    log.debug("getting pdf file validator");
    return new FileExtensionSavedUploadValidator("The supplied Jbook file does not end in the extension .pdf, .zzz, or .zip.", BudgesContentType.PDF, BudgesContentType.ZZZ, BudgesContentType.ZIP);
  }


  private void processZzz(File zzzFile) throws VirusScanException, IOException
  {
    PreviewResultInfo processedXml = UploadPdfUtils.processZzz(zzzFile, mfdata.getWorkingDirectory(),
        getErrorMessages(), getCurrentBudgesUser(), runOnlyVerifiedRules());

    if (false == processedXml.getErrorList().isEmpty())
    {
      this.addErrorMessages(processedXml.getErrorList());
      return;
    }
    if (processedXml.fatalErrorsExist())
    {
      this.addErrorMessage("Fatal errors found parsing Jbook");
    }

    if (processedXml.getXmlValidationResultList() != null && processedXml.getXmlValidationResultList().isEmpty() != false)
    {
      boolean hasSchemaError = false;
      for (XmlValidationInfo xvi : processedXml.getXmlValidationResultList())
      {

        if (xvi.getXmlValidationResult() != null && xvi.getXmlValidationResult().getSchemaErrorList().isEmpty() != false)
        {
          this.addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());
          hasSchemaError = true;
        }
        if (xvi.getXmlValidationResult() != null && xvi.getXmlValidationResult().getSchemaWarningList().isEmpty() != false)
        {
          this.addWarningMessages(xvi.getXmlValidationResult().getSchemaWarningList());
        }
        if (hasSchemaError)
        {
          return;
        }
      }
    }
    if (processedXml.getMjb() == null)
    {
      this.addErrorMessage("Uploaded xml doesn't contain a parsable Master Justification Book");
      return;
    }
    if (navigation.isP40() && (processedXml.getR2ExhibitList() != null))
    {
      this.addErrorMessage("Error, this is the Procurement Wizard and the uploaded file was an RDT&E jBook");
      return;
    }
    if (navigation.isR2() && (processedXml.getLineItemList() != null))
    {
      this.addErrorMessage("Error, this is the RDT&E Wizard and the uploaded file was a Procurement jBook");
      return;
    }
    mfdata.setAppropriation(processedXml.getMjb().getAppropriation());
    mfdata.setHasErrors(processedXml.getMjb().isHasErrors());
    mfdata.setHasWarnings(processedXml.getMjb().isHasWarnings());
    mfdata.setServiceAgency(processedXml.getMjb().getServiceAgency());
    mfdata.setTitle(processedXml.getMjb().getTitle());
    if (processedXml.getMjb().getDocAssemblyOptions() != null)
    {
      mfdata.setForceEvenPages(processedXml.getMjb().getDocAssemblyOptions().isForceEvenPages());
      mfdata.setGenerateLineItemTocByBA(processedXml.getMjb().getDocAssemblyOptions().isGenerateLineItemTocByBA());
      mfdata.setGenerateLineItemTocByTitle(processedXml.getMjb().getDocAssemblyOptions().isGenerateLineItemTocByTitle());
      mfdata.setGenerateP1(processedXml.getMjb().getDocAssemblyOptions().isGenerateP1());
      mfdata.setGenerateP1m(processedXml.getMjb().getDocAssemblyOptions().isGenerateP1m());
      mfdata.setGenerateR1(processedXml.getMjb().getDocAssemblyOptions().isGenerateR1());
      mfdata.setGenerateR1c(processedXml.getMjb().getDocAssemblyOptions().isGenerateR1c());
      mfdata.setGenerateR1d(processedXml.getMjb().getDocAssemblyOptions().isGenerateR1d());
      mfdata.setGenerateR1Summary(processedXml.getMjb().getDocAssemblyOptions().isGenerateR1Summary());
      mfdata.setGenerateLineItemTocByBA(processedXml.getMjb().getDocAssemblyOptions().isIncludeMasterLineItemTocByBA());
      mfdata.setGenerateLineItemTocByTitle(processedXml.getMjb().getDocAssemblyOptions().isIncludeMasterProgramElementTocByTitle());
      mfdata.setIncludeTov(processedXml.getMjb().getDocAssemblyOptions().isIncludeTov());
      mfdata.setSuppressSubExhibits(processedXml.getMjb().getDocAssemblyOptions().isSuppressSubExhibits());
      mfdata.setWatermark(processedXml.getMjb().getDocAssemblyOptions().getWatermark());
      mfdata.setTrackingHeader(processedXml.getMjb().getDocAssemblyOptions().getTrackingHeader());
      mfdata.setGenerateProgramElementTocByBA(processedXml.getMjb().getDocAssemblyOptions().isGenerateProgramElementTocByBA());
      mfdata.setGenerateProgramElementTocByTitle(processedXml.getMjb().getDocAssemblyOptions().isGenerateProgramElementTocByTitle());
      mfdata.setUseLegacyMJBFormat(processedXml.getMjb().getDocAssemblyOptions().isUseLegacyMJBFormat());
    }
    for (BudgetCycle bc : budgetCycleDAO.getBudgetCycles())
    {
      if (bc.isAmended() == (processedXml.getMjb().getBudgetCycle().toLowerCase().contains("amended")) &&
        bc.isSupplemental() == (processedXml.getMjb().getBudgetCycle().toLowerCase().contains("supplemental")) &&
        bc.getCycle().equalsIgnoreCase(processedXml.getMjb().getBudgetCycle()) &&
        bc.getBudgetYear().equals(processedXml.getMjb().getBudgetYear()))
      {
        mfdata.setBudgetCycle(bc);
      }
    }

    if (navigation.isP40())
    {
      liSelectPage.setPeSelect(false);
    }
    if (navigation.isR2())
    {
      peSelectPage.setPeSelectStr("f");
      peSelectPage.setUploaded(true);
    }
    // adding errors into the upload system
    for (XmlValidationInfo xvi : processedXml.getXmlValidationResultList())
    {
      log.debug("xvi.getXmlValidationResult().hasRulesErrors(): " + xvi.getXmlValidationResult().hasRulesErrors());
      log.debug("xvi.getXmlValidationResult().hasRulesWarnings(): " + xvi.getXmlValidationResult().hasRulesWarnings());
      addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());
      addWarningMessages(xvi.getXmlValidationResult().getSchemaWarningList());
      if (processedXml.getLineItemList() != null)
      {
        processedXml.getLineItemList().setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
        processedXml.getLineItemList().setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());
        liSelectPage.addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
      }
      if (processedXml.getR2ExhibitList() != null)
      {
        processedXml.getR2ExhibitList().setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
        processedXml.getR2ExhibitList().setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());
        peSelectPage.addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
      }
    }
    if (processedXml.getLineItemList() != null)
    {
      liSelectPage.setUploadedLisWrapped(processedXml.getLineItemList());
    }
    if (processedXml.getR2ExhibitList() != null)
    {
      peSelectPage.setUploadedPesWrapped(processedXml.getR2ExhibitList());
    }
    if (processedXml.getMjb().getCoverDoc().getLogoAbsoluteFileName() != null)
    {
      log.debug("setting cover file: " + processedXml.getMjb().getCoverDoc().getLogoAbsoluteFileName());
      mfdata.getCoverLogoFile().setUploadFile(new File(processedXml.getMjb().getCoverDoc().getLogoAbsoluteFileName()));
      mfdata.getCoverLogoFile().setOriginalName(processedXml.getMjb().getCoverDoc().getLogoFileName());
      mfdata.getCoverLogoFile().setTitle(processedXml.getMjb().getCoverDoc().getTitle());
    }
    if (processedXml.getMjb().getAcronymDoc() != null && processedXml.getMjb().getAcronymDoc().getAbsoluteFileName() != null)
    {
      log.debug("setting acronyms file: " + processedXml.getMjb().getAcronymDoc().getAbsoluteFileName());
      mfdata.getAcronymsFile().setUploadFile(new File(processedXml.getMjb().getAcronymDoc().getAbsoluteFileName()));
      mfdata.getAcronymsFile().setOriginalName(processedXml.getMjb().getAcronymDoc().getFileName());
      mfdata.getAcronymsFile().setTitle(processedXml.getMjb().getAcronymDoc().getTitle());
    }

    if (processedXml.getMjb().getCostDoc() != null && processedXml.getMjb().getCostDoc().getAbsoluteFileName() != null){
      log.debug("setting Cost file: " + processedXml.getMjb().getCostDoc().getAbsoluteFileName());
      mfdata.getCostFile().setUploadFile(new File(processedXml.getMjb().getCostDoc().getAbsoluteFileName()));
      mfdata.getCostFile().setOriginalName(processedXml.getMjb().getCostDoc().getFileName());
      mfdata.getCostFile().setTitle(processedXml.getMjb().getCostDoc().getTitle());
    }
    
    if (processedXml.getMjb().getIntroductionDoc() != null && processedXml.getMjb().getIntroductionDoc().getAbsoluteFileName() != null)
    {
      log.debug("setting Introduction file: " + processedXml.getMjb().getIntroductionDoc().getAbsoluteFileName());
      mfdata.getIntroFile().setUploadFile(new File(processedXml.getMjb().getIntroductionDoc().getAbsoluteFileName()));
      mfdata.getIntroFile().setOriginalName(processedXml.getMjb().getIntroductionDoc().getFileName());
      mfdata.getIntroFile().setTitle(processedXml.getMjb().getIntroductionDoc().getTitle());
    }
    if (processedXml.getMjb().getUserP1Doc() != null && processedXml.getMjb().getUserP1Doc().getAbsoluteFileName() != null)
    {
      log.debug("setting userP1Doc  file: " + processedXml.getMjb().getUserP1Doc().getAbsoluteFileName());
      mfdata.getP1File().setUploadFile(new File(processedXml.getMjb().getUserP1Doc().getAbsoluteFileName()));
      mfdata.getP1File().setOriginalName(processedXml.getMjb().getUserP1Doc().getFileName());
      mfdata.getP1File().setTitle(processedXml.getMjb().getUserP1Doc().getTitle());
    }
    if (processedXml.getMjb().getUserR1Doc() != null && processedXml.getMjb().getUserR1Doc().getAbsoluteFileName() != null)
    {
      log.debug("setting userR1Doc  file: " + processedXml.getMjb().getUserR1Doc().getAbsoluteFileName());
      mfdata.getR1File().setUploadFile(new File(processedXml.getMjb().getUserR1Doc().getAbsoluteFileName()));
      mfdata.getR1File().setOriginalName(processedXml.getMjb().getUserR1Doc().getFileName());
      mfdata.getR1File().setTitle(processedXml.getMjb().getUserR1Doc().getTitle());
    }
    if (processedXml.getMjb().getSummaryDoc() != null && processedXml.getMjb().getSummaryDoc().getAbsoluteFileName() != null)
    {
      log.debug("setting Summary  file: " + processedXml.getMjb().getSummaryDoc().getAbsoluteFileName());
      mfdata.getSummaryFile().setUploadFile(new File(processedXml.getMjb().getSummaryDoc().getAbsoluteFileName()));
      mfdata.getSummaryFile().setOriginalName(processedXml.getMjb().getSummaryDoc().getFileName());
      mfdata.getSummaryFile().setTitle(processedXml.getMjb().getSummaryDoc().getTitle());
    }
    if (processedXml.getMjb().getSupplementalDocCollection() != null && processedXml.getMjb().getSupplementalDocCollection().getSupplementalDocList() != null)
    {
      mfdata.getSupplementalFiles().clear();
      for (JBSupplementalDoc s : processedXml.getMjb().getSupplementalDocCollection().getSupplementalDocList())
      {
        log.debug("setting supplementalDoc file: " + s.getTitle() + "; filename: " + s.getAbsoluteFileName());
        BudgesUploadFileT5 sf = new BudgesUploadFileT5(s.getTitle());
        sf.setUploadFile(new File(s.getAbsoluteFileName()));
        sf.setOriginalName(s.getFileName());
        sf.setT5Id(s.getTitle());
        mfdata.getSupplementalFiles().add(sf);
      }
    }

    List<MJBVolumeModel> mFDataVolumes = mfdata.getVolumes();// this local variable is because the accesor doesn't allow for you to access an empty volume list So i need to store the link here clear it and reset it without re-calling the accessor
    mFDataVolumes.clear();
    mFDataVolumes.addAll(UploadJbUtils.getVolumeModels(processedXml.getMjb(), mfdata.getSupplementalFiles()));
  }

  public boolean isWorkflowStatusDisabled(String workflowStatus){
    boolean result = false;
    
    switch(JBookWorkFlowStatus.getByDisplayName(workflowStatus)){
      case DRAFT:
        result =  XmlUtil.isJbWorkflowStatusDisabled(JBookWorkFlowStatus.DRAFT.getCode());
        log.info("Workflow status DRAFT is: " + (result ? "Disabled" : "Enabled"));
        
        break;
      case PREPRCP:
        result = XmlUtil.isJbWorkflowStatusDisabled(JBookWorkFlowStatus.PREPRCP.getCode());
        log.info("Workflow status PREPRCP is: " + (result ? "Disabled" : "Enabled"));

        break;
      case REVIEW:
        result = XmlUtil.isJbWorkflowStatusDisabled(JBookWorkFlowStatus.REVIEW.getCode());
        log.info("Workflow status REVIEW is: " + (result ? "Disabled" : "Enabled"));

        break;
      case FINAL:
        result = XmlUtil.isJbWorkflowStatusDisabled(JBookWorkFlowStatus.FINAL.getCode());
        log.info("Workflow status FINAL is: " + (result ? "Disabled" : "Enabled"));

        break;
      default:
        result = true;
    }
    
    return result;
  }
  
  private JBookWorkFlowStatus setDefault() {	
	  JBookWorkFlowStatus result = JBookWorkFlowStatus.DRAFT;
	  
	  List<JBookWorkFlowStatus> statuses = XmlUtil.getEnabledJBookWorkflowStatuses();
	  
	  if(!statuses.contains(JBookWorkFlowStatus.DRAFT)) {
		  if(statuses.contains(JBookWorkFlowStatus.PREPRCP)) {
			  result = JBookWorkFlowStatus.PREPRCP;
		  }
		  else if(statuses.contains(JBookWorkFlowStatus.REVIEW)) {
			  result = JBookWorkFlowStatus.REVIEW;
		  }
		  else if(statuses.contains(JBookWorkFlowStatus.FINAL)) {
			  result = JBookWorkFlowStatus.FINAL;
		  }
		  else {
			  result = JBookWorkFlowStatus.NONE;
		  }
	  }
	  
	  return result;
  }
  
  private Boolean isMaintenanceRedirectNeeded() {
    boolean isMaintenanceModeOn = false;
    boolean canUserAccessDuringMaintenance = false;

    if (navigation.isP40()) {
      isMaintenanceModeOn = config.getP40MaintenanceModeValue();
	    canUserAccessDuringMaintenance = checkPrivilege(P40Privileges.ACCESS_IN_MAINTENANCE_MODE);
    }
    else if (navigation.isR2()) {
      isMaintenanceModeOn = config.getR2MaintenanceModeValue();
	    canUserAccessDuringMaintenance = checkPrivilege(Privilege.ACCESS_IN_MAINTENANCE_MODE);
    }
	  
	  return (isMaintenanceModeOn && !canUserAccessDuringMaintenance);
  }
}
