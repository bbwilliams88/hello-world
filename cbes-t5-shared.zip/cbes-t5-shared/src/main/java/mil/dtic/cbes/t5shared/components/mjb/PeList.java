/*
 * $Id: PeList.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components.mjb;

import java.util.List;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;

public class PeList
{
  @Parameter(required=true)
  @Property
  private List<ProgramElement> pes;
  
  @SuppressWarnings("unused")
  @Property
  private ProgramElement pe; //current pe in loop
  
  void setupRender()
  {
    //if from db, merge to get lazy agency/ba (L.I.E. paranoia)
    //jibx populates agency name only btw in the from xml case
    //commented since they should be prefetched now
//    if (pes!=null && pes.size()>0 && pes.get(0).getId()!=null) {
//      for (ProgramElement pe : pes) {
//        BudgesContext.getProgramElementDAO().merge(pe); //
//      }
//    }
  }
}
