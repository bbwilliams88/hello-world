package mil.dtic.cbes.t5shared.components.mjb;

import java.io.File;

import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.TextField;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.PdfUtil;

public class MJBAttachmentUpload
{
    private static final Logger log = CbesLogFactory.getLog(MJBAttachmentUpload.class);

    @Inject
    private Messages messages;
    @Property
    @Parameter(required = true, defaultPrefix = "literal")
    @SuppressWarnings("unused") // Used in the TML.
    private String titleTitle;

    @Property
    @Parameter(required = true, defaultPrefix = "literal")
    private String fileTitle;

    @Property
    @Parameter(required = true)
    @SuppressWarnings("unused") // Used in the TML.
    private String title;

    @Property
    @Parameter(required = true)
    @SuppressWarnings("unused") // Used in the TML.
    private File file;

    @Property
    @Parameter(required = true)
    @SuppressWarnings("unused") // Used in the TML.
    private File workingDir;    

    @Property
    @Parameter
    @SuppressWarnings("unused") // Used in the TML.
    private String savedFilename;

    @Parameter
    private SavedUploadValidator filevalidator;

    @SuppressWarnings("unused")
    @Component(publishParameters = "annotationProvider,clientId,disabled,label,nulls,translate,validate,value", inheritInformalParameters = true)
    private TextField titleTextField;

    @SuppressWarnings("unused")
    @Component(publishParameters = "agency,originalName,showSaved,uploadDisabled,showDelete", inheritInformalParameters = true)
    private SavedUpload savedUpload;    

    public SavedUploadValidator getFileValidator()
    {
        if (filevalidator != null)
            return filevalidator;
        return getPdfFileValidator(fileTitle);
    }

    private SavedUploadValidator getPdfFileValidator(final String label)
    {
        return new FileExtensionSavedUploadValidator("", BudgesContentType.PDF)
        {
            @Override
            public void validateFilename(String filename) throws ValidationException
            {
                if (!isValid(filename))
                    throw new ValidationException(messages.format("pdfattach-bad-ext", label, filename));
            }

            @Override
            public void validateFile(File f, String originalName) throws ValidationException
            {
                if (!PdfUtil.isPdf(f))
                    throw new ValidationException(messages.format("pdfattach-bad", label, originalName));

                if (PdfUtil.isSecured(f))
                    throw new ValidationException(messages.format("pdfattach-bad-sec", label, originalName));
            }
        };
    }
    public Object onDelete(){
      log.debug("MJBAttachmentUpload onDelete running");
      file = null;
      savedFilename = null;
      return null;
    }
}
