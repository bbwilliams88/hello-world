/**
 * A simple mixin for attaching javascript that updates a zone on any client-side event.
 * Based on http://tinybits.blogspot.com/2010/03/new-and-better-zoneupdater.html
 */
package mil.dtic.cbes.t5shared.mixins;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Environmental;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.Symbol;
import org.apache.tapestry5.services.Cookies;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
/**
 * A mixin to apply to <a> links that initiate downloads. It appends a random
 * token as a query parameter on the href, then upon click shows a progressbar.
 * The server can take this token and send it back upon download completion as a
 * cookie. The mixin polls for a cookie with this token on the client side, and
 * hides the progress bar when it finds the token.
 * 
 * @author aahmed
 */
@Import(stack=CbesT5SharedModule.JQUERYSTACK, library="classpath:${cb.assetpath}/js/buttonprogressdownload.coffee")
public class ButtonProgressDownload
{
  public static final String PARAM_NAME = "buttonprogressdownload";

  @Inject
  private ComponentResources resources;
  @Environmental
  private JavaScriptSupport jsSupport;
  @Inject
  @Symbol(CbesT5SharedModule.SHOW_PROGRESS_JS_FUNC)
  private String defaultShow;
  @Inject
  @Symbol(CbesT5SharedModule.HIDE_PROGRESS_JS_FUNC)
  private String defaultHide;


  /** Literal name of a global javascript function that shows the progressbar */
  @Parameter(defaultPrefix=BindingConstants.LITERAL)
  private String show;
  /** Literal name of a global javascript function that hides the progressbar */
  @Parameter(defaultPrefix=BindingConstants.LITERAL)
  private String hide;


  @InjectContainer
  private ClientElement element;


  void afterRender() {
    if (show == null) {
      show = defaultShow;
    }
    if (hide == null) {
      hide = defaultHide;
    }
    jsSupport.addScript("new CBES.ProgressDownload('%s', window.%s, window.%s)", element.getClientId(), show, hide);
  }


  /**
   * Write the cookie that notifies client of download completion
   */
  public static void writeCookie(Cookies cookies, String token) {
    if (token != null) {
      cookies.writeCookieValue(PARAM_NAME + token, "foobarbaz", 300);
    }
  }
}