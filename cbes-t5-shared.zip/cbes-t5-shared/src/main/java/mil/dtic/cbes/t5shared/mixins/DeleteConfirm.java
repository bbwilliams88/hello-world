package mil.dtic.cbes.t5shared.mixins;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

/**
 * Put this confirmation anchors only. It will intercept the click,
 * then fire the click event when the dialog's Yes is clicked, and
 * also fall back to going to the anchor's href.
 */
@Import(stack = CbesT5SharedModule.JQUERYTOOLSSTACK, library="classpath:${cb.assetpath}/js/deleteConfirmMixin.js")
public class DeleteConfirm
{
  @Inject
  private JavaScriptSupport jsSupport;

  @InjectContainer
  private ClientElement element;

  @Parameter(required=true, defaultPrefix=BindingConstants.LITERAL)
  private String message;

  void afterRender()
  {
    // jsSupport.addScript(String.format("CBES.deleteConfirm('#%s','%s');", element.getClientId(), message));
      jsSupport.addScript(String.format("CBES.deleteConfirmMixin('#%s','%s');", element.getClientId(), message));

  }
}
