package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;

import mil.dtic.cbes.constants.Constants.JBLogoImageFileType;
import mil.dtic.cbes.submissions.delegates.BudgesUploadFileT5;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.ImageUtil;
import mil.dtic.utility.PdfUtil;

/**
 * Attachments wizard page for Master Justification Book.
 */
public class MJBWizardAttachments extends MJBWizardPage
{
    private static final Logger log = CbesLogFactory.getLog(MJBWizardAttachments.class);

    @Property @SuppressWarnings("unused")
    private BudgesUploadFileT5 currentBuf;

    @Property
    private MJBVolumeModel currentvol;

    private int suppFileLoopIndex;

    @Inject
    private JavaScriptSupport jsSupport;

    @Property
    private boolean p1mChk;

    @Property
    private boolean disableAttachP1R1;

    @Property
    private boolean disableAttachP1R1Upload;

    @Property
    private String jbWizAttachmentsHelp;

    @Log
    void onPrepare()
    {
      suppFileLoopIndex = 0;
    }
    void afterRender()
    {
      jsSupport.addScript("setMaxAjaxFormLoopRows("+(getMaxSupplementals()+2)+",'you cannot attach more then "+getMaxSupplementals() + " supplemental documents');");
      jsSupport.addScript("loadSupplementalsJs(%d);", getMaxSupplementals());
    }

    public SavedUploadValidator getJbImageValidator()
    {
        return new FileExtensionSavedUploadValidator("", JBLogoImageFileType.values())
        {
            @Override
            public void validateFilename(String filename) throws ValidationException
            {
                if (!isValid(filename))
                    throw new ValidationException("The logo image file is invalid; make sure it has the correct extension " + filename);
            }

            @Override
            public void validateFile(File f, String originalName) throws ValidationException
            {
                if (!ImageUtil.validateImageFile(f))
                {
                    throw new ValidationException("The logo image file is invalid; make sure it has the correct extension and content: " + originalName);
                }
            }
        };
    }

    @Override
    Object onActivate() throws IOException {

      Object obj = super.onActivate();

      disableAttachP1R1 = false;
      disableAttachP1R1Upload = false;

      boolean generateRequired = config.isJbWizGenerateP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      boolean attachRequired = config.isJbWizAttachP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());

      if(generateRequired) {

        disableAttachP1R1 = true;
        disableAttachP1R1Upload = true;

        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          if(navigation.isR2())
            vol.setR1File(false);
          else if(navigation.isP40())
            vol.setP1File(false);
        }
      }

      if(attachRequired) {

        disableAttachP1R1 = true;
        disableAttachP1R1Upload = false;

        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          if(navigation.isR2())
            vol.setR1File(true);
          else if(navigation.isP40())
            vol.setP1File(true);
        }
      }

      if(!attachRequired && !generateRequired) {

        disableAttachP1R1 = false;
        disableAttachP1R1Upload = false;
      }

      if(navigation.isP40())
        jbWizAttachmentsHelp = config.getJbWizP40AttachmentsHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      else if (navigation.isR2())
        jbWizAttachmentsHelp = config.getJbWizR2AttachmentsHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      else
        jbWizAttachmentsHelp = "";

      return obj;
    }

    BudgesUploadFileT5 onAddRowFromSupplementals()
    {
        BudgesUploadFileT5 o = new BudgesUploadFileT5(null);
        o.setOriginalName(null);
        o.setUploadFile(null);
        o.setTitle(null);
        o.setOriginalName(null);
        getJBFormData().getSupplementalFiles().add(o);
        return o;
    }

    void onRemoveRowFromSupplementals(BudgesUploadFileT5 o)
    {
        int index = mfdata.getSupplementalFiles().indexOf(o);
        getJBFormData().getSupplementalFiles().remove(o);
        for(MJBVolumeModel vol: mfdata.getVolumes()){
          if (vol.getSupplementalFiles() != null && vol.getSupplementalFiles().length >= getVolSize()){
            vol.getSupplementalFiles()[index] = false;
            vol.getSupplementalFiles()[getVolSize() -1] = false;
          }
        }
    }

    public void setSuppChk(boolean b)
    {
      logFileAndVol(b);
      currentvol.getSupplementalFiles()[suppFileLoopIndex/getVolSize()] = b;
      suppFileLoopIndex++;
    }

    public boolean getSuppChk()
    {
      boolean b = currentvol.getSupplementalFiles()[suppFileLoopIndex/getVolSize()];
      suppFileLoopIndex++;
      return b;
    }
    private int getVolSize()
    {
      //prevent dividebyzero
      return getJBFormData().getVolumes().size() == 0 ? 1 : getJBFormData().getVolumes().size();
    }

    private void logFileAndVol(boolean b)
    {
      int indexOfVol = getJBFormData().getVolumes().indexOf(currentvol);
      log.debug(b + " " + suppFileLoopIndex + " " + indexOfVol + " " + currentvol);
    }

    public <T> int getNonzeroIndex(List<T> l, T obj)
    {
      return l.indexOf(obj) + 1;
    }

    public int getMaxSupplementals()
    {
      return MJBVolumeModel.MAX_SUPPLEMENTAL_FILES;
    }

    public boolean showP1mCheckbox()
    {
      return false;
    }

//    public void setP1mChk(boolean b)
//    {
//      p1mChk = b;
//    }
//
//    public boolean getP1mChk()
//    {
//      return p1mChk;
//    }

    @Override
    public void validate()
    {
      log.debug("Validating Attachments");

      boolean isP1File = false;
      boolean isR1File = false;
      boolean isAcronymsFile = false;
      boolean isCostFile = false;
      boolean isIntroFile = false;
      boolean isSummaryFile = false;
      boolean isSupplementalFile = false;
      
      String checkboxErrorMessage = "You attached %s Document for one or more volumes, but did not select the required checkbox.";

      for(MJBVolumeModel vol : mfdata.getVolumes())
      {

        isAcronymsFile = vol.isAcronymsFile() ? true : isAcronymsFile;
        isIntroFile = vol.isIntroFile() ? true : isIntroFile;
        isCostFile = vol.isCostFile() ? true : isCostFile;
        isSummaryFile = vol.isSummaryFile() ? true : isSummaryFile;

        if(navigation.isP40())
          isP1File = vol.isP1File() ? true : isP1File;
        if(navigation.isR2())
          isR1File = vol.isR1File() ? true : isR1File;
      }

      if(isP1File && mfdata.getP1File().getUploadFile() == null)
        addErrorMessage("The Comptroller P-1 Exhibit option was selected.  You must attach the required PDF document.");
      else if (isP1File)
        validatePageSizes(mfdata.getP1File().getUploadFile(), "P-1 Exhibit");

      if(isR1File && mfdata.getR1File().getUploadFile() == null)
        addErrorMessage("The Comptroller R-1 Exhibit option was selected.  You must attach the required PDF document.");
      else if (isR1File)
        validatePageSizes(mfdata.getR1File().getUploadFile(), "R-1 Exhibit");

      if(isAcronymsFile && mfdata.getAcronymsFile().getUploadFile() == null)
        addErrorMessage("You selected to include an Acronyms Document for one or more volumes, but did not attach the required PDF document.");
      else if (!isAcronymsFile && mfdata.getAcronymsFile().getUploadFile() != null)
          addErrorMessage(String.format(checkboxErrorMessage, "an Acronyms"));
      else if(isAcronymsFile)
        validatePageSizes(mfdata.getAcronymsFile().getUploadFile(), "Acronyms Document");

      if(isIntroFile && mfdata.getIntroFile().getUploadFile() == null)
        addErrorMessage("You selected to include an Introduction Document for one or more volumes, but did not attach the required PDF document.");
      else if (!isIntroFile && mfdata.getIntroFile().getUploadFile() != null)
        addErrorMessage(String.format(checkboxErrorMessage, "an Introduction"));
      else if(isIntroFile)
        validatePageSizes(mfdata.getIntroFile().getUploadFile(), "Introduction Document");

      if(isCostFile && mfdata.getCostFile().getUploadFile() == null)
        addErrorMessage("You selected to include a Cost of Report Document for one or more volumes, but did not attach the required PDF document.");
      else if (!isCostFile && mfdata.getCostFile().getUploadFile() != null)
        addErrorMessage(String.format(checkboxErrorMessage, "a Cost of Report"));
      else if(isCostFile)
        validatePageSizes(mfdata.getCostFile().getUploadFile(), "Cost of Report Document");

      if(isSummaryFile && mfdata.getSummaryFile().getUploadFile() == null)
        addErrorMessage("You selected to include a Summary Document for one or more volumes, but did not attach the required PDF document.");
      else if (!isSummaryFile && mfdata.getSummaryFile().getUploadFile() != null)
        addErrorMessage(String.format(checkboxErrorMessage, "a Summary"));
      else if(isSummaryFile)
        validatePageSizes(mfdata.getSummaryFile().getUploadFile(), "Summary Document");

      int i = 0;

      outer : for(BudgesUploadFileT5 file : mfdata.getSupplementalFiles())
      {

        // if any volume has supplemental doc checked
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          isSupplementalFile = vol.getSupplementalFiles()[i];
          if(isSupplementalFile) break;
        }

        if(isSupplementalFile && file.getUploadFile() == null) {
          addErrorMessage("You selected to include a Supplemental Document for one or more volumes, but did not attach the required PDF document.");
          break outer;
        } else if (!isSupplementalFile && file.getUploadFile() != null) {
          addErrorMessage(String.format(checkboxErrorMessage, "a Supplemental"));
          break outer;
        } else if(isSupplementalFile) {
          validatePageSizes(file.getUploadFile(), "Supplemental Document " + (i+1));
        }

        i++;
      }
    }

    /**
     * Helper method which will take an already open pdfreader and validate that all pages in the pdf are 8.5x11 in landscape or portrait mode.
     * @param pdfReader
     * @return true - All pages are proper size.<br>false - One or more pages are not 8.5x11
     */
    protected boolean validatePageSizes(File file, String documentName)
    {
      PdfReader pdfReader = null;

      try
      {
        pdfReader = new PdfReader(file.getAbsolutePath());

        for (int currPageIndex = 1; currPageIndex <= pdfReader.getNumberOfPages(); ++currPageIndex)
        {

          Rectangle pageSizeRectangle = pdfReader.getPageSizeWithRotation(currPageIndex);
          float widthInches = pageSizeRectangle.getWidth()/72;
          float heightInches = pageSizeRectangle.getHeight()/72;

          if (!PdfUtil.pageCorrectDimensions(widthInches, heightInches))
          {
              String errorMessage = "The attached PDF [" + documentName + "] includes pages that aren't properly sized. " +
                                    "Landscape oriented pages must be 8.5\" x 11\" and portrait oriented pages must be 11\" x 8.5\". " +
                                    "Calculated size for page #" + currPageIndex + " are " + widthInches + "\" x " + heightInches + "\".";
            addErrorMessage(errorMessage);
            return false;
          }
        }
      }
      catch (IOException e)
      {
        log.error("Could not validate page size for file: " + file, e);
        return false;
      }

      return true;
    }
}
