/*
 * $Id: T5Base.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.base;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Secure;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.PropertyAccess;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.RequestGlobals;
import org.apache.tapestry5.services.Response;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.p40.vo.IBase;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.sso.siteminder.P40Privileges;
import mil.dtic.cbes.sso.siteminder.P40UserCredentials;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.sso.siteminder.PrivilegeChecker;
import mil.dtic.cbes.sso.siteminder.SpringUser;
import mil.dtic.cbes.sso.siteminder.UserCredentials;
import mil.dtic.cbes.submissions.ValueObjects.AuditableObject;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.encoders.GenericValueEncoder;
import mil.dtic.cbes.t5shared.encoders.ListUUIDEncoder;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;
import mil.dtic.utility.specialcategory.api.service.SpecialCategoryService;


@Secure
public class T5JBBase
{
  private static final Logger log = CbesLogFactory.getLog(T5JBBase.class);
  @Inject
  private RequestGlobals requestGlobals;
  @Inject
  private Request request;
  @Inject
  private PropertyAccess propertyAccess;
  @Inject
  private ComponentResources componentResources;
  @Inject
  protected SpecialCategoryService specialCategoryService;

  @Inject
  protected ConfigService config;


  @SuppressWarnings("unused")
  @Property
  private Object current; //Do not use this with prop: (the default), only ognl:. With prop it's typesafe.

  private int loopIndex;

  public int getLoopIndex()
  {
    return loopIndex;
  }

  public void setLoopIndex(int loopIndex)
  {
    this.loopIndex = loopIndex;
  }

  public RequestGlobals getRequestGlobals()
  {
    return requestGlobals;
  }

  public void setRequestGlobals(RequestGlobals requestGlobals)
  {
    this.requestGlobals = requestGlobals;
  }

  public AppDefaults getAppDefaults()
  {
    return BudgesContext.getAppDefaults();
  }

  public UserCredentials getUserCredentials()
  {
    if (requestGlobals.getRequest().getSession(false) != null)
    {
      return (UserCredentials)requestGlobals.getRequest().getSession(false).getAttribute("state:r2:user.credentials");
    }
    log.error("getUserCredentials: no user credentials in session");
    return null;
  }

  public BudgesUser getCurrentBudgesUser()
  {
    if (getUserCredentials() != null && getUserCredentials().getUserInfo() != null)
    {
      return getUserCredentials().getUserInfo().getBudgesUser();
    }
    return null;
  }

  public P40UserCredentials getP40UserCredentials()
  {
    if (requestGlobals.getRequest().getSession(false) != null)
    {
      return (P40UserCredentials)requestGlobals.getRequest().getSession(false).getAttribute("state:p40:p40user.credentials");
    }
    log.error("getP40UserCredentials: no user credentials in session");
    return null;
  }

  public P40User getP40User()
  {
    if (getP40UserCredentials() != null && getP40UserCredentials().getP40UserInfo() != null)
    {
      return getP40UserCredentials().getP40UserInfo().getP40User();
    }
    return null;
  }

  public User getCurrentUser()
  {
    return (User)((SecurityContext)SecurityContextHolder.getContext()).getAuthentication().getPrincipal();
  }

  public PrivilegeChecker getPrivs()
  {
    if (getUserCredentials() != null)
    {
      return getUserCredentials().getPrivs();
    }
    return null;
  }

  protected boolean checkPrivilege(Privilege p) 
  {
    if (getUserCredentials()!=null)
      return getUserCredentials().checkPrivilege(p);
    return false;
  }

  /** Check if user has a permission from {@link P40Privileges} */
  protected boolean checkPrivilege(String permission)
  {
    P40User user = getP40User();
    return user.hasPermission(permission);
  }

  public List<ServiceAgency> getAvailableRdteAgencies()
  {
    if (getUserCredentials()!=null && getUserCredentials().getUserInfo()!=null)
    {
      return getUserCredentials().getUserInfo().getAvailableRdteAgencies();
    }
    return Collections.emptyList();
  }

  public List<ServiceAgency> getAvailableProcurementAgencies()
  {
    if (getUserCredentials()!=null && getUserCredentials().getUserInfo()!=null)
    {
      return getUserCredentials().getUserInfo().getAvailableProcurementAgencies();
    }
    return Collections.emptyList();
  }

  public SimpleDateFormat newDateTimeFormatter(String sdf)
  {
    if (sdf != null)
      return new SimpleDateFormat(sdf);
    return null;
  }

  public String formatHeaderDate(Date d)
  {
    if (d!=null) return newDateTimeFormatter(Constants.HEADER_DATETIME_FORMAT).format(d);
    log.error("formatHeaderDate: null date");
    return "null";
  }

  public String formatDatetime(Date d)
  {
    if (d!=null) return newDateTimeFormatter(Constants.DATETIME_FORMAT).format(d);
    log.error("formatDatetime: null date");
    return "";
  }

  public String formatDate(Date d)
  {
    if (d!=null) return newDateTimeFormatter(Constants.DATE_FORMAT).format(d);
    log.error("formatDate: null date");
    return "";
  }

  /*protected String createUniqueFileSystemPrefix()
  {
    return getCurrentUser().getUsername() + "_" + request.getRequestedSessionId() + "_" + System.currentTimeMillis();
  }*/


  //  protected String getT4PageName(Class<? extends BasePage> page)
  //  {
  //    return page.getSimpleName() + ".html";
  //  }

  protected void recordErrors(Form f, List<String> errors)
  {
    for (String error : errors) {
      f.recordError(error);
    }
  }

  public int[] getIterable(int count)
  {
    return new int[count];
  }

  public <T> ValueEncoder<T> getGenericEncoder(List<T> l, String valueField)
  {
    return new GenericValueEncoder<T>(l, valueField, propertyAccess);
  }

  public <T extends IBase> ValueEncoder<T> getUUIDEncoder(List<T> l)
  {
    return new ListUUIDEncoder<T>(l);
  }

  public String encodeUuid(IBase object)
  {
    if (object.getT5Id() == null)
      object.setT5Id(UUID.randomUUID().toString());
    return object.getT5Id();
  }

  @Log
  void onNukeSessionData()
  {
    componentResources.discardPersistentFieldChanges();
  }

  @Log
  protected StreamResponse getStreamResponse(final BudgesDownloadableObject dbdo)
  {
    return new StreamResponse() {
      InputStream inputStream;

      @Override
      public void prepareResponse(Response response) {
        try {
          inputStream = dbdo.getInputStream();
          response.setHeader("Content-Disposition", "attachment; filename=" + dbdo.getUserVisibleLabel());
          response.setContentLength(inputStream.available());          
        }
        catch (IOException e) {
          log.error("Could not stream back contents of budges downloadable object.", e);          
        }
      }

      @Override
      public String getContentType() {
        return dbdo.getBudgesContentType().getMimeType() + Constants.RESPONSE_CHARSET;
      }

      @Override
      public InputStream getStream() throws IOException {
        return inputStream;
      }
    };
    //return getStreamResponse(dbdo.getInputStream(), dbdo.getBudgesContentType().getMimeType() + Constants.RESPONSE_CHARSET, dbdo.getUserVisibleLabel());
  }

  /** fileName can be null for no attachment header */
  @Log
  protected StreamResponse getStreamResponse(final InputStream is, final String contentType, final String fileName)
  {
    if (is==null || contentType==null)
      throw new NullPointerException();
    return new StreamResponse() {
      @Override
      public void prepareResponse(Response response) {
        try {
          if (fileName!=null)
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
          response.setContentLength(is.available());
        } catch (IOException e) {
          log.error("Could not stream", e);
        }
      }
      @Override
      public String getContentType() {
        return contentType;
      }
      @Override
      public InputStream getStream() throws IOException {
        return is;
      }
    };
  }

  public String getContextPath() {
    return request.getContextPath();
  }

  /** Called by tapestry pages to format user name */
  public String getName(BudgesUser b)
  {
    return b == null ? "" : Util.formatName(b);
  }

  /** Called by tapestry pages to format user name */
  public String getCreatorName(AuditableObject item)
  {
    BudgesUser b = item==null ? null : item.getCreatedByBudgesUser();
    if (b!=null) return Util.formatName(b);
    else return "";
  }

  /** Called by tapestry pages to format user name */
  public String getModifierName(AuditableObject item)
  {
    BudgesUser b = item==null ? null : item.getModifiedByBudgesUser();
    if (b!=null) return Util.formatName(b);
    else return "";
  }

  public String getStyleForGridRow(int index)
  {
    String color = (index%2) == 0 ? Constants.COLOR_WHITE_STYLE : Constants.COLOR_LIGHT_GRAY_STYLE;
    return color;
  }

  public String getUserId()
  {
    if (getCurrentBudgesUser() != null) {
      return getCurrentBudgesUser().getUserLdapId();
    }
    if (getP40User() != null) {
      return getP40User().getUserLdapId();
    }
    return "blowj2109";
  }

  protected boolean runOnlyVerifiedRules()
  {
    String email = "";
    if (getCurrentBudgesUser() != null)
      email = getCurrentBudgesUser().getEmail();
    if (getP40User() != null)
      email = getP40User().getEmail();
    boolean isUnverifiedForDticEnabled = !config.getP40OnlyRunVerifiedBusinessRules();
    if (isUnverifiedForDticEnabled && StringUtils.endsWith(email.toLowerCase(), "dtic.mil"))
      return false;
    return true;
  }
}
