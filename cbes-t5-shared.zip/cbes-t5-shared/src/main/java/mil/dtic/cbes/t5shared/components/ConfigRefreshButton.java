/*
 * $Id: PeList.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

/** Refresh the config using multiple trigger urls */
@Import(stack=CbesT5SharedModule.JQUERYSTACK, library={"classpath:${cb.assetpath}/js/log.js", "classpath:${cb.assetpath}/js/refresh.js"})
public class ConfigRefreshButton
{
  @Inject
  private JavaScriptSupport jsSupport;


  @SuppressWarnings("unused")
  @Parameter(defaultPrefix=BindingConstants.LITERAL, value="Refresh Config")
  @Property
  private String text;
  @Parameter(required=true)
  private JSONArray urls;
  @Property
  private String clientId;


  void setupRender()
  {
    clientId = jsSupport.allocateClientId("refresher");
  }

  void afterRender()
  {
    jsSupport.addScript("refresher('%s',%s)", clientId, urls.toCompactString());
  }
}
