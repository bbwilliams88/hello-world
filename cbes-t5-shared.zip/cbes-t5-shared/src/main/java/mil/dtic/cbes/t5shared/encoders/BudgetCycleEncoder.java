package mil.dtic.cbes.t5shared.encoders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;

import mil.dtic.utility.CbesLogFactory;


public class BudgetCycleEncoder implements ValueEncoder<BudgetCycle>
{
  private static final Logger log = CbesLogFactory.getLog(BudgetCycleEncoder.class);
  
  private final Map<String, BudgetCycle> budgetCycleMap = new HashMap<String, BudgetCycle>();

  public BudgetCycleEncoder(List<BudgetCycle> budgetCycles)
  {
    if (budgetCycles==null) throw new IllegalArgumentException();
    for (BudgetCycle bc : budgetCycles)
    {
      budgetCycleMap.put(bc.getValue(), bc);
    }
    log.debug("constructed");
  }


  public String toClient(BudgetCycle value)
  {
    return value.getValue();
  }


  public BudgetCycle toValue(String keyAsString)
  {
    log.debug("toValue " + keyAsString);
    return budgetCycleMap.get(keyAsString);
  }
}