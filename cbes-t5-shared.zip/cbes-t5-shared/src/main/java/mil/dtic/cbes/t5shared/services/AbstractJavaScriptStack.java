package mil.dtic.cbes.t5shared.services;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptStack;
import org.apache.tapestry5.services.javascript.StylesheetLink;

public abstract class AbstractJavaScriptStack implements JavaScriptStack
{
  private final Asset[] js;
  private final StylesheetLink[] css;
  
  public AbstractJavaScriptStack(AssetSource assetSource, SymbolSource symbolSource, String[] jspaths, String[] csspaths)
  {
    this.js = jspaths == null ? new Asset[0] : new Asset[jspaths.length];
    this.css = csspaths == null ? new StylesheetLink[0] : new StylesheetLink[csspaths.length];
    for (int i = 0; i < js.length; i++) {
      js[i] = getAsset(assetSource, symbolSource, jspaths[i]);
    }
    for (int i = 0; i < css.length; i++) {
      css[i] = new StylesheetLink(getAsset(assetSource, symbolSource, csspaths[i]));
    }
    
  }
  
  /**
   * <p>The constructor will call this to create the Asset objects.
   * <p>Override to have the constructor do {@link AssetSource#getContextAsset} or {@link AssetSource#getClasspathAsset}, etc.
   * @param symbolSource TODO
   */
  protected abstract Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path);
  
  public String getInitialization()
  {
    return null;
  }

  public List<Asset> getJavaScriptLibraries()
  {
    return Arrays.asList(js);
  }

  public List<StylesheetLink> getStylesheets()
  {
    return Arrays.asList(css);
  }

  public List<String> getStacks()
  {
    return Collections.emptyList();
  }
}
