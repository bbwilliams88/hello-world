package mil.dtic.cbes.t5shared.utils.wizard;


public abstract class BaseMjbWizardNavigation extends WizardNavigation
{
  public abstract boolean isP40();
  public abstract boolean isR2();
}
