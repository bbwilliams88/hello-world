package mil.dtic.cbes.t5shared.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.access.DataContext;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;

import mil.dtic.cbes.p40.vo.BudgetSubActivity;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.ServiceAgency;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.service.XmlFullValidationService;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.xml.XmlDocument;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;

public class UploadExhibitSelectionModel implements Serializable {

  /**
   *
   */

  private static final long serialVersionUID = 1L;
  private static final Logger log = CbesLogFactory.getLog(UploadExhibitSelectionModel.class);
  private List<ProgramElement> peList;
  private List<LineItem> liList;

  public UploadExhibitSelectionModel() {
    // TODO Auto-generated constructor stub
  }

  public List<ProgramElement> getProgramElements(){
    if (peList==null){
      peList = new ArrayList<ProgramElement>();
    }
    return peList;
  }

  public List<LineItem> getLineItems(){
    if (liList==null){
      liList = new ArrayList<LineItem>();
    }
    return liList;
  }

  public List<JSONObject> parseFileForNewItems(XmlDocument xd) {
    List<JSONObject> jsonObjs = new LinkedList<JSONObject>();
    R2ExhibitList r2List = xd.getR2ExhibitList();
    LineItemList p40List = xd.getLineItemList();

    if (r2List != null) {
      List <ProgramElement> list = r2List.getProgramElements();
      jsonObjs.addAll(getProgramElementsAsJson(list));
      getProgramElements().addAll(list);
    }
    else if(p40List != null) {
      List<LineItem> list = p40List.getLineItemsUnWrapped();
      jsonObjs.addAll(getLineItemsAsJson(list));
      getLineItems().addAll(list);
    }

   return jsonObjs;
  }

  public List<JSONObject> parseFileForNewItemsWithValidation(XmlDocument xd) {
    List<JSONObject> exhibits = parseFileForNewItems(xd);
    XmlFullValidationService xfvs = xd.validateBusinessRules();
    Map<String, List<String>> warnings = xfvs.getRulesWarningListMap();

    if(warnings == null) {
      return exhibits;
    }

    for(Map.Entry<String, List<String>> entry : warnings.entrySet()) {
      String k = entry.getKey();
      List<String> v = entry.getValue();
      if(k != null) {
        int splitPoint = k.lastIndexOf(".");
        int index = Integer.valueOf(k.substring(splitPoint + 1));
        String mapExhibitNum = k.substring(0, splitPoint);
        if(exhibits != null && exhibits.size() >= index) {
          JSONObject jsonExhibit = exhibits.get(index - 1);
          // make sure the exhibit numbers match
          if(jsonExhibit.has("exhibitNumber")) {
            String jsonExhibitNum = jsonExhibit.getString("exhibitNumber");
            if(StringUtils.equals(mapExhibitNum, jsonExhibitNum)) {
              JSONArray warningsJSON = new JSONArray();
              for(String warning : v) {
                warningsJSON.put(new JSONObject("message", warning));
              }
              jsonExhibit.put("warningMessages", warningsJSON);
              exhibits.set(index - 1, jsonExhibit);
            }
          }
        }
      }
    }

    return exhibits;
  }

  public List<JSONObject> getAllAsJson() {
    List<JSONObject> response = new LinkedList<JSONObject>();
    if(!CollectionUtils.isEmpty(peList)) {
      response.addAll(getProgramElementsAsJson(peList));
    }
    if(!CollectionUtils.isEmpty(liList)) {
      response.addAll(getLineItemsAsJson(liList));
    }
    return response;
  }

  private List<JSONObject> getLineItemsAsJson(List<LineItem> list){
    List<JSONObject> objs = new LinkedList<JSONObject>();
    for (LineItem li : list){
      objs.add(getLineItemAsJson(li));
    }
    return objs;
  }

  private JSONObject getLineItemAsJson(LineItem li) {
    JSONObject obj = new JSONObject();
    obj.put("exhibitType", "P40");
    obj.put("selectionType", "Upload");
    obj.put("number", li.getP1LineItemNumber());
    obj.put("exhibitNumber", li.getLineItemNumber());
    obj.put("title", li.getLineItemTitle());
    obj.put("serviceAgencyCode", li.getServiceAgency().getCode());
    obj.put("serviceAgencyName", li.getServiceAgency().getName());
    obj.put("budgetActivityNumber", li.getBudgetSubActivity().getNumber()).toString();
    obj.put("budgetActivityTitle", li.getBudgetSubActivity().getTitle());
    obj.put("budgetCycle", li.getBudgetCycle());
    obj.put("budgetYear", li.getBudgetYear().toString());
    return obj;
  }

  private List<JSONObject> getProgramElementsAsJson(List<ProgramElement> list){
    List<JSONObject> objs = new LinkedList<JSONObject>();
    for (ProgramElement pe : list){
      objs.add(getProgramElementAsJson(pe));
    }
    return objs;
  }

  private JSONObject getProgramElementAsJson(ProgramElement pe) {
    JSONObject obj = new JSONObject();
    obj.put("exhibitType", "R2");
    obj.put("selectionType", "Upload");
    obj.put("number", pe.getR1LineNumber());
    obj.put("exhibitNumber", pe.getNumber());
    obj.put("title", pe.getTitle());
    obj.put("serviceAgencyCode", pe.getServiceAgency().getCode());
    obj.put("serviceAgencyName", pe.getServiceAgency().getName());
    obj.put("budgetActivityNumber", pe.getBudgetActivity().getNumber().toString());
    obj.put("budgetActivityTitle", pe.getBudgetActivity().getTitle());
    obj.put("budgetCycle", pe.getBudgetCycle());
    obj.put("budgetYear", pe.getBudgetYear().toString());
    return obj;
  }

  public void removeP40UploadedItem(String lineItemTitle, String lineItemNumber, int budgetYear, String budgetCycle, String serviceAgencyCode, String bsaNumber, String bsaTitle){
    DataContext dc = CayenneUtils.createDataContext();

    LineItem lineItemTarget = dc.newObject(LineItem.class);

    lineItemTarget.setLineItemTitle(lineItemTitle);
    lineItemTarget.setLineItemNumber(lineItemNumber);

     mil.dtic.cbes.p40.vo.ServiceAgency sa = ServiceAgency.fetchWithCode(dc, serviceAgencyCode);
     lineItemTarget.setServiceAgency(sa);

     BudgetSubActivity bsa = dc.newObject(BudgetSubActivity.class);
     if (StringUtils.isNotEmpty(bsaNumber)){
       bsa.setNumber(new Short(bsaNumber));
     }
     bsa.setTitle(bsaTitle);
     lineItemTarget.setBudgetSubActivity(bsa);
     lineItemTarget.setBudgetCycle(budgetCycle);
     lineItemTarget.setBudgetYear(Integer.valueOf(budgetYear));

    for (LineItem li : liList){
      if (li.equivalentTo(lineItemTarget)){
        liList.remove(li);
        break;
      }
    }
  }

  public void removeR2UploadedItem(String peNumber, int budgetYear, String budgetCycle, Date submissionDate, String serviceAgencyCode, String budgetActivityNumber, String budgetActivityTitle){

  for (ProgramElement pe : peList){
    String peAgencyCode = "";
    if (pe.getServiceAgency()!=null){
      peAgencyCode = pe.getServiceAgency().getCode();
    }
    Short peBudgetActivityNumber = null;
    String peBudgetActivityTitle = "";
    if (pe.getBudgetActivity()!=null){
      peBudgetActivityNumber = pe.getBudgetActivity().getNumber();
      peBudgetActivityTitle = pe.getBudgetActivity().getTitle();
    }
    if (StringUtils.equals(peNumber, pe.getNumber()) &&
        budgetYear==pe.getBudgetYear().intValue() &&
        StringUtils.equals(budgetCycle, pe.getBudgetCycle()) &&
        StringUtils.equals(serviceAgencyCode, peAgencyCode) &&
        peBudgetActivityNumber != null  &&
        peBudgetActivityNumber.equals(Short.valueOf(budgetActivityNumber)) &&
        StringUtils.equals(budgetActivityTitle, peBudgetActivityTitle)){
      peList.remove(pe);
    }
  }
}

  public void resetLists(){
    if (liList!=null){
      liList.clear();
    }
    if (peList!=null){
      peList.clear();
    }
  }

}
