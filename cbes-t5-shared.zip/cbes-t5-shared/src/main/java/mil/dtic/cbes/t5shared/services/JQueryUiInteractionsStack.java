package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class JQueryUiInteractionsStack extends AbstractJavaScriptStack
{
  public JQueryUiInteractionsStack(AssetSource assetSource, SymbolSource symbolSource)
  {
    super(assetSource, 
      symbolSource,
      new String[] {},
      new String[] {});
  }

  @Override
  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(path, null);
  }

  @Override
  public List<String> getStacks()
  {
    return Collections.singletonList(CbesT5SharedModule.JQUICORESTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
