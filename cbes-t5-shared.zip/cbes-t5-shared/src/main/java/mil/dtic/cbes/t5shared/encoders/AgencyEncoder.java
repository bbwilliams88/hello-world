package mil.dtic.cbes.t5shared.encoders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.utility.CbesLogFactory;

public class AgencyEncoder implements ValueEncoder<ServiceAgency>
{
  private static final Logger log = CbesLogFactory.getLog(AgencyEncoder.class);
  
  private final Map<String, ServiceAgency> agencyMap = new HashMap<String, ServiceAgency>();

  public AgencyEncoder(List<ServiceAgency> agencies)
  {
    if (agencies==null) throw new IllegalArgumentException();
    for (ServiceAgency sa : agencies)
    {
      agencyMap.put(sa.getCode(), sa);
    }
    log.debug("constructed");
  }


  public String toClient(ServiceAgency value)
  {
    return value.getCode();
  }


  public ServiceAgency toValue(String keyAsString)
  {
    log.debug("toValue " + keyAsString);
    return agencyMap.get(keyAsString);
  }
}