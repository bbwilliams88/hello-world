package mil.dtic.cbes.t5shared.components.mjb;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.utility.CbesLogFactory;

public class LogoImage extends T5JBBase {
    private static final String IMGEVENT = "selectedImage";
    public static final String NO_IMAGE = "dodgeneric-logo.png"; 

    private static final Logger log = CbesLogFactory.getLog(LogoImage.class);
    @Inject
    private ComponentResources componentResources;

    @Inject
    private ConfigService config;

    @Property
    @Parameter(required = false)
    private File file;

    @Property
    @Parameter(required = true)
    private ServiceAgency agency;

    @Property
    @Parameter(defaultPrefix=BindingConstants.LITERAL, value="200px")
    private String maxHeight, maxWidth;

    @OnEvent(value = IMGEVENT)
    StreamResponse onSelectedImage() throws IOException{
        log.trace("onSelectedImage: start");
        File streamthis;
        
        if (agency==null) { 
            return null;
        }

        if (file !=null && file.exists() && file.isFile()){
            log.trace("onSelectedImage - image exists at: " + file.getPath());
            streamthis = file;
        }
        else {
            log.trace("onSelectedImage: using " + LogoImage.NO_IMAGE + " as default global image: ");
            file = getDefaultLogoFile(); 
            if (null != file && file.exists()){
                streamthis = getDefaultLogoFile();    
            }
            else {
              log.error("onSelectedImage: No logo file found! (MJB processing) AppAdmin must manually add " 
                      + LogoImage.NO_IMAGE + " to \\d2\\webfiles\\r2\\logos\\ folder");  
              return null;
            }
        }
        
        String mimeType = URLConnection.getFileNameMap().getContentTypeFor(streamthis.getName());
        log.trace("onSelectedImage: returning stream response with mimeType: " + mimeType);
        return getStreamResponse(FileUtils.openInputStream(streamthis), mimeType, null);
    }

    public Object getSelectedImage(){
        return componentResources.createEventLink(IMGEVENT, UUID.randomUUID().toString());
    }

    private File getDefaultLogoFile(){
        File imageFile = null;
        String logosDir = config.getLogoImagesFolder();
        log.trace("getDefaultLogoFile: logosDir: " + logosDir);
        
        if (null == logosDir) {
            return null;
        }
        
        if (null == agency || null == agency.getLogoFileName()){
            imageFile = new File(logosDir, LogoImage.NO_IMAGE);
        }
        else {
            imageFile = new File(logosDir, agency.getLogoFileName()) ;
            if (!imageFile.isFile()) { 
                log.trace("getDefaultLogoFile: imageFile is not a file, defaulting to: " + LogoImage.NO_IMAGE);
                imageFile = new File(logosDir, LogoImage.NO_IMAGE);
            }
        }
        
        return imageFile;
        
    }
}
