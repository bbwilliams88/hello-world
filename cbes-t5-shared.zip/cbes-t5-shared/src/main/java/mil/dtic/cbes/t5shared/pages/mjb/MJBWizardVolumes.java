package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
//import mil.dtic.utility.specialcategory.api.service.SpecialCategoryService;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.utility.CbesLogFactory;


/**
 * Volumes wizard page for Master Justification Book.
 */
public class MJBWizardVolumes extends MJBWizardPage
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardVolumes.class);

  @Property
  private MJBVolumeModel currentvol;
  
  @Property
  private String jbWizSingleVolumesHelp;
  
  @Property
  private String jbWizMultiVolumesHelp;

  @Inject
  private JavaScriptSupport jsSupport;
  
  @Log
  Object onActivate() throws IOException {
    Object obj = super.onActivate();
    
    jbWizSingleVolumesHelp = config.getJbWizSingleVolumesHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    jbWizMultiVolumesHelp = config.getJbWizMultiVolumesHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    
    return obj;
  }
  @Log
  void afterRender(){
    jsSupport.addScript("jQuery('#addrowlink').click( function(){setTimeout(volumesDeleteUpdater,300);});");
    jsSupport.addScript("volumesDeleteUpdater();");
  }

  @Log
  MJBVolumeModel onAddRowFromVolumes() {
    if (getJBFormData().getVolumes().size() == 1) {
      log.debug("Going from single-volume to multi-volume - Toggling TOC/master TOC defaults on existing vol");
      
      for(MJBVolumeModel v : getJBFormData().getVolumes()) {
        if(navigation.isR2()) {
          v.getDaOptions().setGenerateProgramElementTocByBA(false);
          v.getDaOptions().setGenerateProgramElementTocByTitle(false);
          v.getDaOptions().setIncludeMasterProgramElementTocByBA(true);
          v.getDaOptions().setIncludeMasterProgramElementTocByTitle(true);
        }
        if(navigation.isP40()) {
          v.getDaOptions().setGenerateLineItemTocByBA(false);
          v.getDaOptions().setGenerateLineItemTocByTitle(false);
          v.getDaOptions().setIncludeMasterLineItemTocByBA(true);
          v.getDaOptions().setIncludeMasterLineItemTocByTitle(true);
        }
      }
    }
    
    MJBVolumeModel m;
    ServiceAgency sa = getJBFormData().getServiceAgency();

    //CXE-5873
    if(null != sa && isDodService(sa.getCode())){
        m = new MJBVolumeModel();
    }
    else {
        m = getJBFormData().newVolumeForAgency(sa);
    }

    if (m == null) { //the DEMO agencies
        m = new MJBVolumeModel();
    }

    m.getDaOptions().setIncludeTov(true);   
    
    if(navigation.isR2()) {
       if(getJBFormData().getVolumes().size() > 0){
            m.getDaOptions().setGenerateProgramElementTocByBA(false);
            m.getDaOptions().setGenerateProgramElementTocByTitle(false);
            m.getDaOptions().setIncludeMasterProgramElementTocByBA(true);
            m.getDaOptions().setIncludeMasterProgramElementTocByTitle(true);        
      }
      else {        
           m.getDaOptions().setGenerateProgramElementTocByBA(true);
           m.getDaOptions().setGenerateProgramElementTocByTitle(true);
           m.getDaOptions().setIncludeMasterProgramElementTocByBA(false);
           m.getDaOptions().setIncludeMasterProgramElementTocByTitle(false);        
      }
    }
    
    if(navigation.isP40()) {
      
      if(getJBFormData().getVolumes().size() > 0) {
        m.getDaOptions().setGenerateLineItemTocByBA(false);
        m.getDaOptions().setGenerateLineItemTocByTitle(false);
        m.getDaOptions().setIncludeMasterLineItemTocByBA(true);
        m.getDaOptions().setIncludeMasterLineItemTocByTitle(true);        
      }
      else {        
        m.getDaOptions().setGenerateLineItemTocByBA(true);
        m.getDaOptions().setGenerateLineItemTocByTitle(true);
        m.getDaOptions().setIncludeMasterLineItemTocByBA(false);
        m.getDaOptions().setIncludeMasterLineItemTocByTitle(false);        
      }
    }

    getJBFormData().getVolumes().add(m);
    return m;
  }

  @Log
  void onRemoveRowFromVolumes(MJBVolumeModel volume)
  {
    if (getJBFormData().getVolumes().size()<=1)
    {
      log.debug("******** Last Volume - don't delete");
      return;
    }
    
    getJBFormData().getVolumes().remove(volume);
    
    if (getJBFormData().getVolumes().size() == 1) {
      
      log.debug("Going from multi-volume to single-volume - Toggling TOC/master TOC defaults on remaining vol");
      
      for(MJBVolumeModel v : getJBFormData().getVolumes()) {
        if(navigation.isR2()) {
          v.getDaOptions().setGenerateProgramElementTocByBA(true);
          v.getDaOptions().setGenerateProgramElementTocByTitle(true);
          v.getDaOptions().setIncludeMasterProgramElementTocByBA(false);
          v.getDaOptions().setIncludeMasterProgramElementTocByTitle(false);
        }
        if(navigation.isP40()) {
          v.getDaOptions().setGenerateLineItemTocByBA(true);
          v.getDaOptions().setGenerateLineItemTocByTitle(true);
          v.getDaOptions().setIncludeMasterLineItemTocByBA(false);
          v.getDaOptions().setIncludeMasterLineItemTocByTitle(false);
        }
      }
    }
  }


  @Override
  public void validate()
  {
    log.debug("Validating Volumes");
    if(currentvol != null && currentvol.getSubVolume() != null) 
    {      
      if(!StringUtils.isAlpha(currentvol.getSubVolume()))
      {
        addErrorMessage("Volume Suffix can only contain letters.");        
      }
    }
    if(currentvol != null && currentvol.getSuperVolume() != null) 
    {      
      // Ensure volume number is within XML schema defined character length limit
      if(currentvol.getSuperVolume().length() > 10)
      {
        addErrorMessage("Volume Number can be at most ten characters.");        
      }
    }

    if (CollectionUtils.isEmpty(getJBFormData().getVolumes()))
    {
      addErrorMessage("You must have at least one volume.");
    }
    else
    {
      Map<String, Object> uniquenessMap = new HashMap<String, Object>();

      for (MJBVolumeModel v : getJBFormData().getVolumes())
      {
        String vnumber = v.getSuperVolumeSubVolumeNumber();

        //while we have the new 'volume number' might as well put it into the final base field
        v.setNumber(vnumber);

        if (uniquenessMap.get(vnumber.toLowerCase()) != null)
          addErrorMessage("Volume number/Sub numbers should be unique. You have a repeating one, " + vnumber + ".");
        else
          uniquenessMap.put(vnumber.toLowerCase(), new Object());
      }
    }
  }


  public boolean isShowVolumeSuffixEnabled()
  {
    return getNavigation().isP40() || isDodServiceOrDodBigAgency();
  }

  public boolean isVolumeDescEditEnabled(){
      return getNavigation().isP40() || isDodService(getJBFormData().getServiceAgency().getCode());
  }

  public boolean isVolumeNumberEditEnabled(){
      return getNavigation().isP40() || isDodService(getJBFormData().getServiceAgency().getCode());
  }

  public boolean isAddVolumeEnabled()  {
    return getNavigation().isP40() || isDodServiceOrDodBigAgency();
  }
  
  public boolean isIncludeTovDisabled() {
    return !(isDodServiceOrDodBigAgency());
  }
  
}
