package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;

import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;



/**
 * Break the R2s into volumes
 */
@Import(
  stack=CbesT5SharedModule.JQUERYSTACK,
    library={
    "classpath:${cb.assetpath}/js/json2.js",
    "classpath:${cb.assetpath}/js/jquery.pfSelect.js",
    "classpath:${cb.assetpath}/js/jquery.sortElements.js",
    "classpath:${cb.assetpath}/js/libreakdown.js"
  },
  stylesheet="classpath:${cb.assetpath}/css/libreakdown.css")
public class MJBWizardPeBreakdown extends MJBWizardPage
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardPeBreakdown.class);
  
  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private HttpServletRequest request;

  @Property
  private MJBVolumeModel currentvol;
  @SuppressWarnings("unused")
  @Property
  private ProgramElement pe;  
  @Property
  private String jbWizSingleVolumeBreakdownHelp;
  @Property
  private String jbWizR2MultiVolumeBreakdownHelp;


  void afterRender()
  {
    jsSupport.addScript("initTables('%s');", resources.createEventLink("moveRows"));
  }
  
  Object onActivate() throws IOException
  {
    Object obj = super.onActivate();
    
    jbWizSingleVolumeBreakdownHelp = config.getJbWizSingleVolumeBreakdownHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    jbWizR2MultiVolumeBreakdownHelp = config.getJbWizR2MultiVolumeBreakdownHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    
    return obj;    
  }

  void onMoveRows()
  {
    log.debug("onMoveRows " + request.getParameter("rowids") + " " + request.getParameter("volid"));
    final List<Object> rowids = Lists.newArrayList(new JSONArray(request.getParameter("rowids")));
    String volumeid = request.getParameter("volid");
    List<ProgramElement> toBeMoved = new ArrayList<ProgramElement>(rowids.size());
    MJBVolumeModel destVolume = null;
    //first gather the rows from the other volumes
    for (MJBVolumeModel volume : getVolumes())
    {
      if (!volumeid.equals(volume.getT5Id()))
      {
        toBeMoved.addAll(Collections2.filter(volume.getProgramElements(), new Predicate<ProgramElement>()
         {
           public boolean apply(ProgramElement input)
           {
             return rowids.contains(input.getT5Id());
           }
         }
        ));
        volume.getProgramElements().removeAll(toBeMoved);
      }
      else
      {
        destVolume = volume;
      }
    }
    
    //now move them to dest
    if (destVolume != null)
    {
      destVolume.getProgramElements().addAll(toBeMoved);
      sortPes(destVolume.getProgramElements());
    }
    else
    {
      throw new IllegalArgumentException("destVolume not found");
    }
  }


  public List<MJBVolumeModel> getVolumes()
  {
    return getJBFormData().getVolumes();
  }

  public List<ProgramElement> getCurrentProgramElements()
  {
    return currentvol.getProgramElements();
  }


//  public String getCurrentUuid()
//  {
//    if (pe.getT5Id() == null)
//      pe.setT5Id(UUID.randomUUID().toString());
//    return pe.getT5Id();
//  }
}
