/*
 * $Id: R2EventButton.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components.mjb;

import java.io.File;

import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.TextField;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.utility.PdfUtil;

public class MJBFileRow
{
  @Inject
  private Messages messages;
  
  @SuppressWarnings("unused")
  @Parameter(required=true,defaultPrefix="literal") @Property
  private String titleTitle;
  
  @Parameter(required=true,defaultPrefix="literal") @Property
  private String fileTitle;
  
  @SuppressWarnings("unused")
  @Parameter(required=true)
  @Property
  private String title;
  
  @SuppressWarnings("unused")
  @Parameter(required=true) @Property
  private File file;
  
  @SuppressWarnings("unused")
  @Parameter(required=true) @Property
  private File workingDir;
  
  @SuppressWarnings("unused")
  @Parameter @Property
  private boolean uploadClicked;
  
  @SuppressWarnings("unused")
  @Parameter @Property
  private String savedFilename;
  
  @Parameter
  private SavedUploadValidator filevalidator;

  @SuppressWarnings("unused")
  @Component(publishParameters="annotationProvider,clientId,disabled,label,nulls,translate,validate,value", inheritInformalParameters=true)
  private TextField titleTextField;
  
  @SuppressWarnings("unused")
  @Component(publishParameters="originalName,showSaved", inheritInformalParameters=true)
  private SavedUpload savedUpload;
  
  @Log
  void onSelectedFromUpload()
  {
    uploadClicked = true;
  }
  
  public SavedUploadValidator getFileValidator()
  {
    if (filevalidator!=null) return filevalidator;
    return getPdfFileValidator(fileTitle);
  }
  
  private SavedUploadValidator getPdfFileValidator(final String label)
  {
    return new FileExtensionSavedUploadValidator("", BudgesContentType.PDF)
    {
      @Override
      public void validateFilename(String filename) throws ValidationException
      {
        if (!isValid(filename))
          throw new ValidationException(messages.format("pdfattach-bad-ext", label, filename));
      }
      @Override
      public void validateFile(File f, String originalName) throws ValidationException
      {
        if (!PdfUtil.isPdf(f))
        {
          throw new ValidationException(messages.format("pdfattach-bad", label, originalName));
        }
        if (PdfUtil.isSecured(f))
        {
          throw new ValidationException(messages.format("pdfattach-bad-sec", label, originalName));
        }
      }
    };
  }
}
