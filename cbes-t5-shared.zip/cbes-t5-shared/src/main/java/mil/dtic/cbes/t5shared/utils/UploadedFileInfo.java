package mil.dtic.cbes.t5shared.utils;

import java.io.File;
import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.apache.tapestry5.upload.services.UploadedFile;

import mil.dtic.utility.attachment.RandomStringGenerator;


public class UploadedFileInfo implements Serializable 
{
  private static final long serialVersionUID = 1L;

  private final String contentType;
  private final String fileName;
  private final long size;

  public UploadedFileInfo(UploadedFile ufile) {
    this.contentType = ufile.getContentType();
    this.fileName = ufile.getFileName();
    this.size = ufile.getSize();
  }
  
  // this doesn't change the name of the file.  We can make changes on the backend, but not here.
//  public UploadedFileInfo(UploadedFile ufile, String agency) {
//    String fstr = ufile.getFileName();
//    StringBuffer sb = new StringBuffer(fstr);
//    this.fileName = sb.insert(fstr.lastIndexOf("."), "_" + agency).toString();
//    this.size = ufile.getSize();
//    this.contentType = ufile.getContentType();
//  }

  public UploadedFileInfo(File file) {
    this.contentType = null;
    this.fileName = file.getName();
    this.size = file.length();
  }
  
  public UploadedFileInfo(File file, String agency) {
    this.fileName = createFilenameWithAgency(file.getName(), agency);
    this.size = file.length();
    this.contentType = null;
  }
  
  public String getContentType(){
    return contentType;
  }

  public String getFileName() {
    return fileName;
  }

  public long getSize() {
    return size;
  }
  
  // I don't think we want to change the name of the file info here. You'll end up scanning more files that you need to if you do this. 
  private String createFilenameWithAgency(String uploadedFilename, String agencyCode){
    StringBuilder stringBuilder = new StringBuilder(uploadedFilename);
    return (uploadedFilename.contains(".") ? stringBuilder.insert(uploadedFilename.indexOf("."), agencyCode).toString() : StringUtils.EMPTY);
  }
}
