package mil.dtic.cbes.t5shared.services;
 
import javax.inject.Inject;
 
import org.apache.tapestry5.ioc.annotations.ServiceId;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
 
@ServiceId("AuthenticationManager")
public class CustomAuthenticationManager implements AuthenticationManager{
    @Inject
    private UserDetailsService userDetailsService;
 
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        if (userDetailsService == null) throw new AuthenticationServiceException("Config service is null. Cannot authenticate now.");
        if (authentication == null) throw new AuthenticationCredentialsNotFoundException("Provided authentication is null.");
 
        UserDetails userDetails = userDetailsService.loadUserByUsername(authentication.getName());
 
        if (userDetails == null || !userDetails.isEnabled()) throw new UsernameNotFoundException("Could not find Ldap User ID.");
 
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(userDetails, authentication.getCredentials(), userDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(token);
        return token;
    }
}