package mil.dtic.cbes.t5shared.services;

import java.io.IOException;

import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.RequestFilter;
import org.apache.tapestry5.services.RequestHandler;
import org.apache.tapestry5.services.Response;

/**
 * Sets request header to disable IE compatibility mode in IE8
 * @author rzinger
 */
public class IEStandardModeHeader implements RequestFilter
{
  @Override
  public boolean service(Request request, Response response, RequestHandler handler) throws IOException
  {
    response.setHeader("X-UA-Compatible", "IE=edge");
    return handler.service(request, response);
  }
}
