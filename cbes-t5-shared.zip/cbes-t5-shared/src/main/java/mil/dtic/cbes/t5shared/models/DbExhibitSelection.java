package mil.dtic.cbes.t5shared.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.utility.CayenneUtils;

/**
 * A cache of Line Item and/or Program Element selections (such as when building
 * a J-Book) which are preserved in the user's session.
 */
public class DbExhibitSelection implements Serializable
{
    private static final long serialVersionUID = 1L;

    private static final int ONE_MINUTE = 1000 * 60 * 1; // 1000ms * 60s * 1m.

    private List<LineItem>       lineItems       = new ArrayList<LineItem>();
    private List<ProgramElement> programElements = new ArrayList<ProgramElement>();

    private Date lineItemRefreshTime;
    private Date programElementRefreshTime;

    /**
     * Clear all Line Items and reset the cache timer.
     */
    public void clearLineItems()
    {
        lineItems           = new ArrayList<LineItem>();
        lineItemRefreshTime = null;
    }

    /**
     * Refresh the cache of Line Items with fresh data (picking up any changes
     * to Line Items in the database) and set the timer to the time of the
     * refresh.
     */
    public void refreshLineItems()
    {
        lineItems           = LineItem.fetchWithIds(CayenneUtils.createDataContext(), getLineItemPKs());
        lineItemRefreshTime = new Date();
    }

    /**
     * @return The cached list of Line Items, refreshing with fresh data if they
     *         are "old".
     */
    public List<LineItem> getLineItems()
    {
        // If the cache is stale, refresh.
        if (lineItemRefreshTime == null || System.currentTimeMillis() - lineItemRefreshTime.getTime() > ONE_MINUTE)
            refreshLineItems();

        return lineItems;
    }

    /**
     * Sets the cache of Line Items to the given list and updates the refresh timer.
     *
     * @param lineItems The new Line Items to cache.
     */
    public void setLineItems(List<LineItem> lineItems)
    {
        this.lineItems           = lineItems == null ? new ArrayList<LineItem>() : lineItems;
        this.lineItemRefreshTime = new Date();
    }

    /**
     * @return The number of Line Items cached (does NOT trip the refresh
     *         timer).
     */
    public int getNumberOfLineItems()
    {
        return lineItems.size();
    }

    /**
     * @return The primary keys of all cached Line Items (does NOT trip the
     *         refresh timer).
     */
    public List<Integer> getLineItemPKs()
    {
        return CayenneUtils.pksForObjects(lineItems);
    }

    /**
     * Clear all Program Elements and reset the cache timer.
     */
    public void clearProgramElements()
    {
        programElements     = new ArrayList<ProgramElement>();
        programElementRefreshTime = null;
    }

    /**
     * Refresh the cache of Program Elements with fresh data (picking up any
     * changes to Program Elements in the database) and set the timer to the
     * time of the refresh.
     */
    private void refreshProgramElements()
    {
        // FIXME: Do something...
    }

    /**
     * @return The cached list of Program Elements, refreshing with fresh data
     *         if they are "old".
     */
    public List<ProgramElement> getProgramElements()
    {
        // If the cache is stale, refresh.
        if (programElementRefreshTime == null || System.currentTimeMillis() - programElementRefreshTime.getTime() > ONE_MINUTE)
            refreshProgramElements();

        return programElements;
    }

    /**
     * Sets the cache of Program Elements to the given list and updates the refresh timer.
     *
     * @param lineItems The new Program Elements to cache.
     */
    public void setProgramElements(List<ProgramElement> programElements)
    {
        this.programElements           = programElements == null ? new ArrayList<ProgramElement>() : programElements;
        this.programElementRefreshTime = null;
    }

    /**
     * @return The number of Program Elements cached (does NOT trip the refresh
     *         timer).
     */
    public int getNumberOfProgramElements()
    {
        return programElements.size();
    }

    /**
     * @return The primary keys of all cached Program Elements (does NOT trip
     *         the refresh timer).
     */
//    public List<Integer> getProgramElementPKs()
//    {
//        return CayenneUtil.pksForObjects(programElements);
//    }
    
    public void addToProgramElementList(List<ProgramElement> pes){
      if (programElements==null){
        programElements = new ArrayList<ProgramElement>();
      }
      programElements.addAll(pes);
    }
    
    public void addToLineItemList(List<LineItem>lis){
      if (lineItems==null){
        lineItems = new ArrayList<LineItem>();
      }
      lineItems.addAll(lis);
    }
}
