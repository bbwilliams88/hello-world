package mil.dtic.cbes.t5shared.encoders;

import java.util.List;
import java.util.UUID;

import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.p40.vo.IBase;

/**
 * A Tapestry 5 ValueEncoder designed to handle Lists of objects that implement
 * the IBase interface. This encoder does an O(n) search on the list of objects
 * using the getT5Id() method to map objects.
 */
public class ListUUIDEncoder<T extends IBase> implements ValueEncoder<T>
{
    private final List<T> list;

    public ListUUIDEncoder(List<T> list)
    {
        this.list = list;
    }

    /**
     * Returns the client value of the object (via getT5Id() defined in the
     * IBase interface), optionally creating a missing T5 ID. Tapestry uses this
     * value to store in the HTML to identify the object.
     *
     * @see org.apache.tapestry5.ValueEncoder#toClient(java.lang.Object)
     */
    public String toClient(T value)
    {
        // If missing a T5 ID, create it.
        if (value.getT5Id() == null)
            value.setT5Id(UUID.randomUUID().toString());

        return value.getT5Id();
    }

    /**
     * Returns the object that matches the given key in the List of objects
     * supplied in the constructor. The key was produced by the toClient()
     * method. Tapestry uses this method to match the correct object to push
     * form values on a submit.
     *
     * @see org.apache.tapestry5.ValueEncoder#toValue(java.lang.String)
     */
    public T toValue(String key)
    {
        // Loop over the list trying to find the matching object via the key.
        for (T targetObject : list)
            if (key.equals(targetObject.getT5Id()))
                return targetObject;

        throw new IllegalArgumentException(key + " not found in list.");
    }
}
