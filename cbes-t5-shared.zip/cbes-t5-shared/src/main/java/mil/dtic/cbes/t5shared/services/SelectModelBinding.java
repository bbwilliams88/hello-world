package mil.dtic.cbes.t5shared.services;

import java.lang.annotation.Annotation;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.apache.tapestry5.PropertyConduit;
import org.apache.tapestry5.SelectModel;
import org.apache.tapestry5.internal.bindings.AbstractBinding;
import org.apache.tapestry5.ioc.Location;
import org.apache.tapestry5.services.SelectModelFactory;

public class SelectModelBinding extends AbstractBinding
{
  private final SelectModelFactory selectModelFactory;
  private final Object root;
  private final PropertyConduit conduit;
  private final String labelProperty;
  private final String toString;


  public SelectModelBinding(final Location location, final SelectModelFactory selectModelFactory, final Object root,
    final PropertyConduit conduit, final String labelProperty, final String toString)
  {
    super(location);
    this.selectModelFactory = selectModelFactory;
    this.root = root;
    this.conduit = conduit;
    this.labelProperty = labelProperty;
    this.toString = toString;
  }

  @Override
public Object get()
  {
      Iterable<?> iterable = (Iterable<?>)conduit.get(root);
      List<?> l = iterable instanceof List ? (List<?>)iterable : IteratorUtils.toList(iterable.iterator());
      return selectModelFactory.create(l, labelProperty);
  }

  @Override
public void set(Object value)
  {
    throw new UnsupportedOperationException();
  }

  @Override
public Class<?> getBindingType()
  {
    return SelectModel.class;
  }


  @Override
public boolean isInvariant()
  {
    return true;
  }

  @Override
public <A extends Annotation> A getAnnotation(Class<A> annotationClass)
  {
    return null;
  }

  @Override
  public String toString()
  {
    return toString;
  }
}