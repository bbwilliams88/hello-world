
package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.internal.URLEventContext;
import org.apache.tapestry5.internal.services.ComponentEventLinkEncoderImpl;
import org.apache.tapestry5.internal.services.RequestSecurityManager;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.Symbol;
import org.apache.tapestry5.services.BaseURLSource;
import org.apache.tapestry5.services.ComponentClassResolver;
import org.apache.tapestry5.services.ComponentEventRequestParameters;
import org.apache.tapestry5.services.ContextPathEncoder;
import org.apache.tapestry5.services.ContextValueEncoder;
import org.apache.tapestry5.services.LocalizationSetter;
import org.apache.tapestry5.services.MetaDataLocator;
import org.apache.tapestry5.services.PersistentLocale;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.Response;
import org.apache.tapestry5.services.security.ClientWhitelist;

/**
 * Pull event parameters from post requests and pass them as parameters to event handlers.
 */
public class PostedComponentEventLinkEncoder extends ComponentEventLinkEncoderImpl
{
  //  private static final Logger log = CbesLogFactory.getLog(PostedComponentEventLinkEncoder.class);
  @Inject
  private ContextValueEncoder contextValueEncoder;


  public PostedComponentEventLinkEncoder(ComponentClassResolver componentClassResolver,
    ContextPathEncoder contextPathEncoder, LocalizationSetter localizationSetter,
    Response response, RequestSecurityManager requestSecurityManager, BaseURLSource baseURLSource,
    PersistentLocale persistentLocale,
    @Symbol(SymbolConstants.ENCODE_LOCALE_INTO_PATH)
    boolean encodeLocaleIntoPath,
    @Symbol(SymbolConstants.CONTEXT_PATH)
    String contextPath,
    @Symbol(SymbolConstants.APPLICATION_FOLDER) String applicationFolder,
    MetaDataLocator metaDataLocator,
    ClientWhitelist clientWhitelist)
  {
    super(componentClassResolver, contextPathEncoder, localizationSetter,
      response, requestSecurityManager, baseURLSource,
      persistentLocale, encodeLocaleIntoPath, contextPath, applicationFolder,
      metaDataLocator, clientWhitelist);
  }

  public ComponentEventRequestParameters decodeComponentEventRequest(Request request)
  {
    ComponentEventRequestParameters cerp = super.decodeComponentEventRequest(request);
    if (cerp != null && request != null && StringUtils.equals(request.getMethod(), "POST") && cerp.getEventContext().getCount() == 0) {
      // replace URLEventContext with parameters from post request
      List<String> parameters = new ArrayList<String>(request.getParameterNames().size());
      for (String name : request.getParameterNames()) {
        parameters.add(request.getParameter(name));
      }
      return new ComponentEventRequestParameters(
        cerp.getActivePageName(), cerp.getContainingPageName(), cerp.getNestedComponentId(),
        cerp.getEventType(), cerp.getPageActivationContext(),
        new URLEventContext(contextValueEncoder, parameters.toArray(new String[0])));
    } else {
      return cerp;
    }
  }
}
