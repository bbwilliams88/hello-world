package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;

import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;


/**
 * Table of contents wizard page for Master Justification Book.
 */
public class MJBWizardTableOfContents extends MJBWizardPage
{  
    @Property
    private MJBVolumeModel currentvol;
        
    @Property
    private boolean disableGenerateP1R1;

    @Property
    private String jbWizTableOfContentsHelp;
    
    Object onActivate() throws IOException {
      
      Object obj = super.onActivate();
      
      disableGenerateP1R1 = false;
      
      boolean generateRequired = config.isJbWizGenerateP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      boolean attachRequired = config.isJbWizAttachP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());      
      
      if(generateRequired) {
        disableGenerateP1R1 = true;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          
            vol.getDaOptions().setGenerateR1(true);
            
            if(mfdata.getVolumes().size() > 1) 
            {
              vol.getDaOptions().setIncludeMasterR1(true);
              if(isDodServiceOrDodBigAgency()) { // already true by default, but force true if master TOC checkboxes are disabled
                vol.getDaOptions().setIncludeMasterProgramElementTocByBA(true);
                vol.getDaOptions().setIncludeMasterProgramElementTocByTitle(true);
              }
            }
        }
      }
      if(attachRequired) {
        disableGenerateP1R1 = true;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          
          vol.getDaOptions().setGenerateR1(false);
          
          if(mfdata.getVolumes().size() > 1) 
          {
            vol.getDaOptions().setIncludeMasterR1(false);
            if(isDodServiceOrDodBigAgency()) { 
              vol.getDaOptions().setIncludeMasterProgramElementTocByBA(true);
              vol.getDaOptions().setIncludeMasterProgramElementTocByTitle(true);
            }
          }
        }
      }
      if(!attachRequired && !generateRequired) {
        disableGenerateP1R1 = false;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          
          vol.getDaOptions().setGenerateR1(true);     
          
          if(mfdata.getVolumes().size() > 1) 
          {
            vol.getDaOptions().setIncludeMasterR1(true);
            if(isDodServiceOrDodBigAgency()) { 
              vol.getDaOptions().setIncludeMasterProgramElementTocByBA(true);
              vol.getDaOptions().setIncludeMasterProgramElementTocByTitle(true);        
            }
          }
        }
      }      
      
      jbWizTableOfContentsHelp = config.getJbWizR2TableOfContentsHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      
      return obj;
    }
    
    public boolean isIncludeMasterProgramElementTocByBADisabled() 
    {
      return this.isDodServiceOrDodBigAgency() && mfdata.getVolumes().size() > 1;
    }
    
    public boolean isIncludeMasterProgramElementTocByTitleDisabled() 
    {
      return isDodServiceOrDodBigAgency() && mfdata.getVolumes().size() > 1;
    }
}
