package mil.dtic.cbes.t5shared.components.mjb;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.sso.siteminder.P40Privileges;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class LogoUpload extends T5JBBase {
    private static final String IMGEVENT = "selectedImage";
    private static final String FILE_DELIMETER = "//";

    private static final Logger log = CbesLogFactory.getLog(LogoUpload.class);

    @Inject
    private ComponentResources componentResources;

    @Inject
    private ConfigService config;

    private boolean makeDefault;

    @Parameter(required = true)
    @Property
    private File file;

    @Parameter(required = true)
    @Property
    private ServiceAgency agency;

    @Component(publishParameters = "workingDir,showSaved,originalName,filevalidator,validate", inheritInformalParameters = true)
    private SavedUpload uploadcomponent;

    @Property
    @Parameter(defaultPrefix = BindingConstants.LITERAL, value = "200px")
    private String maxHeight, maxWidth;

    @OnEvent(value = IMGEVENT)
    StreamResponse onSelectedImage() throws IOException {

        File streamthis;
        
        if (agency == null) {
            return null;
        }
        
        if (file != null && file.exists() && file.isFile()) {
            streamthis = file;
        }
        else if (getDefaultLogoFile().exists() && getDefaultLogoFile().isFile()) {
            streamthis = getDefaultLogoFile();
        }
        else {
            log.error("onSelectedImage: No logo file found! " + getDefaultLogoFile(), new FileNotFoundException());
            return null;
        }
        String mimeType = URLConnection.getFileNameMap().getContentTypeFor(streamthis.getName());
        log.trace("onSelectedImage: returning stream response with mimeType: " + mimeType);
        
        return getStreamResponse(FileUtils.openInputStream(streamthis), mimeType, null);
    }

    public Object getSelectedImage() {
        return componentResources.createEventLink(IMGEVENT, UUID.randomUUID().toString());
    }

    public boolean isDefault() {
        return file == null || !file.exists() || !file.isFile();
    }

    public boolean getMakeDefault() {
        return makeDefault;
    }

    public void setMakeDefault(boolean makeDefault) {
        log.trace("setMakeDefault:  - makeDefault: " + makeDefault);
        this.makeDefault = makeDefault;
        
        if (makeDefault && file != null && file.exists() && file.isFile()) {
            doDefault();
        }
        else {
            log.debug("setMakeDefault: unable to execute doDefault - file is defective");
        }
    }

    public boolean showCheckbox() {
        return checkPrivilege(Privilege.LOGODEFAULT) || checkPrivilege(P40Privileges.SHOW_DEFAULT_LOGO_CHECKBOX);
    }

    private File getDefaultLogoFile() {
        String logosDir = config.getLogoImagesFolder();
        log.debug("getDefaultLogoFile: logosDir: " + logosDir);
        String agencyLogo = (agency == null || agency.getLogoFileName() == null) ? LogoImage.NO_IMAGE : agency.getLogoFileName();
        if (agency == null || agency.getLogoFileName() == null) {
            // log.error("Null logo filename in db", new
            // FileNotFoundException());
            log.debug("Service Agency does not have default LOG assigned");
        }
        return new File(logosDir, agencyLogo);
    }

    private void doDefault() {
        log.debug("doDefault: setting " + file + " as default image for agency: " + agency);

        Path uploadedFile = file.toPath();
        Path originalPath = getDefaultLogoFile().toPath();
        String logosDir = originalPath.getParent().toString();
        String logoFileName = agency.getCode() + ".png";
        Path targetPath = null;
            
        try {
            targetPath = Paths.get(logosDir);
            Files.move(uploadedFile, targetPath.resolve(logosDir + LogoUpload.FILE_DELIMETER  + logoFileName), StandardCopyOption.REPLACE_EXISTING);
            agency.setLogoFileName(logoFileName);
            ServiceAgencyDAO serviceAgency = BudgesContext.getServiceAgencyDAO();
            serviceAgency.saveOrUpdate(agency);
        } 
        catch (IOException ioe) {
            log.error("doDefault: failure to create new file: " + logosDir + logoFileName, ioe.getMessage(), ioe);
        } 
        catch (Exception e) {
            log.error("doDefault: failure to create new file: " + logosDir + logoFileName, e.getMessage(), e);
        }
        finally {
            uploadcomponent.delete();
            file = null;
            makeDefault = false;
        }
    }

}
