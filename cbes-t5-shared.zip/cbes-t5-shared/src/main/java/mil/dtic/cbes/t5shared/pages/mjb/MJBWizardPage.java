package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
//import org.apache.cayenne.exp.Expression;
//import org.apache.cayenne.exp.ExpressionFactory;
//import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.AfterRender;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionAttribute;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.InjectService;
import org.apache.tapestry5.services.ComponentSource;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.cbes.output.BudgesDownloadableObject;
import mil.dtic.cbes.p40.validation.LineItemListValidator;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.rule.RuleGroup;
import mil.dtic.cbes.rule.RuleGroupVisitor;
import mil.dtic.cbes.rule.RuleGroupVisitorFactory;
import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.ValueObjects.SubmissionDate;
import mil.dtic.cbes.submissions.dao.BudgetActivityDAO;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.delegates.JBFormData;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.submissions.validation.backend.R2ExhibitListRulesValidator;
import mil.dtic.cbes.submissions.validation.backend.ValidationMessages;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.utils.wizard.BaseMjbWizardNavigation;
import mil.dtic.cbes.t5shared.utils.wizard.PageEntry;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.samanage.service.api.AdminService;

/** Abstract superclass for all Master Justification Book wizard pages to
 * subclass. Each wizard page is passed as a parameter to the wizard layout
 * component that surrounds the page's content. */
public abstract class MJBWizardPage extends T5JBBase {
    private static final Logger log = CbesLogFactory.getLog(MJBWizardPage.class);
    private static final String BA_KEY = "MJBWizardPage:BudgetActivities";
    private static final String BUDGET_ESTIMATE_DOWNLOAD_KEY = "MJBWizardPage:BudgetEstimateDownload";
    private static final String MJB_FORM_DATA_KEY = "MJBWizardPage:JBFormData";
    private static final String TRACKING_KEY = "MJBWizardPage:TrackingURL";
    
    private final ProgramElementDAO peDAO = BudgesContext.getProgramElementDAO();
    
    @Inject
    private AppDefaults appDefaults;
    
    @Inject
    private BudgetActivityDAO baDAO;
    
    @Inject
    private ComponentResources componentResources;
    
    @Inject
    private ComponentSource componentSource;
    
    @Inject
    protected AdminService specialCategoryService;

    
    
    @InjectPage("cb/MJB/wizardpeselection")
    private MJBWizardPESelection peSelectPage;
    
    @Property
    @SessionAttribute(value = BA_KEY)
    private List<BudgetActivity>  bas;
    
    @Persist
    private List<String> errorMessages;
    
    @Persist
    private List<String> warningMessages;
    
    @Property
    @SessionAttribute(value = MJB_FORM_DATA_KEY)
    protected JBFormData mfdata;
    
    @Property
    protected String jbWizHelp;
    
    @SessionAttribute(value = BUDGET_ESTIMATE_DOWNLOAD_KEY)
    private BudgesDownloadableObject mjbDownloadableObject;
    
    @InjectService("MJBWizardNavigation")
    protected BaseMjbWizardNavigation navigation;
    
    @SessionAttribute(value = TRACKING_KEY)
    private String trackingURL;
    
    @Inject
    private LineItemListValidator lineItemListValidator;
    
    Object onActivate() throws IOException {
        log.debug("** MJBWizardPage.onActivate " + this);
        boolean gotoFirstPage = false;
        
        if (mfdata == null) {
            gotoFirstPage = true;
            mfdata = new JBFormData(getUserId(), getNavigation().isR2(), getNavigation().isP40());
            log.debug("Starting new MJB Wizard session with working directory : " + mfdata.getWorkingDirectory());
            
            P40User user = null;
            
            if (getP40User() != null) {
                user = getP40User();
            } 
            else if (getUserCredentials() != null) {
                user = P40User.fetchWithLdapId(CayenneUtils.createDataContext(),
                        getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
            }
            
            //      jbh:  what is the point of this code? I don't think there is any point. am removing....
                  if (getJBFormData() != null && getJBFormData().getServiceAgency() != null){
                    Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.
                    vo.ServiceAgency.CODE_PROPERTY, getJBFormData().getServiceAgency().getCode());
                    SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
                  }
            
        }
        logStep();
        
        jbWizHelp = config.getJbWizHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
        
        if (gotoFirstPage) {
            return navigation.getPageEntry(0).getPageClass();
        } else
            return null;
    }
    
    @Log
    void onActivate(String resetValues) {
        if (StringUtils.equals(resetValues, "reset"))
            resetAll();
    }
    
    void beginRender() {
        addXmlExhibitWarning();
    }
    
    /** Add warnings from validation */
    protected void addXmlExhibitWarning() {
        R2ExhibitList r2ExhibitList = getJBFormData().getR2ExhibitList();
        if (r2ExhibitList != null) {
            addWarningMessages(validateR2Exhibits(r2ExhibitList));
        }
        LineItemList lineItemList = getJBFormData().getLineItemList();
        if (lineItemList != null) {
            addWarningMessages(validateP40Exhibits(lineItemList));
        }
    }
    
    /** Run business rules on R2 Exhibits
     *
     * @param r2ExhibitList */
    private List<String> validateR2Exhibits(R2ExhibitList r2ExhibitList) {
        refreshProgramElementsToAvoidHibernateLazyEvalException(r2ExhibitList);
        // Validate R2 exhibits
        String selectedBudgetCycleAndYear = getJBFormData().getBudgetCycle().getValue();
        r2ExhibitList.setParentBudgetCycleAndYear(selectedBudgetCycleAndYear);
        
        RuleGroupVisitor visitor = RuleGroupVisitorFactory.makeVisitor();
        RuleGroup rlv = new R2ExhibitListRulesValidator(r2ExhibitList);
        
        visitor.visit(rlv, getJBFormData().getServiceAgency().getCode());
        log.debug("** MJBWizardPage.addXmlExhibitWarning r2 exhibit list has warnings? " + visitor.hasViolations());
        if (visitor.hasViolations() && !getWarningMessages().isEmpty()) {
            addWarningMessage("Your Justification Book(s) can be created but will NOT be acceptable for "
                    + "submission to the Comptroller's Office due to warning(s) in one or more "
                    + "of your Exhibit R-2's");
        }
        
        return visitor.getRuleViolations().asList();
    }
    
    protected void refreshProgramElementsToAvoidHibernateLazyEvalException(R2ExhibitList r2ExhibitList) {
        //Ensure the exhibit objects are initialized to avoid a lazy initialization
        //exception due to hibernate and child exhibits being out of session.
        if (r2ExhibitList == null || r2ExhibitList.getR2Exhibits() == null) {
            return;
        }
        List<R2Exhibit> r2Exhibits = r2ExhibitList.getR2Exhibits();
        for (R2Exhibit exhibit : r2Exhibits) {
            if (peSelectPage.isPeSelect()) {
                peDAO.refresh(exhibit.getProgramElement());
            }
        }
    }
    
    /** Run business rules on P40 Exhibits
     *
     * @param lineItemList */
    private List<String> validateP40Exhibits(LineItemList lineItemList) {
        // Validate P40 exhibits
        String selectedBudgetCycleAndYear = getJBFormData().getBudgetCycle().getValue();
        lineItemList.setParentBudgetCycleAndYear(selectedBudgetCycleAndYear);
        ValidationMessages messages = lineItemListValidator.validate(lineItemList, null, "", 0, "", true, null);
        
        log.debug(
                "** MJBWizardPage.addXmlExhibitWarning P40 exhibit list has warnings? " + lineItemList.isHasWarnings());
        if (lineItemList.isHasWarnings() && !getWarningMessages().isEmpty()) {
            addWarningMessage("Your Justification Book(s) can be created but will NOT be acceptable for "
                    + "submission to the Comptroller's Office due to warning(s) in one or more "
                    + "of your Exhibit P-40's");
        }
        
        return messages.getWarningStrings();
    }
    
    /** Reset the error messages after rendering. the reason this The annotation
     * was used instead of the the afterRender naming convention is to prevent
     * shadowing from the child classes */
    @AfterRender
    void basePageAfterRender() {
        resetErrorMessages();
        resetWarningMessages();
    }
    
    /******************************************************************** Wizard
     * Events ********************************************************************/
    
    /** Called by the wizard layout to validate the current page before
     * navigation forward is allowed. Subclasses can override to do validation
     * (adding error messages for problems) and to initialize values needed by
     * later pages. */
    public void validate() {
    }
    
    /** Called by the wizard layout when the next/continue button is clicked.
     * This is called pre-validation. This is a notification-only event and not
     * called during sidebar navigation. */
    public void nextButtonClicked() {
    }
    
    /** Called by the wizard layout when the back/previous button is clicked.
     * This is called pre-validation. This is a notification-only event and not
     * called during sidebar navigation. */
    public void previousButtonClicked() {
    }
    
    /** Cover method. Subclasses should override to return a different page or
     * stream (such as a PDF) for the user. The default returns <tt>null</tt>
     * which informs the wizard layout to use the wizard logic/steps in
     * determining the response page.
     *
     * @return The page/stream to render to the user. */
    public Object successResponse() {
        return null;
    }
    
    /******************************************************************** Logic ********************************************************************/
    
    private void logStep() {
        log.debug("Now on JB Wizad step: " + this);
        StringBuilder sb = new StringBuilder();
        for (MJBVolumeModel volume : mfdata.getVolumes()) {
            sb.append("Volume Supp Flags " + volume.getNumber() + ": [");
            for (int key = 0; key < volume.getSupplementalFiles().length; ++key)
                sb.append(" " + volume.getSupplementalFiles()[key]);
            sb.append("]\n");
        }
        
        log.debug(sb.toString());
    }
    
    /******************************************************************** Accessors ********************************************************************/
    
    public List<BudgetActivity> getBudgetActivities() {
        return bas;
    }
    
    public List<BudgetCycle> getBudgetCycles() {
        return appDefaults.getBudgetCycles();
    }
    
    public String getCurrentSubmDate() {
        SubmissionDate submissionDate = mfdata.getSubmissionDate();
        
        String submissionDateValue = (submissionDate == null) ? StringUtils.EMPTY : submissionDate.getValue();
        
        log.debug("submissionDateValue: " + submissionDate.getValue());
        
        return submissionDateValue;
    }
    
    /** Adds an error message to be displayed to the user for this page.
     *
     * @param errorMessage */
    public void addErrorMessage(String errorMessage) {
        getErrorMessages().add(errorMessage);
    }
    
    public void addWarningMessage(String warningMessage) {
        getWarningMessages().add(warningMessage);
    }
    
    /** Add all error messages from the list.
     *
     * @param errorMessages List of error messages. */
    public void addErrorMessages(List<String> errorMessages) {
        for (String errorMessage : errorMessages)
            addErrorMessage(errorMessage);
    }
    
    public void addWarningMessages(List<String> warningMessages) {
        for (String warningMessage : warningMessages) {
            addWarningMessage(warningMessage);
        }
    }
    
    /** Retrieves the list of error messages for this page.
     *
     * @return The page's error messages. */
    public List<String> getErrorMessages() {
        if (errorMessages == null)
            errorMessages = new ArrayList<String>();
        
        return errorMessages;
    }
    
    public List<String> getWarningMessages() {
        if (warningMessages == null)
            warningMessages = new ArrayList<String>();
        
        return warningMessages;
    }
    
    /** Resets (erases) the page's error messages. */
    public void resetErrorMessages() {
        errorMessages = null;
    }
    
    public void resetWarningMessages() {
        warningMessages = null;
    }
    
    /** Resets the current page's @Persist properties. This is done after the
     * request is processed. */
    void reset() {
        log.debug("*** reset called ***");
        
        componentResources.discardPersistentFieldChanges();
    }
    
    /** Resets ALL @Persist properties of every page in the MJB wizard. Also
     * resets all @SessionState properties defined in the MJBWizardPage class.
     * This is done after the request is processed. */
    void resetAll() {
        log.debug("*** reset all called ***");
        
        for (PageEntry pageEntry : navigation.getPageEntries()) {
            MJBWizardPage page = (MJBWizardPage) componentSource.getPage(pageEntry.getPageClass());
            
            page.reset();
        }
        
        bas = null;
        mfdata = null;
        mjbDownloadableObject = null;
        trackingURL = null;
        //        xmlWarningMessages    = null;
    }
    
    public void setTrackingURL(String trackingURL) {
        this.trackingURL = trackingURL;
    }
    
    public String getTrackingURL() {
        return trackingURL;
    }
    
    public BudgesDownloadableObject getMjbDownloadableObject() {
        return this.mjbDownloadableObject;
    }
    
    public void setMjbDownloadableObject(BudgesDownloadableObject mjbDownloadableObject) {
        this.mjbDownloadableObject = mjbDownloadableObject;
    }
    
    public JBFormData getJBFormData() {
        return mfdata;
    }
    
    /** @return The default label for the next/continue button. Subclasses can
     * override if needed. */
    public String getNextLabel() {
        return "Continue >";
    }
    
    /** @return The default label for the previous/back button. Subclasses can
     * override if needed. */
    public String getPreviousLabel() {
        return "< Back";
    }
    
    /** Checks to see if the page is valid.
     *
     * @return <tt>true</tt> if the error message list is empty, <tt>false</tt>
     * otherwise. */
    public boolean isValid() {
        return getErrorMessages().size() == 0;
    }
    
    public BaseMjbWizardNavigation getNavigation() {
        return navigation;
    }
    
    public void checkForWarnings() {
        
    }
    
    public boolean isDodService(String code){
        if (null != code){
            if (specialCategoryService.isDodService(code)){
                return true;
            }
        }
        return false;
        
    }
    
    public boolean isDodServiceOrDodBigAgency() {
        ServiceAgency sa = getJBFormData().getServiceAgency();
        if (null != sa){
            if (specialCategoryService.isDodService(sa.getCode()) || specialCategoryService.isDodBigAgency(sa.getCode())){
                return true;
            }
        }
        return false;
    }
    
    protected void sortLineItems(List<LineItem> l) {
        //TapestryUtil.ognlsortcomparable(l, LineItem.P1LINE_ITEM_NUMBER_PROPERTY, true);
        Collections.sort(l, LineItem.getComparatorForOrderingByBa());
    }
    
    protected void sortPes(List<ProgramElement> l) {
        Collections.sort(l, ProgramElement.getR2ComparatorForOrderingByBa());
    }
}