package mil.dtic.cbes.t5shared.services;


import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.Request;

// Modified from https://gist.github.com/bryanjswift/318237.
public class UserAgentImpl implements UserAgent
{
    // Standard desktop browser version strings.
    public static final String IE      = "MSIE";
    public static final String IE60    = "MSIE 6.0";
    public static final String IE61    = "MSIE 6.1";
    public static final String IE7     = "MSIE 7.0";
    public static final String IE8     = "MSIE 8.0";
    public static final String IE9     = "MSIE 9.0";
    public static final String IE10    = "MSIE 10.0";
    public static final String IE11    = "rv:11.0";
    public static final String EDGE    = "Edge";
    public static final String CHROME  = "Chrome";
    public static final String FIREFOX = "Firefox";
    public static final String SAFARI  = "Safari";

    @Inject
    private Request request;

    @Override
    public String getUserAgent()
    {
        return request.getHeader("User-Agent");
    }

    @Override
    public boolean isIE()
    {
        return getUserAgent().indexOf(IE) != -1 || isIE11();
    }

    @Override
    public boolean isIE6()
    {
        return getUserAgent().indexOf(IE60) != -1 && getUserAgent().indexOf(IE61) != -1;
    }

    @Override
    public boolean isIE7()
    {
        return getUserAgent().indexOf(IE7) != -1;
    }

    @Override
    public boolean isIE8()
    {
        return getUserAgent().indexOf(IE8) != -1;
    }

    @Override
    public boolean isIE9()
    {
        return getUserAgent().indexOf(IE9) != -1;
    }

    @Override
    public boolean isIE10()
    {
        return getUserAgent().indexOf(IE10) != -1;
    }

    @Override
    public boolean isIE11()
    {
        return getUserAgent().indexOf(IE11) != -1;
    }

    @Override
    public boolean isBadIE()
    {
        return isIE6() || isIE7() || isIE8();
    }

    @Override
    public boolean isChrome()
    {
        // Chrome contains CHROME and SAFARI, so just test for CHROME.
        return getUserAgent().indexOf(CHROME) != -1;
    }

    @Override
    public boolean isFirefox()
    {
        // Firefox contains FIREFOX.
        return getUserAgent().indexOf(FIREFOX) != -1;
    }

    @Override
    public boolean isSafari()
    {
        // Safari contains SAFARI, but not CHROME, so test for SAFARI with a missing CHROME.
        return getUserAgent().indexOf(SAFARI) != -1 && getUserAgent().indexOf(CHROME) == -1;
    }

    @Override
    public boolean isEdge()
    {
        return getUserAgent().indexOf(EDGE) != -1;
    }
}
