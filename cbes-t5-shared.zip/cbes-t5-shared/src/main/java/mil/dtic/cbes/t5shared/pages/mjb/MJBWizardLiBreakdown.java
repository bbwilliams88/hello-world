package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;

import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;



/**
 * Break the P40s into volumes
 */
@Import(
  stack=CbesT5SharedModule.JQUERYSTACK,
    library={
	"classpath:${cb.assetpath}/js/json2.js",
    "classpath:${cb.assetpath}/js/jquery.pfSelect.js",
    "classpath:${cb.assetpath}/js/jquery.sortElements.js",
    "classpath:${cb.assetpath}/js/libreakdown.js"
  },
  stylesheet="classpath:${cb.assetpath}/css/libreakdown.css")
public class MJBWizardLiBreakdown extends MJBWizardPage
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardLiBreakdown.class);
  
  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private HttpServletRequest request;


  @Property
  private MJBVolumeModel currentvol;
  @Property
  private LineItem li;
  @Property
  private String jbWizSingleVolumeBreakdownHelp;
  @Property
  private String jbWizP40MultiVolumeBreakdownHelp;
  @Property
  private String jbWizR2MultiVolumeBreakdownHelp;

  void afterRender()
  {
    jsSupport.addScript("initTables('%s');", resources.createEventLink("moveRows"));
  }
  
  Object onActivate() throws IOException
  {
    Object obj = super.onActivate();
    
    jbWizSingleVolumeBreakdownHelp = config.getJbWizSingleVolumeBreakdownHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    jbWizP40MultiVolumeBreakdownHelp = config.getJbWizP40MultiVolumeBreakdownHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    jbWizR2MultiVolumeBreakdownHelp = config.getJbWizR2MultiVolumeBreakdownHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
    
    return obj;    
  }

  void onMoveRows()
  {
    log.debug("onMoveRows " + request.getParameter("rowids") + " " + request.getParameter("volid"));
    final List<Object> rowids = Lists.newArrayList(new JSONArray(request.getParameter("rowids")));
    String volumeid = request.getParameter("volid");
    List<LineItem> toBeMoved = new ArrayList<LineItem>(rowids.size());
    MJBVolumeModel destVolume = null;
    //first gather the rows from the other volumes
    for (MJBVolumeModel volume : getVolumes()) {
      if (!volumeid.equals(volume.getT5Id())) {
        toBeMoved.addAll(Collections2.filter(volume.getLineItems(), new Predicate<LineItem>() {
          public boolean apply(LineItem input) {
            return rowids.contains(input.getT5Id());
          }
        }));
        volume.getLineItems().removeAll(toBeMoved);
      } else {
        destVolume = volume;
      }
    }
    //now move them to dest
    if (destVolume != null) {
      destVolume.getLineItems().addAll(toBeMoved);
      sortLineItems(destVolume.getLineItems());
    }
    else throw new IllegalArgumentException("destVolume not found");
  }


  public List<MJBVolumeModel> getVolumes()
  {
    return getJBFormData().getVolumes();
  }

  public List<LineItem> getCurrentLineItems()
  {
    return currentvol.getLineItems();
  }


  public String getCurrentLiUuid()
  {
    if (li.getT5Id() == null)
      li.setT5Id(UUID.randomUUID().toString());
    return li.getT5Id();
  }
}
