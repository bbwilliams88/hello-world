package mil.dtic.cbes.t5shared.components.mjb;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.InjectService;
import org.apache.tapestry5.services.ComponentSource;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardPage;
import mil.dtic.cbes.t5shared.utils.wizard.BaseMjbWizardNavigation;
import mil.dtic.cbes.t5shared.utils.wizard.PageEntry;
import mil.dtic.utility.CbesLogFactory;

/**
 * This component is the layout manager for the Master Justification Book
 * wizard. It includes the CSS and JS and master FORM used to encompass all
 * navigation within the wizard and data entry items. A wizard page sits inside
 * this component and is notified of navigation events. The wizard page itself
 * has very little control over navigation (mainly adding errors during
 * validation).
 * <p/>
 * The wizard layout communicates with the wizard pages by sending the following
 * events/notifications:
 * <ul>
 * <li><tt>nextButtonClicked</tt> / <tt>previousButtonClicked</tt> - When the
 * "next" or "previous" buttons are clicked. These don't get fired for the
 * sidebar navigation links.</li>
 * <li><tt>validate</tt> - When attempting to navigate forward or staying on the
 * same page (which happens when a wizard page has buttons in it). This event
 * will be sent to every page that the user is trying to navigate forward to.
 * The wizard page is expected to add error messages if there are validation
 * problems. Navigation forward will be halted at the page with the validation
 * errors.</li>
 * <li><tt>successResponse</tt> - When all validation events are successful,
 * determines the response to render.</li>
 * </ul>
 */

@Import(
  library={
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/wizard.js",
    "classpath:${cb.assetpath}/js/warnings.js"
  },
  stylesheet="classpath:${cb.assetpath}/css/wizard.css")
public class MJBWizardLayout
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardLayout.class);

    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private String breadcrumb;

    @Property
    @Parameter(required = true, defaultPrefix = BindingConstants.PROP)
    private MJBWizardPage currentPage;

    @Inject
    private ComponentSource componentSource;

    @Property
    private String jumpToPage;

    private String requestedPage;

    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private String errorMessage;

    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private String warningMessage;

    @InjectService("MJBWizardNavigation")
    private BaseMjbWizardNavigation navigation;

    @Property
    @SuppressWarnings("unused") // Used in the TML.
    private PageEntry pageEntry;

    private int currentPageIndex   = -1;
    private int requestedPageIndex = -1;

    private MJBWizardPage actualPage;

    @Property
    private int pageIndex;

    @Inject
    private JavaScriptSupport jsSupport;

    @Component
    private Form wizardInputs;
    
    @SuppressWarnings("unused")
    @Property
    @Parameter(required = false, defaultPrefix = BindingConstants.BLOCK)
    private Block instructions;
    

    /********************************************************************
     * Tapestry Events
     ********************************************************************/

    /**
     * Initialize the current page.
     */
    void pageAttached()
    {
        log.debug("MJBWizardLayout.pageAttached: currentPage = " + currentPage);
        log.debug("MJBWizardLayout.pageAttached: jumpToPage = " + jumpToPage);
        setCurrentPageIndex(getNavigation().getIndexForClass(currentPage.getClass()));
    }

    /**
     * Initialize the breadcrumb.
     */
    void setupRender()
    {
        if (currentPage.getJBFormData().getServiceAgency() != null &&
            currentPage.getJBFormData().getBudgetCycle()   != null &&
                currentPage.getCurrentSubmDate()                != null)
        {
            breadcrumb = currentPage.getJBFormData().getServiceAgency().getName() +
                         " ("                                                      +
                         currentPage.getJBFormData().getBudgetCycle().getValue()  +
                         " - "                                                     +
                         currentPage.getCurrentSubmDate()                           +
                         ")";
        }
    }

    /**
     * Validates that the form values are correct/acceptable. This calls the
     * page instance's (the contained page component) validate method to allow
     * the the validation to occur in the child.
     */
    @Log
    void onValidateFromWizardInputs()
    {
        log.debug("MJBWizardLayout.onValidateForm: currentPage = " + currentPage);
        log.debug("MJBWizardLayout.onValidateForm: currentPageIndex = " + getCurrentPageIndex());
        log.debug("MJBWizardLayout.onValidateForm: requestedPageIndex = " + getRequestedPageIndex());

        // Add any errors from component validation/exceptions.
        if (wizardInputs.getDefaultTracker() != null && wizardInputs.getDefaultTracker().getHasErrors())
            currentPage.addErrorMessages(wizardInputs.getDefaultTracker().getErrors());

        // Assume we are going to the requested page.
        actualPage = getPage(getRequestedPageIndex());

        // If we are staying on the same page, validate only this page.
        if (getCurrentPageIndex() == getRequestedPageIndex())
            actualPage.validate();

        // If trying to move forward, validate all pages from the current up to the one we want.
        for (int pageIndex = getCurrentPageIndex(); pageIndex < getRequestedPageIndex(); pageIndex++)
        {
            MJBWizardPage page = getPage(pageIndex);

            log.debug("MJBWizardLayout.onValidateForm: validating " + page);

            page.validate();

            // If invalid, record the errors and bail out.
            if (page.isValid() == false)
            {
                // Change the page we are transitioning to.
                actualPage = page;

                // Don't continue processing pages.
                break;
            }
        }
    }

    /**
     * After all validations are complete, return the successful
     * response to be rendered.  This is usually a T5 page.
     *
     * @return The response to send to the browser.
     */
    @Log
    Object onSuccess()
    {
        log.debug("MJBWizardLayout.onSuccess: currentPage = " + currentPage);
        log.debug("MJBWizardLayout.onSuccess: requested page = " + getRequestedPage());
        log.debug("MJBWizardLayout.onSuccess: jumpToPage = " + jumpToPage);
        log.debug("MJBWizardLayout.onSuccess: currentPageIndex = " + getCurrentPageIndex());


        // Get the response from the contained page.
        Object response = currentPage.successResponse();

        log.debug("Success Response: " + response);

        // If the response is a wizard page, check for warnings.
        if (response instanceof MJBWizardPage)
            ((MJBWizardPage) response).checkForWarnings();
        else if (response == null)
            actualPage.checkForWarnings();

        // If the returned response is not null, render it instead of the
        // normal navigation behavior.
        if (response != null)
            return response;
        else
            return actualPage;
    }

    /**
     * Handle the "Next" navigation button click.
     */
    public void onSelectedFromSubmitNext()
    {
        setRequestedPageIndex(getCurrentPageIndex() + 1);
        getPage(getCurrentPageIndex()).nextButtonClicked();
    }

    /**
     * Handle the "Previous" navigation button click.
     */
    public void onSelectedFromSubmitPrevious()
    {
        setRequestedPageIndex(getCurrentPageIndex() - 1);
        getPage(getCurrentPageIndex()).previousButtonClicked();
    }

    /**
     * After rendering the page, fire off our wizard JS.
     */
    void afterRender()
    {
        jsSupport.addScript("initializeWizardNavigation();");
        jsSupport.addScript("initializeWizardBtPopups();");
        if (currentPage.getWarningMessages() != null && currentPage.getWarningMessages().size() > 0)
          jsSupport.addScript("initializeValidationBox();");
    }

    /********************************************************************
     * Logic
     ********************************************************************/

    /**
     * If jumpToPage is set, the user clicked on a navigation link and JS was
     * used to submit the form and assign the page to jump to next. Otherwise,
     * Previous/Next was used to navigate.
     */
    private void initializeRequestedPage()
    {
        if (requestedPage == null)
        {
            log.debug("MJBWizardLayout.initializeRequestedPage: jumpToPage = " + jumpToPage);

            // Check the jumpToPage for JS support and get the requestedPageIndex.
            if ((jumpToPage != null) && (jumpToPage.length() > 0))
            {
                setRequestedPage(jumpToPage);
                setRequestedPageIndex(getNavigation().getIndexForPage(jumpToPage));
            }
            else
            {
                log.debug("MJBWizardLayout.initializeRequestedPage: requestedPageIndex = " + requestedPageIndex);

                if (requestedPageIndex == -1)
                    requestedPageIndex = getCurrentPageIndex();
                setRequestedPage(getNavigation().getPageEntry(requestedPageIndex).getPageName());
            }
        }
    }


    /********************************************************************
     * Accessors
     ********************************************************************/

    /**
     * Gets the wizard page by index position.
     *
     * @param pageIndex The index position in the navigation.
     * @return A wizard page.
     */
    private MJBWizardPage getPage(int pageIndex)
    {
        // FIXME: move to navigation?
        return (MJBWizardPage) componentSource.getPage(getNavigation().getPageEntry(pageIndex).getPageClass());
    }

    /**
     * @return The requested page to navigate to next.
     */
    public String getRequestedPage()
    {
        initializeRequestedPage();

        return requestedPage;
    }

    public int getRequestedPageIndex()
    {
        initializeRequestedPage();

        return requestedPageIndex;
    }

    /**
     * @return If the current page is the selected page in the navigation list.
     */
    public boolean isPageSelected()
    {
        if (pageIndex == getCurrentPageIndex())
            return true;
        else
            return false;
    }


    /**
     * @return The float position for the navigation buttons (used in the TML).
     */
    public String getNavigationButtonFloat()
    {
        if (isFirstPage())
            return "";
        else
            return "float: right;";
    }

    /**
     * @return <tt>true</tt> if the wizard navigation is on the first page,
     *         <tt>false</tt> otherwise.
     */
    public boolean isFirstPage()
    {
        return getCurrentPageIndex() == 0;
    }

    /**
     * @return <tt>true</tt> if the wizard navigation is on the last page,
     *         <tt>false</tt> otherwise.
     */
    public boolean isLastPage()
    {
        return getCurrentPageIndex() == getNavigation().getPageEntries().size() - 1;
    }

    private void setCurrentPageIndex(int currentPageIndex)
    {
        this.currentPageIndex = currentPageIndex;
    }

    private int getCurrentPageIndex()
    {
        return currentPageIndex;
    }

    private void setRequestedPageIndex(int requestedPageIndex)
    {
        this.requestedPageIndex = requestedPageIndex;
    }

    public BaseMjbWizardNavigation getNavigation()
    {
        return navigation;
    }

    private void setRequestedPage(String requestedPage)
    {
        this.requestedPage = requestedPage;
    }

    public int getCurrentStep()
    {
        return pageIndex + 1;
    }
    
    public boolean getShowWarnings()
    {
        return currentPage.getJBFormData().isShowWarnings();
    }
    
    public void setShowWarnings(boolean showWarnings)
    {
        currentPage.getJBFormData().setShowWarnings(showWarnings);
    }
}
