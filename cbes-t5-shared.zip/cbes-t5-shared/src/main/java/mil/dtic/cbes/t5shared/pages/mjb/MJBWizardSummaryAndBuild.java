package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.exceptions.BadPasswordException;

import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.data.config.JobTypeFlag;
import mil.dtic.cbes.jb.DocumentAssemblyOptions;
import mil.dtic.cbes.p40.vo.P40User;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.Project;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.ServiceAgencyDAO;
import mil.dtic.cbes.submissions.delegates.BudgesUploadFileT5;
import mil.dtic.cbes.submissions.delegates.BuildConsolidatedJbDelegate;
import mil.dtic.cbes.submissions.delegates.BuildJbBaseDelegate;
import mil.dtic.cbes.submissions.delegates.DelegateResultInfo;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.validation.backend.SubmissionDateValidator;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.BudgesJbUploadFile;
import mil.dtic.utility.CayenneUtils;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;
import mil.dtic.utility.SendEmailOnInvalidXML2;
import mil.dtic.utility.Util;

/**
 * Summary and build wizard page for Master Justification Book.
 */
public class MJBWizardSummaryAndBuild extends MJBWizardPage {
    
    private static final Logger log = CbesLogFactory.getLog(MJBWizardSummaryAndBuild.class);

    @Inject
    private ConfigService config;

    @Inject
    private BudgesJobDAO jobDAO;


    private boolean buildBookClicked;

    @Property
    private boolean currentBaFlag; // Used in the TML.

    @Property
    private MJBVolumeModel currentvol; // Used in the TML.

    @Property
    private BudgesJbUploadFile currentTov; // Used in the TML.

    @Inject
    private ServiceAgencyDAO saDAO;
    
    @Inject
    private BudgesUserDAO userDAO;

    @Property
    private BudgesUploadFileT5 file; // Used in the TML.

    @Property
    private String jbWizSummaryAndBuildHelp;

    private List<BudgesJbUploadFile> agencyTov;

    @Override
    Object onActivate() throws IOException {
      Object obj = super.onActivate();
      jbWizSummaryAndBuildHelp = config.getJbWizSummaryAndBuildHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      return obj;
    }

    @Override
    public void nextButtonClicked()
    {
        buildBookClicked = true;
    }

    public String convertBooleanToYesNoString(boolean val)
    {
      return Util.convertBooleanToYesNoString(val);
    }

    @Override
    public void validate() {
        log.debug("Validating Summary and Build");

        if (buildBookClicked == false){
            addErrorMessage("You must review and click 'Build Book' to build your Justification Books and see the confirmation page.");
        }else{

          P40User user = null;

          if(getP40User() != null){
            user = getP40User();
          }else if(getUserCredentials() != null){
             user = P40User.fetchWithLdapId(CayenneUtils.createDataContext(), getUserCredentials().getUserInfo().getLdapUser().getLdapUserId());
          }
       
          if(getJBFormData() != null && getJBFormData().getServiceAgency() != null){
            Expression exp = ExpressionFactory.matchExp(mil.dtic.cbes.p40.vo.ServiceAgency.CODE_PROPERTY, getJBFormData().getServiceAgency().getCode());
            SelectQuery query = new SelectQuery(mil.dtic.cbes.p40.vo.ServiceAgency.class,exp);
          }
       
          processMjb();
        }
    }

    @Log
    private void processMjb(){
      try {
        getJBFormData().updateTov();
        R2Storage r2storage = new R2Storage("mjbbuild");
        File workingFolder = r2storage.createEmptyFolderInUpload(getJBFormData().getWorkingDirectory().getAbsolutePath());
        log.debug("Created working folder for new MJB build: " + workingFolder);
        if (getNavigation().isR2()) {
          //hack to set appropriation to the default R2 one
          //getMJBFormData().setServiceAgency(saDAO.findByCode((getMJBFormData().getServiceAgency().getCode()))); //reattach to get lazy appropriation
          //getMJBFormData().setAppropriation(getMJBFormData().getServiceAgency().getAppropriations());
        }

        // Fix for CXE-8497
        if (getJBFormData().getR2ExhibitList() != null)
        {
          priorYearsDataCheck(getJBFormData().getR2ExhibitList().getProgramElements());
        }
        

        // Check if Submission Date is available in selected BudgetCycle
        SubmissionDateValidator sdv = new SubmissionDateValidator(getJBFormData().getSubmissionDate(), getJBFormData().getBudgetCycle());
        if (!sdv.isValidSubmissionDate())
          throw new ValidationException(sdv.getSubmissionDateError());

        DocumentAssemblyOptions docAssemblyOptions = new DocumentAssemblyOptions();
        docAssemblyOptions.setForceEvenPages(getJBFormData().isForceEvenPages());
        docAssemblyOptions.setP1mCheckbox(getJBFormData().isP1mCheckbox());
        docAssemblyOptions.setGenerateP1m(getJBFormData().isGenerateP1m());
        docAssemblyOptions.setIncludeMasterP1m(getJBFormData().isIncludeMasterP1m());
        docAssemblyOptions.setWatermark(getJBFormData().getWatermark());
        docAssemblyOptions.setTrackingHeader(getJBFormData().getTrackingHeader());
        
        
        String aggregatedTitles = getJBFormData().getVolumeTitleAggregation();  //value used to identify the job.
        docAssemblyOptions.setVolumeTitleAggregation(aggregatedTitles);
        docAssemblyOptions.setPositionAttachmentsAfterExhibits(getJBFormData().isPositionAttachmentsAfterExhibits()); //cxe-4197
        
        //RFR stuff
        String workFlowStatus = getJBFormData().getWorkFlowStatus();
        JBookWorkFlowStatus jBookWorkFlowStatus = JBookWorkFlowStatus.valueOf(workFlowStatus);
        if (jBookWorkFlowStatus.getType() == 3){
            docAssemblyOptions.setJobReference(getJBFormData().getJobReference());
            docAssemblyOptions.setAnalystReference(getJBFormData().getAnalystReference());
            docAssemblyOptions.setFinalNotes(getJBFormData().getFinalNotes());
        }
        docAssemblyOptions.setWorkFlowStatus(workFlowStatus);
        //end of RFR stuff
        
        docAssemblyOptions.setSuppressSubExhibits(getJBFormData().isSuppressSubExhibits());
        BuildJbBaseDelegate bjbbd = createBuildJbBaseDelegate(workingFolder, docAssemblyOptions);
        bjbbd.setInvalidXMLListener(new SendEmailOnInvalidXML2()); //TODO fix email

        bjbbd.setCoverLogoBudgesFile(createBudgesFile(getJBFormData().getCoverLogoFile(), workingFolder));
        bjbbd.setCostBudgesFile(createBudgesFile(getJBFormData().getCostFile(), workingFolder));
        bjbbd.setIntroDocBudgesFile(createBudgesFile(getJBFormData().getIntroFile(), workingFolder));
        bjbbd.setSummaryDocBudgesFile(createBudgesFile(getJBFormData().getSummaryFile(), workingFolder));
        bjbbd.setAcronymDocBudgesFile(createBudgesFile(getJBFormData().getAcronymsFile(), workingFolder));
        bjbbd.setUserR1BudgesFile(createBudgesFile(getJBFormData().getR1File(), workingFolder));
        bjbbd.setUserP1BudgesFile(createBudgesFile(getJBFormData().getP1File(), workingFolder));
        bjbbd.setSupplementalDocBudgesFileList(createSupplementalDocBudgesFileList(getJBFormData().getSupplementalFiles(), workingFolder));
        bjbbd.setUserSuppliedData(getJBFormData());

        if (!config.getRunWizardJobsImmediately()) {
          if (!scheduleMjbJob(bjbbd, r2storage.getUuid()) && !bjbbd.getResultInfo().hasErrors())
            bjbbd.getResultInfo().addError("A system error occurred. Could not generate MJB.");
          if (bjbbd.getResultInfo().hasErrors())
            addErrorMessages(bjbbd.getResultInfo().getErrorList());

        } else {
          DelegateResultInfo dri = bjbbd.buildJbSinglePdf();

          if (dri.hasErrors())
            addErrorMessages(dri.getErrorList());

          setMjbDownloadableObject(dri.getMjb());

          if (getMjbDownloadableObject() == null)
            throw new ValidationException("Could not generate MJB");

        }
      } catch (BadPasswordException e) {
        log.error("", e);
        addErrorMessage("One of the PDF attachments is a secure PDF. You cannot use secured PDFs as attachments.");
      }
      catch (IOException | SQLException | DocumentException | ValidationException e)
      {
        log.error("", e);
        addErrorMessage("A system error occurred. Could not generate MJB.");
      }
    }

    private static BudgesFile createBudgesFile(BudgesUploadFileT5 buf, File workingDir)
    {
      if (buf==null || buf.getUploadFile()==null) return null;
      return new BudgesFile(buf.getOriginalName(), buf.getUploadFile(), null, null, buf.getTitle());
    }

    private BuildJbBaseDelegate createBuildJbBaseDelegate(File workingFolder, DocumentAssemblyOptions docAssemblyOptions){
      BuildConsolidatedJbDelegate bmd = new BuildConsolidatedJbDelegate(workingFolder, new SendEmailOnInvalidXML2(), null, docAssemblyOptions); 
      bmd.setMjbTocItemList(getJBFormData().getTov());
      return bmd;
    }

    private static List<BudgesFile> createSupplementalDocBudgesFileList(List<BudgesUploadFileT5> bufs, File workingDir)
    {
      List<BudgesFile> l = new ArrayList<BudgesFile>(bufs.size());
      for (BudgesUploadFileT5 buf : bufs)
      {
        BudgesFile bf = createBudgesFile(buf, workingDir);
        if (bf!=null) l.add(bf);
      }
      return l;
    }


    @Log
    private boolean scheduleMjbJob(BuildJbBaseDelegate bjbbd, UUID uuid) throws IOException, SQLException  {
      log.trace("scheduleMjbJob(): start");
      boolean success = false;
      setTrackingURL(null);
      log.debug("suppressSubExhibits = " + bjbbd.getDocAssemblyOptions().isSuppressSubExhibits());
      File zipFile = bjbbd.buildJbSingleZip();
      if (zipFile != null){
        log.debug("Scheduling MJB build job from Wizard, uuid=" + uuid);

        // Zip file has format 'MasterJB_File.zzz'
        File renamedFile = new File(zipFile.getParentFile(), FileUtil.createZipFileName("MJB_XML_From_Wizard"));
        log.debug("Renaming " + zipFile + " to " + renamedFile);
        if (zipFile.renameTo(renamedFile))
        {
          String workingFolder =  new File(bjbbd.getWorkingFolder().getParentFile().getName(), bjbbd.getWorkingFolder().getName()).toString();
          String queueName = config.getQueueName();
          BudgesUser budgesUser = getCurrentBudgesUser();
          if (budgesUser == null) {
            if (getP40User() != null) { //P40
              budgesUser = userDAO.findByUserLdapId(getP40User().getUserLdapId());
            } else {
              log.error("No user found to set on job", new IllegalArgumentException());
            }
          }
          JobTypeFlag jobType = Util.getJobType(bjbbd.getResultInfo());
          BudgesJob job = new BudgesJob(uuid, jobType, workingFolder, renamedFile.getName(), budgesUser, getJBFormData().getServiceAgency(), queueName);
          job.setBudgetCycle(getJBFormData().getBudgetCycle().getLabel());
          jobDAO.saveOrUpdate(job);
          

          // TODO just a demo, not really the right url, gotta fix this by adding a tracking url property to *envsettings*.xml files...
          setTrackingURL(Util.concat("/", config.getTrackingUrl(), uuid.toString()));
          log.debug("Tracking URL for built MJB from Wizard is: " + getTrackingURL());
          success = true;        } else {
          log.debug("Could not rename " + zipFile + " to " + renamedFile);
        }
      } else {
        log.debug("NOT scheduling MJB build job from Wizard -- no zip file generated, uuid=" + uuid);
      }

      return success;
    }

    public List<BudgesJbUploadFile> getJbUploadFileListForAgencies() {
      if (agencyTov == null) {
        agencyTov = new ArrayList<BudgesJbUploadFile>();
        List<BudgesJbUploadFile> tovList = getNavigation().isR2() ? BudgesContext.getJbUploadFileListForAgencies() : BudgesContext.getJbUploadFileListForP40Agencies();
        
        for (BudgesJbUploadFile file : tovList) {
          if (file.getBookDescription() != null && !"".equals(file.getBookDescription())){
            agencyTov.add(file);
          }
        }
      }

      return agencyTov;
    }

    public boolean getHasAttachments()
    {
      if (getJBFormData().getCoverLogoFile().getOriginalName() != null)
        return true;
      if (getJBFormData().getIntroFile().getOriginalName() != null)
        return true;
      if (getJBFormData().getSummaryFile().getOriginalName() != null)
        return true;
      if (getJBFormData().getR1File().getOriginalName() != null)
        return true;
      if (getJBFormData().getP1File().getOriginalName() != null)
        return true;
      if (getJBFormData().getAcronymsFile().getOriginalName() != null)
        return true;

      return getJBFormData().getHasSupplimentalFiles();
    }

    @Override
    public String getNextLabel(){
        return "Build Book >";
    }
    
    /**
     * Fix for CXE-8497
     * 
     * Check if the Prior Years data for the ProgramElement(s) are null
     * If yes, permanently set to 0
     * 
     * Same thing for the Project(s) of each ProgramElement
     * If the Prior Years data is null, permanently set to 0
     * 
     * @param programElements List of ProgramElement objects used in this Justification Book
     */
    private void priorYearsDataCheck(List<ProgramElement> programElements)
    {
      if (programElements == null) return;
      for (ProgramElement pe : programElements)
      {
        if (pe == null) continue;
        if (pe.getFundingAllPys() == null)
        {
          pe.setFundingAllPys(BigDecimal.ZERO);
        }
        for (Project project : pe.getProjects())
        {
          if (project == null) continue;
          if (project.getFundingAllPys() == null)
          {
            project.setFundingAllPys(BigDecimal.ZERO);
          }
        }
      }
    }
}
