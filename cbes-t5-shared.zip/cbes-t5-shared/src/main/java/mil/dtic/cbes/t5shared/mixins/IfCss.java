/*
 * $Id: SelectChangeSubmit.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.mixins;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;

/**
 * Apply a css class based on a certain condition.
 */
@Import(stack=CbesT5SharedModule.JQUERYSTACK, library="classpath:${cb.assetpath}/js/if.js")
public class IfCss
{
  @Parameter(required = true)
  private boolean cssTest;
  @Parameter(defaultPrefix = BindingConstants.LITERAL, value = "F90EC2F853B163B1") //an empty string would always come out as "null". So I stuck in a random number instead
  private String trueClass;
  @Parameter(defaultPrefix = BindingConstants.LITERAL, value = "F90EC2F853B163B1")
  private String falseClass;
  @Inject
  private JavaScriptSupport jsSupport;
  @InjectContainer
  private ClientElement element;
  
  void afterRender()
  {
    jsSupport.addScript(String.format("CBES.ifCss('#%s',%s,'%s','%s');", element.getClientId(), cssTest, trueClass, falseClass));
  }
}
