package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.IOException;

import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;


/**
 * Table of contents wizard page for Master Justification Book.
 */
public class MJBWizardP40TableOfContents extends MJBWizardPage
{
    @Property
    private MJBVolumeModel currentvol;
    
    @Property
    private boolean disableGenerateP1R1;
    
    @Property
    private String jbWizP40TableOfContentsHelp;
    
    protected Object onActivate() throws IOException {
      
      Object obj = super.onActivate();
      
      disableGenerateP1R1 = false;
      
      boolean generateRequired = config.isJbWizGenerateP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      boolean attachRequired = config.isJbWizAttachP1R1Required(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());      
      
      if(generateRequired) {
        disableGenerateP1R1 = true;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
            vol.getDaOptions().setGenerateP1(true);
            
            if(mfdata.getVolumes().size() > 1) 
            {
              vol.getDaOptions().setIncludeMasterP1(true);
              if(isDodServiceOrDodBigAgency()) {
                vol.getDaOptions().setIncludeMasterLineItemTocByBA(true);
                vol.getDaOptions().setIncludeMasterLineItemTocByTitle(true);
              }
            }
        }
      }
      if(attachRequired) {
        disableGenerateP1R1 = true;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          vol.getDaOptions().setGenerateP1(false);     
          
          if(mfdata.getVolumes().size() > 1) 
          {           
            vol.getDaOptions().setIncludeMasterP1(false);
            if(isDodServiceOrDodBigAgency()) {
              vol.getDaOptions().setIncludeMasterLineItemTocByBA(true);
              vol.getDaOptions().setIncludeMasterLineItemTocByTitle(true);
            }
          }
        }
      }
      if(!attachRequired && !generateRequired) {
        disableGenerateP1R1 = false;
        
        for(MJBVolumeModel vol : mfdata.getVolumes()) {
          vol.getDaOptions().setGenerateP1(true);     
          
          if(mfdata.getVolumes().size() > 1) 
          {         
            vol.getDaOptions().setIncludeMasterP1(true);
            if(isDodServiceOrDodBigAgency()) {
              vol.getDaOptions().setIncludeMasterLineItemTocByBA(true);
              vol.getDaOptions().setIncludeMasterLineItemTocByTitle(true);
            }
          }
        }
      }
      
      jbWizP40TableOfContentsHelp = config.getJbWizP40TableOfContentsHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());
      
      return obj;
    }
    
    public boolean isIncludeMasterLineItemTocByBADisabled() 
    {
      return isDodServiceOrDodBigAgency() && mfdata.getVolumes().size() > 1;
    }
    
    public boolean isIncludeMasterLineItemTocByTitleDisabled() 
    {
      return isDodServiceOrDodBigAgency() && mfdata.getVolumes().size() > 1;
    }    
}
