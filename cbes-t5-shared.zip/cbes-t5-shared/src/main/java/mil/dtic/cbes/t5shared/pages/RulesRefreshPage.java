package mil.dtic.cbes.t5shared.pages;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.submissions.validation.backend.ValidationService;

public class RulesRefreshPage
{
  @Inject
  private ValidationService validationService;


  @Log
  void onActivate()
  {
    validationService.markRulesCacheForReload();
  }
}
