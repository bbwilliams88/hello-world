package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.InjectPage;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SessionState;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.p40.validation.LineItemValidator;
import mil.dtic.cbes.p40.vo.LineItem;
import mil.dtic.cbes.p40.vo.jibx.LineItemList;
import mil.dtic.cbes.p40.vo.jibx.LineItemWrapper;
import mil.dtic.cbes.service.ValidationMessage;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.delegates.XmlValidationDelegate;
import mil.dtic.cbes.submissions.delegates.XmlValidationInfo;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.models.DbExhibitSelection;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.wizard.ExhibitSelectionPage;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.SendEmailOnInvalidXML2;


/**
 * P40 selection wizard page for MJB
 */
public class MJBWizardLiSelection extends MJBWizardPage
{
  private static final Logger log = CbesLogFactory.getLog(MJBWizardLiSelection.class);
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private LineItemValidator lineItemValidator;


  @InjectPage("P40Select")
  private ExhibitSelectionPage p40select;
  @Component(id = "xmlFile")
  private SavedUpload xmlFileComp;


  @SessionState
  private DbExhibitSelection selection;
  @Persist
  @Property
  private Boolean peSelect;
  @Persist
  private LineItemList selectedLisWrapped;
  @Persist
  private LineItemList uploadedLisWrapped;
  @Persist
  @Property
  private File xmlFile; // if Upload from XML is selected
  @SuppressWarnings("unused")
  @Property
  private String error;
  @SuppressWarnings("unused")
  @Property
  private String warning;


  @Property
  private String originalXmlFileName;

  @Property
  String jbWizP40ExhibitSelectHelp;

  private boolean xmlErrors;
  private boolean enableXmlFile;
  private boolean redirect;
  private boolean uploaded;
  private boolean errorsOrWarnings;
  private boolean triggerRefresh;


  @Override
  Object onActivate() throws IOException
  {
    Object activateValue = super.onActivate();

    if (activateValue == null)
      init();

    jbWizP40ExhibitSelectHelp = config.getJbWizP40ExhibitSelectHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());

    return activateValue;
  }


  void setupRender()
  {
    if (checkForJs(getJBFormData().getLineItemList()))
    {
      addErrorMessage("Selected P40s have hidden errors");
    }
  }



void afterRender()
  {
    // Enable/disable select link/file upload depending on radiobutton
    jsSupport.addScript("toggleLISelections(); jQuery('input.peselectradio').click(toggleLISelections);");
  }


  @Log
  void onSelectedFromXmlUpload()
  {
    uploaded = true;
  }
  
  @Log
  void onSelectedFromRefreshSelected()
  {
    selectedLisWrapped = null;
    triggerRefresh = true;
  }



  @Log
  @Override
  public void validate()
  {
    log.debug("Validating LI Selection");
    
    resetErrorMessages();
    if (uploaded && originalXmlFileName == null)
      addErrorMessage("You must upload an XML/ZIP File if you select the Upload Exhibit P-40s option.");

    if (!redirect){
      LineItemList newLineItems = isPeSelect() ? selectedLisWrapped : uploadedLisWrapped;
      getJBFormData().setLineItemList(newLineItems);
    }
  }


  @Log
  void onSelectedFromSelectExhibitsButton()
  {
    selectedLisWrapped = null;
    redirect = true;
  }


  @Log
  @Override
  public Object successResponse()
  {
    log.debug("********* isPeSelect = " + isPeSelect());
    if (uploaded)
    {
      log.debug("********* successResponse = UPLOADED");
      enableXmlFile = !isPeSelect();

      if (enableXmlFile && originalXmlFileName != null)
        processR2XmlFile(originalXmlFileName);

      return this;
    }
    else if (redirect)
    {
      p40select.setReturnPage(getClass());
      p40select.setReturnButton("Return to JB Wizard With Selections");
      return p40select;
    }
    else if (triggerRefresh)
    {
      selection.refreshLineItems();
    }

    return null;
  }


  public SavedUploadValidator getXmlFileValidator()
  {
    return new FileExtensionSavedUploadValidator("The supplied XML file does end in the extension .xml or .zip.", BudgesContentType.XML,
      BudgesContentType.ZIP);
  }


  public List<LineItem> getSelectedLis()
  {
    return selectedLisWrapped.getLineItemsUnWrapped();
  }


  public List<LineItem> getUploadedLis()
  {
    return uploadedLisWrapped.getLineItemsUnWrapped();
  }

  @Log
  private void init()
  {
    initSelected();
    if ((mfdata.getLineItemList() != null) && uploadedLisWrapped == null)
    {
      uploadedLisWrapped = new LineItemList();
      uploadedLisWrapped.setLineItems(mfdata.getLineItemList().getLineItems());
    }
    else if ((mfdata.getLineItemList() == null) && uploadedLisWrapped == null)
    {
      uploadedLisWrapped = new LineItemList();
      uploadedLisWrapped.setLineItems(new ArrayList<LineItemWrapper>());
    }
    LineItemList newLis = isPeSelect() ? selectedLisWrapped : uploadedLisWrapped;
    getJBFormData().setLineItemList(newLis);


    if (selectedLisWrapped.isHasErrors())
      addErrorMessage("Selected P40s have errors.");
  }


  private void initSelected()
  {
    if (isPeSelect() && selectedLisWrapped == null)
    {
      selectedLisWrapped =new LineItemList();
      getErrorMessages().clear();
      getWarningMessages().clear();
      List<LineItem> _selectedLis = selection.getLineItems();
      selectedLisWrapped = new LineItemList();
      selectedLisWrapped.setLineItems(new ArrayList<LineItemWrapper>());
      for (LineItem li : _selectedLis)
      {
        LineItemWrapper liw = new LineItemWrapper();
        liw.setLineItem(li);
        selectedLisWrapped.getLineItems().add(liw);
        liw.setHasErrors(li.isErrors());
        liw.setHasWarnings(li.isWarnings());
        selectedLisWrapped.setHasErrors(selectedLisWrapped.isHasErrors() || liw.isHasErrors());
        selectedLisWrapped.setHasWarnings(selectedLisWrapped.isHasWarnings() || liw.isHasWarnings());
      }
    }else if (selectedLisWrapped == null){
      selectedLisWrapped = new LineItemList();
    }

    log.debug("Initialized LineItemList, hasErrors = " + selectedLisWrapped.isHasErrors() + ", hasWarnings = " + selectedLisWrapped.isHasWarnings());
  }


  @Log
  private void processR2XmlFile(String originalName)
  {
    // resetXmlWarningMessages();

    log.debug("********* processXmlFile = " + originalName);

    // form stuff
    try
    {
      PreviewResultInfo pri = processXmlFile(originalName, xmlFile);
      if (pri.getLineItemList() != null)
      {
        uploadedLisWrapped = pri.getLineItemList();
        List<XmlValidationInfo> xviList = pri.getXmlValidationResultList();
        if (xviList != null)
        {
          for (XmlValidationInfo xvi : xviList)
          {
            uploadedLisWrapped.setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
            uploadedLisWrapped.setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());

            addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
            addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());
            // addXmlWarningMessage(WARNING_MESSAGE);
          }
        }
        return; // success
      }
      else
      {
        List<XmlValidationInfo> xviList = pri.getXmlValidationResultList();
        if (xviList != null)
        {
          for (XmlValidationInfo xvi : xviList)
          {
            uploadedLisWrapped.setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
            uploadedLisWrapped.setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());

            addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
            addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());
          }
        }
        addErrorMessage("Did not find any error-free P-40s.");
      }
    }
    catch (VirusScanException e)
    {
      log.error("", e);
      for (ValidationMessage vm : e.getErrorsList())
      {
        addErrorMessage(vm.getMessage());
      }
    }
    catch (IOException e)
    {
      log.error("", e);
      addErrorMessage("System Error while processing XML. Could not load R-2s from file.");
    }
    // any error, remove cached file from savedupload component
    xmlFileComp.delete();
  }


  @Log
  private PreviewResultInfo processXmlFile(String originalName, File xmlFile) throws VirusScanException, IOException
  {
    // actually perform xmltojava
    String destFileName = R2Storage.prependFileSettingToName(FileSetting.P40COLLECTION, xmlFile.getName());
    File scanned = R2Storage.scanAndPutInUpload(getJBFormData().getWorkingDirectory(), destFileName, xmlFile, originalName);
    BudgesFile bf = new BudgesFile(originalName, scanned, null);
    XmlValidationDelegate xvd = new XmlValidationDelegate( getJBFormData().getWorkingDirectory(), new SendEmailOnInvalidXML2(), runOnlyVerifiedRules()); // TODO
                                                                                                                                                               // fix
                                                                                                                                                               // email
    xvd.setScanEnabled(false);
    return xvd.doValidateXml(bf);
  }


  private boolean checkForJs(LineItemList _lineItemList)
  {
    if (_lineItemList != null && _lineItemList.getLineItems() != null)
      for (LineItemWrapper liw : _lineItemList.getLineItems())
      {
      if (!liw.getLineItem().getXmlValidity().isValid())
      {
        return true;
      }
      }
    return false;
  }


  private boolean isPeSelect()
  {
    if (peSelect == null)
      peSelect = true; // default to Select P-40s
    return peSelect;
  }


  public void setPeSelect(boolean b)
  {
    peSelect = b;
  }


  public void setUploadedLisWrapped(LineItemList x)
  {
    uploadedLisWrapped = x;
  }
}
