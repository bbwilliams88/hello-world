package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class DatatableJavaScriptStackUpdated extends AbstractJavaScriptStack
{
  public DatatableJavaScriptStackUpdated(AssetSource assetSource, SymbolSource symbolSource)
  {
    super(assetSource, symbolSource,
      new String[]{"${cb.assetpath}/js/jquery.dataTables.new.js","${cb.assetpath}/js/ColVis.js", "${cb.assetpath}/js/moment.min.js", "${cb.assetpath}/js/datetime-moment.js"}, new String[]{"${cb.assetpath}/css/datatable.css","${cb.assetpath}/css/ColVis.css","${cb.assetpath}/css/flick/jquery-ui-1.8.5.custom.css"});
  }

  @Override
  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(symbolSource.expandSymbols(path), null);
  }

  @Override
  public List<String> getStacks()
  {
    // DataTables depends upon the jQuery stack.
    return Collections.singletonList(CbesT5SharedModule.JQUERYSTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    List<String> modules = new ArrayList<String>();
    modules.add("datatables.net.js");
    return modules;
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
