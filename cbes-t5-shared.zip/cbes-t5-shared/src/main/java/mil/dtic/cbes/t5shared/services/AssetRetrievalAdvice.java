package mil.dtic.cbes.t5shared.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.plastic.MethodAdvice;
import org.apache.tapestry5.plastic.MethodInvocation;

import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;

/**
 * <p>Watches asset injection requests in Tapestry, catches and replaces
 * certain ones with it's own.
 * <p>Configured with assetoverrides.properties on the classpath.
 * <p>Exactly one override per key is allowed
 * <p>Set log level to trace to know what key to use
 * <p>Values can be arg{n}string or resultstring
 * <p>arg{n}blah will overwrite the nth argument with blah
 * <p>resultblah will overwrite the result with blah
 * <p>The n in arg{n} can only be from 0-9 (usually there only 3 arguments are available)=
 */
public class AssetRetrievalAdvice implements MethodAdvice
{
  private static final Logger log = CbesLogFactory.getLog(AssetRetrievalAdvice.class);
  private static final String overrideFile = "assetoverrides.properties";
  private static final String argOverride = "arg";
  private static final String resOverride = "result";
  private final Properties overrides;
  
  public AssetRetrievalAdvice() throws IOException
  {
    overrides = new Properties();
    InputStream is = null;
    try
    {
      is = getClass().getClassLoader().getResourceAsStream(overrideFile);
      if (is==null) throw new IOException("File not found on classpath: " + overrideFile);
      overrides.load(is);
    } finally {
      FileUtil.close(is);
    }
  }
  
  private String invToString(MethodInvocation inv)
  {
    StringBuilder sb = new StringBuilder();
    sb.append(inv.getMethod().getName());
    sb.append("-");
    for (int i = 0; i < inv.getMethod().getParameterTypes().length; i++)
    {
      sb.append(inv.getParameter(i));
      if (i+1 < inv.getMethod().getParameterTypes().length)
      {
        sb.append("-");
      }
    }
    return sb.toString();
  }
  
  public void advise(MethodInvocation inv)
  {
    String invStr = invToString(inv);
    log.trace(invStr);
    Object o = overrides.get(invStr);
    if (o!=null)
    {
      log.trace("Override: " + o);
      String s = o.toString();
      if (s.startsWith(argOverride) && s.length() > argOverride.length())
      {
        // replace argument
        int index = s.charAt(argOverride.length()) - 48; // don't feel like catching NumberFormatException
        if (index>=0 && index < inv.getMethod().getParameterTypes().length) {
          inv.setParameter(index, s.substring(argOverride.length() + 1));
        }
        else log.error("Could not parse arg override");
      } else log.error("Could not parse arg override");
      inv.proceed();
      if (s.startsWith(resOverride) && s.length() > resOverride.length())
      {
        // replace result
        inv.setReturnValue(s.substring(resOverride.length()));
        int index = s.charAt(resOverride.length()) - 48;
        if (index>=0 && index < inv.getMethod().getParameterTypes().length) {
          inv.setParameter(index, s.substring(4));
        }
        
      } else if (s.startsWith(resOverride)) log.error("Could not parse result override");
    } else {
      inv.proceed();
    }
    log.trace(inv.getReturnValue());
  }
}