package mil.dtic.cbes.t5shared.services;


import java.io.IOException;

import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.ioc.Configuration;
import org.apache.tapestry5.ioc.MappedConfiguration;
import org.apache.tapestry5.ioc.OrderedConfiguration;
import org.apache.tapestry5.ioc.ServiceBinder;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.Local;
import org.apache.tapestry5.services.BindingFactory;
import org.apache.tapestry5.services.BindingSource;
import org.apache.tapestry5.services.ComponentEventLinkEncoder;
import org.apache.tapestry5.services.LibraryMapping;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.RequestFilter;
import org.apache.tapestry5.services.RequestHandler;
import org.apache.tapestry5.services.Response;
import org.apache.tapestry5.services.javascript.JavaScriptStack;
import org.chenillekit.tapestry.core.bindings.OgnlBindingFactory;
import org.chenillekit.tapestry.core.factories.ListBindingFactory;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class CbesT5SharedModule
{	
  private static final Logger log = CbesLogFactory.getLog(CbesT5SharedModule.class);

  public static final String SHAREDPKG = "mil/dtic/cbes/t5shared";
  public static final String JQUERYSTACK = "jquery";
  public static final String JQUERYCOOKIESTACK = "jquerycookie";
  public static final String JQUERYTOOLSSTACK = "jquerytools";
  public static final String JQUICORESTACK = "core";
  public static final String JQUIINTERACTIONSSTACK = "jquery.ui.interactions";
  public static final String JQUIWIDGETSTACK = "jquery.ui.widgets";
  public static final String JQUIEFFECTSTACK = "jquery.ui.effects";
  public static final String DATATABLESTACK = "datatables";

  public static final String BOOTSTRAPSTACK = "bootstrap";
  public static final String DROPZONESTACK = "dropzone";
  public static final String DATATABLESUPDATED = "datatablesUpdated";
  
  public static final String DATATABLESBUTTONS = "datatablesButtons";

  // These two are used by ProgressDownload
  public static final String SHOW_PROGRESS_JS_FUNC = "show.progress.js";
  public static final String HIDE_PROGRESS_JS_FUNC = "hide.progress.js";
  public static final String BEAUTYTIPSSTACK = "beautytips";
  
  public static void bind(ServiceBinder binder)
  {
    binder.bind(BindingFactory.class, SelectModelBindingFactory.class).withId("SelectModelBindingFactory");
    binder.bind(ComponentEventLinkEncoder.class, PostedComponentEventLinkEncoder.class).withId("PostedComponentEventLinkEncoder");
    binder.bind(UserAgent.class);
  }

  public static void contributeServiceOverride(
    MappedConfiguration<Class<?>,Object> configuration,
    @Local ComponentEventLinkEncoder postedEncoder)
  {
    configuration.add(ComponentEventLinkEncoder.class, postedEncoder);
  }

  public void contributeComponentClassResolver(Configuration<LibraryMapping> configuration)
  {
    configuration.add(new LibraryMapping("cb", "mil.dtic.cbes.t5shared"));
  }

  public static void contributeFactoryDefaults(MappedConfiguration<String, String> configuration)
  {
    configuration.add("cb.assetpath", SHAREDPKG);
    configuration.add(SHOW_PROGRESS_JS_FUNC, "showProgress");
    configuration.add(HIDE_PROGRESS_JS_FUNC, "hideProgress");
  }

  public static void contributeApplicationDefaults(MappedConfiguration<String,String> configuration)
  {
	  ConfigService config = BudgesContext.getConfigService();
    configuration.add(SymbolConstants.HOSTNAME, config.getHostName());
  }

  public static void contributeBindingSource(MappedConfiguration<String, BindingFactory> configuration, BindingSource bindingSource)
  {
    configuration.add("list", new ListBindingFactory(bindingSource));
    configuration.add("ognl", new OgnlBindingFactory());
  }

  public static void contributeJavaScriptStackSource(MappedConfiguration<String, JavaScriptStack> configuration)
  {
    configuration.addInstance(JQUERYSTACK, JQueryJavaScriptStack.class);
    configuration.addInstance(JQUERYCOOKIESTACK, JQueryCookieJavaScriptStack.class);
    configuration.addInstance(JQUERYTOOLSSTACK, JQueryToolsJavaScriptStack.class);
    configuration.addInstance(DATATABLESTACK, DatatableJavaScriptStack.class);
    configuration.addInstance(JQUIINTERACTIONSSTACK, JQueryUiInteractionsStack.class);
    configuration.addInstance(JQUIEFFECTSTACK, JQueryUiInteractionsStack.class);
    configuration.addInstance(BEAUTYTIPSSTACK, BeautyTipsJavaScriptStack.class);

    configuration.addInstance(DATATABLESUPDATED, DatatableJavaScriptStackUpdated.class); // The new version of DataTables.
    configuration.addInstance(DATATABLESBUTTONS, DatatablesButtonsStack.class);          // A new extension that adds buttons to the table
    configuration.addInstance(BOOTSTRAPSTACK, BootStrapStack.class);
    configuration.addInstance(DROPZONESTACK, DropZoneStack.class);
  }

  public RequestFilter buildTimingFilter()
  {
    return new RequestFilter() {
      @Override
      public boolean service(Request request, Response response, RequestHandler handler) throws IOException {
        long startTime = System.currentTimeMillis();
        String path = request.getPath();
        boolean doit = !path.contains("asset");
        try {
          return handler.service(request, response);
        } finally {
          long elapsed = System.currentTimeMillis() - startTime;
          if (doit)
            log.info(String.format("Request time: %d ms " + path, elapsed));
        }
      }
    };
  }

  public void contributeRequestHandler(OrderedConfiguration<RequestFilter> configuration,
    @Local RequestFilter filter)
  {
	
    configuration.add("Timing", filter);
    configuration.add("IEStandardModeHeader", new IEStandardModeHeader());
  }
}