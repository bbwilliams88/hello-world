package mil.dtic.cbes.t5shared.pages;

import org.apache.tapestry5.ioc.annotations.InjectService;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.t5shared.pages.mjb.MJBWizardPage;
import mil.dtic.cbes.t5shared.utils.wizard.BaseMjbWizardNavigation;
import mil.dtic.utility.CbesLogFactory;

/**
 * Shortcut to get into the wizard.
 */
public class MJBWizard
{
    private static final Logger log = CbesLogFactory.getLog(MJBWizard.class);

    @InjectService("MJBWizardNavigation")
    private BaseMjbWizardNavigation navigation;

    @SuppressWarnings("unchecked")
    Class<MJBWizardPage> onActivate()
    {
        log.debug("MJBWizard: Redirecting to " + navigation.getPageEntry(0).getPageClass());

        return (Class<MJBWizardPage>) navigation.getPageEntry(0).getPageClass();
    }
}
