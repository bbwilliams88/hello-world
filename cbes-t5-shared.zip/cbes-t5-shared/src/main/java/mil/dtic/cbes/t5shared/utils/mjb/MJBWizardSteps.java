package mil.dtic.cbes.t5shared.utils.mjb;

public enum MJBWizardSteps
{  
  BASIC_INFO_STEP,
  PE_SELECTION_STEP,
  VOLUMES_STEP,
  TABLE_OF_VOLUMES_STEP,
  TABLE_OF_CONTENTS_STEP,
  PES_BY_BA_STEP,  
  FILE_ATTACHMENTS_STEP,
  SUMMARY_AND_BUILD_STEP,
  ASYNC_CONFIRMATION_STEP;
    
  public static MJBWizardSteps firstStep()
  {
    return BASIC_INFO_STEP;
  }

  public static MJBWizardSteps finalStep()
  {
    return ASYNC_CONFIRMATION_STEP;
  }
  
  public MJBWizardSteps nextStep()
  {
    MJBWizardSteps[] allSteps = MJBWizardSteps.values();
    int nextOrdinalVal = ordinal() + 1;
    if (nextOrdinalVal >= allSteps.length)
      return finalStep();
    return allSteps[nextOrdinalVal];
  }

  public MJBWizardSteps prevStep()
  {
    MJBWizardSteps[] allSteps = MJBWizardSteps.values();
    int nextOrdinalVal = ordinal() - 1;
    if (nextOrdinalVal < 0)
      return firstStep();
    return allSteps[nextOrdinalVal];
  }

  public String getStepXOfYString()
  {
    return "Step " + (ordinal() + 1) + " of " + values().length;
  }
}
