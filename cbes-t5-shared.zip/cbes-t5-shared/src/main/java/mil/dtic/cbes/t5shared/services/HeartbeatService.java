package mil.dtic.cbes.t5shared.services;



/**
 * This is used to maintain a list of running VMs with time of last response.
 * @author aahmed
 *
 */
public interface HeartbeatService extends Runnable
{
  /** Pass the tapestry-generated proxied version to the polling thread to allow service reload to work */
  void start(HeartbeatService proxy);
  void stop();
}
