package mil.dtic.cbes.t5shared.pages.mjb;


/**
 * Confirmation wizard page for Master Justification Book.
 */
public class MJBWizardConfirmation extends MJBWizardPage
{
    /**
     * Called when the user wants to reset the wizard and start over.
     *
     * @return The basic information wizard page.
     */
    Class<MJBWizardBasicInformation> onActionFromStartOver()
    {
        resetAll();

        return MJBWizardBasicInformation.class;
    }
}
