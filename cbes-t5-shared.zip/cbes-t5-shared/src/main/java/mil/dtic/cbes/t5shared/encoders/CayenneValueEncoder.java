package mil.dtic.cbes.t5shared.encoders;

import java.util.List;

import org.apache.cayenne.DataObject;
import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.p40.vo.BudgetSubActivity;

/**
 * A copy of GenericValueEncoder that takes advantage of Cayenne nested properties
 * @author aahmed
 *
 */
// FIXME: Is this used for anything?
public class CayenneValueEncoder<T extends DataObject> implements ValueEncoder<T> {

  private List<T> list;
  private final String prop;
  
  public CayenneValueEncoder(List<T> list, String fieldName) {
    this.list = list;
    this.prop = fieldName;
  }

  @Override
public String toClient(T obj) {
    if(obj instanceof BudgetSubActivity){
      return obj.getObjectId()+ "";
    }
    
    return obj.readNestedProperty(prop) + "";
  }

  @Override
public T toValue(String string) {
    for (T obj : list) {      
      if(toClient(obj).equals(string)){
        return obj;
      }
    }
    return null;
  }
}