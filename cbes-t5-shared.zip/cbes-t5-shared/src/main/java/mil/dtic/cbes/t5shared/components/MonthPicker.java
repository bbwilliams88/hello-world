package mil.dtic.cbes.t5shared.components;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.tapestry5.Binding;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.FieldValidationSupport;
import org.apache.tapestry5.FieldValidator;
import org.apache.tapestry5.MarkupWriter;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.ValidationTracker;
import org.apache.tapestry5.annotations.Environmental;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.corelib.base.AbstractField;
import org.apache.tapestry5.ioc.Messages;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.internal.util.InternalUtils;
import org.apache.tapestry5.services.ComponentDefaultProvider;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.utility.CbesLogFactory;

/**
 * Adds a month picker popup to a textfield
 * http://tawus.wordpress.com/2011/04/14/creating-a-simple-datetime-field-in-tapestry5/
 */
@Import(library={
  "classpath:${cb.assetpath}/js/jquery.mtz.monthpicker.js",
  "classpath:${cb.assetpath}/js/monthpicker.js"
},stylesheet= { "classpath:${cb.assetpath}/css/monthpicker.css", "context:/css/jquery-ui-1.8.12.autocomplete.css"}, stack=CbesT5SharedModule.JQUICORESTACK)
public class MonthPicker extends AbstractField
{
  private static final Logger log = CbesLogFactory.getLog(MonthPicker.class);
  @Inject
  private ComponentResources resources;
  @Inject
  private JavaScriptSupport jsSupport;
  @Inject
  private FieldValidationSupport fieldValidationSupport;
  @Inject
  private ComponentDefaultProvider defaultProvider;
  @Inject
  private Request request;
  @Inject
  private Messages messages;
  @Inject
  private Locale locale;
  @Environmental
  private ValidationTracker validationTracker;


  private static final String defaultDateFormat = "MM/yyyy";


  @Parameter(required = true, principal = true, autoconnect = true)
  private Date value;
  @Parameter(allowNull = false, defaultPrefix = BindingConstants.LITERAL)
  private DateFormat format;
  @Parameter(defaultPrefix = BindingConstants.VALIDATE)
  private FieldValidator<Object> validate;


  void beginRender(MarkupWriter writer) {
    String value = validationTracker.getInput(this);

    if (value == null) {
      value = formatCurrentValue();
    }

    writer.element("input", "type", "text", "value", value, "id",
      getClientId(), "name", getControlName());
    if (isDisabled()) {
      writer.attributes("disabled", "disabled");
    }

    putPropertyNameIntoBeanValidationContext("value");
    validate.render(writer);
    removePropertyNameFromBeanValidationContext();
    resources.renderInformalParameters(writer);
    decorateInsideField();

    writer.end();
  }

  void afterRender()
  {
    jsSupport.addScript("CBES.monthPicker('#%s')", getClientId());
  }

  DateFormat defaultFormat() {
    final DateFormat dateFormat;
    if ("locale".equalsIgnoreCase(defaultDateFormat)) {
      dateFormat = DateFormat.getDateInstance(DateFormat.SHORT, locale);
    } else {
      dateFormat = new SimpleDateFormat(defaultDateFormat);
    }
    dateFormat.setLenient(false);
    return dateFormat;
  }

  final Binding defaultValidate() {
    Binding b = defaultProvider.defaultValidatorBinding("value", resources);
    log.debug(b.get()+"");
    return b;
  }


    @Override
    protected void processSubmission(String elementName)
    {
        Date   parseValue = null;
        String value      = request.getParameter(elementName);

        format.setLenient(false);
        validationTracker.recordInput(this, value);

        try
        {
            if (InternalUtils.isNonBlank(value))
            {
                parseValue = format.parse(value);
                // if a year below 1990 is entered throw an IAE
                // this prevents 05/12 from being parsed to 05/0012
                // and other strange dates
                if (parseValue.before(format.parse("1/1990")))
                    throw new IllegalArgumentException();
            }
        }
        catch (ParseException pe)
        {
            validationTracker.recordError(this, messages.format("date-value-not-parseable", value));
            return;
        }
        catch (IllegalArgumentException pe)
        {
            validationTracker.recordError(this, messages.format("date-value-too-early", value));
            return;
        }
        putPropertyNameIntoBeanValidationContext("value");
        try
        {
            fieldValidationSupport.validate(parseValue, resources, validate);
            this.value = parseValue;
        }
        catch (ValidationException ve)
        {
            validationTracker.recordError(this, ve.getMessage());
        }

        removePropertyNameFromBeanValidationContext();
    }

  private String formatCurrentValue() {
    final String value;
    if (this.value == null) {
      value = "";
    } else {
      value = format.format(this.value);
    }
    return value;
  }

  @Override
  public boolean isRequired() {
    return validate.isRequired();
  }
}
