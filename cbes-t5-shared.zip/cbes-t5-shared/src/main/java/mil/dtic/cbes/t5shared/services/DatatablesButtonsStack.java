package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class DatatablesButtonsStack extends AbstractJavaScriptStack
{

    public DatatablesButtonsStack(AssetSource assetSource, SymbolSource symbolSource)
    {
      super(assetSource, symbolSource,
        new String[]{"${cb.assetpath}/js/dataTables.buttons.min.js", "${cb.assetpath}/js/buttons.colVis.min.js", "${cb.assetpath}/js/buttons.html5.min.js"}, new String[]{"${cb.assetpath}/css/datatable.css","${cb.assetpath}/css/buttons.dataTables.min.css"});
    }

    @Override
    protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
    {
      return assetSource.getClasspathAsset(symbolSource.expandSymbols(path), null);
    }

    @Override
    public List<String> getStacks()
    {
      // DataTables depends upon the jQuery stack.
      return Collections.singletonList(CbesT5SharedModule.DATATABLESUPDATED);
    }

    @Override
    public List<String> getModules() {
      // TODO Might need to look into this more
      return new ArrayList<String>();
    }

    @Override
    public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
      // TODO This should be fine
      return JavaScriptAggregationStrategy.DO_NOTHING;
    }
}
