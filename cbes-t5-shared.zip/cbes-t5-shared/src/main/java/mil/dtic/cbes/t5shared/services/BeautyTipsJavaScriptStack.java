package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.assets.AssetPathConstructor;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;
import org.apache.tapestry5.services.javascript.JavaScriptStack;
import org.apache.tapestry5.services.javascript.StylesheetLink;

/**
 * Tapestry stack for importing BeautyTips resources.
 */
public class BeautyTipsJavaScriptStack implements JavaScriptStack
{
  private final Asset[] assets;

  public BeautyTipsJavaScriptStack(SymbolSource symbolSource, AssetSource assetSource, AssetPathConstructor assetPathConstructor)
  {
    this.assets = new Asset[] {
      assetSource.getAsset(null, symbolSource.expandSymbols("${cb.assetpath}/js/excanvas.compiled.js"), null),
      assetSource.getAsset(null, symbolSource.expandSymbols("${cb.assetpath}/js/jquery.bt.js"), null),
      assetSource.getAsset(null, symbolSource.expandSymbols("${cb.assetpath}/js/bt.defaults.js"), null)      
    };
  }

  public String getInitialization()
  {
    return null;
  }

  public List<Asset> getJavaScriptLibraries()
  {
    return Arrays.asList(assets);
  }

  public List<StylesheetLink> getStylesheets()
  {
    return Collections.emptyList();
  }

  public List<String> getStacks()
  {
    return Collections.emptyList();
  }
  
  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
