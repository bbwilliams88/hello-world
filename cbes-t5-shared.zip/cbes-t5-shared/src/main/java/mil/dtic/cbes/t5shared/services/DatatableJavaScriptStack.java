package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class DatatableJavaScriptStack extends AbstractJavaScriptStack
{
  public DatatableJavaScriptStack(AssetSource assetSource, SymbolSource symbolSource)
  {
    super(assetSource, symbolSource,
      new String[]{"${cb.assetpath}/js/jquery.dataTables.js","${cb.assetpath}/js/ColVis.js"}, new String[]{"${cb.assetpath}/css/datatable.css","${cb.assetpath}/css/ColVis.css","${cb.assetpath}/css/flick/jquery-ui-1.8.5.custom.css"});
  }

  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(symbolSource.expandSymbols(path), null);
  }

  public List<String> getStacks()
  {
    //load jquery stack first
    return Collections.singletonList(CbesT5SharedModule.JQUERYSTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
