package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.assets.AssetPathConstructor;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

/**
 * Tapestry stack for importing Bootstrap resources.
 */
public class BootStrapStack extends  AbstractJavaScriptStack
{
  public BootStrapStack(SymbolSource symbolSource, AssetSource assetSource, AssetPathConstructor assetPathConstructor)
  {
	  super(assetSource, symbolSource,
	      new String[]{"META-INF/assets/js/bootstrap.js"}, new String[]{"META-INF/assets/css/bootstrap.min.css"});
   }

  @Override
  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(symbolSource.expandSymbols(path), null);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
