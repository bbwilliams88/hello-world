package mil.dtic.cbes.t5shared.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.Symbol;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.UpdateListenerHub;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.FileUtil;


/**
 * Store list of running VMs in a json file in /upload/r2. This is broken at the
 * moment
 * 
 * @author aahmed
 * 
 */
public class FileHeartbeatServiceImpl implements HeartbeatService
{
  private static final Logger log = CbesLogFactory.getLog(FileHeartbeatServiceImpl.class);
  // @Inject
  // private ApplicationContext applicationContext;
  @Inject
  @Symbol(SymbolConstants.PRODUCTION_MODE)
  private boolean productionMode;
  @Inject
  private UpdateListenerHub updateListenerHub;



  @Inject
  private ConfigService config;


  private ScheduledFuture<?> task;


  public void start(HeartbeatService proxy)
  {
    int freq = config.getP40HeartbeatFreq();
    task = Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(proxy, 0, freq, TimeUnit.SECONDS);
  }


  @Override
  public void stop()
  {
    log.trace("stop");
    if (task != null)
      task.cancel(false);
  }


  @Override
  public void run()
  {
    try
    {
      log.error("runnnnn4!");
      String heartbeatFileName = config.getP40HeartbeatFileName();
      maybeCreateFile(heartbeatFileName);
      checkUpdateHeartbeat(heartbeatFileName);
    }
    catch (RuntimeException e)
    {
      log.error("Uncaught exception", e);
    }
    if (!productionMode)
    {
      updateListenerHub.fireCheckForUpdates(); // hot-reload in local env
    }
  }


  private void maybeCreateFile(String heartbeatFileName)
  {
    File uploadr2 = new File("/upload/r2/touchfiles"); // doesn't matter if this
                                                       // isn't the directory
                                                       // used in the config
                                                       // table
    if (!uploadr2.exists())
    {
      if (uploadr2.mkdir())
        log.info("Created " + uploadr2);
    }
    File heartbeatFile = new File(heartbeatFileName);
    if (!heartbeatFile.exists())
    {
      try
      {
        if (!heartbeatFile.createNewFile())
        {
          log.debug("heartbeat file was already created by someone else");
        }
      }
      catch (IOException e)
      {
        log.error("Error creating heartbeat file " + heartbeatFileName, e);
      }
    }
  }


  private void checkUpdateHeartbeat(String heartbeatFileName)
  {
    String queueName = config.getQueueName();
    String thisHost = null;
    FileInputStream fis = null;
    FileLock lock;
    int maxIdleInterval = 30;
    long maxIdleInMillis = maxIdleInterval * 1000L;
    List<String> timedOutHosts = new ArrayList<String>(1);
    try
    {
      thisHost = InetAddress.getLocalHost().getHostName();
    }
    catch (UnknownHostException e)
    {
      log.error("", e);
    }
    try
    {
      fis = new FileInputStream(new File(heartbeatFileName));
      log.error("trying lock");
      lock = fis.getChannel().tryLock(0L, Long.MAX_VALUE, true);
      log.error("lock " + lock);
      if (lock != null)
      {
        String json = IOUtils.toString(fis);
        JSONObject queueList = new JSONObject(json);
        JSONObject hostList = (JSONObject) queueList.opt(queueName);
        hostList = hostList == null ? new JSONObject() : hostList;
        JSONObject newHostList = new JSONObject();
        long now = new Date().getTime();
        if (thisHost != null)
        {
          newHostList.put(thisHost, now);
          for (String host : hostList.keys())
          {
            long time = hostList.getLong(host);
            if (thisHost.equals(host))
              time = now;
            if ((now - time) > maxIdleInMillis)
            {
              log.error("Found timed-out heartbeat, host=" + host + " time=" + new Date(time));
              timedOutHosts.add(host);
              log.error("Removing...");
              continue;
            }
            newHostList.put(host, time);
          }
          queueList.put(queueName, newHostList);
        }
      }
    }
    catch (IOException e)
    {
      log.error("", e);
    }
    finally
    {
      FileUtil.close(fis);
    }
  }
}
