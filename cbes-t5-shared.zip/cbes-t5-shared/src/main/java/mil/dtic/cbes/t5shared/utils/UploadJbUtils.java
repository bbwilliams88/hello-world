package mil.dtic.cbes.t5shared.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.encryption.BadSecurityHandlerException;
import org.apache.tapestry5.ValidationException;

import mil.dtic.cbes.jb.JBSupplementalDoc;
import mil.dtic.cbes.jb.JustificationBook;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.jb.MasterJustificationBook;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.delegates.BudgesUploadFileT5;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.utility.UploadPdfUtils;

public class UploadJbUtils 
{
  //uses the UploadPdfUtils unwrap method with some additional handling for JBook zzz attachments
  public static List<File> unwrapJbookFile(File jbFile, boolean isMjb) throws ValidationException, IOException, VirusScanException, CryptographyException, BadSecurityHandlerException {
    
    List<File> zzzFiles = new ArrayList<File>();
    
    // return empty list if argument is null
    if ((jbFile == null) ||(jbFile.getName() == null)){
      return zzzFiles;
    }
    
    String fileExt = FilenameUtils.getExtension(jbFile.getName()).toLowerCase();
    String fileName = null;
    
    // if file is already a zip or zzz, we can return it as-is
    if (StringUtils.equals(fileExt, "zzz") || StringUtils.equals(fileExt, "zip"))
    {
      zzzFiles.add(jbFile);
    }
    
    // if file is a PDF, we have to pick whether to use the JB or MJB attachment
    else
    {
      List<File> jbAttachments = UploadPdfUtils.unwrapPdfFile(jbFile);
      
      if(CollectionUtils.isEmpty(jbAttachments)) {
        throw new ValidationException("Couldn't find any valid .zip files or .zzz attachments.");
      }
      
      for(File f : jbAttachments) {
        fileName = f.getName().toLowerCase();
        fileExt = FilenameUtils.getExtension(fileName).toLowerCase();
        
//        if( (StringUtils.equals(fileExt,"zzz") || StringUtils.equals(fileExt,"zip")) && StringUtils.contains(fileName, "justificationbook") ) {
//          if (isMjb == fileName.contains("master")) {
//            zzzFiles.add(f);
//          }
//        }
        
        if( (StringUtils.equals(fileExt,"zzz") || StringUtils.equals(fileExt,"zip")) && StringUtils.contains(fileName, "jb") ) {
            if (isMjb == fileName.contains("mjb")) {
              zzzFiles.add(f);
            }
          }
        
      }
    }
    
    if(CollectionUtils.isEmpty(zzzFiles)) {
      throw new ValidationException("PDF attachments did not contain a .zzz file of type " + (isMjb ? "MasterJustificationBook" : "JustificationBook"));
    }
    
    return zzzFiles;
  }
  
  public static MJBVolumeModel jbToMJBVolModel(JustificationBook x, boolean overwriteDaOptions)
  {
    if (x == null){
      return null;
    }
    
    MJBVolumeModel ans = new MJBVolumeModel();
    ans.setAcronymsFile(x.getAcronymDoc() != null);
    ans.setCostFile(x.getCostDoc() != null);
    ans.setIntroFile(x.getIntroductionDoc() != null);
    ans.setSummaryFile(x.getSummaryDoc() != null);
    ans.setP1File(x.getP1() != null);
    
    if (x.getDocAssemblyOptions() != null && overwriteDaOptions == false)
    {
      ans.getDaOptions().setGenerateLineItemTocByBA(x.getDocAssemblyOptions().isGenerateLineItemTocByBA());
      ans.getDaOptions().setGenerateLineItemTocByTitle(x.getDocAssemblyOptions().isGenerateLineItemTocByTitle());
      ans.getDaOptions().setGenerateP1(x.getDocAssemblyOptions().isGenerateP1());
      ans.getDaOptions().setGenerateP1m(x.getDocAssemblyOptions().isGenerateP1m());
      ans.getDaOptions().setGenerateR1(x.getDocAssemblyOptions().isGenerateR1());
      ans.getDaOptions().setGenerateR1c(x.getDocAssemblyOptions().isGenerateR1c());
      ans.getDaOptions().setGenerateR1d(x.getDocAssemblyOptions().isGenerateR1d());
      ans.getDaOptions().setGenerateR1Summary(x.getDocAssemblyOptions().isGenerateR1Summary());
      ans.getDaOptions().setGenerateProgramElementTocByBA(x.getDocAssemblyOptions().isGenerateProgramElementTocByBA());
      ans.getDaOptions().setGenerateProgramElementTocByTitle(x.getDocAssemblyOptions().isGenerateProgramElementTocByTitle());
      ans.getDaOptions().setSuppressSubExhibits(x.getDocAssemblyOptions().isSuppressSubExhibits());
      ans.getDaOptions().setIncludeMasterLineItemTocByBA(x.getDocAssemblyOptions().isIncludeMasterLineItemTocByBA());
      ans.getDaOptions().setIncludeMasterLineItemTocByTitle(x.getDocAssemblyOptions().isIncludeMasterLineItemTocByTitle());
      ans.getDaOptions().setIncludeMasterP1(x.getDocAssemblyOptions().isIncludeMasterP1());
      ans.getDaOptions().setIncludeMasterP1m(x.getDocAssemblyOptions().isIncludeMasterP1m());
      ans.getDaOptions().setIncludeTov(x.getDocAssemblyOptions().isIncludeTov());
      ans.getDaOptions().setIncludeMasterR1(x.getDocAssemblyOptions().isIncludeMasterR1());
      ans.getDaOptions().setIncludeMasterR1c(x.getDocAssemblyOptions().isIncludeMasterR1c());
      ans.getDaOptions().setIncludeMasterR1d(x.getDocAssemblyOptions().isIncludeMasterR1d());
      ans.getDaOptions().setIncludeMasterR1Summary(x.getDocAssemblyOptions().isIncludeMasterR1Summary());
      ans.getDaOptions().setIncludeMasterProgramElementTocByBA(x.getDocAssemblyOptions().isIncludeMasterProgramElementTocByBA());
      ans.getDaOptions().setIncludeMasterProgramElementTocByTitle(x.getDocAssemblyOptions().isIncludeMasterProgramElementTocByTitle());
    }
    
    if (x.getJbi()!= null){
      ans.setNumber(x.getJbi().getNumber());
      ans.setDescription(x.getJbi().getDescription());
    }
    
    if (x.getLineItemList() != null)
    {
      ans.setLineItems(x.getLineItemList().getLineItemsUnWrapped());
    }
    
    if (x.getR2ExhibitList() != null)
    {
      ArrayList<ProgramElement> pes = new ArrayList<ProgramElement>();
      
      for (R2Exhibit e : x.getR2ExhibitList().getR2Exhibits())
      {
        pes.add(e.getProgramElement());
      }
      
      ans.setProgramElements(pes);
    }
    
    if (x.getCoverDoc() != null && x.getCoverDoc().getTitle() != null)
    {
      ans.setTitle(x.getCoverDoc().getTitle());
    }
    
    return ans;
  }
  

  public static MJBVolumeModel jbiToMJBVolModel(JustificationBookInfo x, List<BudgesUploadFileT5> supFiles)
  {
    if (x.getJb().getJbi() == null){
      x.getJb().setJbi(x); // I have no idea why this is necessary. I just saw that it wasn't set so...
    }
    
    MJBVolumeModel ans = jbToMJBVolModel(x.getJb(), false);
    
    int i = 0;
    
    for (BudgesUploadFileT5 supFile : supFiles)
    {
      if (x.getJb().getSupplementalDocCollection() != null)
      {
        for (JBSupplementalDoc ef : x.getJb().getSupplementalDocCollection().getSupplementalDocList())
        {
          if (supFile.getUploadFile().getAbsolutePath().equals(ef.getAbsoluteFileName()))
          {
            ans.getSupplementalFiles()[i] = true;
          }
        }
      }
      
      i++;
    }
    
    ans.setSuperVolume(x.getNumber());
    
    return ans;
  }
  
  public static List<MJBVolumeModel> getVolumeModels(MasterJustificationBook mjb, List<BudgesUploadFileT5> supFiles)
  {
    ArrayList<MJBVolumeModel> ans = new ArrayList<MJBVolumeModel>();
    for (JustificationBookGroup jbg : mjb.getJbgList())
    {
      for (JustificationBookInfo jbi : jbg.getJbiList())
      {
        ans.add(UploadJbUtils.jbiToMJBVolModel(jbi, supFiles));
      }
    }
    
    return ans;
  }
}
