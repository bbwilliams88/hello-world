
package mil.dtic.cbes.t5shared.mixins;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ClientElement;
import org.apache.tapestry5.ComponentAction;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.EventConstants;
import org.apache.tapestry5.MarkupWriter;
import org.apache.tapestry5.TrackableComponentEventCallback;
import org.apache.tapestry5.annotations.Environmental;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectContainer;
import org.apache.tapestry5.annotations.MixinAfter;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.services.FormSupport;
import org.apache.tapestry5.services.Heartbeat;
import org.apache.tapestry5.services.Request;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import com.google.common.collect.Iterables;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
/**
 * Mixin to allow any element to submit a form and trigger an event 
 * Based on http://tinybits.blogspot.com/2010/05/mixin-to-allow-any-element-to-submit.html
 */
@MixinAfter
@Import(stack=CbesT5SharedModule.JQUERYSTACK, library="../js/anysubmit.js")
public class AnySubmit
{
  /**
   * The name of the event that will be triggered if this component is the cause of the form submission. The default
   * is "selected".
   */
  @Parameter(allowNull = false, defaultPrefix = BindingConstants.LITERAL)
  private String event = EventConstants.SELECTED;

  @Parameter(defaultPrefix = BindingConstants.LITERAL)
  private String clientEvent = "change";

  /**
   * The value that will be made available to event handler method of this component when the form is
   * submitted.
   */
  @Parameter
  private Object[] context;

  /**
   * If true (the default), then any notification sent by the component will be deferred until the end of the form
   * submission (this is usually desirable).
   */
  @Parameter
  private boolean defer = true;

  /** Trigger a tapestry submitmode=CANCEL to discard submitted data */
  @Parameter(value="false")
  @Property
  private boolean readOnly;

  @InjectContainer
  private ClientElement container;

  @Inject
  private ComponentResources resources;

  @Inject
  private JavaScriptSupport jsSupport;

  @Environmental
  private FormSupport formSupport;

  @Environmental
  private Heartbeat heartbeat;

  @Inject
  private Request request;

  @Environmental
  private TrackableComponentEventCallback<?> eventCallback;

  @SuppressWarnings("serial")
  private static class ProcessSubmission implements ComponentAction<AnySubmit> {

    private final String clientId;

    public ProcessSubmission(String clientId) {
      this.clientId = clientId;
    }

    public void execute(AnySubmit component) {
      component.processSubmission(clientId);
    }
  }

  private void processSubmission(String clientId) {

    String hiddenFieldName = clientId + ":hidden";

    if (request.getParameter(hiddenFieldName) != null) {
      final Object[] contextToPublish = getContext(request, clientId);
      Runnable notification = new Runnable() {

        public void run() {
          resources.triggerEvent(event, contextToPublish, eventCallback);
        }
      };

      if (defer)
        formSupport.defer(notification);
      else
        heartbeat.defer(notification);
    }
  }

  private Object[] getContext(Request request, String clientId) {
    String contextFieldName = clientId + ":context";
    String context = request.getParameter(contextFieldName);
    if (context != null) {
      return Iterables.toArray(new JSONArray(context), Object.class);
    }
    String value = request.getParameter(clientId);
    if (value != null) {
      return new Object[] { value };
    }
    return null;
  }

  void beginRender() {
    formSupport.store(this, new ProcessSubmission(container.getClientId()));
  }

  void afterRender(MarkupWriter writer) {
    jsSupport.addInitializerCall("anySubmit", new JSONArray(formSupport.getClientId(), container.getClientId(), clientEvent, readOnly+""));
    if (context != null) {
      writer.element("input", "type", "hidden", "value", new JSONArray(context).toCompactString(), "name", container.getClientId() + ":context");
      writer.end();
    }
  }
}