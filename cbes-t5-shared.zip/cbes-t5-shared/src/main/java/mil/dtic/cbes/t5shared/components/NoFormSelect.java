package mil.dtic.cbes.t5shared.components;

import java.util.List;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.MarkupWriter;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.SupportsInformalParameters;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.PropertyAccess;

import mil.dtic.cbes.t5shared.encoders.GenericValueEncoder;


/**
 * Create a select dropdown without the usual Tapestry form requirements
 */
@SupportsInformalParameters
public class NoFormSelect
{
  //private static final Logger log = CbesLogFactory.getLog(NoFormSelect.class);
  @Inject
  private ComponentResources resources;
  @Inject
  private PropertyAccess propertyAccess;


  @SuppressWarnings("unused")
  @Parameter(required=true)
  @Property
  private List<Object> options;
  @Parameter(required=true)
  @Property
  private Object value;
  @SuppressWarnings("unused")
  @Parameter(value="true")
  @Property
  private boolean showBlank;
  @Parameter(value="newGenericEncoder(options, valueField)")
  private ValueEncoder<Object> valueEncoder;
  @Parameter(value="newGenericEncoder(options, labelField)")
  private ValueEncoder<Object> labelEncoder;
  @Parameter(value="newGenericEncoder(options, titleField)")
  private ValueEncoder<Object> titleEncoder;
  @SuppressWarnings("unused")
  @Parameter(defaultPrefix=BindingConstants.LITERAL)
  @Property
  private String valueField;
  @SuppressWarnings("unused")
  @Parameter(defaultPrefix=BindingConstants.LITERAL)
  @Property
  private String labelField;
  @SuppressWarnings("unused")
  @Parameter(defaultPrefix=BindingConstants.LITERAL)
  @Property
  private String titleField;


  @Property
  private Object currentOption;


  void onRenderInformals(final MarkupWriter writer)
  {
    resources.renderInformalParameters(writer);
  }


  public boolean isSelectedOption()
  {
    return currentOption != null && currentOption.equals(value);
  }

  public String getCurrentValue()
  {
    return valueEncoder.toClient(currentOption);
  }

  public String getCurrentLabel()
  {
    return labelEncoder.toClient(currentOption);
  }

  public String getCurrentTitle()
  {
    return titleEncoder.toClient(currentOption);
  }

  public <T> ValueEncoder<T> newGenericEncoder(List<T> l, String prop)
  {
    return new GenericValueEncoder<T>(l, prop, propertyAccess);
  }
}
