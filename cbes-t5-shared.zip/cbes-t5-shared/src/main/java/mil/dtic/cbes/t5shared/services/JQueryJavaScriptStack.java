package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.assets.AssetPathConstructor;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;
import org.apache.tapestry5.services.javascript.JavaScriptStack;
import org.apache.tapestry5.services.javascript.StylesheetLink;

public class JQueryJavaScriptStack implements JavaScriptStack
{
  private final Asset[] assets;

  public JQueryJavaScriptStack(SymbolSource symbolSource, AssetSource assetSource, AssetPathConstructor assetPathConstructor)
  {
    this.assets = new Asset[] {
      // jquery itself is provided by the org.got5.tapestry5-jquery compatibility library; last available version 1.10.2
      // this stack ensures the jquery migrate plugin is available wherever jquery is used, since jquerytools/beautytips won't run on jq 1.9+ without shims
      assetSource.getAsset(null, symbolSource.expandSymbols("${cb.assetpath}/js/json2.js"), null),
      assetSource.getAsset(null, symbolSource.expandSymbols("${cb.assetpath}/js/jquery-migrate-1.4.1.js"), null)
    };
  }

  public String getInitialization()
  {
    return null;
  }

  public List<Asset> getJavaScriptLibraries()
  {
    return Arrays.asList(assets);
  }

  public List<StylesheetLink> getStylesheets()
  {
    return Collections.emptyList();
  }

  public List<String> getStacks()
  {
    return Collections.emptyList();
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
