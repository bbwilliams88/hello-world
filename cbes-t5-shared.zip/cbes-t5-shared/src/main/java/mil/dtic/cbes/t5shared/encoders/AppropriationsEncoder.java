package mil.dtic.cbes.t5shared.encoders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tapestry5.ValueEncoder;

import mil.dtic.cbes.jb.IAppropriation;

public class AppropriationsEncoder implements ValueEncoder<IAppropriation> {

    private final Map<String, IAppropriation> appropriationsMap = new HashMap<String, IAppropriation>();

    public AppropriationsEncoder(List<IAppropriation> appropriations)
    {
        if (appropriations==null) throw new IllegalArgumentException();
        for (IAppropriation appropriation : appropriations)
        {
            appropriationsMap.put(appropriation.getCode(), appropriation);
        }
    }


    public String toClient(IAppropriation value)
    {
        return value.getCode();
    }


    public IAppropriation toValue(String keyAsString)
    {
        return appropriationsMap.get(keyAsString);
    }
}
