/*
 * $Id: R2EventButton.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components.mjb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.ValueObjects.BudgetActivity;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.delegates.MJBVolumeModel;
import mil.dtic.cbes.t5shared.base.T5JBBase;
import mil.dtic.utility.CbesLogFactory;

public class PesByBA extends T5JBBase
{
  private static final Logger log = CbesLogFactory.getLog(PesByBA.class);
  
  @Parameter(required=true)
  private List<ProgramElement> pes;

  @Parameter(required=true) @Property
  private ServiceAgency serviceAgency;
 
  @Parameter(required=true) @Property
  private List<MJBVolumeModel> volumes;
  
  @Property 
  private MJBVolumeModel currentvol;
  @Persist
  private Integer oldVolsize; //if you hit back and change the number of volumes, need to rebuild
  
  @Persist @Property
  private List<BudgetActivity> bas;
  
  @Property
  private BudgetActivity currentBa;
  
  //index in array corresponds to index of volumes list
  //only one of them should be true (radiobuttons)
  @Persist @Property
  private Map<Short,boolean[]> baToJbiMap;
  
  @Log
  void setupRender()
  {
    int volSize = volumes.size();
    
    if (oldVolsize!=null && oldVolsize != volSize) { //if old vol size != new vol size, nuke baToJbiMap
      baToJbiMap = null;
    }
    oldVolsize = volSize;
    if (bas==null) {
      bas = serviceAgency.getRDTEBudgetActivities();
    }
    if (baToJbiMap==null) {
      //CXE-5873
      boolean isDodService = (serviceAgency != null && specialCategoryService.isDodService(serviceAgency.getCode()));
      baToJbiMap = new HashMap<Short, boolean[]>();
      for (BudgetActivity ba : bas) {
        log.debug("Got BA " + ba.getTitle() + " for dividing PE's among " + volSize + " volumes.");
        boolean[] volInclusionFlags = new boolean[volSize];
        baToJbiMap.put(ba.getNumber(), volInclusionFlags);
        
        // Prefill default PE selection by BA based on agency
        if (volInclusionFlags.length >= 3)
        {
          if (isDodService)
          {
            if (ba.getNumber() == 1 || ba.getNumber() == 2 || ba.getNumber() == 3)
              volInclusionFlags[0] = true;
            else if (ba.getNumber() == 4 || ba.getNumber() == 5)
              volInclusionFlags[1] = true;
            else 
              volInclusionFlags[2] = true;
          } else {
              volInclusionFlags[0] = true;
          }
        }
      }
    }
  }
  
  //assumed to be in ba loop with currentba and loopIndex set
  public Integer getArray()
  {
    if (currentBa!=null) {
      int index = firstTrue(baToJbiMap.get(currentBa.getNumber()));
      if (index<0) return null;
      return index;
    }
    log.error("ummm");
    return null;
  }
  
  public void setArray(Integer indexOfVol)
  {
    if (currentBa!=null && indexOfVol!=null) {
      boolean[] arr =  baToJbiMap.get(currentBa.getNumber());
      Arrays.fill(arr, false); //only one true plz
      arr[indexOfVol] = true;
    }
    if (currentBa == bas.get(bas.size()-1)) {
      setJbis(); //call this on last BA
    }
    if (currentBa==null)
      log.error("ummm");
  }
  
  //get index of first true found
  private int firstTrue(boolean[] arr)
  {
    for (int i=0; i<arr.length; i++) {
      if (arr[i]) return i;
    }
    return -1;
  }
  
  //apply results to volumes
  @Log
  private void setJbis()
  {
    Map<Short, List<R2Exhibit>> map = new HashMap<Short, List<R2Exhibit>>(); //which pes in each ba
    for (BudgetActivity ba : bas) {
      map.put(ba.getNumber(), new ArrayList<R2Exhibit>());
    }
    for (ProgramElement pe : pes) {
      R2Exhibit r2 = new R2Exhibit();
      r2.setProgramElement(pe);
      map.get(pe.getBudgetActivity().getNumber()).add(r2);
    }
    for (BudgetActivity ba : bas) {
      int indexOfVol = firstTrue(baToJbiMap.get(ba.getNumber()));
      if (indexOfVol>=0) {
        MJBVolumeModel m = volumes.get(indexOfVol);
//        if (m.getR2ExhibitList() == null)
//          m.setR2ExhibitList(new R2ExhibitList());
//        if (m.getR2ExhibitList().getR2Exhibits() == null)
//          m.getR2ExhibitList().setR2Exhibits(map.get(ba.getNumber()));
//        else
//          m.getR2ExhibitList().getR2Exhibits().addAll(map.get(ba.getNumber()));
      }
    }
  }
}
