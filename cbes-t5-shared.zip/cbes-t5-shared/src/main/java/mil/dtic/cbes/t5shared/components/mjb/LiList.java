/*
 * $Id: PeList.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components.mjb;

import java.util.List;

import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

import mil.dtic.cbes.p40.vo.LineItem;

public class LiList
{
  @SuppressWarnings("unused")
  @Parameter(required=true)
  @Property
  private List<LineItem> lineItems;

  @SuppressWarnings("unused")
  @Property
  private LineItem li; //current pe in loop

}
