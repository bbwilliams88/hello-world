package mil.dtic.cbes.t5shared.pages.mjb;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.annotations.Component;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;

import mil.dtic.cbes.constants.BudgesContentType;
import mil.dtic.cbes.constants.Constants;
import mil.dtic.cbes.constants.FileSetting;
import mil.dtic.cbes.data.config.PeSubmissionFlag;
import mil.dtic.cbes.service.ValidationMessage;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.sso.siteminder.Privilege;
import mil.dtic.cbes.submissions.ValueObjects.ProgramElement;
import mil.dtic.cbes.submissions.ValueObjects.R2Exhibit;
import mil.dtic.cbes.submissions.ValueObjects.R2ExhibitList;
import mil.dtic.cbes.submissions.ValueObjects.ServiceAgency;
import mil.dtic.cbes.submissions.dao.ProgramElementDAO;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.delegates.XmlValidationDelegate;
import mil.dtic.cbes.submissions.delegates.XmlValidationInfo;
import mil.dtic.cbes.t5shared.components.SavedUpload;
import mil.dtic.cbes.t5shared.utils.FileExtensionSavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.SavedUploadValidator;
import mil.dtic.cbes.t5shared.utils.TapestryUtil;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.BudgesFile;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.InvalidXMLListener;


/**
 * Program Exhibit selection wizard page for Master Justification Book.
 */
public class MJBWizardPESelection extends MJBWizardPage
{
  private final String STORED_PE_SET_FOR_JB = "mil.dtic.cbes.storedPeSetForJb"; //"state:r2:mil.dtic.cbes.storedPeSetForJb";
  //    private final String WARNING_MESSAGE      = "Your Master Justification Book will contain warnings.";

  private static final Logger log = CbesLogFactory.getLog(MJBWizardPESelection.class);
  
  @Inject
  private HttpServletRequest httpRequest;
  @Inject
  private JavaScriptSupport jsSupport;


  @Persist
  @Property
  private String isPeSelectStr;
  
  private final ProgramElementDAO peDAO = BudgesContext.getProgramElementDAO();

  @Persist
  private R2ExhibitList selectedPesWrapped;

  @Persist
  private R2ExhibitList uploadedPesWrapped;

  @Persist
  @Property
  private File xmlFile; // if Upload R-2's from XML is selected

  @Component(id = "xmlFile")
  private SavedUpload xmlFileComp;

  @Property
  private String originalXmlFileName;
  
  @Property
  private String jbWizR2ExhibitSelectHelp;
  
  @Property
  private String warning;

  private boolean xmlErrors;


  private boolean enableXmlFile;
  private boolean redirect;
  private boolean uploaded;
  private boolean triggerRefresh;


  @Override
  Object onActivate() throws IOException
  {
    Object activateValue = super.onActivate();
    if (isPeSelectStr == null)
      isPeSelectStr = "t";
    refreshSelectedPesList();
    hideJbButton();
    
    jbWizR2ExhibitSelectHelp = config.getJbWizR2ExhibitSelectHelp(mfdata.getBudgetCycle().getCycle(), mfdata.getBudgetCycle().getBudgetYear());    

    return activateValue;
  }
  @Log
  void setupRender()
  {
    initPes();
  }

  void afterRender()
  {
    //Enable/disable select link/file upload depending on radiobutton
    jsSupport.addScript("togglePESelections(); jQuery('input.peselectradio').click(togglePESelections);");
  }

  @Override
  void reset()
  {
    super.reset();
    TapestryUtil.setSessionVar(httpRequest, STORED_PE_SET_FOR_JB,  new HashSet<Integer>());
  }

  private void initPes()
  {
    if (isPeSelectStr == null)
      isPeSelectStr = "t"; // default to PeSelectionPage, since form
    // submit never happens for it
    
    initSelectedPes();
    if (uploadedPesWrapped == null)
      uploadedPesWrapped = new R2ExhibitList();
    
    updateR2ExhibitList();
    
    if (selectedPesWrapped.isHasErrors())
      addErrorMessage("Selected PEs have errors.");
    
    if (selectedPesWrapped.getR2Exhibits() != null)
    {
//      if (hasInvalidSuffix()){
//        addWarningMessage("Selected PEs have invalid PE suffixes.");
//      }
    }
  }

  private boolean hasInvalidSuffix()
  {
	  boolean allowNotMemberOfSuffix = checkPrivilege(Privilege.ADMIN_ALL_AGENCIES);
	  boolean allowBadSuffix = false;
	  ProgramElement pe = null;
	  String peNum = null;
	  // most suffixes correspond to only one agency, but a few services/agencies share a suffix so we have to start with a list
	  List<ServiceAgency> suffixAgencies = null;
	  ServiceAgency suffixAgency = null;
	  String suffix = null;
	  
	  for (R2Exhibit r2Ex : selectedPesWrapped.getR2Exhibits())
	  {
		  pe = r2Ex.getProgramElement();
		  peNum = pe.getNumber();

		  if (peNum != null && peNum.length() >= Constants.MIN_LENGTH_PENUM)
		  {
			  // last 1-3 chars are agency suffix
			  suffix = peNum.substring(7);
			  
	      suffixAgencies = BudgesContext.getServiceAgencyDAO().findByActivePeSuffix(suffix);
	      
	      // narrow down the results for this suffix to a single agency
	      // usually we want the first one; for multiple results we need to be sure we aren't discarding a valid
	      // match for the agency listed in the PE
	      if(suffixAgencies.size() > 1 && suffixAgencies.contains(pe.getServiceAgency())) {
	        suffixAgency = pe.getServiceAgency();
	      } 
	      else if(suffixAgencies.size() > 0) {
	        suffixAgency = suffixAgencies.get(0);
	      }

			  if (suffixAgency == null)
			  {
				  log.debug("no agency found for suffix in " + peNum);
				  return true;
			  }
			  else if (!suffixAgency.equals(pe.getServiceAgency()))
			  {
				  log.debug("agency suffix '" + suffix + "' does not match selected agency '" + pe.getServiceAgency().getName() + "'");
				  return true;
			  }
			  else
			  {
				  log.debug("found agency " + suffixAgency + " for suffix " + peNum);
				  if (!getUserCredentials().getUserInfo().getBudgesUser().getAgencies().contains(suffixAgency))
				  {
					  log.debug("agency is not one of user's agencies");
					  if (!(allowBadSuffix || allowNotMemberOfSuffix)) {
						  log.debug("The PE Number suffix \"" + suffix + "\" does not belong to an agency you are a member of.");
              return true;
					  }
				  }
			  }
		  }
	  }
	  return false;
  }
  

  private void initSelectedPes()
  {
    if ((selectedPesWrapped == null || selectedPesWrapped.getR2Exhibits() == null || selectedPesWrapped.getR2Exhibits().isEmpty()) && isPeSelect())
    {
      selectedPesWrapped = new R2ExhibitList();
      Set<Integer> ids = getStoredJBPeSet();     
      if (ids != null && !ids.isEmpty())
      {
        List<ProgramElement> _selectedPes = peDAO.findForMjbWizard(ids);
        selectedPesWrapped = new R2ExhibitList();
        selectedPesWrapped.setR2Exhibits(new ArrayList<R2Exhibit>());
        for (ProgramElement pe : _selectedPes)
        {
          R2Exhibit r2 = new R2Exhibit();
          peDAO.refresh(pe);
          r2.setProgramElement(pe);
          selectedPesWrapped.getR2Exhibits().add(r2);
          r2.setHasErrors(PeSubmissionFlag.ERRORS.equals(pe.getSubmissionStatus()));
          r2.setHasWarnings(PeSubmissionFlag.INVALID.equals(pe.getSubmissionStatus()));
          selectedPesWrapped.setHasErrors(selectedPesWrapped.isHasErrors() || r2.isHasErrors());
          selectedPesWrapped.setHasWarnings(selectedPesWrapped.isHasWarnings() || r2.isHasWarnings());
        }
      }
    }else if (selectedPesWrapped == null){
      selectedPesWrapped = new R2ExhibitList();
    }
    refreshSelectedPesList();
    log.debug("Initialized R2ExhibitList, hasErrors = " + selectedPesWrapped.isHasErrors() + ", hasWarnings = " + selectedPesWrapped.isHasWarnings());
  }
  
  public boolean isPeSelect()
  {
    return StringUtils.equals(isPeSelectStr, "t");
  }

  public SavedUploadValidator getXmlFileValidator()
  {
    return new FileExtensionSavedUploadValidator("The supplied XML file does end in the extension .xml or .zip.", BudgesContentType.XML,
      BudgesContentType.ZIP);
  }

  public List<ProgramElement> getSelectedPes()
  {
    return selectedPesWrapped==null?new ArrayList<ProgramElement>():selectedPesWrapped.getProgramElements();
  }

  public List<ProgramElement> getUploadedPes()
  {
    return uploadedPesWrapped==null?new ArrayList<ProgramElement>():uploadedPesWrapped.getProgramElements();
  }

  @SuppressWarnings("unchecked")
  @Log
  private HashSet<Integer> getStoredJBPeSet()
  {
    return (HashSet<Integer>)TapestryUtil.getSessionVar(httpRequest, STORED_PE_SET_FOR_JB);
  }
  
  // refresh this page's selected PEs to avoid hibernate lazy initialization exception whether or not the isPeSelect option is chosen
  private void refreshSelectedPesList() {
    if(selectedPesWrapped != null && selectedPesWrapped.getR2Exhibits() != null) {
      for(R2Exhibit ex : selectedPesWrapped.getR2Exhibits()) {
        peDAO.refresh(ex.getProgramElement());
      }
    }
  }
  private void updateR2ExhibitList() {
    
    R2ExhibitList currPEs = getJBFormData().getR2ExhibitList();
    List<R2Exhibit> currPesUnwrapped = new ArrayList<R2Exhibit>();
    if(currPEs != null)
      currPesUnwrapped = currPEs.getR2Exhibits();
    
    List<R2Exhibit> uploadedPesUnwrapped = new ArrayList<R2Exhibit>();
    if(canUnwrapExhibitList(uploadedPesWrapped))
      uploadedPesUnwrapped = uploadedPesWrapped.getR2Exhibits();
    List<R2Exhibit> selectedPesUnwrapped = new ArrayList<R2Exhibit>();
    if(canUnwrapExhibitList(selectedPesWrapped))
      selectedPesUnwrapped = selectedPesWrapped.getR2Exhibits();
    
    if((isPeSelect() && CollectionUtils.containsAny(currPesUnwrapped, uploadedPesUnwrapped))
    || (!isPeSelect() && CollectionUtils.containsAny(currPesUnwrapped, selectedPesUnwrapped))) {
      log.debug("clearing list to avoid possibility of mixing selected and uploaded PEs");
      getJBFormData().emptyR2ExhibitList();
    }
    
    R2ExhibitList newPEs = isPeSelect() ? selectedPesWrapped : uploadedPesWrapped;
    getJBFormData().setR2ExhibitList(newPEs);
  }

  @Override
  public void validate()
  {
    log.debug("Validating PE Selection");
    if (uploaded && originalXmlFileName == null)
      addErrorMessage("You must upload an XML/ZIP File if you select the Upload Exhibit R-2's option.");
    
    if (!redirect || uploaded)
    {
      updateR2ExhibitList();
    }

    if (!enableXmlFile && xmlErrors)
      resetErrorMessages(); //clear out empty upload error
  }

  @Log
  void onSelectedFromSelectExhibitsButton()
  {
    redirect = true;
    selectedPesWrapped = null;
  }

  @Log
  @Override
  public Object successResponse()
  {
    if (uploaded)
    {
      enableXmlFile = !isPeSelect();

      if (enableXmlFile && originalXmlFileName!=null)
        processR2XmlFile(originalXmlFileName);

      return this;
    }
    else if (redirect)
    {
      //            resetXmlWarningMessages();
      showJbButton();

      try
      {
        String hostText = httpRequest.getHeader("X-Forwarded-Host");
        String scheme      = httpRequest.getScheme();         // http
        String serverName  = httpRequest.getServerName();     // hostname.com
        int    serverPort  = httpRequest.getServerPort();     // 80
        String contextPath = httpRequest.getContextPath();    // /mywebapp

        String url = scheme + "://" + hostText + contextPath + "/NewPeSelectionPage";

        log.debug("URL = " + url);

        return new URL(url);
      }
      catch (MalformedURLException e)
      {
        log.error("Malformed URL.", e);
      }
    }
    else if (triggerRefresh)
    {
      
    }

    return null;
  }


  @Log
  void onSelectedFromXmlUpload()
  {
    uploaded = true;
  }
  
  @Log
  void onSelectedFromRefreshSelected()
  {
    selectedPesWrapped = null;
    triggerRefresh = true;
  }


  @Log
  private void processR2XmlFile(String originalName)
  {
    //        resetXmlWarningMessages();
    //form stuff
    try {
      PreviewResultInfo pri = processR2XmlFile(originalName, xmlFile);
      if (pri.getR2ExhibitList()!=null) {
        uploadedPesWrapped = pri.getR2ExhibitList();
        List<XmlValidationInfo> xviList = pri.getXmlValidationResultList();
        if (xviList != null)
        {
          for (XmlValidationInfo xvi : xviList)
          {
            uploadedPesWrapped.setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
            uploadedPesWrapped.setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());

            addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
            addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());          
            //              addXmlWarningMessage(WARNING_MESSAGE);
          }
        }
        return; //success
      }
      else
      {
        List<XmlValidationInfo> xviList = pri.getXmlValidationResultList();
        if (xviList != null)
        {
          for (XmlValidationInfo xvi : xviList)
          {
            uploadedPesWrapped.setHasErrors(xvi.getXmlValidationResult().hasSchemaErrors() || xvi.getXmlValidationResult().hasRulesErrors());
            uploadedPesWrapped.setHasWarnings(xvi.getXmlValidationResult().hasRulesWarnings());

            addErrorMessages(xvi.getXmlValidationResult().getRulesErrorList());
            addErrorMessages(xvi.getXmlValidationResult().getSchemaErrorList());
          }
        }
        addErrorMessage("Did not find any error-free R-2s.");
        
        if (getErrorMessages() != null && getErrorMessages().size() > 0)
        	uploadedPesWrapped.setHasWarnings(false);
      }
    } catch (VirusScanException e) {
      log.error("", e);
      for (ValidationMessage vm : e.getErrorsList()) {
        addErrorMessage(vm.getMessage());
      }
    } catch (IOException e) {
      log.error("", e);
      addErrorMessage("System Error while processing XML. Could not load R-2s from file.");
    }
    //any error, remove cached file from savedupload component
    xmlFileComp.delete();
  }

  @Log
  private PreviewResultInfo processR2XmlFile(String originalName, File xmlFile) throws VirusScanException, IOException
  {
    //actually perform xmltojava
    String destFileName = R2Storage.prependFileSettingToName(FileSetting.R2COLLECTION, xmlFile.getName());
    File scanned = R2Storage.scanAndPutInUpload(getJBFormData().getWorkingDirectory(), destFileName, xmlFile, originalName);
    BudgesFile bf = new BudgesFile(originalName, scanned, null);
    XmlValidationDelegate xvd = new XmlValidationDelegate(getJBFormData().getWorkingDirectory(), InvalidXMLListener.DO_NOTHING, runOnlyVerifiedRules()); //TODO fix email
    xvd.setScanEnabled(false);
    return xvd.doValidateXml(bf);
  }


  //Show/hide PeSelectionPage "Return to JB Wizard" button
  private void showJbButton()
  {
    TapestryUtil.setSessionVar(httpRequest, Constants.JBBUTTON_KEY, Boolean.TRUE.toString());
  }

  private void hideJbButton()
  {
    TapestryUtil.setSessionVar(httpRequest, Constants.JBBUTTON_KEY, Boolean.FALSE.toString());
  }

  @Override
  public void nextButtonClicked()
  {
    if (isPeSelect() == false)
      TapestryUtil.setSessionVar(httpRequest, STORED_PE_SET_FOR_JB,  new HashSet<Integer>());
  }

  public void setPeSelectStr(String s) {
    isPeSelectStr = s;
  }

  public void setUploadedPesWrapped(R2ExhibitList uploadedPesWrapped) {
    this.uploadedPesWrapped = uploadedPesWrapped;
  }
  
  public void setUploaded(boolean uploaded) {
    this.uploaded = uploaded;
  }
  
  private boolean canUnwrapExhibitList(R2ExhibitList list) {
	  return null != list && null != list.getR2Exhibits();
  }

}
