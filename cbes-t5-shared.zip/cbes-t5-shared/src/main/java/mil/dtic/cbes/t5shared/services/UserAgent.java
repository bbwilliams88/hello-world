package mil.dtic.cbes.t5shared.services;

public interface UserAgent
{
    String getUserAgent();

    boolean isIE();      // Any version of IE.
    boolean isIE6();     // Any version of IE 6.
    boolean isIE7();     // Any version of IE 7.
    boolean isIE8();     // Any version of IE 8.
    boolean isIE9();     // Any version of IE 9.
    boolean isIE10();    // Any version of IE 10.
    boolean isIE11();    // Any version of IE 11.
    boolean isBadIE();   // Any version of IE 6, 7, or 8.
    boolean isChrome();  // Any version of Chrome.
    boolean isFirefox(); // Any version of Firefox.
    boolean isSafari();  // Any version of Safari.
	boolean isEdge();    // Any version of Edge.
}

