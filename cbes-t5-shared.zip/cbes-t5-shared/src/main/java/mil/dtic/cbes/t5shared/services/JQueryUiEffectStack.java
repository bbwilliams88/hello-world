package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class JQueryUiEffectStack extends AbstractJavaScriptStack
{
  public JQueryUiEffectStack(AssetSource assetSource, SymbolSource symbolSource)
  {
    super(assetSource, 
      symbolSource,
      new String[] {
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-core.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-blind.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-bounce.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-clip.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-drop.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-explode.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-fade.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-fold.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-highlight.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-pulsate.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-scale.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-shake.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-slide.js"),
      symbolSource.expandSymbols("${jquery.ui.path}/jquery.ui.effect-transfer.js"),
    }, new String[] {});
  }

  @Override
  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(path, null);
  }

  @Override
  public List<String> getStacks()
  {
    return Collections.singletonList(CbesT5SharedModule.JQUICORESTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
