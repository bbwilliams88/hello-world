package mil.dtic.cbes.t5shared.utils.wizard;

import mil.dtic.cbes.t5shared.models.DbExhibitSelection;


/**
 * Pages that implement this select exhibit R2s/P40s, and send them back in
 * the {@link DbExhibitSelection} SessionState variable. setReturnPage is
 * used for a return button to know which page to go back to.
 */
public interface ExhibitSelectionPage
{
  void setReturnPage(Object returnPage);
  void setReturnButton(String returnButtonMessage);
}
