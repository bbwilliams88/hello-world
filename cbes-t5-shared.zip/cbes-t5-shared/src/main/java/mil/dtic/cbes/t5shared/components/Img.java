/*
 * $Id: PeList.java 33301 2009-11-02 19:08:09Z aahmed $
 */
package mil.dtic.cbes.t5shared.components;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.MarkupWriter;
import org.apache.tapestry5.annotations.OnEvent;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.SupportsInformalParameters;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;

/** Shorthand for an img tag that references an image at ${cb.assetpath]/images */
@SupportsInformalParameters
public class Img
{
  @Inject
  private ComponentResources resources;
  @Inject
  private AssetSource assetSource;
  @Inject
  private SymbolSource symbolSource;


  @Parameter(required=true, defaultPrefix=BindingConstants.LITERAL)
  private String image;


  @OnEvent("renderInformals")
  void renderInformals(final MarkupWriter writer)
  {
    resources.renderInformalParameters(writer);
  }


  public Asset getSrc()
  {
    return assetSource.getClasspathAsset(symbolSource.expandSymbols("${cb.assetpath}/images/" + image));
  }
}
