package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.List;

import mil.dtic.cbes.submissions.ValueObjects.BudgetCycle;
import mil.dtic.utility.BudgesContext;

/** Provides models for select boxes */
public class DropdownService
{
  public List<BudgetCycle> getAllBudgetCycles()
  {
    return BudgesContext.getBudgetCycleDAO().getBudgetCycles();
  }
  
  public List<String> getAllSubmDates()
  {
    List<BudgetCycle> l = BudgesContext.getBudgetCycleDAO().getBudgetCycles();
    List<String> dates = new ArrayList<String>(l.size());
    for (BudgetCycle bc : l)
    {
      dates.add(bc.getSubmissionDates().get(0).getValue());
    }
    return dates;
  }
}