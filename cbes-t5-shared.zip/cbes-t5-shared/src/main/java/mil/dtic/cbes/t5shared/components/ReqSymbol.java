package mil.dtic.cbes.t5shared.components;

import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

@Import(stylesheet="classpath:${cb.assetpath}/css/shared.css")
public class ReqSymbol
{
  @Parameter(value="true") @Property @SuppressWarnings("unused")
  private boolean show;
}
