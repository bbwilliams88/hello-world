package mil.dtic.cbes.t5shared.pages;

import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.submissions.service.annotated.ConfigService;

public class ConfigRefreshPage
{
  @Inject
  private ConfigService config;


  @Log
  void onActivate()
  {
    config.markConfigCacheForReload();
  }
}
