package mil.dtic.cbes.t5shared.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.tapestry5.Asset;
import org.apache.tapestry5.ioc.services.SymbolSource;
import org.apache.tapestry5.services.AssetSource;
import org.apache.tapestry5.services.javascript.JavaScriptAggregationStrategy;

public class JQueryCookieJavaScriptStack extends AbstractJavaScriptStack
{
  public JQueryCookieJavaScriptStack(AssetSource assetSource, SymbolSource symbolSource)
  {
    super(assetSource,
      symbolSource,
      new String[]{symbolSource.expandSymbols("${cb.assetpath}/js/jquery.cookie.js")}, new String[]{});
  }

  protected Asset getAsset(AssetSource assetSource, SymbolSource symbolSource, String path)
  {
    return assetSource.getClasspathAsset(path, null);
  }

  public List<String> getStacks()
  {
    //load jquery stack first
    return Collections.singletonList(CbesT5SharedModule.JQUERYSTACK);
  }

  @Override
  public List<String> getModules() {
    // TODO Might need to look into this more
    return new ArrayList<String>();
  }

  @Override
  public JavaScriptAggregationStrategy getJavaScriptAggregationStrategy() {
    // TODO This should be fine
    return JavaScriptAggregationStrategy.DO_NOTHING;
  }
}
