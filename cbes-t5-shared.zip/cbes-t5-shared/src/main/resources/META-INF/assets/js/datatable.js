(function() {
    var $, _,
      __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  
    if (!window.CBES) {
      window.CBES = {};
    }
  
    $ = jQuery;
  
    _ = T5._;
  
    CBES.Datatable = (function() {
  
      Datatable.prototype.opts = {};
  
      function Datatable() {
        this.getTruncatedFnRender = __bind(this.getTruncatedFnRender, this);
  
        this.findColumnIndex = __bind(this.findColumnIndex, this);
  
        var dext;
        this.opts = {
          bJQueryUI: true,
          bProcessing: true,
          sPaginationType: "full_numbers",
          iDisplayLength: 10,
          bSortCellsTop: true,
          oLanguage: {
            sSearch: "Filter:"
          },
          bLengthChange: true,
          aLengthMenu: [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
          iCookieDuration: 30 * 60,
          sCookiePrefix: "",
          sDom: "C<\"H\"frp>t<\"F\"li>",
          oColVis: {
            buttonText: "Columns"
          },
          bStateSave: true,
          aoColumns: []
        };
        dext = $.fn.dataTableExt;
        dext.ofnSearch["title-filtering"] = this.filterByTitleAttrs;
        dext.oSort["title-filtering-asc"] = dext.oSort["string-asc"];
        dext.oSort["title-filtering-desc"] = dext.oSort["string-desc"];
      }
  
      Datatable.prototype.findColumnIndex = function(mDataProp) {
        var aoCol;
        aoCol = _.find(this.opts.aoColumns, function(col) {
          return col.mDataProp === mDataProp;
        });
        return _.indexOf(this.opts.aoColumns, aoCol);
      };
  
      Datatable.prototype.getTruncatedFnRender = function(maxlen) {
        var _this = this;
        return function(o, val) {
          return _.str.truncate(o.aData[o.mDataProp], maxlen, "...");
        };
      };
  
      Datatable.prototype.filterByTitleAttrs = function(sData) {
        return sData.replace(/[\r\n]/gm, " ").replace(/<.*?>/gm, "");
      };
  
      Datatable.prototype.parseJsonScriptTag = function(id) {
        return JSON.parse($(id).html());
      };
  
      Datatable.prototype.formatDate = function(jsondate) {
        return "";
      };
  
      return Datatable;
  
    })();
  
  }).call(this);
  