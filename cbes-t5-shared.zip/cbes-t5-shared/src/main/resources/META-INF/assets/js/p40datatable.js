(function() {
    var $, _,
      __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  
    if (!window.P40) {
      window.P40 = {};
    }
  
    $ = jQuery;
  
    _ = T5._;
  
    P40.Datatable = (function() {
  
      Datatable.prototype.hmap = {};
  
      Datatable.prototype.exampleopts = {
        overrideAoColumns: {
          "headerid": {
            bSearchable: true,
            bSortable: true
          }
        }
      };
  
      function Datatable(jq, opts) {
        this.findColumnIndex = __bind(this.findColumnIndex, this);
  
        this.truncateLineItemTitleColumn = __bind(this.truncateLineItemTitleColumn, this);
  
        this.getTruncatedFnRender = __bind(this.getTruncatedFnRender, this);
  
        var aoColumns, dext, headerid, _i, _len, _ref;
        this.datatable = jQuery(jq);
        this.createHeaderMap(this.datatable);
        this.opts = {
          bJQueryUI: true,
          sPaginationType: "full_numbers",
          iDisplayLength: 10,
          bSortCellsTop: true,
          oLanguage: {
            sSearch: "Filter:"
          },
          bLengthChange: true,
          aLengthMenu: [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
          iCookieDuration: 30 * 60,
          sCookiePrefix: "default_",
          sDom: "C<\"H\"frp>t<\"F\"li>",
          oColVis: {
            buttonText: "Columns"
          },
          bStateSave: true
        };
        aoColumns = this.opts.aoColumns = [];
        this.datatable.find("tr:eq(0) th").each(function() {
          return aoColumns.push({
            bSearchable: true,
            bSortable: true
          });
        });
        if (opts && opts.overrideAoColumns) {
          _ref = _.keys(opts.overrideAoColumns);
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            headerid = _ref[_i];
            if (this.hmap[headerid] != null) {
              aoColumns[this.hmap[headerid]] = opts.overrideAoColumns[headerid];
            } else {
              log("header id not found in map - " + headerid);
            }
          }
        }
        if (opts) {
          _.extend(this.opts, opts);
        }
        dext = jQuery.fn.dataTableExt;
        dext.ofnSearch["title-filtering"] = this.filterByTitleAttrs;
        dext.oSort["title-filtering-asc"] = dext.oSort["string-asc"];
        dext.oSort["title-filtering-desc"] = dext.oSort["string-desc"];
        this.datatable = this.datatable.dataTable(this.opts);
        jQuery(window).resize(function() {
          return jQuery(this.datatable).css("width", "100%");
        });
        this.datatable.css("width", "100%");
        this.datatable.show();
      }
  
      Datatable.prototype.getTruncatedFnRender = function(maxlen) {
        var _this = this;
        return function(o, val) {
          return _.str.truncate(o.aData[o.mDataProp], maxlen, "...");
        };
      };
  
      Datatable.prototype.createHeaderMap = function(jtable) {
        var _this = this;
        if (_.keys(this.hmap).length === 0) {
          return jtable.find("tr").each(function(idx, headerrow) {
            return jQuery(headerrow).find("th").each(function(idx, th) {
              return _this.hmap[th.id] = idx;
            });
          });
        }
      };
  
      Datatable.prototype.truncateLineItemTitleColumn = function(obj) {
        return _.str.truncate(obj.aData[this.hmap["lineitemtitle"]], 30, "...");
      };
  
      Datatable.prototype.filterByTitleAttrs = function(content) {
        return "" + (jQuery(content).attr('title')) + " " + (jQuery(content).text());
      };
  
      Datatable.prototype.findColumnIndex = function(mDataProp) {
        var aoCol;
        aoCol = _.find(this.opts.aoColumns, function(col) {
          return col.mDataProp === mDataProp;
        });
        return _.indexOf(this.opts.aoColumns, aoCol);
      };
  
      Datatable.prototype.parseJsonScriptTag = function(id) {
        return JSON.parse($(id).html());
      };
  
      return Datatable;
  
    })();
  
  }).call(this);