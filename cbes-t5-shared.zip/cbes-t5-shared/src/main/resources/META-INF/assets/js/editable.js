(function() {
    var $,
      __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
  
    if (!window.CBES) {
      window.CBES = {};
    }
  
    $ = jQuery;
  
    CBES.Editable = (function() {
  
      function Editable(datatable, findColumnIndex, updateUrl, td, nextTd, isValidFunc, updateCb, nextevent) {
        this.datatable = datatable;
        this.findColumnIndex = findColumnIndex;
        this.updateUrl = updateUrl;
        this.td = td;
        this.nextTd = nextTd;
        this.isValidFunc = isValidFunc;
        this.updateCb = updateCb != null ? updateCb : this._defaultUpdate;
        this.nextevent = nextevent != null ? nextevent : "dblclick";
        this.onKey = __bind(this.onKey, this);
  
        this.onBlur = __bind(this.onBlur, this);
  
        this.hide = __bind(this.hide, this);
  
        this.tdNode = this.td[0];
        this.aPos = this.datatable.fnGetPosition(this.tdNode);
        this.text = $("<input type='text' />").on("blur", this.onBlur);
        this.text.on("keyup keydown", this.onKey);
      }
  
      Editable.prototype._defaultUpdate = function(dt, val, aPos) {
        return dt.fnUpdate(val, aPos[0], aPos[2]);
      };
  
      Editable.prototype.show = function() {
        var _this = this;
        this.td.css("padding", "0px");
        this.text.val(this.td.text());
        this.oldval = this.text.val();
        this.td.empty().append(this.text);
        return setTimeout(function() {
          return _this.text.focus();
        }, 0);
      };
  
      Editable.prototype.hide = function() {
        this.text.remove();
        if (this.oldval !== this.text.val() && this.isValidFunc(this.text.val())) {
          this.updateCb(this.datatable, this.text.val(), this.aPos);
        } else {
          this.td.text(this.oldval);
        }
        return this.td.css("padding", "");
      };
  
      Editable.prototype.onBlur = function(e) {
        log("onBlur");
        this.hide();
        if (this.tabPressed) {
          return this.nextTd.trigger(this.nextevent);
        }
      };
  
      Editable.prototype.onKey = function(e) {
        if (e.keyCode === 9) {
          this.tabPressed = e.type === "keydown";
        }
        if (e.type === "keydown" && e.keyCode === 13) {
          this.hide();
          e.stopPropagation();
        }
      };
  
      return Editable;
  
    })();
  
  }).call(this);
  