var $, ATTRROW, ATTRYEAR, DIRTY_EVENT, SAVE_EVENT, UPDATE_EVENT, autonumber, getFnRenderFunding, _,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

if (!window.P40) {
    window.P40 = {};
}

$ = jQuery;

_ = T5._;

DIRTY_EVENT = "r2:dirty";

SAVE_EVENT = "r2:controlnumbersave";

UPDATE_EVENT = "r2:controlnumberupdate";

ATTRYEAR = "data-year";

ATTRROW = "data-fundingrow";

autonumber = true;

window.setup = function(tableid) {
    try {
        return new P40LiListDatatable("#" + tableid);
    } catch (ex) {
        return log(ex);
    }
};

class P40LiListDatatable extends P40.Datatable {
    constructor (tableid) {
        super();
        var dt,
            _this = this;
        dt = $(tableid);
        if (!dt.length) {
            throw "table not found by id";
        }
        dt.find("thead tr.filter th").addClass("ui-state-default");
        _.extend(this.opts, {
            fnRowCallback: function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            return nRow.setAttribute(ATTRROW, "gross");
            },
            aoColumns: [
            {
                mDataProp: "p1LineItemNumber",
                bSearchable: true,
                bSortable: true,
                sWidth: "5%",
                sDefaultContent: ""
            }, {
                mDataProp: "lineItemNumber",
                bSearchable: true,
                bSortable: true,
                sClass: "nobreak",
                sWidth: "10%",
                sDefaultContent: ""
            }, {
                mDataProp: "budgetCycleAndYear",
                bSearchable: true,
                bSortable: true,
                sClass: "center",
                sDefaultContent: ""
            }, {
                mDataProp: "lineItemTitle",
                bSearchable: true,
                bSortable: true,
                fnRender: this.getTruncatedFnRender(30),
                bUseRendered: false,
                sDefaultContent: ""
            }, {
                mDataProp: "agencyCode",
                bSearchable: true,
                bSortable: true,
                sClass: "center",
                sType: "title-filtering",
                fnRender: _.template("<span title='<%= obj.aData.agencyName %>'><%= obj.aData.agencyCode %></span>"),
                sDefaultContent: ""
            }, {
                mDataProp: "appropriationNumber",
                bSearchable: true,
                bSortable: true,
                sClass: "center",
                sType: "title-filtering",
                sDefaultContent: "",
                fnRender: _.template("<span title='<%= obj.aData.appropriationTitle %>'><%= obj.aData.appropriationNumber %></span>")
            }, {
                mDataProp: "budgetActivityNumber",
                bSearchable: true,
                bSortable: true,
                sClass: "center",
                sType: "title-filtering",
                sDefaultContent: "",
                fnRender: _.template("<span title='<%= obj.aData.budgetActivityTitle %>'><%= obj.aData.budgetActivityNumber %></span>")
            }, {
                mDataProp: "bsaNum",
                bSearchable: true,
                bSortable: true,
                sClass: "center",
                sType: "title-filtering",
                sDefaultContent: "",
                fnRender: _.template("<span title='<%= obj.aData.budgetSubActivityTitle %>'><%= obj.aData.bsaNum %></span>")
            }
            ]
        });
        this.opts.aaSorting = [[this.findColumnIndex("p1LineItemNumber"), "asc"], [this.findColumnIndex("lineItemNumber"), "asc"]];
        this.datatable = dt.dataTable(this.opts);
        $(window).resize(function() {
            return dt.css('width', '100%');
        });
        dt.css('width', '100%');
        this.datatable._fnProcessingDisplay(true);
        window.setTimeout(function() {
            _this.datatable.fnAddData(_this.parseJsonScriptTag(tableid + "data"));
            return _this.datatable._fnProcessingDisplay(false);
        }, 50);
    }
};

getFnRenderFunding = function(row, year) {
    return function(o, val) {
        var ret;
        ret = o.aData[row][year];
        if (ret === null) {
            return "";
        } else {
            return ret;
        }
    };
};
