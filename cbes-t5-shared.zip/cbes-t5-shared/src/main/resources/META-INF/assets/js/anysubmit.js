(function() {

	Tapestry.Initializer.anySubmit = function(formId, clientId, event, readOnly) {
	  var createHidden, element, form;
	  form = jQuery("#" + formId);
	  element = jQuery("#" + clientId);
	  if (form.length === 0 || element.length === 0) {
		log("anysubmit - Error finding element");
		return;
	  }
	  createHidden = function() {
		var hidden, submittingElement;
		hidden = jQuery("<input type='hidden' name='" + clientId + ":hidden' value='" + clientId + "'></input>");
		hidden.insertAfter(element);
		if (readOnly === 'true') {
		  submittingElement = jQuery("<input type='hidden' name='cancel' value=''></input>");
		  return submittingElement.insertAfter(element);
		}
	  };
	  return element.bind(event, function(event) {
		var proceed;
		event.stopPropagation();
		event.preventDefault();
		proceed = true;
		if (window.Prototype) {
		  proceed = form[0].onsubmit();
		} else {
		  proceed = form[0].checkValidity();
		}
		if (proceed) {
		  createHidden();
		  form[0].submit();
		}
		return false;
	  });
	};
  
  }).call(this);
  