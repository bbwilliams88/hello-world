if (!window.CBES) CBES={};
(function($) {
	CBES.monthPicker = function(elementId, condition, trueClass, falseClass) {
		try {
		    setTimeout(function() { if (! $(elementId).is("[readonly]")) $(elementId).monthpicker(); }, 0);
		} catch (ex) {
			log(ex);
		}
	};
})(jQuery);
