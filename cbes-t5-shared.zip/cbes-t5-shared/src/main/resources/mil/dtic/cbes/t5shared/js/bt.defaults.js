// Default values for BeautyTips.  Pull these in after loading the BeautyTips
// JavaScript itself (the Tapestry 5 BeautyTips stack should ensure this).

jQuery.bt.options.cornerRadius = 15;
jQuery.bt.options.fill = '#FDFBFF';
jQuery.bt.options.offsetParent = 'body';
jQuery.bt.options.shadow = true;
jQuery.bt.options.shadowBlur = 12;
jQuery.bt.options.shadowColor = '#243F62';
jQuery.bt.options.shadowOffsetX = 1;
jQuery.bt.options.shadowOffsetY = 4;
jQuery.bt.options.strokeStyle = '#1F477D';
jQuery.bt.options.strokeWidth = 1;
jQuery.bt.options.width = '280px';
