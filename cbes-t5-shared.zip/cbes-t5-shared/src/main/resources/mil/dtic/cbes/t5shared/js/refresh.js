//"Refresh" multiple urls (hit with get requests)

function refresher(buttonId,urls) {
	try {
		jQuery('#' + buttonId).click(function() {
			jQuery.each(urls, function(i,url) {
				jQuery.ajax({
					url: url, cache: false,
					success: function () { log('refresh worked ' + url); },
					error:function(data,status,e){ log('refresh failed ' + url); }
				});
			});
		});
	} catch (ex) {
		log(ex);
	}
}