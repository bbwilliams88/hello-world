//for MJBWizardLiBreakdown

function initTables(moveurl) {
	try {
		var tableSelector = 'table.t-data-grid';
		//setup pfselect
		var tables = jQuery(tableSelector);
		tables.find('tbody td').addClass('selectable');
		tables.each(function(index) {
			jQuery(this).pfselect({
				selectElement : 'tr',
				targetWindow : jQuery(this).parents('.deselectArea')
			});
		});
		//setup move buttons
		jQuery('a.movebutton').click(function(e) {
			e.preventDefault();
			var table = jQuery(e.target).parent().find(tableSelector);
			var volid = table.find('input.volid').val();
			var othertables = tables.not(table);
			var rows = othertables.find('.selected');
			var inputs = rows.find('input.t5id');
			var t5ids = [];
			inputs.each(function(idx,t5input){
				t5ids.push(t5input.value);
			});
			log(t5ids);
			//move
			p40lbmove_post(moveurl,t5ids,volid,function() {
				rows.detach();
				rows.show();
				rows.removeClass('selected');
				table.find('tbody').append(rows);
				p40lb_sort(table,['firstSort', 'secondSort']);
				},
				function() {
					rows.show();
				});
			rows.effect('transfer', {to: table, className: 'ui-transfer'}, 500);
			rows.hide();
		});
	} catch (ex) {
		log(ex);
	}
}


function p40lbmove_post(url,rowids,volid,successcb,failcb) {
	jQuery.ajax({
		url: url,
		type: 'POST',
		data: {rowids: JSON.stringify(rowids), volid: volid},
		cache: false,
		success: successcb,
		error:function(data,status,e){
			log('meh failed');
			Tapestry.error('System Error - Move failed');
			hideProgress();
			if (failcb)
				failcb(data,status,e);
		} });
}

//Sort the rows in jqtable by the cells specified with sortClasses
function p40lb_sort(jqtable,sortClasses) {
	log('hiya!');
	sortClasses.reverse();
/*	sortClasses.each(
		function(sortClass) {
			log(jqtable.find('td.' + sortClass));
			jqtable.find('td.' + sortClass).sortElements(
					function(a, b) {
						return jQuery(a).text() > jQuery(b).text() ? 1 : -1;
					},
					function() {
						return this.parentNode;
					})
		});
		*/
//	jqtable.find('td').sortElements(
//			function(a, b) {
//				var result = 0;
//				sortClasses.each(function(i,sortClass) {
//				if (result == 0) {
//					var achild = jQuery(a); //get the td element
//					var bchild = jQuery(b);
//					if (achild.text() > bchild.text)
//						result = 1;
//					else if (achild.text() < bchild.text)
//						result = -1;
//					else
//						result = 0;
//				}
//			},
//			function(){
//				return this.parentNode;
//			})
//		);
//		return result;
//	});
}