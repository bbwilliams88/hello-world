function initializeValidationBox()
{
    setValidationBoxState(jQuery("#display-warnings").val());
    
    jQuery("#warnings-header").click(function()
        {
            if (jQuery("#display-warnings").val() == 'false')
                setValidationBoxState('true');
            else
                setValidationBoxState('false');
                //jQuery(contentId).toggle('fast', function() { setValidationBoxState(stateId, ! jQuery(stateId).val()); });
        });
}

function setValidationBoxState(flag)
{
    if (flag == 'false')
        jQuery("#warnings-list").hide('fast');
    else
        jQuery("#warnings-list").show('fast');

    jQuery("#display-warnings").val(flag);
}
