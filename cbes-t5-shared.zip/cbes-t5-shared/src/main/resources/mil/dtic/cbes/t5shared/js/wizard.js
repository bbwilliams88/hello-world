//The methods in this script handle wizard navigation and text field entry.
//An onChange handler is defined to trim text fields and an onClick handler
//is defined for the navigation sidebar links to submit the form (saving the
//values) instead of processing the link click (which would lose the values).


//This gets called after the DOM is loaded.  It is setup and called by the
//afterRender() T5 method.
function initializeWizardNavigation()
{
	// onchange handler on all text fields in the wizard form to trim the text fields
	jQuery("#wizardInputs input[type='text']").change(function(e) {
		this.value = _.str.trim(this.value);
	});

	//Handles the navigation link click.
	jQuery("a.nav-entry").click(function(event) {
		// Submit the form -- the ID must be the T5 page name.
		submitForm(this.id, event);
		// Cancel the event (this prevents the click from occurring after the submit).
		event.preventDefault();
	});
}


//Submit the Wizard form.
function submitForm(page, event)
{
	// Record the page we are jumping to from the navigation link click.  There
	// is a bug in the T5 Hidden component in that it doesn't render the ID of
	// the element, so we have to get the FORM by ID and then get the hidden
	// input out of it.
	jQuery("#wizardInputs input[name='jumpToPage']").val(page);

	// Submit
	jQuery("#wizardInputs").trigger("submit");
}

function togglePESelections()
{
	var radio = jQuery("#wizardInputs input[type='radio']:checked").val();

	if (radio == 'f')
	{
		jQuery(".peselecttrue").hide();
		jQuery(".peselectfalse").show();
	}
	else
	{
		jQuery(".peselecttrue").show();
		jQuery(".peselectfalse").hide();
	}

	jQuery("a.selectExhibits").click(respondToNavigationClick2);
}

function toggleLISelections()
{
	var radiostr = jQuery("#wizardInputs input[type='radio']:checked").val();
	var radio = radiostr == 'true';

	if (radio)
	{
		jQuery(".peselecttrue").show();
		jQuery(".peselectfalse").hide();
	}
	else
	{
		jQuery(".peselecttrue").hide();
		jQuery(".peselectfalse").show();
	}

	jQuery("a.selectExhibits").click(respondToNavigationClick2);
}

function respondToNavigationClick2(event)
{
	jQuery("#wizardInputs input[name='selectExhibits']").val(page);
	// Submit the form -- the ID must be the T5 page name.
	submitForm(this.id, event);
	// Cancel the event (this prevents the click from occurring after the submit).
	event.preventDefault();
}

//TODO jquery this
if (Tapestry.ElementEffect) {
	Tapestry.ElementEffect.highlight = function(element) {
		return new Effect.Highlight(element, { startcolor: '#D5E2F5', endcolor: '#FFFFFF' });
	};
}

function toggleAddSupplementals(max,forceHide)
{
	var rowCount = jQuery(".suprow").length;
	if (max<=rowCount || forceHide===true) {
		jQuery(".suplinkadd").hide();
	} else {
		jQuery(".suplinkadd").show();
	}
};

var onloadDone = false;
jQuery(function() {
	onloadDone = true;
});
function loadSupplementalsJs(max)
{
	//Disable add supplemental row based on row count
	if (onloadDone) toggleAddSupplementals(max); //on attaching to dom, from ajax add
}

function initializeWizardBtPopups()
{
	jQuery("#wizard-bt-help-box").bt({
		contentSelector: "jQuery('#wizard-bt-help-content')",
		positions: ['left'],
		trigger: 'hover',
		width: '550px' });
	
	jQuery("#bt-jbwiz-basic-info-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-basic-info-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-exhibit-select-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-exhibit-select-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-volumes-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-volumes-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-table-of-contents-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-table-of-contents-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-volume-breakdown-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-volume-breakdown-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-attachments-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-attachments-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-summary-and-build-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-summary-and-build-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
	
	jQuery("#bt-jbwiz-confirmation-help-box").bt({
		contentSelector: "jQuery('#bt-jbwiz-confirmation-help-content')",
		positions: ['right'],
		trigger: 'hover',
		width: '400px' });
}

window.volumesDeleteUpdater = function(){
	console.log("volumeDeleteUpdater setting up")
	var getUpdaterFn = function(l) { return function(){
		console.log("volume delete updater running: " + $('.removerowicon').length);
		  if ($('.removerowicon').length <= l) {
		    return $('.removerowicon').hide();
		  } else {
		    return $('.removerowicon').show();
		  }
		}};
	getUpdaterFn(1)();
	jQuery('#modal-dialog-accept-button').click(getUpdaterFn(2));
	jQuery('#addrowlink').click( function(){setTimeout(getUpdaterFn(1),300);});
};

window.setMaxAjaxFormLoopRows = function(length, message){
	$('#addrowlink').after('<span class="setMaxAjaxFormLoopRowsMessage">' + message + '</span>');
	$('.setMaxAjaxFormLoopRowsMessage').hide()
	var getUpdaterFn = function(maxLength) {
		return function() {
			var curLength = $('#addrowlink').parents('tbody').first().children('tr').length;
			console.log("updateFn running curLength: " + curLength + " >= " + maxLength);
			if (curLength >= maxLength){
				$('#addrowlink').hide();
				$('.setMaxAjaxFormLoopRowsMessage').show()
			}else{
				$('#addrowlink').show();
				$('.setMaxAjaxFormLoopRowsMessage').hide()
			}
		};
	};
	$('#addrowlink').click(getUpdaterFn(length));
	$('#modal-dialog-accept-button').click(getUpdaterFn(length+2));
	getUpdaterFn(length+1)();
};

