if (!window.CBES) CBES={};

CBES.ifCss = function(elementId, condition, trueClass, falseClass) {
	try {
		jQuery(elementId).addClass(condition ? trueClass : falseClass);
	} catch (ex) {
		log(ex);
	}
};

CBES.ifAttr = function(elementId, condition, attr, trueAttr, falseAttr) {
	try {
		var val = condition ? trueAttr : falseAttr;
		if (val)
			jQuery(elementId).attr(attr, val);
		else
			jQuery(elementId).removeAttr(attr);
	} catch (ex) {
		log(ex);
	}
};
