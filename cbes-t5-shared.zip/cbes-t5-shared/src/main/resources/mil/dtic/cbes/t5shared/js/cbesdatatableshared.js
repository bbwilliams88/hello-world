/**
 * Called by Tapestry to save the index of each column before the DataTable
 * re-arranges the columns.  Enables getIndex() to function later in life.
 */
function beforeDatatable(id)
{
	jQuery('#' + id + ' th').each(function(index) { jQuery('#' + id).data(this.id, index); });
}

/**
 * Returns the saved column index value for the given header ID.
 * 
 * @param headerId The column name key to find the saved index.
 * @param tableId optional table id - defaults to 'datatable'
 * @returns The index for the column name.
 */
function getIndex(headerId,tableId)
{
	var selector = tableId == undefined ? '#datatable' : '#' + tableId;
	return jQuery(selector).data(headerId);
}

/**
 * Gets a cookie from the browser.
 * 
 * @param name The name of the cookie.
 * @returns The value of the cookie or null if the cookie doesn't exist.
 */
function getCookie(name)
{
	var cookies = document.cookie.split(/[; ]+/);

	for (var i = 0; i < cookies.length; i++)
	{
		var cookieName = cookies[i].substring(0, cookies[i].indexOf('='));

		if (cookieName == name)
			return cookies[i].substring(cookies[i].indexOf('=') + 1);
	}

	return null; // No cookie for you.
}