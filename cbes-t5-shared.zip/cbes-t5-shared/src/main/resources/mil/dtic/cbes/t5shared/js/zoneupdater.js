var ZoneUpdater = Class.create( {
	initialize : function(spec) {
		try {
			this.element = $(spec.elementId);
			this.url = spec.url;
			$T(this.element).zoneId = spec.zone;
			if (spec.event) {
				this.event = spec.event;
				this.element.observe(this.event, this.updateZone.bindAsEventListener(this));
			}
		} catch (ex) {
			log(ex);
		}
	},
	updateZone : function() {
		var zoneManager = Tapestry.findZoneManager(this.element);
		var updatedUrl = this.url;
		//remove query params temporarily
		var queryparams = updatedUrl.match(/\?[^\?]*$/);
		updatedUrl = updatedUrl.replace(/\?[^\?]*$/g, '');
		//tack on a random number as a 2nd param to make tapestry happy (it doesn't like one null param).
		var param = '' + this.element.value;
		param = URLEncoder.encodeForUrl(param);
		updatedUrl = updatedUrl + '/' + param + '/' + Math.random();
		//put queryparams back on
		if (queryparams)
			updatedUrl = updatedUrl + queryparams;
		zoneManager.updateFromURL(updatedUrl);
	}
});