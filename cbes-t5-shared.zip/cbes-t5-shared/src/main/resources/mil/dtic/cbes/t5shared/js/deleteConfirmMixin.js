//Show a Yes/No delete confirmation with a certain message
//Only works on <a> in IE, unless a linksubmit is involved.

(function() {
	if (!window.CBES) window.CBES = {};
	var modalOverlay;
	var currentTargetElement; // current element that needs onclick fired on it, set on initial show of dialog
	function fireOnclickEvent(link) {
		var cancelled = false;
		if (document.createEvent) {
			var event = document.createEvent("MouseEvents");
			event.initMouseEvent("click", true, true, window,
					0, 0, 0, 0, 0,
					false, false, false, false,
					0, null);
			cancelled = !link.dispatchEvent(event);
		}
		else if (link.fireEvent) {
			cancelled = !link.fireEvent("onclick");
		}
		return cancelled;
	}
	window.CBES.deleteConfirmMixin = function(elementid,message) {
		var element = jQuery(elementid);
		element.click(function(e) {
			if (e.button != 1 && e.button != 4) // don't do it for middle clicks (4 is for IE)
			{
				try {
					jQuery("#delete_confirm_message").text(message);
					modalOverlay.overlay().load();
					if (e.target && e.target.tagName === "a") {
						currentTargetElement = e.target;
					} else {
						currentTargetElement = jQuery(e.target).parents("a").first()[0];
					}
					e.stopPropagation();
					e.preventDefault();
				} catch (ex) {
					log(ex);
				}
			}
		});
		if (typeof modalOverlay == "undefined")
		{
			// Create the shared modal overlay for later use.
			modalOverlay = jQuery("#delete_confirm").overlay({
				top: 160, // Top position.
				mask: {
					color: '#ebecff',
					loadSpeed: 200, // Load mask a little faster.
					opacity: 0.6,
					zIndex: 99999
				},
				closeOnClick: false, // Disable this for modal dialog-type of overlays.
				load: false, // Don't load immediately.
				target: '#delete_confirm'
			});
			jQuery("#delete_confirm_yes").click(function(e){
				try {
					modalOverlay.overlay().close();
					window.setTimeout(function() { //delay 300ms to let the progress thingie show, if it's enabled
						var cancelled = fireOnclickEvent(currentTargetElement);
						if (!cancelled && currentTargetElement.href) {
							// <a>-only workaround for IE not natively listening to trigger onClicks
							window.location = currentTargetElement.href;
						}
					}, 300);
				} catch (ex) {
					log(ex);
				}
			});
			jQuery("#delete_confirm_no").click(function(e){
				try {
					modalOverlay.overlay().close();
					e.preventDefault(); // Do not submit the form.
				} catch (ex) {
					log(ex);
				}
			});
		}
	};
}).call(this);