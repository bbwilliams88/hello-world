// utility function for rendering dropzone responses
// sanitizes filenames for use as DOM element id's
function getIdFilename(fileNameStr) {
  return fileNameStr.replace(/[\s\\.]/g, '_');
}

function getDefaultDropzoneConfig(prefix, url) {
  var previewTemplate = $('.' + prefix + '-row').parent().html();
  $('.' + prefix + '-row').remove();
  
  return {
     'url': url,
     'parallelUploads': 20,
     'previewTemplate': previewTemplate,
     'acceptedFiles': 'application/pdf, application/zip, application/x-zip-compressed, text/xml',
     'autoQueue': false,
     'previewsContainer': '#' + prefix + 'Previews',
     'clickable': '#' + prefix + 'FileInput-button'
  };
}

function addDropzoneEventListeners(prefix, cxeDropzone) {
  cxeDropzone.on('addedfile', function(file) {
    $('#' + prefix + 'Form').find('.instruction').hide();
    var container = $(file.previewElement);
    container.find('.active').hide();
    container.find('.complete').hide();
    container.find('.start').click(function() {
      cxeDropzone.enqueueFile(file);
    });
  });
  
  cxeDropzone.on('removedfile', function(file) {
    var resultsId = "[id^="+prefix+"_"+getIdFilename(file.name)+"]";
    $(resultsId).remove();
  });
  
  cxeDropzone.on('uploadprogress', function(file, progress) {
    var progressBar = file.previewElement.querySelector('.progress-bar');
    progressBar.style.width = progress+'%';
    if(progress > 99) {
      progressBar.textContent = 'Upload complete.';
    }
  });
  
  cxeDropzone.on('sending', function(file, xhr, formData) {
    var csrfToken = $('#' + prefix + 'Csrf').val();
    formData.append('csrfToken', csrfToken);
    var container = $(file.previewElement);
    container.find('.progress').css('opacity', '1');
    container.find('.start').attr('disabled', 'disabled');
    container.find('.active').show();
  });
  
  cxeDropzone.on('success', function(file, response) {
    var container = $(file.previewElement);
    container.find('.active').hide();
    container.find('.complete').show();
  });
  
  cxeDropzone.on('error', function(file, message) {
    var errMsg = "An error occurred while uploading file " + file.name + ". Please try again.";
    var container = $(file.previewElement);
    container.find('.active').hide();
    container.find('.complete').show();
    container.find('[data-dz-errormessage]').text(errMsg);
    container.find('.progress-bar').text('Error');
  });
  
  cxeDropzone.on('reset', function() {
    $('#' + prefix + 'Form').find('.instruction').show();
  });
  
  $('#' + prefix + 'Form button.cancel').click(function() {
    cxeDropzone.removeAllFiles(true);
  });
}

//Basic Dropzone as found on the XML Tools and Build Docs page, with default event handlers set
//To customize (adding form data to the POST request for each file, etc), set additional event handlers
//Parameters:
//- prefix (string): use this in the IDs for your dropzone Template, Previews, Fileinput-button, and Form elements
//- url (string): destination URL to upload files to

var cxeDefaultDropzone = function(prefix, url) {
  var cxeDropzone = new Dropzone('#' + prefix + 'Form', getDefaultDropzoneConfig(prefix, url));
  addDropzoneEventListeners(prefix, cxeDropzone);
  return cxeDropzone;
};

//Dropzone component with the same default event handlers that accepts custom configuration for setup
//To customize further (adding form data to the POST request for each file, etc), set additional event handlers
//Parameters:
//- prefix (string): use this in the IDs for your dropzone Template, Previews, Fileinput-button, and Form elements
//- url (string): destination URL to upload files to
//- config (object): dropzone config properties to override; any properties not specified will be set to the defaults

var cxeCustomDropzone = function(prefix, url, config) {
  var defaults = getDefaultDropzoneConfig(prefix, url);
  var customConfig = $.extend({}, defaults, config);
  var cxeDropzone = new Dropzone('#' + prefix + 'Form', customConfig);
  addDropzoneEventListeners(prefix, cxeDropzone);
  return cxeDropzone;
}