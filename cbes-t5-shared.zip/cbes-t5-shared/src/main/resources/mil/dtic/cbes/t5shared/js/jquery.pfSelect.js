/*
	SELECTION TOOL
	
	USAGE:
	
	jQuery('#tableID').select({
		accepts: 'selectable', 			// default class to define which elements are going to be selectable
		selectElement: null				// which element the function should select (if td's are selectable, you can define the parent table row to be selected by setting the value to 'tr'
		selectElement:'tr',				// which parent element should be selected. If blank, the element itself will be selected	
		targetWindow: '#page',    		// is needed when you click outside an area
		filterClass: 'noDeselect',		// don't deselect elements when clicking on the filter
		onselect : false,				// when an element is selected, the target objects gets passed into the function 
        ondeselect : false,				// when an element is deselected, the target objects gets passed into the function 
        onDragStart : false,			// when the drag starts, the event is passed 
        onDragStop : false				// when the drag stops, the event is passed 
	});
	
	!! WORKS REALLY WELL TOGETHER WITH THE CONTEXT MENU PLUGIN.
*/

jQuery.selector = {
	drag  : 0,
	first : null,
	last : null,
	sA : [],

	build : function (options){
		var o = jQuery.extend({
	        accepts: 'selectable',
	        selectElement: null, // if null then you select the element itself, otherwise you can define a parent type like div and such
	        selectClass: 'selected',
	        targetWindow: '#deselectArea',
	        table: this,
	        filterClass: 'noDeselect',
	        onselect : false,
	        ondeselect : false,
	        onDragStart : false,
	        onDragStop : false
    	}, options);

		// extend the object with the selectorOptions which are used for the mouseup and mousedown events in the toggleWindowsdown and toggleWindowsup events
    	targetWindow = jQuery(o.targetWindow);
    	
    	// to prevent duplicate events we have to unbind the function before reattaching them
	    targetWindow.unbind('mousedown',jQuery.selector.targetWindowMouseDown).unbind('mouseup',jQuery.selector.targetWindowMouseUp);
	    targetWindow.bind('mousedown',{o:o},jQuery.selector.targetWindowMouseDown).bind('mouseup',{o:o},jQuery.selector.targetWindowMouseUp);

		// bind all the fun
	    sA = jQuery("." + o.accepts, this);
	    var unbound = sA.not('.pfclaimed');
	    unbound.addClass('pfclaimed');
	    unbound.mousedown(function(e){
	    	e.preventDefault();
			currentElement = o.selectElement ? jQuery(e.target).parents(o.selectElement+':first') : jQuery(e.target);
			if(e.shiftKey==true){
				jQuery.selector.last = e.target;
				jQuery.selector.deselectAll(o);
				// find out how to select
				firstIndex = sA.index(jQuery.selector.first);
				lastIndex  = sA.index(jQuery.selector.last);
				for (var x = Math.min(firstIndex,lastIndex); x <= Math.max(firstIndex,lastIndex); x++)
				{
					elm = o.selectElement ? jQuery(sA[x]).parents(o.selectElement+':first') : jQuery(sA[x]);
					jQuery.selector.select(elm,o);
				}
			}else{
				jQuery.selector.first = e.target;
				if(jQuery.selector.modifier1(e, false) && !jQuery(currentElement.get(0)).is('.'+o.selectClass)){
					jQuery.selector.deselectAll(o);
				}
				if(jQuery.selector.modifier1(e, true)){
					jQuery.selector.toggle(currentElement,o);
				}else{
					jQuery.selector.select(currentElement,o);
				}

			}
	    })
	    .mouseover(function(e){
	    	currentElement = o.selectElement ? jQuery(e.target).parents(o.selectElement+':first') : jQuery(e.target);
	    	if(jQuery.selector.drag==1){
	    		if(jQuery.selector.modifier1(e, true))
	    			jQuery.selector.toggle(currentElement,o);
	    		else
					jQuery.selector.select(currentElement,o);
	    	}
	    });
	},


    select: function(obj,o){
		// only selects when it is not already selected
    	if(!jQuery(obj.get(0)).is('.'+o.selectClass)){
	    	if(o.onselect){
	    		o.onselect(obj.get(0));
	    	}
			obj.addClass(o.selectClass);
    	}
    },

    deselect: function(obj,o){
    	if(o.ondeselect){o.ondeselect(obj.get(0));}
		obj.removeClass(o.selectClass);
    },

    toggle: function(obj,o){
    	if(jQuery(obj.get(0)).is('.'+o.selectClass)){
			jQuery.selector.deselect(obj,o);
    	}else{
    		jQuery.selector.select(obj,o);
    	}
    },

    deselectAll : function (o){
    	if(o){
			o.table.find('.' + o.selectClass).each(function(){
				jQuery.selector.deselect(jQuery(this),o);
			});
    	}else{
    		log('I wanna see this lame thing being called');
    		//in case we do not have the option we assume the default and deselect all visible objects with the selected class (selected is the default class)
    		jQuery('.selected:visible').each(function(){
				jQuery(this).removeClass('selected');
			});
    	}
    },

    targetWindowMouseDown : function (e){
    	var o = e.data.o;
    	if ((e.button != 0 && e.button != 1) || !jQuery(e.target).is('.' + o.accepts)) {
    		jQuery.selector.deselectAll(o);
    		return;
    	}
    	if(o.onDragStart){o.onDragStart(e);}
    		jQuery.selector.drag = 1;
    	if(!jQuery(e.target).is('.'+o.accepts)){
    		if(!jQuery(e.target).is('.'+o.filterClass))
				jQuery.selector.deselectAll(o);
    	}
    },

    targetWindowMouseUp : function (e){
    	var o = e.data.o;
    	if (e.button != 0 && e.button != 1) {
    		jQuery.selector.deselectAll(o);
    		return;
    	}
    	if(o.onDragStop){o.onDragStop(e);}
		jQuery.selector.drag = 0;
    },

    modifier1 : function(e, isPressed) {
    	var modifierPressed = e.metaKey ? e.ctrlKey || e.metaKey : e.ctrlKey; //kabuki dance to get around metaKey being undefined in IE
    	return modifierPressed == isPressed;
    }

};

jQuery.fn.pfselect = jQuery.selector.build;