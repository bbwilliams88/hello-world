class ZoneUpdater {
	constructor (spec){
		try {
			var element = jQuery("#" + spec.elementId);
			var zone = jQuery("#" + spec.zone);
			var updateZone = function() {
				if (Tapestry.findZoneManagerForZone) {
					//original Prototype way
					var updatedUrl = spec.url;
					//remove query params temporarily
					var queryparams = updatedUrl.match(/\?[^\?]*$/);
					updatedUrl = updatedUrl.replace(/\?[^\?]*$/g, '');
					//tack on a random number as a 2nd param to make tapestry happy (it doesn't like one null param).
					var param = '' + element.val();
					param = URLEncoder.encodeForUrl(param);
					updatedUrl = updatedUrl + '/' + param + '/' + Math.random();
					//put queryparams back on
					if (queryparams)
						updatedUrl = updatedUrl + queryparams;
					Tapestry.findZoneManagerForZone(zone[0]).updateFromURL(updatedUrl);
				} else {
					//the t5-jquery way
					var newValue = element.val() ? element.val() : "";
					var opts = {
						url: spec.url,
						type: "POST",
						data: {
							"selectedPdfOption": newValue,
							"t:formid": "form",
							"t:formcomponentid": "P40Edit:t5crudlayout.form",
							't:zoneid' : zone.attr('id')
						}
					}
					return $.ajax(opts);
				}
			};
			if (spec.event) {
				element.bind(spec.event, updateZone);
			}
			return {
				updateZone : updateZone
			};
		} catch (ex) {
			log(ex);
		}
	}
}