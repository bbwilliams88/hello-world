function log(s)
{
	if (typeof console != "undefined") {
		console.log(Array.prototype.slice.call(arguments));
		if (s instanceof Error) {
			if (console.error) console.error(s);
			//http://help.dottoro.com/ljfhismo.php
			if (s.line && s.sourceURL) //safari
				console.log(s.sourceURL + ':' + s.line);
			if (s.lineNumber && s.fileName) //ff
				console.log(s.fileName + ':' + s.lineNumber);
			if (s.stack) //chrome
				console.log(s.stack);
			if (typeof s.description != "undefined") //ie
				console.log(s.name + ',' + s.message + ',' + s.description + ',' + s.number);
		} else {
			//var error = new Error();
			//if (error.stack) console.log(error.stack);
		}
	}
}