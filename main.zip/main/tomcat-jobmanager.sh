#!/bin/sh

trap "kill -TERM 0; sleep 2; kill -9 0" INT TERM EXIT

. shared.sh
rmi start

MAVEN_OPTS=$MAVEN_OPTS; DBGPORT=8002;
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appName=$APP_NAME_JOBMANAGER $@" mvn -P tomcat,-svn,-replacer tomcat7:run -pl jobmanager -am &

tail -0f /logs/r2/${APP_NAME_JOBMANAGER}.log &

wait
