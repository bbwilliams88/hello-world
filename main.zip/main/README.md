# Comptroller XML Exhibits

This is the source code for the R2/P40 project. This application builds PDF documents for the Budget Estimate Submission (BES) and President's Budget (PB) from XML and related files. It also provides a web front-end for users from DoD agencies to edit their exhibits. The application can be accessed from the following URLs:

## DTIC AWS

- [https://exhibits.dtic.mil](https://exhibits.dtic.mil) (production)
- [https://exhibits.stg.dtic.mil](https://exhibits.stg.dtic.mil) (staging, used for testing)
- [https://exhibits-preview.cicd.dev-eval.net/](https://exhibits-preview.cicd.dev-eval.net/r2/newhomepage) (development)

## How to build locally

The best approach for building this project locally will depend on which operating system you are using as well as how you are accessing MySQL, but we'll outline (and hopefully keep updated) some of the most common approaches here.

For all environments, you will need:

- A MySQL database + schema to connect to
- A fake RMI/virus scanner
- A working installation of Maven, with access to all of this project's dependencies

The following configuration steps (should) be in common for all developers:

- create a new tomcat-context.xml file from the tomcat-context.xml.sample file
- edit the values in tomcat-context.xml to match how you connect to MySQL
- [https://www.dodtechipedia.mil/dodwiki/display/reference/Comptroller+XML+Exhibits](https://www.dodtechipedia.mil/dodwiki/display/reference/Comptroller+XML+Exhibits) view the OS specific setup guides for additional information. 
### On OS X / Linux

In the root level of this directory are a couple of shell scripts that are helpful in starting/stopping a local server. They are:

- tomcat-all.sh
- tomcat-r2.sh
- tomcat-p40.sh
- tomcat-jobmanager.sh
- tomcat-restapp.sh

Choose your shell script based on which portion of the app you wish to modify. Hopefully we will be merging these apps soon.

### On Windows

Windows users generally run the app from Maven builds inside of Eclipse. However, the fake virus scanner must be running in order to upload and download files. This is started from PowerShell.

The Maven commands for starting a local server inside of Eclipse are:

### Docker
- Create a war file of the application you want to deploy (R2, P40, etc.) by running mvn install or mvn install -DskipTests=true at the top level of CXE repo folder.
The war files are created in the following paths:
CXE/r2-frontend/target/r2.war || CXE/p40-frontend/target/p40.war)
- Unzip the war file(s); copy the tomcat-context.xml file in CXE into the unzipped war folder in META-INF as context.xml; open context.xml, change every "localhost" appearance to "host.docker.internal", and save.
- Add the server.xml file at the top level CXE folder.  Change the tomcat server.xml file to look like the deployment servers. The connector tag is the most important change. Attached is a server.xml file with the right information.
- Create a dependency folder at the top level CXE folder.  Move the jar files from Users/{yourUser}/.m2/repository/mysql/mysql-connector-j/{currentVersion} to the dependency folder.
- Create a Dockerfile at the top level CXE folder, attached is an example of a working one. Modify the directories of all files listed to match your directories, to make things simpler the dockerfile provided is in a folder where all the required folders/files are there at the top level with it.
- Open up the terminal in the folder where dockerfile is and build the container. Something like docker build -t r2 . should work.
- Now run/start the container. Something like docker run -dp 8081:8081 r2 should work.
- See [https://www.dodtechipedia.mil/dodwiki/display/reference/CXE+Containerization+in+Docker](https://www.dodtechipedia.mil/dodwiki/display/reference/CXE+Containerization+in+Docker) for additional information. 

