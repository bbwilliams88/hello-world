#!/bin/sh

# This script fixes problems with git seeing line ending differences as being unstaged changes.
# see: http://stackoverflow.com/questions/11383094/unstaged-changes-left-after-git-reset-hard

git rm .gitattributes
git add -A
git reset --hard
