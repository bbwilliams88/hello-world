#!/bin/bash
svn add .  --force
svn update --accept=mine-full
svn delete $( svn status | sed -e '/^!/!d' -e 's/^!//' ) #fix for svn can't find added file error 
svn resolve -R --accept=mine-full .
svn commit -m "Updating the svn ropository. Additional log details are contained in the git repo contained in the svn repo."