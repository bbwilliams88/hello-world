projname=R2
mavenjars=~/.m2/repository/**/*.jar
sourceanalyzer -Xmx1024M -source 1.6 -verbose -cp "$mavenjars" -build-project "$projname" **/src/main/**/* -f $projname.fpr
