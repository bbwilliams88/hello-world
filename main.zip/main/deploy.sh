#!/bin/sh


servers="dapp-ra dapp-rd stgra1 sapp-r1"

for server in $servers; do
	scp r2-frontend/target/r2.war $server:
	scp jobmanager/target/jobmanager.war $server:
	scp cbes-rest/target/restapp.war $server:
	scp p40-frontend/target/p40.war $server:
done

