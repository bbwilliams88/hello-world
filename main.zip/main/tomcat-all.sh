#!/bin/sh

trap "kill -TERM 0; sleep 2; kill -9 0" INT TERM EXIT

. shared.sh
rmi start

MAVEN_OPTS_ORIG=$MAVEN_OPTS

MAVEN_OPTS=$MAVEN_OPTS_ORIG; DBGPORT=8000;
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appName=${APP_NAME_R2} $@" mvn -P tomcat,-svn,-replacer tomcat7:run -pl r2-frontend -am &

MAVEN_OPTS=$MAVEN_OPTS_ORIG; DBGPORT=8001;
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appName=${APP_NAME_P40} $@" mvn -P tomcat,-svn,-replacer tomcat7:run -pl p40-frontend -am &

MAVEN_OPTS=$MAVEN_OPTS_ORIG; DBGPORT=8002;
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appName=${APP_NAME_JOBMANAGER} $@" mvn -P tomcat,-svn,-replacer tomcat7:run -pl jobmanager -am &

MAVEN_OPTS=$MAVEN_OPTS_ORIG; DBGPORT=8003;
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appName=${APP_NAME_RESTAPP} $@" mvn -P tomcat,-svn,-replacer tomcat7:run -pl cbes-rest -am &

wait
