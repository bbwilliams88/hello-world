#!/bin/sh

APP_NAME_R2="r2"
APP_NAME_P40="p40"
APP_NAME_RESTAPP="restapp"
APP_NAME_JOBMANAGER="jobmanager"
APP_NAME_LIST="${APP_NAME_R2},${APP_NAME_P40},${APP_NAME_RESTAPP},${APP_NAME_JOBMANAGER}"
APP_INSTANCE_ID=`whoami`
MAVEN_OPTS="$MAVEN_OPTS -Dmil.dtic.cbes.appInstanceId=$APP_INSTANCE_ID -Dmil.dtic.cbes.appNameList=$APP_NAME_LIST"

R2_LOG="/logs/r2/${APP_NAME_R2}.log"
P40_LOG="/logs/r2/${APP_NAME_P40}.log"
RESTAPP_LOG="/logs/r2/${APP_NAME_RESTAPP}.log"
JOBMANAGER_LOG="/logs/r2/${APP_NAME_JOBMANAGER}.log"

function cdexit
{
	cd "$PARENTDIR"
	exit 1
}

function clean_build_common
{
	PARENTDIR="$PWD"
	cd cbes-common
	mvn clean install -Dmaven.test.skip=true || cdexit
	cd "$PARENTDIR"
}

function build_common
{
	PARENTDIR="$PWD"
	cd cbes-common
	mvn install -Dmaven.test.skip=true || cdexit
	cd "$PARENTDIR"
}

#Run in parent dir, takes subproject DIR as env parameter
function clean
{
	PARENTDIR="$PWD"
	cd $DIR || exit 1
	mvn clean || cdexit
	cd "$PARENTDIR"
}

#rmi server
function rmi
{
	echo RMI is now disabled.
	return
	
	PARENTDIR="$PWD"
	RMIDIR=cbes-misc/rmi/dist/server
	cd "$RMIDIR" || cdexit
	case $1 in
		start)
			java -classpath cmdserver.jar -Xmx8m -XX:PermSize=4m -Djava.awt.headless=true -Djava.security.policy=all.policy -Djava.rmi.server.codebase="file://$PWD/cmdserver.jar" mil.dtic.utility.commandline.rmi.server.JavaCommandServiceImpl -uniqueName r2rminame -createRegistry&
			#export RMI_PID=$!
			;;
		stop)
			#./stopServer.sh
			#wait_kill_rmi
			trap "kill 0" INT TERM EXIT
			;;
		*)
			#whatever
			echo not doing rmi stuff
			;;
	esac
	cd "$PARENTDIR"
}

function wait_kill_rmi
{
	echo RMI is now disabled.
	return

	T=15
	if [ -n "$RMI_PID" ]; then
		#echo "sleep $T; kill -9 $RMI_PID" | at now #at is disabled on mac
		(sleep $T; kill -9 $RMI_PID >/dev/null)&
		wait $RMI_PID &> /dev/null
		if [ $? -eq 143 ]; then
			echo "WARNING - command was wtfpwnd - timeout of $T secs reached."
		fi
		unset RMI_PID
	else
		echo "WARNING - No RMI pid to force-kill found in \$RMI_PID... it might stop after 10secs, or it might not"
	fi
}
