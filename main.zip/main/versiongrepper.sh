#!/bin/sh

cbescommonold=4.6
cbescommonnew=4.7
r2old=4.6
r2new=4.7
p40old=1.2.4
p40new=1.2.5
jmold=1.2.2
jmnew=1.2.3
rsold=1.0.8
rsnew=1.0.9
t5old=5.3.1
t5new=5.3.2
tssold=3.0.0adam2
tssnew=3.0.4
spold=3.0.5.RELEASE
spnew=3.1.0.RELEASE

echo "'s/<cbes.common.version>$cbescommonold<\/cbes.common.version>/<cbes.common.version>$cbescommonnew<\/cbes.common.version>/g"
find . -name pom.xml -exec  perl -pi -e "s/<cbes.common.version>$cbescommonold<\/cbes.common.version>/<cbes.common.version>$cbescommonnew<\/cbes.common.version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<r2.version>$r2old<\/r2.version>/<r2.version>$r2new<\/r2.version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<p40.version>$p40old<\/p40.version>/<p40.version>$p40new<\/p40.version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<jobmanager.version>$jmold<\/jobmanager.version>/<jobmanager.version>$jmnew<\/jobmanager.version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<restapp.version>$rsold<\/restapp.version>/<restapp.version>$rsnew<\/restapp.version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<tapestry-release-version>$t5old<\/tapestry-release-version>/<tapestry-release-version>$t5new<\/tapestry-release-version>/g" {} \;
find . -name pom.xml -exec  perl -pi -e "s/<org.springframework.version>$spold<\/org.springframework.version>/<org.springframework.version>$spnew<\/org.springframework.version>/g" {} \;



#find . -name pom.xml -exec  perl -pi -e "s/<version>3.1-SNAPSHOT<\/version>/<version>3.1M3pre1148304<\/version>/g" {} \;