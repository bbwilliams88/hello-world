mvn clean compile flyway:info "-Pproduction,promptUser"
