 mvn clean compile install sql:execute "-Pproduction,load-validation-rules,promptUser"
 