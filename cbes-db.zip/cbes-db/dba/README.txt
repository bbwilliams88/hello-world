These PowerShell scripts are intended solely for the DBAs since they hard-code
the PRODUCTION environment into the scripts.  Developers shouldn't use them.
