mvn clean compile flyway:validate "-Pproduction,promptUser"
