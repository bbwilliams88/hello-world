SET TIME_ZONE='+00:00';
SET UNIQUE_CHECKS=0;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET SQL_NOTES=0;

DROP TABLE if EXISTS R2_SERV_AGY_APPN_BA_BSA;
DROP TABLE if EXISTS `P40_SERV_AGY_APPN_BA_BSA`;

DROP VIEW IF EXISTS v_r2_appn_ba;
DROP VIEW IF EXISTS v_r2_core;

CREATE ALGORITHM=UNDEFINED
VIEW `v_r2_core` AS
SELECT DISTINCT
fn_inc_var_session() AS `v_r2_core_id`,
`vb`.`sa_ID` AS `SERVICE_AGENCY_ID`, 
`vb`.`aa_ID` AS `APPN_ACCT_ID`, 
`vb`.`appn_code` AS `APPN_CODE`, 
`vb`.`appn_name` AS `APPN_NAME`, 
`vb`.`ba_ID` AS `BUDGET_ACTIVITY_ID`, 
`vb`.`ba_num` AS `BUDGET_ACTIVITY_NUM`, 
`vb`.`ba_title` AS `BUDGET_ACTIVITY_TITLE`,
`pbsa`.`bsa_ID` AS `BUDGET_SUB_ACTIVITY_ID`, 
`pbsa`.`bsa_num` AS `BUDGET_SUB_ACTIVITY_NUM`, 
`pbsa`.`bsa_title` AS `BUDGET_SUB_ACTIVITY_TITLE`
FROM `v_budget_activity_types` vb 
	 LEFT JOIN `proc_budget_sub_activity` as pbsa USING (ba_ID)
WHERE isR2 = 1
ORDER BY sa_ID, APPN_CODE, BA_NUM, BSA_NUM;

DROP VIEW IF EXISTS v_p40_appn_ba;
DROP VIEW IF EXISTS v_p40_core;

CREATE ALGORITHM=UNDEFINED
VIEW `v_p40_core` AS
SELECT DISTINCT 
fn_inc_var_session() AS `v_p40_core_id`,
`vb`.`sa_ID` AS `SERVICE_AGENCY_ID`, 
`vb`.`aa_ID` AS `APPN_ACCT_ID`, 
`vb`.`appn_code` AS `APPN_CODE`, 
`vb`.`appn_name`AS `APPN_NAME`, 
`vb`.`ba_ID` AS `BUDGET_ACTIVITY_ID`, 
`vb`.`ba_num` AS `BUDGET_ACTIVITY_NUM`, 
`vb`.`ba_title` AS `BUDGET_ACTIVITY_TITLE`,
`pbsa`.`bsa_ID` AS `BUDGET_SUB_ACTIVITY_ID`, 
`pbsa`.`bsa_num` AS `BUDGET_SUB_ACTIVITY_NUM`, 
`pbsa`.`bsa_title` AS `BUDGET_SUB_ACTIVITY_TITLE`
FROM `v_budget_activity_types` vb 
	 LEFT JOIN `proc_budget_sub_activity` as pbsa USING (ba_ID)
WHERE isR2 = 0
ORDER BY sa_ID, APPN_CODE, BA_NUM, BSA_NUM; 




