UPDATE `config` SET `cf_value`='PB 2021' WHERE `cf_name`='r2.budgetCycle';
