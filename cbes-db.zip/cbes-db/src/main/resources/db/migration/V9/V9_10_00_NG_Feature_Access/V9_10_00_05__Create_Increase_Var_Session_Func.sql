SET TIME_ZONE='+00:00';
SET UNIQUE_CHECKS=0;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET SQL_NOTES=0;

DROP function if EXISTS fn_inc_var_session;

DELIMITER ;;
CREATE FUNCTION `fn_inc_var_session`() RETURNS int(11)
	NO SQL
    NOT DETERMINISTIC
BEGIN
	
	if 
		@var >= 9999 then  set @var := 1;
	else
		set @var := IFNULL(@var,0) + 1;
	end if; 
	
		
	return @var;
END;;
DELIMITER ;

