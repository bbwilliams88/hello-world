UPDATE `config` SET `cf_value`='BES 2021' WHERE `cf_name`='r2.budgetCycle';
