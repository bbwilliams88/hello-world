SET TIME_ZONE='+00:00';
SET UNIQUE_CHECKS=0;
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET SQL_NOTES=0;


UPDATE `role` set `role_desc` = 'Can access R2/P40 exhbits icw their agency and edit them' WHERE `role_id` = 2;
UPDATE `role` set `role_desc` = 'Can access R2/P40 exhbits icw their agency and marginally manage users' WHERE `role_id` = 3;
UPDATE `role` set `role_desc` = 'Can access R2/P40 exhbits icw their agency and minimally manage users' WHERE `role_id` = 4;
UPDATE `role` set `role_desc` = 'Can view and download Justification Books processed for review' WHERE `role_id` = 5;
