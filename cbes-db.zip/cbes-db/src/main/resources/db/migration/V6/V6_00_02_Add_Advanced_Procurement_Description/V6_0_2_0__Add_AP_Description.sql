alter table proc_line_item add column `li_adv_proc_desc` mediumtext;
