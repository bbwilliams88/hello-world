ALTER TABLE `proc_advance_bdgt_just` DROP COLUMN `abj_cost_elem_UC_byd_ID`, DROP INDEX `FK_abj_CE_UC_byd_ID` ;
