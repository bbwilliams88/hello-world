ALTER TABLE `proc_item` ADD COLUMN `pi_mod_type` VARCHAR(255) NULL DEFAULT NULL  AFTER `pi_mod_item` ;
