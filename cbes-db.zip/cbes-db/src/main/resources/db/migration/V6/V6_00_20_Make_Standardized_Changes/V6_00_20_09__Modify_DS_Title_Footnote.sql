ALTER TABLE proc_delivery_schedule MODIFY COLUMN `sc_title_footnote` VARCHAR(3000) AFTER `sc_ID`;
