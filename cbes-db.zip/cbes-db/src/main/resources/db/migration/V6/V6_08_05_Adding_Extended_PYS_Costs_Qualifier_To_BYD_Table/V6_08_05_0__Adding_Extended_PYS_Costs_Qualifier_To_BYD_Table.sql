ALTER TABLE `proc_bdgt_yrs_data` ADD COLUMN `byd_isExtended` TINYINT(1) NULL DEFAULT NULL  AFTER `byd_parent_tab` ;
