ALTER TABLE `proc_advance_bdgt_just` CHANGE COLUMN `abj_cost_elem_qty_byd_ID` `abj_cost_elem_qty_byd_ID` INT(10) UNSIGNED NULL,
  CHANGE COLUMN `abj_cost_elem_UC_byd_ID` `abj_cost_elem_UC_byd_ID` INT(10) UNSIGNED NULL,
  CHANGE COLUMN `abj_cost_elem_cost_byd_ID` `abj_cost_elem_cost_byd_ID` INT(10) UNSIGNED NULL;
