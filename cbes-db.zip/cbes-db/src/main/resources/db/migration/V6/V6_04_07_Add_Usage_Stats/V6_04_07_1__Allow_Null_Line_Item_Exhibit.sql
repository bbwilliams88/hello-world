alter table usage_stats MODIFY COLUMN LINEITEM_ID int(10) unsigned;
alter table usage_stats MODIFY COLUMN EXHIBIT_ID int(10) unsigned;