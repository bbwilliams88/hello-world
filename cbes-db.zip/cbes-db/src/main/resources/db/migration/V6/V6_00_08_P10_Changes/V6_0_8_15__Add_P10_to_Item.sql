--Adding P10 to Item
alter table proc_item add column `proc_advance_rqmt_fk` INT UNSIGNED;
