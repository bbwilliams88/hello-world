alter table usage_stats
    drop foreign key FK_us_e_ID,
    DROP EXHIBIT_ID;