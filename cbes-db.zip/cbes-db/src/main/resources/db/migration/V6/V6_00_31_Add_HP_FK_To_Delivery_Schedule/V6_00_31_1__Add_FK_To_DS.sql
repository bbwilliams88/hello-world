alter table proc_delivery_schedule add column hp_delivery_total_fk int(10) unsigned;
