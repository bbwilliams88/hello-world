ALTER TABLE `proc_spare_part_item` 
  MODIFY COLUMN `spi_name` VARCHAR(255) NULL DEFAULT NULL  ;
 