ALTER TABLE `proc_ships_class` ADD COLUMN `sc_p27_remarks` TEXT NULL DEFAULT NULL  AFTER `sc_prod_sched_remarks` ;
