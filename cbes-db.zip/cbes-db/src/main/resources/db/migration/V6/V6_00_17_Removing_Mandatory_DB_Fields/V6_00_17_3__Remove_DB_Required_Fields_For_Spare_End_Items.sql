ALTER TABLE `proc_spare_part_end_item`
  MODIFY COLUMN `spei_name` VARCHAR(255) NULL  ;
