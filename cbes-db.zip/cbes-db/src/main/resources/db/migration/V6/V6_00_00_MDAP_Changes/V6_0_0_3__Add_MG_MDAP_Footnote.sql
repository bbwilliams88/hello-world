alter table proc_mod_grp add column mg_MDAP_footnote VARCHAR (3000) after mg_MDAP;
