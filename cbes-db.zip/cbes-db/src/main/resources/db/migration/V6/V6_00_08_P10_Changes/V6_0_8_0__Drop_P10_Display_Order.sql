-- Droping display order for the P10

alter table proc_advance_rqmt drop column ar_display_order;
