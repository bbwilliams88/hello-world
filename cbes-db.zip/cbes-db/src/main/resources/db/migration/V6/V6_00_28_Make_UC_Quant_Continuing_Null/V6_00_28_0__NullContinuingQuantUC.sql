UPDATE `proc_bdgt_yrs_data` SET `byd_continuing`=null WHERE `byd_type`='Q';

UPDATE `proc_bdgt_yrs_data` SET `byd_continuing`=null WHERE `byd_type`='U';

UPDATE `proc_bdgt_yrs_data` SET `byd_continuing_footnote`=null WHERE `byd_type`='Q';

UPDATE `proc_bdgt_yrs_data` SET `byd_continuing_footnote`=null WHERE `byd_type`='U';