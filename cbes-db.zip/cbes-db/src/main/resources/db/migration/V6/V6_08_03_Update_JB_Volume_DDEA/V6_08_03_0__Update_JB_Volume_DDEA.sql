UPDATE jb_volume 
SET bookDescription='Department of Defense Education Activity'
WHERE bookDescription='Department of Defense Education Activity (No Dependants)' ;