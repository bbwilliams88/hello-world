ALTER TABLE proc_item MODIFY COLUMN `pi_title_footnote` VARCHAR(3000) AFTER `pi_title`;
