alter table proc_item add column `pi_mod_item` tinyint(1);
