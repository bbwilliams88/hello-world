ALTER TABLE `proc_spare_part_rqmt`
 MODIFY COLUMN `spr_pys_delta` INT UNSIGNED AFTER `spr_total_byd_ID`;