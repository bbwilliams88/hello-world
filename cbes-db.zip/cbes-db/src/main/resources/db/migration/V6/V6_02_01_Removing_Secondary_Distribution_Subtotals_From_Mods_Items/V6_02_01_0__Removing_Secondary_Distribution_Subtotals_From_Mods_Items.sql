ALTER TABLE `proc_mod_item` DROP COLUMN `mi_sec_dist_qty_byd_ID` , DROP COLUMN `mi_sec_dist_subtot_byd_ID` ;
