ALTER TABLE `proc_mod_item_implem_meth` 
  MODIFY COLUMN `miim_name` VARCHAR(255) NULL  ;
