ALTER TABLE `proc_mod_grp`
 ADD COLUMN `mg_pys_delta` INT UNSIGNED;