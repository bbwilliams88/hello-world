alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_abj_ID;
alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_cec_ID;
