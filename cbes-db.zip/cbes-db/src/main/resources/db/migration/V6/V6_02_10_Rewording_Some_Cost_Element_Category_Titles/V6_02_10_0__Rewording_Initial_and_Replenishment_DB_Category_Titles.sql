UPDATE `proc_cost_elem_cat` SET `cec_title`='Initial Spares' WHERE `cec_title`='INITIAL';
UPDATE `proc_cost_elem_cat` SET `cec_title`='Replenishment Spares' WHERE `cec_title`='REPLENISHMENT';
