ALTER TABLE `proc_advance_rqmt`
 DROP PRIMARY KEY;
ALTER TABLE `proc_advance_rqmt`
 DROP `ar_ID`;