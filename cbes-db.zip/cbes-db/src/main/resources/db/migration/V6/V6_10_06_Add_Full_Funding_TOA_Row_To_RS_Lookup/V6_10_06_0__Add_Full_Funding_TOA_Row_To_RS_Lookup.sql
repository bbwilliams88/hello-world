INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('FF TOA', 'Full Funding TOA', 'C', 'A');
