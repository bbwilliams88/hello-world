update proc_budget_activity set ba_title='Joint Urgent Operational Needs Funds' where ba_title='Joint Urgent Operational Needs Fund';

update proc_budget_activity set ba_title='Mine Resistant Ambush Protected Vehicle Program' where ba_title='Mine Resistant Ambush Prot Veh Fund';

update proc_budget_activity set ba_status_flag='I' where ba_title='Communications & electronics equipment';

update proc_budget_activity set ba_status_flag='I' where ba_title='NATO Cooperative Defense Programs';

update proc_budget_activity set ba_status_flag='I' where ba_title='Procurement of Ammo, Air Force';

update proc_budget_activity set ba_status_flag='I' where ba_title='Ready Reserve Force';

update proc_budget_activity set ba_status_flag='I' where ba_title='Strategic Sealift Acquisition';

update proc_budget_activity set ba_status_flag='I' where ba_title='Transformation Savings';

update proc_budget_activity set ba_status_flag='I' where ba_title='Undistributed';

update proc_budget_activity set ba_status_flag='I' where ba_title='DHP Wedge Placeholder';

update proc_budget_activity set ba_status_flag='I' where ba_title='DoD Mobilization Assets';