INSERT INTO `proc_item_exhibit` (`ie_code`, `ie_title`, `ie_status_flag`) VALUES ('P-29/P-30', 'Combined Outfitting and Delivery Costs', 'A');
