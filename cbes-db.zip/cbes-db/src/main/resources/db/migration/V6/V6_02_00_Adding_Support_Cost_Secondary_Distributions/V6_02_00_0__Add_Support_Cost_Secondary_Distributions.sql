ALTER TABLE `proc_compo_split` ADD COLUMN `mgsc_ID` INT(10) UNSIGNED NULL  AFTER `mg_ID`;
