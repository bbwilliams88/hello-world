ALTER TABLE `proc_mod_milestone` 
  MODIFY COLUMN `mm_date` DATE NULL  , 
  MODIFY COLUMN `mm_title` VARCHAR(255) NULL  ;
