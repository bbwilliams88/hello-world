update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='0117D';

update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='0130';

update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='4557N';

update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='0460';

update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='0370D';

update APPROP_ACCOUNT set aa_status_flag='I' where BUDGES_APPROP_ACCT_CODE='0370D';

update APPROP_ACCOUNT set BUDGES_APPROP_ACCT_NAME='National Guard and Reserve Equipment' where BUDGES_APPROP_ACCT_NAME='National Guard & Reserve Equipment';

update APPROP_ACCOUNT set BUDGES_APPROP_ACCT_NAME='Shipbuilding and Conversion, Navy' where BUDGES_APPROP_ACCT_NAME='Shipbuilding & Conversion, Navy';