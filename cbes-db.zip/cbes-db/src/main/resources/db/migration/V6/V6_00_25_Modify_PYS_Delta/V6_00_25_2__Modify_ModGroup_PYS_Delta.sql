ALTER TABLE `proc_mod_grp`
 MODIFY COLUMN `mg_pys_delta` INT UNSIGNED AFTER `mg_total_cost_byd_ID`;