ALTER TABLE `proc_spare_part_rqmt`
  MODIFY COLUMN `spr_name` VARCHAR(255) NULL  ;
