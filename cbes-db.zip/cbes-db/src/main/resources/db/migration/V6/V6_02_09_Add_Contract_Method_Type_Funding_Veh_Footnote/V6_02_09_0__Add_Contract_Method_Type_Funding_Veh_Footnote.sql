-- Add a footnote column to the contract_method_type_fundveh table
alter table proc_history_and_planning add column hp_cmtf_footnote text;