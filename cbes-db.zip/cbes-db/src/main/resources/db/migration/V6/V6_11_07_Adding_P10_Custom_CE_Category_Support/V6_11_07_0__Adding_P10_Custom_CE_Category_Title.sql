ALTER TABLE `proc_advance_bdgt_just` ADD COLUMN `abj_custom_cat_title` VARCHAR(200) NULL DEFAULT NULL COMMENT '' AFTER `abj_category`;
