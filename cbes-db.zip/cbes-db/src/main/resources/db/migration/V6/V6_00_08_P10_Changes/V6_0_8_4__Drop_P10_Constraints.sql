alter table proc_manufacturer drop FOREIGN KEY FK_cem_abj_ID;
