alter table proc_mod_item add column mi_MDAP VARCHAR (4), add column mi_MDAP_footnote VARCHAR (3000);
