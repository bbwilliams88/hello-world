-- Set fixed flag to permissions
UPDATE `permission` SET `perm_fixed`='1' WHERE `perm_name`='ROLE_P40_ADMIN_TOOLS';