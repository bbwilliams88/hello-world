alter table `proc_cost_element` drop FOREIGN KEY `FK_ce_qty_byd_ID`;
