ALTER TABLE `proc_mod_item_implem_meth` drop column `miim_install_name`, 
drop column `miim_install_name_footnote`;
