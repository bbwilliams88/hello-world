alter table proc_spare_part_rqmt add column spr_name_footnote varchar(3000);
