alter table proc_spare_part_end_item add column spei_MDAP_footnote VARCHAR (3000) after spei_MDAP;
