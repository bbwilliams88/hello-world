alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_ar_ID;
