alter table proc_delivery_schedule add column sc_title_footnote varchar(3000);
