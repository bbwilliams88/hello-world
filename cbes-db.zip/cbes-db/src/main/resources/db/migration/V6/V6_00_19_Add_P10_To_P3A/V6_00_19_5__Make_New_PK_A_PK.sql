ALTER TABLE `proc_advance_rqmt`
 ADD PRIMARY KEY (`ar_ID`);