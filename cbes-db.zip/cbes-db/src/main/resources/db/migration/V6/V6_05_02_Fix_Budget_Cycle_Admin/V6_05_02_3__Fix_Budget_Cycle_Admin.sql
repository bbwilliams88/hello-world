ALTER TABLE `budget_cycle_config` ADD COLUMN label VARCHAR(255);
ALTER TABLE `budget_cycle_config` MODIFY cycle VARCHAR(10);