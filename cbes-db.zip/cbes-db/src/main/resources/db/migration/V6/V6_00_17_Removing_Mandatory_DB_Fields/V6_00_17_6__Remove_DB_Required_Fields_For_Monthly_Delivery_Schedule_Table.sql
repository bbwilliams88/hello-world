ALTER TABLE `proc_deliv_sched_monthly_prod` MODIFY COLUMN `dsmp_date` DATE NULL  ;
