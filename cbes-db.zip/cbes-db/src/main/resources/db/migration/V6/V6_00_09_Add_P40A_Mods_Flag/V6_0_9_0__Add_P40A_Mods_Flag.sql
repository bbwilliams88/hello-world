alter table proc_item_group_40A add column `ig_mods_indicator` tinyint(1);
