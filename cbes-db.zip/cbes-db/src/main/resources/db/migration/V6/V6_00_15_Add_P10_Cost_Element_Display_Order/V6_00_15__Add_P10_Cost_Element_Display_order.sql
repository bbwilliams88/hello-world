ALTER TABLE `proc_quantity_for_budget_year` 
add column `display_order` smallint(5) UNSIGNED NULL AFTER `proc_advance_bdgt_just_fk`;