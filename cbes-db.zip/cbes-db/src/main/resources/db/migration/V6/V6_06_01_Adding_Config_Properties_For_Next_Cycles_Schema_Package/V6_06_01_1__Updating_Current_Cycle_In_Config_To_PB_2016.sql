UPDATE `config` SET `cf_value`='PB 2016' WHERE `cf_name`='r2.budgetCycle';
