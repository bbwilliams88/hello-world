alter table proc_line_item add column `li_adv_proc_P1_item_num` varchar(25);
