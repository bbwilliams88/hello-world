ALTER TABLE `proc_advance_rqmt` DROP COLUMN `ar_end_item_qty_byd_ID` ;
