ALTER TABLE `proc_advance_bdgt_just` DROP COLUMN `abj_PLT` ;
