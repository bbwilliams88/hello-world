alter table `proc_mod_grp` drop column `mg_proc_support_subtot_byd_ID`;
