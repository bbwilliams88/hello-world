ALTER TABLE `proc_line_item`
 ADD COLUMN `li_pys_delta` INT UNSIGNED;