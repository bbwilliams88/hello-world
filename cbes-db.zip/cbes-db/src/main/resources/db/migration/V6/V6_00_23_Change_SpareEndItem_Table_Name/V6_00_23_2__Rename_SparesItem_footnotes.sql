ALTER TABLE `proc_spare_part_item`
 CHANGE COLUMN `spei_MDAP_footnote` `spi_MDAP_footnote` VARCHAR(3000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
