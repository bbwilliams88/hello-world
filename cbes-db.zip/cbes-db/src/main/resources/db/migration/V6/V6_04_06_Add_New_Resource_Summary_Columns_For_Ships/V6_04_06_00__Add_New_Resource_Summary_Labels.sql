INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Less CTC', 'Less Cost To Complete', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Less Hurricane', 'Less Hurricane Supplemental', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Less SY FF', 'Less Subsequent Year Full Funding', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Plus SY FF', 'Plus Subsequent Year Full Funding', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Plus CTC', 'Plus Cost To Complete', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Plus Hurricane', 'Plus Hurricane Supplemental', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Plus OAPD', 'Plus Outfitting And Post Delivery', 'C', 'A');
INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('All LI Total', 'All Line Items Total', 'C', 'A');
