alter table proc_cost_elem_cat_exhibit add column `total_cost_proc_bdgt_yrs_data_fk` INT UNSIGNED;
alter table proc_cost_elem_cat_exhibit add column `unit_cost_proc_bdgt_yrs_data_fk` INT UNSIGNED;
alter table proc_cost_elem_cat_exhibit add column `quantity_proc_bdgt_yrs_data_fk` INT UNSIGNED;
