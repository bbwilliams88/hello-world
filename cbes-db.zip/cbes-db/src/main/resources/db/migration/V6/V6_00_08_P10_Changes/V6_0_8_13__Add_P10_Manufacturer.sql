--Adding columns for Manufacturer to the P10 Cost Element table
alter table proc_advance_bdgt_just add column `proc_manufacturer_fk` INT UNSIGNED;
