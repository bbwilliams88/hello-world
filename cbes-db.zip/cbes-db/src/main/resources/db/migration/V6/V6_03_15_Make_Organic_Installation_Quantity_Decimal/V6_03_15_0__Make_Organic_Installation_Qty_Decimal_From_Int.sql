ALTER TABLE `proc_mod_item_implem_meth` CHANGE COLUMN `miim_qty` `miim_qty` DECIMAL(12,3) UNSIGNED NULL DEFAULT NULL  ;
