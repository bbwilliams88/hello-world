ALTER TABLE `proc_item`
 ADD COLUMN `pi_pys_delta` INT UNSIGNED;