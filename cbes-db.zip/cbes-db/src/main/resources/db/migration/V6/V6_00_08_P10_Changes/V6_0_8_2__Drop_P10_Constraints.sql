alter table proc_advance_rqmt drop FOREIGN KEY FK_ar_EI_cost_byd_ID;
alter table proc_advance_rqmt drop FOREIGN KEY FK_ar_EI_qty_byd_ID;
alter table proc_advance_rqmt drop FOREIGN KEY FK_ar_EI_UC_byd_ID;
