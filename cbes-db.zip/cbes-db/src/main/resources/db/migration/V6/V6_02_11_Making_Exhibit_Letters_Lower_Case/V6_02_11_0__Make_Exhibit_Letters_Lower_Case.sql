UPDATE `proc_item_exhibit` SET `ie_code`='P-40a' WHERE `ie_code`='P-40A';
UPDATE `proc_item_exhibit` SET `ie_code`='P-5a' WHERE `ie_code`='P-5A';
UPDATE `proc_item_exhibit` SET `ie_code`='P-3a' WHERE `ie_code`='P-3A';
