ALTER TABLE proc_line_item MODIFY COLUMN `li_mods_out_years_delta` INT UNSIGNED AFTER `li_P26_count`;
