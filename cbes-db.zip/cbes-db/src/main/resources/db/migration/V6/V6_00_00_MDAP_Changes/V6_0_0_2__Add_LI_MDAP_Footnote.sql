alter table proc_line_item add column li_MDAP_footnote VARCHAR (3000) after li_MDAP;
