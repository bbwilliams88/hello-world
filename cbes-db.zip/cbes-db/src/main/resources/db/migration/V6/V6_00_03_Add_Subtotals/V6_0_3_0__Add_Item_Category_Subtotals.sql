alter table proc_item_cat_40A add column `total_cost_proc_bdgt_yrs_data_fk` INT UNSIGNED;
alter table proc_item_cat_40A add column `unit_cost_proc_bdgt_yrs_data_fk` INT UNSIGNED;
alter table proc_item_cat_40A add column `quantity_proc_bdgt_yrs_data_fk` INT UNSIGNED;
