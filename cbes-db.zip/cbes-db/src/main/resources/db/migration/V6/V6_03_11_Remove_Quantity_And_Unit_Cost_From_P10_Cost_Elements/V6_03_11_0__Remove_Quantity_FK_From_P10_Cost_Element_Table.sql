ALTER TABLE `proc_advance_bdgt_just` DROP COLUMN `abj_cost_elem_qty_byd_ID`, DROP INDEX `FK_abj_CE_qty_byd_ID` ;
