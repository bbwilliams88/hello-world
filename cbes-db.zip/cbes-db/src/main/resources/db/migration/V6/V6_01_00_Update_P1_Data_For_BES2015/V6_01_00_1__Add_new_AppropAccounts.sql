insert into APPROP_ACCOUNT (BUDGES_APPROP_ACCT_ID, BUDGES_APPROP_ACCT_CODE, BUDGES_APPROP_ACCT_NAME, aa_status_flag) values ('10020', '0390A', 'Chem Agents & Munitions Ds, Army', 'A');
