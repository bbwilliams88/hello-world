ALTER TABLE `proc_ships_class` ADD COLUMN `proc_advance_rqmt_fk` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `cec_tot_byd_ID` ;
