ALTER TABLE `proc_compo_split`
 ADD COLUMN `cs_outyear_quantity_delta` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `cs_mods_out_years_delta`;