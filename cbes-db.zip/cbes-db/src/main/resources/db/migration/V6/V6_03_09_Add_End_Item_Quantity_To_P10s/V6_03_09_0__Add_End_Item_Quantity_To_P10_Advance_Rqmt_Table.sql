ALTER TABLE `proc_advance_rqmt` ADD COLUMN `ar_end_item_qty_byd_ID` INT(10) UNSIGNED NULL  AFTER `ar_other_subtot_byd_ID` ;
