ALTER TABLE `proc_mod_item`
DROP COLUMN mi_MDAP, DROP COLUMN mi_MDAP_footnote;