ALTER TABLE `proc_spare_part_rqmt`
 ADD COLUMN `spr_pys_delta` INT UNSIGNED;