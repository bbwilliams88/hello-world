ALTER TABLE `proc_related_PE` 
  MODIFY COLUMN `rpe_PE_num` VARCHAR(10) NULL  ;
