ALTER TABLE `proc_ships_class` ADD COLUMN `sc_prod_sched_remarks` TEXT NULL DEFAULT NULL  AFTER `sc_title_footnote` ;
