ALTER TABLE `proc_item` ADD COLUMN `pi_mod_type_footnote` TEXT NULL DEFAULT NULL  AFTER `pi_mod_type` ;
