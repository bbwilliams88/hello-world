ALTER TABLE `proc_ships_class` DROP COLUMN `sc_bdgt_yrs_for_pdf` ;
