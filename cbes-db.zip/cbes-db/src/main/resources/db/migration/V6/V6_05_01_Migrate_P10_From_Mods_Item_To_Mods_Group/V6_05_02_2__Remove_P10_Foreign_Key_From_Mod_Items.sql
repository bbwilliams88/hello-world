ALTER TABLE `proc_mod_item`
DROP proc_advance_rqmt_fk;