alter table proc_item add column `pi_title_footnote` varchar(3000);
