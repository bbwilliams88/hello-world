UPDATE `config` SET `cf_value`='PB 2017' WHERE `cf_name`='r2.budgetCycle';
