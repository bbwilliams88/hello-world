INSERT INTO `proc_resource_summ_entry_lkup` (`rsel_title`, `rsel_desc`, `rsel_type`, `rsel_status_flag`) VALUES ('Less PY FF', 'Less Prior Year Full Funding', 'C', 'A'), 
                                                                                                                ('Plus PY FF', 'Plus Prior Year Full Funding', 'C', 'A');
