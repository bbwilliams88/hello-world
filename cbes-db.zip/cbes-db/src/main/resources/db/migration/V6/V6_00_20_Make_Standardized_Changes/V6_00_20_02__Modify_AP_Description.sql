ALTER TABLE proc_line_item MODIFY COLUMN `li_adv_proc_desc` MEDIUMTEXT AFTER li_compo_split_remarks;
