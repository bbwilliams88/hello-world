ALTER TABLE `proc_ships_outfitting_delivery_cost_type` 
DROP COLUMN `sodt_category`;
