ALTER TABLE `proc_delivery_schedule` MODIFY COLUMN `ds_proc_qty` DECIMAL(15,3) UNSIGNED DEFAULT NULL ;
