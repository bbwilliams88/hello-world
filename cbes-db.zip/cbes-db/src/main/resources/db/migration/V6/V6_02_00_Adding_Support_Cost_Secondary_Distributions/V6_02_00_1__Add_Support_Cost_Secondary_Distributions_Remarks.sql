ALTER TABLE `proc_mod_grp` ADD COLUMN `mg_support_compo_split_remarks` TEXT NULL DEFAULT NULL  AFTER `mg_compo_split_remarks` ;
