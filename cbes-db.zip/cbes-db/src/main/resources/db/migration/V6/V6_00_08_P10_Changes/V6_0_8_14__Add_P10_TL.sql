--Adding Termination Liability to the P10 Cost Element Table
alter table proc_advance_bdgt_just add column `proc_termination_liability_fk` INT UNSIGNED;
