ALTER TABLE `proc_history_and_planning` CHANGE COLUMN `hp_new_option` `hp_new_option` ENUM('NEW','OPTION','VARIOUS') NULL DEFAULT NULL  ;
