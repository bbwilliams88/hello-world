UPDATE `proc_budget_sub_activity` SET `bsa_title`='Auxiliaries, Craft and Prior Yr Program Cost' WHERE `bsa_title`='Auxiliaries, Craft And Prior Yr Program Cost';
