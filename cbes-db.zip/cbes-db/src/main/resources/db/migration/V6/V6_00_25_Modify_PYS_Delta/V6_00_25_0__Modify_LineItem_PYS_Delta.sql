ALTER TABLE `proc_line_item`
 MODIFY COLUMN `li_pys_delta` INT UNSIGNED AFTER `li_P1_item_num`;