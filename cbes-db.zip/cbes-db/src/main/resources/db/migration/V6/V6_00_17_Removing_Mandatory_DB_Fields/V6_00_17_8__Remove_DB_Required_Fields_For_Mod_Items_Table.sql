ALTER TABLE `proc_mod_item` 
  MODIFY COLUMN `mi_title` VARCHAR(255) NULL  ;
