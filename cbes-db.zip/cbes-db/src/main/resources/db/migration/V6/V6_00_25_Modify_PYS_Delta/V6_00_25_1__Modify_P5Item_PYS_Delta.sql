ALTER TABLE `proc_item`
 MODIFY COLUMN `pi_pys_delta` INT UNSIGNED AFTER `pi_item_number`;