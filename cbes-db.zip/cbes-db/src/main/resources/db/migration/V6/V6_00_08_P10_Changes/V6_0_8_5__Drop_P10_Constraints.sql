alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_CE_cost_byd_ID;
alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_CE_qty_byd_ID;
alter table proc_advance_bdgt_just drop FOREIGN KEY FK_abj_CE_UC_byd_ID;
