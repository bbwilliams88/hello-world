ALTER TABLE `proc_history_and_planning` CHANGE COLUMN `hp_qty` `hp_qty` DECIMAL(15,3) UNSIGNED NULL DEFAULT NULL  ;
