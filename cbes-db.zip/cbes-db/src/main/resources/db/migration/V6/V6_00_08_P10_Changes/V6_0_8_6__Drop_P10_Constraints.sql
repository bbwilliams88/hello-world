alter table proc_advance_rqmt drop FOREIGN KEY FK_ar_lie_ID;
