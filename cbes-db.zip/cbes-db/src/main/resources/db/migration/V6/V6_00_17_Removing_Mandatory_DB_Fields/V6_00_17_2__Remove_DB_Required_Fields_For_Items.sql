ALTER TABLE `proc_item`
  MODIFY COLUMN `pi_title` VARCHAR(255) NULL  ;
