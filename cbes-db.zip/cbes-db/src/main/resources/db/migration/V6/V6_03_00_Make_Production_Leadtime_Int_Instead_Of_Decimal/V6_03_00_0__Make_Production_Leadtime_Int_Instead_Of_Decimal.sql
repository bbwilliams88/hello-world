ALTER TABLE `proc_advance_rqmt` CHANGE COLUMN `ar_production_leadtime` `ar_production_leadtime` INT(10) NULL DEFAULT NULL  ;
