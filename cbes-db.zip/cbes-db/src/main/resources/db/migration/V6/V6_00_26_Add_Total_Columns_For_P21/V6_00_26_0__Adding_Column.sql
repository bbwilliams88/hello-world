ALTER TABLE `proc_history_and_planning` ADD COLUMN `hp_delivery_total_fk` INT(10) NULL  AFTER `date_modified` ;
