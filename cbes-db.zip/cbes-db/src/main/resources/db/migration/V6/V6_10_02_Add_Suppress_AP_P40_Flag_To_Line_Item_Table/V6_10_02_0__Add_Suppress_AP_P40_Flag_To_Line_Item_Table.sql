ALTER TABLE `proc_line_item` ADD COLUMN `li_suppress_ap_p40` TINYINT(1) NULL DEFAULT NULL  AFTER `p40_short` ;
