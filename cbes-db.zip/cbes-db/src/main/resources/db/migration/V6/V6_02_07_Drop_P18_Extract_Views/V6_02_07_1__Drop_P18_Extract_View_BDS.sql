-- This view references invalid tables/columns/functions and is no longer needed/used.
drop view if exists v_extract_p18_cat_bdgtdata_sum;
