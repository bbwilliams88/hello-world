ALTER TABLE `proc_mod_item_manuf` 
  MODIFY COLUMN `mim_name` VARCHAR(125) NULL  , 
  MODIFY COLUMN `mim_location` VARCHAR(125) NULL  ;
