alter table proc_advance_bdgt_just add column abj_category VARCHAR(100);
