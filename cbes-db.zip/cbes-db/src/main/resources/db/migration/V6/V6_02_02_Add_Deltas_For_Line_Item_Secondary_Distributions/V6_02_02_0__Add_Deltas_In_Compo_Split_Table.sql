ALTER TABLE `proc_compo_split` ADD COLUMN `cs_mods_out_years_delta` INT(10) UNSIGNED NULL DEFAULT NULL  AFTER `cs_total_byd_ID` ;
