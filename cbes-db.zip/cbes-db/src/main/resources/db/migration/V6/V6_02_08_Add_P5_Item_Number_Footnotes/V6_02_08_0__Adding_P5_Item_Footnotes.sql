ALTER TABLE `proc_item` ADD COLUMN `pi_item_number_footnote` VARCHAR(3000) NULL  AFTER `pi_item_number` ;
