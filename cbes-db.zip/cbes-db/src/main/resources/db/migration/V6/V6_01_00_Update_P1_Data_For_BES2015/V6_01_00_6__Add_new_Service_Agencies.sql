insert into SERVICE_AGENCY (BUDGES_SERV_AGY_ID, BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME, NO_WARNING) values ('84', 'CIFA', 'Counterintelligence Field Activity' ,'9999', 'A', '0','TEST.png', 'N');

insert into SERVICE_AGENCY (BUDGES_SERV_AGY_ID, BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME, NO_WARNING) values ('85', 'DEFR', 'Defense Reserve' ,'9999', 'A', '0','TEST.png', 'N');

insert into SERVICE_AGENCY (BUDGES_SERV_AGY_ID, BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME, NO_WARNING) values ('86', 'DEFW', 'Defense Wide' ,'9999', 'A', '0','TEST.png', 'N');

insert into SERVICE_AGENCY (BUDGES_SERV_AGY_ID, BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME, NO_WARNING) values ('87', 'NDU', 'Nation Defense University' ,'9999', 'A', '0','TEST.png', 'N');

insert into SERVICE_AGENCY (BUDGES_SERV_AGY_ID, BUDGES_SERV_AGY_CODE, SERV_AGY_NAME, BUDGES_APPROP_ACCT_ID, sa_status_flag, sa_SMCA_tag, LOGO_FILE_NAME, NO_WARNING) values ('88', 'NGA', 'National Geospatial-Intelligence Agency' ,'9999', 'A', '0','TEST.png', 'N');
