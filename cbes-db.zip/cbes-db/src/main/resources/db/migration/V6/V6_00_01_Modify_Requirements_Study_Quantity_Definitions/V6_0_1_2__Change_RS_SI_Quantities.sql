alter table proc_rqmts_study_suppl_info modify column rqssi_py_qty decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column `rqssi_py-1_qty` decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column `rqssi_py-2_qty` decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column `rqssi_py-3_qty` decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column rqssi_by1_qty decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column rqssi_by2_qty decimal(14,3);
alter table proc_rqmts_study_suppl_info modify column rqssi_augment_qty decimal(14,3);
