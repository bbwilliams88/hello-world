alter table proc_rqmts_study_inv_obj modify column rqsio_elem_qty decimal(14,3);
