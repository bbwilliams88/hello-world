UPDATE proc_budget_sub_activity SET bsa_status_flag='I' WHERE bsa_title='Undistributed';
