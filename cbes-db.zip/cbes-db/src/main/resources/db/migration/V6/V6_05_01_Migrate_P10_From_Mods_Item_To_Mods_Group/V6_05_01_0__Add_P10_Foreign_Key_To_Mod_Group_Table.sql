ALTER TABLE `proc_mod_grp`
ADD proc_advance_rqmt_fk INT(10) UNSIGNED DEFAULT NULL;