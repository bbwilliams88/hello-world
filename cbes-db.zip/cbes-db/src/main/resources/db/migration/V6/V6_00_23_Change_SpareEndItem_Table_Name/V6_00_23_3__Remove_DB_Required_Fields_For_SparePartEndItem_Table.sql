ALTER TABLE `proc_spare_part_item` 
  MODIFY COLUMN `spi_elem_num` VARCHAR(25) NULL DEFAULT NULL  ;
 