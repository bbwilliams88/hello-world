ALTER TABLE `proc_line_item` 
CHANGE COLUMN `li_bdgt_cycle` `li_bdgt_cycle` VARCHAR(14) NULL DEFAULT NULL COMMENT '' ;