ALTER TABLE `proc_line_item`  ADD COLUMN `li_tracking_note` VARCHAR(30) NULL DEFAULT NULL COMMENT '' AFTER `li_suppress_ap_p40`;
