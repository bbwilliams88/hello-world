ALTER TABLE `budget_cycle_config` 
CHANGE COLUMN `cycle` `cycle` VARCHAR(14) NULL DEFAULT NULL COMMENT '' ;