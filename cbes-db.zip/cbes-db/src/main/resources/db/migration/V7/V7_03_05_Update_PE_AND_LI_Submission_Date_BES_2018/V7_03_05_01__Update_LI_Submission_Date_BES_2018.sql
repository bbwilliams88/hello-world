UPDATE `proc_line_item` SET `li_submit_date`='2016-12-01' WHERE `li_submit_date`='2016-09-01';
