ALTER TABLE `config` 
CHANGE COLUMN `cf_cycle` `cf_cycle` VARCHAR(14) NOT NULL DEFAULT 'xxxxx' COMMENT '' ;