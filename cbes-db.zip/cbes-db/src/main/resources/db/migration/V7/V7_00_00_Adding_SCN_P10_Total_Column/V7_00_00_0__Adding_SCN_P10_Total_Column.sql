ALTER TABLE `proc_advance_rqmt` ADD COLUMN `ar_p10_tot_byd_ID` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT '' AFTER `ar_other_subtot_byd_ID`;
