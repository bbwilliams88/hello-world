UPDATE `config` SET `cf_value`='BES 2019' WHERE `cf_name`='r2.budgetCycle';
