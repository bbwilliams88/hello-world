INSERT IGNORE INTO role (role_name, role_desc)
VALUES ('ROLE_Analyst', 'Can access list of P40s in their agency and edit them'); 
