Update jb_volume 
set bookDescription = 'National Geospatial-Intelligence Agency'
where bookDescription = 'Defense Geospatial Intelligence Agency';

