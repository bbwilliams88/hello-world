UPDATE `config` SET `cf_value`='BES 2020' WHERE `cf_name`='r2.budgetCycle';
