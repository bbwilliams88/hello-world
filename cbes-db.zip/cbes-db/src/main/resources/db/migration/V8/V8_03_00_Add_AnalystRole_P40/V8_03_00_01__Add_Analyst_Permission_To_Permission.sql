INSERT IGNORE INTO permission (perm_name, perm_desc)
VALUES ('ROLE_P40_VIEW_ALL_JB_BUILDS', 'Can access all JB Builds'); 
