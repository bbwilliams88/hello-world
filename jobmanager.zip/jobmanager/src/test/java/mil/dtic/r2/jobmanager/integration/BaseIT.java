package mil.dtic.r2.jobmanager.integration;

public abstract class BaseIT
{
  protected static final String jobManagerUrl = "http://127.0.0.1:8085/jobmanager";
}
