package mil.dtic.r2.jobmanager.quartz;


import static org.junit.Assert.assertTrue;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;



public class QuartzJobInfoTest
{
	public final String JOB_NAME = "SimpleJobName";
	public final String GROUP_NAME = "SimpleGroupName";
	public final String JOB_ID = "1234567890123456";

	QuartzJobInfo testObj;
	
	public QuartzJobInfoTest()
	{
		
	}
	
	@Before
	public  void setUP()
	{
		testObj = new QuartzJobInfo();
	}
	
	
	@Test
	public void aSimpleTest()
	{
		testObj.setJobName(JOB_NAME);
		assertTrue(StringUtils.equals(JOB_NAME, testObj.getJobName()));
		testObj.setGroupName(GROUP_NAME);
		assertTrue(StringUtils.equals(GROUP_NAME, testObj.getGroupName()));
		testObj.setId(JOB_ID);
		assertTrue(StringUtils.equals(JOB_ID, testObj.getId()));
	}
}
