package mil.dtic.r2.jobmanager.tasks.jobs;

import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.quartz.TriggerListener;

public class QueryJobTriggerListener implements TriggerListener
{
	public static final String listenerName = "QueryTriggerListener";
	

	public String getName()
	{
		return listenerName;
	}

	public void triggerFired(Trigger trigger, JobExecutionContext context)
	{
		// we do nothing but veto a second query job
	}

	public boolean vetoJobExecution(Trigger trigger, JobExecutionContext context)
	{
		
		return QueryJob.getJobIsRunning();
	}

	public void triggerMisfired(Trigger trigger)
	{
		// we do nothing but veto a second query job

		
	}

	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			int triggerInstructionCode)
	{
		// we do nothing but veto a second query job

	}

	@Override
	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			CompletedExecutionInstruction triggerInstructionCode)
	{
		// we do nothing but veto a second query job
	}
}
