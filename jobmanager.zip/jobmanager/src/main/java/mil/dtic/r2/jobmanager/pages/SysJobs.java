package mil.dtic.r2.jobmanager.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.quartz.Trigger;
import org.apache.logging.log4j.Logger;

import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.utility.CbesLogFactory;

/**
 * System job list
 */
@SuppressWarnings("unused")
@Import(stylesheet = "context:css/SysJobs.css")
public class SysJobs
{
  private static final Logger log = CbesLogFactory.getLog(SysJobs.class);
  @Inject
  private ComponentResources componentResources;


  @Inject
  private IJobScheduler jobScheduler;


  @Property
  private Trigger sysjob;


  void setupRender()
  {

  }


//  Object onActionFromRunStopJob(String jobName)
//  {
//        SysJobInfo jobInfo = systemJobCatalog.getJobInfoForJobName(jobName);
//    
//        if (jobInfo == null)
//        {
//          quartzManager.startSysJobWithName(jobName, systemJobCatalog);
//        }
//        else
//        {
//          quartzManager.stopSysJobWithName(jobName, systemJobCatalog);
//        }
//  }

  public List<Trigger> getSysJobInfoList()
  {
    return jobScheduler.getSysJobInfo();
  }

  public String formatDate(Date d)
  {
    return new SimpleDateFormat("yyyy MM dd HH:mm:ss").format(d);
  }
}
