package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * Job to automatically deploy builds on dev. Hudson builds and outputs to the
 * /release directory, this job copies it over to the jboss deploy directory.
 */
public class DeploymentJob implements R2Job
{
  private static final Logger log = CbesLogFactory.getLog(DeploymentJob.class);

  public static final String TOUCHFILE_PATH = "/tmp/deploytouch";
  private static final String SRC_FILE_PATHS = "srcFilePaths";
  private static final String DEST_FILE_PATHS = "destFilePaths";
  private static final String R2_WAR = "r2War";
  private static final String P40_WAR = "p40War";
  private static final String REST_WAR = "restappWar";
  private static final String JM_WAR = "jobmanagerWar";


  @Autowired
  private ConfigService config;


  private Map<String, Long> warfileModtimes = new HashMap<String, Long>();


  @Override
  public void execute(Map<String, Object> jobData)
  {
    log.trace(jobData.get(JOB_NAME).toString());
    if (config.getEnableAutodeployer())
    {
      String rawSrcFilePaths = jobData.get(SRC_FILE_PATHS).toString();
      String rawDestFilePaths = jobData.get(DEST_FILE_PATHS).toString();

      boolean failed = false;
      try
      {
        JSONArray srcFilePaths = new JSONArray(rawSrcFilePaths);
        JSONObject destFilePaths = new JSONObject(rawDestFilePaths);

        boolean updatedWars = scanWars(srcFilePaths);

        if (updatedWars)
        {
          for (Object o : srcFilePaths)
          {
            failed |= doOneWar(o, destFilePaths);
          }
          if (failed)
          {
            log.error("Failures detected, logging jobdata: " + new HashMap<String, Object>(jobData));
          }
        }
        else
        {
          log.trace("No modified wars");
        }
      }
      catch (RuntimeException e)
      {

    	Util.error(log, "Failed to parse deployment job - " + new HashMap<String, Object>(jobData), e);
      }
    }
    else
    {
      log.trace("disabled");
    }
  }


  // return true if one of them has been modified since last deploy
  private boolean scanWars(JSONArray srcFilePaths)
  {
    try
    {
      for (Object o : srcFilePaths)
      {
        JSONObject warSrc = (JSONObject) o;
        String warname = warSrc.keys().iterator().next();
        String warpath = warSrc.getString(warname);
        File warFile = new File(warpath);
        if (!warFile.canRead())
        {
          log.error("Source war not readable - " + warpath);
          continue;
        }
        long modtime = warFile.lastModified();
        if (warfileModtimes.get(warpath) == null)
        {
          log.info("Initially adding " + warpath + " to watchlist");
          warfileModtimes.put(warpath, modtime);
        }
        if (warfileModtimes.get(warpath) < modtime)
        {
          Date olddate = warfileModtimes.get(warpath) == null ? null : new Date(warfileModtimes.get(warpath));
          log.info("Found modified war - " + warname + " - " + warpath + " - " + new Date(modtime) + " - " + (olddate == null ? "" : olddate.toString()));
          return true;
        }
      }
    }
    catch (RuntimeException e)
    {
      log.error("Error parsing source war list" + srcFilePaths, e);
    }
    return false;
  }


  // return true on failure
  private boolean doOneWar(Object o, JSONObject destFilePaths)
  {
    try
    {
      log.trace("parsing entry");
      JSONObject warSrc = (JSONObject) o;
      String warname = warSrc.keys().iterator().next();
      String warpath = warSrc.getString(warname);
      log.trace("found entry name=" + warname);
      JSONArray currentDestFilePaths = destFilePaths.getJSONArray(warname);
      File warFile = new File(warpath);
      if (!warFile.exists() || !warFile.canRead())
      {
        log.error("Cannot read source file: " + warFile);
        return true;
      }
      warfileModtimes.put(warpath, warFile.lastModified());
      File[] copyFiles = new File[currentDestFilePaths.length()];
      // copy to temp files first
      for (int i = 0; i < copyFiles.length; i++)
      {
        copyFiles[i] = new File(currentDestFilePaths.getString(i) + ".tmp");
        log.trace("Copying file " + i + " from " + warpath + " to " + copyFiles[i]);
        InputStream warFileInputStream = null;
        OutputStream destFileOutputStream = null;
        try
        {
          warFileInputStream = new FileInputStream(warFile);
          destFileOutputStream = new FileOutputStream(copyFiles[i]);
          IOUtils.copy(warFileInputStream, destFileOutputStream);
        }
        catch (IOException e)
        {
          log.error("One of the wars failed to copy", e);
        }
        finally
        {
          try
          {
            if (warFileInputStream != null)
              warFileInputStream.close();
          }
          finally
          {
            if (destFileOutputStream != null)
              destFileOutputStream.close();
          }
        }
      }
      // rename temps to final dest. Presumably they were on the same partition
      // making this quick.
      for (int i = 0; i < copyFiles.length; i++)
      {
        if (copyFiles[i].exists())
        {
          File destFile = new File(currentDestFilePaths.getString(i));
          if (copyFiles[i].renameTo(destFile))
            log.info("Successfully renamed " + copyFiles[i] + " to " + destFile);
          else
            throw new IOException("renameTo failed");
        }
        else
          log.info("Ignoring nonexistant " + copyFiles[i]);
      }
    }
    catch (IOException e)
    {
      String ostr = o instanceof JSONObject ? ((JSONObject) o).toCompactString() : o + "";
      log.error("Failed to copy file " + ostr, e);
      return true;
    }
    catch (RuntimeException e)
    {
      String ostr = o instanceof JSONObject ? ((JSONObject) o).toCompactString() : o + "";
      log.error("Failed to copy file " + ostr, e);
      return true;
    }
    return false;
  }


  @Override
  public JSONObject getConfigTemplate()
  {
    JSONObject value = new JSONObject();
    value.put(ENABLE, "true");
    value.put(JOB_BEAN, getClass().getName());
    value.put(JOB_NAME, "deploy");
    value.put(JOB_GROUP, JobManagerConstants.DEPLOYMENT_GROUP);
    value.put(JOB_CRON, "0/30 * * ? * *");
    value.put(SRC_FILE_PATHS, buildExampleSourcePaths());
    value.put(DEST_FILE_PATHS, buildExampleDestPaths());
    return value;
  }


  private JSONArray buildExampleSourcePaths()
  {
    return new JSONArray(
      new JSONObject("touchfile", TOUCHFILE_PATH),
      new JSONObject(R2_WAR, "/release/R2/dev/trunk/r2-frontend/target/r2.war"),
      new JSONObject(P40_WAR, "/release/R2/dev/trunk/p40-frontend/target/p40.war"),
      new JSONObject(REST_WAR, "/release/R2/dev/trunk/cbes-rest/target/restapp.war"),
      new JSONObject(JM_WAR, "/release/R2/dev/trunk/jobmanager/target/jobmanager.war"));
  }


  private JSONObject buildExampleDestPaths()
  {
    JSONObject value = new JSONObject();
    value.put(R2_WAR, new JSONArray("/wd/r2-deploy/r2.war", "/wd/r2-deploy2/r2.war", "/release/R2/dev/dev-deployed/r2.war"));
    value.put(P40_WAR, new JSONArray("/wd/p40-deploy/p40.war", "/wd/p40-deploy2/p40.war", "/release/R2/dev/dev-deployed/p40.war"));
    value.put(REST_WAR, new JSONArray("/wd/restapp-deploy/restapp.war", "/wd/restapp-deploy2/restapp.war", "/release/R2/dev/dev-deployed/restapp.war"));
    value.put(JM_WAR, new JSONArray("/wd/jobmanager-deploy/jobmanager.war", "/wd/jobmanager-deploy2/jobmanager.war", "/release/R2/dev/dev-deployed/jobmanager.war"));
    return value;
  }


  @Override
  public String getDescription()
  {
    return "Automatically deploys wars built by Hudson";
  }
}
