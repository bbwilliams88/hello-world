package mil.dtic.r2.jobmanager.utility;

import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

public class SysJobInstance
{
	String jobName;
	JobDetailFactoryBean jobBean;
	CronTriggerFactoryBean triggerBean;

	
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}

	public JobDetailFactoryBean getJobBean()
	{
		return jobBean;
	}
	public void setJobBean(JobDetailFactoryBean jobBean)
	{
		this.jobBean = jobBean;
	}
	public CronTriggerFactoryBean getTriggerBean()
	{
		return triggerBean;
	}
	public void setTriggerBean(CronTriggerFactoryBean triggerBean)
	{
		this.triggerBean = triggerBean;
	}
	
	
	
}
