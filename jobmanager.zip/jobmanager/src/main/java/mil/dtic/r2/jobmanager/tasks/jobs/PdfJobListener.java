package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.JobListener;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import mil.dtic.cbes.data.config.JobSourceFlag;
import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.services.SpringJobService;
import mil.dtic.r2.jobmanager.utility.DticUtils;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

public class PdfJobListener  implements JobListener{
    private static final Logger log = CbesLogFactory.getLog(PdfJobListener.class);
    public static final String JOB_LISTENER_NAME = "R2PdfJobListner";


    @Autowired
    private SpringJobService service;
    
    @Autowired
    private ConfigService config;

    @Override
    public String getName() {
        return JOB_LISTENER_NAME;
    }

    @Override
    public synchronized void jobToBeExecuted(JobExecutionContext context) {
        PdfJobData jobInfo = (PdfJobData) context.getJobDetail().
        getJobDataMap().get(QueryJobData.JOB_DATA_KEY);
        String key = jobInfo.getJobId();
        if (key != null){
            try {
                System.out.println("service: " + service);
                service.setRunningJob(key);
            } 
            catch (RuntimeException e) {
                abortDecrAndRethrow(key, e);
            }
        }
        else{
            log.error("Value for key not set, can't set status to running");
        }
    }

    @Override
    public void jobExecutionVetoed(JobExecutionContext context) {
        PdfJobData jobInfo = (PdfJobData) context.getJobDetail().getJobDataMap().get(QueryJobData.JOB_DATA_KEY);
        String key = jobInfo.getJobId();
        
        try {
            service.setStartfailJob(key);
            service.saveDecrementedRunningPdfJobCount();
        } 
        catch (RuntimeException e) {
            abortDecrAndRethrow(key, e);
        }
    }

    // coming into this method the job has now exited. If it threw an
    // exception which was caught at the highest level of the job,
    // then the JOB_ABORTED value in the map will be set to a value.
    // If that value is not null, then the job did not complete
    // properly and the status in the table will be set to ABORTED  

    
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public synchronized void jobWasExecuted(JobExecutionContext context, JobExecutionException jobException)  {
        log.debug("Executing job: " + context.getJobDetail().getKey().getName());
        Map jobInfo = context.getJobDetail().getJobDataMap();
        BudgesUser theUser = null;

        String jobAborted = (String) jobInfo.get(JobManagerConstants.JOB_ABORTED);
        PdfJobData jobPdfInfo = (PdfJobData) jobInfo.get(QueryJobData.JOB_DATA_KEY);
        String key = jobPdfInfo.getJobId();
        BudgesJob theJob = service.findJob(key);
    
        if (theJob.getCreatedByBudgesUser() != null) {
            Integer id = theJob.getCreatedByBudgesUser().getId();
            theUser = service.findUser(id);
        }
    
        if (jobException == null){
            
            if (jobAborted != null){
                try {
                    service.setAbortJob(key, null);
                    service.saveDecrementedRunningPdfJobCount();
                } 
                catch (RuntimeException e) {
                    abortDecrAndRethrow(key, e);
                }
            }
            else if (theJob.getJobStatus() == JobStatusFlag.RUNNING){
                // if the status is running, then we're done and all is good.
                // if the status is not running, then something in the job
                // set the status and we dont' want to change that.
                try {
                    service.setDoneJob(key);
                    theJob.setJobStatus(JobStatusFlag.DONE); //replicate db change to detached copy
                    service.saveDecrementedRunningPdfJobCount();
                } 
                catch (RuntimeException e) {
                    abortDecrAndRethrow(key, e);
                }
            }
            else if (theJob.getJobStatus() == JobStatusFlag.ERROR) { //ERROR status = done with business errors
                service.saveDecrementedRunningPdfJobCount();
            } 
            else {
                log.error("Unexpected job status - " + theJob.getJobStatus(), new NullPointerException("doink"));
                service.saveDecrementedRunningPdfJobCount();
            }
      
            boolean sendEmail = config.getJobManagerEmailEnabled();      
            boolean emailSent = false;

            if (sendEmail && theJob.getSource() == JobSourceFlag.UI){
                
                if (theUser != null){
                    if (BudgesContext.getEmailUtil().sendJobCompleteEmail(theJob, theUser)){
                        log.debug("Email successfully sent to user");
                    }
                    else{
                        log.debug("Email failed to be sent to user");
                    }
                }
                else {
                    log.error("unable to send email, user is null on job with id = "+key);
                }
            }  
            else if (sendEmail && isRfr(theJob)){
                emailSent = BudgesContext.getEmailUtil().sendJobCompleteEmail(theJob, null);
                log.debug("Rest service email request sent: " + emailSent);
            }
        }
        else {
            cleanUpExceptionMess(context, jobException, theJob, key);
            jobInfo.put(JobManagerConstants.JOB_ABORTED, "true");
        }
    
        Boolean cleanUpDirectory =  config.getRemoveFileArtifacts();
    
        if (cleanUpDirectory){
            removeFileArtifacts(theJob);
        }
    }
  

  private void cleanUpExceptionMess(JobExecutionContext context,
    JobExecutionException jobException, BudgesJob theJob, String key) {
    // something caused an exception that Quartz had to handle.
    // We need to remove the job from the queue, and set the status
    // to aborted, because something bad happened.
    //
      if (jobException.unscheduleAllTriggers()) {
          Scheduler sched = context.getScheduler();
          String jobName = context.getJobDetail().getKey().getName();
          String groupName = context.getJobDetail().getKey().getGroup();
          JobKey jobKey = new JobKey(jobName, groupName);
          try{
              sched.deleteJob(jobKey);
          } 
          catch (SchedulerException e){
              log.error("scheduler error trying to remove job with name "
                      +jobName+ " and group "+groupName);
          }
      }
      // quartz threw an exception so now we need to handle it.
      abortAndDecr(key, jobException);
      }

  private void removeFileArtifacts(BudgesJob theJob){
      String dirPath = DticUtils.getPathForDirectory(theJob);
      File inputFile = new File(dirPath+"/"+theJob.getInputFilename());
      File outputFile = new File( dirPath+"/"+theJob.getResultFilename());

      File path = new File(dirPath);
      List<File> files = Arrays.asList(path.listFiles());
      for (File item: files) {
          if (0 == item.compareTo(inputFile)) {
              continue;
          }
          if (0 == item.compareTo(outputFile)) {
              continue;
          }
          // This will delete directories and files.
          FileUtils.deleteQuietly(item);
      }
  }

  /** on error, mark aborted and don't hog the running job slot */
  private void abortDecrAndRethrow(String jobUuid, RuntimeException e) {
    log.error("Caught unexpected error on set status, abandoning job");
    abortAndDecr(jobUuid, e);
    throw e;
  }

  private void abortAndDecr(String jobUuid, Throwable e)
  {
    log.error("Aborting job");
    try {
      service.setAbortJob(jobUuid, e);
    } catch (RuntimeException e2) {
      log.error("Abort failed as well, whatevs", e2);
    }
    try {
      service.saveDecrementedRunningPdfJobCount();
    } catch (RuntimeException e2) {
      log.error("decrement job count failed as well, dang", e2);
    }
  }
  
  //CXE-6081
  private boolean isRfr(BudgesJob theJob){
      Integer rfr = theJob.getReadyForReview();
      if (null != rfr && rfr > 0){
          return true;   
      }
      return false;
  }
  
}

