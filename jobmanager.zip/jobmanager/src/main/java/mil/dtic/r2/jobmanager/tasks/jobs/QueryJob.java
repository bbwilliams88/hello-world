package mil.dtic.r2.jobmanager.tasks.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.TapestryFilter;
import org.apache.tapestry5.ioc.Registry;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateOptimisticLockingFailureException;

import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.r2.jobmanager.services.SpringJobService;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;

/**
 * Schedule PDF and system jobs by polling the db
 *
 */
public class QueryJob implements R2Job
{
  private static final Logger log = CbesLogFactory.getLog(QueryJob.class);
  private static final String QUERY_JOB_PDF_LIMIT = "pdfJobLimit";


  @Autowired
  ServletContext servletContext;
  @Autowired
  private ConfigService config;
  @Autowired
  private ConfigDAO configDAO;
  @Autowired
  private SpringJobService service;
  @Autowired
  private PdfJob pdfJobBean;


  private Date lastRun;


  private String lastSysjobJson;
  private List<BudgesJob> jobList = null;


  @Override
  public void execute(Map<String,Object> jobData)
  {
    lastRun = new Date();
    String queueName = config.getQueueName();
    scanHeartbeat(queueName);
    scanForSystemJobs();
    scanForPdfJobs(queueName, Integer.parseInt(jobData.get(QUERY_JOB_PDF_LIMIT).toString()));
  }

  private void scanHeartbeat(String queueName)
  {
    try {
      int maxIdleInterval = 30;
      List<String> deadHosts = configDAO.lockCheckAndUpdateJmHeartbeat(queueName, maxIdleInterval);
      if (!deadHosts.isEmpty()) {
        log.info("Found dead hosts " + deadHosts);
        if (config.getRestartRunningJobs())
          service.restartPreviouslyRunningJobs(deadHosts);
      }
    } catch (RuntimeException e) {
      log.error("scanHeartbeat", e);
    }
  }

  private void scanForPdfJobs(String queueName, int limit)
  {
    //never query more than the number of free slots
    int queryLimit = limit - configDAO.getRunningPdfJobCount();

    // get a list of jobs to work on. It's possible some other instance may
    // be pulling from the queue, so we look for jobs that we can claim as
    // our own.
    //
    jobList = getJobList(service, queueName, queryLimit);
    if (jobList != null)
    {
      int count = jobList.size();
      String postfix = (count > 1) ? " jobs" : " job";
      if (count > 0)
        log.info("found " + count + postfix);

      for (int i = 0; i < count; i++)
      {
        PdfJobData data = new PdfJobData();
        BudgesJob item = jobList.get(i);
        data.setJobName(item.getUuidStr());
        data.setJobId(item.getUuidStr());
        data.setJobGroup(JobManagerConstants.PDF_JOB_GROUP_NAME);
        log.info("Creating pdf job " + i);
        configDAO.saveIncrementedRunningPdfJobCount();
        getJobScheduler().createR2Job(pdfJobBean, data);
        // when we grabed the
        if (data.getJobStatus() == JobStatusFlag.STARTFAIL)
        {
          service.setStartfailJob(item.getUuidStr());
        }
      }
      //log.trace("finished scheduling pdf jobs");
    }
  }

  private void scanForSystemJobs()
  {
    List<String> sysjobs = configDAO.getSystemJobs();
    String json = new JSONArray(sysjobs.toArray()).toString();
    if (lastSysjobJson != json && !StringUtils.equals(lastSysjobJson, json)) {
      log.info("Rescheduling system jobs based on updated config json");
      lastSysjobJson = json;
      getJobScheduler().unscheduleSystemJobs();
      getJobScheduler().scheduleJobsFromConfig(sysjobs);
    }
  }


  private IJobScheduler getJobScheduler()
  {
    Registry registry = (Registry)servletContext.getAttribute(TapestryFilter.REGISTRY_CONTEXT_NAME);
    return registry.getService(IJobScheduler.class);
  }

  public static boolean getJobIsRunning()
  {
    return false;
  }


  public static void setJobIsRunning(boolean newValue)
  {

  }


  public Date getLastRun()
  {
    return lastRun;
  }


  // we grab a bite of N items from the queue, then we try to update them.
  // if they aren't stale then we know we got good jobs that no one else
  // is looking at, they be ours..
  private List<BudgesJob> getJobList(SpringJobService service, String queueName, int queryLimit)
    {
    String instanceName = configDAO.getInstanceName();
    List<BudgesJob> candidateList = null;
    List<BudgesJob> jobList = new ArrayList<BudgesJob>();
    while (jobList.size() < queryLimit)
    {
      candidateList = service.findNewJobsFromQueueWithLimit(queueName, queryLimit);
      if ((candidateList.size() > 0))
      {
        for (BudgesJob job : candidateList)
        {
          try
          {
            // if two instances are trying to work this job one
            // on the save will get a StaleObjectState exception.
            // that means another instance is working the job. So
            // let it go and examine more jobs. Most of the time
            // this will not happen.
            //
            service.setScheduledJob(job, instanceName);
          }
          catch (HibernateOptimisticLockingFailureException e)
          {
            log.info("Optimisitic lock, dropping job " + job);
            job = null;
          }
          if (job != null)
          {
            jobList.add(job);
          }
        }
      }
      else
      {
        // no more jobs to be found so go with what we got..
        break;
      }
    }
    return(jobList);
    }

  @Override
  public JSONObject getConfigTemplate()
  {
    JSONObject value = new JSONObject();
    value.put(ENABLE, "true");
    value.put(JOB_BEAN, getClass().getName());
    value.put(JOB_NAME, JobManagerConstants.QUERY_JOB_NAME);
    value.put(JOB_GROUP, JobManagerConstants.QUERY_GROUP_NAME);
    value.put(JOB_CRON, "0/30 * * ? * *");
    value.put(QUERY_JOB_PDF_LIMIT, "number of pdf jobs allowed to run in parallel");
    return value;
  }

  @Override
  public String getDescription()
  {
    return "Polls db for PDF and System jobs";
  }
}
