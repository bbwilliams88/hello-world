package mil.dtic.r2.jobmanager.quartz;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.ioc.annotations.InjectResource;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.JobListener;
import org.quartz.ScheduleBuilder;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.r2.jobmanager.tasks.jobs.AbstractJobData;
import mil.dtic.r2.jobmanager.tasks.jobs.AnyJob;
import mil.dtic.r2.jobmanager.tasks.jobs.PdfJobListener;
import mil.dtic.r2.jobmanager.tasks.jobs.R2Job;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;

import static org.quartz.TriggerBuilder.*;
import static org.quartz.CronScheduleBuilder.*;

import static org.quartz.TriggerBuilder.*;
import static org.quartz.CronScheduleBuilder.*;

public class JobScheduler implements IJobScheduler
{
  private static final String QUERY_JOB_NAME = "R2QueryJob";
  private static final String SYS_JOB_GROUP = "R2JobGroup";
  private static final String PDF_GROUP_NAME = "R2PdfJobGroup";
  private static final String SYS_JOB_CLASS = "jobBeanClass";
  private static final String SYS_JOB_NAME = "jobName";
  private static final String SYS_JOB_CRON_SPEC = "cronTrigger";



  private static final Logger log = CbesLogFactory.getLog(JobScheduler.class);
  //  @Inject @Autowired
  //  private QuartzManager qManager;
  @Inject
  private ApplicationContext applicationContext;
  @Inject
  private Scheduler quartzScheduler;

  @Inject @Autowired
  private PdfJobListener pdfJobListener;


  @Override
  public void scheduleJobsFromConfig(List<String> jobs)
  {
    try {
      for (String jobstr : jobs) {
        try {
          JSONObject job = new JSONObject(jobstr);
          String classname = job.getString(SYS_JOB_CLASS);
          String jobname = job.getString(SYS_JOB_NAME);
          boolean enable = job.getBoolean(R2Job.ENABLE);
          if (!enable) {
            log.info("job " + jobname + " is disabled, skipping");
            continue;
          }
          if (jobname == null || jobname.isEmpty())
            throw new IllegalArgumentException("bad jobname");
          String cronSpec = job.getString(SYS_JOB_CRON_SPEC);
          Class<?> clazz = Class.forName(classname);
          Object bean = applicationContext.getBean(clazz);
          Map<String, Object> additionalData = new HashMap<String, Object>();
          for (String key : job.keys())
            additionalData.put(key, job.get(key));
          Trigger trigger = newTrigger().withIdentity("Trigger" + jobname, SYS_JOB_GROUP).withSchedule(cronSchedule(cronSpec)).build();
          startJob((R2Job)bean, jobname, SYS_JOB_GROUP, trigger, additionalData);
        } catch (ClassNotFoundException e) {
          log.error("scheduleSystemJobs", e);
        }
      }
    } catch (RuntimeException e) {
      log.error("scheduleSystemJobs", e);
    }
  }

  @Override
  public void unscheduleAllJobs()
  {
    try {
      for (String triggerGroup : quartzScheduler.getTriggerGroupNames())
        for (TriggerKey triggerKey : quartzScheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(triggerGroup)))
          quartzScheduler.unscheduleJob(triggerKey);
    }
    catch (SchedulerException e) {
      log.error("unscheduleAllJobs", e);
    }
  }



  @Override
  public void startQueryJob()
  {
    try {
      TriggerKey triggerKey = new TriggerKey("Trigger" + QUERY_JOB_NAME, SYS_JOB_GROUP);
      quartzScheduler.resumeTrigger(triggerKey);
    } catch (SchedulerException e) {
      log.error("startQueryJob", e);
    }
  }

  @Override
  public void pauseQueryJob()
  {
    try {
      TriggerKey triggerKey = new TriggerKey("Trigger" + QUERY_JOB_NAME, SYS_JOB_GROUP);
      quartzScheduler.pauseTrigger(triggerKey);
    } catch (SchedulerException e) {
      log.error("pauseQueryJob", e);
    }
  }

  @Override
  public void scheduleSystemJobs(String jobsJson)
  {
    try {
      JSONArray jobs = new JSONArray(jobsJson);
      for (Object jobobj : jobs) {
        try {
          JSONObject job = (JSONObject)jobobj;
          String classname = job.getString(SYS_JOB_CLASS);
          String jobname = job.getString(SYS_JOB_NAME);
          if (jobname == null || jobname.isEmpty())
            throw new IllegalArgumentException("bad jobname");
          String cronSpec = job.getString(SYS_JOB_CRON_SPEC);
          Class<?> clazz = Class.forName(classname);
          Object bean = applicationContext.getBean(clazz);
          Map<String, Object> additionalData = new HashMap<String, Object>();
          for (String key : job.keys())
            additionalData.put(key, job.get(key));
          Trigger trigger = newTrigger().withIdentity("Trigger" + jobname, SYS_JOB_GROUP).withSchedule(cronSchedule(cronSpec)).build();
          startJob((R2Job)bean, jobname, SYS_JOB_GROUP, trigger, additionalData);
          } catch (ClassNotFoundException e) {
            log.error("scheduleSystemJobs", e);
          }
      }
    } catch (RuntimeException e) {
      log.error("scheduleSystemJobs", e);
    }
  }

  @Override
  public void pauseSystemJobs()
  {
    try {
      quartzScheduler.pauseJobs(GroupMatcher.jobGroupEquals(SYS_JOB_GROUP));
    } catch (SchedulerException e) {
      log.error("pauseSystemJobs", e);
    }
  }


  @Override
  public void resumeSystemJobs()
  {
    try {
      quartzScheduler.resumeJobs(GroupMatcher.jobGroupEquals(SYS_JOB_GROUP));
    } catch (SchedulerException e) {
      log.error("resumeSystemJobs", e);
    }
  }

  @Override
  public void unscheduleSystemJobs()
  {
    try {
      for (JobKey jobKey : quartzScheduler.getJobKeys(GroupMatcher.jobGroupEquals(SYS_JOB_GROUP))) {
        quartzScheduler.pauseJob(jobKey);
      }
    } catch (SchedulerException e) {
      log.error("pauseSystemJobs", e);
    }
  }


  @Override
  public void createR2Job(R2Job jobBean, AbstractJobData theData)
  {
    startJob(jobBean, theData);
  }


  @Override
  public void stopAllJobs()
  {
    log.error("lol you think this works? It doesn't.", new NullPointerException("herp"));
    //qManager.stopAllJobs();
  }


  @Override
public void stopJobWithGroupAndName(String groupName, String jobName)
  {
    log.error("neither does this one.", new NullPointerException("derp"));
    //qManager.interrupt(groupName, jobName);
  }


  @Override
  public boolean isQuartzRunning()
  {
    try {
      return quartzScheduler.isStarted() && !quartzScheduler.isInStandbyMode() && !quartzScheduler.isShutdown();
    } catch (SchedulerException e) {
      log.error("QM9 QuartzManager startJob threw a Scheduler Exception ", e);
      return false;
    }
  }


  @Override
  public List<QuartzJobInfo> getJobInfo()
  {

    List<QuartzJobInfo> jobList = new ArrayList<QuartzJobInfo>();
    try
    {
      @SuppressWarnings("unchecked")
      List<JobExecutionContext> currentlyExecutingJobs = quartzScheduler.getCurrentlyExecutingJobs();
      for (int i = 0; i < currentlyExecutingJobs.size(); i++)
      {
        JobExecutionContext ctx = currentlyExecutingJobs.get(i);
        JobDetail theJob = ctx.getJobDetail();
        QuartzJobInfo node = new QuartzJobInfo();
        Object value = theJob.getJobDataMap().get(AbstractJobData.JOB_DATA_KEY);
        if (value instanceof AbstractJobData)
        {
          AbstractJobData theData = (AbstractJobData) value;
          node.setId(theData.getJobId());
          node.setGroupName(theData.getJobGroup());
          node.setJobName(theData.getJobName());
          //jobList.add(node);
        }
        jobList.add(node);
      }
    }
    catch (SchedulerException e)
    {
      log.error("QMA QuartzManager threw a scheduling exception in getJobList", e);
    }
    return(jobList);
  }

  @Override
  public List<Trigger> getSysJobInfo()
  {

    List<Trigger> jobList = new ArrayList<Trigger>();
    try
    {
      for (JobKey jobName : quartzScheduler.getJobKeys(GroupMatcher.jobGroupEquals(SYS_JOB_GROUP))) {
        for (Trigger trigger : quartzScheduler.getTriggersOfJob(jobName))
          jobList.add(trigger);
      }
      @SuppressWarnings("unchecked")
      List<JobExecutionContext> currentlyExecutingJobs = quartzScheduler.getCurrentlyExecutingJobs();
      for (int i = 0; i < currentlyExecutingJobs.size(); i++)
      {
        JobExecutionContext ctx = currentlyExecutingJobs.get(i);
        JobDetail theJob = ctx.getJobDetail();
        QuartzJobInfo node = new QuartzJobInfo();
        Object value = theJob.getJobDataMap().get(AbstractJobData.JOB_DATA_KEY);
        if (value instanceof AbstractJobData)
        {
          AbstractJobData theData = (AbstractJobData) value;
          node.setId(theData.getJobId());
          node.setGroupName(theData.getJobGroup());
          node.setJobName(theData.getJobName());
          //jobList.add(node);
        }
        //jobList.add(node);
      }
    }
    catch (SchedulerException e)
    {
      log.error("QMA QuartzManager threw a scheduling exception in getJobList", e);
    }
    return(jobList);
  }


  @Override
public boolean isQueryRunning()
  {
    try {
      TriggerKey triggerKey = new TriggerKey("Trigger" + JobManagerConstants.QUERY_JOB_NAME, SYS_JOB_GROUP);
      Trigger t = quartzScheduler.getTrigger(triggerKey);
      return t !=null && t.getNextFireTime() != null;
    } catch (SchedulerException e) {
      log.error("", e);
      return false;
    }
  }

  @Override
public String getLastQueryRunTime()
  {
    try {
      TriggerKey triggerKey = new TriggerKey("Trigger" + JobManagerConstants.QUERY_JOB_NAME, SYS_JOB_GROUP);
      Trigger t = quartzScheduler.getTrigger(triggerKey);
      return t!=null && t.getPreviousFireTime()!=null ? t.getPreviousFireTime().toString() : "{error checking time}";
    } catch (SchedulerException e) {
      log.error("", e);
      return "{error checking time}";
    }
  }

  @Override
public String getLastQueryStatus()
  {
    return "N/A";
  }


  /**
   *
   * @param theJobClass
   * @param theData
   * @param isUUid
   */
  private void startJob(R2Job jobBean, AbstractJobData theData)
  {
    String jobName = theData.getJobName();
    String jobGroup = PDF_GROUP_NAME;
    String jobId = theData.getJobId();

    if (StringUtils.isBlank(jobId))
    {
      jobId = UUID.randomUUID().toString();
    }
    if (jobName == null)
    {
      jobName = jobId;
    }

    theData.setJobStatus(JobStatusFlag.SCHEDULED);
    JobDetail jobDetail = JobBuilder.newJob(AnyJob.class).withIdentity(jobName, jobGroup).build();
    jobDetail.getJobDataMap().put(AbstractJobData.JOB_DATA_KEY, theData);
    jobDetail.getJobDataMap().put(AnyJob.JOB_BEAN_KEY, jobBean);

    Trigger trigger = newTrigger().withIdentity("startNow" + jobName).startNow().withSchedule(SimpleScheduleBuilder.simpleSchedule().withRepeatCount(0).withIntervalInMilliseconds(0)).build();
    try
    {
      // JobListener jobListener = quartzScheduler.getListenerManager().getJobListener(theData.getJobListenerName());
      // if (jobListener == null)
      // {
      quartzScheduler.getListenerManager().addJobListener(pdfJobListener, GroupMatcher.jobGroupEquals(jobGroup));
      // }
      quartzScheduler.scheduleJob(jobDetail, trigger);
    }
    catch (SchedulerException e)
    {
      theData.setJobStatus(JobStatusFlag.STARTFAIL);
      log.error("QM2: QuartzManager startJob threw a Scheduler Exception ", e);
    }
  }

  private void startJob(R2Job jobBean, String jobName, String jobGroup, Trigger trigger, Map<String,Object> jobData)
  {
    JobDetail jobDetail = JobBuilder.newJob(AnyJob.class).withIdentity(jobName, jobGroup).build();
    jobDetail.getJobDataMap().put(AnyJob.JOB_BEAN_KEY, jobBean);
    jobDetail.getJobDataMap().putAll(jobData);
    try
    {
      quartzScheduler.deleteJob(jobDetail.getKey());
      quartzScheduler.scheduleJob(jobDetail, trigger);
    }
    catch (SchedulerException e)
    {
      log.error("QM2: QuartzManager startJob threw a Scheduler Exception ", e);
    }
  }
}
