package mil.dtic.r2.jobmanager.services;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsError;



public interface ISpringJobService
{
  BudgesJob findJob(String uuid);
  BudgesUser findUser(Integer id);
  void setAbortJob(String uuid, String error);
  void setStartfailJob(String uuid);
  void setScheduledJob(BudgesJob job, String instanceName);
  void setRunningJob(String uuid);
  void setDoneJob(String uuid);
  List<BudgesJob> findNewJobsFromQueueWithLimit(String queue, int size);
  BudgesJob runJobAndSetStatus(String uuid) throws IOException, R2XMLToolsError;
  void saveOrUpdate(BudgesJob item);
  void deleteJobsBeyondDate(Date when);
  BudgesJobDAO getJobDAO();
  void setJobDAO(BudgesJobDAO jobDAO);
  BudgesUserDAO getUserDAO();
  void setUserDAO(BudgesUserDAO userDAO);
}