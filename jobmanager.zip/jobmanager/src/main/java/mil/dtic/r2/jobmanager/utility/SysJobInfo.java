package mil.dtic.r2.jobmanager.utility;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.quartz.Trigger;
import org.apache.logging.log4j.Logger;

import mil.dtic.utility.CbesLogFactory;

public class SysJobInfo
{
  private static final Logger log = CbesLogFactory.getLog(SysJobInfo.class);

  private final String UNKNOWN = "unknown";
  private final String DATE_FORMAT = "MM dd HH:mm:ss";

  private String name;
  private Boolean active;
  private String jobDescription;

  private List<Trigger> triggers;


  public String getName()
  {
    return name;
  }


  public void setName(String name)
  {
    this.name = name;
  }


  public Boolean getActive()
  {
    return active;
  }


  public void setActive(Boolean active)
  {
    this.active = active;
  }


  public List<Trigger> getTriggers()
  {
    return triggers;
  }


  public void setTriggers(List<Trigger> triggers)
  {
    this.triggers = triggers;
  }


  public String getJobDescription()
  {
    return jobDescription;
  }


  public void setJobDescription(String jobDescription)
  {
    this.jobDescription = jobDescription;
  }


  public String getNextFire()
  {
    SimpleDateFormat fmt = new SimpleDateFormat(DATE_FORMAT);
    String fireDate = UNKNOWN;
    if ((triggers != null) && (triggers.size() > 0))
    {
      // we should do something more sophisticated then pull the first one
      // but for now that should be sufficenet as I don't ever expect
      // we'll have more than one trigger.
      //
      Date nextTime = ((Trigger) triggers.get(0)).getNextFireTime();
      String name = triggers.get(0).getKey().getName();
      log.debug("in getNexFire, Trigger name = " + name);
      fireDate = fmt.format(nextTime);
    }

    return(fireDate);
  }

}
