package mil.dtic.r2.jobmanager.utility;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.quartz.Trigger;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import mil.dtic.utility.CbesLogFactory;

public class SysJobCatalog
{

	private static final Logger log = CbesLogFactory.getLog(SysJobCatalog.class);

	public final static String NOT_SCHED = "Not Scheduled";
	public final static String JOB_GROUP_NAME = "sysJobGroup";

	private List<SysJobInstance> jobs;
	private List<SysJobInfo> jobInfo;

	public SysJobCatalog()
	{
		jobs = new ArrayList<SysJobInstance>();
		jobInfo = new ArrayList<SysJobInfo>();
	}

	public List getJobs()
	{
		return jobs;
	}

	public void setJobs(List jobs)
	{
		this.jobs = jobs;
	}

	public String getSysGroupName()
	{
		return JOB_GROUP_NAME;
	}

	public List<SysJobInfo> getJobInfo()
	{
		return jobInfo;
	}

	public void setJobInfo(List<SysJobInfo> jobInfo)
	{
		this.jobInfo = jobInfo;
	}

	public String getDateForNextFile(JobDetailFactoryBean theJob)
	{
		String retValue = NOT_SCHED;
		SysJobInfo jInfo = findInfoForBean(theJob);
		if (jInfo != null)
		{
			retValue = jInfo.getNextFire();
		}
		return (retValue);
	}

	public Trigger jobTriggerForBean(JobDetailFactoryBean theJob)
	{
		Trigger retValue = null;
		SysJobInfo activeJob = findInfoForBean(theJob);
		if ((activeJob != null) && (activeJob.getTriggers().size() > 0))
		{
			retValue = activeJob.getTriggers().get(0);
		}
		return (retValue);
	}

	public boolean isJobDetailBeanActive(JobDetailFactoryBean theJob)
	{
		boolean active = false;
		SysJobInfo activeJob = findInfoForBean(theJob);
		if ((activeJob != null) && (activeJob.getTriggers().size() > 0))
		{
			active = true;
		}
		return (active);
	}

	private SysJobInfo findInfoForBean(JobDetailFactoryBean bean)
	{
		SysJobInfo value = null;
		if (bean != null)
		{
			for (SysJobInfo jInfo : jobInfo)
			{
				if (StringUtils.equals(jInfo.getName(), bean.getObject().getKey().getName()))
				{
					value = jInfo;
					break;
				}
			}
		}
		return (value);
	}

	public SysJobInfo getJobInfoForJobName(String jobName)
	{
		SysJobInfo retValue = null;
		for (SysJobInfo item : jobInfo)
		{
			if (StringUtils.equals(item.getName(), jobName))
			{
				retValue = item;
				break;
			}
		}
		return retValue;
	}

	public List<Trigger> getTriggerForJobWithName(String jobName)
	{
		SysJobInfo theInfo = getJobInfoForJobName(jobName);
		List<Trigger> retValue = theInfo.getTriggers();
		return retValue;
	}

	public SysJobInstance getDetailBeanWithName(String jobName)
	{
		SysJobInstance protoJob = null;
		for (SysJobInstance jobEntry : jobs)
		{
			String name = jobEntry.getJobName();
			if ((name != null) && (StringUtils.equals(name, jobName)))
			{
				protoJob = jobEntry;
				break;
			}
		}

		return protoJob;
	}

	public List<JobDetailFactoryBean> getBeanList()
	{
		List<JobDetailFactoryBean> retValue = new ArrayList<JobDetailFactoryBean>();
		for (SysJobInstance item : jobs)
		{
			retValue.add(item.getJobBean());
		}
		return (retValue);
	}

}
