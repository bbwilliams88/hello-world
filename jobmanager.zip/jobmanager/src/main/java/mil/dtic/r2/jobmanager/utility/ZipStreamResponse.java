package mil.dtic.r2.jobmanager.utility;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.services.Response;

public class ZipStreamResponse implements StreamResponse
{
	private final static String fileExt = ".zip";
	private InputStream is;
	private String filename = "default";

	public ZipStreamResponse(InputStream is, String... args)
	{
		this.is = is;
		if (args != null)
		{
			this.filename = args[0];
		}
	}

	public String getContentType()
	{
		return "application/" + ZipStreamResponse.fileExt;
	}

	public InputStream getStream() throws IOException
	{
		return is;
	}

	public void prepareResponse(Response arg0)
	{
		String fileWithExt = filename;
		if (!StringUtils.endsWith(fileWithExt, fileExt))
		{
			fileWithExt = fileWithExt + ZipStreamResponse.fileExt;
		}
		arg0.setHeader("Content-Disposition", "attachment; filename="
				+ fileWithExt);
		arg0.setHeader("Expires", "0");
		arg0.setHeader("Cache-Control",
				"must-revalidate, post-check=0, pre-check=0");
		arg0.setHeader("Pragma", "public");
	}
}