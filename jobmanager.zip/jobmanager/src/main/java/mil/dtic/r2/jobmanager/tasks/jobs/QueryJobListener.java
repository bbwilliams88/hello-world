package mil.dtic.r2.jobmanager.tasks.jobs;

import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

import mil.dtic.cbes.data.config.JobStatusFlag;

public class QueryJobListener implements JobListener
{
	
	public static QueryJobData queryJobData;

	public static final String JOB_LISTENER_NAME = "R2QueryJobListner";

	public QueryJobListener()
	{
		
	}

	public String getName()
	{
		return JOB_LISTENER_NAME;
	}

	public synchronized void jobToBeExecuted(JobExecutionContext context)
	{
		QueryJobData jobInfo = getJobData(context.getJobDetail()
				.getJobDataMap().get(QueryJobData.JOB_DATA_KEY));
		if (jobInfo != null)
		{
			jobInfo.setJobStart(new Date());
			jobInfo.setJobStatus(JobStatusFlag.RUNNING);
		}
		QueryJob.setJobIsRunning(true);
	}

	public void jobExecutionVetoed(JobExecutionContext context)
	{
		QueryJobData jobInfo = getJobData(context.getJobDetail()
				.getJobDataMap().get(QueryJobData.JOB_DATA_KEY));
		if (jobInfo != null)
		{
			jobInfo.setJobEnd(new Date());
			jobInfo.setJobStatus(JobStatusFlag.STARTFAIL);
		}

	}

	public synchronized void jobWasExecuted(JobExecutionContext context,
			JobExecutionException jobException)
	{
		QueryJobData jobInfo = getJobData(context.getJobDetail()
				.getJobDataMap().get(QueryJobData.JOB_DATA_KEY));
		if (jobInfo != null)
		{
			jobInfo.setJobEnd(new Date());
			jobInfo.setJobStatus(JobStatusFlag.DONE);
		}
		QueryJob.setJobIsRunning(false);
	}

	private QueryJobData getJobData(Object obj)
	{
		QueryJobData jobInfo = null;
		if (obj instanceof QueryJobData)
		{
			jobInfo = (QueryJobData) obj;
		}
		return (jobInfo);
	}

}
