package mil.dtic.r2.jobmanager.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;
import org.apache.tapestry5.services.Request;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.utility.PDFStreamResponse;
import mil.dtic.r2.jobmanager.utility.XmlStreamResponse;
import mil.dtic.r2.jobmanager.utility.ZipStreamResponse;
import mil.dtic.utility.CbesLogFactory;

@SuppressWarnings({"unchecked", "rawtypes"})
public class Document
{
  private final static int PDF_FILE_ID = 1;
  private final static int ZIP_FILE_ID = 2;
  private final static int XML_FILE_ID = 3;
  private final static String PDF_FILE_EXT = "pdf";
  private final static String ZIP_FILE_EXT = "zip";
  private final static String XML_FILE_EXT = "xml";

  private static final Logger log = CbesLogFactory.getLog(Document.class);
  
  @Inject
  private Request request;
  @Inject
  private ComponentResources _componentResources;
  @Inject
  private BeanModelSource _beanModelSource;


  @Inject
  private ConfigService config;
  @Inject
  private BudgesJobDAO jobDAO;
  @Inject
  private BudgesUserDAO userDAO;


  @Persist
  private boolean _showAll;
  @Persist
  private BudgesUser theUser;
  @Property
  private BeanModel jobModel;

  @Property
  private List jobList;

  @Property(read = true)
  private BudgesJob r2JobEntry;

  @Property
  private BudgesJob theJob;
  @Property
  private String theUUID;


  void setupRender()
  {
    if (jobModel == null)
    {
      jobModel = _beanModelSource.createDisplayModel(BudgesJob.class, _componentResources.getMessages());
      jobModel.include("uuidStr", "jobType", "jobStatus", "dateJobStarted", "dateJobEnded");
      jobModel.get("uuidStr").label("Id");
      jobModel.get("jobType").label("Type");
      jobModel.get("jobStatus").label("Status");
      jobModel.get("dateJobStarted").label("Start");
      jobModel.get("dateJobEnded").label("End");
      jobModel.add("action", null);
      jobModel.get("action").label("Action");
    }
    if (StringUtils.isNotBlank(clippedUUID()))
    {
      jobList = new ArrayList();
      theJob = jobDAO.findByUUID(clippedUUID());
      jobList.add(theJob);

    }
    else
    {
      if (theUser == null)
      {
        acquireUser();
      }
      jobList = jobDAO.findAllJobsByUser(theUser);

    }
  }


  public int getJobListSize()
  {
    return((jobList != null) ? jobList.size() : 0);
  }


  public boolean isShowList()
  {
    boolean retvalue = (theUUID != null);
    retvalue = retvalue || _showAll;
    return(retvalue);
  }


  public boolean isShowAllBot()
  {
    return _showAll;
  }


  public void setShowAllBot(boolean newAll)
  {
    _showAll = newAll;
  }


  public boolean isShowAllTop()
  {
    return _showAll;
  }


  public void setShowAllTop(boolean newAll)
  {
    _showAll = newAll;
  }


  public String clippedUUID()
  {
    String retValue = null;
    if (theUUID != null)
    {
      int pos = theUUID.indexOf("_");
      retValue = theUUID.substring(pos + 1);
    }
    return(retValue);
  }


  void onActivate(String uuid)
  {

    if (StringUtils.isNotEmpty(uuid))
    {
      theUUID = StringUtils.trim(uuid);
      theJob = jobDAO.findByUUID(clippedUUID());
    }
  }


  String onPassivate()
  {

    return(theUUID);
  }


  public String getTheId()
  {
    return(theUUID);
  }


  public String getTheDate()
  {
    String retValue = "";
    if (theJob != null)
    {
      retValue = theJob.getDateJobStarted().toString();
    }
    return(retValue);
  }


  public StreamResponse onActionFromDownloadResult(String theId)
	{
		StreamResponse retValue = null;
		InputStream is = null;
		BudgesJob selectedJob = jobDAO.findByUUID(theId);
		String filePath = getPathForFile(selectedJob);
		try
		{
		  if (StringUtils.isNotBlank(filePath))
		  {
		    try
		    {
				is = new FileInputStream(filePath);
			} catch (FileNotFoundException e)
			{
				log.info("didn't find a file to download");
			}
			
			String filename = selectedJob.getResultFilename();
			if (StringUtils.isNotBlank(filename))
			{
				int length = filename.length();
				String ext = filename.substring(length - 3, length);
				int extId = this.getExtIdForExtension(ext);
				switch (extId)
				{
				case PDF_FILE_ID:
					retValue = new PDFStreamResponse(is, filename);
					break;
				case ZIP_FILE_ID:
					retValue = new ZipStreamResponse(is, filename);
					break;
				case XML_FILE_ID:
					retValue = new XmlStreamResponse(is, filename);
					break;
				}
			}
		}
		}finally{
		  if(is != null) try
      {
        is.close();
      }
      catch (IOException e)
      {
        log.warn("Failed while attempting to close Input Stream: " + e.getMessage(),e);
      }
		}
		return (retValue);
	}  private String getPathForFile(BudgesJob theJob)
  {
    String fullPath = null;
    String workingFolder = config.getWorkingFolder();
    if (theJob != null)
    {
      fullPath = workingFolder + "/" + theJob.getWorkingDirectory() + "/" + theJob.getResultFilename();
    }
    return(fullPath);
  }


  private int getExtIdForExtension(String ext)
  {
    int retValue = 0;
    if (StringUtils.equals(ext, PDF_FILE_EXT))
    {
      retValue = Document.PDF_FILE_ID;
    }
    else if (StringUtils.equals(ext, Document.XML_FILE_EXT))
    {
      retValue = Document.XML_FILE_ID;
    }
    if (StringUtils.equals(ext, Document.ZIP_FILE_EXT))
    {
      retValue = Document.ZIP_FILE_ID;
    }
    return retValue;
  }


  public Object onSuccess()
  {
    if (theJob != null)
    {
      String filename = theJob.getResultFilename();
      if (StringUtils.isNotBlank(filename))
      {

      }
    }
    return(null);
  }


  private void acquireUser()
  {
    log.info("Attempting to acquire user ...");

    // Look for a JVM-defined LDAP ID property (for development only).
    String ldapId = System.getProperty("ldapId");

    // If the JVM-defined LDAP ID property is null, look in SiteMinder.
    if (ldapId == null)
    {
      ldapId = request.getHeader("remote_user");

      log.info("remote_user = " + ldapId);
    }
    if (ldapId == null)
    {
      ldapId = "userc1239";
    }

    log.info("LDAP ID = " + ldapId);

    // Set the user if possible.
    if (ldapId != null)
    {
      theUser = userDAO.findByUserLdapId(ldapId);

    }
  }


  public boolean isValidDownload()
  {
    boolean retValue = (r2JobEntry != null) ? StringUtils.isNotBlank(r2JobEntry.getResultFilename()) : false;
    return(retValue);
  }

}
