package mil.dtic.r2.jobmanager.tasks.jobs;

import java.util.Map;

import org.apache.tapestry5.json.JSONObject;

public interface R2Job
{
  static final String ENABLE = "enable";
  static final String JOB_BEAN = "jobBeanClass";
  static final String JOB_NAME = "jobName";
  static final String JOB_GROUP = "jobGroup";
  static final String JOB_CRON = "cronTrigger";
  void execute(Map<String,Object> quartzJobData);
  /** Create example json config value with all the available options documented */
  JSONObject getConfigTemplate();
  String getDescription();
}