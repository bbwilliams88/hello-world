package mil.dtic.r2.jobmanager.tasks.jobs;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.tapestry5.json.JSONObject;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import mil.dtic.r2.jobmanager.services.SpringJobService;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;

/**
 * Used to clean out old entries from the database.
 * 
 * @author agiaccon
 * 
 */
public class DatabaseCleanJob implements R2Job
{
  private static final Logger log = CbesLogFactory.getLog(DatabaseCleanJob.class);
  private static final String AGE = "age";


  @Autowired
  private SpringJobService service;


  @Override
  public void execute(Map<String,Object> jobData)
  {
    String enablestr = (String) jobData.get(ENABLE);
    String ageInDays = (String) jobData.get(AGE);

    if(Boolean.TRUE.toString().equals(enablestr))
    {
      log.info("Starting to prune database tables, age=" + ageInDays);

      int age = Integer.valueOf(ageInDays);
      Calendar cal = Calendar.getInstance();
      // take now and subtract days from it.
      cal.add(Calendar.DAY_OF_MONTH, -1 * age);
      Date when = cal.getTime();
      int count = service.deleteJobsBeyondDate(when);
      log.info("Done pruning database tables - count=" + count);
      
      cal = Calendar.getInstance();
      cal.set(Calendar.HOUR, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND,0);
      cal.set(Calendar.MILLISECOND, 0);
      cal.set(Calendar.DATE, -180);

    } else {
      log.info("This job has been disabled in the database config table");
    }
  }

  @Override
  public JSONObject getConfigTemplate()
  {
    JSONObject value = new JSONObject();
    value.put(ENABLE, "true");
    value.put(JOB_BEAN, getClass().getName());
    value.put(JOB_NAME, "dbclean");
    value.put(JOB_GROUP, JobManagerConstants.DEFAULT_GROUP);
    value.put(JOB_CRON, "0 0 0 1 12 ? 2099");
    value.put(AGE, "minimum age of db records to delete, as integer days");
    return value;
  }

  @Override
  public String getDescription()
  {
    return "Deletes old rows from the pdf job table periodically";
  }
}
