package mil.dtic.r2.jobmanager.utility;

import java.util.Arrays;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.utility.BudgesContext;

public class DticUtils
{

	public static <T extends Exception> String elementsToString(T e)
	{
		StringBuffer sb = new StringBuffer();
		for(StackTraceElement elm : Arrays.asList(e.getStackTrace()))
		{
			sb.append(elm.toString());
		}
		return sb.toString();

	}


	public static String getPathForDirectory(BudgesJob theJob)
	{
		String directoryPath  = null;
		String workingFolder = BudgesContext.getConfigService().getWorkingFolder();
		if (theJob != null)
		{
			directoryPath= workingFolder+"/"+theJob.getWorkingDirectory();
		}
		return(directoryPath);
	}


	public static String getPathForFile(BudgesJob theJob)
	{
		String fullPath  = null;
		String workingFolder = BudgesContext.getConfigService().getWorkingFolder();
		if (theJob != null)
		{
			fullPath= workingFolder+"/"+theJob.getWorkingDirectory()+"/"+theJob.getResultFilename();
		}
		return(fullPath);
	}

}
