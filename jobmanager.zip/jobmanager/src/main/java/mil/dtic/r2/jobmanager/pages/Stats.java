package mil.dtic.r2.jobmanager.pages;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.EventContext;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.annotations.Retain;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;
import org.apache.tapestry5.services.Request;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.r2.jobmanager.tapestryutil.StringSelectModel;
import mil.dtic.utility.CbesLogFactory;


@SuppressWarnings({ "unused", "unchecked", "rawtypes" })

public class Stats
{
  private static final Logger log = CbesLogFactory.getLog(Stats.class);
  
	@Persist
	@Property
	private Date start;
	
	@Persist
	@Property
	private Date finish;
	
    @Inject
    private Request request;
	
	@Inject 
	private BudgesJobDAO jobDAO;
	
	@Inject 
	private BudgesUserDAO userDAO;

	@Persist 
	private BudgesUser theUser;

	@Property
	@Retain
	private BeanModel jobModel;	

	@Inject
	private ComponentResources _componentResources;
	@Inject
	private BeanModelSource _beanModelSource;
	
	@Property
	private List jobList;

	@Property(read=true)
	private BudgesJob r2JobEntry;
	
	@Property
	private String selectedQueue;

	@Property 
	private List queueList;
	
	@Persist
	@Property 
	private String queueName;
	
	@Property
	private StringSelectModel queues;

	
	void setupRender()
	{
		if (queueList == null)
		{
			if (StringUtils.isBlank(selectedQueue))
			{
				selectedQueue = "default";
			}
			queueList = jobDAO.findDistinctQueueNames();
		}
		queues = new StringSelectModel(queueList);
		if (jobModel == null)
		{
			jobModel = _beanModelSource.createDisplayModel(BudgesJob.class,
					_componentResources.getMessages());
			jobModel.include("uuidStr", "jobType", "queueName", "jobStatus",
					"dateJobStarted", "dateJobEnded");
			jobModel.get("uuidStr").label("Id");
			jobModel.get("jobType").label("Type");
			jobModel.get("jobStatus").label("Status");
			jobModel.get("dateJobStarted").label("Start");
			jobModel.get("queueName").label("Q Name");
			jobModel.get("dateJobEnded").label("End");
		}
		if (theUser == null)
		{
			acquireUser();
		}
	
		Calendar cal = Calendar.getInstance();
		Date now = new Date();
		cal.setTime(now);
		cal.add(Calendar.DATE, -5);
		Date then = cal.getTime();
		jobList = jobDAO.findJobsCreatedBetween(selectedQueue,now, then);

	}
	
	
	String onPassivate() {
		return selectedQueue;
	}

	void onActivate(EventContext context) {
		if (context.getCount() > 0) {
			selectedQueue = context.get(String.class, 0);
		}
	}

	
    private void acquireUser()
    {
        log.info("Attempting to acquire user ...");

        // Look for a JVM-defined LDAP ID property (for development only).
         String ldapId = System.getProperty("ldapId");

        // If the JVM-defined LDAP ID property is null, look in SiteMinder.
        if (ldapId == null)
        {
            ldapId = request.getHeader("remote_user");

            log.info("remote_user = " + ldapId);
        }
        if (ldapId == null)
        {
        	ldapId = "userc1239";
        }

        log.info("LDAP ID = " + ldapId);

        // Set the user if possible.
        if (ldapId != null)
        {
        	theUser = userDAO.findByUserLdapId(ldapId);

        }
    }
    
	public Object onSuccess()
    {
		log.info("Selected Objejct is "+ selectedQueue);
    	return (null);
    }
	

    public Object onValueChanged(String choice)
    {
    	selectedQueue = choice;
    	return(null);
    }
    
    public Date getJobStartDate()
    {
    	return (new Date());
    }

    public Date getJobEndDate()
    {
    	return (new Date());
    }


}
