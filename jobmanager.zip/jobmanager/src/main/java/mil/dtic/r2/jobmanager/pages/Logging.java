package mil.dtic.r2.jobmanager.pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.CbesLogManager;

/**
 * Log4j log level editor
 */
public class Logging
{
//  private static final Logger log = CbesLogFactory.getLog(Logging.class);


  @Property
  private CbesLogManager cbesLogManager;


  @Property
  private String loggerName;
  @Property
  private String logLevel;
  
  @Property 
  private org.apache.logging.log4j.Logger currentLogger;

  public void onActivate()
  {
    if (this.cbesLogManager == null) this.cbesLogManager = CbesLogFactory.getCbesLogManagerInstance();
  }

  @Log
  void onSuccess()
  {
    if (StringUtils.isNotEmpty(loggerName))
    {
      loggerName = loggerName.trim();
      Level level = Level.toLevel(logLevel);
      this.cbesLogManager.setLogLevel(loggerName, level);
    }
  }
}
