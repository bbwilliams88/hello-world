package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.Serializable;
import java.util.Date;

import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.data.config.JobTypeFlag;


/**
 * This class holds data for the jobs we implement. There's a standard group of
 * data elements that are encapsulated in this class.
 * 
 * @author agiaccon
 * 
 */
public abstract class AbstractJobData implements Serializable
{

  /**
   * Serial Id for AbstractJobData
   */
  private static final long serialVersionUID = 7844174938400571687L;

  public static final String JOB_DATA_KEY = "JobData";

  protected String jobId;
  protected String jobName;
  protected String jobGroup;
  protected JobStatusFlag jobStatus;
  protected Date jobStart;
  protected Date jobEnd;
  protected JobTypeFlag jobType;

  public AbstractJobData()
  {
    super();
  }


  public String getJobId()
  {
    return(jobId);
  }


  public void setJobId(String jobId)
  {
    this.jobId = jobId;
  }


  public JobStatusFlag getJobStatus()
  {
    return jobStatus;
  }


  public void setJobStatus(JobStatusFlag jobStatus)
  {
    this.jobStatus = jobStatus;
  }


  public Date getJobStart()
  {
    return jobStart;
  }


  public void setJobStart(Date jobStart)
  {
    this.jobStart = jobStart;
  }


  public Date getJobEnd()
  {
    return jobEnd;
  }


  public void setJobEnd(Date jobEnd)
  {
    this.jobEnd = jobEnd;
  }


  public String getJobName()
  {
    return jobName;
  }


  public void setJobName(String jName)
  {
    jobName = jName;
  }


  public String getJobGroup()
  {
    return jobGroup;
  }


  public void setJobGroup(String jobGroup)
  {
    this.jobGroup = jobGroup;
  }


  public JobTypeFlag getJobType()
  {
    return jobType;
  }


  public void setJobType(JobTypeFlag jobType)
  {
    this.jobType = jobType;
  }


  abstract public String getJobListenerName();

}