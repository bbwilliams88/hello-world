package mil.dtic.r2.jobmanager.quartz;

import java.util.List;

import org.quartz.Trigger;

import mil.dtic.r2.jobmanager.tasks.jobs.AbstractJobData;
import mil.dtic.r2.jobmanager.tasks.jobs.R2Job;


public interface IJobScheduler
{
  void startQueryJob();
  void pauseQueryJob();
  void createR2Job(R2Job jobBean, AbstractJobData theData);
  void stopAllJobs();
  List<QuartzJobInfo> getJobInfo();
  void stopJobWithGroupAndName(String groupName, String jobName);
  boolean isQueryRunning();
  String getLastQueryRunTime();
  String getLastQueryStatus();
  void scheduleSystemJobs(String jobs);
  void pauseSystemJobs();
  void unscheduleSystemJobs();
  List<Trigger> getSysJobInfo();
  void unscheduleAllJobs();
  void scheduleJobsFromConfig(List<String> jobs);
  void resumeSystemJobs();
  boolean isQuartzRunning();
}
