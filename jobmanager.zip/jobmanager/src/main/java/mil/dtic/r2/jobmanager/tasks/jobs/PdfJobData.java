package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.Serializable;


/*
 *   private UUID uuid;
 *   private JobTypeFlag jobType;
 *   private JobStatusFlag jobStatus;
 *   private String workingDirectory;
 *   private String inputFilename;
 *   private String resultFilename;
 *   private String originalInputFilename;
 *   private ServiceAgency agency;
 * 
 */
public class PdfJobData extends AbstractJobData implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8146015243122973081L;
	

	
	@Override
	public String getJobListenerName() {
			return PdfJobListener.JOB_LISTENER_NAME;
	}
	
}
