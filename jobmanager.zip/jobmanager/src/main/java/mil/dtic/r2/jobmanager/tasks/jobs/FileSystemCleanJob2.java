package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.AgeFileFilter;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.NameFileFilter;
import org.apache.commons.io.filefilter.NotFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.springframework.stereotype.Component;

import com.google.common.base.Functions;
import com.google.common.collect.Lists;

import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;

/**
 * gets locations, day file expire, and file extensions from the db
 * for each location, removes all files past expire limit with any of the given extensions
 */
@Component("FileSystemCleanJob2")
public class FileSystemCleanJob2 implements R2Job
{
  private static final Logger log = CbesLogFactory.getLog(FileSystemCleanJob2.class);
  private static final String LOCATIONS_FIELD = "locations";
  private static final String PATH = "path";
  private static final String AGE = "age";
  private static final String EXTS = "extensions";
  private static final String WHTLIST = "whitelist";


  @Override
  public void execute(Map<String,Object> jobData)
  {
    log.info("Starting File Cleanup Job");

    String rawLocations = jobData.get(LOCATIONS_FIELD) + "";

    boolean failed = false;
    try {
      JSONArray locations = new JSONArray(rawLocations);
      for (Object o : locations) {
        failed |= doOneLocation((JSONObject)o);
      }
    } catch (RuntimeException e) {
      log.error("Failed to parse fsclean job - " + new HashMap<String, Object>(jobData), e);
      throw e;
    }
    if (failed)
      log.error("Earlier failures were detected");

    log.info("Finished File Cleanup Job");
  }

  //return false on failure
  private boolean doOneLocation(JSONObject json)
  {
    String path;
    FileFilter filter;
    try {
      log.trace("parsing entry");
      path = json.getString(PATH);
      int age = json.getInt(AGE);
      long ageInMilliSeconds = TimeUnit.DAYS.toMillis(age);
      Date cutoff = new Date(new Date().getTime() - ageInMilliSeconds);
      List<String> extensions =
        Lists.transform(Lists.newArrayList(json.getJSONArray(EXTS).iterator()), Functions.toStringFunction());
      List<String> whitelist =
        Lists.transform(Lists.newArrayList(json.getJSONArray(WHTLIST).iterator()), Functions.toStringFunction());
      filter = new AndFileFilter(Arrays.<IOFileFilter>asList(
        new AgeFileFilter(cutoff, true),
        new SuffixFileFilter(extensions),
        new NotFileFilter(new NameFileFilter(whitelist))
        ));
    } catch (RuntimeException e) {
      log.error("Failed to parse path in fsclean job - " + json, e);
      return true;
    }
    try {
      File file = new File(path);
      if (!file.exists()) {
        log.trace("File does not exist");
        return false;
      }
      if (file.isFile()) {
        log.error(path + " is not a directory");
        return true;
      }
      File[] contents = file.listFiles(filter);
      if (contents == null) {
        log.error("I/O error listing files in dir " + file);
        return true;
      }
      if (contents.length > 0)
        log.info("Deleting following files - " + Arrays.asList(contents));
      
      // Avoid race conditions by randomizing the deletion order,
      // in the shared disk, multiple server scenario. 
      List<File> randomized = Arrays.asList(contents);
      Collections.shuffle(randomized);
      
      for (File f : randomized) {
        try {
          if (f.isDirectory())
            FileUtils.deleteDirectory(f);
          else if (f.exists() && f.canWrite() && f.isFile())
            f.delete();
          else 
            log.trace("unable to delete " + f);
        } catch (IOException e) {
          log.error("delete failed for " + f, e);
        }
      }
      return false;
    } catch (RuntimeException e) {
      log.error("Failed to scan/delete" + path, e);
      return true;
    }
  }

  @Override
  public JSONObject getConfigTemplate()
  {
    JSONObject value = new JSONObject();
    value.put(ENABLE, "true");
    value.put(JOB_BEAN, getClass().getName());
    value.put(JOB_NAME, "fsclean");
    value.put(JOB_GROUP, JobManagerConstants.DEFAULT_GROUP);
    value.put(JOB_CRON, "0 0 0 1 12 ? 2099");
    JSONObject examplelocation = new JSONObject(PATH, "/tmp", AGE, "9000");
    examplelocation.put(EXTS, new JSONArray(".xpz", ".xpm"));
    examplelocation.put(WHTLIST, new JSONArray((Object)"logos"));
    value.put(LOCATIONS_FIELD, new JSONArray(examplelocation).toCompactString());
    value.put("doc-" + LOCATIONS_FIELD, "json array of path/age/extension objects, with the paths to directories to scan for deletion, minimum file age in days, and extension list");
    return value;
  }

  @Override
  public String getDescription()
  {
    return "Cleans out certain file system directories periodically";
  }
}
