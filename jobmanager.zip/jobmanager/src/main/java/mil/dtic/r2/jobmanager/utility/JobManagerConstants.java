package mil.dtic.r2.jobmanager.utility;

public class JobManagerConstants
{
  public static final String JOB_DATA_KEY = "JobData";
  public static final String DAO_BEAN_NAME = "BudgesJobDAOTarget";
  public static final String JOB_KEY = "JOB_ID_VALUE";
  public static final String XML_RESP_FILENAME = "xmlresponse.xml";
  public static final String REST_TMP_FILE_PFX = "rst";
  public static final String JOB_RUN_STATUS = "JobRunStatus";
  public static final String JOB_ABORTED = "JOB_RUN_ABORTED";
  public static final String DEFAULT_GROUP = "defaultGroup";
  public static final String PDF_JOB_GROUP_NAME = "PDFGroup";
  public static final String QUERY_JOB_NAME = "R2QueryJob";
  public static final String QUERY_GROUP_NAME = "R2QueryGroup";
  public static final String QUERY_TRIGGER_NAME = "R2QueryTrigger";
  public static final String SPRING_JOB_SERVICE = "SpringJobService";
  public static final String START_UP_MANAGER = "startUpManager";
  public static final String JOB_SCHEDULER = "jobScheduler";
  public static final String JSON_CONFIG_VALUE_KEY = "value";
  public static final String CONFIG_NAME_JOB_PREFIX = "jm.job.";
  public static final String DEPLOYMENT_GROUP = "DeployGroup";
}
