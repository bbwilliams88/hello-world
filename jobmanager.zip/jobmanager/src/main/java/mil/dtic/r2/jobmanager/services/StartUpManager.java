package mil.dtic.r2.jobmanager.services;

import java.util.List;

import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONObject;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;

import mil.dtic.cbes.data.config.ConfigTypeFlag;
import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.r2.jobmanager.tasks.jobs.R2Job;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;


/**
 * @author agiaccon
 * this class manages the start up of the jobmanager. The methods get called
 * as part of the start up of tapestry.
 */
public class StartUpManager implements IStartUpManager
{
  private static final String TEMPLATE_HOST = "TEMPLATE.mooch2Sh";

  private static final Logger log = CbesLogFactory.getLog(StartUpManager.class);
  @Inject
  private IJobScheduler jobScheduler;
  @Inject
  private ApplicationContext applicationContext;
  @Inject
  private SpringJobService service;
  @Inject
  private ConfigService config;
  @Inject
  private ConfigDAO configDAO;
  @Inject
  private BudgesUserDAO userDAO;


  @Override
  public void start()
  {
    log.trace("start");
    configDAO.saveNewJobTypeColumn(); //TODO remove since its only needed once
    String queueName = config.getQueueName();
    List<String> sysjobs = configDAO.getSystemJobs();

    updateConfigTemplates();
    checkUpdateHeartbeatAndJobs(queueName);
    configDAO.saveZeroPdfJobCount();
    jobScheduler.scheduleJobsFromConfig(sysjobs);
  }


  @Override
  public void stop()
  {
    log.trace("stop");
    jobScheduler.unscheduleAllJobs();
  }

  /**
   * <p>each bean has a dummy config row, with the same name as the bean's class with "jm.job." prepended
   * <p>it's purpose is for somebody to copy it as a template in the config UI
   * and then edit that copy to make it live
   */
  private void updateConfigTemplates()
  {
    for (R2Job bean : applicationContext.getBeansOfType(R2Job.class).values()) {
      JSONObject json = bean.getConfigTemplate();
      if (json == null)
        continue; //undocumented, so no template
      String configName = JobManagerConstants.CONFIG_NAME_JOB_PREFIX + bean.getClass().getSimpleName();
      Config c = configDAO.findByName(configName, TEMPLATE_HOST);
      if (c == null) {
        c = new Config();
        c.setName(configName);
        c.setHostName(TEMPLATE_HOST);
        c.setValueType(ConfigTypeFlag.JSONJOB);
        c.setCreatedByBudgesUser(userDAO.findAll().get(0));
        c.setModifiedByBudgesUser(c.getCreatedByBudgesUser());
        c.setBudgetCycle("xxxxx");
        c.setBudgetYear(0);
      }
      c.setDescription(bean.getDescription());
      c.setValue(json.toString());
      configDAO.saveByConfig(c);
    }
  }
  
  /**
   * Check the heartbeat, possibly restart jobs
   */
  private void checkUpdateHeartbeatAndJobs(String queueName)
  {
    try {
      configDAO.saveCreateJmHeartbeat();
      int maxIdleInterval = 30;
      List<String> thegratefuldead = configDAO.lockCheckAndUpdateJmHeartbeat(queueName, maxIdleInterval);
      thegratefuldead.add(configDAO.getInstanceName()); //restart own jobs too
      if (config.getRestartRunningJobs())
        service.restartPreviouslyRunningJobs(thegratefuldead);
    } catch (RuntimeException e) {
      log.error("checkAndUpdateHeartbeat", e);
    }
  }
}
