package mil.dtic.r2.jobmanager.utility;

import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.Field;
import org.apache.tapestry5.MarkupWriter;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.internal.translator.AbstractTranslator;
import org.apache.tapestry5.services.FormSupport;

public class UUIDTranslator extends AbstractTranslator<UUID>
{

	public UUIDTranslator()
	{
		super("uuid", UUID.class, "uuid-format-exception");
	}

	public String toClient(UUID value)
	{
		
		return ((value != null) ? value.toString(): "");
	}

	public UUID parseClient(Field field, String clientValue, String message)
			throws ValidationException
	{
		UUID retValue = null;
		if (StringUtils.isNotBlank(clientValue))
		{
			retValue = UUID.fromString(clientValue);
		}
		return retValue;
	}

	public void render(Field field, String message, MarkupWriter writer,
			FormSupport formSupport)
	{
		// don't do anything, we don't support
		
	}


}
