package mil.dtic.r2.jobmanager.components;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;

import mil.dtic.cbes.constants.AppDefaults;
import mil.dtic.utility.Util;

/**
 * Layout component for pages of application jobmanager.
 */
@SuppressWarnings("unused")
@Import(stylesheet="context:layout/layout.css")
public class Layout
{
    /** The page title, for the <title> element and the <h1> element. */
	@Property
    @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
    private String title;

    @Property
    private String pageName;


    @Inject
    private ComponentResources resources;


    @Inject
    @Property
    private AppDefaults appDefaults;

    public String getClassForPageName()
    {
      return resources.getPageName().equalsIgnoreCase(pageName)
             ? "current_page_item"
             : null;
    }

    public String[] getPageNames()
    {
      return new String[] { "Index", "Document", "QuartzJobs", "Stats", "SysJobs"};
    }

    public String getHost() throws UnknownHostException
    {
      return InetAddress.getLocalHost().toString();
    }

    public boolean isClassified()
    {
      return Util.isClassified();
    }

}
