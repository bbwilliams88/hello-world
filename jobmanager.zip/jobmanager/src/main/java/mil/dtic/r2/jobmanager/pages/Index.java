package mil.dtic.r2.jobmanager.pages;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;
import org.apache.tapestry5.services.javascript.JavaScriptSupport;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Lists;

import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.cbes.submissions.validation.backend.ValidationService;
import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.r2.jobmanager.tapestryutil.StringSelectModel;
import mil.dtic.r2.jobmanager.tasks.jobs.DeploymentJob;
import mil.dtic.r2.jobmanager.utility.BudgesJobDataSource;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

/**
 * Start page of application jobmanager.
 */
@SuppressWarnings("unused")
@Import(
  stylesheet="context:css/Index.css",
  stack={
    CbesT5SharedModule.DATATABLESTACK,
    CbesT5SharedModule.JQUERYTOOLSSTACK
  },
  library={
    "classpath:${cb.assetpath}/js/underscore.string.js",
    "classpath:${cb.assetpath}/js/urlencoder.js",
    "classpath:${cb.assetpath}/js/json2.js",
    "classpath:${cb.assetpath}/js/progressdownload.coffee",
    "classpath:${cb.assetpath}/js/datatable.coffee",
    "context:/js/index.coffee"
})
public class Index
{
  private static final Logger log = CbesLogFactory.getLog(Index.class);
  @Inject
  private ComponentResources componentResources;
  @Inject
  private JavaScriptSupport jsSupport;

  @Inject
  private IJobScheduler jobScheduler;
  @Inject
  private BudgesJobDAO jobDAO;
  @Inject
  private ConfigService config;
  @Inject
  private ValidationService validationService;

  @Persist
  @Property
  private Date start;
  @Persist
  @Property
  private Date finish;

  @Property
  @Persist
  private String selectedQueue;
  @Property 
  private List<String> queueList;
  @Property
  private StringSelectModel queues;
  @Property 
  private BudgesJob r2JobEntry;
  @Property
  private BudgesJobDataSource jobDataSource;
  @Property
  private List<BudgesJob> jobs;

  /***********************************************************************/
  /*** Tapestry Handlers                                               ***/
  /***********************************************************************/

  /**
   * 
   */
  void setupRender()
  {
    componentResources.discardPersistentFieldChanges();
    if (queueList == null)
    {
      queueList = jobDAO.findDistinctQueueNames();
    }
    queues = new StringSelectModel(queueList);

    jobDataSource = new BudgesJobDataSource(selectedQueue, jobDAO);
    jobDataSource.setStart(start);
    // so here's the deal when you get a date from the drop down its time 
    // value is not known. So we set it to a known value.   
    Calendar myCal = Calendar.getInstance();
    if (finish != null)
    {
      myCal.setTime(finish);
      myCal.set(Calendar.HOUR, 23);
      myCal.set(Calendar.MINUTE, 59);
      jobDataSource.setFinish(myCal.getTime());
    }
    else
    {
      jobDataSource.setFinish(new Date());
    }
  }

  /**
   * Gets all the jobs
   */
  @Log
  void onActivate()
  {
    log.debug("Retrieving jobs...");
    if (jobs == null)
    {
      //TODO Change this based on what fliters are selected
      jobs = jobDAO.findAll();
    }
  }

  /**
   * Sets up the action links
   */
  void afterRender()
  {
    //TODO Need to add the two lines below for the filter
//    Link budgetCycleFilterPageLink = componentResources.createEventLink("BudgetCycleChange");
//    jsSupport.addScript("setupBudgetCycleReload('%s');", budgetCycleFilterPageLink);
    JSONObject tableLinks = new JSONObject(
      "reset", componentResources.createEventLink("reset").toString(),
      "stop", componentResources.createEventLink("stop").toString());
    jsSupport.addScript("setupDatatable(%s);", tableLinks.toCompactString());
  }
  
  /**
   * Refreshes page
   * @return
   */
  Object onSelectedFromRefresh()
  {
    return(null); // return to the same page. 
  }
  
  /**
   * Handles the reset click by passing in the jobId from the coffee file
   * @param jobId
   * @return
   */
  Object onReset(String jobId)
  {
    log.debug("id = "+jobId);
    BudgesJob theJob = jobDAO.findByUUID(jobId);
    theJob.setJobStatus(JobStatusFlag.NEW);
    jobDAO.saveOrUpdate(theJob);
    return (null);
  }
  
  /**
   * Handles the stop click by passing in the jobId from the coffee file
   * @param jobId
   * @return
   */
  Object onStop(String jobId)
  {
    log.debug("id = "+jobId);
    BudgesJob theJob = jobDAO.findByUUID(jobId);
    theJob.setJobStatus(JobStatusFlag.STOPPED);
    jobDAO.saveOrUpdate(theJob);
    return (null);
  }

  @Log
  void onSelectedFromRefreshValidatorRules()
  {
    validationService.markRulesCacheForReload();
  }

  @Log
  void onSelectedFromRefreshConfig()
  {
    config.markConfigCacheForReload();
  }

  @Log
  void onSelectedFromDeploy() throws IOException
  {
    File f =  new File(DeploymentJob.TOUCHFILE_PATH);
    if (!f.exists())
      log.debug(f.createNewFile()+"");
    log.debug(f.setLastModified(new Date().getTime())+"");
  }
  
  /***********************************************************************/
  /*** Logic                                                           ***/
  /***********************************************************************/
  
  public String getJobJson()
  {
    List<String> allowedProps = Lists.newArrayList(new String[]{
      "uuid", "dateCreated","jobStatus", "queueName", "dateJobStarted", "dateJobEnded", "startCount"});
    JSONArray jsonArray = new JSONArray();
    
    for (BudgesJob job : jobs)
    {
      JSONObject obj = new JSONObject(Util.toJson(job, allowedProps));
      jsonArray.put(obj);
    }
    return jsonArray.toString(false);
  }

  /***********************************************************************/
  /*** Accessors                                                       ***/
  /***********************************************************************/

  /**
   * Value for 'The Query is Running:'
   * @return Yes or No
   */
  public String getQueryActive()
  {
    return (jobScheduler.isQueryRunning() ? " Yes": " No");
  }

  public boolean getShowDeployButton()
  {
    return config.getEnableAutodeployer();
  }
  

  /**
   * Allocated Memory for footer
   * @return the Allocated Memory in MBs
   */
  public String getAllocatedMemory()
  {
    return (Runtime.getRuntime().totalMemory() / 1024 / 1024) + "MB";
  }

  /**
   * Free Memory for footer
   * @return the free Memory in MBs
   */
  public String getFreeMemory()
  {
    return (Runtime.getRuntime().freeMemory() / 1024 / 1024) + "MB";
  }

  /**
   * Max Memory for footer
   * @return the Max Memory in MBs
   */
  public String getMaxMemory()
  {
    return (Runtime.getRuntime().maxMemory() / 1024 / 1024) + "MB";
  }
  
  /**
   * Total Free Memory for footer
   * @return the Total Free Memory in MBs
   */
  public String getTotalFreeMemory()
  {
    long tfree = Runtime.getRuntime().maxMemory() - Runtime.getRuntime().totalMemory() + Runtime.getRuntime().freeMemory();
    return (tfree / 1024 / 1024) + "MB";
  }

  /**
   * Total Free Memory for footer
   * @return the Total Free Memory in MBs
   */
  public int getProcessors()
  {
    return Runtime.getRuntime().availableProcessors();
  }
}
