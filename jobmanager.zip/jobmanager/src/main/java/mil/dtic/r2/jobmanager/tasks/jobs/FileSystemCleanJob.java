package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONObject;

import mil.dtic.r2.jobmanager.utility.FileCleaner;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;

/**
 * gets locations, day file expire, and file extensions from the db
 * for each location, removes all files past expire limit with any of the given extensions
 */
public class FileSystemCleanJob implements R2Job
{
  private static final Logger log = CbesLogFactory.getLog(FileSystemCleanJob.class);

  private static final String LOCATIONS_FIELD = "locations";
  private static final String EXTENSIONS_FIELD = "extensions";
  private static final String FIELD_SEPARATOR = ";";


  @Override
  public void execute(Map<String,Object> jobData)
  {
    log.info("Starting File Cleanup Job");
    List<String> fileTypes = null;
    List<String> locationAndTimeToExpireList = null;

    String rawLocationAndTimeToExpireData = jobData.get(LOCATIONS_FIELD) + "";
    String rawExtensionData = jobData.get(EXTENSIONS_FIELD) + "";

    if(!rawLocationAndTimeToExpireData.isEmpty())
    {
      locationAndTimeToExpireList = Arrays.asList(rawLocationAndTimeToExpireData.split(FIELD_SEPARATOR));
      fileTypes = Arrays.asList(rawExtensionData.split(FIELD_SEPARATOR));

      if(locationAndTimeToExpireList.size() % 2 == 0)
      {
        int i = 0;
        while(i < locationAndTimeToExpireList.size())
        {
          FileCleaner myCleaner = new FileCleaner(fileTypes, locationAndTimeToExpireList, Integer.parseInt(locationAndTimeToExpireList.get(i + 1)));
          try
          {
            File fLocation = new File(locationAndTimeToExpireList.get(i));
            myCleaner.clean(fLocation);
          }
          catch (IOException e)
          {
            log.error("", e);
          }
          i=i+2;
        } 
      }else{
        log.error("There is an odd number of entries for the directory day pairs.");
        log.error("The directories and days must be pairs seperated by a ; in the db");
      }
    }else{
      log.error("Parameter error values must not be blank");
      log.error("  and multiple values must be separated by " + FIELD_SEPARATOR + "as a field separator");
      log.error("locations;days = " + rawLocationAndTimeToExpireData);
      log.error("extensions = " + rawExtensionData);
    }

    // do we use the value from the environment settings or the value in
    // the application context. The environment overrides the value from
    // the application context.

    log.info("Finished File Cleanup Job");
  }

  @Override
  public JSONObject getConfigTemplate()
  {
    JSONObject value = new JSONObject();
    value.put(ENABLE, "true");
    value.put(JOB_BEAN, getClass().getName());
    value.put(JOB_NAME, "fsclean");
    value.put(JOB_GROUP, JobManagerConstants.DEFAULT_GROUP);
    value.put(JOB_CRON, "0 0 0 1 12 ? 2099");
    value.put(LOCATIONS_FIELD, "paths to directories to scan for deletion along with file age for each directory, semicolon-delimited");
    value.put(EXTENSIONS_FIELD, "file extensions to search for a delete, comma-delimited (no dots)");
    return value;
  }

  @Override
  public String getDescription()
  {
    return "Cleans out certain file system directories periodically";
  }
}
