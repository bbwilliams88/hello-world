package mil.dtic.r2.jobmanager.tapestryutil;

import java.util.ArrayList;
import java.util.List;

import org.apache.tapestry5.OptionGroupModel;
import org.apache.tapestry5.OptionModel;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.internal.OptionModelImpl;
import org.apache.tapestry5.util.AbstractSelectModel;

public class StringSelectModel extends AbstractSelectModel implements ValueEncoder<String>
{
	private List<String> entries;

	public StringSelectModel(List<String> items) {
		entries = items;
	}

	public List<OptionGroupModel> getOptionGroups() {
		return null;
	}

	public List<OptionModel> getOptions() {
		List<OptionModel> options = new ArrayList<OptionModel>();
		for (String value : entries) {
			options.add(new OptionModelImpl(value,value));
		}
		return options;
	} 

	
	public List<String> getList() {
		return entries;
	}
	
	
	public String toClient(String obj) {
		
		return obj;
	}

	public String toValue(String str) {
		return str;
	}


}
