package mil.dtic.r2.jobmanager.utility;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.StreamResponse;
import org.apache.tapestry5.services.Response;

public class XmlStreamResponse implements StreamResponse
{
	private final static String fileExt = ".xml";
	private InputStream is;
	private String filename = "default";

	public XmlStreamResponse(InputStream is, String... args)
	{
		this.is = is;
		if (args != null)
		{
			this.filename = args[0];
		}
	}

	public String getContentType()
	{
		return "application/" + XmlStreamResponse.fileExt;
	}

	public InputStream getStream() throws IOException
	{
		return is;
	}

	public void prepareResponse(Response arg0)
	{
		String fileWithExt = new String(filename);
		if (!StringUtils.endsWith(fileWithExt, ".xml"))
		{
			fileWithExt = fileWithExt + XmlStreamResponse.fileExt;
		}
		arg0.setHeader("Content-Disposition", "attachment; filename="
				+ fileWithExt);
		arg0.setHeader("Expires", "0");
		arg0.setHeader("Cache-Control",
				"must-revalidate, post-check=0, pre-check=0");
		arg0.setHeader("Pragma", "public");
	}
}