package mil.dtic.r2.jobmanager.services;

public interface IStartUpManager
{
  /** Start any jobs that start automatically */
  void start();
  /** stop all jobs */
  void stop(); 
}