package mil.dtic.r2.jobmanager.quartz;

public class QuartzJobInfo
{
	private String jobName;
	private String groupName;
	private String id;
	
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}
	public String getGroupName()
	{
		return groupName; 
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}



}
