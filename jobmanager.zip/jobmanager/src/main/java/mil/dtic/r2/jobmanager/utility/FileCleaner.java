package mil.dtic.r2.jobmanager.utility;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.DirectoryWalker;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;

import mil.dtic.utility.CbesLogFactory;

public class FileCleaner extends DirectoryWalker
{
  private static final Logger log = CbesLogFactory.getLog(FileCleaner.class);

  private List<String> endings;
  private List<String> parentDirectoriesToNotDelete;
  private int age;
  private Date targetDate;

  public FileCleaner(List<String> extensions, List<String> parentDirectoriesToNotDelete, int age)
  {
    this.endings = extensions;
    this.parentDirectoriesToNotDelete = parentDirectoriesToNotDelete;
    this.age = age;
    Calendar targetCal = Calendar.getInstance();
    targetCal.add(Calendar.DAY_OF_MONTH, -1 * this.age);
    targetDate = targetCal.getTime();
  }

  @SuppressWarnings("rawtypes")
  public void clean(File startDirectory) throws IOException 
  {
    walk(startDirectory, new ArrayList(0));
  }


  protected void handleDirectoryEnd(File directory, int depth, @SuppressWarnings("rawtypes") Collection results) throws IOException
  {
    log.trace("Checking directory with path: "+ directory.getAbsolutePath());
    //Check to make sure it does not delete the main directory
    boolean notParentDirectory = true;
    for(String parentDirectoryString : parentDirectoriesToNotDelete)
    {
      if(parentDirectoryString == directory.getAbsolutePath() || parentDirectoryString.equals(directory.getAbsolutePath()))
        notParentDirectory = false;
    }
    if (directory.list() == null)
    {
      log.error("IO Error checking contents of directory with path: "+ directory.getAbsolutePath());
      return;
    }
    if (directory.list().length == 0 && notParentDirectory)
    {
      boolean result = directory.delete();
      if (result)
        log.info("Deleted directory with path: "+ directory.getAbsolutePath());
      else
        log.error("Deleting directory with path: "+ directory.getAbsolutePath() + " failed");
    }
  }


  protected boolean handleDirectory(File directory, int depth, @SuppressWarnings("rawtypes") Collection results)
  {
    if (directory.list() == null)
    {
      log.error("IO Error checking contents of directory with path: "+ directory.getAbsolutePath());
      return false;
    }
    if (directory.list().length >= 0)
    {
      return true;
    }
    else
    {
      boolean result = directory.delete();
      if (result)
        log.info("Deleted directory with path: "+ directory.getAbsolutePath());
      else
        log.error("Deleting directory with path: "+ directory.getAbsolutePath() + " failed");
      return false;
    }
  }

  protected void handleFile(File file, int depth, @SuppressWarnings("rawtypes") Collection results) {

    String name = file.getAbsolutePath();
    if (testEnding(name)&& FileUtils.isFileOlder(file, targetDate))
    {
      boolean result = file.delete();
      if (result)
        log.info("Deleted file with path: "+ file.getAbsolutePath());
      else
        log.error("Deleting file with path: "+ file.getAbsolutePath() + " failed");
    }
  }

  private boolean testEnding(String fileName)
  {
    for(String ending: endings)
    {
      if (StringUtils.endsWith(fileName, ending))
      {
        return true;
      }
    }
    return false;
  }
}
