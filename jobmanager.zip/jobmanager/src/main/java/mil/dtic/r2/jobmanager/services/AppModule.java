package mil.dtic.r2.jobmanager.services;

import java.util.Collections;
import java.util.UUID;

import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.Translator;
import org.apache.tapestry5.ioc.Configuration;
import org.apache.tapestry5.ioc.MappedConfiguration;
import org.apache.tapestry5.ioc.ServiceBinder;
import org.apache.tapestry5.ioc.annotations.Startup;
import org.apache.tapestry5.ioc.annotations.SubModule;
import org.apache.tapestry5.ioc.services.Coercion;
import org.apache.tapestry5.ioc.services.CoercionTuple;
import org.apache.tapestry5.ioc.services.RegistryShutdownHub;
import org.apache.tapestry5.ioc.services.RegistryShutdownListener;
import org.apache.tapestry5.json.JSONObject;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import mil.dtic.cbes.t5shared.services.CbesT5SharedModule;
import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.r2.jobmanager.quartz.JobScheduler;
import mil.dtic.r2.jobmanager.utility.UUIDTranslator;
import mil.dtic.utility.CbesLogFactory;

/**
 * This module is automatically included as part of the Tapestry IoC Registry, it's a good place to
 * configure and extend Tapestry, or to place your own service definitions.
 */
@SubModule({CbesT5SharedModule.class})
public class AppModule
{
  private static final Logger log = CbesLogFactory.getLog(AppModule.class);


  public static void bind(ServiceBinder binder)
  {
    // binder.bind(MyServiceInterface.class, MyServiceImpl.class);

    // Make bind() calls on the binder object to define most IoC services.
    // Use service builder methods (example below) when the implementation
    // is provided inline, or requires more initialization than simply
    // invoking the constructor.
    binder.bind(IStartUpManager.class, StartUpManager.class);
    binder.bind(IJobScheduler.class, JobScheduler.class);
  }

  public Logger buildLogger(final Logger log)
  {
    return log;
  }

  @Startup
  public void initStartUpManager(final IStartUpManager startUpManager)
  {
    startUpManager.start(); //start automatic jobs on Tapestry startup
  }
  
  @Startup
  public void addJobStopper(final RegistryShutdownHub shutdownHub, final Scheduler quartzScheduler)
  {
    //Stop any scheduled jobs on shutdown, since if Jetty restarts they keep running with the old classloader
    shutdownHub.addRegistryShutdownListener(new RegistryShutdownListener() {
      public void registryDidShutdown() {
        log.trace("stopping scheduled jobs");
        try {
          for (String triggerGroup : quartzScheduler.getTriggerGroupNames())
            for (TriggerKey triggerKey : quartzScheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(triggerGroup)))
              quartzScheduler.unscheduleJob(triggerKey);
        }
        catch (SchedulerException e) {
          log.error("unschedule failed", e);
        }
      }
    });
  }

  //Unused spring security stuff
  //only here so it can run in the same classpath
  //as the other apps
  public static UserDetailsService buildUserDetailsService()
  {
    return new UserDetailsService() {
      @Override
      public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
        return new User("", "password", true, true, true, true, Collections.<GrantedAuthority>emptyList());
      }
    };
  }



  public static void contributeTranslatorSource(MappedConfiguration<Class<?>,Translator<?>> configuration) {
    configuration.add(UUID.class, new UUIDTranslator());
  }

  public static void contributeDefaultDataTypeAnalyzer(MappedConfiguration<Class<?>, String> configuration)
  {
    configuration.add(UUID.class, "currency");
  }

  public static void contributeTypeCoercer(Configuration<CoercionTuple<?, ?>> configuration)
  {
    configuration.add(new CoercionTuple<String, JSONObject>(String.class, JSONObject.class, new Coercion<String, JSONObject>() {
      @Override
      public JSONObject coerce(String input) {
        log.trace("Coercing String->JSONObject");
        return new JSONObject(input);
      }
    }));
  }

  public static void contributeApplicationDefaults(
    MappedConfiguration<String, String> configuration)
  {
    // Contributions to ApplicationDefaults will override any contributions to
    // FactoryDefaults (with the same key). Here we're restricting the supported
    // locales to just "en" (English). As you add localised message catalogs and other assets,
    // you can extend this list of locales (it's a comma separated series of locale names;
    // the first locale name is the default when there's no reasonable match).

    configuration.add(SymbolConstants.SUPPORTED_LOCALES, "en");

    // The factory default is true but during the early stages of an application
    // overriding to false is a good idea. In addition, this is often overridden
    // on the command line as -Dtapestry.production-mode=false
    configuration.add(SymbolConstants.PRODUCTION_MODE, "false");

    // The application version number is incorprated into URLs for some
    // assets. Web browsers will cache assets because of the far future expires
    // header. If existing assets are changed, the version number should also
    // change, to force the browser to download new versions.
    configuration.add(SymbolConstants.APPLICATION_VERSION, "0.1-SNAPSHOT");
  }
}
