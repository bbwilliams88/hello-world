package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.json.JSONObject;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.support.OpenSessionInterceptor;

import mil.dtic.cbes.constants.JBookWorkFlowStatus;
import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.jb.JustificationBookGroup;
import mil.dtic.cbes.jb.JustificationBookInfo;
import mil.dtic.cbes.service.VirusScanException;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.delegates.P40XMLTools;
import mil.dtic.cbes.submissions.delegates.PreviewResultInfo;
import mil.dtic.cbes.submissions.delegates.R2Storage;
import mil.dtic.cbes.submissions.delegates.R2XMLTools;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsError;
import mil.dtic.cbes.submissions.delegates.R2XMLTools.R2XMLToolsException;
import mil.dtic.cbes.submissions.delegates.errorformat.R2XMLResponseFactory;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.r2.jobmanager.services.SpringJobService;
import mil.dtic.r2.jobmanager.utility.JobManagerConstants;
import mil.dtic.utility.CbesLogFactory;
import mil.dtic.utility.Util;

public class PdfJob implements R2Job {
    private static final Logger log = CbesLogFactory.getLog(PdfJob.class);
    private static final String  ANALYST_REF = "analystRef";
    private static final String  FINAL_NOTES = "finalNotes";
    private static final String  JOB_REF = "jobRef";
    private static final String  WORK_FLOW_STATUS = "workFlowStatus";
    private static final Integer FINAL_CONTENT = 3;
    private static final String  JBOOK_JOB_REFERENCE = "JBook Job reference: ";
    private static final String  JBOOK_ANALYST_REFERENCE = "JBook Analyst reference: ";
    private static final String  NOT_PROVIDED = "NOT PROVIDED";
    private static final String  ADDITIONAL_COMMENTS = "JBook Additional comments: ";
    private static final String  TWO_NEW_LINES = "\n\n";
    private static final String  NON_FINAL_FINAL_CONTENT = "Success Message: Successfully processed %s work flow";
    
    @Autowired
    private ConfigService config;
    
    @Autowired
    private SpringJobService service;
    
    @Autowired
    private OpenSessionInterceptor j_hibernateInterceptor;
    
    private Map<String, String>  workFlowData = null;
    
    @Override
    public void execute(Map<String, Object> jobDetailMap) {
        PdfJobData theData = (PdfJobData) jobDetailMap.get(AbstractJobData.JOB_DATA_KEY);
        String jobId = theData.getJobId();
        log.debug("PdfJob : executing job: " + jobId);
        
        try {
            BudgesJob theJob = service.findJob(jobId);
            boolean returnXmlrspOnly = false;
            boolean onlyRunVerifiedRules = 
                    theJob.getAgency() == null ? true : !config.getUnverifiedRulesAgencies().
                            contains(theJob.getAgency().getCode());
            File dirInUpl = R2Storage.getWorkingDirectory(theJob);
            
            R2XMLToolsMethod method = getMethodFromJob(theJob);
            PreviewResultInfo pri;
            
            try {
                log.trace("PdfJob:execute - start running job");
                pri = method.execute(theJob, onlyRunVerifiedRules);
                log.trace("PdfJob:execute - finsihed running job");
            } 
            catch (R2XMLToolsException e) {
                returnXmlrspOnly = true;
                pri = e.getPreviewResultInfo();
            }
            
            if(pri.getMjb() != null){
                try {
                    processForRfrFormatting(pri, theJob);
                }
                catch(RuntimeException e) {
                    // intentionally eating this exception.
                    log.error("execute: RFR Formatting failure - msg: " + e.getMessage(),e);
                }
            }
            
            theData.setJobType(Util.getJobType(pri));
            String xmlresponse = R2XMLResponseFactory.buildXMLResponse(pri);
            File result = R2XMLTools.getResultFile(pri);
            
            if (returnXmlrspOnly) {
                result = saveXmlResponseToFile(dirInUpl, xmlresponse);
                theJob.setResultFilename(result.getName());
            } else {
                File xml = saveXmlResponseToFile(dirInUpl, xmlresponse);
                result = R2Storage.repackageResult(dirInUpl, result, xml);
                theJob.setResultFilename(result.getName());
            }
            
            if (returnXmlrspOnly) {
                theJob.setJobStatus(JobStatusFlag.ERROR); //having to set this here is annoying
            }
            
            theJob.setDateJobEnded(new Date());
            
            service.saveOrUpdate(theJob);
            
        } catch (IOException | R2XMLToolsError | VirusScanException | TransformerException e) {
            jobDetailMap.put(JobManagerConstants.JOB_ABORTED, "true");
            service.setAbortJob(jobId, e);
            log.error("pdfjob execute", e);
        }
        //System.gc(); //This delays gc slowdown under load by a little
    }
    
    private static interface R2XMLToolsMethod {
        public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules)
                throws IOException, R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException;
    }
    
    private File saveXmlResponseToFile(File parentFolder, String xml) throws IOException {
        if (!parentFolder.exists()) {
            throw new IOException("saveXmlResponseToFile: destinination folder does not exist - " + parentFolder);
        }
        
        File dest = new File(parentFolder, JobManagerConstants.XML_RESP_FILENAME);
        
        if (dest.exists()) {
            dest.delete();
        }
        
        if (!dest.createNewFile()) {
            throw new IOException("saveXmlResponseToFile: Could not create file - " + dest);
        }
        
        FileUtils.writeStringToFile(dest, xml);
        return dest;
    }
    
    private R2XMLToolsMethod getMethodFromJob(BudgesJob job) {
        log.trace("PdfJob:getMethodFromJob - start");
        ProxyFactory proxyFactory = new ProxyFactory(new Class[] { R2XMLToolsMethod.class });
        proxyFactory.setTarget(_getMethodFromJob(job));
        proxyFactory.addAdvice(j_hibernateInterceptor);
        return (R2XMLToolsMethod) proxyFactory.getProxy();
    }
    
    @SuppressWarnings("incomplete-switch")
    private R2XMLToolsMethod _getMethodFromJob(BudgesJob job) {
        log.trace("PdfJob:_getMethodFromJob - start");
        R2XMLToolsMethod nothing = new R2XMLToolsMethod() {
            @Override
            public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules)
                    throws IOException, R2XMLToolsException, R2XMLToolsError {
                return new PreviewResultInfo();
            }
        };
        
        if (job.getJobType() == null) {
            log.error("null job type", new NullPointerException());
            return nothing;
        }
        
        switch (job.getJobType()) {
            case VALIDATEXML:
                log.error("wtf is validatexml doing here in the async jobs?", new IllegalArgumentException());
                return nothing;
            case R2XMLTOSINGLEPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        return R2XMLTools.buildR2Pdfs(job, false, onlyRunVerifiedRules);
                    }
                };
            case R2XMLTOMULTIPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        return R2XMLTools.buildR2Pdfs(job, true, onlyRunVerifiedRules);
                    }
                };
            case R2JBXMLTOPDF:
            case P40JBXMLTOPDF:
            case JBXMLTOPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        log.trace("PdfJob:_getMethodFromJob - processing JBXMLTOPDF job type - > calling R2XMLTools.buildJbPdf(..)");
                        return R2XMLTools.buildJbPdf(job, onlyRunVerifiedRules);
                    }
                };
            case R2MJBXMLTOPDF:
            case P40MJBXMLTOPDF:
            case MJBXMLTOPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        log.trace("PdfJob:_getMethodFromJob - processing for *XMLTOPDF or MJBXMLTOPDF/ job type - > calling R2XMLTools.buildMjbPdf(..)");
                        return R2XMLTools.buildMjbPdf(job, onlyRunVerifiedRules);
                    }
                };
            case P40XMLTOSINGLEPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        return P40XMLTools.buildP40Pdfs(job, false, onlyRunVerifiedRules);
                    }
                };
            case P40XMLTOMULTIPDF:
                return new R2XMLToolsMethod() {
                    @Override
                    public PreviewResultInfo execute(BudgesJob job, boolean onlyRunVerifiedRules) throws IOException,
                            R2XMLToolsException, R2XMLToolsError, VirusScanException, TransformerException {
                        return P40XMLTools.buildP40Pdfs(job, true, onlyRunVerifiedRules);
                    }
                };
        }
        log.error("Unhandled job type " + job.getJobType(), new IllegalArgumentException());
        return nothing;
    }
    
    @Override
    public JSONObject getConfigTemplate() {
        return null;
    }
    
    @Override
    public String getDescription() {
        return "";
    }
    
    private int getRfr(PreviewResultInfo pri) {
        Map<String, String> workFlowMap = new HashMap<>();
        
        if (null != pri.getMjb() && pri.getMjb().isRfr()) {
            workFlowMap.put(PdfJob.ANALYST_REF, pri.getMjb().getDocAssemblyOptions().getAnalystReference());
            workFlowMap.put(PdfJob.FINAL_NOTES, pri.getMjb().getDocAssemblyOptions().getFinalNotes());
            workFlowMap.put(PdfJob.JOB_REF, pri.getMjb().getDocAssemblyOptions().getJobReference());
            workFlowMap.put(PdfJob.WORK_FLOW_STATUS, pri.getMjb().getDocAssemblyOptions().getWorkFlowStatus());
        } else if (null != pri.getJb() && pri.getJb().isRfr()) {
            workFlowMap.put(PdfJob.ANALYST_REF, pri.getJb().getDocAssemblyOptions().getAnalystReference());
            workFlowMap.put(PdfJob.FINAL_NOTES, pri.getJb().getDocAssemblyOptions().getFinalNotes());
            workFlowMap.put(PdfJob.JOB_REF, pri.getJb().getDocAssemblyOptions().getJobReference());
            workFlowMap.put(PdfJob.WORK_FLOW_STATUS, pri.getJb().getDocAssemblyOptions().getWorkFlowStatus());
        } else {
            return 0;
        }
        
        workFlowData = workFlowMap;
        return JBookWorkFlowStatus.valueOf(workFlowMap.get(PdfJob.WORK_FLOW_STATUS)).getType();
    }
    
    private String getRfrFinalContent() {
        StringBuilder builder = new StringBuilder();
        String jobReference = workFlowData.get(PdfJob.JOB_REF);
        if (StringUtils.isNotBlank(jobReference)) {
            builder.append("\n" + PdfJob.JBOOK_JOB_REFERENCE + jobReference + PdfJob.TWO_NEW_LINES);
        } else {
            builder.append("\n" + PdfJob.JBOOK_JOB_REFERENCE + PdfJob.NOT_PROVIDED + PdfJob.TWO_NEW_LINES);
        }
        
        String analystReference = workFlowData.get(PdfJob.ANALYST_REF);
        if (StringUtils.isNotBlank(analystReference)) {
            
            builder.append(PdfJob.JBOOK_ANALYST_REFERENCE + analystReference + TWO_NEW_LINES);
        } else {
            builder.append(PdfJob.JBOOK_ANALYST_REFERENCE + PdfJob.NOT_PROVIDED + PdfJob.TWO_NEW_LINES);
        }
        
        String finalNotes = workFlowData.get(PdfJob.FINAL_NOTES);
        if (StringUtils.isNotBlank(finalNotes)) {
            builder.append(PdfJob.ADDITIONAL_COMMENTS + finalNotes + "\n");
        } else {
            builder.append(PdfJob.ADDITIONAL_COMMENTS + PdfJob.NOT_PROVIDED + "\n");
        }
        
        return builder.toString();
    }
    
    private void processForRfrFormatting(PreviewResultInfo pri, BudgesJob theJob) throws RuntimeException{
        
        String volumeAggregationTitle = null;
        
        //CXE-6636
        if (null == pri.getMjb()) {
            return;
        }
        
        try {
            volumeAggregationTitle = pri.getMjb().getDocAssemblyOptions().getVolumeTitleAggregation();
        }
        catch(RuntimeException e) { //CXE-6636
            if (e instanceof NullPointerException) {
                log.warn("Exception capturing volumeAggregation title - NPE");
            }
            else {
                throw e;
            }
        }
        
        if (null == volumeAggregationTitle){  
            volumeAggregationTitle = processForNullVolumeAggregationTitle(pri);  // in the event title not part of documentsAssemblyOptions
        }
        String appn = pri.getMjb().getJbgList().get(0).getJbiList().get(0).getJb().getAppropriation().getName();
        String appnCode = pri.getMjb().getJbgList().get(0).getJbiList().get(0).getJb().getAppropriation().getCode();
        String budgetCycle = pri.getMjb().getJbgList().get(0).getJbiList().get(0).getJb().getBudgetCycleAndYear();
        
        theJob.setVolumeTitleAggregation(volumeAggregationTitle);
        theJob.setAppropriation(String.format("%s ( %s )", appn, appnCode));
        theJob.setBudgetCycle(budgetCycle);
        
        int rfr = getRfr(pri);
        theJob.setReadyForReview(rfr);
        Boolean useMjb = null;
        if (null != pri.getMjb()) {
            useMjb = Boolean.TRUE;
        } else if (null != pri.getJb()) {
            useMjb = Boolean.FALSE;
        }
        
        JBookWorkFlowStatus jBookWorkFlowStatus = null;
        
        if (useMjb != null) {  // for now, ony process for userMjb, so only testing for null
            if (rfr == 0) {
                if (useMjb) {
                    jBookWorkFlowStatus = JBookWorkFlowStatus
                            .valueOf(pri.getMjb().getDocAssemblyOptions().getWorkFlowStatus());
                } else {
                    jBookWorkFlowStatus = JBookWorkFlowStatus
                            .valueOf(pri.getJb().getDocAssemblyOptions().getWorkFlowStatus());
                }
                String failMsg = jBookWorkFlowStatus.getFailMsg();
                theJob.setRfrFinalContent(failMsg);
            }
            
            if (rfr == PdfJob.FINAL_CONTENT) {
                String content = getRfrFinalContent();
                if (StringUtils.isNotBlank(content)) {
                    theJob.setRfrFinalContent(content);
                }
            }
            
            if (rfr > 0 && rfr < PdfJob.FINAL_CONTENT) {
                if (useMjb) {
                    jBookWorkFlowStatus = JBookWorkFlowStatus
                            .valueOf(pri.getMjb().getDocAssemblyOptions().getWorkFlowStatus());
                } else {
                    jBookWorkFlowStatus = JBookWorkFlowStatus
                            .valueOf(pri.getJb().getDocAssemblyOptions().getWorkFlowStatus());
                }
                
                theJob.setRfrFinalContent(
                        String.format(PdfJob.NON_FINAL_FINAL_CONTENT, jBookWorkFlowStatus.getDisplayName()));
            }
        }
    }
    
    private String processForNullVolumeAggregationTitle(PreviewResultInfo pri){
        StringBuilder sb = new StringBuilder();
        String title = null;
        String defaultTitle = "Title Undetermined";
        try {
            for (JustificationBookGroup grp : pri.getMjb().getJbgList()){
                for (JustificationBookInfo jbi : grp.getJbiList()){
                    sb.append(jbi.getJb().getCoverDoc().getTitle()+ ", ");
                }
            }
            title = sb.toString();
            title = title.substring(0, title.length() -1);
        }
        catch(Exception e){
            log.debug("failed to process for null volumeAggregationTitle: " + e.getMessage(),e);
            title = defaultTitle;
        }
        
        if (null == title){
            title = defaultTitle;
        }
        
        return title;
        
    }
    
    
    
}
