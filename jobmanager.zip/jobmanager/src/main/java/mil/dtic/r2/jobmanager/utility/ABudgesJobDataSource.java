package mil.dtic.r2.jobmanager.utility;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tapestry5.grid.ColumnSort;
import org.apache.tapestry5.grid.GridDataSource;
import org.apache.tapestry5.grid.SortConstraint;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;

public abstract class ABudgesJobDataSource implements GridDataSource
{
	@SuppressWarnings("rawtypes")
	private Iterator pageRowIterator;
	abstract public int getAvailableRows();

	abstract List<BudgesJob> getJobListPaged(String[] entries, boolean ascending, int start, int end);

	public void prepare(int startIndex, int endIndex,
			List<SortConstraint> sortConstraints)
	{
		boolean ascending = false;
		int count = sortConstraints.size() ;
		List<String> sorts = new ArrayList<String>();
		if (count > 0)
		{
			
			for (SortConstraint item: sortConstraints)
			{
				String propertyName = item.getPropertyModel().getPropertyName();
				ascending = (item.getColumnSort()==ColumnSort.ASCENDING);

				sorts.add(propertyName);
			}
		}
		String[] entries = sorts.toArray(new String[sorts.size()]);
		pageRowIterator =  getJobListPaged(entries, ascending, 
								startIndex, endIndex).iterator();
	}

	public Object getRowValue(int index)
	{
		Object retValue = null;
		if ((pageRowIterator != null) && (pageRowIterator.hasNext()))
		{
			retValue = pageRowIterator.next();
		}
		return retValue ;
	}

	@SuppressWarnings("rawtypes")
	public Class getRowType()
	{
		return BudgesJob.class;
	}

}
