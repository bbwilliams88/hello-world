package mil.dtic.r2.jobmanager.tasks.jobs;

import java.io.Serializable;


public class QueryJobData extends AbstractJobData implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5851550990944280299L;
	private String triggerName;

	@Override
	public String getJobListenerName() {
		return QueryJobListener.JOB_LISTENER_NAME;
	}

	public void setJobTriggerName(String queryTriggerName)
	{
		triggerName = queryTriggerName;
		
	}

	public String getJobTriggerName()
	{
		return triggerName;
	}
	
}
