package mil.dtic.r2.jobmanager.tasks.jobs;

import org.apache.logging.log4j.Logger;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.UnableToInterruptJobException;

import mil.dtic.utility.CbesLogFactory;

public class AnyJob  implements InterruptableJob
{
  public static final String JOB_BEAN_KEY = "jobBean";
  private static final Logger log = CbesLogFactory.getLog(AnyJob.class);
  private Thread myThread;
  private int progressCounter = 0;


  @Override
@SuppressWarnings("unchecked")
  public void execute(JobExecutionContext context) throws JobExecutionException
  {
    myThread = Thread.currentThread();
    R2Job jobBean = (R2Job)context.getJobDetail().getJobDataMap().get(JOB_BEAN_KEY);
    jobBean.execute(context.getJobDetail().getJobDataMap());
  }

  public  int getProgressCounter() {
    return progressCounter;
  }

  public  void setProgressCounter(int progressCounter) {
    this.progressCounter = progressCounter;
  }

  @Override
public void interrupt() throws UnableToInterruptJobException
  {
    if (myThread != null)
    {
      myThread.interrupt();
    }
  }
}