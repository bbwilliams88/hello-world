package mil.dtic.r2.jobmanager.pages;

import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.tapestry5.ComponentResources;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.beaneditor.BeanModel;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.services.BeanModelSource;
import org.apache.logging.log4j.Logger;

import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.r2.jobmanager.quartz.IJobScheduler;
import mil.dtic.r2.jobmanager.quartz.QuartzJobInfo;
import mil.dtic.utility.BudgesContext;
import mil.dtic.utility.CbesLogFactory;

@SuppressWarnings("rawtypes")
@Import(stylesheet = "context:css/QuartzJobs.css")
public class QuartzJobs
{
  private final String JOB_FIELD = "jobName";
  private final String GROUP_FIELD = "groupName";
  private final String ID_FIELD = "id";
  private final String JOB_LABEL = "Job Name";
  private final String GROUP_LABEL = "Group Name";
  private final String ID_LABEL = "Id";
  private final String ACTION_FIELD = "action";
  private final String ACTION_LABEL = "Unschedule Job";


  @Property
  private QuartzJobInfo jobItem;

  private static final Logger log = CbesLogFactory.getLog(QuartzJobs.class);

  private List<QuartzJobInfo> jobList;
  @Property
  private BeanModel _jobModel;
  @Inject
  private BeanModelSource _beanModelSource;
  @Inject
  private ComponentResources _componentResources;
  @Inject
  private IJobScheduler jobScheduler;
  @Inject
  private ConfigDAO configDAO;


  @SuppressWarnings("unused")
  @Property
  private QuartzJobInfo r2JobEntry;


  public QuartzJobs()
  {

  }


  public List<QuartzJobInfo> getJobList()
  {
    return jobList;
  }


  public void setJobList(List<QuartzJobInfo> jobList)
  {
    this.jobList = jobList;
  }


  public void setupRender()
  {
    if (_jobModel == null)
    {
      _jobModel = _beanModelSource.createDisplayModel(QuartzJobInfo.class,
        _componentResources.getMessages());
      _jobModel.include(GROUP_FIELD, JOB_FIELD, ID_FIELD);
      _jobModel.get(GROUP_FIELD).label(GROUP_LABEL);
      _jobModel.get(JOB_FIELD).label(JOB_LABEL);
      _jobModel.get(ID_FIELD).label(ID_LABEL);
      _jobModel.add(ACTION_FIELD, null);
      _jobModel.get(ACTION_FIELD).label(ACTION_LABEL);
    }

    jobList = jobScheduler.getJobInfo();
  }


  private static final ThreadLocal<SimpleDateFormat> mdhformatter = new ThreadLocal<SimpleDateFormat>()
  {
    @Override
    protected SimpleDateFormat initialValue()
    {
      return new SimpleDateFormat("MM dd HH:mm:ss");
    }
  };


  public boolean isQueryJobRunning()
  {
    return(jobScheduler.isQueryRunning());
  }


  public boolean isShowList()
  {
    return((jobList != null) && (jobList.size() > 0));
  }


  public int getJobListSize()
  {
    return((jobList != null) && (jobList.size() > 0) ? jobList.size() : 0);
  }


  void onSelectedFromReload()
  {
    jobScheduler.unscheduleAllJobs();
    jobScheduler.scheduleJobsFromConfig(configDAO.getSystemJobs());
  }

  void onSelectedFromPause()
  {
    jobScheduler.pauseSystemJobs();
  }

  void onSelectedFromUnpause()
  {
    jobScheduler.resumeSystemJobs();
  }

  public Object onSelectedFromStopQuery()
  {
    jobScheduler.pauseQueryJob();
    return(null);
  }


  public Object onActionFromDeleteJob(String groupName, String jobName)
  {
    log.debug("gid = " + groupName + " jid= " + jobName);
    jobScheduler.stopJobWithGroupAndName(groupName, jobName);
    return(null);
  }


  public boolean isIdValidForJob()
  {
    return(StringUtils.isNotBlank(jobItem.getId()));
  }


  public Object[] getDeleteContext()
  {
    String groupName = (jobItem.getGroupName() == null) ? "" :
      new String(jobItem.getGroupName());
    String jobName = (jobItem.getJobName() == null) ? "" :
      new String(jobItem.getJobName());
    return new Object[]{groupName, jobName};
  }


  public String getLastRun()
  {
    return jobScheduler.getLastQueryRunTime();
  }


  public String getQueueName()
  {
    String queueName = BudgesContext.getConfigService().getQueueName();
    return(queueName);
  }
  
  public boolean isQuartzRunning()
  {
    return jobScheduler.isQuartzRunning();
  }
}
