package mil.dtic.r2.jobmanager.pages;

import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.apache.tapestry5.ValidationException;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.InjectComponent;
import org.apache.tapestry5.annotations.Log;
import org.apache.tapestry5.annotations.Persist;
import org.apache.tapestry5.annotations.Property;
import org.apache.tapestry5.corelib.components.Form;
import org.apache.tapestry5.ioc.annotations.Inject;
import org.apache.tapestry5.json.JSONArray;
import org.apache.tapestry5.json.JSONObject;

import mil.dtic.cbes.submissions.ValueObjects.Config;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.dao.imp.ConfigDAOImpl;
import mil.dtic.utility.CbesLogFactory;

/**
 * System job editor
 */
@Import(stylesheet = "context:/css/SysJobs.css")
public class SysJobsEdit
{
  private static final String T5ID = "t5id";
  //TODO move these
  private static final String SYS_JOB_CLASS = "jobBeanClass";
  private static final String SYS_JOB_NAME = "jobName";
  private static final String SYS_JOB_GROUP = "R2SysGroup";
  private static final String SYS_JOB_CRON_SPEC = "cronTrigger";

  private static final Logger log = CbesLogFactory.getLog(SysJobsEdit.class);


  @Inject
  private ConfigDAO configDAO;


  @InjectComponent
  private Form form;


  @Persist
  @Property
  private List<JSONObject> jobs;
  @Property
  private Config config;
  @Property
  private JSONObject currentJob;
  @Property
  private String currentProp;
  @Property
  @Persist
  private String newProp;
  private boolean saveClicked;


  void setupRender()
  {
    config = configDAO.findByName(ConfigDAOImpl.JM_JOBS);
    if (jobs == null) {
      jobs = new ArrayList<JSONObject>();
      String json = "[]"; //configDAO.getSystemJobs();
      try {
//        if (json != null)
          CollectionUtils.addAll(jobs, new JSONArray(json).iterator());
      } catch (RuntimeException e) {
        log.error("", e);
        form.recordError(e.getMessage());
      }
    }
  }

  void onSelectedFromSaveIt()
  {
    saveClicked = true;
  }

  void onValidateFromForm() throws UnknownHostException, ValidationException
  {
    if (saveClicked) {
      log.info("save!");
      config = configDAO.findByName(ConfigDAOImpl.JM_JOBS);
      if (config == null)
        throw new ValidationException("No config table row to save to");
      config.setValue(new JSONArray(jobs.toArray()).toString());
      log.debug(config.getValue());
      configDAO.saveByConfig(config);
    } else { //revert
      jobs = null;
    }
  }

  void onSuccess()
  {

  }

  @Log
  void onKeyUp(String newPropValue)
  {
    newProp = newPropValue;
  }

  @Log
  JSONObject onAddRowFromJobs()
  {
    String uuid = UUID.randomUUID().toString();
    jobs.add(new JSONObject(T5ID, uuid, SYS_JOB_NAME, "", SYS_JOB_CLASS, "", SYS_JOB_CRON_SPEC, ""));
    return jobs.get(jobs.size() - 1);
  }

  @Log
  void onRemoveRowFromJobs(JSONObject job)
  {
    updateListWithNewVersion(job); //update version in list
    jobs.remove(job); //now it can be remove with equals()
  }

  @Log
  String onAddRowFromProps(JSONObject context)
  {
    updateListWithNewVersion(context);
    if (StringUtils.isEmpty(newProp))
      throw new IllegalArgumentException("empty property");
    if (context.keys().contains(newProp))
      throw new IllegalArgumentException("That property exists already");
    context.put(newProp, "");
    currentJob = context;
    currentProp = newProp;
    return newProp;
  }

  @Log
  void onRemoveRowFromProps(JSONObject context, String prop)
  {
    updateListWithNewVersion(context);
    context.remove(prop);
  }


  public void setCurrentPropValue(String value)
  {
    updateListWithNewVersion(currentJob);
    currentJob.put(currentProp, value);
  }

  public String getCurrentPropValue()
  {
    return currentJob.getString(currentProp);
  }

  private void updateListWithNewVersion(JSONObject job)
  {
    for (JSONObject j : jobs) {
      if (StringUtils.equals(j.getString(T5ID), job.getString(T5ID))) {
        jobs.set(jobs.indexOf(j), job);
        break;
      }
    }
  }

  public String formatDate(Date d)
  {
    return new SimpleDateFormat("yyyy MM dd HH:mm:ss").format(d);
  }

  public String getCssClass(String propkey)
  {
    return propkey.replaceAll("\\s", "");
  }
}
