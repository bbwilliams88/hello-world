package mil.dtic.r2.jobmanager.services;

import java.lang.reflect.InvocationTargetException;

import org.apache.tapestry5.ioc.annotations.Inject;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.support.OpenSessionInterceptor;

import mil.dtic.utility.CbesLogFactory;


public class HibernateInterceptorAdvice
{
  private static final Logger log = CbesLogFactory.getLog(HibernateInterceptorAdvice.class);
  @Autowired
  private OpenSessionInterceptor j_hibernateInterceptor;

  /**
   * I suppose your DAO's live in com.app.dao package
   * @throws NoSuchMethodException 
   * @throws InvocationTargetException 
   * @throws IllegalAccessException 
   * @throws SecurityException 
   * @throws IllegalArgumentException 
   */
  @Around("execution(* mil.dtic.r2.mil.dtic.r2.jobmanager.services.SpringJobService.*(..))")
  public Object interceptCall(ProceedingJoinPoint joinPoint) throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
    log.trace("intercepted");
    ProxyFactory proxyFactory = new ProxyFactory(joinPoint.getTarget());
    proxyFactory.addAdvice(j_hibernateInterceptor);

    Class<?> [] classArray = new Class[joinPoint.getArgs().length];
    for (int i = 0; i < classArray.length; i++)
      classArray[i] = joinPoint.getArgs()[i].getClass();

    return
    proxyFactory
      .getProxy()
      .getClass()
      .getDeclaredMethod(joinPoint.getSignature().getName(), classArray)
      .invoke(proxyFactory.getProxy(), joinPoint.getArgs());
  }
}
