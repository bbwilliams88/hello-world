package mil.dtic.r2.jobmanager.services;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import mil.dtic.cbes.data.config.JobStatusFlag;
import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.ValueObjects.BudgesUser;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;
import mil.dtic.cbes.submissions.dao.BudgesUserDAO;
import mil.dtic.cbes.submissions.dao.ConfigDAO;
import mil.dtic.cbes.submissions.service.annotated.ConfigService;
import mil.dtic.utility.CbesLogFactory;

public class SpringJobService
{
  private static final Logger log = CbesLogFactory.getLog(SpringJobService.class);
  @Autowired
  private BudgesJobDAO jobDAO;
  @Autowired
  private BudgesUserDAO userDAO;
  @Autowired
  private ConfigDAO configDAO;
  @Autowired
  private ConfigService config;


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#findJob(java.lang.String)
   */
  public BudgesJob findJob(String uuid)
  {
    BudgesJob job = jobDAO.findByUUID(uuid);
    jobDAO.initialize(job.getAgency());
    return job;
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#findUser(java.lang.Integer)
   */
  public BudgesUser findUser(Integer id)
  {
    BudgesUser theUser = userDAO.findById(id);
    return theUser;
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#setAbortJob(java.lang.String, java.lang.String)
   */
  public void setAbortJob(String uuid, Throwable t)
  {
    BudgesJob theJob = jobDAO.findByUUID(uuid);
    theJob.setDateJobEnded(new Date());
    if (t != null) {
      ByteArrayOutputStream bas = new ByteArrayOutputStream();
      PrintStream p = new PrintStream(bas);
      log.debug(t.getStackTrace()); 
      theJob.setStackTrace(bas.toString());
    }
    theJob.setJobStatus(JobStatusFlag.ABORTED);
    jobDAO.saveOrUpdate(theJob);
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#setStartfailJob(java.lang.String)
   */
  public void setStartfailJob(String uuid)
  {
    BudgesJob theJob = jobDAO.findByUUID(uuid);
    theJob.setDateJobEnded(new Date());
    theJob.setJobStatus(JobStatusFlag.STARTFAIL);
    jobDAO.saveOrUpdate(theJob);
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#setScheduledJob(mil.dtic.cbes.submissions.ValueObjects.BudgesJob, java.lang.String)
   */
  public void setScheduledJob(BudgesJob job, String instanceName)
  {
    job.setJobStatus(JobStatusFlag.SCHEDULED);
    job.setRunInstance(instanceName);
    jobDAO.saveOrUpdate(job);

  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#setRunningJob(java.lang.String)
   */
  public void setRunningJob(String uuid)
  {
    BudgesJob theJob = jobDAO.findByUUID(uuid);
    theJob.setDateJobStarted(new Date());
    Integer jobCount = incrementJobCount(theJob.getStartCount());
    theJob.setStartCount(jobCount);
    theJob.setJobStatus(JobStatusFlag.RUNNING);
    jobDAO.saveOrUpdate(theJob);
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#setDoneJob(java.lang.String)
   */
  public void setDoneJob(String uuid)
  {
    BudgesJob theJob = jobDAO.findByUUID(uuid);
    theJob.setDateJobEnded(new Date());
    theJob.setJobStatus(JobStatusFlag.DONE);
    jobDAO.saveOrUpdate(theJob);
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#findNewJobsFromQueueWithLimit(java.lang.String, int)
   */
  public List<BudgesJob> findNewJobsFromQueueWithLimit(String queue, int size)
  {
    return jobDAO.findNewJobsFromQueueWithLimit(queue, size);
  }


  /**
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#saveOrUpdate(mil.dtic.cbes.submissions.ValueObjects.BudgesJob)
   */
  public void saveOrUpdate(BudgesJob item)
  {
    jobDAO.saveOrUpdate(item);
    config.markConfigCacheForReload();
  }


  /**
   * @return TODO
   * @see mil.dtic.r2.jobmanager.services.SpringJobService#deleteJobsBeyondDate(java.util.Date)
   */
  public int deleteJobsBeyondDate(Date when)
  {
    return jobDAO.deleteJobsOlderThan(when);
  }
  
  private Integer incrementJobCount(Integer jobCount)
  {
    Integer newValue = null;
    if (jobCount == null)
    {
      jobCount = Integer.valueOf(0);
    }
    newValue = Integer.valueOf(jobCount.intValue() + 1);
    return(newValue);
  }


  /**
   * this method searches for entries in the job table that match the queuename
   * and instance name that configure this instance of the job manager. It
   * limits the search to the specified number of search elements and then saves
   * the values back to the DB right way.This claims that job for this instance.
   * If the save fails then we know another instance has claimed this job before
   * we were able to. In that case, continue looking for new jobs until the job
   * manager has either found enough jobs to fill the request, or there are no
   * more jobs ready to run.
   * 
   * 
   */
  public void restartPreviouslyRunningJobs(List<String> deadHosts)
  {
    String queueName = config.getQueueName();

    // We have to do this here, because the map we passed in to quartz
    // is not the same map that the job gets here. So we need a copy of
    // this that we can hold on to and use later for communication
    // with the job.
    // Two classes of jobs we have to find, those that were running,
    // and those that where scheduled.
    //
    log.info("Restarting jobs in queue named " + queueName + " and instances " + deadHosts);
    List<BudgesJob> jobList = new ArrayList<BudgesJob>();
    jobList.addAll(jobDAO.findJobsWithInstances(queueName, deadHosts.toArray(new String[0])));
    for (int i = 0; i < jobList.size(); i++)
    {
      BudgesJob item = jobList.get(i);
      item.setJobStatus(JobStatusFlag.NEW);
      saveOrUpdate(item);
    }
  }

  public void saveDecrementedRunningPdfJobCount()
  {
    configDAO.saveDecrementedRunningPdfJobCount();
  }
}
