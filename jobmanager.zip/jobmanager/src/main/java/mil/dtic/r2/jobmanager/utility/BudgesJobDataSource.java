package mil.dtic.r2.jobmanager.utility;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import mil.dtic.cbes.submissions.ValueObjects.BudgesJob;
import mil.dtic.cbes.submissions.dao.BudgesJobDAO;

public class BudgesJobDataSource extends ABudgesJobDataSource
{
	private BudgesJobDAO theDAO;
	private String queueName;
	private Date startDate;
	private Date finishDate;

	public BudgesJobDataSource(String queue, BudgesJobDAO theDAO)
	{
		this.theDAO = theDAO;
		this.queueName = queue;
	}
	
	@Override
	public int getAvailableRows()
	{
		int count = theDAO.findBudgesJobCountForQueueNamedInDateRange(queueName, startDate, finishDate);
		return count;
	}

	// Big steaming pile of hack. This should be fixed in the 
	// display code, but I can't figure out how to get the
	// beanmodel to expand its idea of what a property is. 
	// so when we are sorting in the UI on uuidstr, what
	// we need to sort on in the db is uuid, make the switch
	// here. 

	@Override
	List<BudgesJob> getJobListPaged(String[] entries, boolean ascending,
			int start, int end)
	{
		if (entries.length > 0)
		{
			for (int i = 0;i< entries.length;i++)
			{
				String value = entries[i];
				if (StringUtils.equalsIgnoreCase("uuidstr", value))
				{
					entries[i] = "uuid";
				}
			}
		}
		List<BudgesJob> results =  theDAO.findInDateRangeFromQueuePaged(queueName, startDate, finishDate, entries, ascending, start, end+1);
		return results;
	}

	public String getQueueName()
	{
		return queueName;
	}

	public void setQueueName(String queueName)
	{
		this.queueName = queueName;
	}

	public Date getStart()
	{
		return startDate;
	}

	public void setStart(Date start)
	{
		this.startDate = start;
	}

	public Date getFinish()
	{
		return finishDate;
	}

	public void setFinish(Date finish)
	{
		this.finishDate = finish;
	}

	
}
