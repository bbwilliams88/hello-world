(function() {
  var $, fnRenderActions, fnRenderDownloads, numberTemplate, _,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor; child.__super__ = parent.prototype; return child; };

if (!window.jobmanager) {
  window.jobmanager = {};
}

$ = jQuery;

_ = T5._;

window.setupDatatable = function(links) {
  var dt;
  try {
    new jobmanager.JobsDatatable("#datatable", links);
    dt = $("#datatable");
    return $("#datatable_filter").find("input").focus().select();
  } catch (ex) {
    return log(ex);
  }
};

var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
__hasProp = {}.hasOwnProperty,
__extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

jobmanager.JobsDatatable = (function(_super) {

__extends(JobsDatatable, _super);

function JobsDatatable(tableid, links) {
  var dt, hasCookie,
    _this = this;
  this.links = links;
  this.onStopLinkClick = __bind(this.onStopLinkClick, this);

  this.onResetLinkClick = __bind(this.onResetLinkClick, this);

  this.getRowId = __bind(this.getRowId, this);

  this.getRowData = __bind(this.getRowData, this);

  JobsDatatable.__super__.constructor.call(this);
  dt = $(tableid);
  if (!dt.length) {
    throw "table not found by id";
  }
  dt.find("thead tr.filter th").addClass("ui-state-default");
  _.extend(this.opts, {
    aoColumns: [
      {
        mDataProp: "uuid",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "dateCreated",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "jobStatus",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "queueName",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "dateJobStarted",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "dateJobEnded",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: "startCount",
        bSearchable: true,
        bSortable: true
      }, {
        mDataProp: null,
        bSearchable: false,
        bSortable: false,
        sClass: "center sortless",
        fnRender: fnRenderActions
      }
    ]
  });
  hasCookie = document.cookie.indexOf("datatable_r2downloads") !== -1;
  this.datatable = dt.dataTable(this.opts);
  $(window).resize(function() {
    return dt.css('width', '100%');
  });
  dt.css('width', '100%');
  this.datatable._fnProcessingDisplay(true);
  window.setTimeout(function() {
    _this.datatable.fnAddData(_this.parseJsonScriptTag("#tabledata"));
    return _this.datatable._fnProcessingDisplay(false);
  }, 50);
  this.datatable.delegate("a.resetlink", "click", this.onResetLinkClick);
  this.datatable.delegate("a.stoplink", "click", this.onStopLinkClick);
}

JobsDatatable.prototype.getRowData = function(domnode, mDataProp) {
  var row;
  row = $(domnode).parents("tr:first")[0];
  return this.datatable.fnGetData(row)[mDataProp];
};

JobsDatatable.prototype.getRowId = function(domnode) {
  return this.getRowData(domnode, "id");
};

JobsDatatable.prototype.onResetLinkClick = function(e) {
  var a, id;
  e.preventDefault();
  a = $(e.target);
  id = this.getRowId(e.target);
  a.attr("href", "" + this.links.name + "/" + id);
  CBES.progressDownload(a, showProgressManual, hideProgressManual);
  log(a.attr("href"));
  return window.location.href = a.attr("href");
};

JobsDatatable.prototype.onStopLinkClick = function(e) {
  var a, id;
  e.preventDefault();
  a = $(e.target);
  id = this.getRowId(e.target);
  a.attr("href", "" + this.links.name + "/" + id);
  CBES.progressDownload(a, showProgressManual, hideProgressManual);
  log(a.attr("href"));
  return window.location.href = a.attr("href");
};

return JobsDatatable;

})(CBES.Datatable);

nameTemplate = _.template """
<a href='#' class='namelink'><%= obj.aData.name %></a>
""".replace(/[\n\t]/g,"")

fnRenderActions = _.template """
<% { %>
	<a href="#" class="resetlink" title="Reset Job">Reset Job</a>&nbsp;
<% } %>
""".replace(/[\n\t]/g,"")
<% { %>
	<a href="#" class="stoplink" title="Stop Job">Stop Job</a>&nbsp;
<% } %>
""".replace(/[\n\t]/g,"")his);