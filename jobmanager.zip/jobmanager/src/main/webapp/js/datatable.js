
/**
 * Called by Tapestry to save the index of each column before the DataTable
 * re-arranges the columns.  Enables getIndex() to function later in life.
 */
function beforeDatatable()
{
	jQuery('#datatable th').each(function(index) { jQuery('#datatable').data(this.id, index); });
}

/**
 * Returns the saved column index value for the given header ID.
 * 
 * @param headerId The column name key to find the saved index.
 * @returns The index for the column name.
 */
function getIndex(headerId)
{
	return jQuery('#datatable').data(headerId);
}

/**
 * Called by Tapestry to set up and configure the DataTable.
 */
function setupDatatable(eventLink,dateRangeChanged)
{
	try
	{
		// Create and initialize the DataTable.
		opts = {
			"bJQueryUI": true,
			"bProcessing":true,
			"bServerSide": true,
			"sAjaxSource": eventLink,
			"sPaginationType": "full_numbers",
			"iDisplayLength" : 10,
			"oLanguage": { "sSearch": "Filter:" },
			"aLengthMenu": [[5, 10, 15, 20, 25, 50, -1], [5, 10, 15, 20, 25, 50, "All"]],
			"aaSorting" : [[getIndex('datesubmitted'), 'desc']],
			"bSortCellsTop" : true,
			"iCookieDuration" : 30 * 60, // 30 minutes.
			"sDom": 'C<"H"frp>t<"F"li>',
			"bStateSave": true,
			"fnStateLoadCallback": function (oSettings,oData) {
				if (dateRangeChanged) {
					oData.iStart = 0; // Reset page index on date change
				}
	    	},
			"fnStateLoadParams": function (oSettings,oData) {
				if (dateRangeChanged) {
					oData.iStart = 0; // Reset page index on date change
				}
	    	},
			"aoColumns" : [ { "bSearchable" : true, "bSortable" : true }, // Name
			                { "bSearchable" : true, "bSortable" : true }, // Group
			                { "bSearchable" : true, "bSortable" : true, "sType" : "date"   }, // Previous Fire Time
			                { "bSearchable" : true, "bSortable" : true, "sType" : "date"   }, // Next Fire Time
			                { "bSearchable" : true, "bSortable" : true }, // Last Run Time
			                { "bSearchable" : true, "bSortable" : true }, // Active
			                { "bSearchable" : true, "bSortable" : true } // Action
		]};
		var datatable = jQuery('#datatable').dataTable(opts);		
			
		// The following are to prevent problems when you hide columns in the DataTable.
		jQuery(window).bind('resize', function () { datatable.css('width', '100%'); } );
		datatable.css('width', '100%'); 

		// This doesn't work in IE < 9, but other browsers get a win.
		jQuery('#datatable_filter input').attr('placeholder', 'Filter on all columns...');

		// Finally, show the DataTable!
		datatable.show();
		
		// Focus on the filter field and select the text for the user to begin typing immediately.
		jQuery('#datatable_filter input').focus().select();
	}
	catch (ex)
	{
		log(ex);
	}
}



